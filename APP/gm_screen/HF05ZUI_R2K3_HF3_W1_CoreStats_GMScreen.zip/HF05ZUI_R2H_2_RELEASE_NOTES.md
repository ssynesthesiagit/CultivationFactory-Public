# HF05ZUI-R2H.2 Character Builder Insights and Background Advancement Patch

This is a Builder/UI patch over the unchanged **HF05ZUI-R2H consumer and acceptance contract**.

## Added

- Published Background ability-score increase selection: +2 to one listed ability or +1 to two listed abilities.
- Separate display of pre-Background point-buy scores and final adjusted scores.
- Published Background Origin Insight selection using each Background's own suggested list.
- Origin Insight synchronization and locking across the Background and Insights sections.
- Dedicated Insights browser with all 50 PHB General/Origin Insights and 518 Sphere Cultivation Insights across all 85 canonical Spheres.
- Printed Sphere variants and drawback scriptures for selected Spheres: 346 entries across 74 Spheres.
- Search/scope controls, compact descriptions, full-text tooltips, and selected-state badges.
- Draft retention and package export for Background ASI, selected Insights, and variants.
- New package records: `Selected_Insights.json`, `Sphere_Variants.json`, and `Background_Ability_Increase.json`.

## Preserved

- All R2H.1 Background grant, compact talent-description, and Foundation readability improvements.
- All 14 character-viewer tabs.
- HF05ZVK-R1E import compatibility.
- HF05ZUI-R2H acceptance version and HF05ZN-R2C combat compatibility.
- Existing Foundation, Sphere, talent, Origin Insight, and variant mechanics; this patch changes presentation and authoring capture only.

## Builder identifier

- Builder package version: `HF05ZUI-R2H-builder-v6`
- Builder patch: `HF05ZUI-R2H.2-BUILDER-INSIGHTS-ABILITY`
- Consumer target: `HF05ZUI-R2H`
