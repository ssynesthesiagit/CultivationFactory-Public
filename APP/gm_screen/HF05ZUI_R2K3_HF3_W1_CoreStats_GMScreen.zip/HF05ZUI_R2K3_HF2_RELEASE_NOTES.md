# HF05ZUI-R2K.3-HF2 Release Notes

- Added catalog-driven Sphere → multiple-talent composition for martial training sources.
- Added catalog-driven Recorded Art authoring with multiple talent expressions, tactical role, and source notes.
- Retained custom/source-specific entries and raw pipe rows.
- Explicitly marks the selector as organizational rather than a legality gate.
- Exports `Training_Source_and_Recorded_Arts.json` and enriched Builder Snapshot records.
- Clarified that Factory Handoff ZIPs are planning inputs; the factory creates canonical ledger and full Build JSONs during the six-command workflow.
- Updated handoff targets to Factory HF05ZVK-R1H and GM Screen HF05ZUI-R2K.3.
