# HF05ZUI-R2K.1 — Factory Compatibility Seal

- Native 18-tab R2K acceptance contract.
- Real acceptance exports identify consumer `HF05ZUI-R2K` and schema `HF05ZUI-R2K.RealAcceptanceReport.v1`.
- Validates exact tab order, all required Phase 2F sidecars, semantic projection, source candidate hash, and compact save/rehydration.
- Compatible with HF05ZVK-R1F Phase 2G Command 5 and Command 6.
- Cross-runtime JSON semantic hashes normalize integral decimals so Python and Chromium bind identical values.
- No character rules or visible feature mechanics changed.
