/* HF05ZUI-R2H.2 — Background ability/origin, Sphere variants, and complete Insight selector. */
(() => {
  const insightCatalog = window.TIANXIA_INSIGHT_CATALOG || { origin_insights: [], spheres: [] };
  const originCatalog = Array.isArray(insightCatalog.origin_insights) ? insightCatalog.origin_insights : [];
  const sphereInsightCatalog = Array.isArray(insightCatalog.spheres) ? insightCatalog.spheres : [];
  const normalized = (value) => String(value || "").trim().toLowerCase().replace(/[’‘]/g, "'").replace(/[^a-z0-9]+/g, " ").trim();
  const compactKey = (value) => normalized(value).replace(/\band\b/g, "").replace(/\s+/g, "");
  const originByName = new Map(originCatalog.map((row) => [compactKey(row.name), row]));
  const sphereCatalogByName = new Map(sphereInsightCatalog.map((row) => [compactKey(row.sphere), row]));
  const ABILITY_SHORT = { Strength:"STR", Dexterity:"DEX", Constitution:"CON", Intelligence:"INT", Wisdom:"WIS", Charisma:"CHA" };
  const ABILITY_FULL = Object.fromEntries(Object.entries(ABILITY_SHORT).map(([full, short]) => [short, full]));

  let insightSelections = {};
  let variantSelections = {};
  let backgroundOriginSelection = null;
  let backgroundAbilitySelection = null;
  let autoOriginApplied = false;

  const priorBuilderAbilityScores = builderAbilityScores;
  const priorBuilderBackgroundRecord = builderBackgroundRecord;
  const priorBuilderSnapshot = hf05zuiR2eBuilderSnapshot;
  const priorDraftSnapshot = hf05zuiR2eDraftSnapshot;
  const priorValidationRows = hf05zuiR2eValidationRows;
  const priorReadable = hf05zuiR2eReadable;
  const priorCompleteSheet = builderCompleteSheet;
  const priorPackageFiles = builderPackageFiles;
  const priorHandoffPackage = hf05zuiR2ePackage;
  const priorRenderSphereList = renderBuilderSphereList;
  const priorUpdateBuilderPreview = updateBuilderPreview;

  function backgroundTemplate() {
    const name = document.getElementById("builderBackground")?.value || "";
    return window.TIANXIA_BACKGROUND_CATALOG?.[name] || null;
  }

  function compactSummary(record = {}, max = 118) {
    const raw = String(record.summary || record.full_text || "Exact source text governs this selection.")
      .replace(/\*\*|__|`/g, "")
      .replace(/\s+/g, " ")
      .trim();
    const first = raw.split(/(?<=[.!?])\s+/)[0] || raw;
    return first.length > max ? `${first.slice(0, max - 3).trimEnd()}...` : first;
  }

  function titleText(record = {}) {
    return String(record.full_text || record.summary || "Exact source text governs this selection.")
      .replace(/\*\*|__|`/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 1400);
  }

  function baseAbilityScores() {
    const scores = priorBuilderAbilityScores();
    return Object.fromEntries(Object.entries(scores).map(([key, value]) => [key, Number(value || 0)]));
  }

  function abilityAdjustments() {
    const result = { STR:0, DEX:0, CON:0, INT:0, WIS:0, CHA:0 };
    Object.entries(backgroundAbilitySelection?.increases || {}).forEach(([ability, value]) => {
      const short = ABILITY_SHORT[ability] || ability;
      if (Object.prototype.hasOwnProperty.call(result, short)) result[short] += Number(value || 0);
    });
    return result;
  }

  builderAbilityScores = function builderAbilityScoresR2H2() {
    const base = baseAbilityScores();
    const adjustments = abilityAdjustments();
    return Object.fromEntries(Object.entries(base).map(([key, value]) => [key, value + (adjustments[key] || 0)]));
  };

  hf05zuiR2ePointBuy = function hf05zuiR2ePointBuyR2H2() {
    const scores = baseAbilityScores();
    const costs = {8:0,9:1,10:2,11:3,12:4,13:5,14:7,15:9};
    let valid = true;
    let total = 0;
    Object.values(scores).forEach((score) => {
      if (costs[score] === undefined) valid = false;
      else total += costs[score];
    });
    return { scores, total, valid, remaining:27-total, calculated_from:"pre-background ability scores" };
  };

  function abilityOptionsForBackground(background) {
    const abilities = Array.isArray(background?.ability_options) ? background.ability_options.filter((x) => ABILITY_SHORT[x]) : [];
    const options = abilities.map((ability) => ({
      id:`plus2_${ABILITY_SHORT[ability].toLowerCase()}`,
      mode:"one_plus_two",
      label:`${ability} +2`,
      increases:{[ability]:2},
      source_rule:"Increase one listed ability score by 2."
    }));
    for (let i=0; i<abilities.length; i += 1) {
      for (let j=i+1; j<abilities.length; j += 1) {
        options.push({
          id:`plus1_${ABILITY_SHORT[abilities[i]].toLowerCase()}_${ABILITY_SHORT[abilities[j]].toLowerCase()}`,
          mode:"two_plus_one",
          label:`${abilities[i]} +1 · ${abilities[j]} +1`,
          increases:{[abilities[i]]:1,[abilities[j]]:1},
          source_rule:"Increase two listed ability scores by 1 each."
        });
      }
    }
    return options;
  }

  function abilitySelectionValid(background) {
    if (!backgroundAbilitySelection) return false;
    return abilityOptionsForBackground(background).some((row) => row.id === backgroundAbilitySelection.id);
  }

  function renderBackgroundAbilityOptions({ preserve=false } = {}) {
    const target = document.getElementById("builderBackgroundAbilityOptions");
    const status = document.getElementById("builderBackgroundAbilityStatus");
    if (!target) return;
    const background = backgroundTemplate();
    if (!background) {
      backgroundAbilitySelection = null;
      target.innerHTML = `<div class="empty-state">Choose a background to see its legal ability-score increases.</div>`;
      const finalTarget = document.getElementById("builderFinalAbilityScores");
      if (finalTarget) finalTarget.innerHTML = "";
      if (status) status.textContent = "Choose a background first.";
      return;
    }
    const options = abilityOptionsForBackground(background);
    if (!preserve || !abilitySelectionValid(background)) backgroundAbilitySelection = null;
    target.innerHTML = options.map((option) => {
      const checked = backgroundAbilitySelection?.id === option.id;
      return `<label class="background-grant-card background-ability-card${checked ? " selected" : ""}" title="${escapeHtml(option.source_rule)}"><input type="radio" name="builderBackgroundAbility" value="${escapeHtml(option.id)}" ${checked ? "checked" : ""}><span><strong>${escapeHtml(option.label)}</strong><small>Published Background increase</small><span>${escapeHtml(option.source_rule)}</span></span></label>`;
    }).join("");
    target.querySelectorAll('input[name="builderBackgroundAbility"]').forEach((radio, index) => radio.addEventListener("change", () => {
      if (!radio.checked) return;
      backgroundAbilitySelection = { ...options[index], background:background.name };
      renderBackgroundAbilityOptions({ preserve:true });
      updateBuilderPreview();
    }));
    const finalScores = builderAbilityScores();
    const baseScores = baseAbilityScores();
    const finalTarget = document.getElementById("builderFinalAbilityScores");
    if (finalTarget) finalTarget.innerHTML = Object.keys(baseScores).map((ability) => {
      const changed = finalScores[ability] !== baseScores[ability];
      return `<span class="builder-final-score${changed ? " increased" : ""}"><strong>${escapeHtml(ability)}</strong><span>${escapeHtml(baseScores[ability])}${changed ? ` → ${escapeHtml(finalScores[ability])}` : ""}</span></span>`;
    }).join("");
    if (status) {
      status.textContent = backgroundAbilitySelection
        ? `${backgroundAbilitySelection.label} applied · final ${Object.entries(backgroundAbilitySelection.increases).map(([name]) => `${ABILITY_SHORT[name]} ${finalScores[ABILITY_SHORT[name]]}`).join(" / ")}`
        : `${options.length} legal arrangements; choose one.`;
    }
  }

  function originRecord(name) {
    return originByName.get(compactKey(name)) || null;
  }

  function unlockOriginFields({ clear=false } = {}) {
    const name = document.getElementById("builderOriginInsightName");
    const source = document.getElementById("builderOriginInsightSource");
    const mechanics = document.getElementById("builderOriginInsightMechanics");
    if (clear && autoOriginApplied) {
      if (name) name.value = "";
      if (source) source.value = "printed";
      if (mechanics) mechanics.value = "";
    }
    if (name) name.readOnly = false;
    if (source) source.disabled = false;
    if (mechanics) mechanics.readOnly = false;
    autoOriginApplied = false;
  }

  function syncOriginFields() {
    const record = backgroundOriginSelection ? originRecord(backgroundOriginSelection.name) : null;
    if (!record) {
      unlockOriginFields({ clear:true });
      return;
    }
    const name = document.getElementById("builderOriginInsightName");
    const source = document.getElementById("builderOriginInsightSource");
    const mechanics = document.getElementById("builderOriginInsightMechanics");
    if (name) { name.value = record.name; name.readOnly = true; }
    if (source) { source.value = "printed"; source.disabled = true; }
    if (mechanics) { mechanics.value = record.full_text || record.summary || ""; mechanics.readOnly = true; }
    autoOriginApplied = true;
  }

  function renderBackgroundOriginOptions({ preserve=false } = {}) {
    const target = document.getElementById("builderBackgroundOriginOptions");
    const status = document.getElementById("builderBackgroundOriginStatus");
    if (!target) return;
    const background = backgroundTemplate();
    if (!background) {
      backgroundOriginSelection = null;
      unlockOriginFields({ clear:true });
      target.innerHTML = `<div class="empty-state">Choose a background to see its Origin Insight options.</div>`;
      if (status) status.textContent = "Choose a background first.";
      return;
    }
    const names = Array.isArray(background.origin_insights) ? background.origin_insights : [];
    if (!preserve || !backgroundOriginSelection || backgroundOriginSelection.background !== background.name || !names.some((name) => compactKey(name) === compactKey(backgroundOriginSelection.name))) {
      backgroundOriginSelection = null;
      unlockOriginFields({ clear:true });
    }
    target.innerHTML = names.map((name, index) => {
      const record = originRecord(name) || { name, summary:"Published Background suggestion; exact Origin Insight text is unavailable." };
      const checked = backgroundOriginSelection && compactKey(backgroundOriginSelection.name) === compactKey(record.name);
      return `<label class="background-grant-card background-origin-card${checked ? " selected" : ""}" title="${escapeHtml(titleText(record))}"><input type="radio" name="builderBackgroundOrigin" value="${escapeHtml(`${background.name}:${index+1}`)}" ${checked ? "checked" : ""}><span><strong>${escapeHtml(record.name)}</strong><small>Origin Insight · locked through Background</small><span>${escapeHtml(compactSummary(record))}</span></span></label>`;
    }).join("");
    target.querySelectorAll('input[name="builderBackgroundOrigin"]').forEach((radio, index) => radio.addEventListener("change", () => {
      if (!radio.checked) return;
      const record = originRecord(names[index]) || { name:names[index], summary:"", full_text:"" };
      backgroundOriginSelection = { ...record, background:background.name, choice_id:radio.value, locked_by_background:true };
      syncOriginFields();
      renderBackgroundOriginOptions({ preserve:true });
      renderInsightBrowser();
      updateBuilderPreview();
    }));
    if (backgroundOriginSelection) syncOriginFields();
    if (status) status.textContent = backgroundOriginSelection ? `${backgroundOriginSelection.name} locked into the Insights section.` : `${names.length} suggested Origin Insights; choose one.`;
  }

  function sphereCatalogRecord(sphere) {
    return sphereCatalogByName.get(compactKey(sphere)) || { sphere, insights:[], variants:[] };
  }

  function selectedNames(store, sphere) {
    const key = Object.keys(store).find((name) => compactKey(name) === compactKey(sphere));
    return new Set(key && Array.isArray(store[key]) ? store[key] : []);
  }

  function setSelectedNames(store, sphere, values) {
    Object.keys(store).forEach((key) => { if (compactKey(key) === compactKey(sphere)) delete store[key]; });
    if (values.size) store[sphere] = [...values];
  }

  function toggleVariant(sphere, name, checked) {
    const values = selectedNames(variantSelections, sphere);
    if (checked) values.add(name); else values.delete(name);
    setSelectedNames(variantSelections, sphere, values);
    renderVariantBrowser();
    updateBuilderPreview();
  }

  function renderVariantBrowser() {
    const target = document.getElementById("builderVariantBrowser");
    const status = document.getElementById("builderVariantSelectionStatus");
    if (!target) return;
    if (!builderSphereNames.length) {
      target.innerHTML = `<div class="empty-state">Select a Sphere to browse its printed variants and drawback scriptures.</div>`;
      if (status) status.textContent = "No Spheres selected.";
      return;
    }
    const sections = builderSphereNames.map((sphere) => {
      const catalogRow = sphereCatalogRecord(sphere);
      const variants = Array.isArray(catalogRow.variants) ? catalogRow.variants : [];
      const chosen = selectedNames(variantSelections, sphere);
      const cards = variants.length ? variants.map((variant) => {
        const on = chosen.has(variant.name);
        return `<label class="builder-talent-card builder-variant-card${on ? " selected" : ""}" title="${escapeHtml(titleText(variant))}"><input type="checkbox" data-r2h2-variant-sphere="${escapeHtml(sphere)}" data-r2h2-variant-name="${escapeHtml(variant.name)}" ${on ? "checked" : ""}><span><strong>${escapeHtml(variant.name)}</strong><span class="builder-talent-meta"><span class="builder-talent-badge variant-badge">Variant</span><span class="builder-talent-badge">Source line ${escapeHtml(variant.line || "—")}</span></span><span class="builder-talent-summary">${escapeHtml(compactSummary(variant))}</span></span></label>`;
      }).join("") : `<div class="empty-state compact-empty">No printed variant or drawback scripture is recorded for this Sphere.</div>`;
      return `<details class="builder-talent-sphere builder-variant-sphere" ${variants.length ? "open" : ""}><summary><span>${escapeHtml(sphere)} variants</span><span class="builder-talent-count">${chosen.size} selected · ${variants.length} catalog entries</span></summary><div class="builder-talent-grid">${cards}</div></details>`;
    }).join("");
    target.innerHTML = sections;
    target.querySelectorAll('[data-r2h2-variant-name]').forEach((box) => box.addEventListener("change", () => toggleVariant(box.dataset.r2h2VariantSphere, box.dataset.r2h2VariantName, box.checked)));
    const count = Object.values(variantSelections).reduce((sum, values) => sum + (Array.isArray(values) ? values.length : 0), 0);
    if (status) status.textContent = `${count} selected variant${count === 1 ? "" : "s"}. Source-specific exclusivity and drawbacks remain binding.`;
  }

  function toggleInsight(sphere, name, checked) {
    const values = selectedNames(insightSelections, sphere);
    if (checked) values.add(name); else values.delete(name);
    setSelectedNames(insightSelections, sphere, values);
    renderInsightBrowser();
    updateBuilderPreview();
  }

  function originInsightCards(query) {
    const rows = originCatalog.filter((row) => !query || normalized(`${row.name} ${row.summary} ${row.full_text}`).includes(query));
    if (!rows.length) return "";
    const selectedName = backgroundOriginSelection?.name || "";
    const cards = rows.map((row) => {
      const selected = compactKey(row.name) === compactKey(selectedName);
      return `<label class="builder-talent-card builder-insight-card origin-insight-card${selected ? " selected background-granted" : ""}" title="${escapeHtml(titleText(row))}"><input type="checkbox" ${selected ? "checked" : ""} disabled aria-label="Origin Insights are selected through the Background section"><span><strong>${escapeHtml(row.name)}</strong><span class="builder-talent-meta"><span class="builder-talent-badge origin-badge">Origin Insight</span>${selected ? `<span class="builder-talent-badge background-badge">Locked by Background</span>` : `<span class="builder-talent-badge">Choose above</span>`}</span><span class="builder-talent-summary">${escapeHtml(compactSummary(row))}</span></span></label>`;
    }).join("");
    return `<details class="builder-talent-sphere" open><summary><span>General / Origin Insights</span><span class="builder-talent-count">${selectedName ? 1 : 0} locked · ${rows.length} shown / ${originCatalog.length}</span></summary><div class="builder-talent-grid">${cards}</div></details>`;
  }

  function sphereInsightSections(spheres, query) {
    return spheres.map((sphere) => {
      const row = sphereCatalogRecord(sphere);
      const all = Array.isArray(row.insights) ? row.insights : [];
      const insights = all.filter((insight) => !query || normalized(`${insight.name} ${insight.summary} ${insight.full_text}`).includes(query));
      if (!insights.length && query) return "";
      const chosen = selectedNames(insightSelections, sphere);
      const cards = insights.length ? insights.map((insight) => {
        const on = chosen.has(insight.name);
        return `<label class="builder-talent-card builder-insight-card${on ? " selected" : ""}" title="${escapeHtml(titleText(insight))}"><input type="checkbox" data-r2h2-insight-sphere="${escapeHtml(sphere)}" data-r2h2-insight-name="${escapeHtml(insight.name)}" ${on ? "checked" : ""}><span><strong>${escapeHtml(insight.name)}</strong><span class="builder-talent-meta"><span class="builder-talent-badge insight-badge">${escapeHtml(sphere)} Insight</span><span class="builder-talent-badge">Source line ${escapeHtml(insight.line || "—")}</span></span><span class="builder-talent-summary">${escapeHtml(compactSummary(insight))}</span></span></label>`;
      }).join("") : `<div class="empty-state compact-empty">No Sphere Insights match the current search.</div>`;
      return `<details class="builder-talent-sphere" open><summary><span>${escapeHtml(sphere)} Insights</span><span class="builder-talent-count">${chosen.size} selected · ${insights.length} shown / ${all.length}</span></summary><div class="builder-talent-grid">${cards}</div></details>`;
    }).filter(Boolean).join("");
  }

  function renderInsightBrowser() {
    const target = document.getElementById("builderInsightBrowser");
    const status = document.getElementById("builderInsightSelectionStatus");
    if (!target) return;
    const query = normalized(document.getElementById("builderInsightSearch")?.value || "");
    const scope = document.getElementById("builderInsightScope")?.value || "selected_spheres";
    let html = "";
    if (scope === "origin" || scope === "all") html += originInsightCards(query);
    if (scope === "selected_spheres" || scope === "all") html += sphereInsightSections(builderSphereNames, query);
    if (scope === "all_spheres") html += sphereInsightSections(sphereInsightCatalog.map((row) => row.sphere), query);
    if (!html) {
      const message = scope === "selected_spheres" && !builderSphereNames.length
        ? "Select one or more Spheres above to browse their Cultivation Insights."
        : "No Insights match the current search and scope.";
      html = `<div class="empty-state">${escapeHtml(message)}</div>`;
    }
    target.innerHTML = html;
    target.querySelectorAll('[data-r2h2-insight-name]').forEach((box) => box.addEventListener("change", () => toggleInsight(box.dataset.r2h2InsightSphere, box.dataset.r2h2InsightName, box.checked)));
    const sphereCount = Object.values(insightSelections).reduce((sum, values) => sum + (Array.isArray(values) ? values.length : 0), 0);
    if (status) status.textContent = `${sphereCount} Sphere Insight${sphereCount === 1 ? "" : "s"} selected${backgroundOriginSelection ? ` · ${backgroundOriginSelection.name} locked as Origin Insight` : " · choose an Origin Insight above"}.`;
  }

  function selectedVariantRows() {
    const rows = [];
    Object.entries(variantSelections).sort(([a],[b]) => a.localeCompare(b)).forEach(([sphere, names]) => {
      const catalogRow = sphereCatalogRecord(sphere);
      (names || []).forEach((name) => {
        const record = (catalogRow.variants || []).find((row) => compactKey(row.name) === compactKey(name)) || { name, summary:"", full_text:"" };
        rows.push({
          row_id:`sphere_variant_${rows.length+1}`,
          name:record.name,
          sphere:catalogRow.sphere || sphere,
          summary:record.summary || "",
          mechanics:record.full_text || record.summary || "",
          source:"Tianxia Sphere Compendium R0I",
          source_line:record.line || null,
          raw:`${record.name} | ${catalogRow.sphere || sphere} | ${record.full_text || record.summary || ""}`
        });
      });
    });
    return rows;
  }

  function selectedSphereInsightRows() {
    const rows = [];
    Object.entries(insightSelections).sort(([a],[b]) => a.localeCompare(b)).forEach(([sphere, names]) => {
      const catalogRow = sphereCatalogRecord(sphere);
      (names || []).forEach((name) => {
        const record = (catalogRow.insights || []).find((row) => compactKey(row.name) === compactKey(name)) || { name, summary:"", full_text:"" };
        rows.push({
          row_id:`sphere_insight_${rows.length+1}`,
          name:record.name,
          source:`${catalogRow.sphere || sphere} Sphere`,
          effect:record.full_text || record.summary || "",
          summary:record.summary || "",
          insight_type:"sphere_cultivation_insight",
          source_sphere:catalogRow.sphere || sphere,
          source_line:record.line || null,
          raw:`${record.name} | ${catalogRow.sphere || sphere} Sphere | ${record.full_text || record.summary || ""}`
        });
      });
    });
    return rows;
  }

  function selectedOriginRow() {
    const record = backgroundOriginSelection ? originRecord(backgroundOriginSelection.name) : null;
    if (!record) return null;
    return {
      row_id:"origin_insight_background_locked",
      name:record.name,
      source:`Origin Insight · ${backgroundOriginSelection.background} Background`,
      effect:record.full_text || record.summary || "",
      summary:record.summary || "",
      insight_type:"origin_insight",
      locked_by_background:true,
      background:backgroundOriginSelection.background,
      source_line:record.number || null,
      raw:`${record.name} | Origin Insight | ${record.full_text || record.summary || ""}`
    };
  }

  function syncSphereDependentSelections() {
    const allowed = new Set(builderSphereNames.map(compactKey));
    [insightSelections, variantSelections].forEach((store) => Object.keys(store).forEach((sphere) => {
      if (!allowed.has(compactKey(sphere))) delete store[sphere];
    }));
  }

  builderBackgroundRecord = function builderBackgroundRecordR2H2() {
    const record = priorBuilderBackgroundRecord();
    if (!record) return null;
    record.ability_score_increase = backgroundAbilitySelection ? {
      mode:backgroundAbilitySelection.mode,
      label:backgroundAbilitySelection.label,
      increases:{...backgroundAbilitySelection.increases},
      source_rule:backgroundAbilitySelection.source_rule,
      background_locked:true
    } : null;
    record.selected_origin_insight = backgroundOriginSelection ? {
      name:backgroundOriginSelection.name,
      locked_by_background:true,
      source:"Tianxia PHB Origin Insights v0.4"
    } : null;
    return record;
  };

  hf05zuiR2eBuilderSnapshot = function hf05zuiR2eBuilderSnapshotR2H2() {
    const snapshot = priorBuilderSnapshot();
    const sphereInsights = selectedSphereInsightRows();
    const manualInsights = Array.isArray(snapshot.additional_insights) ? snapshot.additional_insights : [];
    const seen = new Set();
    snapshot.additional_insights = [...sphereInsights, ...manualInsights].filter((row) => {
      const key = compactKey(`${row.name}|${row.source || row.source_sphere || ""}`);
      if (!key || seen.has(key)) return false;
      seen.add(key); return true;
    });
    const origin = selectedOriginRow();
    if (origin) {
      const record = originRecord(origin.name);
      snapshot.origin_insight = {
        name:origin.name,
        source_type:"printed",
        mechanics:record?.full_text || origin.effect,
        summary:record?.summary || origin.summary,
        background:snapshot.background?.name || backgroundOriginSelection?.background || "",
        background_choice_id:backgroundOriginSelection?.choice_id || "",
        locked_by_background:true,
        counts_against_background:false,
        counts_against_level_talent:false,
        counts_against_trained_choices:false
      };
    }
    snapshot.selected_insights = [origin, ...snapshot.additional_insights].filter(Boolean);
    snapshot.sphere_variants = selectedVariantRows();
    snapshot.abilities.base_scores = baseAbilityScores();
    snapshot.abilities.background_increase = backgroundAbilitySelection ? {
      mode:backgroundAbilitySelection.mode,
      label:backgroundAbilitySelection.label,
      increases:{...backgroundAbilitySelection.increases},
      source_rule:backgroundAbilitySelection.source_rule,
      background_locked:true
    } : null;
    snapshot.abilities.final_scores = builderAbilityScores();
    snapshot.abilities.scores = snapshot.abilities.final_scores;
    snapshot.builder_patch = "HF05ZUI-R2H.2-BUILDER-INSIGHTS-ABILITY";
    snapshot.builder_version = document.getElementById("builderVersion")?.value || "HF05ZUI-R2H-builder-v6";
    snapshot.insight_catalog = {
      origin_insights:originCatalog.length,
      sphere_insights:sphereInsightCatalog.reduce((sum, row) => sum + (row.insights || []).length, 0),
      sphere_variants:sphereInsightCatalog.reduce((sum, row) => sum + (row.variants || []).length, 0),
      selected_sphere_insights:sphereInsights.length,
      selected_variants:snapshot.sphere_variants.length,
      origin_locked:Boolean(origin)
    };
    return snapshot;
  };

  hf05zuiR2eDraftSnapshot = function hf05zuiR2eDraftSnapshotR2H2() {
    const draft = priorDraftSnapshot();
    draft.insightSelections = JSON.parse(JSON.stringify(insightSelections));
    draft.variantSelections = JSON.parse(JSON.stringify(variantSelections));
    draft.backgroundOriginSelection = backgroundOriginSelection ? { ...backgroundOriginSelection } : null;
    draft.backgroundAbilitySelection = backgroundAbilitySelection ? JSON.parse(JSON.stringify(backgroundAbilitySelection)) : null;
    draft.builderPatch = "HF05ZUI-R2H.2-BUILDER-INSIGHTS-ABILITY";
    return draft;
  };

  hf05zuiR2eValidationRows = function hf05zuiR2eValidationRowsR2H2(snapshot) {
    const rows = priorValidationRows(snapshot);
    rows.splice(3, 0,
      { label:"Background ASI", value:snapshot.abilities.background_increase?.label || "Choose an increase", state:snapshot.abilities.background_increase ? "pass" : "warn" },
      { label:"Insights", value:`${snapshot.additional_insights.length} Sphere/additional · ${snapshot.origin_insight?.locked_by_background ? "Origin locked" : "Origin missing"}`, state:snapshot.origin_insight?.locked_by_background ? "pass" : "warn" },
      { label:"Sphere variants", value:String(snapshot.sphere_variants.length), state:"pass" }
    );
    return rows;
  };

  hf05zuiR2eReadable = function hf05zuiR2eReadableR2H2(snapshot = hf05zuiR2eBuilderSnapshot()) {
    const base = priorReadable(snapshot);
    const insightLines = snapshot.additional_insights.length ? snapshot.additional_insights.map((row) => `- ${row.name} | ${row.source}`) : ["- None selected"];
    const variantLines = snapshot.sphere_variants.length ? snapshot.sphere_variants.map((row) => `- ${row.name} | ${row.sphere}`) : ["- None selected"];
    return `${base}\n\n## Selected Cultivation Insights\n${insightLines.join("\n")}\n\n## Selected Sphere Variants\n${variantLines.join("\n")}\n\n## Background Ability Increase\n${snapshot.abilities.background_increase?.label || "Not selected."}`;
  };

  builderCompleteSheet = function builderCompleteSheetR2H2() {
    const sheet = priorCompleteSheet();
    const snapshot = hf05zuiR2eBuilderSnapshot();
    sheet.abilities.base_scores = snapshot.abilities.base_scores;
    sheet.abilities.background_increase = snapshot.abilities.background_increase;
    sheet.abilities.scores = snapshot.abilities.final_scores;
    sheet.build.insights = snapshot.additional_insights;
    sheet.build.selected_insights = snapshot.selected_insights;
    sheet.build.sphere_variants = snapshot.sphere_variants;
    sheet.identity.origin_insight = snapshot.origin_insight;
    if (sheet.identity.background) {
      sheet.identity.background.ability_score_increase = snapshot.abilities.background_increase;
      sheet.identity.background.selected_origin_insight = snapshot.origin_insight;
    }
    return sheet;
  };

  function insertPackageBlock(blocks, row) {
    if (blocks.some((block) => block.name === row.name)) return;
    const manifestIndex = blocks.findIndex((block) => block.name === "package_manifest.json");
    blocks.splice(manifestIndex >= 0 ? manifestIndex : blocks.length, 0, row);
  }

  builderPackageFiles = function builderPackageFilesR2H2() {
    const pkg = priorPackageFiles();
    const snapshot = hf05zuiR2eBuilderSnapshot();
    insertPackageBlock(pkg.blocks, { name:"Selected_Insights.json", content:JSON.stringify({ origin_insight:snapshot.origin_insight, cultivation_insights:snapshot.additional_insights, selected_insights:snapshot.selected_insights }, null, 2) });
    insertPackageBlock(pkg.blocks, { name:"Sphere_Variants.json", content:JSON.stringify({ sphere_variants:snapshot.sphere_variants }, null, 2) });
    insertPackageBlock(pkg.blocks, { name:"Background_Ability_Increase.json", content:JSON.stringify({ base_scores:snapshot.abilities.base_scores, background_increase:snapshot.abilities.background_increase, final_scores:snapshot.abilities.final_scores }, null, 2) });
    const request = pkg.blocks.find((row) => row.name === "Action_Generation_Request.json");
    if (request) {
      try {
        const data = JSON.parse(request.content);
        data.feature_sources = data.feature_sources || {};
        data.feature_sources.cultivation_insights = snapshot.additional_insights;
        data.feature_sources.sphere_variants = snapshot.sphere_variants;
        request.content = JSON.stringify(data, null, 2);
      } catch {}
    }
    const manifestBlock = pkg.blocks.find((row) => row.name === "package_manifest.json");
    if (manifestBlock) {
      try {
        const manifest = JSON.parse(manifestBlock.content);
        manifest.builder_patch = snapshot.builder_patch;
        manifest.files = pkg.blocks.map((row) => row.name);
        manifestBlock.content = JSON.stringify(manifest, null, 2);
      } catch {}
    }
    return pkg;
  };

  hf05zuiR2ePackage = function hf05zuiR2ePackageR2H2(mode) {
    const pkg = priorHandoffPackage(mode);
    const snapshot = hf05zuiR2eBuilderSnapshot();
    const files = pkg.files || [];
    const add = (name, content) => {
      if (files.some((row) => row.name === name)) return;
      const index = files.findIndex((row) => row.name === "package_manifest.json");
      files.splice(index >= 0 ? index : files.length, 0, { name, content:JSON.stringify(content, null, 2) });
    };
    add("Selected_Insights.json", { origin_insight:snapshot.origin_insight, cultivation_insights:snapshot.additional_insights, selected_insights:snapshot.selected_insights });
    add("Sphere_Variants.json", { sphere_variants:snapshot.sphere_variants });
    add("Background_Ability_Increase.json", { base_scores:snapshot.abilities.base_scores, background_increase:snapshot.abilities.background_increase, final_scores:snapshot.abilities.final_scores });
    const locks = files.find((row) => row.name === "User_Locks.json");
    if (locks) {
      try {
        const data = JSON.parse(locks.content);
        data.background_ability_increase = snapshot.abilities.background_increase;
        data.background_origin_insight = snapshot.origin_insight;
        locks.content = JSON.stringify(data, null, 2);
      } catch {}
    }
    const authoredLock = files.find((row) => row.name === "Authored_Mechanics_Lock.json");
    if (authoredLock) authoredLock.content = JSON.stringify(snapshot, null, 2);
    const request = files.find((row) => row.name === "Action_Generation_Request.json");
    if (request) {
      try {
        const data = JSON.parse(request.content);
        data.feature_sources = data.feature_sources || {};
        data.feature_sources.cultivation_insights = snapshot.additional_insights;
        data.feature_sources.sphere_variants = snapshot.sphere_variants;
        request.content = JSON.stringify(data, null, 2);
      } catch {}
    }
    const manifest = files.find((row) => row.name === "package_manifest.json");
    if (manifest) {
      try {
        const data = JSON.parse(manifest.content);
        data.builder_patch = snapshot.builder_patch;
        data.files = files.map((row) => row.name);
        manifest.content = JSON.stringify(data, null, 2);
      } catch {}
    }
    return pkg;
  };

  renderBuilderSphereList = function renderBuilderSphereListR2H2() {
    priorRenderSphereList();
    syncSphereDependentSelections();
    renderVariantBrowser();
    renderInsightBrowser();
  };

  // Keep the established R2H preview pipeline intact. Sphere-dependent R2H.2
  // surfaces are refreshed through renderBuilderSphereList, while Background
  // controls refresh from their own events. This avoids duplicating the full
  // package/visual-sheet rebuild on every Background change.

  function restoreR2H2State() {
    try {
      const saved = JSON.parse(localStorage.getItem("hf05zui_r2e_builder_draft") || "{}");
      insightSelections = saved.insightSelections && typeof saved.insightSelections === "object" ? saved.insightSelections : {};
      variantSelections = saved.variantSelections && typeof saved.variantSelections === "object" ? saved.variantSelections : {};
      backgroundOriginSelection = saved.backgroundOriginSelection && typeof saved.backgroundOriginSelection === "object" ? saved.backgroundOriginSelection : null;
      backgroundAbilitySelection = saved.backgroundAbilitySelection && typeof saved.backgroundAbilitySelection === "object" ? saved.backgroundAbilitySelection : null;
      syncSphereDependentSelections();
      renderBackgroundAbilityOptions({ preserve:true });
      renderBackgroundOriginOptions({ preserve:true });
      renderVariantBrowser();
      renderInsightBrowser();
      updateBuilderPreview();
    } catch {
      insightSelections = {};
      variantSelections = {};
      backgroundOriginSelection = null;
      backgroundAbilitySelection = null;
    }
  }

  function resetR2H2State() {
    insightSelections = {};
    variantSelections = {};
    backgroundOriginSelection = null;
    backgroundAbilitySelection = null;
    unlockOriginFields({ clear:true });
    const version = document.getElementById("builderVersion");
    if (version) version.value = "HF05ZUI-R2H-builder-v6";
    renderBackgroundAbilityOptions();
    renderBackgroundOriginOptions();
    renderVariantBrowser();
    renderInsightBrowser();
  }

  ["builderStr","builderDex","builderCon","builderInt","builderWis","builderCha"].forEach((id) => {
    document.getElementById(id)?.addEventListener("input", () => renderBackgroundAbilityOptions({ preserve:true }));
  });
  document.getElementById("builderInsightSearch")?.addEventListener("input", renderInsightBrowser);
  document.getElementById("builderInsightScope")?.addEventListener("change", renderInsightBrowser);
  document.getElementById("builderBackground")?.addEventListener("change", () => {
    backgroundOriginSelection = null;
    backgroundAbilitySelection = null;
    unlockOriginFields({ clear:true });
    renderBackgroundAbilityOptions();
    renderBackgroundOriginOptions();
    renderInsightBrowser();
    setTimeout(() => priorUpdateBuilderPreview(), 0);
  });
  document.getElementById("builderLoadDraftButton")?.addEventListener("click", () => setTimeout(restoreR2H2State, 30));
  document.getElementById("builderResetButton")?.addEventListener("click", () => setTimeout(resetR2H2State, 30));
  document.getElementById("builderAddSphereButton")?.addEventListener("click", () => setTimeout(() => { renderVariantBrowser(); renderInsightBrowser(); }, 0));

  const version = document.getElementById("builderVersion");
  if (version && (!version.value || /builder-v5$/i.test(version.value))) version.value = "HF05ZUI-R2H-builder-v6";
  renderBackgroundAbilityOptions();
  renderBackgroundOriginOptions();
  renderVariantBrowser();
  renderInsightBrowser();
  updateBuilderPreview();
})();
