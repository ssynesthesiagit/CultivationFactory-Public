# Foundation Family and Path Expression Contract v1

## Authority

This contract governs all 34 Foundation families and 86 supported expressions in the RC1 catalog.

## Path expressions

- Body Refining uses a **Body Aspect**, developed through a Tempering Record, inherited physique, innate constitution, transformed body, or compatible lineage procedure.
- Qi Cultivation uses a **Cultivation Root**, with a Root Aspect, dantian/meridian architecture, Qi behavior, affinity, compatibility, bottlenecks, damage, repair, and breakthrough logic.
- Spirit Awakening uses a **Soul Anchor**, where self-comprehension becomes Resonance, an Aura Signature, a mechanically exact Refined Aura, a persistent Perfected Aura, and a Domain Seed.
- Unsupported expressions are intentional exclusions and may not be inferred.

## Complexity and power

- Each expression uses one Foundation resource and normally three primary spend features. A fourth tightly related spend is permitted when the Foundation grade and central cultivation identity justify it; four is the hard maximum.
- Combat features do not recharge by rest. Out-of-combat repair, diagnosis, purification, preparation, and advancement procedures may use rest-scale time.
- Numerical effects use cultivation-first scaling. D&D supplies resolution rules, not the power ceiling.

## Selection and integration

- Selecting a family does not grant all of its expressions. Select the expression legal for the character's Path.
- Multiple expressions combine only through a cultivation Method that explicitly authorizes them.
- The Method must define the primary structure, unified or separate resource behavior, translated benefits, advancement, damage propagation, repair, deviations, Source CL, and Realm Suppression.
- The default for an integrated Foundation is one unified resource. Full benefits do not need to be flattened merely because the Attainment burden is extreme.

## Aura stacking

- Identical numeric Aura bonuses do not stack; use the highest applicable value.
- Distinct permissions and detections may coexist when their scopes differ.
- A single event cannot generate the same Foundation resource more than once.
- A Soul Anchor Aura is not a complete Domain. The Perfected Aura is the persistent seed from which later Sphere/Dao/Method Domain expressions develop.

## Stacking and suppression

Foundation, active Primary Method, item, Path, and other authorized modifiers stack unless a printed rule states otherwise. Realm Suppression retains Foundation identity and passive cultivated quality while disabling expressions above the available Source CL or stage. Injuries and deviations remain.
