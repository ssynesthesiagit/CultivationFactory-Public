/* HF05ZUI-R2K.3-HF1 — Builder talent readability, full-source hover, and dedicated Insight/variant separation. */
(() => {
  const catalog = Array.isArray(window.TIANXIA_SPHERE_TALENT_CATALOG) ? window.TIANXIA_SPHERE_TALENT_CATALOG : [];
  const normalized = (value) => String(value || "").trim().toLowerCase().replace(/[’‘]/g, "'").replace(/[^a-z0-9]+/g, " ").trim();
  const compactKey = (value) => normalized(value).replace(/\band\b/g, "").replace(/\s+/g, "");
  const catalogByName = new Map();
  catalog.forEach((row) => {
    catalogByName.set(normalized(row.name), row);
    catalogByName.set(compactKey(row.name), row);
  });
  const dedicatedNonTalentNames = new Map();
  (window.TIANXIA_INSIGHT_CATALOG?.spheres || []).forEach((row) => {
    const names = new Set([...(row.insights || []), ...(row.variants || [])].map((item) => compactKey(item.name)));
    dedicatedNonTalentNames.set(compactKey(row.sphere), names);
  });
  const isDedicatedNonTalent = (sphere, name) => dedicatedNonTalentNames.get(compactKey(sphere))?.has(compactKey(name)) || false;
  const selectableTalents = (sphereRow) => (sphereRow?.talents || []).filter((talent) => !isDedicatedNonTalent(sphereRow?.name, talent.name));
  const existingSphereMeta = new Map(SPHERES.map((row) => [String(row.name || "").toLowerCase(), row]));
  const genericMeta = (row) => ({
    name: row.name,
    path: row.path || (row.catalog === "chakra_only" ? "Chakra" : "Tianxia Cultivation"),
    natural: row.catalog === "chakra_only" ? ["Kun", "Kan", "Li"] : ["Qian", "Kun", "Xun"],
    testing: row.catalog === "chakra_only" ? ["Gen", "Zhen", "Dui"] : ["Gen", "Kan", "Zhen"],
    shadow: ["Qian Line 6", "Kan Line 6", "Gen Line 6"],
    verbs: row.catalog === "chakra_only" ? ["embodies", "routes", "balances", "strains", "integrates"] : ["cultivates", "shapes", "applies", "tests", "refines"],
    read: row.catalog === "chakra_only"
      ? `${row.name} is a Chakra-only Sphere whose exact embodied routes and permissions come from its authored source.`
      : `${row.name} is part of the current 85-Sphere Tianxia compendium.`
  });

  const nextSpheres = catalog.map((row) => {
    const old = existingSphereMeta.get(String(row.name).toLowerCase());
    return old ? { ...old, path: row.path || old.path, catalog: row.catalog, catalogStatus: row.status } : { ...genericMeta(row), catalog: row.catalog, catalogStatus: row.status };
  });
  SPHERES.splice(0, SPHERES.length, ...nextSpheres);
  if (Array.isArray(CANONICAL_SPHERE_NAMES)) CANONICAL_SPHERE_NAMES.splice(0, CANONICAL_SPHERE_NAMES.length, ...nextSpheres.map((row) => row.name));

  let talentSelections = {};
  let backgroundGrantSelection = null;
  let backgroundAutoSphere = "";
  const selectedSet = (sphere) => new Set(Array.isArray(talentSelections[sphere]) ? talentSelections[sphere] : []);
  const currentBackgroundGrant = () => backgroundGrantSelection;
  const selectedCount = () => {
    const keys = new Set();
    Object.entries(talentSelections).forEach(([sphere, rows]) => (rows || []).forEach((name) => keys.add(`${compactKey(sphere)}|${compactKey(name)}`)));
    const bg = currentBackgroundGrant();
    if (bg?.sphere && bg?.talent) keys.add(`${compactKey(bg.sphere)}|${compactKey(bg.talent)}`);
    return keys.size;
  };

  function sphereRecord(name) {
    return catalogByName.get(normalized(name)) || catalogByName.get(compactKey(name)) || null;
  }

  function talentRecord(sphere, name) {
    if (isDedicatedNonTalent(sphere, name)) return null;
    const row = sphereRecord(sphere);
    return selectableTalents(row).find((talent) => compactKey(talent.name) === compactKey(name)) || null;
  }

  function plainTalentText(value) {
    return String(value || "")
      .replace(/\*\*|__|`/g, "")
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, "$1")
      .replace(/^>\s*/gm, "")
      .replace(/[ \t]+/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function talentTooltipText(talent = {}) {
    return plainTalentText(talent.full_text || talent.summary || "Exact authored source text governs this talent.");
  }

  function compactTalentSummary(talent = {}) {
    let text = plainTalentText(talent.short_description || talent.summary || talent.full_text || "Exact authored source text governs this talent.")
      .replace(/…/g, "...")
      .replace(/\s+/g, " ")
      .trim();
    if (/^Action Type:/i.test(text) && talent.full_text) {
      const prose = plainTalentText(talent.full_text).split(/\n\s*\n/).find((part) => !/^(?:Action Type|Canonical Action Type|Factory Combat Bucket|Factory Routing|Timing Detail|Prerequisite|Range|Area|Target|Duration|Cost|Limit|Concentration):/i.test(part.trim()));
      if (prose) text = prose.replace(/\s+/g, " ").trim();
    }
    text = text.split(/(?<=[.!?])\s+/)[0].trim();
    if (text.length > 132) text = `${text.slice(0, 129).trimEnd()}...`;
    return text || "Exact authored source text governs this talent.";
  }

  function selectedTalentRows() {
    const rows = [];
    const seen = new Set();
    const add = (sphere, name, grantSource = "catalog") => {
      const key = `${compactKey(sphere)}|${compactKey(name)}`;
      if (!sphere || !name || seen.has(key) || isDedicatedNonTalent(sphere, name)) return;
      seen.add(key);
      const talent = talentRecord(sphere, name) || { name, realm: "Unclassified", summary: "Exact source record required." };
      rows.push({
        row_id: `catalog_talent_${rows.length + 1}`,
        name: talent.name,
        sphere_or_source: sphereRecord(sphere)?.name || sphere,
        effect_or_note: [talent.realm, talent.summary].filter(Boolean).join(" — "),
        realm: talent.realm || "Unclassified",
        tags: Array.isArray(talent.tags) ? [...talent.tags] : [],
        catalog: sphereRecord(sphere)?.catalog || "current_catalog",
        grant_source: grantSource,
        free_background_grant: grantSource === "background",
        raw: `${talent.name} | ${sphere} | ${[talent.realm, talent.summary].filter(Boolean).join(" — ")}`
      });
    };
    const bg = currentBackgroundGrant();
    if (bg?.sphere && bg?.talent) add(bg.sphere, bg.talent, "background");
    Object.keys(talentSelections).sort().forEach((sphere) => (talentSelections[sphere] || []).forEach((name) => add(sphere, name)));
    return rows;
  }

  function refillBuilderSphereSelect(query = "") {
    const select = document.getElementById("builderSphereSelect");
    if (!select) return;
    const current = select.value;
    const q = normalized(query);
    select.innerHTML = "";
    const canonicalGroup = document.createElement("optgroup");
    canonicalGroup.label = "Current Tianxia Compendium — 85 Spheres";
    const chakraGroup = document.createElement("optgroup");
    chakraGroup.label = "Chakra-only Spheres";
    catalog.filter((row) => !q || normalized(`${row.name} ${row.path} ${row.catalog}`).includes(q)).forEach((row) => {
      const option = new Option(`${row.name}${row.catalog === "chakra_only" ? " · Chakra-only" : ""}`, row.name);
      (row.catalog === "chakra_only" ? chakraGroup : canonicalGroup).appendChild(option);
    });
    if (canonicalGroup.children.length) select.appendChild(canonicalGroup);
    if (chakraGroup.children.length) select.appendChild(chakraGroup);
    if (current && [...select.options].some((option) => option.value === current)) select.value = current;
  }

  function toggleTalent(sphere, name, checked) {
    const values = selectedSet(sphere);
    if (checked) values.add(name); else values.delete(name);
    talentSelections[sphere] = [...values];
    if (!talentSelections[sphere].length) delete talentSelections[sphere];
    renderTalentBrowser();
    updateBuilderPreview();
  }

  function renderTalentBrowser() {
    const target = document.getElementById("builderTalentBrowser");
    const status = document.getElementById("builderTalentSelectionStatus");
    if (!target) return;
    const query = normalized(document.getElementById("builderTalentSearch")?.value);
    const realm = document.getElementById("builderTalentRealmFilter")?.value || "all";
    if (!builderSphereNames.length) {
      target.innerHTML = `<div class="empty-state">Select a Sphere to browse and highlight talents.</div>`;
      if (status) status.textContent = "No Spheres selected.";
      return;
    }
    const bg = currentBackgroundGrant();
    const sections = builderSphereNames.map((sphere) => {
      const sphereRow = sphereRecord(sphere);
      const availableTalents = selectableTalents(sphereRow);
      const talents = availableTalents.filter((talent) => {
        const realmPass = realm === "all" || String(talent.realm || "General") === realm;
        const searchPass = !query || normalized(`${talent.name} ${talent.heading} ${(talent.tags || []).join(" ")} ${talent.summary} ${talent.full_text || ""}`).includes(query);
        return realmPass && searchPass;
      });
      const chosen = selectedSet(sphere);
      const backgroundTalent = bg && compactKey(bg.sphere) === compactKey(sphere) ? talentRecord(sphere, bg.talent) : null;
      const notice = sphereRow?.notice || (sphereRow?.catalog === "chakra_only" && !sphereRow?.talents?.length ? "The exact authored source packet is required before talent selection." : "");
      const cards = talents.length ? talents.map((talent) => {
        const isBackground = Boolean(backgroundTalent && compactKey(backgroundTalent.name) === compactKey(talent.name));
        const on = chosen.has(talent.name) || isBackground;
        const fullSummary = talentTooltipText(talent);
        return `<label class="builder-talent-card${on ? " selected" : ""}${isBackground ? " background-granted" : ""}" title="${escapeHtml(fullSummary)}" data-builder-talent-tooltip="full-source">
          <input type="checkbox" data-r2g-talent-sphere="${escapeHtml(sphere)}" data-r2g-talent-name="${escapeHtml(talent.name)}" ${on ? "checked" : ""} ${isBackground ? "disabled aria-label='Free Background talent'" : ""}>
          <span><strong>${escapeHtml(talent.name)}</strong><span class="builder-talent-meta"><span class="builder-talent-badge">${escapeHtml(talent.realm || "General")}</span>${isBackground ? `<span class="builder-talent-badge background-badge">Free Background grant</span>` : ""}${(talent.tags || []).slice(0,3).map((tag) => `<span class="builder-talent-badge">${escapeHtml(tag)}</span>`).join("")}</span><span class="builder-talent-summary">${escapeHtml(compactTalentSummary(talent))}</span></span>
        </label>`;
      }).join("") : `<div class="empty-state">${escapeHtml(notice || "No talents match the current search or realm filter.")}</div>`;
      const count = new Set([...chosen].map(compactKey));
      if (backgroundTalent) count.add(compactKey(backgroundTalent.name));
      return `<details class="builder-talent-sphere" open><summary><span>${escapeHtml(sphereRow?.name || sphere)}</span><span class="builder-talent-count">${count.size} selected · ${availableTalents.length} talent entries</span></summary><div class="builder-talent-grid">${cards}</div></details>`;
    }).join("");
    target.innerHTML = sections;
    target.querySelectorAll("[data-r2g-talent-name]:not(:disabled)").forEach((box) => box.addEventListener("change", () => toggleTalent(box.dataset.r2gTalentSphere, box.dataset.r2gTalentName, box.checked)));
    if (status) {
      status.className = `builder-inline-status ${selectedCount() ? "pass" : "warn"}`;
      status.textContent = `${selectedCount()} selected talent${selectedCount() === 1 ? "" : "s"} across ${builderSphereNames.length} Sphere${builderSphereNames.length === 1 ? "" : "s"}; free Background grants are included automatically.`;
    }
  }


  renderBuilderSphereList = function renderBuilderSphereListR2H1() {
    const target = document.getElementById("builderSphereList");
    if (!target) return;
    const bg = currentBackgroundGrant();
    target.innerHTML = builderSphereNames.length
      ? builderSphereNames.map((sphere) => {
          const isBackground = bg && compactKey(bg.sphere) === compactKey(sphere);
          return `<button type="button" data-remove-builder-sphere="${escapeHtml(sphere)}" ${isBackground ? "disabled title='This Sphere is supplied by the selected Background grant.'" : ""}>${escapeHtml(sphereRecord(sphere)?.name || sphere)}${isBackground ? `<span>Free Background</span>` : ""}</button>`;
        }).join("")
      : `<div class="empty-state">No Spheres selected yet.</div>`;
    target.querySelectorAll("[data-remove-builder-sphere]:not(:disabled)").forEach((button) => button.addEventListener("click", () => {
      const sphere = button.dataset.removeBuilderSphere;
      builderSphereNames = builderSphereNames.filter((name) => compactKey(name) !== compactKey(sphere));
      Object.keys(talentSelections).forEach((key) => { if (compactKey(key) === compactKey(sphere)) delete talentSelections[key]; });
      updateBuilderPreview();
    }));
    renderTalentBrowser();
  };


  // Remove every legacy branch and expose both current libraries by default.
  foundationCatalogSetValue = function foundationCatalogSetValueR2G() {
    return document.getElementById("builderFoundationCatalogSet")?.value || "all";
  };
  foundationCatalogGroup = function foundationCatalogGroupR2G(item = {}) {
    if (item.catalog_set === "foundation_split_v0_3B") return "foundation_split_v0_3B";
    if (item.catalog_set === "chakra_foundations_v0_1" || String(item.primary_path || "").toLowerCase() === "chakra") return "chakra_foundations_v0_1";
    return "excluded";
  };
  fillFoundationCatalogSelect = function fillFoundationCatalogSelectR2G() {
    const select = document.getElementById("builderFoundationCatalogSelect");
    if (!select) return;
    const current = select.value;
    const view = foundationCatalogSetValue();
    select.innerHTML = `<option value="">Custom Foundation</option>`;
    const groups = [
      { key:"foundation_split_v0_3B", label:"Foundation Split v0.3B — FS01–FS30" },
      { key:"chakra_foundations_v0_1", label:"Chakra Foundations v0.1 — CH01–CH32" }
    ];
    groups.forEach((group) => {
      if (view !== "all" && view !== group.key) return;
      const rows = FOUNDATION_CATALOG.filter((item) => foundationCatalogGroup(item) === group.key)
        .sort((a,b) => String(a.catalog_code || "").localeCompare(String(b.catalog_code || ""), undefined, {numeric:true}));
      const optgroup = document.createElement("optgroup"); optgroup.label = group.label;
      rows.forEach((item) => {
        const option = new Option(`${item.catalog_code} · ${item.name}${item.foundation_grade ? ` — ${item.foundation_grade}` : ""}`, item.id || item.name);
        optgroup.appendChild(option);
      });
      if (optgroup.children.length) select.appendChild(optgroup);
    });
    if (current && [...select.options].some((option) => option.value === current)) select.value = current;
  };

  function foundationLayer(item = {}) {
    return item.known_player_text || item.player_known_layer || item.known || {};
  }
  function compactText(value, max = 260) {
    const text = foundationDisplayValue(value || "").replace(/\s+/g, " ").trim();
    return text.length > max ? `${text.slice(0, max - 3).trimEnd()}...` : text;
  }
  function runtimeRows(item, key) {
    const rows = item?.runtime_record?.[key] ?? item?.[key] ?? [];
    return Array.isArray(rows) ? rows : (rows ? [rows] : []);
  }
  function namedPressure(rows = []) {
    return rows.map((row) => typeof row === "string" ? foundationReadableToken(row) : foundationReadableToken(row.display_name || row.name || row.title || row.id || "Foundation pressure")).filter(Boolean);
  }
  function mechanicLine(row = {}) {
    const name = row.display_name || row.name || row.action_name || row.resource_name || row.title || row.id || "Foundation mechanic";
    const meta = [row.action_type, row.cost || row.resource_cost, row.range || row.range_or_reach].filter(Boolean).map(foundationDisplayValue).join(" · ");
    const effect = compactText(row.effect_summary || row.damage_or_effect || row.effect_text || row.effect || row.description || row.refresh || row.maximum_formula || "", 230);
    return `<li><strong>${escapeHtml(foundationDisplayValue(name))}</strong>${meta ? `<span>${escapeHtml(meta)}</span>` : ""}${effect ? `<p>${escapeHtml(effect)}</p>` : ""}</li>`;
  }
  foundationBuilderPreviewHtml = function foundationBuilderPreviewHtmlR2H1(item = {}, stage = "") {
    if (!item || !item.name) return `Custom foundation mode. Enter the foundation fields manually.`;
    const stageKey = foundationStageKey(stage || item.stage || item.default_stage || "");
    const player = foundationLayer(item);
    const summary = compactText(player.summary || player.common_knowledge || item.dao_principle || item.role || "No player-facing summary recorded.", 420);
    const sign = compactText(player.sign || player.visible_sign || player.known_sign || "", 300);
    const benefit = compactText(foundationStageBenefitText(item, stageKey) || player.benefit || player.known_benefit || "", 520);
    const warning = compactText(player.warning || player.known_warning || "", 320);
    const resources = runtimeRows(item, "resources");
    const actions = runtimeRows(item, "actions");
    const passives = runtimeRows(item, "passives");
    const repairs = runtimeRows(item, "repair_practices");
    const challenges = runtimeRows(item, "challenge_actions");
    const lineage = runtimeRows(item, "lineage_actions");
    const burdens = namedPressure(runtimeRows(item, "burdens"));
    const injuries = namedPressure(runtimeRows(item, "hidden_injuries"));
    const strains = namedPressure(runtimeRows(item, "strains"));
    const deviations = namedPressure(runtimeRows(item, "deviations"));
    const compatible = item.sphere_interfaces?.compatible_spheres || [];
    const conditional = item.sphere_interfaces?.conditional_spheres_unlocked || [];
    const boundaries = item.foundation_display_row?.does_not_grant_boundaries || item.fixed_scope?.does_not_grant || item.fixed_scope?.boundaries || "";
    const statusPill = item.catalog_set === "chakra_foundations_v0_1"
      ? `<span class="foundation-pill tone-warning">Chakra theoretical draft</span>`
      : `<span class="foundation-pill tone-ready">Audited v0.3B</span>`;
    const operationRows = [...passives, ...resources, ...actions];
    return `<div class="foundation-builder-readable">
      <div class="foundation-preview-head"><div><strong>${escapeHtml(item.catalog_code ? `${item.catalog_code} · ${item.name}` : item.name)}</strong><p>${escapeHtml(item.dao_principle || item.role || "No Dao principle recorded.")}</p></div><div class="foundation-preview-pills"><span class="foundation-pill">${escapeHtml(item.foundation_grade || titleCase(String(item.depth || "minor").replace(/_/g, " ")))}</span>${statusPill}<span class="foundation-pill tone-ready">${escapeHtml(foundationStageLabel(stageKey))}</span></div></div>
      <section class="foundation-readable-section player-layer"><h4>Player-facing understanding</h4><p>${escapeHtml(summary)}</p>${sign ? `<p><strong>Visible sign:</strong> ${escapeHtml(sign)}</p>` : ""}${warning ? `<p><strong>Known warning:</strong> ${escapeHtml(warning)}</p>` : ""}</section>
      <section class="foundation-readable-section stage-layer"><h4>What it does at ${escapeHtml(foundationStageLabel(stageKey))}</h4>${benefit ? `<p>${escapeHtml(benefit)}</p>` : `<p class="muted-copy">The exact stage benefit is not recorded in this catalog entry.</p>`}${operationRows.length ? `<ul class="foundation-mechanic-list">${operationRows.slice(0,6).map(mechanicLine).join("")}</ul>${operationRows.length>6 ? `<p class="muted-copy">${operationRows.length-6} additional runtime entries remain in the exported Foundation record.</p>` : ""}` : ""}</section>
      <details class="foundation-readable-details"><summary>GM-facing risks, lifecycle, and counterplay</summary><div class="foundation-risk-grid">${burdens.length ? `<span><strong>Burdens</strong>${escapeHtml(burdens.join(", "))}</span>` : ""}${injuries.length ? `<span><strong>Hidden injuries</strong>${escapeHtml(injuries.join(", "))}</span>` : ""}${strains.length ? `<span><strong>Strains</strong>${escapeHtml(strains.join(", "))}</span>` : ""}${deviations.length ? `<span><strong>Deviations</strong>${escapeHtml(deviations.join(", "))}</span>` : ""}</div>${repairs.length ? `<h5>Repair / integration</h5><ul class="foundation-mechanic-list compact">${repairs.slice(0,5).map(mechanicLine).join("")}</ul>` : ""}${challenges.length ? `<h5>Foundation challenge routes</h5><ul class="foundation-mechanic-list compact">${challenges.slice(0,4).map(mechanicLine).join("")}</ul>` : ""}${lineage.length ? `<h5>Lineage-bearing routes</h5><ul class="foundation-mechanic-list compact">${lineage.slice(0,4).map(mechanicLine).join("")}</ul>` : ""}</details>
      <details class="foundation-readable-details"><summary>Compatibility and boundaries</summary>${compatible.length ? `<p><strong>Compatible Spheres:</strong> ${escapeHtml(compatible.map(foundationRuleText).join(", "))}</p>` : ""}${conditional.length ? `<p><strong>Conditional Spheres:</strong> ${escapeHtml(conditional.map(foundationRuleText).join(", "))}</p>` : ""}${boundaries ? `<p><strong>Does not grant / boundary:</strong> ${escapeHtml(foundationDisplayValue(boundaries))}</p>` : ""}${item.fixed_scope && typeof item.fixed_scope === "string" ? `<p><strong>Legal scope:</strong> ${escapeHtml(compactText(item.fixed_scope,700))}</p>` : ""}</details>
      ${item.seated_wheel ? `<p class="muted-copy"><strong>Seated Wheel:</strong> ${escapeHtml(item.seated_wheel)}</p>` : ""}${item.builder_notice ? `<p class="foundation-source-note"><strong>Source note:</strong> ${escapeHtml(item.builder_notice)}</p>` : ""}
    </div>`;
  };


  const priorSnapshot = hf05zuiR2eBuilderSnapshot;
  hf05zuiR2eBuilderSnapshot = function hf05zuiR2gBuilderSnapshot() {
    const snapshot = priorSnapshot();
    const manual = Array.isArray(snapshot.talents) ? snapshot.talents : [];
    const selected = selectedTalentRows();
    const seen = new Set();
    snapshot.talents = [...selected, ...manual].filter((row) => {
      const key = normalized(`${row.name}|${row.sphere_or_source}`);
      if (!key || seen.has(key)) return false;
      seen.add(key); return true;
    });
    snapshot.schema = "HF05ZUI-R2H.BuilderSnapshot.v1";
    snapshot.builder_patch = "HF05ZUI-R2H.1-BUILDER-USABILITY";
    snapshot.target_consumer = "HF05ZUI-R2H";
    snapshot.sphere_catalog = { canonical_spheres:85, chakra_only_spheres:5, selected_catalog_talents:selected.length, background_grant: currentBackgroundGrant() };
    return snapshot;
  };

  const priorDraftSnapshot = hf05zuiR2eDraftSnapshot;
  hf05zuiR2eDraftSnapshot = function hf05zuiR2gDraftSnapshot() {
    const draft = priorDraftSnapshot();
    draft.talentSelections = JSON.parse(JSON.stringify(talentSelections));
    draft.backgroundGrantSelection = backgroundGrantSelection ? { ...backgroundGrantSelection } : null;
    return draft;
  };

  function restoreTalentSelections() {
    try {
      const saved = JSON.parse(localStorage.getItem("hf05zui_r2e_builder_draft") || "{}");
      talentSelections = saved.talentSelections && typeof saved.talentSelections === "object" ? saved.talentSelections : {};
      backgroundGrantSelection = saved.backgroundGrantSelection && typeof saved.backgroundGrantSelection === "object" ? saved.backgroundGrantSelection : null;
      if (backgroundGrantSelection?.sphere) {
        const hasManualTalent = Object.keys(talentSelections).some((key) => compactKey(key) === compactKey(backgroundGrantSelection.sphere) && (talentSelections[key] || []).length);
        if (!hasManualTalent) backgroundAutoSphere = sphereRecord(backgroundGrantSelection.sphere)?.name || backgroundGrantSelection.sphere;
      }
      renderBackgroundGrantOptions({ preserve: true });
      renderBuilderSphereList(); updateBuilderPreview();
    } catch { talentSelections = {}; backgroundGrantSelection = null; }
  }

  function backgroundRecord() {
    const name = document.getElementById("builderBackground")?.value || "";
    return TIANXIA_BACKGROUNDS[name] || null;
  }
  function backgroundStatusLabel(status = "active") {
    return status === "dormant" ? "Dormant until legally activated" : status === "preparatory" ? "Preparatory knowledge / practice" : "Active free Background grant";
  }
  function clearBackgroundAutoSphere() {
    if (!backgroundAutoSphere) return;
    const hasManualTalent = Object.keys(talentSelections).some((key) => compactKey(key) === compactKey(backgroundAutoSphere) && (talentSelections[key] || []).length);
    if (!hasManualTalent) builderSphereNames = builderSphereNames.filter((sphere) => compactKey(sphere) !== compactKey(backgroundAutoSphere));
    backgroundAutoSphere = "";
  }
  function applyBackgroundGrant(grant, choiceId) {
    clearBackgroundAutoSphere();
    backgroundGrantSelection = grant ? { ...grant, choice_id: choiceId || grant.id || "" } : null;
    if (backgroundGrantSelection?.sphere) {
      const row = sphereRecord(backgroundGrantSelection.sphere);
      const canonical = row?.name || backgroundGrantSelection.sphere;
      if (!builderSphereNames.some((name) => compactKey(name) === compactKey(canonical))) {
        builderSphereNames.push(canonical);
        backgroundAutoSphere = canonical;
      }
    }
    renderBackgroundGrantOptions({ preserve: true });
    renderBuilderSphereList();
    updateBuilderPreview();
  }
  function renderBackgroundGrantOptions({ preserve = false } = {}) {
    const target = document.getElementById("builderBackgroundGrantOptions");
    const status = document.getElementById("builderBackgroundGrantStatus");
    if (!target) return;
    const background = backgroundRecord();
    const options = background?.grant_options || [];
    if (!background) {
      target.innerHTML = `<div class="empty-state">Choose a background to see its legal free grants.</div>`;
      if (status) status.textContent = "Choose a background first.";
      return;
    }
    if (!preserve || !backgroundGrantSelection || !options.some((row) => compactKey(row.sphere) === compactKey(backgroundGrantSelection.sphere) && compactKey(row.talent) === compactKey(backgroundGrantSelection.talent))) {
      clearBackgroundAutoSphere();
      backgroundGrantSelection = null;
    }
    target.innerHTML = options.map((grant, index) => {
      const row = sphereRecord(grant.sphere);
      const talent = talentRecord(grant.sphere, grant.talent);
      const checked = backgroundGrantSelection && compactKey(backgroundGrantSelection.sphere) === compactKey(grant.sphere) && compactKey(backgroundGrantSelection.talent) === compactKey(grant.talent);
      const summary = talent ? compactTalentSummary(talent) : "Published Background option; exact talent record is retained even if the catalog entry is unavailable.";
      return `<label class="background-grant-card${checked ? " selected" : ""}"><input type="radio" name="builderBackgroundGrant" value="${escapeHtml(`${background.name}:${index+1}`)}" data-background-sphere="${escapeHtml(row?.name || grant.sphere)}" data-background-talent="${escapeHtml(talent?.name || grant.talent)}" data-background-status="${escapeHtml(grant.status || "active")}" ${checked ? "checked" : ""}><span><strong>${escapeHtml(row?.name || grant.sphere)} <em>+</em> ${escapeHtml(talent?.name || grant.talent)}</strong><small>${escapeHtml(backgroundStatusLabel(grant.status))}</small><span>${escapeHtml(summary)}</span></span></label>`;
    }).join("");
    target.querySelectorAll('input[name="builderBackgroundGrant"]').forEach((radio, index) => radio.addEventListener("change", () => {
      if (radio.checked) applyBackgroundGrant(options[index], radio.value);
    }));
    if (status) status.textContent = backgroundGrantSelection ? `${backgroundGrantSelection.sphere} + ${backgroundGrantSelection.talent} applied below.` : `${options.length} legal option${options.length===1?"":"s"}; choose one.`;
  }

  document.getElementById("builderSphereSearch")?.addEventListener("input", (event) => refillBuilderSphereSelect(event.target.value));
  document.getElementById("builderTalentSearch")?.addEventListener("input", renderTalentBrowser);
  document.getElementById("builderTalentRealmFilter")?.addEventListener("change", renderTalentBrowser);
  document.getElementById("builderBackground")?.addEventListener("change", () => { clearBackgroundAutoSphere(); backgroundGrantSelection = null; renderBackgroundGrantOptions(); renderBuilderSphereList(); updateBuilderPreview(); });
  document.getElementById("builderLoadDraftButton")?.addEventListener("click", () => setTimeout(restoreTalentSelections, 0));
  document.getElementById("builderResetButton")?.addEventListener("click", () => setTimeout(() => { talentSelections = {}; backgroundGrantSelection = null; backgroundAutoSphere = ""; renderBackgroundGrantOptions(); renderBuilderSphereList(); }, 0));
  document.getElementById("builderAddSphereButton")?.addEventListener("click", () => setTimeout(renderTalentBrowser, 0));

  // Refresh every Sphere-backed selector after replacing the stale catalog.
  populateControls();
  const foundationView = document.getElementById("builderFoundationCatalogSet");
  if (foundationView) foundationView.value = "all";
  fillFoundationCatalogSelect();
  refillBuilderSphereSelect();
  renderBackgroundGrantOptions();
  renderBuilderSphereList();
  updateBuilderPreview();
})();
