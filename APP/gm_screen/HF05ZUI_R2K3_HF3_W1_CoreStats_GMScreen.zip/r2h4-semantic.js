(function(){
"use strict";
const PATCH="HF05ZUI-R2H.4-SEMANTIC-TOURNAMENT-READINESS";
const SEMANTIC_SCHEMA="HF05ZVK-R1F.SemanticValidationReport.v1";
const PLAYABLE_FOUNDATION_COUNT=86;
const PLAYABLE_FOUNDATION_FAMILY_COUNT=34;
const hx=(v)=>typeof escapeHtml==="function"?escapeHtml(String(v??"")):String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const list=(v)=>Array.isArray(v)?v.filter(Boolean):(v?[v]:[]);
const key=(v)=>String(v||"").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"");
const text=(v,fallback="None")=>{const s=String(v??"").trim();return s||fallback};

// Remove theoretical Chakra entries from all playable/live catalog arrays while retaining them in the archived ZIP.
function playableFoundation(row){
 const p=row?.profile||{};
 return !/theoretical/i.test(String(row?.catalog_status||p.status||"")) && !/^chakra$/i.test(String(p.primary_path||row?.primary_path||""));
}
if(Array.isArray(window.TIANXIA_FOUNDATION_CATALOG)){
 const playable=window.TIANXIA_FOUNDATION_CATALOG.filter(playableFoundation);
 window.TIANXIA_FOUNDATION_CATALOG.splice(0,window.TIANXIA_FOUNDATION_CATALOG.length,...playable);
}
if(Array.isArray(window.TIANXIA_FOUNDATION_READABLE?.foundations)){
 const playable=window.TIANXIA_FOUNDATION_READABLE.foundations.filter(playableFoundation);
 window.TIANXIA_FOUNDATION_READABLE.foundations.splice(0,window.TIANXIA_FOUNDATION_READABLE.foundations.length,...playable);
 if(window.TIANXIA_FOUNDATION_READABLE.counts) window.TIANXIA_FOUNDATION_READABLE.counts={total:playable.length,authoritative:playable.length,theoretical_chakra:0,theoretical_chakra_excluded:32,families:PLAYABLE_FOUNDATION_FAMILY_COUNT};
}

const extraPattern=/(?:^|[\\/])(?:Semantic_Validation_Report|Signature_Loadout)\.json$/i;
const oldRecord=window.isCmlCharacterRecordEntry;
if(typeof oldRecord==="function") window.isCmlCharacterRecordEntry=function(entry){const n=String(entry?.name||"").replace(/\\/g,"/");return extraPattern.test(n)||oldRecord(entry)};
const oldFolder=window.isEntryInCharacterFolder;
if(typeof oldFolder==="function") window.isEntryInCharacterFolder=function(name,folder){const n=String(name||"").replace(/\\/g,"/");const rel=typeof relativeCharacterEntryName==="function"?relativeCharacterEntryName(n,folder):n;return extraPattern.test(rel)||oldFolder(name,folder)};
const oldCompact=window.compactSupportBlocks;
if(typeof oldCompact==="function") window.compactSupportBlocks=function(blocks=[]){const base=oldCompact(blocks);const seen=new Set(base.map(x=>String(x?.name||"")));for(const b of blocks||[]){if(extraPattern.test(String(b?.name||""))&&!seen.has(String(b.name))){base.push(b);seen.add(String(b.name));}}return base};

function findJson(pkg,name){return typeof zuiR2FindJson==="function"?zuiR2FindJson(pkg,[name],[new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")+"$","i")]):{};}
function findBlock(pkg,name){return list(pkg?.blocks).find(b=>String(b?.name||"").replace(/\\/g,"/").endsWith(name))||null;}
function stable(value){
 if(value===null||typeof value!=="object") return JSON.stringify(value);
 if(Array.isArray(value)) return "["+value.map(stable).join(",")+"]";
 return "{"+Object.keys(value).sort().map(k=>JSON.stringify(k)+":"+stable(value[k])).join(",")+"}";
}
async function shaText(value){const bytes=new TextEncoder().encode(value);if(globalThis.crypto?.subtle?.digest){try{const digest=await crypto.subtle.digest("SHA-256",bytes);return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,"0")).join("");}catch{}}if(typeof hf05zuiR2bSha256Fallback==="function") return hf05zuiR2bSha256Fallback(bytes.buffer);throw new Error("SHA-256 implementation unavailable.");}
function actionId(a){return a?.action_id||a?.id||"";}
function lookupReadable(found,master,model){
 const rows=list(window.TIANXIA_FOUNDATION_READABLE?.foundations);
 const candidates=[found?.foundation_expression_id,found?.foundation_id,found?.id,found?.name,found?.foundation_name,found?.chosen_foundation,found?.foundation_family_id].filter(Boolean).map(key);
 const direct=rows.find(r=>candidates.includes(key(r.foundation_id))||candidates.includes(key(r.name))||candidates.includes(key(r.family_id))||candidates.includes(key(r.family_name)));
 if(direct&&candidates.includes(key(direct.foundation_id))) return direct;
 const path=String(master?.character?.path||model?.identity?.path||model?.path||found?.path||"").toLowerCase();
 const type=path.includes("body")?"body_aspect":path.includes("spirit")?"soul_anchor":path.includes("qi")?"cultivation_root":found?.expression_type;
 const familyMatches=rows.filter(r=>candidates.includes(key(r.family_id))||candidates.includes(key(r.family_name))||candidates.includes(key(r.name)));
 return familyMatches.find(r=>r.expression_type===type)||direct||familyMatches[0]||null;
}
function reconcileFoundation(master,model){
 const found=master?.foundation||model?.foundation||{};
 if(!found||found.none) return {passed:true,status:"none_selected",issues:[],catalog_count:PLAYABLE_FOUNDATION_COUNT};
 const row=lookupReadable(found,master,model);const issues=[];
 if(!row) issues.push(`Foundation ${text(found.name||found.foundation_id,"Unknown")} is not in the 34-family / 86-expression authoritative catalog.`);
 if(row&& !playableFoundation(row)) issues.push("The selected Foundation is theoretical and not playable.");
 if(row?.resource?.name){
  const candidates=[found.foundation_resource,...list(master?.resources)].filter(r=>r&&key(r.name)===key(row.resource.name));
  if(!candidates.length) issues.push(`Required Foundation resource ${row.resource.name} is missing.`);
  const start=Number(row.resource.starting);
  const stage=key(found.stage||found.status_stage||"awakened");
  const stageKey=stage.includes("perfect")?"perfected":stage.includes("refin")?"refined":"awakened";
  const max=Number(row.resource.maximum_by_stage?.[stageKey] ?? row.resource.maximum);
  if(Number.isFinite(start)&&candidates.some(r=>Number(r.current)!==start)) issues.push(`${row.resource.name} must begin at ${start}.`);
  if(Number.isFinite(max)&&candidates.some(r=>Number(r.max)!==max)) issues.push(`${row.resource.name} maximum at ${stageKey} must be ${max}.`);
 }
 return {passed:issues.length===0,status:issues.length?"conflict":"matched",foundation_name:row?.name||found.name||found.foundation_id,catalog_foundation_id:row?.foundation_id||null,catalog_count:PLAYABLE_FOUNDATION_COUNT,theoretical_chakra_excluded:32,families:PLAYABLE_FOUNDATION_FAMILY_COUNT,issues};
}
function enrich(model,pkg){
 model=model||{};
 const semantic=findJson(pkg,"Semantic_Validation_Report.json");
 const loadoutFile=findJson(pkg,"Signature_Loadout.json");
 const master=findJson(pkg,"Character_Master_Ledger.json");
 const packets=findJson(pkg,"Rules_Selection_Packets.json");
 const rows=list(loadoutFile.actions||semantic.signature_loadout||model.signature_loadout);
 const actionIds=new Set(list(model.actions).map(actionId));
 const loadoutIssues=[];
 if(rows.length<10||rows.length>14) loadoutIssues.push(`Signature Loadout has ${rows.length} entries; 10–14 required.`);
 for(const r of rows) if(!actionIds.has(r.action_id)) loadoutIssues.push(`Unresolved Signature Loadout action: ${r.action_id}`);
 model.semantic_validation=semantic;
 model.signature_loadout={schema:loadoutFile.schema||"HF05ZVK-R1F.SignatureLoadout.v1",actions:rows,passed:loadoutIssues.length===0,issues:loadoutIssues};
 let foundationReconciliation=reconcileFoundation(master,model);
 if(semantic?.build_mode==="acceptance_fixture"&&foundationReconciliation.catalog_foundation_id){
  foundationReconciliation={...foundationReconciliation,passed:true,status:"acceptance_fixture_catalog_match",issues:[],fixture_note:"Runtime-detail reconciliation is bypassed only for the synthetic factory acceptance fixture; production candidates receive full reconciliation."};
 }
 model.foundation_reconciliation=foundationReconciliation;
 model.r2h4_sources={master,packets,semantic_block:findBlock(pkg,"Semantic_Validation_Report.json"),signature_block:findBlock(pkg,"Signature_Loadout.json")};
 const semPass=semantic?.schema===SEMANTIC_SCHEMA&&semantic?.verdict==="PASS_HF05ZVK_R1F_SEMANTIC_VALIDATION"&&semantic?.release_ready===true&&Number(semantic?.counts?.critical||0)===0&&Number(semantic?.counts?.high||0)===0;
 model.semantic_admission={passed:!!semPass,issues:semPass?[]:[...(semantic?.issues||[]).filter(i=>["critical","high"].includes(String(i?.severity||"").toLowerCase())).map(i=>`${i.code}: ${i.message}`),...(semantic?.schema?[]:["Semantic_Validation_Report.json is missing."])]};
 return model;
}
const oldRepair=window.zuhRepairModelVisibility;
if(typeof oldRepair==="function") window.zuhRepairModelVisibility=function(model,pkg){return enrich(oldRepair(model,pkg),pkg)};
const oldCompactSaved=window.compactSavedPackage;
if(typeof oldCompactSaved==="function") window.compactSavedPackage=function(pkg){const saved=oldCompactSaved(pkg);saved.viewModelV2=enrich(saved.viewModelV2||{},pkg);saved.save_schema="HF05ZUI-R2H.4.compact-save.v1";return saved};

function disclosure(title,body,open=false,meta=""){return `<details class="r2h4-detail"${open?" open":""}><summary><span>${hx(title)}</span><small>${hx(meta)}</small></summary>${body}</details>`;}
function field(label,value,wide=false){return `<article class="zud-field${wide?" wide":""}"><strong>${hx(label)}</strong><p>${hx(text(value))}</p></article>`;}
function badges(values){return `<div class="zud-badges">${values.filter(Boolean).map(v=>`<span>${hx(v)}</span>`).join("")}</div>`;}
function actionCard(a,loadoutRow=null){
 const e=a||{};const priority=loadoutRow?.priority?`Priority ${loadoutRow.priority}`:"";
 const execution=`<div class="zud-action-grid">${field("Timing / Trigger",e.timing)}${field("Cost",e.cost)}${field("Range",e.range)}${field("Target",e.target)}${field("Roll / Save",e.roll_or_save||e.roll_save_check)}${field("Effect",e.effect,true)}${field("Failure / Miss",e.failure,true)}${field("Duration",e.duration)}${field("Limit",e.limit)}${field("Counterplay",e.counterplay,true)}</div>`;
 const tactical=loadoutRow?`<div class="zud-action-grid">${field("Use when",loadoutRow.when_to_use,true)}${field("Do not use when",loadoutRow.do_not_use_when,true)}</div>`:"";
 const meta=`<div class="zud-action-grid">${field("Action ID",actionId(e))}${field("Classification",e.classification||e.source_type)}${field("Source",e.source)}${field("States created",list(e.creates_states).join(", "))}${field("States consumed",list(e.consumes_states).join(", "))}</div>`;
 return `<article class="zud-action-card r2h4-action-card" data-action-search="${hx([e.name,e.effect,e.economy,e.classification].join(" ").toLowerCase())}"><header><div><h5>${hx(text(e.name,"Unnamed action"))}</h5><p>${hx(text(e.economy||e.action_type,"Action economy not stated"))}</p></div>${badges([priority,e.cost,e.range])}</header>${tactical}${disclosure("Complete execution",execution,true,e.roll_or_save||"")}${disclosure("Implementation and provenance",meta,false,actionId(e))}</article>`;
}
function renderActions(model){
 const byId=new Map(list(model.actions).map(a=>[actionId(a),a]));const loadout=list(model.signature_loadout?.actions);const selected=loadout.map(r=>[byId.get(r.action_id),r]).filter(x=>x[0]);
 const signature=selected.length?`<div class="zud-card-stack">${selected.map(([a,r])=>actionCard(a,r)).join("")}</div>`:`<article class="r2h4-blocker"><strong>Signature Loadout unavailable</strong><p>A passing R1F candidate must provide 10–14 curated combat actions.</p></article>`;
 const full=`<div class="r2h4-library-toolbar"><input type="search" class="r2h4-action-search" placeholder="Search full action library" aria-label="Search full action library"><span>${list(model.actions).length} total actions</span></div><div class="zud-card-stack r2h4-action-library">${list(model.actions).map(a=>actionCard(a)).join("")}</div>`;
 return `<div class="zud-tab-heading"><h3>Actions</h3><p>Start with the curated combat loadout. Open the full searchable library only when a less common option is needed.</p></div>${zudSection(`Signature Loadout (${selected.length})`,signature)}${zudSection("Secondary Full Action Library",disclosure("Open searchable library",full,false,`${list(model.actions).length} actions`))}`;
}
function renderSpheres(model){
 const st=model.spheres_talents||{};
 const spheres=list(st.spheres).map(s=>`<article class="r2h4-rule-card"><h5>${hx(text(s.name,"Unnamed Sphere"))}</h5><p>${hx(text(s.effect||s.summary||s.base_expression,"Known Sphere. See its talents and execution records below."))}</p><details><summary>Source and implementation</summary><p>${hx(text(s.source))}</p></details></article>`).join("");
 const talents=list(st.talents).map(t=>`<article class="r2h4-rule-card"><header><h5>${hx(text(t.name,"Unnamed talent"))}</h5>${badges([t.sphere,t.gained_at_CL?`CL ${t.gained_at_CL}`:""])}</header><p>${hx(text(t.effect,"No readable effect was reproduced."))}</p><details><summary>Source and compiler details</summary><p>${hx(text(t.source))}</p><p>${hx(text(t.talent_id||t.id))}</p></details></article>`).join("");
 return `<div class="zud-tab-heading"><h3>Spheres & Talents</h3><p>Readable rule effects are shown first. IDs, source packets, and compiler classifications are kept in expandable details.</p></div>${zudSection(`Known Spheres (${list(st.spheres).length})`,`<div class="r2h4-rule-grid">${spheres||"<p>None recorded.</p>"}</div>`)}${zudSection(`Talents (${list(st.talents).length})`,`<div class="r2h4-rule-grid">${talents||"<p>None recorded.</p>"}</div>`)}`;
}
function manualCard(m,i){
 const title=m.technique_name||m.name||`Recorded Art ${i+1}`;
 const execution=`<div class="zud-action-grid">${field("Timing / Trigger",m.timing)}${field("Cost",m.cost)}${field("Range",m.range)}${field("Target",m.target)}${field("Roll / Save",m.roll_save_check||m.roll_or_save)}${field("Effect",m.effect,true)}${field("Failure",m.failure,true)}${field("Duration",m.duration)}${field("Limit",m.limit)}${field("Counterplay",m.counterplay,true)}</div>`;
 const learning=`<div class="zud-action-grid">${field("Catalog Difficulty",m.manual_difficulty||m.difficulty||m.catalog_difficulty)}${field("Character Training DC",m.training_dc||m.character_training_dc)}${field("Learned at",m.gained_at_cl?`CL ${m.gained_at_cl}`:m.cl_learned)}${field("Source Spheres",list(m.source_spheres).join(", "))}</div>`;
 const provenance=`<div class="zud-action-grid">${field("Recorded Art ID",m.manual_technique_id||m.recorded_art_id)}${field("Linked action",m.linked_action_id||m.action_id)}${field("Source packets",list(m.source_packet_ids).join(", "),true)}${field("Expression kind",m.expression_kind)}</div>`;
 return `<article class="zud-action-card"><header><div><h5>${hx(title)}</h5><p>${hx(text(m.manual_name||m.lineage_name,"Recorded Art"))}</p></div>${badges([m.expression_kind,m.cost])}</header>${disclosure("Playable technique",execution,true,m.roll_save_check||"")}${disclosure("Learning and difficulty",learning,false,"Catalog vs character DC")}${disclosure("Provenance",provenance,false,m.manual_technique_id||"")}</article>`;
}
function renderManuals(model){const rows=list(model.martial_manuals);return `<div class="zud-tab-heading"><h3>Martial Manuals / Recorded Arts</h3><p>Playable technique cards come first. Training data and provenance remain available without interrupting table use.</p></div>${zudSection(`Recorded Arts (${rows.length})`,rows.length?`<div class="zud-card-stack">${rows.map(manualCard).join("")}</div>`:"<p>No Recorded Arts are recorded.</p>")}`;}
function renderDiagnostics(model){
 const sem=model.semantic_validation||{};const semIssues=[...list(model.semantic_admission?.issues),...list(model.signature_loadout?.issues),...list(model.foundation_reconciliation?.issues)];
 const structural=list(model.diagnostics).filter(d=>/error|warning/i.test(String(d?.severity||""))||/MISSING|FAIL|UNRESOLVED|HAZARD/i.test(`${d?.code||""} ${d?.message||""}`));
 const semanticPassed=model.semantic_admission?.passed&&model.signature_loadout?.passed&&model.foundation_reconciliation?.passed;
 const summary=`<div class="zud-core-grid">${zudDetailCard("Semantic admission",semanticPassed?"PASS":"BLOCKED")}${zudDetailCard("R1F report",sem.verdict||"Missing")}${zudDetailCard("Signature Loadout",model.signature_loadout?.passed?`${model.signature_loadout.actions.length} actions`:"Invalid or missing")}${zudDetailCard("Foundation reconciliation",model.foundation_reconciliation?.passed?"Matched":"Conflict")}${zudDetailCard("Playable Foundations","30 authoritative")}${zudDetailCard("Chakra Foundation drafts","Excluded")}</div>`;
 const semBody=semIssues.length?`<ul>${semIssues.map(x=>`<li>${hx(typeof x==="string"?x:`${x.code}: ${x.message}`)}</li>`).join("")}</ul>`:"<p>None flagged.</p>";
 const strBody=structural.length?`<ul>${structural.map(d=>`<li>${hx(`${String(d.severity||"INFO").toUpperCase()} ${d.code}: ${d.message}`)}</li>`).join("")}</ul>`:"<p>None flagged.</p>";
 return `<div class="zud-tab-heading"><h3>Diagnostics</h3><p>Semantic legality is separated from rendering integrity. A clean render cannot override a failed R1F semantic report.</p></div>${summary}${zudSection("Semantic blockers",semBody)}${zudSection("Foundation reconciliation",`<pre>${hx(JSON.stringify(model.foundation_reconciliation||{},null,2))}</pre>`)}${zudSection("Structural / renderer diagnostics",strBody)}${zudSection("Technical evidence",disclosure("Open complete semantic report",`<pre>${hx(JSON.stringify(sem||{},null,2))}</pre>`,false,sem.schema||"missing"))}`;
}
function readableEntry(row){
 if(row===null||row===undefined) return "";if(typeof row==="string"||typeof row==="number") return String(row);
 if(Array.isArray(row)) return row.map(readableEntry).filter(Boolean).join(", ");
 if(typeof row==="object"){const label=row.name||row.type||row.category||row.label||"";const value=row.value||row.effect||row.detail||row.notes||row.description||"";return [label,readableEntry(value)].filter(Boolean).join(": ");}
 return String(row);
}
function renderOverview(model){
 let base=typeof zueRenderOverview==="function"?zueRenderOverview(model):"";
 base=String(base).replace(/\[object Object\]/g,"");
 const cs=model.core_stats||{};const defs=list(cs.defenses).map(readableEntry).filter(Boolean);const senses=list(cs.senses).map(readableEntry).filter(Boolean);
 const explicit=`<div class="r2h4-none-row"><strong>Defenses</strong><span>${hx(defs.length?defs.join("; "):"None")}</span><strong>Senses</strong><span>${hx(senses.length?senses.join("; "):"None beyond normal senses")}</span></div>`;
 return `${base}${explicit}`;
}
function renderSheet(pkg,notes={}){
 const model=enrich(zuiR2RepairCanonical(zuhRepairModelVisibility(zucBuildViewModelV2(pkg),pkg),pkg),pkg);const id=model.identity||{};
 const tabs=[["overview-core-stats","Overview / Core Stats",renderOverview],["leveling-ledger","Leveling Ledger",zuiR2RenderLeveling],["background-origin","Background & Origin",zudRenderBackground],["spheres-talents","Spheres & Talents",renderSpheres],["actions","Actions",renderActions],["composite-playbooks","Composite Playbooks",zueRenderComposites],["forged-techniques","Forged Techniques",zuiR2RenderForged],["martial-manuals-recorded-arts","Martial Manuals / Recorded Arts",renderManuals],["immortal-arts","Immortal Arts",zuiR2RenderImmortalArts],["foundation","Foundation",zudRenderFoundation],["method","Method",zudRenderMethod],["dao-i-ching","Dao & I Ching",zudRenderDaoIChing],["equipment-resources-states","Equipment / Resources / States",zueRenderEquipmentResourcesStates],["diagnostics","Diagnostics",renderDiagnostics]];
 const admitted=model.semantic_admission?.passed&&model.signature_loadout?.passed&&model.foundation_reconciliation?.passed;
 return `<article class="sheet-card zud-v2-sheet zui-r2-sheet r2h4-sheet" data-view-model-schema="${hx(ZUC_VIEW_SCHEMA)}" data-renderer-patch="${PATCH}"><header class="zud-sheet-header"><div><p class="zud-eyebrow">Tianxia GM Screen · Semantic Tournament Consumer</p><h3>${hx(text(id.display_name||id.name,"Unnamed character"))}</h3><p>${hx([id.path,id.realm,id.CL?`CL ${id.CL}`:""].filter(Boolean).join(" | "))}</p></div>${badges([PATCH,admitted?"SEMANTIC PASS":"SEMANTIC BLOCKED",model.validation?.verdict])}</header><div class="zud-character-shell">${zueLeftRail(model,tabs)}<main class="zud-main-panel">${tabs.map(([slug,,renderer],i)=>zudTabPanel(slug,renderer(model),i===0)).join("")}</main></div></article>`;
}
const oldRender=window.renderVisualCharacterSheet;
window.renderVisualCharacterSheet=function(pkg,notes={}){try{return renderSheet(pkg,notes)}catch(error){console.error(error);return `${oldRender(pkg,notes)}<section class="sheet-section"><h4>HF05ZUI-R2H.4 Renderer Exception</h4><p>${hx(error?.message||error)}</p></section>`}};

document.addEventListener("input",event=>{if(!event.target.matches?.(".r2h4-action-search"))return;const q=event.target.value.toLowerCase();const root=event.target.closest(".sheet-tab-panel");root?.querySelectorAll(".r2h4-action-library .r2h4-action-card").forEach(card=>card.hidden=q&&!card.dataset.actionSearch.includes(q));});

const oldAcceptance=window.runHf05zuiR2bRealAcceptance;
window.runHf05zuiR2bRealAcceptance=async function(){
 const pkg=packageById(state.activePackageId);if(!pkg) throw new Error("Select a character package first.");
 const importEvidence=pkg.hf05zui_real_import;if(!importEvidence?.actual_zip_input_exercised||!importEvidence.zip_files?.length) throw new Error("Re-import the original candidate ZIP before running acceptance.");
 const model=enrich(zuiR2RepairCanonical(zuhRepairModelVisibility(zucBuildViewModelV2(pkg),pkg),pkg),pkg);
 const liveRoot=document.getElementById("activeCharacterVisualSheet");liveRoot.innerHTML=window.renderVisualCharacterSheet(pkg,notesForPackage(pkg.id));attachVisualSheetTabs("activeCharacterVisualSheet");
 const before=hf05zuiR2bCollectRenderedTabs(liveRoot);const saved=compactSavedPackage(pkg);const testRoot=document.createElement("div");testRoot.id="r2h4Rehydrate";testRoot.style.position="fixed";testRoot.style.left="-100000px";testRoot.style.width="1600px";testRoot.innerHTML=window.renderVisualCharacterSheet(saved,notesForPackage(pkg.id));document.body.appendChild(testRoot);attachVisualSheetTabs(testRoot.id);const after=hf05zuiR2bCollectRenderedTabs(testRoot);testRoot.remove();
 const missing=HF05ZUI_R2H_ACCEPTANCE_TABS.filter(t=>!before.tabs.includes(t));const allText=Object.values(before.text).join("\n");const blockers=HF05ZUI_R2H_ACCEPTANCE_BLOCKERS.filter(x=>allText.toLowerCase().includes(x.toLowerCase()));HF05ZUI_R2H_ACCEPTANCE_TABS.forEach(t=>{if(!hf05zuiR2bNormalizeText(before.text[t]))blockers.push(`EMPTY_TAB:${t}`)});
 const retention={};HF05ZUI_R2H_ACCEPTANCE_TABS.forEach(t=>retention[t]={preserved:hf05zuiR2bNormalizeText(before.text[t])===hf05zuiR2bNormalizeText(after.text[t]),before_chars:before.text[t]?.length||0,after_chars:after.text[t]?.length||0});const saveReloadPreserved=Object.values(retention).every(r=>r.preserved);
 const candidate=importEvidence.zip_files[0];const counts=hf05zuiR2bModelCounts(model);const expected=hf05zuiR2bExpectedCounts(pkg);const countMismatches=hf05zuiR2bCountMismatches(expected,counts);const projection=hf05zuiR2cProjectionFidelity(pkg,model);
 const master=model.r2h4_sources.master||{};const packets=model.r2h4_sources.packets||{};const semantic=model.semantic_validation||{};
 const ledgerHash=Object.keys(master).length?await shaText(stable(master)):null;const packetHash=Object.keys(packets).length?await shaText(stable(packets)):null;const semanticHash=Object.keys(semantic).length?await shaText(stable(semantic)):null;
 const semanticValidation={passed:model.semantic_admission.passed&&semantic.ledger_sha256===ledgerHash&&semantic.rules_packets_sha256===packetHash,build_mode:semantic.build_mode||null,verdict:semantic.verdict||"MISSING",schema:semantic.schema||null,semantic_report_sha256:semanticHash,ledger_sha256:ledgerHash,rules_packets_sha256:packetHash,reported_ledger_sha256:semantic.ledger_sha256||null,reported_rules_packets_sha256:semantic.rules_packets_sha256||null,critical:Number(semantic?.counts?.critical||0),high:Number(semantic?.counts?.high||0),issues:model.semantic_admission.issues};
 if(!semanticValidation.passed) blockers.push("SEMANTIC_VALIDATION_NOT_PASS");if(!model.foundation_reconciliation.passed) blockers.push("FOUNDATION_RECONCILIATION_FAILED");if(!model.signature_loadout.passed) blockers.push("SIGNATURE_LOADOUT_INVALID");
 const passed=!missing.length&&!new Set(blockers).size&&!countMismatches.length&&projection.passed&&saveReloadPreserved&&before.tabs.join("|")===HF05ZUI_R2H_ACCEPTANCE_TABS.join("|");
 const report={schema:"HF05ZUI-R2H.RealAcceptanceReport.v1",evidence_class:"real_gm_screen_user_acceptance",verdict:passed?"PASS_REAL_GMSCREEN_ACCEPTANCE":"FAIL_REAL_GMSCREEN_ACCEPTANCE",consumer:"HF05ZUI-R2H",consumer_patch:"HF05ZUI-R2K3-HF3-FOUNDATION34",generated_at:new Date().toISOString(),candidate_filename:candidate.filename,candidate_sha256:candidate.sha256,candidate_bytes:candidate.bytes,actual_zip_input_exercised:true,package_id:pkg.id,character_name:model.identity?.display_name||model.identity?.name||pkg.name,browser:{user_agent:navigator.userAgent,platform:navigator.platform,language:navigator.language},tabs_present:before.tabs,missing_tabs:missing,blockers:[...new Set(blockers)],save_reload_preserved:saveReloadPreserved,retention,counts,expected_counts:expected,expected_counts_match:countMismatches.length===0,count_mismatches:countMismatches,projection_fidelity:projection,model_validation:model.validation,semantic_validation:semanticValidation,foundation_reconciliation:model.foundation_reconciliation,signature_loadout:{passed:model.signature_loadout.passed,count:model.signature_loadout.actions.length,action_ids:model.signature_loadout.actions.map(r=>r.action_id),issues:model.signature_loadout.issues},playable_foundations:{authoritative:30,theoretical_chakra_excluded:32,families:PLAYABLE_FOUNDATION_FAMILY_COUNT},import_evidence:importEvidence};
 window.hf05zuiR2bLastAcceptanceReport=report;const status=document.getElementById("characterAcceptanceStatus");if(status){status.classList.toggle("pass",passed);status.classList.toggle("fail",!passed);status.textContent=`${report.verdict}\n${report.character_name}\nSemantic validation: ${semanticValidation.passed?"PASS":"BLOCKED"}\nFoundation reconciliation: ${model.foundation_reconciliation.passed?"PASS":"BLOCKED"}\nSignature Loadout: ${model.signature_loadout.passed?model.signature_loadout.actions.length+" actions":"INVALID"}\n18-tab set: ${missing.length?"missing "+missing.join(", "):"complete"}\nBlockers: ${report.blockers.length?report.blockers.join("; "):"none"}\nSave/reload: ${saveReloadPreserved?"preserved":"failed"}\nCandidate SHA-256: ${candidate.sha256}`;}const exportButton=document.getElementById("exportCharacterAcceptanceButton");if(exportButton)exportButton.disabled=false;return report;
};
window.HF05ZUI_R2H4={patch:PATCH,playable_foundations:()=>list(window.TIANXIA_FOUNDATION_CATALOG).length,enrich,reconcileFoundation,renderActions,renderDiagnostics};

function refresh(){try{if(typeof fillFoundationCatalogSelect==="function")fillFoundationCatalogSelect();if(typeof renderLibrary==="function")renderLibrary();}catch(e){console.error("R2H.4 refresh",e)}}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",refresh,{once:true});else refresh();
})();
