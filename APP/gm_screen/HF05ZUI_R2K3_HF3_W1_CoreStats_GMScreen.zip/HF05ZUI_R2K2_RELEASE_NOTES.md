# HF05ZUI-R2K.2 — Factory Assurance Patch

This patch coordinates with Factory HF05ZVK-R1G Phase 2H and Combat Bootstrap HF05ZN-R2F.

## Corrections

- Distinguishes the current Foundation **Common Expression** stage from **Awakened** catalog progression.
- Renders legacy and mundane equipment when no Item Book R2 instance exists.
- Retains and requires all 26 Phase 2H sidecars through compact save/rehydration.
- Preserves the fixed 18-tab registry and updates stale 14-tab status text.
- Keeps candidate schema compatibility at HF05ZVK-R1F; R1G is the producer release, not a new candidate schema.

## Acceptance

Production release still requires a native `HF05ZUI-R2K.RealAcceptanceReport.v1` bound to the exact candidate ZIP SHA-256.
