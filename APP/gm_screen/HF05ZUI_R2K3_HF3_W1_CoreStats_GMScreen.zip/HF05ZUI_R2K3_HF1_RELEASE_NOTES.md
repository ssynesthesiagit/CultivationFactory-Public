# HF05ZUI-R2K.3 HF1 — Builder Talent Readability and Classification

This is a Character Builder catalog/UI hotfix. It does not change the 18-tab character-viewer contract, compact-save schema, native acceptance schema, candidate schema, or HF05ZN-R2G combat admission boundary.

## Repairs

- Regenerated the short descriptions for all 3,721 canonical 85-Sphere selector rows from their complete authored source text.
- Added the complete authored talent text to the same native hover tooltip used by Background Origin Insights.
- Removed 509 Cultivation Insight rows from the talent selector; they remain in the dedicated Insight selector.
- Removed 218 variant/drawback rows from the talent selector; they remain in the dedicated variant selector.
- Added runtime filtering so stale saved drafts cannot export an Insight or variant as a talent.
- Search now includes the complete authored talent text.

## Catalog assurance

- 90 Sphere catalogs checked.
- 3,761 selectable rows retained.
- 3,721 canonical rows bound to complete authored source text.
- 40 Chakra-extension rows have explicit source-reference summaries because the supplied Phase 2I corpus does not contain their full authored talent packet. No mechanics were invented to conceal that source gap.
- 0 canonical 85-Sphere rows lack a source-text match.
- Static/catalog regression: 20/20 checks passed.

## Scope boundary

The hotfix removes rows that can be proven to be dedicated Insights or variants. A broader parser audit found that a few Sphere source trees may still expose nested rule headings as selectable rows. Those were not deleted automatically because safe removal requires a canon-sensitive classification pass rather than a UI heuristic.
