# HF05ZUI-R2H.1 Character Builder Usability Hotfix

This is a UI and authoring patch over the unchanged **HF05ZUI-R2H consumer/acceptance contract**. Combat Bootstrap compatibility remains HF05ZUI-R2H.

- Expanded the Character Builder from 12 to all 31 published Backgrounds.
- Selecting a Background now displays every legal free Background Sphere and talent option.
- Choosing a grant automatically adds the Sphere to the main Sphere browser and marks the free talent without double-counting it.
- Active, dormant, and preparatory grants are visibly distinguished and exported in the Background record.
- Talent cards now use compact one-line descriptions with full text retained as a tooltip, preventing card-height expansion.
- Restored four published Background talents omitted by the generated catalog: Armor Training, Shield Training, Mount Training, and False Opening.
- Foundation previews now combine player-facing identity and signs with selected-stage mechanics, runtime actions/resources, GM-facing burdens/injuries/deviations, repair routes, compatibility, and explicit boundaries.
- Character Builder package version advanced to `HF05ZUI-R2H-builder-v5`; consumer target remains `HF05ZUI-R2H`.
- Completed readable player summaries for Red Lotus Ash-Returning, Jade Furnace Meridian, and Beast-Echo Marrow from their existing runtime records; no mechanics changed.
