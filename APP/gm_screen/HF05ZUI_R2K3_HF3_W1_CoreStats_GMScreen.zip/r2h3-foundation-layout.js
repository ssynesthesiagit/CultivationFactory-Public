(function () {
  "use strict";

  const PATCH_ID = "HF05ZUI-R2H.3-FOUNDATION-UNIFIED-LAYOUT";
  const projection = window.TIANXIA_FOUNDATION_READABLE || { foundations: [] };
  const rows = Array.isArray(projection.foundations) ? projection.foundations : [];

  const compactKey = (value) => String(value || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "");

  const readableById = new Map();
  const readableByName = new Map();
  const readableByCode = new Map();
  rows.forEach((row) => {
    if (!row || !row.name) return;
    const ids = [row.foundation_id, row.id].filter(Boolean);
    ids.forEach((id) => readableById.set(compactKey(id), row));
    readableByName.set(compactKey(row.name), row);
    if (row.catalog_code) readableByCode.set(compactKey(row.catalog_code), row);
  });

  const html = (value) => {
    const text = String(value ?? "");
    if (typeof window.escapeHtml === "function") return window.escapeHtml(text);
    return text.replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  };
  const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  const list = (value) => Array.isArray(value) ? value.filter(Boolean) : (value ? [value] : []);
  const sentence = (value) => clean(value) || "Not defined in the source record.";
  const shorten = (value, max = 240) => {
    const text = clean(value);
    return text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text;
  };
  const label = (value) => clean(value)
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());

  const stageOrder = ["common_expression", "awakened", "integrated", "refined", "perfected"];
  const stageKey = (value) => {
    const raw = compactKey(value);
    if (raw.includes("perfect")) return "perfected";
    if (raw.includes("refin")) return "refined";
    if (raw.includes("integrat")) return "integrated";
    if (raw.includes("awaken")) return "awakened";
    if (raw.includes("commonexpression")) return "common_expression";
    return raw || "awakened";
  };
  const stageName = (value) => ({ common_expression: "Common Expression", awakened: "Awakened", integrated: "Integrated", refined: "Refined", perfected: "Perfected" }[stageKey(value)] || label(value));
  const stageIndex = (value) => Math.max(0, stageOrder.indexOf(stageKey(value)));

  function lookupReadable(item = {}) {
    if (!item) return null;
    if (typeof item === "string") return readableByName.get(compactKey(item)) || readableById.get(compactKey(item)) || readableByCode.get(compactKey(item)) || null;
    const candidates = [
      item.foundation_id, item.id, item.catalog_binding?.foundation_id,
      item.name, item.foundation_name, item.chosen_foundation, item.display_name,
      item.catalog_code, item.catalog_binding?.catalog_code
    ].filter(Boolean);
    for (const candidate of candidates) {
      const key = compactKey(candidate);
      const found = readableById.get(key) || readableByName.get(key) || readableByCode.get(key);
      if (found) return found;
    }
    return null;
  }

  function pill(text, tone = "") {
    if (!clean(text)) return "";
    return `<span class="uf-pill${tone ? ` ${tone}` : ""}">${html(text)}</span>`;
  }

  function fact(labelText, value, options = {}) {
    const text = clean(value);
    if (!text && !options.showEmpty) return "";
    return `<article class="uf-fact${options.wide ? " wide" : ""}"><strong>${html(labelText)}</strong><p>${html(text || "Not defined in the source record.")}</p></article>`;
  }

  function bulletList(values, empty = "No entries recorded.") {
    const items = list(values).map((value) => {
      if (typeof value === "string") return clean(value);
      return clean(value?.text || value?.display || value?.name || value?.display_name || value?.summary || JSON.stringify(value));
    }).filter(Boolean);
    return items.length
      ? `<ul class="uf-bullets">${items.map((item) => `<li>${html(item)}</li>`).join("")}</ul>`
      : `<p class="uf-empty">${html(empty)}</p>`;
  }

  function overviewHtml(row, options = {}) {
    const p = row.profile || {};
    const o = row.overview || {};
    const draft = row.catalog_status === "theoretical_draft" || /theoretical/i.test(String(p.status || ""));
    const currentStage = stageName(options.stage || p.default_stage || "Awakened");
    const code = row.catalog_code || (row.number ? `FS${String(row.number).padStart(2, "0")}` : "");
    return `<section class="uf-hero${draft ? " is-draft" : ""}">
      <div class="uf-hero-main">
        <span class="uf-kicker">${html(code ? `${code} · Foundation Path Expression` : "Foundation Path Expression")}</span>
        <h3>${html(row.name)}</h3>
        <p class="uf-summary">${html(sentence(o.summary))}</p>
        <blockquote>${html(sentence(o.dao_principle))}</blockquote>
      </div>
      <div class="uf-pill-row">
        ${pill(p.grade || "Grade not recorded")}
        ${pill(currentStage, "stage")}
        ${pill(p.primary_path || "Path not recorded")}
        ${pill(p.typical_role || "Role not recorded")}
        ${draft ? pill("Theoretical draft — not mechanically complete", "warning") : pill(p.status || "Stable", "ready")}
      </div>
      <div class="uf-at-glance">
        ${fact("Visible Sign", o.visible_sign, { wide: true })}
        ${fact("Core Warning", o.warning, { wide: true })}
        ${fact("Complexity", p.complexity || "Not rated")}
        ${fact("Secondary Path Fit", list(p.secondary_path_fit).join(", ") || "None listed")}
        ${p.seated_wheel ? fact("Seated Wheel", p.seated_wheel) : ""}
      </div>
      ${draft ? `<div class="uf-draft-banner"><strong>Incomplete rules source.</strong><span>${html(row.builder_notice || "This Foundation is a concept entry only. Do not infer benefits, resources, actions, or progression.")}</span></div>` : ""}
    </section>`;
  }

  function resourceHtml(resource) {
    if (!resource) return `<section class="uf-section"><div class="uf-section-heading"><span>3</span><div><h4>Foundation Resource</h4><p>No executable resource loop exists in the source.</p></div></div><p class="uf-empty">Resource mechanics are not defined.</p></section>`;
    return `<section class="uf-section resource-section">
      <div class="uf-section-heading"><span>3</span><div><h4>Foundation Resource — ${html(resource.name || "Unnamed Resource")}</h4><p>How the resource is gained, held, spent, and denied.</p></div></div>
      <div class="uf-resource-banner"><strong>${html(resource.name || "Resource")}</strong><span>Maximum ${html(resource.maximum ?? "?")} · Starts at ${html(resource.starting ?? "0")}</span></div>
      <div class="uf-fact-grid resource-grid">
        ${fact("How You Gain It", resource.gain, { wide: true })}
        ${fact("Timing", resource.timing)}
        ${fact("Generation Limit", resource.frequency)}
        ${fact("Expiration", resource.expiry)}
        ${fact("Same-Event Rule", resource.same_event, { wide: true })}
        ${fact("Anti-Farming / Counterplay", resource.anti_farming, { wide: true })}
      </div>
      <h5 class="uf-subheading">What Spends It</h5>
      ${bulletList(resource.spends, "No spend routes recorded.")}
    </section>`;
  }

  function featureCard(feature, currentStage, compact = false) {
    const meta = [feature.type, feature.stage ? `Stage ${stageName(feature.stage)}` : "", feature.cost ? `Cost ${feature.cost}` : ""].filter(Boolean);
    const details = [
      ["Trigger", feature.trigger],
      ["Range", feature.range],
      ["Target", feature.target],
      ["Attack or Save", feature.attack_or_save],
      ["Duration", feature.duration],
      ["Limit", feature.limit],
      ["Counterplay", feature.counterplay]
    ].filter(([, value]) => clean(value));
    return `<article class="uf-feature-card${stageKey(feature.stage) === stageKey(currentStage) ? " current" : ""}">
      <header><div><span class="uf-feature-stage">${html(stageName(feature.stage || currentStage))}</span><h5>${html(feature.name || "Unnamed Feature")}</h5></div><div class="uf-feature-meta">${meta.map((m) => pill(m)).join("")}</div></header>
      <p class="uf-effect"><strong>Effect.</strong> ${html(sentence(feature.effect))}</p>
      ${compact ? "" : `<div class="uf-feature-details">${details.map(([k, v]) => fact(k, v)).join("")}</div>`}
      ${list(feature.source_spheres).length ? `<p class="uf-source-spheres"><strong>Natural source expressions:</strong> ${html(list(feature.source_spheres).join(", "))}</p>` : ""}
    </article>`;
  }

  function attainedFeatures(row, currentStage) {
    const features = row.features || {};
    const max = stageIndex(currentStage);
    return stageOrder.slice(0, max + 1).flatMap((stage) => list(features[stage]));
  }

  function currentStageHtml(row, currentStage) {
    const features = attainedFeatures(row, currentStage);
    return `<section class="uf-section current-stage-section">
      <div class="uf-section-heading"><span>2</span><div><h4>What It Does at ${html(stageName(currentStage))}</h4><p>Foundation stages are cumulative. The cards below include all attained stages.</p></div></div>
      ${features.length ? `<div class="uf-feature-stack">${features.map((feature) => featureCard(feature, currentStage, true)).join("")}</div>` : `<p class="uf-empty">No executable features are defined for this stage.</p>`}
    </section>`;
  }

  function progressionHtml(row, currentStage) {
    const features = row.features || {};
    const currentIndex = stageIndex(currentStage);
    return `<section class="uf-section progression-section">
      <div class="uf-section-heading"><span>4</span><div><h4>Complete Stage Progression</h4><p>Earlier stage benefits remain active unless a feature explicitly replaces them.</p></div></div>
      <div class="uf-stage-stack">${stageOrder.map((stage, index) => {
        const stageFeatures = list(features[stage]);
        const attained = index <= currentIndex;
        return `<details class="uf-stage-card${attained ? " attained" : " future"}"${stage === stageKey(currentStage) ? " open" : ""}>
          <summary><span>${html(stageName(stage))}</span><em>${attained ? "Attained" : "Future stage"} · ${stageFeatures.length} feature${stageFeatures.length === 1 ? "" : "s"}</em></summary>
          ${stageFeatures.length ? `<div class="uf-feature-stack compact">${stageFeatures.map((feature) => featureCard(feature, currentStage, false)).join("")}</div>` : `<p class="uf-empty">No separate feature rows are defined for this stage.</p>`}
        </details>`;
      }).join("")}</div>
    </section>`;
  }

  function compatibilityHtml(row) {
    const c = row.compatibility || {};
    return `<section class="uf-section compatibility-section">
      <div class="uf-section-heading"><span>5</span><div><h4>Compatibility and Rules Boundaries</h4><p>Compatibility is not a grant. Only the explicitly listed effects apply.</p></div></div>
      ${list(c.legal_spheres).length ? `<h5 class="uf-subheading">Compatible Spheres and Expressions</h5><div class="uf-chip-grid">${list(c.legal_spheres).map((sphere) => pill(sphere, "sphere")).join("")}</div>` : `<p class="uf-empty">No compatible Sphere list is defined.</p>`}
      <div class="uf-two-column">
        <div><h5 class="uf-subheading">Expression Notes</h5>${bulletList(c.expression_notes, "No additional expression notes.")}</div>
        <div><h5 class="uf-subheading">What It Does Not Grant</h5>${bulletList(c.does_not_grant, "No additional boundaries recorded.")}</div>
      </div>
    </section>`;
  }

  function riskCard(row, category) {
    const name = row.display_name || row.name || row.id || label(category);
    const severity = row.severity ? `Severity ${row.severity}` : "";
    return `<article class="uf-risk-card ${html(category)}"><header><h5>${html(name)}</h5>${severity ? pill(severity, "warning") : ""}</header><p>${html(sentence(row.text || row.effect || row.summary))}</p></article>`;
  }

  function risksHtml(row) {
    const risks = row.risks || {};
    const groups = [
      ["Burdens", "burden", risks.burdens],
      ["Hidden Injuries", "injury", risks.hidden_injuries],
      ["Strains", "strain", risks.strains],
      ["Deviations", "deviation", risks.deviations]
    ];
    const total = groups.reduce((n, [, , values]) => n + list(values).length, 0);
    return `<section class="uf-section risk-section">
      <div class="uf-section-heading"><span>6</span><div><h4>Risks and Consequences</h4><p>These risks are visible to both player and GM.</p></div></div>
      ${total ? groups.map(([heading, cls, values]) => list(values).length ? `<div class="uf-risk-group"><h5 class="uf-subheading">${html(heading)}</h5><div class="uf-risk-stack">${list(values).map((risk) => riskCard(risk, cls)).join("")}</div></div>` : "").join("") : `<p class="uf-empty">No structured risk records are defined.</p>`}
    </section>`;
  }

  function procedureCard(item, kind) {
    const name = item.name || item.display_name || item.title || `${kind} Procedure`;
    const meta = [item.stage ? stageName(item.stage) : "", item.type, item.cost].filter(Boolean);
    const fields = [
      ["Trigger / Requirement", item.trigger || item.requirements],
      ["Range", item.range],
      ["Target", item.target],
      ["Check or Save", item.attack_or_save],
      ["Procedure / Effect", item.effect || item.procedure],
      ["Limit", item.limit],
      ["Counterplay / Failure", item.counterplay || item.failure]
    ].filter(([, value]) => clean(value));
    return `<article class="uf-procedure-card"><header><div><span>${html(kind)}</span><h5>${html(name)}</h5></div><div>${meta.map((m) => pill(m)).join("")}</div></header><div class="uf-fact-grid">${fields.map(([k, v]) => fact(k, v, { wide: k === "Procedure / Effect" })).join("")}</div></article>`;
  }

  function recoveryHtml(row) {
    const repairs = list(row.repair_practices);
    const challenges = list(row.foundation_challenges);
    const lineage = list(row.lineage_hooks);
    return `<section class="uf-section recovery-section">
      <div class="uf-section-heading"><span>7</span><div><h4>Repair, Advancement, and Lineage</h4><p>How the Foundation is corrected, advanced, and transmitted.</p></div></div>
      <details class="uf-procedure-group" open><summary>Repair and Recovery · ${repairs.length}</summary>${repairs.length ? `<div class="uf-procedure-stack">${repairs.map((item) => procedureCard(item, "Repair Practice")).join("")}</div>` : `<p class="uf-empty">No standalone structured repair practice is defined in the source.</p>`}</details>
      <details class="uf-procedure-group"><summary>Foundation Challenges · ${challenges.length}</summary>${challenges.length ? `<div class="uf-procedure-stack">${challenges.map((item) => procedureCard(item, "Foundation Challenge")).join("")}</div>` : `<p class="uf-empty">No standalone structured Foundation Challenge is defined in the source.</p>`}</details>
      <details class="uf-procedure-group"><summary>Lineage and Setting Hooks · ${lineage.length}</summary>${lineage.length ? `<div class="uf-procedure-stack">${lineage.map((item) => procedureCard(item, "Lineage Hook")).join("")}</div>` : `<p class="uf-empty">No lineage hook is defined.</p>`}</details>
    </section>`;
  }

  function sourceGapsHtml(row) {
    const gaps = list(row.source_gaps);
    if (!gaps.length) return "";
    return `<section class="uf-source-gaps"><strong>Source gaps retained transparently</strong>${bulletList(gaps)}</section>`;
  }

  function importedRecordHtml(imported = {}) {
    const groups = [
      ["Prominent Benefits", imported.benefits],
      ["Passive Chassis", imported.passive_chassis],
      ["Resource Modifiers", imported.primary_resource_modifiers],
      ["Resources / Counters", imported.resources_counters],
      ["Actions / Riders", imported.actions_riders],
      ["Fixed Scope", imported.fixed_scope],
      ["Suppressed / Excluded", imported.suppressed_or_excluded_benefits],
      ["Current Risks / Notes", imported.burdens_strains_deviations],
      ["AI Piloting Notes", imported.ai_notes]
    ].filter(([, values]) => list(values).length);
    if (!groups.length) return "";
    return `<section class="uf-section imported-record-section">
      <div class="uf-section-heading"><span>1</span><div><h4>Current Character Record</h4><p>Character-specific values imported from the candidate ZIP. These take precedence where they are more specific than the catalog summary.</p></div></div>
      <div class="uf-imported-grid">${groups.map(([heading, values]) => `<article><h5>${html(heading)}</h5>${bulletList(values)}</article>`).join("")}</div>
    </section>`;
  }

  function unifiedFoundationHtml(row, options = {}) {
    if (!row) return "";
    const currentStage = stageKey(options.stage || row.profile?.default_stage || "Awakened");
    const draft = row.catalog_status === "theoretical_draft" || /theoretical/i.test(String(row.profile?.status || ""));
    return `<div class="foundation-unified-layout" data-foundation-readable="${html(row.foundation_id || row.name)}" data-patch="${PATCH_ID}">
      ${overviewHtml(row, { stage: currentStage })}
      ${options.imported ? importedRecordHtml(options.imported) : ""}
      ${draft ? "" : currentStageHtml(row, currentStage)}
      ${draft ? "" : resourceHtml(row.resource)}
      ${draft ? "" : progressionHtml(row, currentStage)}
      ${compatibilityHtml(row)}
      ${draft ? "" : risksHtml(row)}
      ${draft ? "" : recoveryHtml(row)}
      ${sourceGapsHtml(row)}
    </div>`;
  }

  function readableNotes(row, stage) {
    const o = row.overview || {};
    const p = row.profile || {};
    const r = row.resource || {};
    const lines = [
      `${row.name} — ${p.grade || "Grade not recorded"}, ${stageName(stage || p.default_stage)}`,
      `In plain language: ${sentence(o.summary)}`,
      `Visible sign: ${sentence(o.visible_sign)}`,
      `Core warning: ${sentence(o.warning)}`,
      `Dao principle: ${sentence(o.dao_principle)}`,
      r.name ? `Resource: ${r.name} ${r.starting ?? 0}/${r.maximum ?? "?"}; gain ${sentence(r.gain)}; ${sentence(r.frequency)}; expires ${sentence(r.expiry)}; ${sentence(r.same_event)}` : "Resource: none defined in the source."
    ];
    return lines.join("\n");
  }

  function readableLifecycle(row) {
    const risks = row.risks || {};
    const lines = [
      ...stageOrder.map((stage) => `${stageName(stage)}: ${list(row.features?.[stage]).map((f) => f.name).join(", ") || "No separate feature rows."}`),
      `Burdens: ${list(risks.burdens).map((x) => x.display_name || x.name || x.id).join(", ") || "None structured."}`,
      `Hidden injuries: ${list(risks.hidden_injuries).map((x) => x.display_name || x.name || x.id).join(", ") || "None structured."}`,
      `Strains: ${list(risks.strains).map((x) => x.display_name || x.name || x.id).join(", ") || "None structured."}`,
      `Deviations: ${list(risks.deviations).map((x) => x.display_name || x.name || x.id).join(", ") || "None structured."}`,
      `Repair practices: ${list(row.repair_practices).map((x) => x.name || x.display_name).join(", ") || "No standalone structured repair rows."}`,
      `Foundation Challenges: ${list(row.foundation_challenges).map((x) => x.name || x.display_name).join(", ") || "No standalone structured challenge rows."}`,
      `Does not grant: ${list(row.compatibility?.does_not_grant).join("; ") || "No additional boundary rows."}`
    ];
    return lines.join("\n");
  }

  const previousBuilderPreview = window.foundationBuilderPreviewHtml;
  window.foundationBuilderPreviewHtml = function foundationBuilderPreviewHtmlR2H3(item = {}, stage = "") {
    const readable = lookupReadable(item);
    if (!readable) return typeof previousBuilderPreview === "function" ? previousBuilderPreview(item, stage) : "Custom Foundation mode. Enter the Foundation fields manually.";
    return unifiedFoundationHtml(readable, { stage });
  };

  const previousNotes = window.foundationCatalogNotes;
  window.foundationCatalogNotes = function foundationCatalogNotesR2H3(item = {}, stage = "") {
    const readable = lookupReadable(item);
    return readable ? readableNotes(readable, stage) : (typeof previousNotes === "function" ? previousNotes(item, stage) : "");
  };

  const previousLifecycle = window.foundationCatalogLifecycleText;
  window.foundationCatalogLifecycleText = function foundationCatalogLifecycleTextR2H3(item = {}) {
    const readable = lookupReadable(item);
    return readable ? readableLifecycle(readable) : (typeof previousLifecycle === "function" ? previousLifecycle(item) : "");
  };


  const previousFoundationLibraryCard = window.foundationLibraryCard;
  window.foundationLibraryCard = function foundationLibraryCardR2H3(item = {}) {
    const readable = lookupReadable(item);
    if (!readable) return typeof previousFoundationLibraryCard === "function" ? previousFoundationLibraryCard(item) : "";
    const p = readable.profile || {};
    const o = readable.overview || {};
    const draft = readable.catalog_status === "theoretical_draft" || /theoretical/i.test(String(p.status || ""));
    return `<article class="library-card foundation-library-card uf-library-card">
      <header class="foundation-card-header"><div><span class="manual-label">${html(readable.catalog_code || `FS${String(readable.number || "").padStart(2,"0")}`)}</span><h3>${html(readable.name)}</h3></div></header>
      <div class="uf-pill-row">${pill(p.grade)}${pill(p.primary_path)}${pill(p.typical_role)}${draft ? pill("Theoretical draft", "warning") : pill(p.status || "Stable", "ready")}</div>
      <p class="foundation-doctrine">${html(sentence(o.summary))}</p>
      <div class="uf-library-quick">${fact("Visible Sign", o.visible_sign)}${fact("Core Warning", o.warning)}${readable.resource ? fact("Resource", `${readable.resource.name} — maximum ${readable.resource.maximum}`) : fact("Resource", "Not defined")}</div>
      <details class="uf-library-details" data-foundation-lazy="${html(readable.foundation_id || readable.name)}"><summary>Open complete unified record</summary><div class="uf-library-detail-host"><p class="uf-empty">Open this record to load the complete Foundation rules.</p></div></details>
    </article>`;
  };

  const previousLibraryCard = window.foundationCardHtml;
  window.foundationCardHtml = function foundationCardHtmlR2H3(item = {}, index = 0) {
    const readable = lookupReadable(item);
    if (!readable) return typeof previousLibraryCard === "function" ? previousLibraryCard(item, index) : "";
    const p = readable.profile || {};
    const o = readable.overview || {};
    const draft = readable.catalog_status === "theoretical_draft" || /theoretical/i.test(String(p.status || ""));
    return `<article class="foundation-card uf-library-card">
      <header class="foundation-card-header"><div><span class="manual-label">${html(readable.catalog_code || `Foundation ${index + 1}`)}</span><h4>${html(readable.name)}</h4></div><span class="foundation-index">${html(String(index + 1))}</span></header>
      <div class="uf-pill-row">${pill(p.grade)}${pill(p.primary_path)}${pill(p.typical_role)}${draft ? pill("Theoretical draft", "warning") : pill(p.status || "Stable", "ready")}</div>
      <p class="foundation-doctrine">${html(sentence(o.summary))}</p>
      <div class="uf-library-quick">${fact("Visible Sign", o.visible_sign)}${fact("Core Warning", o.warning)}${readable.resource ? fact("Resource", `${readable.resource.name} — max ${readable.resource.maximum}`) : fact("Resource", "Not defined")}</div>
      <details class="uf-library-details" data-foundation-lazy="${html(readable.foundation_id || readable.name)}"><summary>Open complete unified record</summary><div class="uf-library-detail-host"><p class="uf-empty">Open this record to load the complete Foundation rules.</p></div></details>
    </article>`;
  };

  const previousExplainer = window.foundationExplainerHtml;
  window.foundationExplainerHtml = function foundationExplainerHtmlR2H3() {
    return `<section class="foundation-explainer uf-library-explainer"><div><span class="manual-label">Foundation family and expression catalog</span><h4>Read each Foundation in table order</h4><p>Every expression begins with its Body Aspect, Root Aspect, or Anchor Aspect, followed by plain-language function, then current mechanics, resource flow, progression, compatibility, risks, recovery, and adjudication. Player and GM information are intentionally combined.</p></div><div class="foundation-explainer-grid"><article><strong>What it does</strong><p>Start with the role, visible sign, warning, and current-stage feature cards.</p></article><article><strong>How it runs</strong><p>Resource generation, timing, costs, limits, and counterplay are presented together.</p></article><article><strong>What can go wrong</strong><p>Burdens, injuries, strains, and deviations are fully visible.</p></article><article><strong>How it recovers</strong><p>Repair practices, advancement challenges, and lineage hooks follow the risk section.</p></article></div></section>`;
  };

  const previousZudFoundation = window.zudRenderFoundation;
  window.zudRenderFoundation = function zudRenderFoundationR2H3(model = {}) {
    const imported = model.foundation || {};
    const readable = lookupReadable(imported);
    if (!readable) return typeof previousZudFoundation === "function" ? previousZudFoundation(model) : `<p class="zud-muted">Foundation not recorded.</p>`;
    return `<div class="zud-tab-heading"><h3>Foundation</h3><p>Unified player-and-GM record: current character values first, followed by the complete readable Foundation rules.</p></div>${unifiedFoundationHtml(readable, { stage: imported.status_stage || readable.profile?.default_stage, imported })}`;
  };


  document.addEventListener("click", (event) => {
    const summary = event.target.closest?.(".uf-library-details > summary");
    if (!summary) return;
    const details = summary.parentElement;
    const host = details?.querySelector(".uf-library-detail-host");
    if (!details || !host || details.dataset.loaded === "true") return;
    const readable = lookupReadable(details.dataset.foundationLazy || "");
    if (!readable) return;
    host.innerHTML = unifiedFoundationHtml(readable, { stage: readable.profile?.default_stage });
    details.dataset.loaded = "true";
  });

  window.HF05ZUI_R2H3_FOUNDATION_LAYOUT = {
    patch: PATCH_ID,
    projection_schema: projection.schema,
    projection_status: projection.status,
    count: rows.length,
    lookup: lookupReadable,
    render: unifiedFoundationHtml
  };

  function refreshVisibleFoundation() {
    try {
      const selected = typeof window.selectedBuilderFoundationCatalog === "function" ? window.selectedBuilderFoundationCatalog() : null;
      const preview = document.getElementById("builderFoundationPreview");
      if (selected && preview) {
        const stage = document.getElementById("builderFoundationStage")?.value || selected.stage || selected.default_stage || "Awakened";
        preview.innerHTML = window.foundationBuilderPreviewHtml(selected, stage);
      }
      if (typeof window.renderLibrary === "function") window.renderLibrary();
    } catch (error) {
      console.error("R2H.3 Foundation refresh failed", error);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", refreshVisibleFoundation, { once: true });
  else refreshVisibleFoundation();
})();
