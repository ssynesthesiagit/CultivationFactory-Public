# Tianxia Foundation Families and Path Expressions RC1

**34 families · 86 supported expressions**

Foundation is the umbrella subsystem. Body Refining uses Body Aspects, Qi Cultivation uses Cultivation Roots, and Spirit Awakening uses Soul Anchors. Unsupported expressions are intentional exclusions.

## FF01 · Ancient Desolate Sacred Body (Legendary)

The body becomes a golden sea whose depth cannot be defined by the limits Heaven assigns to ordinary flesh.

### FF01-B · Ancient Desolate Sacred Body — Body Refining

**Body Aspect: Ancient Desolate Sacred Body**

This is an innate Legendary physique, not merely a learned defensive technique. Bones, blood, skin, organs, and the inner golden sea possess extraordinary density, vitality, and resistance to bodily suppression. Scriptures teach the cultivator how to survive and develop what was already born within them.

**Resource:** Golden Sea Pressure (4/6/8)

- **Golden Sea Guard (1 Golden Sea Pressure; Reaction):** Reduce the damage by three times your Proficiency Bonus + Constitution modifier at Awakened, four times PB + Constitution modifier at Refined, or five times PB + Constitution modifier at Perfected.
- **Sacred Body Rebuke (1 Golden Sea Pressure; No Action):** Deal additional force or radiant damage equal to three times your Proficiency Bonus at Awakened, four times PB at Refined, or five times PB at Perfected. Push the target 15, 20, or 30 feet respectively if it is no more than one size larger than you. At Perfected, it also cannot take Reactions until the start of your next turn.
- **Refuse Heaven-Lock (2 Golden Sea Pressure; Reaction):** Negate the triggering Prone, Grappled, or Restrained condition; prevent the physical transformation or bodily suppression until the end of your next turn; or reduce the forced movement to 0. Then you may move up to 15 feet without provoking opportunity attacks.
- **Golden Sea Restoration (3 Golden Sea Pressure; Bonus Action):** Gain temporary Hit Points equal to three times your Character Level + Constitution modifier and end one poison, disease, or level of exhaustion caused by a hostile bodily effect.

**Explicit non-grants:** Does not grant any Sphere, Method, Recorded Art, Forged Technique, or Immortal Art.; Does not grant a Cultivation Root, Soul Anchor, Aura, or Domain.; Does not automatically combine with the Innate Sacred Body Dao Embryo or another expression; integration requires separate access and an explicit combining Method.

**Cultivation Root excluded:** The Ancient Desolate Sacred Body is specifically an innate physique, not a dantian or meridian Root. A Dao Embryo or other Root must be a separate compatible Foundation integrated by Method.

**Soul Anchor excluded:** Bodily supremacy does not by itself answer what preserves identity or organizes the soul. A separate Soul Anchor may combine through an authorized Method.

## FF02 · Origin-Spirit Body (Rare)

Life is strongest when its source can renew itself, distinguish self from foreign influence, and nourish chosen bonds.

### FF02-B · Origin-Spirit Wellspring Body — Body Refining

**Body Aspect: Origin-Spirit Wellspring**

An origin-spirit current is rooted in the heart, marrow, and blood. It converts cultivation pressure into living vitality and lets the body preserve or transfer that vitality under stress.

**Resource:** Source Dew (3/5/7)

- **Wellspring Guard (1 Source Dew; Reaction):** Reduce the damage by twice Proficiency Bonus plus Constitution modifier. If protecting another creature, you may take up to half the remaining damage instead; that transferred damage cannot be reduced again.
- **Share the Source (1 Source Dew; Bonus Action):** Transfer up to twice your Character Level Hit Points between you and the target. The donor cannot be reduced below 1 Hit Point. The recipient also gains temporary Hit Points equal to Proficiency Bonus.
- **Overflowing Vitality (2 Source Dew; No Action):** Reduce the Stamina cost by 2, minimum 1, or increase one healing, temporary-Hit-Point, or damage-prevention value by three times Proficiency Bonus.

**Explicit non-grants:** Does not grant the Life or Vitality Sphere.; Does not resurrect the dead.; Does not provide unlimited healing or remove the donor limit.

### FF02-Q · Origin-Spirit Wellspring Root — Qi Cultivation

**Root Aspect: First Wellspring**

A spring-like Root forms beneath the dantian. Its Qi rises cleanly through the meridians, replenishes depleted channels, and naturally supports techniques that sustain or restore life.

**Resource:** Wellspring Current (3/5/7)

- **Hold the Source (1 Wellspring Current; Reaction):** Reduce involuntary Qi loss by twice Proficiency Bonus, minimum 0, or prevent one sustained effect from ending due to damage, forced movement, or ordinary circulation disruption.
- **Return the Current (1 Wellspring Current; No Action):** Reduce the Qi cost by 2, minimum 1, or increase one healing, temporary-Hit-Point, or damage-prevention value by three times Proficiency Bonus.
- **Wellspring Benediction (2 Wellspring Current; Bonus Action):** Until the start of your next turn, targets have advantage on saves against exhaustion, Qi drain, and maximum-Hit-Point reduction, and gain temporary Hit Points equal to twice Proficiency Bonus.

**Explicit non-grants:** Does not grant Life, Vitality, or Water.; Does not create Qi without a printed trigger.; Does not negate all Qi drain.

### FF02-S · Constellation of Returning Bonds Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Nourishes and Returns**

The soul sea contains a constellation formed from authentic bonds, responsibilities, and lives you have chosen to sustain. Each star confirms a relationship without allowing that relationship to erase your identity.

**Resource:** Bond Dew (3/5/7)

- **Follow the Bond Home (1 Bond Dew; Reaction):** Add twice Proficiency Bonus to the save after the roll but before resolution.
- **Preserve the Name (1 Bond Dew; Bonus Action):** Until the start of your next turn, the target cannot be made unable to recognize its own name, your Aura, or one authentic bond, and it has advantage on one covered save.
- **Constellation Renewal (2 Bond Dew; No Action):** Reduce the Resonance cost by 2, minimum 1, or reduce the spiritual damage by four times Proficiency Bonus.

**Explicit non-grants:** Does not grant Life, Vitality, Karma, or Spirit Companions.; Does not compel loyalty.; Does not create a complete Domain.

## FF03 · Red Lotus Ash-Returning (Major)

Destruction becomes renewal only when the cultivator chooses what must burn, what must be remembered, and what may return.

### FF03-B · Red Lotus Ash-Returning Body — Body Refining

**Body Aspect: Ash-Returning Red Lotus**

A red lotus furnace is cultivated through the blood, organs, and marrow. It turns injury, poison, disease, and destructive heat into Funeral Embers used for survival and violent renewal.

**Resource:** Funeral Ember (4/6/8)

- **Ash-Skin Refusal (1 Funeral Ember; Reaction):** Reduce the triggering damage by three times Proficiency Bonus plus Constitution modifier. If reduced to 0, end one ongoing source of the same damage type that allows repeated saves.
- **Funeral Petal Strike (1 Funeral Ember; No Action):** Deal additional fire or necrotic damage equal to three times Proficiency Bonus. If the target is below half Hit Points, it cannot regain Hit Points until the start of your next turn.
- **Return From Cinders (2 Funeral Ember; Bonus Action):** End one qualifying effect that permits a repeated save, move up to half your Speed without provoking opportunity attacks, and gain temporary Hit Points equal to twice Character Level.

**Explicit non-grants:** Does not grant Fire, Death, or Life.; Does not resurrect a dead character.; Does not cleanse effects without the listed qualifications.

### FF03-Q · Red Lotus Ash-Cycle Root — Qi Cultivation

**Root Aspect: Red Lotus Ash Cycle**

Nine lotus petals surround a central ash chamber. Qi passes through burning petals, loses contamination, and returns as a hotter, purer current.

**Resource:** Ash Petal (4/6/8)

- **Burn Away the Intrusion (1 Ash Petal; Reaction):** Reduce the triggering damage by twice Proficiency Bonus plus your key ability modifier, or prevent contamination from ending the sustained effect.
- **Rekindle the Cycle (1 Ash Petal; No Action):** Reduce the Qi cost by 2, minimum 1, or increase one damage, purification, or restoration value by three times Proficiency Bonus.
- **Field of Withering Petals (2 Ash Petal; Bonus Action):** Until the start of your next turn, wounded hostile creatures in the area cannot regain Hit Points, while willing allies have advantage on saves against poison, disease, and maximum-Hit-Point reduction.

**Explicit non-grants:** Does not grant Fire, Death, or Life.; Does not negate all healing.; Does not create a permanent area.

### FF03-S · Memorial Red Lotus Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Remains After Loss**

A red lotus grows from the memories of what has ended. Its petals preserve meaning while allowing pain, fear, and imposed despair to burn away.

**Resource:** Memorial Petal (4/6/8)

- **Name What Remains (1 Memorial Petal; Reaction):** Add twice Proficiency Bonus to the roll after it is made but before resolution.
- **Carry Them Through the Ash (1 Memorial Petal; Bonus Action):** The target gains temporary Hit Points equal to twice Proficiency Bonus plus your key ability modifier and advantage on its next covered save before the start of your next turn.
- **Petal Against Oblivion (2 Memorial Petal; No Action):** Preserve recognition and communication until the end of the target’s next turn, or reduce the spiritual damage by four times Proficiency Bonus. If damage is reduced to 0, the target remains at 1 Hit Point instead of becoming unconscious.

**Explicit non-grants:** Does not grant Death, Karma, Dreams, or Life.; Does not resurrect or command the dead.; Does not create a complete Domain.

## FF04 · Divine King Body (Rare)

True sovereignty is strength that bears responsibility without requiring other souls to become lesser.

### FF04-B · Divine King Moon-Sea Body — Body Refining

**Body Aspect: Divine King Moon-Sea**

A moon-sea pattern forms through the bones, blood, and posture. It grants royal physical pressure, immense movement, and the ability to shelter allies beneath the cultivator’s presence.

**Resource:** Royal Tide (3/5/7)

- **Sovereign Refusal (1 Royal Tide; Reaction):** Reduce the damage by three times Proficiency Bonus plus Constitution modifier or reduce forced movement by 20 feet. If the attacker is in range, push it 10 feet.
- **Moon-Sea Impact (1 Royal Tide; No Action):** Deal additional radiant, force, or bludgeoning damage equal to three times Proficiency Bonus and reduce the target’s Speed by 15 feet until the start of your next turn.
- **The King Advances (2 Royal Tide; Bonus Action):** Move up to half your Speed without provoking opportunity attacks. Each chosen ally may move up to 10 feet without provoking opportunity attacks.

**Explicit non-grants:** Does not grant Moon, Water, Warleader, or Protection.; Does not compel obedience.; Does not grant flight or a Domain.

### FF04-Q · Moon-Sea Divine King Root — Qi Cultivation

**Root Aspect: Moon Above the Sovereign Sea**

A silver moon governs a broad dantian sea. Qi gains range, stability, and territorial pressure as it travels through moon-tide meridians.

**Resource:** Moon-Sea Radiance (3/5/7)

- **Tide Beneath the Moon (1 Moon-Sea Radiance; Reaction):** Reduce the damage by twice Proficiency Bonus plus your key ability modifier. If the source is also inside your manifestation, increase the reduction by twice Proficiency Bonus.
- **Royal Current (1 Moon-Sea Radiance; No Action):** Increase one damage, forced-movement, barrier, or temporary-Hit-Point value by three times Proficiency Bonus; a target moved by the action also loses 15 feet of Speed until your next turn.
- **Moon-Sea Court (2 Moon-Sea Radiance; Bonus Action):** Until the start of your next turn, willing creatures have half cover against attacks originating outside the area, and the area is difficult terrain for hostile creatures.

**Explicit non-grants:** Does not grant Moon, Water, Protection, or Warleader.; Does not create a complete Domain.; Does not automatically protect every creature in an area.

### FF04-S · Court Beneath the Moon Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Bears Authority**

The soul sea forms a moonlit court in which every bond and obligation has a named place. The central throne anchors the cultivator’s responsibility without requiring anyone else to bow.

**Resource:** Court Radiance (3/5/7)

- **Refuse the False Throne (1 Court Radiance; Reaction):** Add twice Proficiency Bonus to the save after the roll but before resolution.
- **Name the Court (1 Court Radiance; Bonus Action):** Until the start of your next turn, you know each target’s location while it remains in the Aura, and each gains temporary Hit Points equal to twice Proficiency Bonus.
- **Royal Intercession (2 Court Radiance; No Action):** Reduce the damage by four times Proficiency Bonus or allow the creature to repeat the failed save immediately.

**Explicit non-grants:** Does not grant Warleader, Karma, Protection, or Moon.; Does not compel obedience or reveal ordinary social rank.; Does not create a complete Domain.

## FF05 · Jade Furnace Meridian (Major)

A cultivated vessel becomes precious by identifying impurity, refining what can be integrated, and rejecting what cannot.

### FF05-B · Jade-Furnace Meridian Body — Body Refining

**Body Aspect: Jade Furnace Meridian**

Jade channels encase and reinforce the meridians while the organs act as linked refinement furnaces. The body can withstand hostile substances, purge them, and return their pressure through stronger techniques.

**Resource:** Jade Heat (3/5/7)

- **Jade Furnace Guard (1 Jade Heat; Reaction):** Reduce the damage by three times Proficiency Bonus plus Constitution modifier, or add the same value to the save after rolling but before resolution.
- **Refined Bodily Output (1 Jade Heat; No Action):** Increase one damage, healing, damage-reduction, or forced-movement value by three times Proficiency Bonus. Fire or acid damage added by the action ignores resistance.
- **Purge the Foreign Matter (2 Jade Heat; Bonus Action):** End one qualifying effect that permits a repeated save and gain temporary Hit Points equal to twice Character Level.

**Explicit non-grants:** Does not grant Poison, Disease, Fire, Blacksmithing, or Metal.; Does not make the cultivator immune to all conditions.; Does not cleanse effects lacking the listed qualification.

### FF05-Q · Jade Crucible Meridian Root — Qi Cultivation

**Root Aspect: Jade Crucible**

A faceted jade dantian feeds Qi through protected furnace meridians. Each circulation separates useful essence from poison, disease, corrosion, and spiritual contamination.

**Resource:** Furnace Essence (3/5/7)

- **Seal the Contamination (1 Furnace Essence; Reaction):** Reduce the damage by twice Proficiency Bonus plus your key ability modifier, or prevent contamination from ending the sustained effect.
- **Feed the Jade Crucible (1 Furnace Essence; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, minimum 1.
- **Fourfold Refined Expression (2 Furnace Essence; No Action):** Increase one damage, purification, barrier, or healing value by four times Proficiency Bonus. If it deals damage, choose fire, acid, radiant, or poison; that damage ignores resistance.

**Explicit non-grants:** Does not grant Poison, Disease, Fire, Blacksmithing, Metal, or Radiance.; Does not automatically identify every poison or curse.; Does not provide a Soul Anchor.

**Soul Anchor excluded:** Refinement of substances and Qi does not by itself answer what preserves the self; forcing it would create appetite or purity obsession rather than a stable Anchor.

## FF06 · Empty Bowl (Major)

Emptiness is not failure; need can be acknowledged, filled, or shared without surrendering identity or becoming owned by appetite.

### FF06-Q · Empty Bowl Receiving Root — Qi Cultivation

**Root Aspect: The Empty Bowl That Receives**

The Root forms as a clear bowl within the dantian. It measures depletion precisely, accepts compatible Qi without losing identity, and redistributes reserves where scarcity is most dangerous.

**Resource:** Bowl Measure (3/5/7)

- **Refuse the Devourer (1 Bowl Measure; Reaction):** Reduce involuntary Qi loss by twice Proficiency Bonus, minimum 0, or add twice Proficiency Bonus to the save after rolling but before resolution.
- **Pour From the Bowl (1 Bowl Measure; Bonus Action):** Transfer up to twice Character Level Hit Points or Qi between you and the target; the donor retains at least 1. The recipient has advantage on its next save against drain, hunger, or deprivation.
- **Make Room for Need (2 Bowl Measure; No Action):** Reduce the Qi cost by 2, minimum 1, or increase one healing, reserve-restoration, barrier, or damage-prevention value by three times Proficiency Bonus.

**Explicit non-grants:** Does not grant Hunger, Vitality, Water, or Karma.; Does not steal resources without consent.; Does not create unlimited Qi.

### FF06-S · Shelter of the Empty Bowl Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Can Need Without Being Consumed**

An empty bowl rests at the center of the soul sea. It anchors the cultivator through acknowledged need, chosen interdependence, and the refusal to let hunger define identity.

**Resource:** Empty-Bowl Mark (3/5/7)

- **Name the Need (1 Empty-Bowl Mark; Reaction):** Add twice Proficiency Bonus to the save after rolling but before resolution.
- **Offer Shelter Without Chains (1 Empty-Bowl Mark; Bonus Action):** The target gains temporary Hit Points equal to twice Proficiency Bonus plus your key ability modifier and advantage on its next covered save before your next turn.
- **The Bowl Is Not Empty of Self (2 Empty-Bowl Mark; No Action):** Allow an immediate repeat save, reduce spiritual damage by four times Proficiency Bonus, or leave the target at 1 Hit Point instead of 0 if the triggering effect was devouring or deprivation.

**Explicit non-grants:** Does not grant Hunger, Vitality, Karma, or Dreams.; Does not compel aid or loyalty.; Does not create a complete Domain.

**Body Aspect excluded:** The concept does not inherently transform flesh; forcing a Body Aspect would duplicate hunger physiques or generic endurance.

## FF07 · Moon-Mirror Still-Water (Major)

Stillness is not inaction. A true reflection receives pressure, reveals what is real, and answers at the correct moment.

### FF07-B · Moon-Mirror Still-Water Body — Body Refining

**Body Aspect: Still-Water Reflection Body**

The Tempering Record reforms blood, fascia, joints, and marrow into linked lunar tide channels. The body does not become soft; it learns to distribute force, restore alignment, and move around obstruction like water returning to level.

**Resource:** Mirror Tide (3/5/7)

- **Yield and Return (1 Mirror Tide; Reaction):** Reduce the triggering damage by twice your Proficiency Bonus + your Constitution modifier. After the damage resolves, move 10 feet at Awakened, 15 feet at Refined, or 20 feet at Perfected. This movement does not provoke opportunity attacks.
- **Reflected Force (1 Mirror Tide; No Action):** Deal additional cold or force damage equal to twice your Proficiency Bonus. Push or pull the target 10 feet at Awakened, 15 feet at Refined, or 20 feet at Perfected if it is no more than one size larger than you.
- **Flow Through the Gap (2 Mirror Tide; No Action):** End one grapple or physical restraint imposed by a creature no more than one size larger than you, then move up to 20 feet. During this movement you may pass through the spaces of hostile creatures, but cannot end there.

**Explicit non-grants:** Does not grant Water, Flowing River, Yin, Protection, or Illusion Sphere access.; Does not grant water breathing, flight, a Soul Anchor Aura, or a Domain.; Does not grant another Foundation expression or multi-Path integration.

### FF07-Q · Moon-Mirror Still-Water Root — Qi Cultivation

**Root Aspect: Moonlit Still-Water**

The Root receives Qi through broad intake meridians, settles impurity and turbulence into the lakebed, and releases techniques through a perfectly reflected surface. It favors controlled redirection and patient clarity rather than rigid stagnation.

**Resource:** Clear Reflections (3/5/7)

- **Quiet the Current (1 Clear Reflection; No Action):** Reduce the Qi cost by 1 at Awakened, 2 at Refined, or 3 at Perfected, to a minimum cost of 1.
- **Mirror-Surface Extension (1 Clear Reflection; No Action):** Increase one range by 30 feet or one area dimension by 10 feet. At Perfected, choose both instead of one.
- **Unbroken Reflection (2 Clear Reflections; Reaction):** The effect does not end from that interruption. At Perfected, you may also move the effect's origin or center up to 10 feet if its existing rules allow a movable origin.

**Explicit non-grants:** Does not grant Water, Yin, Illusion, Dreams, or Protection Sphere access.; Does not copy enemy techniques or grant a Soul Anchor Aura or Domain.; Does not grant a Body Aspect, another expression, or multi-Path integration.

### FF07-S · Moon-Mirror Still-Water Soul Anchor — Spirit Awakening

**Anchor Aspect: The Observer Beneath Reflection**

The soul sea becomes a moonlit lake. Memories, emotions, dreams, roles, and spiritual influences appear as reflections across its surface, while the observing self remains beneath them rather than being identical to any single image.

**Resource:** True Reflections (3/5/7)

- **Name the True Image (1 True Reflection; Reaction):** After the roll but before the result, add your Proficiency Bonus to the save.
- **Return From False Reflection (2 True Reflections; No Action):** The target immediately repeats the save and ends the effect on a success.
- **Expose the False Source (2 True Reflections; Reaction):** Until the end of your next turn, the source cannot benefit from invisibility, illusionary duplication, false spiritual identity, or concealed possession against creatures inside your Aura. This does not remove the underlying effect.

**Explicit non-grants:** Does not grant Dreams, Karma, Illusion, Spirit Companions, Yin, or The Hidden Eye Sphere access.; Does not automatically detect ordinary lies, mundane disguises, or every hidden creature.; Does not grant a complete Domain, another Foundation expression, or multi-Path integration.

## FF08 · Heaven Tyrant Body (Legendary)

Sovereignty is proved by meeting pressure without allowing conquest to become another chain.

### FF08-B · Heaven Tyrant Blood Body — Body Refining

**Body Aspect: Heaven Tyrant Blood**

The legacy Heaven Tyrant Body is rebuilt as an inherited or cultivated blood-and-bone constitution. Its power is bodily supremacy under meaningful pressure, not generic command over others.

**Resource:** Tyrant Pulse (4/6/8)

- **Tyrant Form Crush (1 Tyrant Pulse; No Action):** Add damage equal to twice your Proficiency Bonus + your Constitution modifier. Until the start of your next turn, that creature cannot push, pull, knock you Prone, Grapple, or Restrain you unless its effect is higher-Realm, artifact-scale, Secret, or Domain-scale.
- **Imperial Shoulder-Gate (1 Tyrant Pulse; Reaction):** Reduce the damage by three times your Proficiency Bonus + your Constitution modifier, or add that amount to the failed roll and re-evaluate it. At Perfected, use four times PB instead.
- **Tyrant Blood Surge (2 Tyrant Pulse; Bonus Action):** Gain temporary HP equal to twice your Character Level. Until the end of this turn, your next close attack, shove, grapple, or Strength-based physical contest has Advantage and can affect a creature up to two sizes larger than you. At Perfected, the temporary HP becomes three times your Character Level.

**Explicit non-grants:** No Sphere, talent, Method, extra attack, automatic grapple, or social command authority.; No immunity to all forced movement or control.; No second Foundation expression without a Method that explicitly integrates it.

### FF08-Q · Imperial Pressure Tyrant Root — Qi Cultivation

**Root Aspect: Imperial Pressure**

This Root translates the tyrant theme into dantian compression, meridian authority, and stable pressure. It does not harden the body or grant the Heaven Tyrant Blood Body.

**Resource:** Dominion Current (4/6/8)

- **Imperial Current (1 Dominion Current; No Action):** Reduce the Qi cost by 2, to a minimum of 1. At Perfected, reduce it by 3 instead.
- **Crushing Mandate (1 Dominion Current; No Action):** Add force damage equal to twice PB + your Path key ability modifier and reduce the target’s Speed by 15 feet until the start of your next turn. At Perfected, the Speed reduction is 30 feet.
- **Unbroken Imperial Circulation (2 Dominion Current; Reaction):** Prevent that interruption. At Refined, you may also move the effect’s center up to 10 feet if its normal rules allow a movable center.

**Explicit non-grants:** No Body Aspect, physical HP increase, Sphere access, automatic command, or complete Domain.; No universal cost reduction or forced movement beyond printed actions.; No multi-Path integration without an explicit Method.

### FF08-S · Unbowed Sovereign Soul Anchor — Spirit Awakening

**Anchor Aspect: The Unbowed Sovereign**

Spirit Awakening turns the tyrant theme inward: true sovereignty is self-rule, not domination. The soul forms a court in which every bond must be recognized as chosen, contested, or imposed.

**Resource:** Sovereign Mark (4/6/8)

- **Refuse the Kneeling Soul (1 Sovereign Mark; Reaction):** After the roll but before resolution, add your Proficiency Bonus to the save. At Perfected, also grant temporary HP equal to your PB on a success.
- **Sovereign Reconsideration (2 Sovereign Mark; No Action):** The target immediately repeats one save against that effect. On success it may stand or move 10 feet without provoking opportunity attacks.
- **Bear the Crown (1 Sovereign Mark; Bonus Action):** You gain temporary HP equal to your Character Level, and the other target gains half that amount. Until the start of your next turn both have Advantage against fear or forced obedience. At Perfected, both gain the full amount.

**Explicit non-grants:** No mind control, social rank, automatic command, Warleader Sphere, or complete Domain.; No immunity to charm, possession, fear, or identity effects.; No Body or Root expression without a Method that integrates them.

## FF09 · Dragon-Wind Vessel (Legendary)

The sky does not carry the dragon; the cultivated dragon teaches motion to body, Qi, or soul.

### FF09-B · Dragon-Wind Vessel Body — Body Refining

**Body Aspect: Dragon-Wind Vessel**

The original Dragon-Wind Vessel becomes a true inherited Body Aspect. The Ninefold Sky-Marrow Record develops the physique, but the body itself is the supernatural inheritance.

**Resource:** Dragon-Wind Momentum (4/6/8)

- **Gale Drive (1 Dragon-Wind Momentum; No Action):** Move an additional 20 feet without provoking opportunity attacks. At Refined move 30 feet; at Perfected move 45 feet. This movement may include legal wall-running, liquid-running, or air-step movement granted by your current stage.
- **Dragon-Marrow Strike (1 Dragon-Wind Momentum; No Action):** Add damage equal to twice PB + your Constitution modifier and push the target 15 feet if it is no more than two sizes larger than you. At Perfected, add three times PB and push 30 feet.
- **Skycoil Escape (1 Dragon-Wind Momentum; Reaction):** Move 15 feet to a legal space and choose one: impose disadvantage on the triggering opportunity attack; remain standing; reduce a fall by 60 feet; or add twice PB + Dexterity modifier to the triggering escape/control roll. At Refined the movement is 25 feet; at Perfected 40 feet.

**Explicit non-grants:** No Air or Weather Sphere, true flight, dragon breath, full transformation, extra action, or complete immunity to restraint.; No Root circulation or Soul Aura from the Body Aspect alone.; No multi-Path integration without an explicit cultivation Method.

### FF09-Q · Circling Dragon-Wind Root — Qi Cultivation

**Root Aspect: Circling Dragon Wind**

This Root is the Qi expression of the Dragon-Wind family. Its dantian and meridians create rapid, spacious circulation rather than bodily speed.

**Resource:** Skycoil Current (4/6/8)

- **Tailwind Circulation (1 Skycoil Current; No Action):** Reduce the Qi cost by 2, to a minimum of 1. At Perfected, reduce it by 3.
- **Skycoil Extension (1 Skycoil Current; No Action):** Increase range or movement by 15 feet, or one area dimension by 10 feet. At Refined use 30/15 feet; at Perfected 45/20 feet.
- **Dragon-Current Reversal (2 Skycoil Current; Reaction):** Prevent the sustain interruption, or reduce the forced movement by 30 feet and move 10 feet in a chosen legal direction. At Perfected, reduce by 60 feet and move 20 feet.

**Explicit non-grants:** No Body Speed, Air/Weather/Lightning Sphere, flight, automatic trajectory bending, or full Domain.; No universal range increase for unrelated actions.; No Body or Anchor integration without an explicit Method.

### FF09-S · Chosen Horizon Soul Anchor — Spirit Awakening

**Anchor Aspect: The Chosen Horizon**

The Dragon-Wind inheritance becomes inward comprehension rather than elemental wind. The soul sea forms an open horizon where every authentic bond leaves room for chosen motion.

**Resource:** Horizon Scale (4/6/8)

- **Choose the Horizon (1 Horizon Scale; Reaction):** After the roll but before resolution, add your Proficiency Bonus to the save. If it succeeds, the target may move 10 feet without provoking opportunity attacks. At Perfected the movement is 20 feet.
- **Open Path (1 Horizon Scale; Bonus Action):** The target moves up to half its Speed without provoking opportunity attacks and ignores ordinary difficult terrain during that movement. At Perfected it may move up to its full Speed.
- **Return to Chosen Direction (2 Horizon Scale; No Action):** The target repeats one save against that effect. On success, it may stand and move 15 feet without provoking opportunity attacks.

**Explicit non-grants:** No Air or Weather Sphere, flight, automatic escape, command over spirits, or complete Domain.; No immunity to restraint, possession, charm, or forced movement.; No Body or Root expression without Method-gated integration.

## FF10 · Heaven-Devouring Shedding-Womb (Forbidden)

Power may be consumed and remade, but survival requires deciding what becomes fuel, what remains self, and what must be shed.

### FF10-B · Heaven-Devouring Shedding Body — Body Refining

**Body Aspect: Origin-Devouring Shedding Body**

The scripture creates a black internal womb around the organs and marrow. Hostile essence is broken down into Devoured Origin, while damaged tissues are treated as shells that can be discarded and rebuilt.

**Resource:** Devoured Origin (4/6/8)

- **Consume Harm (1 Devoured Origin; Reaction):** Reduce the triggering damage by twice your Proficiency Bonus + Constitution modifier at Awakened, three times PB + Constitution modifier at Refined, or four times PB + Constitution modifier at Perfected.
- **Origin-Fed Strike (1 Devoured Origin; No Action):** Deal additional acid, necrotic, or force damage equal to three times your Proficiency Bonus. At Perfected, this additional damage ignores resistance and treats immunity as resistance.
- **Shed the Wounded Shell (3 Devoured Origin; Bonus Action):** End one listed condition or effect, leave a discarded shell or mass of black residue in your space, and gain temporary Hit Points equal to twice your Character Level + Constitution modifier.

**Explicit non-grants:** Does not grant Hunger, Unmaking, Blood, Death, Void, Life, Daemonic Cultivation, or Qiweaving Sphere access.; Does not grant immortality, automatic resurrection, a Soul Anchor, Aura, or Domain.; Does not grant the Root expression or integration without an explicit multi-Path Method.

### FF10-Q · Heaven-Devouring Shedding-Womb Root — Qi Cultivation

**Root Aspect: Devouring Origin Womb**

The Root surrounds the dantian with layered devouring chambers. Qi enters, is stripped of ownership and impurity, and is either expelled or reborn as Devoured Essence. The Root is powerful because it converts many energies, dangerous because foreign patterns can survive digestion.

**Resource:** Devoured Essence (4/6/8)

- **Feed the Black Womb (1 Devoured Essence; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum cost of 1.
- **Origin Conversion (1 Devoured Essence; No Action):** Convert all damage from the action to acid, necrotic, poison, or force and add twice your Proficiency Bonus to one damage roll. At Refined, the action ignores resistance; at Perfected, it treats immunity as resistance.
- **Shed Foreign Qi (2 Devoured Essence; Reaction):** Reroll the save with advantage and use the new result. On a success, expel visible residue into an adjacent space; the residue has no independent effect unless the source says otherwise.

**Explicit non-grants:** Does not grant Hunger, Unmaking, Blood, Death, Void, Life, Daemonic Cultivation, Poison, or Qiweaving Sphere access.; Does not steal techniques, memories, identities, or cultivation levels without a separate explicit rule.; Does not grant the Body Aspect, Soul Anchor, Aura, Domain, or multi-Path integration.

**Soul Anchor excluded:** Endless consumption and shedding do not answer what preserves the self; using appetite as the Anchor would replace identity with hunger rather than stabilize self-realization.

## FF11 · Nine-Bitter Heartfire (Major)

Learn from failure without worshiping it; keep the lesson, burn away the false identity, and do not court the wound.

### FF11-B · Nine-Scar Heartfire Body — Body Refining

**Body Aspect: Nine-Scar Heartfire**

The Body Aspect is a scar-learning physique. Every genuine hardship can temper a new response, but self-harm and deliberate failure produce only ash and deviation.

**Resource:** Bitter Coal (3/4/5)

- **Bitter-Heart Recovery (1 Bitter Coal; No Action):** Gain temporary HP equal to twice PB + your Constitution modifier and move 10 feet without provoking opportunity attacks. At Perfected, gain temporary HP equal to your Character Level + twice PB and move 20 feet.
- **Scar-Answering Strike (1 Bitter Coal; No Action):** Add fire or psychic damage equal to twice PB + your Constitution modifier. The target cannot gain Advantage against you from the same condition or damage source until the start of your next turn. At Perfected, add three times PB instead.
- **Refuse the Ninth Bitter (2 Bitter Coal; Reaction):** Add twice PB + your Constitution modifier to the failed save and re-evaluate it; or, if damage would reduce you to 0 HP, reduce that damage by three times PB + your Constitution modifier. At Perfected use three times PB on the save or four times PB on damage reduction.

**Explicit non-grants:** No automatic adaptation to every source, immunity through repeated damage, Fire/Blood Sphere, or benefit from self-harm.; No extra action or unconditional revival at 0 HP.; No Root or Anchor expression without Method-gated integration.

### FF11-Q · Nine-Bitter Heartfire Root — Qi Cultivation

**Root Aspect: Bitter Heartfire Refinement**

The Root transforms the heartfire principle into diagnostic circulation. Its nine ember chambers record real hostile resistance and convert lessons into efficiency, precision, purification, or recovery.

**Resource:** Ember Lesson (3/4/5)

- **Refine the Failed Expression (1 Ember Lesson; No Action):** Reduce the Qi cost by 1, to a minimum of 1, and add PB to one attack roll, save DC, flat damage value, healing value, or movement value of the action. At Perfected add twice PB instead.
- **Burn Out the Impurity (1 Ember Lesson; Action):** Make the appropriate cultivation check against the source DC. Add PB to the check. On success, suppress one listed impurity for 1 scene or remove it if the underlying effect permits removal by cultivation. At Perfected, treat a success by 5 or more as a full removal when the effect is not artifact-, Secret-, Domain-, or higher-authority scale.
- **Return From Counterflow (2 Ember Lesson; Reaction):** Recover Qi equal to twice PB, up to the amount spent on the triggering action, and move 10 feet without provoking opportunity attacks. At Perfected recover three times PB and move 20 feet.

**Explicit non-grants:** No automatic knowledge of exact enemy statistics, universal adaptation, guaranteed hit, Fire/Radiance Sphere, or benefit from deliberate failure.; No free removal of artifact-, Secret-, Domain-, or higher-authority effects.; No Body or Anchor integration without an explicit Method.

### FF11-S · Nine-Bitter Heartfire Soul Anchor — Spirit Awakening

**Anchor Aspect: I Learn Without Becoming the Wound**

The Anchor is not a soul that seeks suffering. It is the realized ability to recognize a wound, keep the true lesson, and refuse revenge, shame, or trauma as permanent identity.

**Resource:** True Lesson (3/4/5)

- **Name the Lesson (1 True Lesson; Reaction):** After the failed roll, the target adds PB to the result and re-evaluates it. Whether it succeeds or fails, it learns the category of pressure involved: fear, desire, identity, memory, guilt, command, or foreign Resonance.
- **Do Not Become the Wound (1 True Lesson; No Action):** The target gains temporary HP equal to twice PB + your Path key ability modifier and may end the Frightened condition or stand from Prone. At Perfected, it may instead move 15 feet without provoking opportunity attacks.
- **Return From the Bitter Dream (2 True Lesson; No Action):** The target repeats one save against the effect. On success, it immediately gains the benefit of Do Not Become the Wound without another resource cost.

**Explicit non-grants:** No immunity to trauma, charm, fear, possession, or memory effects.; No exact enemy statistics, forced forgiveness, automatic healing of every wound, Fire Sphere, or complete Domain.; No Body or Root expression without Method-gated integration.

## FF12 · Heavenly Body (Legendary)

The body or Root becomes a vessel Heaven recognizes as worthy of higher law, but purity must preserve lawful difference rather than erase it.

### FF12-B · Heaven-Recognized Jade-Gold Body — Body Refining

**Body Aspect: Heaven-Recognized Jade-Gold Vessel**

The Heavenly Body is rebuilt as a true legendary constitution centered on purity, organ resilience, life-force stability, and rejection of corrupt transformation. It is powerful without becoming universal immunity.

**Resource:** Heavenly Integrity (4/6/8)

- **Heavenly Rejection (1 Heavenly Integrity; Reaction):** Reduce the damage by three times PB + your Constitution modifier, or add that amount to the failed save and re-evaluate it. At Perfected use four times PB.
- **Heavenly Vessel Strike (1 Heavenly Integrity; No Action):** Add radiant or force damage equal to twice PB + your Constitution modifier. Against an undead, corrupted, diseased, poisoned, or transformed target, add one additional PB. At Perfected, all values gain one additional PB and the added damage ignores resistance.
- **Vessel Restoration (2 Heavenly Integrity; Bonus Action):** Gain temporary HP equal to twice your Character Level and immediately repeat one save against poison, disease, corruption, bodily transformation, or life-drain. At Perfected, gain three times your Character Level temporary HP.

**Explicit non-grants:** No Radiance, Yang, Life, Protection, Guardian, Weather, or Sword Sphere.; No universal immunity, immortality, automatic regeneration, moral authority, or complete purification of every effect.; No Root expression or combined Body–Root structure without an explicit Method.

### FF12-Q · Heavenly Jade Meridian Root — Qi Cultivation

**Root Aspect: Heavenly Jade Clarity**

The Qi expression of the Heavenly Body is a Root of purity, compatibility, and higher-law capacity. It changes how Qi enters, is examined, refined, and protected rather than duplicating bodily durability.

**Resource:** Celestial Clarity (4/6/8)

- **Clarify the Current (1 Celestial Clarity; No Action):** Reduce the Qi cost by 2, to a minimum of 1. At Perfected, reduce it by 3.
- **Heavenly-Law Expression (1 Celestial Clarity; No Action):** Add twice PB + your Path key ability modifier to one damage, healing, temporary HP, or barrier value; or add PB to the cultivation check made to remove contamination. At Perfected, use three times PB for the flat value or twice PB for the check.
- **Return to Pure Circulation (2 Celestial Clarity; Reaction):** Prevent ordinary corruption or conversion and maintain the effect; or recover Qi equal to twice PB, up to the amount spent, if the action was countered or dispelled. At Perfected recover three times PB.

**Explicit non-grants:** No Heavenly Body HP, physical resistances, Sphere access, universal dispelling, immortality, or complete Domain.; No free removal of effects requiring rare antidotes or story procedures.; No Body–Root integration without a cultivation Method that explicitly combines them.

**Soul Anchor excluded:** External heavenly recognition and structural purity do not inherently answer what preserves the self; a purity- or law-based Soul Anchor would require a separate comprehension family.

## FF13 · Innate Sacred Body Dao Embryo (Legendary)

When body and Dao share one beginning, hostile authority must prove it has the right to move or define the cultivated structure.

### FF13-B · Innate Sacred Dao Body — Body Refining

**Body Aspect: Innate Sacred Dao Body**

This is the physical half of the legacy body–Dao family. The body is not merely strong; it is structurally capable of receiving compatible Dao expression and resisting hostile authority. Full union with the Root requires an explicit Method.

**Resource:** Origin Bell Tone (4/6/8)

- **No-Beginning Guard (1 Origin Bell Tone; Reaction):** Reduce the damage by three times PB + your Constitution modifier, or add that amount to the failed roll and re-evaluate it. At Perfected use four times PB.
- **Sacred-Dao Strike (1 Origin Bell Tone; No Action):** Add force, radiant, or bludgeoning damage equal to twice PB + your Constitution modifier. Until the start of your next turn, that target cannot push, pull, teleport, knock you Prone, Grapple, Restrain, or body-suppress you unless its effect is higher-Realm, artifact-scale, Secret, or Domain-scale. At Perfected add three times PB instead.
- **Origin Bell Surge (2 Origin Bell Tone; Bonus Action):** Gain temporary HP equal to twice your Character Level. Until the end of this turn, your next close attack, Strength or Constitution resistance roll, or legal Foundation-aligned technique roll has Advantage and adds PB to one damage, movement, barrier, or healing value. At Perfected, temporary HP becomes three times Character Level and the added value becomes twice PB.

**Explicit non-grants:** No Sphere, Dao comprehension, Cultivation Root, automatic Concentration, extra action, teleportation, timeline reversal, or complete Domain.; No universal saving throw advantage or immunity to authority.; Full Body–Root unity requires a cultivation Method that explicitly integrates both expressions.

### FF13-Q · Innate Dao Embryo Root — Qi Cultivation

**Root Aspect: Innate Dao Embryo**

The Root expression is not a generic all-Sphere affinity. It selects one known Sphere at Awakened, a second at Refined, and a third at Perfected, then supports only legal Methods and actions that cultivate those relationships.

**Resource:** Origin Resonance (4/6/8)

- **Embryo Alignment (1 Origin Resonance; No Action):** Reduce the Qi cost by 2, to a minimum of 1. At Perfected, reduce it by 3.
- **Dao-Bell Amplification (1 Origin Resonance; No Action):** Add twice PB + your Path key ability modifier to one damage, healing, temporary HP, or barrier value; increase movement or range by 15 feet; or increase one area dimension by 10 feet. At Perfected use three times PB or 30/15 feet.
- **Return to Origin (2 Origin Resonance; Reaction):** Prevent ordinary interruption and maintain the effect, or recover Qi equal to twice PB up to the action’s cost if it was countered or ended. At Perfected recover three times PB.

**Explicit non-grants:** No free Sphere, talent, Method, composite, Dao comprehension, Domain, or universal affinity.; No physical Sacred Dao Body benefits from the Root alone.; Full Body–Root integration requires a cultivation Method explicitly capable of combining both expressions.

**Soul Anchor excluded:** Body–Dao receptivity and shared origin do not inherently define the self; a Soul Anchor requires a separate comprehension principle rather than another authority package.

## FF14 · White Crane Cloud-Step (Major)

Move toward what matters with enough lightness to cross danger, but not so lightly that pain and duty are abandoned.

### FF14-B · White Crane Cloud-Body — Body Refining

**Body Aspect: White Crane Cloud-Body**

A true lightness Body Aspect cultivated through crane posture, open-air breath, hollow-bone tempering, and precise tendon control. The body becomes fast, balanced, and difficult to pin without gaining flight for free.

**Resource:** Crane Breath (3/5/7)

- **Cloud-Step Crossing (1 Crane Breath; No Action):** Move 15 feet at Awakened, 25 feet at Refined, or 35 feet at Perfected. This movement does not provoke Opportunity Attacks and may include standing from Prone without additional movement.
- **White-Wing Deflection (1 Crane Breath; Reaction):** Increase AC against the triggering attack by your Proficiency Bonus + Constitution modifier. If the attack misses, move up to half your Speed without provoking Opportunity Attacks from the attacker.
- **Crane-Wing Cut (2 Crane Breath; No Action):** Add damage equal to three times your Proficiency Bonus and move up to 15 feet after the hit without provoking Opportunity Attacks from that target. At Perfected, the extra damage ignores resistance to the attack’s physical damage type.

**Explicit non-grants:** No Air Sphere, flight, teleportation, free Disengage, or immunity to Grappled, Restrained, or Prone.; No Qi Root or Soul Anchor expression without an authorized Method.

### FF14-Q · White-Cloud Circulation Root — Qi Cultivation

**Root Aspect: Open-Cloud Circulation**

A lightness Root built around an open dantian, paired lung meridians, and looping cloud channels. It supports mobile Qi, curved trajectories, and sustained techniques without turning the body itself into a crane physique.

**Resource:** Cloud Current (3/5/7)

- **Lighten the Circulation (1 Cloud Current; No Action):** Reduce the Qi cost by 1 at Awakened, 2 at Refined, or 3 at Perfected, to a minimum of 1.
- **Carry the Current (1 Cloud Current; No Action):** Increase that movement by 10 feet at Awakened, 20 feet at Refined, or 30 feet at Perfected. Alternatively, increase the action’s range by twice that amount.
- **Unbroken Cloud Breath (2 Cloud Current; Reaction):** Prevent that interruption. At Perfected, you may also move 15 feet without provoking Opportunity Attacks after the triggering event resolves.

**Explicit non-grants:** No Air Sphere, physical Speed increase, flight, or permission to ignore targeting and cover.; No Body Aspect or Soul Anchor without an authorized Method.

### FF14-S · Crane That Flies Into the Storm Soul Anchor — Spirit Awakening

**Anchor Aspect: The Direction I Choose Despite Pain**

A Soul Anchor of deliberate approach. The awakened self is not defined by never being trapped or hurt; it is defined by choosing a direction and continuing toward it. That realization first marks the Aura, then creates room for others to move, and finally seeds a Domain of purposeful passage.

**Resource:** Skyward Resolve (3/5/7)

- **Face the Wind (1 Skyward Resolve; Reaction):** Add your Proficiency Bonus to the save after the roll but before the outcome is resolved.
- **Step Toward What Matters (1 Skyward Resolve; No Action):** The creature may move 10 feet at Awakened, 20 feet at Refined, or 30 feet at Perfected without provoking Opportunity Attacks. It must move toward a declared objective, protected creature, or source of danger.
- **Return to the Chosen Course (2 Skyward Resolve; No Action):** The target repeats one save against the effect. On a success, it may also stand and move 10 feet.

**Explicit non-grants:** No Air Sphere, flight, automatic escape, immunity to control, or complete Domain.; No Body Aspect or Cultivation Root without an authorized Method.

## FF15 · True Blackblood Physique (Major)

What was meant to halt, shame, or define the cultivator becomes a governed inheritance rather than a master.

### FF15-B · True Blackblood Physique — Body Refining

**Body Aspect: Self-Owned Blackblood**

A dark bloodline Body Aspect whose blood is not impure in the ordinary sense; it is a second physiological engine. It metabolizes poison, Yin pressure, and hostile contamination, but becomes dangerous when hoarded without discrimination.

**Resource:** Blackblood Pressure (4/6/8)

- **Blackblood Guard (1 Blackblood Pressure; Reaction):** Reduce the damage by twice your Proficiency Bonus + Constitution modifier at Awakened, three times PB + Constitution modifier at Refined, or four times PB + Constitution modifier at Perfected. This reduction applies after resistance.
- **Venom-Dark Return (1 Blackblood Pressure; No Action):** Deal additional poison or necrotic damage equal to three times your Proficiency Bonus. At Refined, the extra damage ignores resistance; at Perfected, immunity is treated as resistance.
- **Blackblood Refusal (3 Blackblood Pressure; Reaction):** You are reduced to 1 HP instead and gain temporary HP equal to twice your Character Level. At Perfected, also end one poison or necrotic ongoing effect currently affecting you.

**Explicit non-grants:** No Blood, Poison, Yin, Dark, Life, or Hunger Sphere.; No immunity to all poison, disease, corruption, death, or blood control.; No Root or Anchor expression without an authorized Method.

### FF15-Q · Blackblood Cauldron Root — Qi Cultivation

**Root Aspect: Blackblood Cauldron**

A dark refining Root whose dantian contains a blackblood cauldron surrounded by filtering meridians. It excels at metabolizing dangerous Qi without pretending every impurity is useful.

**Resource:** Refined Dregs (4/6/8)

- **Feed the Black Cauldron (1 Refined Dregs; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Blackblood Conversion (1 Refined Dregs; No Action):** Convert the action’s damage to poison or necrotic. It ignores resistance at Refined; at Perfected immunity is treated as resistance.
- **Refuse the Foreign Blood (2 Refined Dregs; Reaction):** Reduce damage by three times PB + your Path key ability modifier and add PB to the triggering save. If the effect fails, identify whether it was poison, disease, foreign Qi, blood control, or another corruption category.

**Explicit non-grants:** No Blood, Poison, Yin, Dark, Life, or Hunger Sphere.; No ability to consume every curse, poison, or hostile technique.; No Body Aspect or Soul Anchor without an authorized Method.

### FF15-S · Self Beneath the Blackblood Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Owns the Mark**

A Soul Anchor for those marked by feared bloodlines, spiritual contamination, or inherited hunger. It does not cleanse the mark away; it establishes the self that chooses how the mark is expressed.

**Resource:** Black Oaths (3/5/7)

- **Name the Self Beneath It (1 Black Oath; Reaction):** Add your Proficiency Bonus to the save after the roll but before resolution.
- **Reject the Inherited Master (1 Black Oath; No Action):** The creature ends one minor command, emotional rider, or movement restriction created by the same effect. If the effect has no divisible rider, gain temporary HP equal to twice your Proficiency Bonus instead.
- **Return the Owned Name (2 Black Oaths; No Action):** Repeat one save against the effect. On a success, the target also knows which part of its current impulse came from the hostile influence.

**Explicit non-grants:** No Blood, Poison, Dark, Yin, or Karma Sphere.; No immunity to corruption, possession, bloodline influence, or shame.; No Body Aspect or Cultivation Root without an authorized Method.

## FF16 · Golden Mandate Seal (Rare)

Command becomes cultivation only when authority is visible, responsibility is borne, and those protected are not reduced to subjects.

### FF16-B · Golden Banner Mandate Body — Body Refining

**Body Aspect: Golden Banner Mandate Body**

A Body Aspect for banner bearers, commanders, guardians, and sovereign lineages. The body becomes physically difficult to displace and can carry protective authority through position, voice, and visible action.

**Resource:** Command Bearing (3/5/7)

- **Banner Interposition (1 Command Bearing; Reaction):** Move up to 15 feet at Awakened, 25 feet at Refined, or 35 feet at Perfected without provoking Opportunity Attacks, ending adjacent to the ally if possible. Reduce the triggering damage by twice PB + Constitution modifier.
- **Imperial Advance (1 Command Bearing; No Action):** You and the ally may each move 10 feet at Awakened, 15 feet at Refined, or 20 feet at Perfected without provoking Opportunity Attacks from the triggering target. The target may also be pushed 10 feet if no more than one size larger than you.
- **Unbroken Standard (2 Command Bearing; Reaction):** Choose one: negate Prone and up to 30 feet of forced movement; add PB to the triggering save and repeat it if it failed; or, if reduced to 0 HP, remain at 1 HP and gain temporary HP equal to your Character Level.

**Explicit non-grants:** No Warleader, Protection, Guardian, Shield, Spear, or Formation Sphere.; No authority over unwilling creatures or immunity to control.; No Root or Anchor expression without an authorized Method.

### FF16-Q · Golden Writ Seal Root — Qi Cultivation

**Root Aspect: Golden Writ Mandate**

A Root built around a central mandate seal, eight writ meridians, and a circulation that grows stable when instructions, formations, and protections are explicit. It supports authority-shaped Qi without creating a separate law system.

**Resource:** Edict Seals (4/6/8)

- **Seal the Expenditure (1 Edict Seal; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Extend the Golden Writ (1 Edict Seal; No Action):** Increase range by 30/60/90 feet by stage, or increase one area dimension by 10/15/20 feet by stage.
- **Seal of Final Authority (2 Edict Seals; No Action):** The creature rolls the save with Disadvantage. If it succeeds anyway, one willing ally affected by or adjacent to the action gains temporary HP equal to twice your Proficiency Bonus.

**Explicit non-grants:** No Warleader, Protection, Formation, Chains, Guardian, or Strategy Sphere.; No universal law, command immunity, or control over unwilling creatures.; No Body Aspect or Soul Anchor without an authorized Method.

### FF16-S · Mandate of Responsible Rule Soul Anchor — Spirit Awakening

**Anchor Aspect: Authority Bears Its Consequence**

A Soul Anchor of legitimate authority rather than domination. Its spirit palace resembles a court whose central seat remains empty until the cultivator earns the right to speak for a particular responsibility.

**Resource:** Legitimate Edicts (3/5/7)

- **Appeal to Legitimate Mandate (1 Legitimate Edict; Reaction):** Add your Proficiency Bonus to the save after the roll but before resolution.
- **Form the Willing Court (1 Legitimate Edict; No Action):** The ally may move 10 feet at Awakened, 15 feet at Refined, or 20 feet at Perfected without provoking Opportunity Attacks and gains temporary HP equal to twice your Proficiency Bonus.
- **Rebuke the False Throne (2 Legitimate Edicts; No Action):** Repeat one save against the effect. On a success, the target also identifies the direction or visible sign from which the authority is being imposed, if perceptible.

**Explicit non-grants:** No Karma, Protection, Warleader, Strategy, or Spirit Companions Sphere.; No power to determine universal legitimacy or compel obedience.; No Body Aspect or Cultivation Root without an authorized Method.

## FF17 · Sword Bones (Major)

The cultivated edge is valuable only when the body or Root knows exactly what must be cut and what must remain whole.

### FF17-B · Sword-Bone Physique — Body Refining

**Body Aspect: Sword-Bone Frame**

A Body Aspect that tempers the skeleton into sword-like support and the marrow into a source of directed edge pressure. It does not merely make attacks sharper; the entire body learns when to draw, redirect, and sheath force.

**Resource:** Severance Edge (4/6/8)

- **Sword-Bone Cut (1 Severance Edge; No Action):** Add damage equal to three times your Proficiency Bonus. At Refined, the extra damage ignores resistance to slashing, piercing, and bludgeoning. At Perfected, immunity to those damage types is treated as resistance for this extra damage.
- **Bone-Sheath Guard (1 Severance Edge; Reaction):** Reduce damage by twice PB + Constitution modifier at Awakened, three times PB + Constitution modifier at Refined, or four times PB + Constitution modifier at Perfected. If reduced to 0, you may move 5 feet without provoking Opportunity Attacks.
- **Sever the Binding Line (2 Severance Edge; No Action):** Make a weapon, unarmed, or Body Refining attack against the effect’s printed AC, DC, or an AC equal to 10 + the source’s PB or equivalent. On success, end the Grappled or Restrained condition on yourself, or create a 5-foot opening in the physical structure.

**Explicit non-grants:** No Sword, Metal, Weapons, Pressure Points, or Spear Sphere.; No ability to sever concepts, complete Domains, or every condition.; No Cultivation Root or Soul Anchor without an authorized Method.

### FF17-Q · Sheathed Sword Meridian Root — Qi Cultivation

**Root Aspect: Sheathed Severance**

A Sword Root with a narrow central dantian, marrow-linked meridians, and a sheath chamber that compresses Qi before release. It favors exact cuts, lines, pressure points, and weapon conduction rather than indiscriminate destruction.

**Resource:** Sword Intent (4/6/8)

- **Draw From the Sheath (1 Sword Intent; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Extend the Invisible Edge (1 Sword Intent; No Action):** Increase range by 30/60/90 feet by stage, or increase a line’s length by 15/30/45 feet and width by 5 feet.
- **Cut the Sustaining Thread (2 Sword Intent; Reaction):** Make a Path-key ability check adding PB against DC 10 + the source’s PB or equivalent. On success, suppress the effect until the start of the source’s next turn. At Perfected, if the effect is below your active Realm and has no higher-authority protection, end it instead.

**Explicit non-grants:** No Sword, Metal, Weapons, Pressure Points, Spear, or Qiweaving Sphere.; No universal dispel, conceptual severance, or ability to end complete Domains.; No Body Aspect or Soul Anchor without an authorized Method.

**Soul Anchor excluded:** The catalog already contains Seven-Star Sword Heart as the dedicated sword-comprehension and Soul Anchor family; adding a Sword Bones Anchor would duplicate that identity rather than express this body-and-meridian concept cleanly.

## FF18 · Taiyin Lunar Body (Rare)

Taiyin preserves what should endure through danger and loss, but becomes a tomb when preservation refuses all warmth and change.

### FF18-B · Taiyin Moon-Preservation Body — Body Refining

**Body Aspect: Taiyin Moon-Preservation Body**

A Rare Body Aspect in which Taiyin cold slows damage, drain, poison, and decay while preserving the body’s essential vitality. It is not a generic ice body; its defining purpose is preservation.

**Resource:** Lunar Yin Dew (4/6/8)

- **Moon-Cold Guard (1 Lunar Yin Dew; Reaction):** Reduce the damage by twice PB + Constitution modifier at Awakened, three times PB + Constitution modifier at Refined, or four times PB + Constitution modifier at Perfected. Against cold, necrotic, poison, life-drain, corpse-qi, or hostile Yin damage, add your Character Level to the reduction.
- **Taiyin Stilling Touch (1 Lunar Yin Dew; No Action):** Deal additional cold or necrotic damage equal to three times PB and reduce the target’s Speed by 15 feet at Awakened, 25 feet at Refined, or 35 feet at Perfected until the start of your next turn. At Perfected, the extra damage ignores resistance.
- **Preserving Moon Breath (2 Lunar Yin Dew; Bonus Action):** The target gains temporary HP equal to twice your Character Level and may immediately repeat one save against poison, disease, life-drain, corpse-qi, cold paralysis, or an anti-healing effect. At Perfected, if the target is at 0 HP, it first becomes stable.

**Explicit non-grants:** No Yin, Ice, Water, Life, Protection, or Dark Sphere.; No immunity to all cold, necrotic damage, death, poison, drain, or decay.; No Cultivation Root or Soul Anchor without an authorized Method.

### FF18-Q · True Moon Yin Root — Qi Cultivation

**Root Aspect: True Moon Preservation**

A Rare Qi Root with a deep moon-well dantian and paired Yin-return meridians. It favors preservation, controlled cold, night-water, corpse-qi resistance, and techniques that slow destructive processes without freezing all change.

**Resource:** Moonwell Essence (4/6/8)

- **Draw From the Moon Well (1 Moonwell Essence; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Deepen the Lunar Stillness (1 Moonwell Essence; No Action):** Choose one: increase range by 30/60/90 feet by stage; increase one area dimension by 10/15/20 feet; add three times PB to damage reduction or temporary HP; or increase Speed reduction by 10/20/30 feet.
- **Preserve the Returning Current (2 Moonwell Essence; Reaction):** Prevent that interruption. If the trigger involved hostile drain or anti-healing, also reduce the triggering damage or resource loss by three times PB + your Path key ability modifier.

**Explicit non-grants:** No Yin, Ice, Water, Life, Protection, or Dark Sphere.; No free healing, resurrection, immunity to drain, or unrestricted cold conversion.; No Body Aspect or Soul Anchor without an authorized Method.

### FF18-S · Moon That Preserves the Self Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self Preserved Through Change**

A Soul Anchor whose spirit palace contains a moon reflected in a deep inner well. It preserves identity, memory, and spiritual continuity against death pressure, drain, numbness, and corpse-like stillness while accepting that living selves must still change.

**Resource:** Moon Reflections (3/5/7)

- **Remember the Moon Within (1 Moon Reflection; Reaction):** Add your Proficiency Bonus to the save after the roll but before resolution.
- **Preserve the Living Name (1 Moon Reflection; Reaction):** Choose one: turn the failed death save into a success; reduce maximum-HP loss by twice your Character Level; or preserve a clear spiritual impression of the threatened memory or identity element so it can be recognized during later repair.
- **Return the Lost Reflection (2 Moon Reflections; No Action):** Repeat one save against the effect. On a success, recover one immediately accessible memory or emotional connection suppressed by that effect, as adjudicated by its printed scope.

**Explicit non-grants:** No Dreams, Karma, Life, Spirit Companions, Yin, Ice, or Water Sphere.; No resurrection, immortality, perfect memory, or immunity to death and possession.; No Body Aspect or Cultivation Root without an authorized Method.

## FF19 · Karma Knot (Major)

A consequence has power only when its cause, bearer, and answer are genuinely connected.

### FF19-Q · Red-Knot Karma Root — Qi Cultivation

**Root Aspect: Red-Knot Consequence**

A Cultivation Root whose meridians perceive genuine causal obligations and circulate Qi through linked knots. It does not control fate freely; it becomes strongest when answering a real consequence that has already been created.

**Resource:** Karmic Due (3/5/7)

- **Settle the Circulation (1 Karmic Due; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Knot Judgment (1 Karmic Due; No Action):** Add force, psychic, or the triggering action’s damage equal to 3×PB. At Refined, the target also cannot take Reactions until the start of its next turn. At Perfected, the extra damage ignores resistance.
- **Red-Cord Recompense (2 Karmic Due; Reaction):** Reduce the damage by 2×PB + your Path key ability modifier at Awakened, 3×PB + the modifier at Refined, or 4×PB + the modifier at Perfected. The source becomes visibly tied by a red cord until the end of your next turn.

**Explicit non-grants:** No Karma, Fate, Chains, Thread, Guardian, Retribution, Protection, or Ink Sphere.; No universal knowledge of guilt, intent, destiny, or hidden contract terms.; No Body Aspect or Soul Anchor without a Method that explicitly integrates expressions.

### FF19-S · Knot of Accepted Consequence Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Accepts Its Due**

A Soul Anchor founded on the realization that identity includes the consequences of chosen actions. It distinguishes genuine responsibility from imposed guilt, false contracts, and spiritual coercion.

**Resource:** Witness Marks (3/5/7)

- **Witness the True Burden (1 Witness Mark; Reaction):** After the roll but before resolution, add PB at Awakened, PB + 2 at Refined, or 2×PB at Perfected to the save.
- **Share the Accepted Due (1 Witness Mark; Reaction):** Reduce the triggering damage by 2×PB + your Spirit key ability modifier, or shorten a qualifying condition with a duration measured in rounds by 1 round. You take psychic damage equal to PB that cannot be reduced by this Foundation.
- **Reveal the Binding Terms (2 Witness Marks; No Action):** Learn its immediate command or consequence, the creature currently bearing it, and one clear method by which it can be resisted, fulfilled, transferred, or broken if such a method exists. At Perfected, the target also gains advantage on its next save against that effect before the end of its next turn.

**Explicit non-grants:** No Karma, Fate, Dreams, Chains, Protection, or Spirit Companions Sphere.; No universal truth detection, legal judgment, guilt determination, or complete contract reading.; No Cultivation Root or Body Aspect without an authorized Method.

**Body Aspect excluded:** The family is fundamentally causal, contractual, and identity-oriented; a physical Karma body would be a separate inherited physique rather than a clean expression of this Root-and-Anchor family.

## FF20 · Verdant Returning-Spring (Major)

Renewal is not reversal; life returns by changing around what was truly lost.

### FF20-B · Returning-Spring Verdant Body — Body Refining

**Body Aspect: Returning-Spring Physique**

A Body Aspect that transforms the body into a living cycle of growth, shedding, and renewal. It is not passive immortality; it stores Spring Vitality through real injury, recovery, and protection, then spends that vitality on strong but finite restoration.

**Resource:** Spring Vitality (4/6/8)

- **Returning-Spring Flesh (1 Spring Vitality; Bonus Action):** Regain HP equal to 2×PB + Constitution modifier at Awakened, 3×PB + Constitution modifier at Refined, or 4×PB + Constitution modifier at Perfected.
- **Verdant Renewal Guard (1 Spring Vitality; Reaction):** Reduce damage by 2×PB + Constitution modifier, or add PB to the failed save and repeat its resolution. At Refined, damage reduction becomes 3×PB + modifier; at Perfected, 4×PB + modifier.
- **Shed the Withered Layer (2 Spring Vitality; No Action):** End Grappled, Prone, or one non-Domain physical restraint; or repeat a save against Poisoned or another listed save-ends effect with advantage. At Perfected, also restore a temporary maximum-HP reduction equal to 2×PB.

**Explicit non-grants:** No Life, Verdant Growth, Medicine, Water, Flowing River, Plants, or Wood Sphere.; No immortality, automatic resurrection, or repair of Foundation injuries through ordinary healing.; No Root or Soul Anchor without an authorized Method.

### FF20-Q · Returning-Spring Verdant Root — Qi Cultivation

**Root Aspect: Verdant Returning Spring**

A Cultivation Root formed around a spring dantian, branching verdant meridians, and a purification basin. It favors Life, Verdant Growth, Medicine, Water, and recovery techniques without granting any Sphere.

**Resource:** Spring Dew (4/6/8)

- **Dew Returns to the Root (1 Spring Dew; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Verdant Mercy Bloom (1 Spring Dew; No Action):** Increase one healing, temporary-HP, or damage-reduction value by 2×PB + your Path key ability modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. If the target is at 0 HP and the effect restores HP, it may stand without spending movement.
- **Purifying Spring Pulse (2 Spring Dew; Action):** The target repeats a save against poison, disease, charm, fear, rot, withering, or a save-ends corruption effect with advantage. On success, it also regains HP equal to 2×PB. At Perfected, range becomes 120 feet and the healing becomes 3×PB.

**Explicit non-grants:** No Life, Verdant Growth, Medicine, Water, Flowing River, Plants, Wood, or Alchemy Sphere.; No automatic cure of curses, Foundation injuries, or permanent conditions.; No Body Aspect or Soul Anchor without an authorized Method.

### FF20-S · Self That Blooms Again Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Blooms Again**

A Soul Anchor based on inward comprehension of renewal. It protects spirits and identities from despair, spiritual withering, and the belief that damage makes restoration meaningless.

**Resource:** Renewal Seeds (4/6/8)

- **Seed of Return (1 Renewal Seed; Reaction):** Add PB to the roll after it is made but before resolution. At Perfected, if the save succeeds, the creature also regains HP or Resonance equal to PB, choosing the resource it possesses.
- **Bloom After Harm (1 Renewal Seed; No Action):** The target gains temporary HP equal to 2×PB + your Spirit key ability modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected, and may stand without spending movement.
- **Call the Spirit Back to Spring (2 Renewal Seeds; Action):** The target repeats one relevant save with advantage. If no repeat save exists but the effect allows spiritual stabilization, stabilize it until the end of its next turn and let it recognize its identity and willing bonds.

**Explicit non-grants:** No Life, Dreams, Karma, Spirit Companions, Verdant Growth, or Medicine Sphere.; No resurrection, forced reconciliation, complete memory restoration, or automatic control of spirits.; No Body Aspect or Root without an authorized Method.

## FF21 · Seven-Star Sword-Heart (Major)

The true sword is the decision that aligns perception, purpose, mercy, consequence, and the chosen line.

### FF21-Q · Seven-Star Sword Root — Qi Cultivation

**Root Aspect: Seven-Star Alignment**

A Cultivation Root that combines star alignment with sword precision. Seven nodes govern Qi circulation by measuring angle, timing, distance, pressure, intent, target, and return. It favors exact weapon and star techniques without granting either Sphere.

**Resource:** Star Intent (4/6/8)

- **Seven-Star Correction (1 Star Intent; No Action):** Add PB + your Path key ability modifier to the attack roll. If this changes the miss into a hit, add damage equal to 2×PB.
- **Draw the Stellar Sword-Line (1 Star Intent; No Action):** Increase range by 30/60/90 feet by stage, or increase a line by 15/30/45 feet. If it hits only one hostile creature, add damage equal to 2×PB.
- **Sever the Sustaining Constellation (2 Star Intent; Reaction):** Make a Path-key ability check adding PB against DC 10 + the source’s PB or equivalent. On success, suppress the effect until the start of the source’s next turn. At Perfected, an effect below your active Realm ends instead unless protected by higher authority.

**Explicit non-grants:** No Sword, Stars, Weapons, Metal, Pressure Points, Spear, or Strategy Sphere.; No universal correction, automatic hit, complete dispel, or conceptual severance.; No Body Aspect or Soul Anchor without an authorized Method.

### FF21-S · Seven-Star Sword-Heart Soul Anchor — Spirit Awakening

**Anchor Aspect: The Heart That Chooses the Cut**

A Soul Anchor built from sword comprehension rather than physical bones. Seven inner stars represent purpose, perception, restraint, courage, mercy, consequence, and decision; the Sword Heart exists only while they remain aligned.

**Resource:** Heart Stars (4/6/8)

- **Sword-Heart Correction (1 Heart Star; Reaction):** After the roll but before resolution, add PB at Awakened, PB + 2 at Refined, or 2×PB at Perfected.
- **Sheathe the Enemy’s Answer (1 Heart Star; No Action):** The target cannot take Reactions against the triggering creature until the start of its next turn. At Refined, the triggering creature may move 10 feet without provoking from that target; at Perfected, 20 feet.
- **Cut the False Line (2 Heart Stars; Reaction):** The target immediately repeats the relevant save with advantage. If no repeat save exists but the effect has an ongoing spiritual or mental structure, suppress that structure until the end of the target’s next turn.

**Explicit non-grants:** No Sword, Stars, Strategy, Karma, Dreams, or Protection Sphere.; No automatic target knowledge, universal true sight, automatic hit, or complete Domain.; No Body Aspect or Root without an authorized Method.

**Body Aspect excluded:** Sword Bones is the dedicated physical sword-body family. A Seven-Star Body would duplicate that role rather than preserve Sword-Heart identity.

## FF22 · Weak Reed Tendons (Minor)

The body survives overwhelming force by yielding without surrendering the rooted purpose that calls it back.

### FF22-B · Weak Reed Tendon Body — Body Refining

**Body Aspect: Weak Reed Frame**

A Minor-grade Body Aspect designed to remain accessible without feeling trivial. It does not make the cultivator indestructible; it produces exceptional flexibility, movement, and survival against control while retaining clear tendon injuries and limits.

**Resource:** Reed Flex (3/4/5)

- **Reed Slip (1 Reed Flex; No Action):** Move 15 feet at Awakened, 20 feet at Refined, or 25 feet at Perfected without provoking Opportunity Attacks from one creature you can perceive.
- **Bend Without Breaking (1 Reed Flex; Reaction):** Reduce damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. If reduced to 0, you may land standing or rotate forced movement by up to 90 degrees.
- **Reed Returns the Current (2 Reed Flex; No Action):** Add damage equal to 3×PB and push or pull the target 10 feet. At Perfected, the movement becomes 20 feet or the target must succeed on a Strength save against your normal feature DC or fall Prone.

**Explicit non-grants:** No Athletics, Air, Water, Flowing River, Verdant Growth, or movement Sphere.; No flight, teleportation, immunity to restraint, or automatic escape from higher-authority control.; No Root or Soul Anchor expression in this family; a Method cannot integrate an expression that does not exist.

**Cultivation Root excluded:** Flexible Qi circulation is already represented by several dedicated Roots; forcing a Weak Reed Root would dilute this intentionally physical common Foundation.

**Soul Anchor excluded:** Yielding self-comprehension could support another family, but Weak Reed Tendons is specifically an anatomical physique rather than an inward identity principle.

## FF23 · Furnace Heart (Major)

Power becomes cultivation only when the cultivator chooses what to refine, what to release, and what purpose the inner flame serves.

### FF23-B · Heart-Cauldron Furnace Body — Body Refining

**Body Aspect: Heart-Cauldron Body**

A Body Aspect focused on internal metabolism and organ refinement rather than devouring every hostile energy. It makes the cultivator exceptionally durable, capable of processing medicine and impurity, and dangerous when venting stored heat.

**Resource:** Furnace Heat (4/6/8)

- **Banked Coals (1 Furnace Heat; Bonus Action):** Gain temporary HP equal to 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected.
- **Furnace Guard (1 Furnace Heat; Reaction):** Reduce damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected.
- **Venting Strike (2 Furnace Heat; No Action):** Add fire, poison, acid, or force damage equal to 4×PB. At Refined, the extra damage ignores resistance. At Perfected, immunity is treated as resistance for this extra damage.

**Explicit non-grants:** No Fire, Medicine, Alchemy, Poison, Blacksmithing, Yang, or Hunger Sphere.; No immunity to all poison, medicine, heat, or hostile energy.; No Root or Soul Anchor without an authorized Method.

### FF23-Q · Medicine-Cauldron Furnace Root — Qi Cultivation

**Root Aspect: Medicine-Cauldron Refinement**

A Cultivation Root built around controlled internal alchemy. It favors Fire, Medicine, Alchemy, Poison, and Blacksmithing expressions that refine or transform material rather than simply consuming it.

**Resource:** Refined Coals (4/6/8)

- **Feed the Cauldron (1 Refined Coal; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Open the Heart-Cauldron (1 Refined Coal; No Action):** Increase one damage, healing, temporary-HP, or reduction value by 3×PB, or add PB to one check or save made to remove poison, disease, corruption, or pill impurity. At Perfected, the numeric increase becomes 4×PB.
- **Purge Through the Exhaust Meridian (2 Refined Coals; Action):** The target repeats a save against poison, disease, acid corrosion, pill impurity, or a save-ends Qi contamination with advantage. On success, it also regains HP or Qi equal to 2×PB, choosing a resource it possesses.

**Explicit non-grants:** No Fire, Medicine, Alchemy, Poison, Blacksmithing, Yang, or Hunger Sphere.; No universal diagnosis, cure, conversion, or energy absorption.; No Body Aspect or Soul Anchor without an authorized Method.

### FF23-S · Flame I Choose to Tend Soul Anchor — Spirit Awakening

**Anchor Aspect: The Flame I Choose to Tend**

A Soul Anchor based on the inward realization that endurance has meaning only when the cultivator chooses what the inner flame is for. It shapes courage, recovery, companion stability, and a persistent hearthlike Aura.

**Resource:** Hearthlight (4/6/8)

- **Tend the Inner Flame (1 Hearthlight; Reaction):** Add PB to the roll after it is made but before resolution. At Perfected, a successful save also removes one level of temporary supernatural exhaustion if the source permits recovery during the scene.
- **Shelter at the Hearth (1 Hearthlight; Reaction):** Reduce damage by 2×PB + your Spirit key ability modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. If this prevents unconsciousness, the creature may move 5 feet toward you without provoking.
- **Keep the Spirit Burning (2 Hearthlight; Action):** The target repeats one relevant save with advantage. If unconscious at 0 HP but stable, it instead regains HP equal to 2×PB and may stand. At Perfected, healing becomes 3×PB.

**Explicit non-grants:** No Fire, Spirit Companions, Karma, Protection, Medicine, or Dreams Sphere.; No immunity to fear, exhaustion, possession, damage, or death.; No Body Aspect or Root without an authorized Method.

## FF24 · Dream-Mirror (Major)

A reflection may reveal, distort, or conceal the self; cultivation begins by knowing which image was chosen and which was imposed.

### FF24-Q · Dream-Reflection Root — Qi Cultivation

**Root Aspect: Waking Reflection**

This Cultivation Root uses a paired dantian and mirror meridians to refine dream, illusion, and perception Qi without confusing a copy for the original.

**Resource:** Mirror Trace (4/6/8)

- **Return Through the Mirror (1 Mirror Trace; No Action):** Reduce the Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum cost of 1.
- **Reflected Course (1 Mirror Trace; No Action):** Choose a reflective surface you can perceive within 30 feet at Awakened, 60 feet at Refined, or 120 feet at Perfected. Treat that surface as the action's point of origin for range and cover.
- **True-Current Witness (2 Mirror Trace; Reaction):** Add PB to the failed roll and resolve it again. At Perfected, the protected creature also learns whether the effect carries foreign Qi.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF24-S · Dream-Mirror Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Chooses the Reflection**

This Soul Anchor converts self-comprehension into explicit defense, a mechanical Aura, and a seed for later dream-and-identity Domains.

**Resource:** Mirror Trace (4/6/8)

- **True-Name Witness (1 Mirror Trace; Reaction):** Add PB to the roll after it is made but before the outcome resolves.
- **Return From the False Self (2 Mirror Trace; No Action):** Repeat one save against the effect with advantage. On success, the creature also knows one concrete way the imposed identity differed from its authentic self.
- **Step Between Reflections (1 Mirror Trace; No Action):** The protected creature moves 10 feet at Awakened, 20 feet at Refined, or 30 feet at Perfected without provoking Opportunity Attacks.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

**Body Aspect excluded:** Dream-Mirror is fundamentally a Qi-perception and self-comprehension inheritance; creating a physical mirror body would duplicate unrelated transformation families and lack a necessary bodily substrate.

## FF25 · Star-Sovereign (Legendary)

Distance does not diminish true authority; light, purpose, and consequence may arrive long after their source.

### FF25-B · Star-Sovereign Astral Body — Body Refining

**Body Aspect: Sovereign Star Body**

A Legendary Body Aspect that tempers bones, marrow, blood, organs, and gravity-bearing fascia into an astral physique.

**Resource:** Old Light (5/8/11)

- **Cross the Night (1 Old Light; No Action):** Move 30 feet at Awakened, 60 feet at Refined, or 120 feet at Perfected in a straight or arcing path without provoking Opportunity Attacks. During this movement you may cross open air, but must end on legal support.
- **Distant-Star Guard (1 Old Light; Reaction):** Reduce damage by 3×PB + Constitution modifier at Awakened, 5×PB + modifier at Refined, or 7×PB + modifier at Perfected. You may then shift 5 feet without provoking.
- **Sovereign Meteor Impact (2 Old Light; No Action):** Deal additional force or radiant damage equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected, and push the target 10/20/30 feet if it is no more than two sizes larger.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF25-Q · Star-Sovereign Core Root — Qi Cultivation

**Root Aspect: Constellation of Old Light**

A Legendary Cultivation Root formed from a central core and orbiting Qi chambers linked by star meridians.

**Resource:** Old Light (5/8/11)

- **Draw Back Old Light (1 Old Light; No Action):** Reduce the Qi cost by 3 at Awakened, 4 at Refined, or 5 at Perfected, to a minimum of 1.
- **Sovereign Distance (1 Old Light; No Action):** Increase one range by 30/60/120 feet or one area dimension by 10/20/30 feet at Awakened/Refined/Perfected.
- **Light That Arrives Later (2 Old Light; Reaction):** Reduce that damage by 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected, or add PB to the failed save and resolve it again.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF25-S · Star-Sovereign Soul Anchor — Spirit Awakening

**Anchor Aspect: The Star That Guides Without Owning**

A Legendary Soul Anchor whose soul sea contains a guiding star and freely orbiting constellations.

**Resource:** Old Light (5/8/11)

- **Guiding-Star Guard (1 Old Light; Reaction):** Add PB to the roll after it is made but before resolution.
- **Name the Constellation (1 Old Light; Bonus Action):** Until the start of your next turn, chosen creatures gain 10/20/30 feet of movement usable only toward that declared purpose; this movement does not provoke Opportunity Attacks.
- **Old Light Remembers (2 Old Light; Reaction):** Until the end of its next turn, it perceives the direction of the declared reference and may repeat one related save with advantage.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

## FF26 · Iron Oath (Major)

A promise becomes cultivation only when freely chosen, carried through danger, and released when fulfilled.

### FF26-B · Iron Oath Guardian Body — Body Refining

**Body Aspect: Oath-Bound Iron Skin**

A Major Body Aspect tempering skin, scars, blood, bones, and reflex around freely accepted protective oaths.

**Resource:** Guarding Iron (4/6/8)

- **Iron Oath Guard (1 Guarding Iron; Reaction):** Reduce damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected.
- **Iron Interposition (1 Guarding Iron; Reaction):** Move up to 15/30/45 feet toward the subject without provoking. If adjacent, become the target when legally possible.
- **Oath-Mark Answer (1 Guarding Iron; No Action):** Deal extra force damage equal to 2×PB/3×PB/4×PB by stage; it cannot ignore your Opportunity Attacks until your next turn.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF26-S · Chosen Oath Soul Anchor — Spirit Awakening

**Anchor Aspect: The Promise I Continue to Choose**

A Major Soul Anchor converting chosen obligation into resistance, diagnosis, release, and a consent-aware Aura.

**Resource:** Guarding Iron (4/6/8)

- **Word-Bound Guard (1 Guarding Iron; Reaction):** Add PB after the roll but before resolution.
- **Name the True Promise (1 Guarding Iron; Action):** It learns whether it knowingly accepted the obligation, whether terms were supernaturally altered, and one broad consequence of refusal.
- **Release the Fulfilled Chain (2 Guarding Iron; No Action):** Repeat one save or check to end it with advantage; if none exists, suppress its penalties until the end of the target's next turn.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

**Cultivation Root excluded:** The concept does not need distinct Qi intake or circulation architecture, and an oath-seal Root would duplicate Golden Mandate and Karma Knot.

## FF27 · Beast-Echo (Major)

Inheritance becomes strength when many instincts are integrated without erasing the cultivator or enslaving the beasts that taught them.

### FF27-B · Beast-Echo Marrow Body — Body Refining

**Body Aspect: Many-Beast Marrow**

A Major Body Aspect that integrates bounded physical traits from beasts and companion lineages.

**Resource:** Pack Echo (4/6/8)

- **Pack-Marrow Strike (1 Pack Echo; No Action):** Deal extra damage equal to 2×PB/3×PB/4×PB by stage and move yourself or the willing ally 5/10/15 feet without provoking.
- **Marrow Pack Guard (1 Pack Echo; Reaction):** Reduce damage by 2×PB + Constitution modifier, 3×PB + modifier, or 4×PB + modifier by stage.
- **Borrow Beast Pattern (2 Pack Echo; No Action):** Until the end of your next turn, intensify that pattern: gain climb or swim Speed equal to Speed, double jump distance, gain advantage on scent/hearing tracking, or reduce one fall/forced movement by 30 feet.

**Explicit non-grants:** No Sphere, flight, breath weapon, monster statistics, legendary action, or full creature transformation is granted.; No additional expression or integration exists without an authorized Method.

### FF27-Q · Totemic Beast-Echo Root — Qi Cultivation

**Root Aspect: Wheel of Remembered Beasts**

Beast lineages become Qi architectures rather than bodily transformations.

**Resource:** Pack Echo (4/6/8)

- **Refine the Echo (1 Pack Echo; No Action):** Reduce Qi cost by 2/3/4 by stage, minimum 1.
- **Totemic Delivery (1 Pack Echo; No Action):** Add 2×PB/3×PB/4×PB to one damage, movement, temporary HP, or damage-reduction value; or grant advantage on one tracking check caused by the action.
- **Companion Chorus (2 Pack Echo; Reaction):** Either reduce that action's resource cost by 1, minimum 1, or add PB to the save after rolling.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF27-S · Many Voices, One Pack Soul Anchor — Spirit Awakening

**Anchor Aspect: Many Voices, One Chosen Pack**

A Major Soul Anchor for companion agency, bond integrity, possession resistance, and coordinated movement.

**Resource:** Pack Echo (4/6/8)

- **Pack-Soul Guard (1 Pack Echo; Reaction):** Add PB after the roll but before resolution.
- **Call a Pack Member Back (2 Pack Echo; Reaction):** It repeats one save with advantage; until its next turn ends, it recognizes its own will and the existence of the bond.
- **Move as a Chosen Pack (1 Pack Echo; Bonus Action):** Each moves 10/20/30 feet by stage without provoking, in either order.

**Explicit non-grants:** No companion obedience, monster stat block, forced loyalty, or complete Domain is granted.; No additional expression or integration exists without an authorized Method.

## FF28 · Ash-Born Remnant (Mythic)

Ruin is not power by itself; cultivation lies in choosing what remains, what must end, and what can be rebuilt without repeating the catastrophe.

### FF28-B · Ash-Born Survivor Body — Body Refining

**Body Aspect: Last-Cinder Body**

A Mythic Body Aspect with immense HP scaling, finite damage reduction, ruin mobility, and aftermath retaliation.

**Resource:** Remnant Cinder (6/9/12)

- **Last Cinder Guard (1 Remnant Cinder; Reaction):** Reduce damage by 3×PB + Constitution modifier at Awakened, 5×PB + modifier at Refined, or 7×PB + modifier at Perfected. If this leaves you conscious, you may stand and move 5 feet.
- **Ashes Cross Ruin (1 Remnant Cinder; No Action):** Move 30/60/120 feet by stage without provoking. You may pass through fire, ash, smoke, rubble, and spaces of destroyed unattended objects as difficult but legal terrain.
- **Remnant-Bearing Strike (2 Remnant Cinder; No Action):** Deal additional fire, necrotic, or radiant damage equal to 3×PB/5×PB/7×PB by stage. The target cannot regain HP until the start of your next turn.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF28-Q · Ash-Born Remnant Root — Qi Cultivation

**Root Aspect: Last Core After Ruin**

It refines hostile aftermath into massive Qi reserve, bounded conversion, and one carefully limited remembered property.

**Resource:** Remnant Cinder (6/9/12)

- **Cinder Returns to the Core (1 Remnant Cinder; No Action):** Reduce cost by 4/6/8 by stage, minimum 1.
- **Ash-Remnant Conversion (1 Remnant Cinder; No Action):** Add 3×PB/5×PB/7×PB to one listed value, or convert its damage to fire, necrotic, or radiant. At Perfected the converted damage treats immunity as resistance.
- **Keep the Last Technique (2 Remnant Cinder; Reaction):** Store one broad property of that action until replaced: damage type, movement direction, range category, area shape, or condition category. Your next compatible action may adopt that property.

**Explicit non-grants:** No Sphere, complete copied action, named enemy feature, unique permission, or full technique is granted.; No additional expression or integration exists without an authorized Method.

### FF28-S · Last Cinder of the Self Soul Anchor — Spirit Awakening

**Anchor Aspect: The Self That Remains After Ruin**

A Mythic Soul Anchor for identity after catastrophe, resistance to annihilation and despair, and powerful recovery support.

**Resource:** Remnant Cinder (6/9/12)

- **Last-Cinder Soul Guard (1 Remnant Cinder; Reaction):** Add PB after the roll but before resolution.
- **Release What Must End (1 Remnant Cinder; No Action):** Suppress one penalty from that persistence until the end of the target's next turn and allow one repeated save with advantage when available.
- **Build From Cinder (2 Remnant Cinder; No Action):** It gains temporary HP equal to 3×PB/5×PB/7×PB by stage and may move 10/20/30 feet without provoking.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

## FF29 · Mud Lotus (Major)

Mud may nourish life without defining it; true cultivation takes what is useful from hardship, rejects corruption, and rises without despising its origin.

### FF29-B · Mud-Lotus Renewal Body — Body Refining

**Body Aspect: Lotus-Renewal Body**

A Major Body Aspect that turns hardship, living water, and humble medicine into physical renewal without treating poison or rot as desirable.

**Resource:** Lotus Vitality (4/6/8)

- **Rooted in Mud (1 Lotus Vitality; Reaction):** Reduce the damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. If the source is poison, disease, rot, or contamination, the target also gains Advantage on its next save against that source before the end of its next turn.
- **Lotus Renewal (1 Lotus Vitality; Bonus Action):** The target regains HP equal to 2×PB + Constitution modifier at Awakened, 4×PB + modifier at Refined, or 6×PB + modifier at Perfected. A creature can benefit from this feature only once per turn.
- **Rise From Filth (2 Lotus Vitality; No Action):** Reroll the save with a bonus equal to PB. On a success, stand without spending movement and move 10 feet at Awakened, 20 feet at Refined, or 30 feet at Perfected without provoking Opportunity Attacks.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF29-Q · Mud-Lotus Dantian Root — Qi Cultivation

**Root Aspect: Lotus in Living Mud**

A Major Cultivation Root with layered water, mud, root, and bloom chambers that refine contaminated or humble materials into clean recovery Qi.

**Resource:** Lotus Dew (4/6/8)

- **Filter the Mire (1 Lotus Dew; Reaction):** Add PB to the save. On a success, reduce associated damage or measurable harm by 2×PB at Awakened, 3×PB at Refined, or 4×PB at Perfected.
- **Lotus-Root Circulation (1 Lotus Dew; No Action):** Reduce the Qi cost by 1 at Awakened, 2 at Refined, or 3 at Perfected, to a minimum of 1.
- **Bloom Through Corruption (2 Lotus Dew; Bonus Action):** The target gains temporary HP equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected and may immediately repeat one save against the listed effect with PB added.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF29-S · Lotus Above Mud Soul Anchor — Spirit Awakening

**Anchor Aspect: The Lotus Is Not the Mud**

A Major Soul Anchor whose inner lotus blooms from remembered hardship while refusing imposed shame, corruption, and the belief that receiving help makes the self lesser.

**Resource:** Lotus Petals (4/6/8)

- **Refuse the Stain (1 Lotus Petal; Reaction):** Add PB to the save after the roll but before the result is finalized. On success, the target also gains temporary HP equal to 2×PB at Awakened, 3×PB at Refined, or 4×PB at Perfected.
- **Share the Pond (1 Lotus Petal; Bonus Action):** The target gains temporary HP equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected and Advantage on its next save against fear, despair, shame, spiritual contamination, poison, or disease before the end of its next turn.
- **Bloom Again (2 Lotus Petals; No Action):** The target repeats one save against the effect with PB added. On a success, it may stand and move 10/20/30 feet without provoking Opportunity Attacks.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

## FF30 · Glass Heart (Major)

Clarity is not invulnerability; the heart becomes trustworthy by allowing truth to pass through without letting every image define it.

### FF30-B · Prismatic Glass-Heart Body — Body Refining

**Body Aspect: Prismatic Glass-Heart Body**

A Major Body Aspect that tempers transparent meridians and a resilient glass heart without pretending fragility has disappeared.

**Resource:** Clarity Shards (4/6/8)

- **Shatter-Guard (1 Clarity Shard; Reaction):** Reduce the damage by 2×PB + Dexterity or Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. If the source is within 15/30/45 feet, it takes radiant or psychic damage equal to PB/2×PB/3×PB.
- **Prism Step (1 Clarity Shard; No Action):** Move 15 feet at Awakened, 30 feet at Refined, or 45 feet at Perfected without provoking Opportunity Attacks. During this movement you may pass through a space occupied by a creature but cannot end there.
- **Clear-Heart Rebuke (2 Clarity Shards; No Action):** Deal additional radiant or psychic damage equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected. If an active supernatural illusion, charm, or identity mask from that target directly caused the trigger, you recognize that specific effect as false.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF30-Q · Clear-Prism Meridian Root — Qi Cultivation

**Root Aspect: Clear-Prism Refraction**

A Major Cultivation Root with a seven-facet dantian, transparent meridians, and return circulation that compares every Qi expression to its original source.

**Resource:** Refractions (4/6/8)

- **Refract the Line (1 Refraction; No Action):** Shift the action's origin or one legal bend point by 15 feet at Awakened, 30 feet at Refined, or 45 feet at Perfected. The new point must be visible and every segment must preserve line of effect.
- **Clear-Prism Conversion (1 Refraction; No Action):** Choose radiant or psychic damage for the action. At Refined, it ignores resistance to the chosen type. At Perfected, immunity is treated as resistance. If the action does not deal damage, add PB to its first save DC contest or opposed check instead.
- **Mirror-Breaking Pulse (2 Refractions; Reaction):** The target rerolls the save with PB added. On a success, the source takes psychic or radiant damage equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected if you can perceive it.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

### FF30-S · Transparent Heart Soul Anchor — Spirit Awakening

**Anchor Aspect: The Heart That Can Be Seen**

A Major Soul Anchor whose spirit palace is a clear heart surrounded by honest reflections, preserving identity through vulnerability rather than emotional numbness.

**Resource:** Clear Reflections (4/6/8)

- **Transparent Witness (1 Clear Reflection; Reaction):** Add PB to the save after the roll but before the result is finalized. On a success, the target knows which emotion, image, or identity element was imposed.
- **Beauty Without Lie (1 Clear Reflection; Bonus Action):** The target gains temporary HP equal to 3×PB at Awakened, 5×PB at Refined, or 7×PB at Perfected and Advantage on its next save against charm, fear, shame, illusion, or identity replacement before the end of its next turn.
- **Shatter the False Self (2 Clear Reflections; No Action):** The target repeats one save against the effect with PB added. On a success, one active supernatural image or identity mask connected to that effect becomes visibly false to willing creatures inside the Aura until the end of your next turn.

**Explicit non-grants:** This expression grants no Sphere, full Domain, additional Path, or unrelated technique.; It does not grant another Foundation expression or integration without an authorized Method.

## FF31 · Ninefold Heavenly Thunder (Powerful)

Calamity does not bestow worth; power is forged by conducting destructive force into a chosen answer.

### FF31-B · Thunder-Calamity Tyrant Body — Body Refining

**Body Aspect: Thunder-Calamity Body**

A Powerful Body Aspect that embodies lightning, thunder, sudden motion, and survival under calamity rather than merely resisting electricity.

**Resource:** Tribulation Charge (4/6/8)

- **Lightning-Shed Guard (1 Tribulation Charge; Reaction):** Reduce damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. Afterward, move 10/20/30 feet without provoking Opportunity Attacks.
- **Heaven-Rending Step (1 Tribulation Charge; No Action):** Move 20 feet at Awakened, 40 feet at Refined, or 60 feet at Perfected without provoking Opportunity Attacks. At Perfected, you may treat open air as footing during this movement but must end on support.
- **Calamity-Forged Strike (2 Tribulation Charge; No Action):** Deal additional lightning or thunder damage equal to 4×PB at Awakened, 6×PB at Refined, or 8×PB at Perfected and push the target 10/20/30 feet. At Perfected this added damage ignores resistance.

**Explicit non-grants:** No Lightning, Thunder, Weather, or Air Sphere access.; No permanent flight or supernatural lightning immunity.; No immunity to stun, paralysis, or heavenly tribulation.

### FF31-Q · Ninefold Tribulation Root — Qi Cultivation

**Root Aspect: Ninefold Tribulation Root**

A Powerful Root that accelerates circulation, refines lightning and thunder Qi, and turns interruption into stored current.

**Resource:** Heavenly Current (4/6/8)

- **Feed the Nine Chambers (1 Heavenly Current; No Action):** Reduce its Qi cost by 2 at Awakened, 3 at Refined, or 4 at Perfected, to a minimum of 1.
- **Chain the Heavenly Current (1 Heavenly Current; No Action):** Extend one line, jump, range, or forced-movement distance by 15 feet at Awakened, 30 at Refined, or 60 at Perfected. If the action can target creatures, it may affect one additional legal target within that extension.
- **Hold the Tribulation Circuit (2 Heavenly Current; Reaction):** Prevent that interruption. At Refined, also remove one ordinary circulation penalty on the effect; at Perfected, hostile counter-circulation must explicitly end or dispel it.

**Explicit non-grants:** No free Lightning, Thunder, Weather, Air, or Radiance Sphere.; No automatic counterspell or universal technique chaining.; No complete heavenly mandate or Domain.

### FF31-S · Heart That Answers Heaven — Spirit Awakening

**Anchor Aspect: The Answer I Choose**

A Powerful Soul Anchor that turns fear, coercive judgment, and calamity into deliberate courage and an Aura of chosen endurance.

**Resource:** Calamity Marks (4/6/8)

- **Stand Beneath Judgment (1 Calamity Mark; Reaction):** After the roll but before resolution, add PB to the save.
- **Return Your Answer (1 Calamity Mark; No Action):** The target moves 10/20/30 feet without provoking Opportunity Attacks or regains Resonance equal to PB/2×PB/3×PB.
- **Name the True Trial (2 Calamity Marks; No Action):** The target repeats one save against that effect. On success, it also gains temporary HP equal to 2×PB/3×PB/4×PB.

**Explicit non-grants:** No complete Domain or heavenly authority.; No immunity to fear, stun, paralysis, Karma, or judgment.; No right to impose trials on unwilling creatures.

## FF32 · Myriad-Venom Jade Cicada (Rare)

Corruption may be studied and transformed without being worshipped, preserved, or allowed to define the cultivator.

### FF32-B · Myriad-Venom Jade Cicada Body — Body Refining

**Body Aspect: Jade Cicada Venom Body**

A Rare Body Aspect focused on toxin adaptation, acid resilience, bodily renewal, and sudden shedding movement.

**Resource:** Jade Venom (4/6/8)

- **Jade Carapace Guard (1 Jade Venom; Reaction):** Reduce damage by 2×PB + Constitution modifier at Awakened, 3×PB + modifier at Refined, or 4×PB + modifier at Perfected. Against poison or acid, double the Constitution modifier added.
- **Venom Transmutation (1 Jade Venom; No Action):** Deal additional poison or acid damage equal to 3×PB/5×PB/7×PB. At Refined it ignores resistance; at Perfected immunity is treated as resistance.
- **Cicada Shedding (2 Jade Venom; Reaction):** Move 15/30/45 feet without provoking Opportunity Attacks and either end grappled/restrained or repeat the triggering save with a +PB bonus. A translucent husk remains in your former space.

**Explicit non-grants:** No Poison, Disease, Acid, Alchemy, or Life Sphere access.; No universal immunity to supernatural toxins or transformations.; No forced infection or control of another creature through poison.

### FF32-Q · Ten-Thousand Toxin Crucible Root — Qi Cultivation

**Root Aspect: Ten-Thousand Toxin Crucible**

A Rare Root focused on toxin intake, purification, alchemical conversion, and stable poison technique expression.

**Resource:** Refined Venom (4/6/8)

- **Feed the Venom Crucible (1 Refined Venom; No Action):** Reduce the Qi cost by 1/2/3, to a minimum of 1.
- **Choose the Toxin (1 Refined Venom; No Action):** Convert its damage to poison or acid and add 2×PB/3×PB/4×PB to one damage roll, or impose a -1/-2/-PB penalty to the first save against its poison/disease rider.
- **Extract the Antidote (2 Refined Venom; Action):** Suppress one such effect until the end of the scene and let the target repeat one save with +PB. At Perfected, success ends the effect if it is not explicitly incurable or Foundation damage.

**Explicit non-grants:** No Poison, Disease, Acid, Alchemy, or Life Sphere access.; No automatic cure of incurable disease or Foundation damage.; No universal poison creation or control of infected creatures.

**Soul Anchor excluded:** Toxin adaptation and shedding do not by themselves answer what preserves identity; a poison-based Soul Anchor would require a separate self-comprehension family.

## FF33 · Starless Void Crossing (Legendary)

The self and its chosen relations remain real even when distance, direction, place, and witness disappear.

### FF33-Q · Starless Gate Root — Qi Cultivation

**Root Aspect: Starless Gate**

A Legendary Root that folds technique origin, traverses space, and stabilizes Qi where ordinary direction fails.

**Resource:** Void Distance (5/8/11)

- **Fold the Interval (1 Void Distance; No Action):** Reduce its Qi cost by 2/3/4 to a minimum of 1, or shift its point of origin to a visible legal point within 30/60/120 feet.
- **Starless Passage (1 Void Distance; No Action):** Teleport 30 feet at Awakened, 60 feet at Refined, or 120 feet at Perfected to a visible unoccupied space.
- **Empty Between (2 Void Distance; Reaction):** Preserve the effect and allow it to resolve from its original or current legal relation. At Perfected, ordinary spatial redirection cannot change its intended target.

**Explicit non-grants:** No Gravity, Shadow, Stars, Air, Darkness, or Hidden Eye Sphere access.; No blind teleportation, planar travel, or bypass of dimensional seals.; No complete spatial Domain.

### FF33-S · Horizon Without Stars Soul Anchor — Spirit Awakening

**Anchor Aspect: I Remain Without a Landmark**

A Legendary Soul Anchor that preserves identity through isolation, spatial displacement, banishment, and sensory absence.

**Resource:** Bearings (5/8/11)

- **Hold the Bearing (1 Bearing; Reaction):** Add PB to the save after the roll but before resolution.
- **Return Along the Relation (1 Bearing; No Action):** After the effect resolves, the target moves or teleports 20/40/80 feet toward a willing creature or place it could perceive before separation.
- **Refuse the Vanishing (2 Bearings; No Action):** The target repeats one save with +PB. On success, it becomes spiritually perceptible to willing bonded creatures for the rest of the scene even through ordinary darkness or distance.

**Explicit non-grants:** No complete Domain, blind planar travel, or universal location sense.; No immunity to banishment, teleportation, darkness, or isolation.; No ownership or forced maintenance of another creature’s bond.

**Body Aspect excluded:** A stable bodily transformation based on spatial absence would require a separate Void Body family with different risks; it is not forced into this Root-and-Anchor concept.

## FF34 · World-Bearing Mountain (Legendary)

True strength is the capacity to bear great weight while choosing, sharing, and moving beneath it rather than becoming a prison of stillness.

### FF34-B · World-Bearing Mountain Body — Body Refining

**Body Aspect: World-Bearing Mountain Body**

A Legendary Body Aspect centered on enormous durability, strength, stability, carrying capacity, and unstoppable deliberate movement.

**Resource:** Worldweight (5/8/11)

- **Bear the World’s Impact (1 Worldweight; Reaction):** Reduce damage by 3×PB + Constitution modifier at Awakened, 5×PB + modifier at Refined, or 7×PB + modifier at Perfected. If protecting another target, you take any unreduced damage after its defenses.
- **The Mountain Advances (1 Worldweight; No Action):** Move 15/30/45 feet without provoking Opportunity Attacks. During this movement you may move through spaces of creatures smaller than the size you count as, pushing each to the nearest legal space.
- **Lift the Fallen Sky (2 Worldweight; No Action):** Deal additional bludgeoning or force damage equal to 5×PB/8×PB/11×PB and push or lift 15/30/45 feet, or support a structural load of equivalent narrative scale until the start of your next turn.

**Explicit non-grants:** No Earth, Gravity, Protection, Metal, Strength, or Formation Sphere access.; No automatic Gargantuan size, reach, or immunity to movement.; No ability to carry unlimited narrative weight without a printed procedure.

### FF34-Q · Ten-Thousand-Ridges Dantian Root — Qi Cultivation

**Root Aspect: Ten-Thousand-Ridges Root**

A Legendary Root focused on immense Qi capacity, Earth and Gravity affinity, pressure distribution, and stable large-area techniques.

**Resource:** Mountain Pressure (5/8/11)

- **Distribute the Pressure (1 Mountain Pressure; No Action):** Reduce its Qi cost by 2/4/6 to a minimum of 1, or divide one instance of recoil, backlash, or self-damage from the action by 2.
- **Raise Ten Thousand Ridges (1 Mountain Pressure; No Action):** Increase one area dimension by 10/20/40 feet, one forced-movement distance by 15/30/45 feet, or one protective radius by 10/20/40 feet.
- **World-Pillar Anchor (2 Mountain Pressure; Reaction):** Prevent up to 20/40/80 feet of movement, prevent prone or collapse, or preserve the sustained effect. At Perfected, ordinary dispelling by force alone is insufficient.

**Explicit non-grants:** No Earth, Gravity, Protection, Metal, Formation, or Harvesting Sphere access.; No automatic terrain creation or unlimited area growth.; No complete world-pillar Domain.

### FF34-S · The Burden I Choose Soul Anchor — Spirit Awakening

**Anchor Aspect: The Burden I Choose**

A Legendary Soul Anchor that protects willing creatures against forced movement, despair, imposed obligation, and collapse while developing a mountain-like Aura.

**Resource:** Chosen Weight (5/8/11)

- **Bear It Together (1 Chosen Weight; Reaction):** Reduce damage by 2×PB/4×PB/6×PB or add PB to the save. If damage is reduced, you may take up to the prevented amount as unavoidable damage after the trigger resolves.
- **Set Your Feet (1 Chosen Weight; No Action):** The target gains temporary HP equal to 2×PB/3×PB/4×PB and may move 10/20/30 feet without provoking Opportunity Attacks.
- **Lay Down What Is Not Yours (2 Chosen Weight; No Action):** The target repeats one save with +PB. On success, it recognizes whether the burden was freely chosen, genuinely owed, or supernaturally imposed; this does not erase real obligations.

**Explicit non-grants:** No complete Domain or authority to assign burdens.; No immunity to fear, despair, damage, forced movement, or duty.; No coercion of allies or transfer of consequences without consent.
