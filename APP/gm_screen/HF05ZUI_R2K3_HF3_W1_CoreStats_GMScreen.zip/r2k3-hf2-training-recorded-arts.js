/* HF05ZUI-R2K.3-HF2 — Training-source and Recorded Art catalog composer. */
(() => {
  const PATCH = "HF05ZUI-R2K.3-HF2-TRAINING-RECORDED-ART-COMPOSER";
  const TARGET_FACTORY = "HF05ZVK-R1H";
  const TARGET_CONSUMER = "HF05ZUI-R2K.3";
  const PACKAGE_VERSION = "HF05ZUI-R2K.3-HF2-builder-v7";
  const catalog = Array.isArray(window.TIANXIA_SPHERE_TALENT_CATALOG) ? window.TIANXIA_SPHERE_TALENT_CATALOG : [];
  const norm = (value) => String(value || "").trim().toLowerCase().replace(/[’‘]/g, "'").replace(/[^a-z0-9]+/g, " ").trim();
  const compact = (value) => norm(value).replace(/\band\b/g, "").replace(/\s+/g, "");
  const sphereMap = new Map(catalog.map((row) => [compact(row.name), row]));
  const excludedBySphere = new Map();
  (window.TIANXIA_INSIGHT_CATALOG?.spheres || []).forEach((row) => {
    excludedBySphere.set(compact(row.sphere), new Set([...(row.insights || []), ...(row.variants || [])].map((item) => compact(item.name))));
  });
  const talentRows = (sphereName) => {
    const sphere = sphereMap.get(compact(sphereName));
    const excluded = excludedBySphere.get(compact(sphereName)) || new Set();
    return (sphere?.talents || []).filter((row) => !excluded.has(compact(row.name)));
  };
  const escape = (value) => typeof escapeHtml === "function" ? escapeHtml(String(value ?? "")) : String(value ?? "").replace(/[&<>\"]/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[ch]));
  const selectedSpheres = () => Array.isArray(window.builderSphereNames) ? window.builderSphereNames : (typeof builderSphereNames !== "undefined" && Array.isArray(builderSphereNames) ? builderSphereNames : []);
  const allSphereNames = () => catalog.map((row) => row.name).filter(Boolean);
  const orderedSphereNames = () => {
    const selected = selectedSpheres();
    const seen = new Set(selected.map(compact));
    return [...selected, ...allSphereNames().filter((name) => !seen.has(compact(name)))];
  };
  const talentText = (sphere, name) => {
    const row = talentRows(sphere).find((item) => compact(item.name) === compact(name));
    return row?.short_description || row?.summary || row?.full_text || "";
  };
  const splitExpressions = (value) => String(value || "").split(/\s*\+\s*/).map((item) => item.trim()).filter(Boolean);
  const lineParts = (line) => String(line || "").split("|").map((part) => part.trim());
  const readRecordedLines = () => String(document.getElementById("builderRecordedArts")?.value || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  const writeRecordedLines = (lines) => {
    const textarea = document.getElementById("builderRecordedArts");
    if (!textarea) return;
    textarea.value = lines.join("\n");
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    renderRecordedList();
  };
  const associationsField = () => document.getElementById("builderTrainingAssociationsJson");
  const readAssociations = () => {
    try {
      const raw = associationsField()?.value || "[]";
      const rows = JSON.parse(raw);
      return Array.isArray(rows) ? rows.filter((row) => row && row.sphere) : [];
    } catch { return []; }
  };
  const writeAssociations = (rows) => {
    const field = associationsField();
    if (!field) return;
    field.value = JSON.stringify(rows, null, 2);
    field.dispatchEvent(new Event("input", { bubbles: true }));
    renderAssociationList();
  };
  const sphereOptions = (value = "") => {
    const selectedKeys = new Set(selectedSpheres().map(compact));
    const selected = orderedSphereNames().filter((name) => selectedKeys.has(compact(name)));
    const others = orderedSphereNames().filter((name) => !selectedKeys.has(compact(name)));
    const option = (name) => `<option value="${escape(name)}" ${compact(name) === compact(value) ? "selected" : ""}>${escape(name)}</option>`;
    return `${selected.length ? `<optgroup label="Selected character Spheres">${selected.map(option).join("")}</optgroup>` : ""}<optgroup label="All Sphere catalog entries">${others.map(option).join("")}</optgroup>`;
  };
  const fillSphereSelect = (id, preserve = true) => {
    const select = document.getElementById(id);
    if (!select) return;
    const prior = preserve ? select.value : "";
    select.innerHTML = `<option value="">Choose Sphere…</option>${sphereOptions(prior)}`;
    if (prior && [...select.options].some((option) => option.value === prior)) select.value = prior;
  };
  const fillTalentSelect = (sphereId, talentId, summaryId) => {
    const sphere = document.getElementById(sphereId)?.value || "";
    const select = document.getElementById(talentId);
    if (!select) return;
    const prior = select.value;
    const rows = talentRows(sphere);
    select.innerHTML = `<option value="">Choose talent…</option>${rows.map((row) => `<option value="${escape(row.name)}">${escape(row.name)}${row.realm ? ` — ${escape(row.realm)}` : ""}</option>`).join("")}`;
    if (prior && [...select.options].some((option) => option.value === prior)) select.value = prior;
    updateTalentSummary(talentId, sphereId, summaryId);
  };
  const updateTalentSummary = (talentId, sphereId, summaryId) => {
    const sphere = document.getElementById(sphereId)?.value || "";
    const talent = document.getElementById(talentId)?.value || "";
    const summary = document.getElementById(summaryId);
    if (summary) summary.textContent = talent ? talentText(sphere, talent) || "Exact source text governs this talent." : "Choose a Sphere, then a talent. This helper does not perform legality validation.";
  };
  const pending = { manual: [], art: [] };
  const renderPending = (kind) => {
    const target = document.getElementById(kind === "manual" ? "builderManualPendingTalents" : "builderArtPendingTalents");
    if (!target) return;
    target.innerHTML = pending[kind].length ? pending[kind].map((name, index) => `<button type="button" class="hf2-token" data-remove-pending="${kind}" data-index="${index}" title="Remove ${escape(name)}">${escape(name)} <span aria-hidden="true">×</span></button>`).join("") : `<span class="hf2-empty-inline">No talents added yet.</span>`;
  };
  const addPending = (kind) => {
    const isManual = kind === "manual";
    const talentId = isManual ? "builderTrainingTalentSelect" : "builderRecordedArtTalentSelect";
    const customId = isManual ? "builderTrainingCustomTalent" : "builderRecordedArtCustomExpression";
    const talent = document.getElementById(talentId)?.value.trim() || "";
    const custom = document.getElementById(customId)?.value.trim() || "";
    [talent, custom].filter(Boolean).forEach((name) => {
      if (!pending[kind].some((existing) => compact(existing) === compact(name))) pending[kind].push(name);
    });
    const customInput = document.getElementById(customId); if (customInput) customInput.value = "";
    const talentSelect = document.getElementById(talentId); if (talentSelect) talentSelect.value = "";
    renderPending(kind);
  };
  const renderAssociationList = () => {
    const target = document.getElementById("builderTrainingAssociationList");
    if (!target) return;
    const rows = readAssociations();
    target.innerHTML = rows.length ? rows.map((row, index) => `<article class="hf2-mapping-row"><div><strong>${escape(row.source_name || "Primary manual / lineage")}</strong><p><b>${escape(row.sphere)}</b> → ${escape((row.talents || []).join(" + ") || "No talent expressions recorded")}</p></div><button type="button" class="ghost-button hf2-remove-button" data-remove-association="${index}">Remove</button></article>`).join("") : `<div class="empty-state compact-empty">No explicit Sphere → talent mapping recorded for this manual. The factory may infer associations from the doctrine and selected build.</div>`;
  };
  const addAssociation = () => {
    const sphere = document.getElementById("builderTrainingSphereSelect")?.value || "";
    const sourceName = document.getElementById("builderTrainingAssociationSource")?.value.trim() || document.getElementById("builderMartialArtName")?.value.trim() || "Primary manual / lineage";
    if (!sphere) { if (typeof toast === "function") toast("Choose a Sphere for the training source mapping."); return; }
    addPending("manual");
    const talents = [...pending.manual];
    if (!talents.length) { if (typeof toast === "function") toast("Add at least one talent or custom expression."); return; }
    const rows = readAssociations();
    const existing = rows.find((row) => compact(row.sphere) === compact(sphere) && compact(row.source_name || "Primary manual / lineage") === compact(sourceName));
    if (existing) {
      existing.talents = [...new Set([...(existing.talents || []), ...talents])];
    } else {
      rows.push({ association_id:`training_association_${rows.length + 1}`, source_name:sourceName, sphere, talents, selection_authority:"organizational_only_no_legality_validation" });
    }
    pending.manual = [];
    writeAssociations(rows);
    renderPending("manual");
  };
  const renderRecordedList = () => {
    const target = document.getElementById("builderRecordedArtStructuredList");
    if (!target) return;
    const lines = readRecordedLines();
    target.innerHTML = lines.length ? lines.map((line, index) => {
      const parts = lineParts(line);
      return `<article class="hf2-mapping-row hf2-art-row"><div><strong>${escape(parts[0] || `Recorded Art ${index + 1}`)}</strong><p><b>${escape(parts[1] || "Sphere not recorded")}</b> → ${escape(parts[2] || "Talent expression not recorded")}</p>${parts[3] ? `<small>${escape(parts[3])}</small>` : ""}</div><button type="button" class="ghost-button hf2-remove-button" data-remove-art="${index}">Remove</button></article>`;
    }).join("") : `<div class="empty-state compact-empty">No Recorded Arts entered.</div>`;
  };
  const addRecordedArt = () => {
    const name = document.getElementById("builderRecordedArtName")?.value.trim() || "";
    const sphere = document.getElementById("builderRecordedArtSphereSelect")?.value || "";
    addPending("art");
    const talents = [...pending.art];
    const role = document.getElementById("builderRecordedArtRole")?.value.trim() || "";
    const notes = document.getElementById("builderRecordedArtNotes")?.value.trim() || "";
    if (!name || !sphere || !talents.length) { if (typeof toast === "function") toast("Recorded Art requires a name, Sphere, and at least one talent expression."); return; }
    const line = [name, sphere, talents.join(" + "), role, notes].join(" | ");
    writeRecordedLines([...readRecordedLines(), line]);
    pending.art = [];
    ["builderRecordedArtName","builderRecordedArtRole","builderRecordedArtNotes","builderRecordedArtCustomExpression"].forEach((id) => { const el = document.getElementById(id); if (el) el.value = ""; });
    const talent = document.getElementById("builderRecordedArtTalentSelect"); if (talent) talent.value = "";
    renderPending("art");
  };
  const injectUi = () => {
    const training = document.querySelector('[data-builder-section="training"] .builder-accordion-body');
    const textarea = document.getElementById("builderRecordedArts");
    if (!training || !textarea || document.getElementById("builderTrainingSphereSelect")) return;
    const field = document.createElement("textarea");
    field.id = "builderTrainingAssociationsJson";
    field.hidden = true;
    field.setAttribute("aria-hidden", "true");
    training.appendChild(field);
    try { if (Array.isArray(HF05ZUI_R2E_BUILDER_FIELD_IDS) && !HF05ZUI_R2E_BUILDER_FIELD_IDS.includes(field.id)) HF05ZUI_R2E_BUILDER_FIELD_IDS.push(field.id); } catch {}

    const textareaLabel = textarea.closest("label");
    const legacy = document.createElement("details");
    legacy.className = "builder-manual-talents hf2-legacy-recorded-arts";
    legacy.innerHTML = `<summary>Advanced / manual Recorded Art rows</summary>`;
    if (textareaLabel) {
      textareaLabel.parentNode?.insertBefore(legacy, textareaLabel);
      legacy.appendChild(textareaLabel);
      const textNode = [...textareaLabel.childNodes].find((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
      if (textNode) textNode.textContent = "Raw Recorded Art rows ";
    }

    const composer = document.createElement("section");
    composer.className = "hf2-training-composer";
    composer.innerHTML = `
      <div class="hf2-composer-head"><div><h4>Manual Sphere and Talent Map</h4><p>Organizational helper only. Choose a Sphere, then add one or more talents the manual teaches or reproduces. This does not decide legality.</p></div></div>
      <div class="hf2-composer-grid">
        <label>Manual / Training Source<input id="builderTrainingAssociationSource" placeholder="Defaults to Primary Manual / Lineage"></label>
        <label>Sphere<select id="builderTrainingSphereSelect"></select></label>
        <label>Talent<select id="builderTrainingTalentSelect"><option value="">Choose Sphere first…</option></select></label>
        <label class="wide">Custom/source-specific talent or expression<input id="builderTrainingCustomTalent" placeholder="Optional custom expression absent from the catalog"></label>
        <div id="builderTrainingTalentSummary" class="hf2-talent-summary wide">Choose a Sphere, then a talent.</div>
        <div class="hf2-pending-row wide"><div id="builderManualPendingTalents" class="hf2-token-list"></div><button id="builderAddManualTalent" type="button" class="secondary-button">Add Talent</button><button id="builderAddTrainingAssociation" type="button" class="primary-button">Add Sphere Mapping</button></div>
      </div>
      <div id="builderTrainingAssociationList" class="hf2-mapping-list"></div>

      <div class="hf2-composer-head hf2-recorded-head"><div><h4>Recorded Art Composer</h4><p>Build each art as Art Name → Sphere → talent expression + talent expression. Tactical role and source notes remain optional.</p></div></div>
      <div class="hf2-composer-grid">
        <label>Recorded Art Name<input id="builderRecordedArtName" placeholder="Rain-Splitting Needle Form"></label>
        <label>Sphere<select id="builderRecordedArtSphereSelect"></select></label>
        <label>Talent<select id="builderRecordedArtTalentSelect"><option value="">Choose Sphere first…</option></select></label>
        <label>Custom/source-specific expression<input id="builderRecordedArtCustomExpression" placeholder="Optional"></label>
        <div id="builderRecordedArtTalentSummary" class="hf2-talent-summary wide">Choose a Sphere, then a talent.</div>
        <label>Tactical Role<input id="builderRecordedArtRole" placeholder="single-target pressure, defense, control"></label>
        <label>Source / Notes<input id="builderRecordedArtNotes" placeholder="manual chapter, teacher, inheritance, limitations"></label>
        <div class="hf2-pending-row wide"><div id="builderArtPendingTalents" class="hf2-token-list"></div><button id="builderAddArtTalent" type="button" class="secondary-button">Add Talent</button><button id="builderAddRecordedArt" type="button" class="primary-button">Add Recorded Art</button></div>
      </div>
      <div id="builderRecordedArtStructuredList" class="hf2-mapping-list"></div>`;
    const status = document.getElementById("builderRecordedArtStatus");
    training.insertBefore(composer, status || legacy);

    fillSphereSelect("builderTrainingSphereSelect", false);
    fillSphereSelect("builderRecordedArtSphereSelect", false);
    renderPending("manual"); renderPending("art"); renderAssociationList(); renderRecordedList();

    document.getElementById("builderTrainingSphereSelect")?.addEventListener("change", () => { pending.manual = []; renderPending("manual"); fillTalentSelect("builderTrainingSphereSelect","builderTrainingTalentSelect","builderTrainingTalentSummary"); });
    document.getElementById("builderRecordedArtSphereSelect")?.addEventListener("change", () => { pending.art = []; renderPending("art"); fillTalentSelect("builderRecordedArtSphereSelect","builderRecordedArtTalentSelect","builderRecordedArtTalentSummary"); });
    document.getElementById("builderTrainingTalentSelect")?.addEventListener("change", () => updateTalentSummary("builderTrainingTalentSelect","builderTrainingSphereSelect","builderTrainingTalentSummary"));
    document.getElementById("builderRecordedArtTalentSelect")?.addEventListener("change", () => updateTalentSummary("builderRecordedArtTalentSelect","builderRecordedArtSphereSelect","builderRecordedArtTalentSummary"));
    document.getElementById("builderAddManualTalent")?.addEventListener("click", () => addPending("manual"));
    document.getElementById("builderAddArtTalent")?.addEventListener("click", () => addPending("art"));
    document.getElementById("builderAddTrainingAssociation")?.addEventListener("click", addAssociation);
    document.getElementById("builderAddRecordedArt")?.addEventListener("click", addRecordedArt);
    textarea.addEventListener("change", renderRecordedList);
    textarea.addEventListener("blur", renderRecordedList);
    training.addEventListener("click", (event) => {
      const pendingButton = event.target.closest("[data-remove-pending]");
      if (pendingButton) { const kind = pendingButton.dataset.removePending; pending[kind].splice(Number(pendingButton.dataset.index), 1); renderPending(kind); return; }
      const associationButton = event.target.closest("[data-remove-association]");
      if (associationButton) { const rows = readAssociations(); rows.splice(Number(associationButton.dataset.removeAssociation), 1); writeAssociations(rows); return; }
      const artButton = event.target.closest("[data-remove-art]");
      if (artButton) { const lines = readRecordedLines(); lines.splice(Number(artButton.dataset.removeArt), 1); writeRecordedLines(lines); }
    });
    document.getElementById("builderLoadDraftButton")?.addEventListener("click", () => setTimeout(() => { renderAssociationList(); renderRecordedList(); }, 0));
    document.getElementById("builderResetButton")?.addEventListener("click", () => setTimeout(() => {
      writeAssociations([]);
      writeRecordedLines([]);
      pending.manual = [];
      pending.art = [];
      renderPending("manual");
      renderPending("art");
    }, 0));
  };

  injectUi();

  const priorRenderSphereList = typeof renderBuilderSphereList === "function" ? renderBuilderSphereList : null;
  if (priorRenderSphereList) {
    renderBuilderSphereList = function renderBuilderSphereListHF2(...args) {
      const result = priorRenderSphereList.apply(this, args);
      fillSphereSelect("builderTrainingSphereSelect", true);
      fillSphereSelect("builderRecordedArtSphereSelect", true);
      fillTalentSelect("builderTrainingSphereSelect","builderTrainingTalentSelect","builderTrainingTalentSummary");
      fillTalentSelect("builderRecordedArtSphereSelect","builderRecordedArtTalentSelect","builderRecordedArtTalentSummary");
      return result;
    };
  }

  const priorSnapshot = hf05zuiR2eBuilderSnapshot;
  hf05zuiR2eBuilderSnapshot = function hf05zuiR2eBuilderSnapshotHF2() {
    const snapshot = priorSnapshot();
    const associations = readAssociations();
    snapshot.builder_patch = PATCH;
    snapshot.builder_version = document.getElementById("builderVersion")?.value || PACKAGE_VERSION;
    snapshot.target_factory = TARGET_FACTORY;
    snapshot.target_consumer = TARGET_CONSUMER;
    snapshot.training_source = snapshot.training_source || {};
    snapshot.training_source.associations = associations;
    snapshot.training_source.associated_spheres = associations.length ? [...new Set(associations.map((row) => row.sphere))] : [...snapshot.spheres];
    snapshot.training_source.talent_expressions = associations.flatMap((row) => (row.talents || []).map((talent) => ({ source_name:row.source_name || snapshot.training_source.name || "Primary manual / lineage", sphere:row.sphere, talent })));
    snapshot.training_source.selection_authority = "organizational_only_no_legality_validation";
    snapshot.recorded_arts.rows = (snapshot.recorded_arts.rows || []).map((row, index) => ({
      ...row,
      row_id: row.row_id || `recorded_art_${index + 1}`,
      talent_expressions: splitExpressions(row.reproduced_talent_expression),
      selection_authority: "organizational_only_no_legality_validation"
    }));
    snapshot.authoring_boundary = {
      input_class:"structured planning handoff",
      compiled_candidate:false,
      unlocked_fields_may_be_blank:true,
      factory_fills_missing_unlocked_content_during_commands:true,
      full_character_master_ledger_created_by_factory:true,
      full_build_json_surface_created_only_during_deterministic_compile:true
    };
    return snapshot;
  };

  const priorCompleteSheet = builderCompleteSheet;
  builderCompleteSheet = function builderCompleteSheetHF2() {
    const sheet = priorCompleteSheet();
    const snapshot = hf05zuiR2eBuilderSnapshot();
    sheet.builder_snapshot = snapshot;
    sheet.build.training_sources = [snapshot.training_source].filter((row) => row.name || row.doctrine || row.associations?.length);
    sheet.build.recorded_arts = snapshot.recorded_arts.rows;
    sheet.build.authoring_boundary = snapshot.authoring_boundary;
    return sheet;
  };

  const patchFiles = (pkg) => {
    const files = pkg.files || pkg.blocks || [];
    const byName = (name) => files.find((row) => row.name === name);
    const snapshot = hf05zuiR2eBuilderSnapshot();
    const trainingFile = { name:"Training_Source_and_Recorded_Arts.json", content:JSON.stringify({ schema:"HF05ZUI-R2K.3-HF2.TrainingRecordedArtsPlanning.v1", training_source:snapshot.training_source, recorded_arts:snapshot.recorded_arts, authority:"organizational helper; factory retains legality and compilation responsibility" }, null, 2) };
    const boundaryFile = { name:"AUTHORING_BOUNDARY.md", content:`# Authoring Boundary\n\nThis package is not a factory-compiled production candidate. It may contain blank unlocked fields and provisional preview records. ${TARGET_FACTORY} must create Character_Master_Ledger.json as authored truth, complete the character through Commands 1–4, and generate the full Build/ JSON surface only at deterministic Command 5. Do not use this package for combat admission or FINAL_RELEASE_READY classification.` };
    [trainingFile, boundaryFile].forEach((row) => {
      if (byName(row.name)) return;
      const manifestIndex = files.findIndex((item) => item.name === "package_manifest.json");
      files.splice(manifestIndex >= 0 ? manifestIndex : files.length, 0, row);
    });
    const builderSnapshot = byName("Builder_Snapshot.json"); if (builderSnapshot) builderSnapshot.content = JSON.stringify(snapshot, null, 2);
    const factoryBrief = byName("Factory_Handoff_Brief.json"); if (factoryBrief) factoryBrief.content = JSON.stringify(snapshot, null, 2);
    const authoredLock = byName("Authored_Mechanics_Lock.json"); if (authoredLock) authoredLock.content = JSON.stringify(snapshot, null, 2);
    const request = byName("Action_Generation_Request.json");
    if (request) { try { const data = JSON.parse(request.content); data.feature_sources = data.feature_sources || {}; data.feature_sources.training_source = snapshot.training_source; data.feature_sources.recorded_arts = snapshot.recorded_arts.rows; request.content = JSON.stringify(data, null, 2); } catch {} }
    const contract = byName("Handoff_Contract.json");
    if (contract) { try { const data = JSON.parse(contract.content); data.target_factory = TARGET_FACTORY; data.target_consumer = TARGET_CONSUMER; data.authoring_boundary = snapshot.authoring_boundary; data.training_recorded_art_composer = { sphere_to_multiple_talents:true, legality_validation:false, custom_source_specific_entries:true, structured_file:trainingFile.name }; contract.content = JSON.stringify(data, null, 2); } catch {} }
    const locks = byName("User_Locks.json");
    if (locks) { try { const data = JSON.parse(locks.content); data.target_factory = TARGET_FACTORY; data.training_source_associations = snapshot.training_source.associations; data.recorded_art_planning = snapshot.recorded_arts.rows; locks.content = JSON.stringify(data, null, 2); } catch {} }
    const readme = byName("README_FIRST.md");
    if (readme) readme.content = readme.content.replace(/HF05ZVK[-_ ]R1E/gi, TARGET_FACTORY).replace(/HF05ZUI[-_ ]R2H/gi, TARGET_CONSUMER) + "\n\nThis ZIP is a structured authoring handoff, not a compiled production character. Blank unlocked fields are intentional inputs for the factory to complete during Commands 1–4. Character_Master_Ledger.json and the full Build/ JSON suite must be created by the factory and sealed only at Command 5.\n";
    const prompt = byName("START_HERE_PROMPT.txt");
    if (prompt) prompt.content = prompt.content.replace(/HF05ZVK-R1E/g, TARGET_FACTORY).replace(/HF05ZUI-R2H/g, TARGET_CONSUMER).replace(/R1E Recorded Art floor/g, "R1H Recorded Art floor") + " Treat Training_Source_and_Recorded_Arts.json as organizational planning, not proof of legality. Fill all missing unlocked character fields during the normal command sequence; do not fabricate a precompiled Build surface before the canonical ledger is complete.";
    const manifest = byName("package_manifest.json");
    if (manifest) { try { const data = JSON.parse(manifest.content); data.builder_patch = PATCH; data.package_version = snapshot.builder_version || PACKAGE_VERSION; data.target_factory = TARGET_FACTORY; data.target_consumer = TARGET_CONSUMER; data.artifact_class = pkg.blocks ? "provisional_dashboard_preview_not_production" : "structured_factory_or_action_handoff_not_compiled"; data.compiled_candidate = false; data.combat_admission_ready = false; data.files = files.map((row) => row.name); manifest.content = JSON.stringify(data, null, 2); } catch {} }
    return pkg;
  };

  const priorDashboardPackage = builderPackageFiles;
  builderPackageFiles = function builderPackageFilesHF2() { return patchFiles(priorDashboardPackage()); };
  const priorHandoffPackage = hf05zuiR2ePackage;
  hf05zuiR2ePackage = function hf05zuiR2ePackageHF2(mode) { return patchFiles(priorHandoffPackage(mode)); };

  hf05zuiR2eFactoryPrompt = function hf05zuiR2eFactoryPromptHF2(snapshot = hf05zuiR2eBuilderSnapshot()) {
    return `Ingest the attached ${TARGET_CONSUMER} Factory Handoff ZIP and use ${TARGET_FACTORY} Phase 2I as the sole authoritative character factory. This is a structured planning handoff, not a compiled candidate. Treat explicit locks as immutable; fill missing unlocked fields during the six-command workflow. Use Training_Source_and_Recorded_Arts.json as an organizational Sphere → talent-expression map only, and perform normal legality/source checks in the factory. Create Character_Master_Ledger.json as authored truth, expand mechanics through Commands 2–4, and generate the complete Build/ JSON surface only at deterministic Command 5. Enforce the Recorded Art floor (${snapshot.recorded_arts.required_floor}), execution routing, Foundation lifecycle, Method–Foundation–item stacking, Forged Techniques, Emergency Forging, optional Command 4B Immortal Arts, and the ${TARGET_CONSUMER} consumer contract. Do not skip commands. Validate the handoff and wait for Command 1.`;
  };
  hf05zuiR2eActionOnlyPrompt = function hf05zuiR2eActionOnlyPromptHF2() {
    return `Ingest the attached ${TARGET_CONSUMER} Action-Only Handoff ZIP. Preserve all authored character mechanics. The Sphere → talent mappings are organizational context, not permission to change talents or Recorded Arts. Generate only executable action/reaction/passive/procedure packets, strictly required states, execution routing, and composite playbooks. Do not rebuild identity, advancement, Spheres, talents, Foundation, Method, Recorded Arts, Forged Techniques, Immortal Arts, equipment, or resource formulas.`;
  };

  const priorExport = hf05zuiR2eExport;
  hf05zuiR2eExport = function hf05zuiR2eExportHF2(mode) {
    const pkg = hf05zuiR2ePackage(mode);
    const bytes = createStoredZip(pkg.files);
    const suffix = mode === "factory" ? "Factory_Handoff" : "Action_Only_Handoff";
    downloadBlob(new Blob([bytes], { type:"application/zip" }), `${pkg.safeName}_${suffix}_HF05ZUI_R2K3_HF2.zip`);
    if (typeof toast === "function") toast(`${mode === "factory" ? "Factory" : "Action-only"} handoff ZIP exported.`);
  };

  const priorReset = hf05zuiR2eResetNewFields;
  hf05zuiR2eResetNewFields = function hf05zuiR2eResetNewFieldsHF2() {
    const result = priorReset();
    writeAssociations([]); writeRecordedLines([]); pending.manual = []; pending.art = []; renderPending("manual"); renderPending("art");
    return result;
  };

  const version = document.getElementById("builderVersion");
  if (version && (!version.value || /R2H-builder-v6/i.test(version.value))) version.value = PACKAGE_VERSION;
  const factoryCard = document.querySelector(".factory-export-card p");
  if (factoryCard) factoryCard.textContent = `Send the structured concept, locks, preferences, training map, and source constraints to ${TARGET_FACTORY} for the full six-command build.`;
  renderAssociationList(); renderRecordedList();
  try { updateBuilderPreview(); hf05zuiR2eRenderBuilder(); } catch {}
})();
