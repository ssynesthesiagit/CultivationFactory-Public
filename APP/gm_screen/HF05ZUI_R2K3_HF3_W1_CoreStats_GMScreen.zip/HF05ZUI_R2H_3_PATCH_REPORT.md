# HF05ZUI-R2H.3 Foundation Layout Patch Report

## Result

`PASS_HF05ZUI_R2H_3_UNIFIED_FOUNDATION_LAYOUT`

The unified 62-entry Foundation rewrite is now integrated into the Character Builder, Foundation library, and imported-character Foundation tab.

## Presentation contract

Each matched Foundation is displayed in this order:

1. Plain-language overview, visible sign, warning, Dao principle, profile, and current stage.
2. Character-specific imported values when viewing a candidate ZIP.
3. Cumulative current-stage feature quick reference.
4. Complete resource generation and spending loop.
5. Awakened, Integrated, Refined, and Perfected progression.
6. Compatibility, expression notes, and non-grants.
7. Burdens, hidden injuries, strains, and deviations.
8. Repair practices, Foundation Challenges, and lineage hooks.
9. Transparent source gaps.

The Builder’s raw summary and lifecycle fields remain available under **Advanced / export records** rather than competing with the readable view.

## Data architecture

- `foundation-catalog.js` remains the mechanical automation catalog.
- `FOUNDATION_READABLE_PROJECTION_v0_4B.json` is the readable source projection.
- `foundation-readable-catalog.js` packages that projection for offline browser use.
- `r2h3-foundation-layout.js` performs matching and rendering.
- Custom or unmatched Foundations retain the previous renderer.
- Imported character-specific values are shown first and remain more specific than catalog guidance.

## Performance

The Foundation library renders 62 compact cards. Full records are injected only when a user opens a card, preventing all 62 long records from occupying the initial DOM.

## Confirmed regressions

- 62/62 Builder Foundation previews render.
- An imported Iron Oath Skin candidate uses the unified tab and retains candidate-specific values.
- Background ability, Origin Insight, free grant, Sphere Insight, and variant behavior remain intact.
- The R1E Immortal-Art candidate imports through the real ZIP input with all 14 tabs, matching SHA-256, save/reload retention, and Pako fallback.
- No mechanics were changed.
