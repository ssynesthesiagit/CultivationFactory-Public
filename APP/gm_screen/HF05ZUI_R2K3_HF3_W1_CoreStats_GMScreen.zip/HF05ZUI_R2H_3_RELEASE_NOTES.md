# HF05ZUI-R2H.3 — Unified Foundation Layout

## Scope

This patch replaces the previous fragmented Foundation presentation with the unified player-and-GM reading order defined in `Tianxia_Foundation_User_Friendly_Template_v0_1` and the 62-entry readable projection `FOUNDATION_READABLE_PROJECTION_v0_4B.json`.

No Foundation mechanics, character-import rules, Builder grants, or combat contracts were changed.

## Character Builder

The Foundation preview now follows one consistent sequence:

1. Plain-language identity, visible sign, core warning, Dao principle, role, grade, Path, and complexity.
2. Current-stage quick reference using cumulative attained features.
3. Complete resource loop: maximum, generation trigger, timing, frequency, expiration, spend routes, same-event restriction, and anti-farming counterplay.
4. Awakened, Integrated, Refined, and Perfected progression.
5. Compatible Spheres, expression notes, and explicit non-grants.
6. Burdens, hidden injuries, strains, and deviations.
7. Repair practices, Foundation Challenges, and lineage hooks.
8. Transparent source gaps.

The generated summary and lifecycle textareas were moved into an expandable **Advanced / export records** area so the readable presentation remains primary.

## Character Viewer

The Foundation tab now shows:

- exact character-specific values imported from the candidate ZIP;
- the matching unified catalog record;
- current stage and all cumulative attained features;
- full resource and risk procedures;
- recovery, challenge, lineage, and boundary information.

Character-specific imported values appear before catalog guidance and remain authoritative when more specific.

Custom or unmatched Foundations retain the prior R2H renderer rather than being forced into an incorrect catalog match.

## Foundation Library

All 62 catalog selections use compact unified cards. Complete entries are loaded only when their details control is opened, reducing initial DOM and mobile rendering cost.

## Catalog status

- 30 authoritative non-Chakra Foundations: complete unified rules entries.
- 32 Chakra Foundations: clearly marked theoretical drafts with no invented mechanics.
- Source gaps in incomplete entries remain visible.

## Compatibility

- Consumer contract: `HF05ZUI-R2H`
- Factory: `HF05ZVK-R1E`
- Combat Bootstrap: `HF05ZN-R2C`
- Builder package version: unchanged from R2H.2
