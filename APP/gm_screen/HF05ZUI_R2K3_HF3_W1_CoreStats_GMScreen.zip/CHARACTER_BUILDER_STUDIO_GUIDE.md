# HF05ZUI-R2H.2 Character Builder Guide

## 1. Select a Background

1. Open **Character Builder** and select one of the 31 published Backgrounds.
2. Review the Background summary, skills, tools/languages, equipment, social feature, and suggested Origin Insights.
3. Complete all three Background choice groups below the Background selector.

### Background ability-score increase

Choose one of the six legal arrangements generated from the Background's three listed abilities:

- +2 to one listed ability; or
- +1 to two different listed abilities.

The STR–CHA inputs remain the character's **pre-Background point-buy scores**. The final-score strip shows the adjusted values. Point-buy validation continues to use the pre-Background scores.

### Free Background Sphere and talent

Choose one legal grant card. The Sphere is added automatically to **Spheres and Talents**, and the talent is checked and labeled **Free Background grant**. It is exported once and does not consume an ordinary talent selection. Active, dormant, and preparatory grant status remains visible and exportable.

### Background Origin Insight

Choose one printed Origin Insight suggested by the Background. The Builder then:

- fills the Origin Insight name and full mechanics;
- locks those fields while the Background choice is active;
- marks the same Insight as selected and Background-locked in **Insights**;
- exports it as the character's level-0 Origin Insight without counting it against ordinary talent or training choices.

Changing the Background clears the prior Background ability and Origin choices so an illegal combination cannot persist.

## 2. Select Spheres, talents, and variants

1. Search or choose a Sphere and press **Add Sphere**.
2. Search or filter the selectable talent cards by Realm band.
3. Select ordinary talents. The Background-granted talent stays checked and cannot be removed while its grant remains active.
4. Review **Sphere Variants and Drawback Scriptures** beneath the talent browser.
5. Select any printed variant that applies. The complete source text remains available as a tooltip, and its drawbacks/exclusivity remain binding.

Manual entries should be used only for source-specific or GM-approved material absent from the current catalog.

## 3. Select Insights

The dedicated **Insights** section supports four scopes:

- Selected Sphere Insights
- All 50 General / Origin Insights
- All 85 Sphere Insight lists
- Origin + selected Sphere Insights

Use search to narrow the cards. The chosen Background Origin Insight is visible and checked but locked; select Sphere Cultivation Insights normally. Manual/source-specific Insights remain available in the expandable manual-entry section.

## 4. Select a Foundation

Use **All current Foundations** to browse FS01–FS30 and CH01–CH32 together. Foundation previews show:

1. player-facing identity, sign, benefit, and warning;
2. current-stage mechanics, resources, actions, and effects;
3. expandable GM burdens, injuries, deviations, treatment, and counterplay;
4. compatibility and explicit boundaries.

## 5. Draft and export behavior

Draft save/load preserves:

- selected Spheres and talents;
- Background free grant;
- Background ability-score increase;
- Background Origin Insight;
- selected Sphere Insights;
- selected Sphere variants.

Both Factory Handoff and Action-Only Handoff exports include the selected Insights, variants, and Background ability increase. The character viewer/importer remains the HF05ZUI-R2H consumer.

---

## HF05ZUI-R2H.3 Foundation reading order

The Foundation selector now treats the readable preview as the primary record. Read it from top to bottom:

1. **Overview:** what changes, the visible sign, the principal warning, role, Path, and Dao principle.
2. **Current Stage:** cumulative feature cards for every attained stage. The effect is always visible; timing, limits, targets, and counterplay remain attached to the same feature.
3. **Foundation Resource:** generation, timing, maximum, expiration, spending, same-event restrictions, and anti-farming guidance.
4. **Complete Progression:** Awakened, Integrated, Refined, and Perfected entries. Earlier benefits remain unless explicitly replaced.
5. **Compatibility:** legal expressions and explicit things the Foundation does not grant.
6. **Risks:** burdens, hidden injuries, strains, and deviations.
7. **Recovery and Advancement:** repair practices, Foundation Challenges, and lineage hooks.
8. **Source Gaps:** any missing source procedures remain visible rather than being filled with invented rules.

The old Foundation Record and Foundation Lifecycle textareas now sit under **Advanced / export records**. They remain available for package generation but should not be used as the primary reading surface.

In the Character Viewer, exact candidate-specific Foundation values appear first. The catalog record follows as the general rules reference. When the two differ, the more specific imported character value controls.

## R2K.3 HF1 talent browsing

- Every canonical 85-Sphere talent card shows a short source-derived effect summary.
- Hover over a talent card with a mouse to display the complete authored talent rule, using the same native tooltip behavior as Background Origin Insights.
- Cultivation Insights are selected only in the dedicated Insight section.
- Sphere variants and drawback scriptures are selected only in the dedicated variant section.
- The 40 Chakra-extension rows retain source-reference text because their complete authored talent packet is not present in this release corpus.


## R2K.3 HF2 Training Sources and Recorded Arts

- Use **Manual Sphere and Talent Map** to associate a martial manual or lineage with one Sphere and one or more talent expressions.
- Use **Recorded Art Composer** to record `Art Name → Sphere → Talent + Talent`, with optional tactical role and source notes.
- These selectors are organizational only. They do not prove acquisition legality, prerequisites, Realm access, source access, or Recorded Art classification. The factory performs those checks.
- Custom or source-specific expressions absent from the catalog remain supported.
- Raw pipe-delimited Recorded Art rows remain available under **Advanced / manual Recorded Art rows**.

The Factory Handoff ZIP is intentionally a structured planning package rather than a compiled character. It may contain blank unlocked fields. HF05ZVK-R1H creates `Character_Master_Ledger.json`, completes missing unlocked content through Commands 1–4, and generates the full `Build/` JSON surface only during deterministic Command 5. The viewer/dashboard export is a provisional local preview and must not be mistaken for a factory-sealed production candidate.
