# HF05ZUI-R2K — Companions, Spirits & Beasts

HF05ZUI-R2K expands the persistent-companion surface into a full secondary character sheet for bonded spirits, Beastmaster beasts, awakened beasts, mounts, constructs, Item Spirits, and future companion categories.

## Visible changes

- Renames the tab to **Companions, Spirits & Beasts**.
- Adds a roster showing type, status, HP, and turn model.
- Adds readable appearance, personality, voice, relationship, origin, goals, fears, loyalties, taboos, and out-of-combat behavior.
- Adds AC, HP, speed, abilities, saves, skills, senses, languages, resistances, resources, conditions, and injuries.
- Separates spirit bond/offerings from beast training/care.
- Shows exact command economy, independent Actions, 0 HP consequences, healing or reconstruction, progression, equipment, and forms.
- Adds mutable companion HP and status with compact save/reload preservation.
- Links companion and beast Actions back to their owning sheet with source badges.
- Keeps Source CL, Realm Suppression, canonical IDs, packets, and coverage mappings under technical provenance rather than in the main reading flow.

No Path, Subpath, Insight, item, or combat mechanics were changed.
