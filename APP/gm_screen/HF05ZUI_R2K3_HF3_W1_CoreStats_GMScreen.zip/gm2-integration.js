(function(global){
  'use strict';
  const ERROR_MESSAGES={
    GM2_INCOMPLETE_STAGE1_PROJECT:'This is an incomplete Stage 1 Factory project, not a completed Character Package.',
    GM2_UNSUPPORTED_PROFILE:'This character package uses a model format this GM Screen does not support.',
    GM2_MODEL_AUTHORITY_CONFLICT:'The package contains conflicting authoritative GM models.',
    GM2_MODEL_STRUCTURALLY_INVALID:'The selected GM model is missing required character data.',
    GM2_CONSUMER_TOO_OLD:'This character requires a newer GM Screen.'
  };
  const text=b=>new TextDecoder('utf-8').decode(b instanceof Uint8Array?b:new Uint8Array(b));
  const json=e=>{try{return JSON.parse(text(e.bytes));}catch(_){return null;}};
  function detect(m,runtime){
    if(!m||typeof m!=='object') return null;
    if(m.schema==='Tianxia_GM_Character_Model_v2'&&m.schema_version==='2.0.0') return 'canonical_v2';
    if(m.schema_version!=='Tianxia_GM_Character_Model_v1') return null;
    const i=m.identity||{},s=m.stats||{};
    if(Number.isInteger(i.CL)&&Number.isFinite(s.hp_current)&&Number.isFinite(s.hp_max)&&Number.isFinite(s.ac_active)) return 'legacy_phase2h_v1';
    if(Number.isInteger(i.cultivation_level)&&s.hit_points&&Number.isFinite(s.hit_points.maximum)&&s.armor_class&&Number.isFinite(s.armor_class.value)) return runtime?'fire_qi_runtime_ready_v1':'fire_qi_c2c1_v1';
    return null;
  }
  function normalize(m,p){
    if(p==='canonical_v2') return {schema:'Tianxia_GM_Normalized_View_Model_v2',source_profile:p,identity:m.identity,core_stats:{cultivation_level:m.cultivation?.cultivation_level,realm:m.cultivation?.realm,hit_points:m.combat?.hit_points,armor_class:m.combat?.armor_class,speed_ft:m.combat?.speed_ft,attack_bonus:m.combat?.attack_bonus,save_dc:m.combat?.save_dc,ability_scores:m.ability_scores||{},skills:m.skills||[],resources:m.cultivation?.resources||[]},cultivation:m.cultivation,surfaces:{spheres:m.spheres||[],talents:m.talents||[],actions:m.actions||[],reactions:m.reactions||[],methods:m.methods||[],equipment:m.equipment||[],states:m.states||[],companions:m.companions||[]},readiness:m.readiness};
    const i=m.identity||{},s=m.stats||{};
    if(p==='legacy_phase2h_v1') return {schema:'Tianxia_GM_Normalized_View_Model_v2',source_profile:p,identity:{display_name:i.display_name||i.name},core_stats:{cultivation_level:i.CL,realm:i.realm_display||i.realm,hit_points:{current:s.hp_current,maximum:s.hp_max},armor_class:s.ac_active,speed_ft:s.speed_ft,attack_bonus:s.primary_attack_bonus,save_dc:s.cultivation_save_dc,ability_scores:s.ability_scores||{},skills:s.skills||[],resources:[{name:s.primary_resource_name||'Qi',current:s.qi_current??s.primary_resource_current,maximum:s.qi_max??s.primary_resource_max}]},cultivation:{path:i.path||'Qi Cultivation',primary_method:m.method||{state:'unavailable'}},surfaces:m,readiness:{gm_ready:true,contract_valid:true}};
    const hp=s.hit_points||{},ac=s.armor_class||{},sp=s.speed||{},ers=m.equipment_resources_states||{};
    let resources=Array.isArray(ers.resources)?ers.resources:Object.values(ers.resources||{}).flatMap(x=>x?.definitions||[x]);
    const normalResource=(row,def={})=>({name:row?.name||row?.resource_name||def.name||s.primary_resource_name||'Qi',current:row?.current??row?.build_state_current??def.current??s.primary_resource_current,maximum:row?.maximum??row?.max??def.maximum??def.max??s.primary_resource_max,path_id:row?.path_id||def.path_id});
    resources=resources.filter(x=>x&&typeof x==='object').map(x=>normalResource(x,(x.definitions||[])[0]||{}));
    if(!resources.length&&s.primary_resource){const pr=s.primary_resource,def=(pr.definitions||[])[0]||{};resources=[normalResource(pr,def)];}
    if(!resources.length&&(s.primary_resource_name||s.primary_resource_current!=null||s.primary_resource_max!=null))resources=[normalResource({}, {})];
    return {schema:'Tianxia_GM_Normalized_View_Model_v2',source_profile:p,identity:{display_name:i.display_name||i.name},core_stats:{cultivation_level:i.cultivation_level,realm:i.realm_display||i.realm,hit_points:{current:hp.current??hp.build_state_current,maximum:hp.maximum},armor_class:ac.value,speed_ft:sp.walking??sp.walking_ft??sp.value,attack_bonus:s.cultivation_attack_bonus||s.primary_attack_bonus,save_dc:s.cultivation_save_dc||s.save_dc,ability_scores:s.abilities||{},skills:s.skills||[],resources},cultivation:{path:i.path,primary_method:(m.method||{state:'explicit_none'}),subpaths_traditions:[m.paths_subpaths_insights?.subpath].filter(Boolean),foundation:m.foundation||{state:'explicit_none'}},surfaces:m,readiness:{gm_ready:true,contract_valid:true}};
  }

  // The existing renderer consumes its long-lived internal character view.
  // This is the sole bridge: every dialect first becomes the accepted GM2
  // normalized view, and only that normalized view is projected here.
  function bridgeNormalizedView(v){
    const c=v.core_stats||{}, cult=v.cultivation||{}, surf=v.surfaces||{};
    const hp=c.hit_points||{};
    const allActions=surf.actions||[];
    const explicitReactions=surf.reactions||[];
    const reactions=explicitReactions.length?explicitReactions:allActions.filter(a=>String(a.category||a.economy||a.action_type||'').toLowerCase()==='reaction');
    const actions=explicitReactions.length?allActions:allActions.filter(a=>String(a.category||a.economy||a.action_type||'').toLowerCase()!=='reaction');
    return {
      schema_version:'Tianxia_GM_Character_View_Model_v2',
      identity:{display_name:v.identity?.display_name||'Unnamed character',cultivation_level:c.cultivation_level,realm:c.realm,realm_display:c.realm,path:(cult.paths||[]).find(x=>x.primary)?.name||cult.path||''},
      stats:{hit_points:{current:hp.current,maximum:hp.maximum},armor_class:{value:c.armor_class},speed:{walking:c.speed_ft},cultivation_attack_bonus:c.attack_bonus,cultivation_save_dc:c.save_dc,abilities:c.ability_scores||{},skills:c.skills||[]},
      method:cult.primary_method||{state:'explicit_none'}, foundation:cult.foundation||{state:'explicit_none'},
      paths_subpaths_insights:{paths:cult.paths||[],subpaths_traditions:cult.subpaths_traditions||[]},
      equipment_resources_states:{resources:c.resources||[],equipment:surf.equipment||[],states:surf.states||[]},
      actions, reactions, spheres_talents:{spheres:surf.spheres||[],talents:surf.talents||[]},
      capability_readiness:v.readiness||{}, metadata:{gm2_normalized_bridge:true,source_profile:v.source_profile}
    };
  }

  function preview(v,p,migrated){const c=v.core_stats||{},cult=v.cultivation||{},paths=Array.isArray(cult.paths)?cult.paths:[];const primaryPath=paths.find(x=>x?.primary)||paths.find(x=>Number(x?.attainment_level)>0);const resources=Array.isArray(c.resources)?c.resources:[];const r=resources.find(x=>x?.primary)||resources.find(x=>primaryPath&&x?.path_id===primaryPath.path_id)||resources[0]||{};const current=r.current??r.build_state_current;const maximum=r.maximum??r.max;return {name:v.identity?.display_name||'Unnamed character',cultivation_level:c.cultivation_level,realm:c.realm,source_profile:p,hp:c.hit_points,ac:c.armor_class,speed_ft:c.speed_ft,primary_resource:r.name?`${r.name} ${current}/${maximum}`:'Not recorded',path:cult.path||primaryPath?.name||'Not recorded',path_attainment:primaryPath?.attainment_level??null,primary_method:cult.primary_method?.name||cult.primary_method?.value?.name||'None recorded',migration_used:migrated,readiness:v.readiness?.gm_ready===false?'Incomplete':'Ready'};}
  function failure(code,details){const e=new Error(ERROR_MESSAGES[code]||'The character package could not be imported.');e.code=code;e.details=details||{};throw e;}
  function inspectEntries(entries){
    const map=new Map(entries.filter(e=>!e.skipped).map(e=>[String(e.name).replace(/\\/g,'/'),e]));
    const project=json(map.get('project.json')||{}), pm=json(map.get('manifest.json')||{});
    if(pm?.schema_version==='TianxiaFoundry.ProjectExport.v1') failure('GM2_INCOMPLETE_STAGE1_PROJECT',{project_id:pm.project_id,status:project?.status});
    const manifest=json(map.get('PACKAGE_MANIFEST.json')||{})||{};
    const runtime=map.has('combat/Combat_Sheet.json');
    const rawCandidates=[];
    for(const [path,e] of map){if(!/\.json$/i.test(path))continue;const m=json(e);const p=detect(m,runtime);if(p)rawCandidates.push({path,model:m,profile:p});}
    if(!rawCandidates.length) failure('GM2_UNSUPPORTED_PROFILE');
    const ref=manifest.gm_model?.path;
    const stable=v=>{if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])]));return v;};
    const semanticKey=m=>JSON.stringify(stable(m));
    const pathScore=c=>(c.path===ref?1000:0)+(c.profile==='canonical_v2'?500:0)+(c.path==='Tianxia_GM_Character_Model_v1.json'?200:0)+(c.path.includes('/')?0:50);
    // Identical preserved source copies are one semantic candidate. Keep the
    // manifest-selected path, otherwise the highest-scoring root path.
    const bySemantic=new Map();
    for(const c of rawCandidates){const key=semanticKey(c.model), prior=bySemantic.get(key);if(!prior||pathScore(c)>pathScore(prior)||(pathScore(c)===pathScore(prior)&&c.path.localeCompare(prior.path)<0))bySemantic.set(key,c);}
    const candidates=[...bySemantic.values()].sort((a,b)=>pathScore(b)-pathScore(a)||a.path.localeCompare(b.path));
    if(candidates.length>1&&pathScore(candidates[0])===pathScore(candidates[1])) failure('GM2_MODEL_AUTHORITY_CONFLICT',{candidates:candidates.map(x=>x.path)});
    const sel=candidates[0],view=normalize(sel.model,sel.profile);if(!view.identity?.display_name||!Number.isFinite(view.core_stats?.cultivation_level))failure('GM2_MODEL_STRUCTURALLY_INVALID');
    const rendererView=bridgeNormalizedView(view);
    return {status:sel.profile==='canonical_v2'?'DIRECT_V2':'MIGRATED',source_profile:sel.profile,selected_path:sel.path,model:sel.model,normalized_view:view,renderer_view:rendererView,preview:preview(view,sel.profile,sel.profile!=='canonical_v2')};
  }
  global.TianxiaGM2={detectProfile:detect,inspectEntries,normalizeView:normalize,bridgeNormalizedView,errorMessages:ERROR_MESSAGES};
})(typeof window!=='undefined'?window:globalThis);
