# HF05ZUI-R2I Release Notes

HF05ZUI-R2I is the Phase 2E canonical-consumer update.

## Added

- 26-sidecar import and compact-save retention.
- 18-tab character viewer.
- Paths & Subpaths, Insights, Companions & Spirits, Equipment, Resources/States/Suppression, and expanded Diagnostics surfaces.
- Authoritative Equipment Ledger R2 item cards and mutable campaign state.
- Source-linked Actions and typed item acquisition reconstruction.
- Full selected-rule coverage and suppression diagnostics.

## Corrected during acceptance

- Numeric item edits save on browser `input` events.
- Compact saves rebuild canonical models from retained blocks, reducing the tested payload to 4.26 MiB.
- Long canonical IDs and diagnostics no longer overlap.
- Technical records are collapsed behind provenance drawers.
- Insight ability increases and prerequisites are recovered from canonical text when projections omit structured fields.

## Compatibility

No Factory CML schema or compiled character schema change is introduced. R2I is a downstream importer/view-model/rendering update over Phase 2E output.
