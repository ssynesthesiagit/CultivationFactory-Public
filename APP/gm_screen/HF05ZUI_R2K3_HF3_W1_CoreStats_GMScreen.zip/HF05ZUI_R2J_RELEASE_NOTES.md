# HF05ZUI-R2J — Path and Subpath Readability UX

R2J is a focused presentation patch over HF05ZUI-R2I. It does not alter Phase 2E import, save-state, equipment, companion, diagnostics, or execution schemas.

## Changes

- Realm Suppression moved out of the primary Path reading flow and into a secondary, collapsed reference.
- Suppression becomes prominent only when Effective CL is actually lower than character CL.
- Path and Subpath features are grouped by acquisition CL.
- Every feature uses a readable plain-language summary and properly formatted complete rules text.
- Full canonical Path and specialization rules are resolved from the P2A/P2B indexes and source line ranges, avoiding the 700-character character-ledger summary cap.
- Activation, trigger, range, cost, duration, and limit are surfaced as quick-reference facts when printed.
- Canonical IDs, execution mappings, Source CL, suppression behavior, packets, and runtime targets moved into Technical Details.
- Added Path and specialization identity cards with key ability, resource, Hit Die, access class, and practical role.

## Change boundary

No rules mechanics changed. No save-state schema changed. No Factory character-output schema changed.
