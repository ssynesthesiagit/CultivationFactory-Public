# HF05ZUI-R2K.3 HF3 — Foundation 34 Integration

- Replaces the legacy 30-row generic Foundation catalog with 34 families and 86 selectable Path expressions.
- Adds expression-aware builder selection, legacy family/path routing, stage-aware resource reconciliation, exact Aura/Domain Seed rendering, and updated acceptance counts.
- Retains the archived 32 theoretical Chakra records outside the playable arrays.
- Consolidated audit: PASS_CONSOLIDATED_ACCEPTANCE.
