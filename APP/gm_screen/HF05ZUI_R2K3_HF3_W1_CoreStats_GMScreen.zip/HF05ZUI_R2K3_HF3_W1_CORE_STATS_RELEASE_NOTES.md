# HF05ZUI-R2K.3-HF3-W1 — Portable Character Core-Stat Consumer Repair

This bounded W1 repair changes only supported GM character-model discovery and display normalization.

- Prefer `Tianxia_GM_Character_View_Model_v2.json` when present.
- Normalize its `core_stats` structure into the established 18-tab renderer contract.
- Fall back to `Tianxia_GM_Character_Model_v1.json.stats` for supported v1 packages.
- Preserve historical aliases and all non-core display surfaces.
- Preserve the attached character’s authoritative Qi build state (`2/15`).

No character mechanics, combat runtime, encounter data, or CPK-1 schemas are changed.
Native Windows/WebView2 owner acceptance remains pending.
