# HF05ZUI-R2H.4 — Semantic Diagnostics and Tournament-Ready Character Reading

This patch consumes HF05ZVK-R1F semantic evidence and displays character legality separately from renderer integrity. It adds a 10–14 card Signature Loadout before the searchable full action library, puts human-readable Sphere/talent and Recorded Art rules before compiler metadata, reconciles imported Foundation values against the 30 authoritative Foundation catalog, and renders empty defenses or senses as `None`.

The 32 theoretical Chakra Foundations remain archived but are excluded from playable Builder choices, acceptance, and tournament admission.

Real acceptance now binds the exact candidate ZIP to the canonical master ledger, rules-selection packets, semantic report, Signature Loadout, Foundation reconciliation, all fourteen tabs, projection fidelity, and save/reload retention.
