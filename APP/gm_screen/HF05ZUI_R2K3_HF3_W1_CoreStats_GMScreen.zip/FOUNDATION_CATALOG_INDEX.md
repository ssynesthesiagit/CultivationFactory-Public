# Active Foundation Catalog — HF05ZUI-R2H.4

The live Character Builder exposes the **30 authoritative non-Chakra Foundations**. Their unified player/GM descriptions, stage progression, resources, risks, repairs, challenges, and counterplay are used by the Builder and imported-character Foundation tab.

The **32 theoretical Chakra Foundation drafts are archived only**. They are not selectable, cannot pass semantic acceptance, and cannot enter tournament combat until their executable mechanics are authored and approved.
