#!/usr/bin/env python3
"""Non-browser release QA for HF05ZUI-R2K.3-HF1 Builder Talent hotfix."""
from __future__ import annotations
import hashlib
import json
import pathlib
import re
import subprocess
import sys
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "HF05ZUI_R2K3_HF1_BUILDER_TALENT_QA.json"


def load_js_assignment(name: str) -> Any:
    raw = (ROOT / name).read_text(encoding="utf-8").strip()
    rhs = raw.split("=", 1)[1].strip()
    if rhs.endswith(";"):
        rhs = rhs[:-1]
    return json.loads(rhs)


def compact(value: str) -> str:
    value = str(value or "").lower().replace("’", "'").replace("‘", "'")
    value = re.sub(r"\band\b", "", value)
    return re.sub(r"[^a-z0-9]+", "", value)


def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: Any = None) -> None:
        checks.append({"name": name, "pass": bool(ok), "detail": detail})

    catalog = load_js_assignment("sphere-talent-catalog.js")
    insight_catalog = load_js_assignment("insight-catalog.js")
    entries = [(sphere, talent) for sphere in catalog for talent in sphere.get("talents", [])]

    check("catalog_is_array", isinstance(catalog, list))
    check("sphere_count_90", len(catalog) == 90, len(catalog))
    check("selector_entry_count_3761", len(entries) == 3761, len(entries))

    empty_short = [(s.get("name"), t.get("name")) for s, t in entries if not str(t.get("short_description") or t.get("summary") or "").strip()]
    empty_full = [(s.get("name"), t.get("name")) for s, t in entries if not str(t.get("full_text") or "").strip()]
    check("every_card_has_short_description", not empty_short, empty_short[:20])
    check("every_card_has_hover_text", not empty_full, empty_full[:20])

    bad_summary_re = re.compile(
        r"^(?:action|bonus action|reaction|passive) talent\.?$|^action type:|^factory routing:|^factory combat bucket:",
        re.I,
    )
    bad_summaries = [
        (s.get("name"), t.get("name"), t.get("short_description"))
        for s, t in entries
        if bad_summary_re.search(str(t.get("short_description") or "").strip())
    ]
    check("no_routing_only_or_action_talent_summaries", not bad_summaries, bad_summaries[:20])

    dedicated: dict[str, set[str]] = {}
    for row in insight_catalog.get("spheres", []):
        dedicated[compact(row.get("sphere"))] = {
            compact(item.get("name"))
            for item in [*(row.get("insights") or []), *(row.get("variants") or [])]
        }
    overlap = [
        (s.get("name"), t.get("name"))
        for s, t in entries
        if compact(t.get("name")) in dedicated.get(compact(s.get("name")), set())
    ]
    check("no_dedicated_insight_or_variant_in_talent_selector", not overlap, overlap[:30])

    source_backed = [(s, t) for s, t in entries if t.get("source_line")]
    fallback = [(s, t) for s, t in entries if not t.get("source_line")]
    non_chakra_fallback = [(s.get("name"), t.get("name")) for s, t in fallback if s.get("catalog") != "chakra_only"]
    check("canonical_source_backed_entries_3721", len(source_backed) == 3721, len(source_backed))
    check("chakra_extension_fallback_entries_40", len(fallback) == 40, len(fallback))
    check("all_fallbacks_are_chakra_extension", not non_chakra_fallback, non_chakra_fallback)

    poison = next((row for row in catalog if row.get("name") == "Poison"), None)
    poison_map = {t.get("name"): t for t in (poison or {}).get("talents", [])}
    expected_poison = {
        "Poison Sense": "Your Appraise the Venom becomes a passive sense.",
        "Irritating Dust": "On a failed save, the creature cannot take Reactions and has Disadvantage on Wisdom (Perception) checks until the start of your next turn.",
        "Toxic Cloud": "On a failed save, the creature takes Poison or Acid damage and becomes Poisoned until the start of its next turn.",
    }
    poison_failures = {
        name: poison_map.get(name, {}).get("short_description")
        for name, expected in expected_poison.items()
        if poison_map.get(name, {}).get("short_description") != expected
    }
    check("poison_regression_samples", not poison_failures, poison_failures)
    check("poison_insight_removed", "Venom Body" not in poison_map)
    check("poison_variant_removed", "Venom Body Scripture" not in poison_map)

    builder_text = (ROOT / "r2h-builder.js").read_text(encoding="utf-8")
    check("builder_filters_dedicated_non_talents", "isDedicatedNonTalent" in builder_text and "selectableTalents" in builder_text)
    check("builder_exports_filter_stale_saved_non_talents", "isDedicatedNonTalent(sphere, name)" in builder_text)
    check("builder_hover_uses_full_text", "talent.full_text || talent.summary" in builder_text and 'data-builder-talent-tooltip="full-source"' in builder_text)
    check("builder_search_includes_full_text", "talent.full_text || \"\"" in builder_text)

    index_text = (ROOT / "index.html").read_text(encoding="utf-8")
    check("hotfix_cache_busting", "20260714-r2k3-hf1-talents" in index_text)

    node = subprocess.run(["node", "--check", str(ROOT / "r2h-builder.js")], capture_output=True, text=True)
    check("r2h_builder_javascript_syntax", node.returncode == 0, (node.stderr or node.stdout).strip())

    json_files = [
        "GM_SCREEN_BUILD_MANIFEST.json",
        "BUILDER_OUTPUT_CONTRACTS.json",
        "SPHERE_TALENT_CATALOG_SUMMARY.json",
        "HF05ZUI_R2K3_BUILDER_TALENT_CATALOG_HOTFIX_AUDIT.json",
    ]
    json_errors = {}
    for name in json_files:
        try:
            json.loads((ROOT / name).read_text(encoding="utf-8"))
        except Exception as exc:  # pragma: no cover - release QA reporting
            json_errors[name] = str(exc)
    check("release_json_files_parse", not json_errors, json_errors)

    result = {
        "schema": "HF05ZUI-R2K.3-HF1.BuilderTalentQA.v1",
        "release": "HF05ZUI-R2K.3-HF1",
        "qa_class": "non_browser_static_and_catalog_regression",
        "acceptance_boundary_changed": False,
        "combat_bootstrap_change_required": False,
        "summary": {
            "checks": len(checks),
            "passed": sum(1 for row in checks if row["pass"]),
            "failed": sum(1 for row in checks if not row["pass"]),
            "sphere_count": len(catalog),
            "selector_entries": len(entries),
            "source_backed_full_descriptions": len(source_backed),
            "chakra_extension_fallback_descriptions": len(fallback),
            "dedicated_insight_variant_overlap": len(overlap),
        },
        "known_source_limitation": {
            "scope": "Chakra-only extension catalog",
            "entry_count": len(fallback),
            "reason": "The supplied Phase 2I rules corpus does not contain the complete authored Chakra talent source packet for these rows. The UI retains explicit source-reference text rather than inventing mechanics.",
            "affected_spheres": sorted({s.get("name") for s, _ in fallback}),
        },
        "checks": checks,
        "file_hashes_before_release_seal": {
            name: sha256(ROOT / name)
            for name in ["sphere-talent-catalog.js", "r2h-builder.js", "index.html"]
        },
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], indent=2))
    if result["summary"]["failed"]:
        for row in checks:
            if not row["pass"]:
                print("FAIL", row["name"], row.get("detail"), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
