// Optional extension hook for Tianxia GM Dashboard.
// The active HF05D packet keeps the canonical sphere catalogue inside app.js.
