# HF05ZUI-R2K.3 HF1 — Builder Talent Readability and Classification

Open `index.html` or `Open_Dao_Dashboard.bat`.

## Builder talent hotfix

- all 3,721 canonical 85-Sphere talent cards have a meaningful short description derived from the authored rule;
- hovering a canonical talent card exposes its complete authored talent text;
- Cultivation Insights appear only in the dedicated Insight selector;
- Sphere variants and drawback scriptures appear only in their dedicated selector;
- stale saved drafts cannot export those dedicated rows as talents;
- the R2K.3 acceptance schema and combat-consumer boundary are unchanged.

The 40 retained Chakra-extension rows have explicit source-reference text rather than fabricated mechanics because their complete authored source packet is not present in the supplied Phase 2I corpus.

## Matching Factory

- Factory: **HF05ZVK-R1H Phase 2I**
- Consumer: **HF05ZUI-R2K.3**
- Character viewer tabs: **18**
- Save schema: `HF05ZUI-R2I.compact-save.v2`
- Native acceptance schema: `HF05ZUI-R2K.RealAcceptanceReport.v1`

## Primary surfaces

- readable Path and Subpath feature progression;
- Cultivation Insights and execution mappings;
- Companions, Spirits & Beasts character sheets;
- authoritative Equipment Ledger R2 item cards and mutable state;
- Actions, Recorded Arts, Forged Techniques, and Immortal Arts;
- Source CL and Realm Suppression, secondary unless active;
- universal execution-coverage and retention diagnostics.

## Save-state support

Compact save/reload preserves the 26 Phase 2E/2F sidecars and mutable item, spirit, and beast state.

## Phase 2I compatibility seal

Command 6 tests the exact candidate ZIP against this 18-tab consumer. Python and Chromium use a cross-runtime semantic hash contract, including integral JSON numbers such as `20.0` and `20`.

Inherited R2H–R2K reports remain in this directory as provenance.


## HF05ZUI-R2K.3-HF2 Builder composer

The Character Builder now provides catalog-driven **Sphere → talent + talent** composition for martial training sources and Recorded Arts. The helper is organizational only; it does not validate acquisition legality, prerequisites, or source access. Factory handoff exports are explicitly marked as planning inputs rather than compiled candidates. HF05ZVK-R1H creates the canonical ledger and full Build JSON surface during its normal six-command workflow.
## R2K.3-HF2 Character Builder composer

Training Sources and Recorded Arts now support catalog-driven `Manual / Source → Sphere → Talent + Talent` planning. These mappings are organizational only; HF05ZVK-R1H remains responsible for legality, prerequisites, acquisition, canonical ledger authoring, and deterministic compilation. Factory Handoff exports are structured planning inputs rather than compiled candidates.

