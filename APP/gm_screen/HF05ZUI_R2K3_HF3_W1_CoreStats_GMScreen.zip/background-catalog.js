window.TIANXIA_BACKGROUND_CATALOG = {
  "Abandoned Orphan": {
    "name": "Abandoned Orphan",
    "region": "Any Region",
    "description": "You grew up in alleys, ruins, kitchens, docks, roadside shrines, or abandoned courtyards. No one gave you a place. You survived by noticing danger early, hiding what mattered, and taking what you needed before someone stronger took it first.",
    "ability_options": [
      "Dexterity",
      "Wisdom",
      "Charisma"
    ],
    "skills": [
      "Deception",
      "Sleight of Hand"
    ],
    "tools": [
      "You gain proficiency with thieves' tools and one language of your choice."
    ],
    "tools_text": "You gain proficiency with thieves' tools and one language of your choice.",
    "feature": "You know how people treat the powerless. Other outcasts may recognize you as one of their own, but officials, guards, and respectable families rarely assume the best of you.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Scoundrel",
        "talent": "Grifter’s Hands",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Grifter’s Hands (GRIFTER’S HANDS) talent."
      },
      {
        "id": "2",
        "sphere": "Scoundrel",
        "talent": "Hidden Tool Cache",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Hidden Tool Cache (HIDDEN TOOL CACHE) talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      }
    ],
    "grant_guidance": "Choose one: - Scoundrel Sphere. You gain the Scoundrel sphere and the Grifter’s Hands (GRIFTER’S HANDS) talent. - Scoundrel Sphere. You gain the Scoundrel sphere and the Hidden Tool Cache (HIDDEN TOOL CACHE) talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent.",
    "kit": [
      "You begin with worn common clothes, a small knife, thieves' tools, a bedroll, a hidden pouch, three days of poor rations, and one keepsake from the life you lost or never had."
    ],
    "equipment_text": "You begin with worn common clothes, a small knife, thieves' tools, a bedroll, a hidden pouch, three days of poor rations, and one keepsake from the life you lost or never had.",
    "origin_insights": [
      "Street-Hardened",
      "Hunger Memory",
      "No One Saves You",
      "Quick Hands"
    ],
    "social_hook": "You know how people treat the powerless. Other outcasts may recognize you as one of their own, but officials, guards, and respectable families rarely assume the best of you.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Cursed Bloodline": {
    "name": "Cursed Bloodline",
    "region": "Any Region",
    "description": "Something touched your family line before you were born. It may be a demon, spirit, broken oath, forbidden method, failed ritual, ancestor's crime, or lie everyone agreed to bury. The mark is faint, but it has never disappeared.",
    "ability_options": [
      "Constitution",
      "Wisdom",
      "Charisma"
    ],
    "skills": [
      "Deception",
      "Intimidation"
    ],
    "tools": [
      "You gain one language of your choice and proficiency in one ritual, clan, or occult practice from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain one language of your choice and proficiency in one ritual, clan, or occult practice from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Some people fear what your blood might become. Others want to use it. Your lineage may be shameful, misunderstood, politically dangerous, or secretly valuable.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Dark",
        "talent": "Blindfold",
        "status": "dormant",
        "source_text": "Dark Sphere — Blindfold (dormant)"
      },
      {
        "id": "2",
        "sphere": "Dark",
        "talent": "Hide in Darkness",
        "status": "dormant",
        "source_text": "Dark Sphere — Hide in Darkness (dormant)"
      },
      {
        "id": "3",
        "sphere": "Dark",
        "talent": "Shadowed Mien",
        "status": "dormant",
        "source_text": "Dark Sphere — Shadowed Mien (dormant)"
      }
    ],
    "grant_guidance": "You gain the Dark sphere in a dormant form. Choose one dormant Dark talent: - Blindfold - Hide in Darkness - Shadowed Mien At level 0, this Background Sphere does not allow active Dark sphere techniques, supernatural darkness creation, or CP spending. Instead, it gives you strange knowledge of darkness, concealment, fear, hidden taint, and spiritual rejection. When you gain a Path and a legal way to express the sphere, this dormant sphere may become active. When the Dark sphere becomes active, choose one legal Variant Expression that explains whether your darkness comes through body-bound night training, qi circulation, spirit-shadow, Chakra blockage, bloodline taint, curse inheritance, or another printed route.",
    "kit": [
      "You begin with travel clothes, a hooded cloak, a family token, a charm meant to hide or suppress your mark, ink and paper, and a small weapon."
    ],
    "equipment_text": "You begin with travel clothes, a hooded cloak, a family token, a charm meant to hide or suppress your mark, ink and paper, and a small weapon.",
    "origin_insights": [
      "Unsettling Blood",
      "Hide the Stain",
      "Marked by Something",
      "Born Under Suspicion"
    ],
    "social_hook": "Some people fear what your blood might become. Others want to use it. Your lineage may be shameful, misunderstood, politically dangerous, or secretly valuable.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Dream-Touched": {
    "name": "Dream-Touched",
    "region": "Any Region",
    "description": "Your dreams have always been too vivid. You wake with symbols on your tongue, warnings you cannot explain, or memories that do not feel fully yours. Sometimes the world seems less solid after you sleep.",
    "ability_options": [
      "Wisdom",
      "Charisma",
      "Intelligence"
    ],
    "skills": [
      "Insight",
      "Perception"
    ],
    "tools": [
      "You gain one language of your choice or proficiency in dream interpretation, divination customs, or another symbolic practice from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain one language of your choice or proficiency in dream interpretation, divination customs, or another symbolic practice from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Some people treat your dreams as omens. Others call them illness, delusion, possession, or spiritual sensitivity. Either way, the sect trial may show whether your dreams are warning, invitation, or bait.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Dreams",
        "talent": "Dream Whisper",
        "status": "dormant",
        "source_text": "Dreams Sphere — Dream Whisper (dormant)"
      },
      {
        "id": "2",
        "sphere": "Dreams",
        "talent": "Dream Ward",
        "status": "dormant",
        "source_text": "Dreams Sphere — Dream Ward (dormant)"
      },
      {
        "id": "3",
        "sphere": "Dreams",
        "talent": "Shared Dream",
        "status": "dormant",
        "source_text": "Dreams Sphere — Shared Dream (dormant)"
      }
    ],
    "grant_guidance": "You gain the Dreams sphere in a dormant form. Choose one dormant Dreams talent: - Dream Whisper - Dream Ward - Shared Dream At level 0, this Background Sphere does not allow active Dreams sphere techniques, CP spending, or combat dream techniques. Instead, it gives you dream literacy, symbolic memory, strange warnings, and future access. When you gain a Path and a legal way to express the sphere, this dormant sphere may become active. When the Dreams sphere becomes active, choose one legal Variant Expression that explains whether your dreams manifest through spirit resonance, qi-trance, body sleep discipline, Chakra wheel imagery, reincarnation fragments, or another printed route.",
    "kit": [
      "You begin with soft travel clothes, a dream journal, ink, a sleeping mat, incense, a small charm against nightmares, and one strange object you do not remember obtaining."
    ],
    "equipment_text": "You begin with soft travel clothes, a dream journal, ink, a sleeping mat, incense, a small charm against nightmares, and one strange object you do not remember obtaining.",
    "origin_insights": [
      "Dream Listener",
      "Old Dream",
      "Omen Sense",
      "Half-Awake"
    ],
    "social_hook": "Some people treat your dreams as omens. Others call them illness, delusion, possession, or spiritual sensitivity. Either way, the sect trial may show whether your dreams are warning, invitation, or bait.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Forest Hermit": {
    "name": "Forest Hermit",
    "region": "Any Region",
    "description": "You lived beneath old branches, among cliffs, caves, rivers, roots, and animal tracks. You may have been alone, raised by a guardian, trained by an eccentric recluse, or simply too far from civilization to belong to it.",
    "ability_options": [
      "Constitution",
      "Wisdom",
      "Dexterity"
    ],
    "skills": [
      "Nature",
      "Survival"
    ],
    "tools": [
      "You gain proficiency with the herbalism kit."
    ],
    "tools_text": "You gain proficiency with the herbalism kit.",
    "feature": "You know the wild better than court, market, or sect politics. Animals, hunters, hermits, and rural folk may trust you faster than city officials do.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Harvesting and Gathering",
        "talent": "Common Herbcraft",
        "status": "active",
        "source_text": "Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Common Herbcraft talent."
      },
      {
        "id": "2",
        "sphere": "Harvesting and Gathering",
        "talent": "Camp Gatherer",
        "status": "active",
        "source_text": "Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Camp Gatherer talent."
      },
      {
        "id": "3",
        "sphere": "Athletics",
        "talent": "Strong Lungs",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent."
      }
    ],
    "grant_guidance": "Choose one: - Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Common Herbcraft talent. - Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Camp Gatherer talent. - Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent. At level 0, Harvesting and Gathering represents field knowledge, clean gathering, camp survival, and resource sense. Athletics represents mortal conditioning, breath, climbing, swimming, and travel discipline.",
    "kit": [
      "You begin with weathered travel clothes, a staff or simple weapon, an herbalism kit, a waterskin, a bedroll, five days of trail rations, and a pouch of useful herbs."
    ],
    "equipment_text": "You begin with weathered travel clothes, a staff or simple weapon, an herbalism kit, a waterskin, a bedroll, five days of trail rations, and a pouch of useful herbs.",
    "origin_insights": [
      "Beast Sign",
      "Bitter Root Wisdom",
      "Weather Ear",
      "Quiet Footsteps"
    ],
    "social_hook": "You know the wild better than court, market, or sect politics. Animals, hunters, hermits, and rural folk may trust you faster than city officials do.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Imperial Scholar": {
    "name": "Imperial Scholar",
    "region": "Shengzhou",
    "description": "You studied in academies, examination halls, archives, or a magistrate's household. You learned history, law, calligraphy, precedent, and the careful language of people who intend every sentence to survive scrutiny.",
    "ability_options": [
      "Intelligence",
      "Wisdom",
      "Charisma"
    ],
    "skills": [
      "History",
      "Investigation"
    ],
    "tools": [
      "You gain proficiency with calligrapher's supplies. You know Classical and one additional language of your choice."
    ],
    "tools_text": "You gain proficiency with calligrapher's supplies. You know Classical and one additional language of your choice.",
    "feature": "Officials, clerks, tutors, and literate elites recognize your training. That respect can open doors, but it also marks you as someone who should know the consequences of breaking rules.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Ink",
        "talent": "Wet Ink Warning",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Wet Ink Warning talent."
      },
      {
        "id": "2",
        "sphere": "Ink",
        "talent": "Revealing Script",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Revealing Script talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Reinforced Robes",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent."
      }
    ],
    "grant_guidance": "Choose one: - Ink Sphere. You gain the Ink sphere and the Wet Ink Warning talent. - Ink Sphere. You gain the Ink sphere and the Revealing Script talent. - Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent. At level 0, Ink gained from this Background is usually expressed as calligraphy, document analysis, seals, marks, copied diagrams, and written pattern literacy. Combat or supernatural Ink expression may require later cultivation access. When the Ink sphere awakens, choose an listed Variant Expression that explains whether your writing acts through scholar-qi, spirit names, bureaucratic law, talismanic script, memory ink, or another legal route.",
    "kit": [
      "You begin with scholar's robes, calligrapher's supplies, a writing brush, ink, a seal or school token, a copybook of laws or histories, and travel papers."
    ],
    "equipment_text": "You begin with scholar's robes, calligrapher's supplies, a writing brush, ink, a seal or school token, a copybook of laws or histories, and travel papers.",
    "origin_insights": [
      "Bureaucratic Eye",
      "Scripture Memory",
      "Paper Trail",
      "Courtly Caution"
    ],
    "social_hook": "Officials, clerks, tutors, and literate elites recognize your training. That respect can open doors, but it also marks you as someone who should know the consequences of breaking rules.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Jambudvipan Mystic": {
    "name": "Jambudvipan Mystic",
    "region": "Jambudvipa",
    "description": "You grew up among temples, jungles, ancient formations, river rites, wandering teachers, and old metaphysical arguments. You were taught that body, breath, mind, hunger, spirit, and cosmos are not easily separated.",
    "ability_options": [
      "Wisdom",
      "Intelligence",
      "Constitution"
    ],
    "skills": [
      "Arcana",
      "Medicine"
    ],
    "tools": [
      "You gain proficiency with the herbalism kit and one sacred, scholarly, or regional language from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with the herbalism kit and one sacred, scholarly, or regional language from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Your customs may be respected, exoticized, misunderstood, or distrusted depending on where the campaign begins. You may notice spiritual assumptions that local cultivators take for granted.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Alchemy",
        "talent": "Calming Heart Pill",
        "status": "active",
        "source_text": "Alchemy Sphere. You gain the Alchemy sphere and the Calming Heart Pill recipe."
      },
      {
        "id": "2",
        "sphere": "Alchemy",
        "talent": "Antidote Pill",
        "status": "active",
        "source_text": "Alchemy Sphere. You gain the Alchemy sphere and the Antidote Pill recipe."
      },
      {
        "id": "3",
        "sphere": "Flowing River",
        "talent": "Reed in Storm",
        "status": "active",
        "source_text": "Flowing River Sphere. You gain the Flowing River sphere and the Reed in Storm talent."
      },
      {
        "id": "4",
        "sphere": "Athletics",
        "talent": "Strong Lungs",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent."
      }
    ],
    "grant_guidance": "Choose one: - Alchemy Sphere. You gain the Alchemy sphere and the Calming Heart Pill recipe. - Alchemy Sphere. You gain the Alchemy sphere and the Antidote Pill recipe. - Flowing River Sphere. You gain the Flowing River sphere and the Reed in Storm talent. - Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent. At level 0, Alchemy from this Background represents basic medicinal and ritual preparation, not advanced pill mastery. Flowing River and Athletics represent breath, posture, discipline, and body-mind training. When one of these spheres awakens into fuller cultivation, choose an listed Variant Expression that explains whether the practice unfolds through vital discipline, qi circulation, spirit attunement, Chakra imagery, body posture, or another legal route.",
    "kit": [
      "You begin with travel robes, prayer beads or a meditation cord, an herbalism kit, incense, a small ritual text, and a satchel of medicinal roots."
    ],
    "equipment_text": "You begin with travel robes, prayer beads or a meditation cord, an herbalism kit, incense, a small ritual text, and a satchel of medicinal roots.",
    "origin_insights": [
      "Breath Before Thought",
      "Body Is a Shrine",
      "Formation Curiosity",
      "Patient Mind"
    ],
    "social_hook": "Your customs may be respected, exoticized, misunderstood, or distrusted depending on where the campaign begins. You may notice spiritual assumptions that local cultivators take for granted.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Merchant Clan Scion": {
    "name": "Merchant Clan Scion",
    "region": "Any Major Trade Region",
    "description": "Your family trades in silk, grain, horses, tools, pills, favors, gossip, transport, and debt. You were taught that everything has a price, but the price is not always money.",
    "ability_options": [
      "Charisma",
      "Intelligence",
      "Wisdom"
    ],
    "skills": [
      "Persuasion",
      "Investigation"
    ],
    "tools": [
      "You gain proficiency with navigator’s tools, merchant’s tools, or one artisan’s tool. You know Trade Pidgin or another trade language from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with navigator’s tools, merchant’s tools, or one artisan’s tool. You know Trade Pidgin or another trade language from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Your family name may open doors, create obligations, or place you under scrutiny. A merchant clan rarely gives help without remembering it.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Sect Stewardship",
        "talent": "Clean Ledger Hand",
        "status": "active",
        "source_text": "Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Clean Ledger Hand talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      },
      {
        "id": "3",
        "sphere": "Ink",
        "talent": "Binding Script",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Binding Script talent."
      }
    ],
    "grant_guidance": "Choose one: - Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Clean Ledger Hand talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent. - Ink Sphere. You gain the Ink sphere and the Binding Script talent. If Ink or Sect Stewardship later awakens into active sphere use, choose an listed Variant Expression that reflects whether your training came through contracts, clan ledgers, trade seals, auction law, caravans, or merchant intelligence.",
    "kit": [
      "You begin with fine travel clothes, a ledger, writing tools, a merchant token, a purse of mixed coin, a trade sample, and one letter of introduction."
    ],
    "equipment_text": "You begin with fine travel clothes, a ledger, writing tools, a merchant token, a purse of mixed coin, a trade sample, and one letter of introduction.",
    "origin_insights": [
      "Everything Has a Price",
      "Read the Buyer",
      "Family Ledger",
      "Courtly Caution"
    ],
    "social_hook": "Your family name may open doors, create obligations, or place you under scrutiny. A merchant clan rarely gives help without remembering it.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Military Brat": {
    "name": "Military Brat",
    "region": "Any Region",
    "description": "You grew up around barracks, marching grounds, horses, weapons, command tents, old soldiers, and shouted orders. Discipline became instinct before you understood the politics behind it.",
    "ability_options": [
      "Strength",
      "Constitution",
      "Charisma"
    ],
    "skills": [
      "Athletics",
      "Intimidation"
    ],
    "tools": [
      "You gain proficiency with land vehicles and Military Sign, a simple gestural code used for field commands."
    ],
    "tools_text": "You gain proficiency with land vehicles and Military Sign, a simple gestural code used for field commands.",
    "feature": "Soldiers, guards, and veterans may treat you as familiar. Deserters, rebels, bandits, and victims of military campaigns may not.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Equipment",
        "talent": "Armor Training",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Armor Training talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Shield Training",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Shield Training talent."
      },
      {
        "id": "3",
        "sphere": "Spear",
        "talent": "Rooted Spear Stance",
        "status": "active",
        "source_text": "Spear Sphere. You gain the Spear sphere and the Rooted Spear Stance talent."
      },
      {
        "id": "4",
        "sphere": "Warleader",
        "talent": "Battlefield Coordination",
        "status": "active",
        "source_text": "Warleader Sphere. You gain the Warleader sphere and the Battlefield Coordination talent."
      }
    ],
    "grant_guidance": "Choose one: - Equipment Sphere. You gain the Equipment sphere and the Armor Training talent. - Equipment Sphere. You gain the Equipment sphere and the Shield Training talent. - Spear Sphere. You gain the Spear sphere and the Rooted Spear Stance talent. - Warleader Sphere. You gain the Warleader sphere and the Battlefield Coordination talent. If Warleader later awakens into active sphere use, choose an listed Variant Expression that reflects whether your command style comes from discipline, fear, battlefield rhythm, banner culture, or protective leadership.",
    "kit": [
      "You begin with sturdy clothes, a simple weapon, a bedroll, a whetstone, a unit token or old insignia, and field rations."
    ],
    "equipment_text": "You begin with sturdy clothes, a simple weapon, a bedroll, a whetstone, a unit token or old insignia, and field rations.",
    "origin_insights": [
      "Drill Instinct",
      "Hold the Line",
      "Pain Familiarity",
      "Open Sky Nerve"
    ],
    "social_hook": "Soldiers, guards, and veterans may treat you as familiar. Deserters, rebels, bandits, and victims of military campaigns may not.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Northern Steppe Rider": {
    "name": "Northern Steppe Rider",
    "region": "Northern Steppes",
    "description": "You were born beneath an open sky and raised among horses, herds, banners, storms, raids, songs, and old ancestor customs. The Empire may call your people barbarians. You know better.",
    "ability_options": [
      "Dexterity",
      "Constitution",
      "Charisma"
    ],
    "skills": [
      "Animal Handling",
      "Intimidation"
    ],
    "tools": [
      "You gain proficiency with land vehicles and one northern tribal language."
    ],
    "tools_text": "You gain proficiency with land vehicles and one northern tribal language.",
    "feature": "Steppe folk may see you as kin or rival. Imperial subjects may see you through stories of raids, tribute, border wars, and freedom they do not understand.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Beastmastery",
        "talent": "Mount Training",
        "status": "active",
        "source_text": "Beastmastery Sphere. You gain the Beastmastery sphere and the Mount Training talent."
      },
      {
        "id": "2",
        "sphere": "Spear",
        "talent": "Pursuit Spear",
        "status": "active",
        "source_text": "Spear Sphere. You gain the Spear sphere and the Pursuit Spear talent."
      },
      {
        "id": "3",
        "sphere": "Barrage",
        "talent": "Mobile Barrage",
        "status": "active",
        "source_text": "Barrage Sphere. You gain the Barrage sphere and the Mobile Barrage talent."
      },
      {
        "id": "4",
        "sphere": "Warleader",
        "talent": "Rallying Speech",
        "status": "active",
        "source_text": "Warleader Sphere. You gain the Warleader sphere and the Rallying Speech talent."
      }
    ],
    "grant_guidance": "Choose one: - Beastmastery Sphere. You gain the Beastmastery sphere and the Mount Training talent. - Spear Sphere. You gain the Spear sphere and the Pursuit Spear talent. - Barrage Sphere. You gain the Barrage sphere and the Mobile Barrage talent. - Warleader Sphere. You gain the Warleader sphere and the Rallying Speech talent. At level 0, Beastmastery from this Background represents horse-handling, herd knowledge, and early bond discipline. It does not grant a full bonded companion unless another feature says so. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as horse-soul, ancestor-rider, banner-herd, or storm-steppe practice.",
    "kit": [
      "You begin with riding clothes, a shortbow or simple weapon, a riding kit, a weather cloak, a clan token, dried meat, and a horsehair charm."
    ],
    "equipment_text": "You begin with riding clothes, a shortbow or simple weapon, a riding kit, a weather cloak, a clan token, dried meat, and a horsehair charm.",
    "origin_insights": [
      "Born in the Saddle",
      "Open Sky Nerve",
      "Beast Sign",
      "Weather Ear"
    ],
    "social_hook": "Steppe folk may see you as kin or rival. Imperial subjects may see you through stories of raids, tribute, border wars, and freedom they do not understand.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Puppeteer’s Child": {
    "name": "Puppeteer’s Child",
    "region": "Any Region; common in Yamato",
    "description": "Your family carved dolls, masks, toys, shrine figures, theater puppets, or ritual effigies. You learned how to make still things seem alive, and how much people reveal when they think only a doll is watching.",
    "ability_options": [
      "Dexterity",
      "Intelligence",
      "Charisma"
    ],
    "skills": [
      "Performance",
      "Sleight of Hand"
    ],
    "tools": [
      "You gain proficiency with woodcarver’s tools."
    ],
    "tools_text": "You gain proficiency with woodcarver’s tools.",
    "feature": "Puppeteers, actors, shrine keepers, and children may welcome you. Others may find your work unsettling, especially where dolls are used for curses, mourning rites, or spirit vessels.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Puppetry",
        "talent": "Little Servant’s Errand",
        "status": "active",
        "source_text": "Puppetry Sphere. You gain the Puppetry sphere and the Little Servant’s Errand talent."
      },
      {
        "id": "2",
        "sphere": "Puppetry",
        "talent": "Hidden Thread",
        "status": "active",
        "source_text": "Puppetry Sphere. You gain the Puppetry sphere and the Hidden Thread talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      }
    ],
    "grant_guidance": "Choose one: - Puppetry Sphere. You gain the Puppetry sphere and the Little Servant’s Errand talent. - Puppetry Sphere. You gain the Puppetry sphere and the Hidden Thread talent. - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. At level 0, Puppetry from this Background represents craft, performance, puppet handling, doll repair, and familiarity with puppet forms. It does not grant a combat puppet or full animated servant unless another feature says so. If Puppetry later awakens into active sphere use, choose an listed Variant Expression such as theater puppet, ritual doll, corpse puppet, battle puppet, spirit doll, or artisan construct.",
    "kit": [
      "You begin with performer’s clothes, woodcarver’s tools, carving knives, paint, string, a small puppet or doll, and a repair kit."
    ],
    "equipment_text": "You begin with performer’s clothes, woodcarver’s tools, carving knives, paint, string, a small puppet or doll, and a repair kit.",
    "origin_insights": [
      "Painted Face",
      "Still Hands",
      "Quick Hands",
      "Patient Mind"
    ],
    "social_hook": "Puppeteers, actors, shrine keepers, and children may welcome you. Others may find your work unsettling, especially where dolls are used for curses, mourning rites, or spirit vessels.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Shinobi Apprentice": {
    "name": "Shinobi Apprentice",
    "region": "Yamato",
    "description": "You trained in silence, misdirection, climbing, coded speech, poison handling, and the discipline of not being remembered. Your name may never have been written down.",
    "ability_options": [
      "Dexterity",
      "Wisdom",
      "Intelligence"
    ],
    "skills": [
      "Acrobatics",
      "Stealth"
    ],
    "tools": [
      "You gain proficiency with poisoner’s kit and thieves’ tools."
    ],
    "tools_text": "You gain proficiency with poisoner’s kit and thieves’ tools.",
    "feature": "You may be useful, feared, or disposable. Samurai, magistrates, sects, and criminal houses may all have reasons to deny knowing people like you exist.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Scoundrel",
        "talent": "Cut and Run",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Cut and Run (CUT AND RUN) talent."
      },
      {
        "id": "2",
        "sphere": "Trap",
        "talent": "Warning Trigger",
        "status": "active",
        "source_text": "Trap Sphere. You gain the Trap sphere and the Warning Trigger talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      },
      {
        "id": "4",
        "sphere": "Poison",
        "talent": "Poison Sense",
        "status": "active",
        "source_text": "Poison Sphere. You gain the Poison sphere and the Poison Sense talent."
      }
    ],
    "grant_guidance": "Choose one: - Scoundrel Sphere. You gain the Scoundrel sphere and the Cut and Run (CUT AND RUN) talent. - Trap Sphere. You gain the Trap sphere and the Warning Trigger talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent. - Poison Sphere. You gain the Poison sphere and the Poison Sense talent. At level 0, Poison from this Background represents mundane poison handling, antidote caution, and training-safe exposure. It does not grant advanced toxic cultivation or supernatural venom unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as shinobi poison, alchemical venom, cursed toxin, needle poison, or breath poison.",
    "kit": [
      "You begin with dark travel clothes, a simple weapon, a climbing cord, a poisoner’s kit, thieves’ tools, smoke pellets with no combat effect unless a printed rule allows, and coded training notes."
    ],
    "equipment_text": "You begin with dark travel clothes, a simple weapon, a climbing cord, a poisoner’s kit, thieves’ tools, smoke pellets with no combat effect unless a printed rule allows, and coded training notes.",
    "origin_insights": [
      "Vanishing Step",
      "Patient Shadow",
      "Poison Familiarity",
      "No One Saves You"
    ],
    "social_hook": "You may be useful, feared, or disposable. Samurai, magistrates, sects, and criminal houses may all have reasons to deny knowing people like you exist.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Temple Initiate": {
    "name": "Temple Initiate",
    "region": "Any Region",
    "description": "You were raised or trained in a shrine, temple, monastery, ancestral hall, or roadside sanctuary. You learned prayers, offerings, ritual forms, discipline, and the names of powers older than your village.",
    "ability_options": [
      "Wisdom",
      "Intelligence",
      "Charisma"
    ],
    "skills": [
      "Religion",
      "Insight"
    ],
    "tools": [
      "You gain proficiency with calligrapher’s supplies. You know Classical or one sacred language from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with calligrapher’s supplies. You know Classical or one sacred language from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Temples and shrines may offer hospitality, but they may also expect discipline, service, humility, and respect for obligations you did not choose.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Talismans",
        "talent": "Warding Talisman",
        "status": "preparatory",
        "source_text": "Talismans Sphere. You gain the Talismans sphere and the Warding Talisman talent."
      },
      {
        "id": "2",
        "sphere": "Protection",
        "talent": "Ward",
        "status": "preparatory",
        "source_text": "Protection Sphere. You gain the Protection sphere and the Ward talent."
      },
      {
        "id": "3",
        "sphere": "Radiance",
        "talent": "Consecrated Lantern",
        "status": "preparatory",
        "source_text": "Radiance Sphere. You gain the Radiance sphere and the Consecrated Lantern talent."
      },
      {
        "id": "4",
        "sphere": "Spirit Companions",
        "talent": "Minor Spirit Agreements",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere. You gain the Spirit Companions sphere and the Minor Spirit Agreements talent."
      }
    ],
    "grant_guidance": "Choose one: - Talismans Sphere. You gain the Talismans sphere and the Warding Talisman talent. - Protection Sphere. You gain the Protection sphere and the Ward talent. - Radiance Sphere. You gain the Radiance sphere and the Consecrated Lantern talent. - Spirit Companions Sphere. You gain the Spirit Companions sphere and the Minor Spirit Agreements talent. At level 0, these Background Spheres represent ritual knowledge, etiquette, shrine practice, and spiritual literacy rather than full active sphere use. If the sphere later awakens into active sphere use, choose an listed Variant Expression that reflects your temple, ancestor hall, doctrine, shrine spirit, vow, or ritual lineage.",
    "kit": [
      "You begin with simple robes, prayer beads, calligrapher’s supplies, incense, a temple token, a small ritual text, and a charm against misfortune."
    ],
    "equipment_text": "You begin with simple robes, prayer beads, calligrapher’s supplies, incense, a temple token, a small ritual text, and a charm against misfortune.",
    "origin_insights": [
      "Shrine Child",
      "Sincere Offering",
      "Scripture Memory",
      "Breath Before Thought"
    ],
    "social_hook": "Temples and shrines may offer hospitality, but they may also expect discipline, service, humility, and respect for obligations you did not choose.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Beast Hunter": {
    "name": "Beast Hunter",
    "region": "Campaign origin",
    "description": "You learned to track things that could kill you. You know claw marks, scat, broken branches, blood trails, territorial warnings, and the difference between an animal, a spirit beast, and something pretending to be either.",
    "ability_options": [
      "Strength",
      "Dexterity",
      "Wisdom"
    ],
    "skills": [
      "Survival",
      "Nature"
    ],
    "tools": [
      "You gain proficiency with leatherworker’s tools, trapper’s tools, or one hunter’s trade from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with leatherworker’s tools, trapper’s tools, or one hunter’s trade from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Villages may respect you when beasts threaten them. Sects may treat you as crude until they need someone who understands what lives beyond their walls.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Spear",
        "talent": "Rooted Spear Stance",
        "status": "active",
        "source_text": "Spear Sphere. You gain the Spear sphere and the Rooted Spear Stance talent."
      },
      {
        "id": "2",
        "sphere": "Barrage",
        "talent": "Distracting Shot",
        "status": "active",
        "source_text": "Barrage Sphere. You gain the Barrage sphere and the Distracting Shot talent."
      },
      {
        "id": "3",
        "sphere": "Trap",
        "talent": "Noose",
        "status": "active",
        "source_text": "Trap Sphere. You gain the Trap sphere and the Noose talent."
      },
      {
        "id": "4",
        "sphere": "Beastmastery",
        "talent": "Lookout",
        "status": "active",
        "source_text": "Beastmastery Sphere. You gain the Beastmastery sphere and the Lookout talent."
      }
    ],
    "grant_guidance": "Choose one: - Spear Sphere. You gain the Spear sphere and the Rooted Spear Stance talent. - Barrage Sphere. You gain the Barrage sphere and the Distracting Shot talent. - Trap Sphere. You gain the Trap sphere and the Noose talent. - Beastmastery Sphere. You gain the Beastmastery sphere and the Lookout talent. At level 0, Beastmastery from this Background represents tracking, calming, baiting, avoiding, and reading beasts. It does not grant a bonded companion unless another feature says so. If Beastmastery later awakens into active sphere use, choose an listed Variant Expression such as hunter’s bond, trophy-oath, pack sign, spirit-beast respect, or predator-prey discipline.",
    "kit": [
      "You begin with travel clothes, a hunting knife, a simple ranged weapon or spear, trapper’s tools or leatherworker’s tools, a coil of cord, trail rations, and a trophy from a beast you survived."
    ],
    "equipment_text": "You begin with travel clothes, a hunting knife, a simple ranged weapon or spear, trapper’s tools or leatherworker’s tools, a coil of cord, trail rations, and a trophy from a beast you survived.",
    "origin_insights": [
      "Beast Sign",
      "Quiet Footsteps",
      "Pain Familiarity",
      "Weather Ear"
    ],
    "social_hook": "Villages may respect you when beasts threaten them. Sects may treat you as crude until they need someone who understands what lives beyond their walls.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Clan Heir": {
    "name": "Clan Heir",
    "region": "Campaign origin",
    "description": "You were born into a family that remembers its ancestors, guards its reputation, and expects its children to become useful. You may be loved, controlled, protected, traded, trained, or burdened by expectation.",
    "ability_options": [
      "Charisma",
      "Intelligence",
      "Wisdom"
    ],
    "skills": [
      "Persuasion",
      "History"
    ],
    "tools": [
      "You gain one language of your choice and proficiency with calligrapher’s supplies or one artisan’s tool tied to your clan."
    ],
    "tools_text": "You gain one language of your choice and proficiency with calligrapher’s supplies or one artisan’s tool tied to your clan.",
    "feature": "Your name opens some doors and closes others. Your actions may reflect on people who are not present but still have power over your life.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Sect Stewardship",
        "talent": "Sect Token Etiquette",
        "status": "active",
        "source_text": "Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Sect Token Etiquette talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Reinforced Robes",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent."
      },
      {
        "id": "3",
        "sphere": "Ink",
        "talent": "Binding Script",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Binding Script talent."
      },
      {
        "id": "4",
        "sphere": "Sword",
        "talent": "Sword Guard",
        "status": "active",
        "source_text": "Sword Sphere. You gain the Sword sphere and the Sword Guard talent."
      }
    ],
    "grant_guidance": "Choose one: - Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Sect Token Etiquette talent. - Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent. - Ink Sphere. You gain the Ink sphere and the Binding Script talent. - Sword Sphere. You gain the Sword sphere and the Sword Guard talent. If Ink, Sect Stewardship, or Sword later awakens into active sphere use, choose an listed Variant Expression that reflects whether your clan trained you through records, etiquette, ancestral seals, guarded forms, ritual weapons, or inherited reputation.",
    "kit": [
      "You begin with quality clothes, a clan token, writing tools, a family letter, a signet or seal, and a small inherited keepsake."
    ],
    "equipment_text": "You begin with quality clothes, a clan token, writing tools, a family letter, a signet or seal, and a small inherited keepsake.",
    "origin_insights": [
      "Bureaucratic Eye",
      "Family Ledger",
      "Courtly Caution",
      "Family Name"
    ],
    "social_hook": "Your name opens some doors and closes others. Your actions may reflect on people who are not present but still have power over your life.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Exiled Noble": {
    "name": "Exiled Noble",
    "region": "Campaign origin",
    "description": "You were born near power and cast away from it. Your family may have lost favor, been defeated, been betrayed, or sent you away as sacrifice, hostage, embarrassment, or hidden hope.",
    "ability_options": [
      "Charisma",
      "Dexterity",
      "Wisdom"
    ],
    "skills": [
      "Deception",
      "Insight"
    ],
    "tools": [
      "You gain one language of your choice and proficiency with one gaming set, musical instrument, courtly tool, or noble practice from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain one language of your choice and proficiency with one gaming set, musical instrument, courtly tool, or noble practice from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Some people still know your name. Some pity it. Some hate it. Some may want to use you as a symbol, hostage, claimant, or scapegoat.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Sword",
        "talent": "Sword Drawing Stance",
        "status": "active",
        "source_text": "Sword Sphere. You gain the Sword sphere and the Sword Drawing Stance talent."
      },
      {
        "id": "2",
        "sphere": "Scoundrel",
        "talent": "Distracting Trickery",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Distracting Trickery (DISTRACTING TRICKERY) talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      },
      {
        "id": "4",
        "sphere": "Sect Stewardship",
        "talent": "Quiet Apology Method",
        "status": "active",
        "source_text": "Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Quiet Apology Method talent."
      }
    ],
    "grant_guidance": "Choose one: - Sword Sphere. You gain the Sword sphere and the Sword Drawing Stance talent. - Scoundrel Sphere. You gain the Scoundrel sphere and the Distracting Trickery (DISTRACTING TRICKERY) talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent. - Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Quiet Apology Method talent. If Sword, Scoundrel, or Sect Stewardship later awakens into active sphere use, choose an listed Variant Expression that reflects whether your exile sharpened your swordwork, dueling, deception, political survival, patronage network, or hatred of courtly masks.",
    "kit": [
      "You begin with worn fine clothes, a concealed family token, a small weapon, a letter you have not decided whether to destroy, and enough coin to look respectable once."
    ],
    "equipment_text": "You begin with worn fine clothes, a concealed family token, a small weapon, a letter you have not decided whether to destroy, and enough coin to look respectable once.",
    "origin_insights": [
      "Fallen House",
      "Hide the Stain",
      "Courtly Caution",
      "Paper Trail"
    ],
    "social_hook": "Some people still know your name. Some pity it. Some hate it. Some may want to use you as a symbol, hostage, claimant, or scapegoat.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Furnace Laborer": {
    "name": "Furnace Laborer",
    "region": "Campaign origin",
    "description": "You worked in heat, smoke, stone, metal, salt, kilns, mines, docks, foundries, or construction yards. Your body learned pain before anyone called it discipline.",
    "ability_options": [
      "Strength",
      "Constitution",
      "Wisdom"
    ],
    "skills": [
      "Athletics",
      "Survival"
    ],
    "tools": [
      "You gain proficiency with smith’s tools, mason’s tools, miner’s tools, carpenter’s tools, or another labor trade from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with smith’s tools, mason’s tools, miner’s tools, carpenter’s tools, or another labor trade from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Workers know the truth of who eats because others bleed. Nobles and sect disciples may underestimate you until effort matters more than pedigree.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Brute",
        "talent": "Focused Might",
        "status": "active",
        "source_text": "Brute Sphere. You gain the Brute sphere and the Focused Might talent."
      },
      {
        "id": "2",
        "sphere": "Blacksmith",
        "talent": "Field Repair",
        "status": "active",
        "source_text": "Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      },
      {
        "id": "4",
        "sphere": "Athletics",
        "talent": "Mighty Conditioning",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Mighty Conditioning talent."
      }
    ],
    "grant_guidance": "Choose one: - Brute Sphere. You gain the Brute sphere and the Focused Might talent. - Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent. - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. - Athletics Sphere. You gain the Athletics sphere and the Mighty Conditioning talent. At level 0, Blacksmith from this Background represents practical repair, forge knowledge, tool use, and material sense. It does not grant advanced artifact forging unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as forge-hand, furnace-body, weapon repair, metal scripture, construction labor, or body-as-forge practice.",
    "kit": [
      "You begin with work clothes, heavy gloves, a simple tool from your trade, a waterskin, a whetstone or chalk line, and a scar from work that should have broken you."
    ],
    "equipment_text": "You begin with work clothes, heavy gloves, a simple tool from your trade, a waterskin, a whetstone or chalk line, and a scar from work that should have broken you.",
    "origin_insights": [
      "Drill Instinct",
      "Hold the Line",
      "Pain Familiarity",
      "Tool Memory"
    ],
    "social_hook": "Workers know the truth of who eats because others bleed. Nobles and sect disciples may underestimate you until effort matters more than pedigree.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Herb-Gatherer": {
    "name": "Herb-Gatherer",
    "region": "Campaign origin",
    "description": "You gathered roots, fungi, flowers, bark, insects, and spirit-touched plants for physicians, alchemists, temples, or hungry families. You learned that the difference between medicine and poison is often timing.",
    "ability_options": [
      "Wisdom",
      "Dexterity",
      "Intelligence"
    ],
    "skills": [
      "Medicine",
      "Nature"
    ],
    "tools": [
      "You gain proficiency with the herbalism kit."
    ],
    "tools_text": "You gain proficiency with the herbalism kit.",
    "feature": "Physicians, alchemists, villagers, and hermits may value your knowledge. Spirit forests, sect gardens, and forbidden groves may punish careless gathering.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Harvesting and Gathering",
        "talent": "Common Herbcraft",
        "status": "active",
        "source_text": "Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Common Herbcraft talent."
      },
      {
        "id": "2",
        "sphere": "Harvesting and Gathering",
        "talent": "Farmer’s Eye",
        "status": "active",
        "source_text": "Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Farmer’s Eye talent."
      },
      {
        "id": "3",
        "sphere": "Alchemy",
        "talent": "Antidote Pill",
        "status": "active",
        "source_text": "Alchemy Sphere. You gain the Alchemy sphere and the Antidote Pill recipe."
      },
      {
        "id": "4",
        "sphere": "Poison",
        "talent": "Poison Sense",
        "status": "active",
        "source_text": "Poison Sphere. You gain the Poison sphere and the Poison Sense talent."
      }
    ],
    "grant_guidance": "Choose one: - Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Common Herbcraft talent. - Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Farmer’s Eye talent. - Alchemy Sphere. You gain the Alchemy sphere and the Antidote Pill recipe. - Poison Sphere. You gain the Poison sphere and the Poison Sense talent. At level 0, Alchemy and Poison from this Background represent medicine, antidotes, safe handling, dosage, plant preparation, and practical field knowledge. They do not grant advanced pill refinement, supernatural toxins, or poison qi unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as field medicine, temple apothecary, forest alchemy, venom craft, herb scripture, or healing garden practice.",
    "kit": [
      "You begin with travel clothes, an herbalism kit, drying paper, small jars, a gathering knife, a field pouch, and a packet of common medicinal herbs."
    ],
    "equipment_text": "You begin with travel clothes, an herbalism kit, drying paper, small jars, a gathering knife, a field pouch, and a packet of common medicinal herbs.",
    "origin_insights": [
      "Bitter Root Wisdom",
      "Triage Mind",
      "Poison Familiarity",
      "Steady Hands"
    ],
    "social_hook": "Physicians, alchemists, villagers, and hermits may value your knowledge. Spirit forests, sect gardens, and forbidden groves may punish careless gathering.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Monastery Novice": {
    "name": "Monastery Novice",
    "region": "Campaign origin",
    "description": "You trained under bells, chants, cold floors, repeated forms, simple meals, and older disciples who corrected your posture before your philosophy. Whether you were devout or restless, discipline entered your bones.",
    "ability_options": [
      "Wisdom",
      "Dexterity",
      "Constitution"
    ],
    "skills": [
      "Religion",
      "Acrobatics"
    ],
    "tools": [
      "You gain proficiency with calligrapher’s supplies, cook’s utensils, or one musical instrument used in temple or monastery practice."
    ],
    "tools_text": "You gain proficiency with calligrapher’s supplies, cook’s utensils, or one musical instrument used in temple or monastery practice.",
    "feature": "Monastic training earns respect in some places and suspicion in others. Your former teachers may expect humility, service, or obedience even after you leave.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Iron Fist",
        "talent": "Focusing Breath",
        "status": "active",
        "source_text": "Iron Fist Sphere. You gain the Iron Fist sphere and the Focusing Breath talent."
      },
      {
        "id": "2",
        "sphere": "Iron Fist",
        "talent": "Merciful Hand",
        "status": "active",
        "source_text": "Iron Fist Sphere. You gain the Iron Fist sphere and the Merciful Hand talent."
      },
      {
        "id": "3",
        "sphere": "Flowing River",
        "talent": "Empty Step",
        "status": "active",
        "source_text": "Flowing River Sphere. You gain the Flowing River sphere and the Empty Step talent."
      },
      {
        "id": "4",
        "sphere": "Spear",
        "talent": "Long-Shaft Discipline",
        "status": "active",
        "source_text": "Spear Sphere. You gain the Spear sphere and the Long-Shaft Discipline talent."
      }
    ],
    "grant_guidance": "Choose one: - Iron Fist Sphere. You gain the Iron Fist sphere and the Focusing Breath talent. - Iron Fist Sphere. You gain the Iron Fist sphere and the Merciful Hand talent. - Flowing River Sphere. You gain the Flowing River sphere and the Empty Step talent. - Spear Sphere. You gain the Spear sphere and the Long-Shaft Discipline talent. If Iron Fist, Flowing River, or Spear later awakens into active sphere use, choose an listed Variant Expression that reflects whether your training came from temple discipline, body forms, compassion, suppression of ego, monastic staff-as-spear drills, weapon forms, breath rhythm, or ritual movement.",
    "kit": [
      "You begin with simple robes, a staff, prayer beads or training beads, a begging bowl, sandals, and a copied verse."
    ],
    "equipment_text": "You begin with simple robes, a staff, prayer beads or training beads, a begging bowl, sandals, and a copied verse.",
    "origin_insights": [
      "Perfect the Stroke",
      "Courtly Caution",
      "Breath Before Thought",
      "Body Is a Shrine"
    ],
    "social_hook": "Monastic training earns respect in some places and suspicion in others. Your former teachers may expect humility, service, or obedience even after you leave.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "River Child": {
    "name": "River Child",
    "region": "Campaign origin",
    "description": "You grew up beside water: ferries, barges, fishing boats, floodplains, bridges, docks, reed marshes, or river shrines. You learned currents before roads and weather before calendars.",
    "ability_options": [
      "Dexterity",
      "Wisdom",
      "Constitution"
    ],
    "skills": [
      "Athletics",
      "Perception"
    ],
    "tools": [
      "You gain proficiency with water vehicles, fisher’s tools, or one river trade from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with water vehicles, fisher’s tools, or one river trade from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Boatfolk, fishers, ferrymen, smugglers, and river shrines may know your ways. Landed officials often underestimate people whose homes move.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Flowing River",
        "talent": "Patient Water",
        "status": "active",
        "source_text": "Flowing River Sphere. You gain the Flowing River sphere and the Patient Water talent."
      },
      {
        "id": "2",
        "sphere": "Flowing River",
        "talent": "Empty Step",
        "status": "active",
        "source_text": "Flowing River Sphere. You gain the Flowing River sphere and the Empty Step talent."
      },
      {
        "id": "3",
        "sphere": "Athletics",
        "talent": "Strong Lungs",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent."
      },
      {
        "id": "4",
        "sphere": "Athletics",
        "talent": "Sure Grip",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Sure Grip talent."
      }
    ],
    "grant_guidance": "Choose one: - Flowing River Sphere. You gain the Flowing River sphere and the Patient Water talent. - Flowing River Sphere. You gain the Flowing River sphere and the Empty Step talent. - Athletics Sphere. You gain the Athletics sphere and the Strong Lungs talent. - Athletics Sphere. You gain the Athletics sphere and the Sure Grip talent. At level 0, Flowing River from this Background represents balance, breath, current-reading, footwork, and the habit of yielding before force. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as ferry-step, reed-water body, current-listening, river memory, soft redirection, or flood-survival practice.",
    "kit": [
      "You begin with practical clothes, a fishing line or net, a river knife, waterproof wrapping, a small charm for safe crossings, and a coil of rope."
    ],
    "equipment_text": "You begin with practical clothes, a fishing line or net, a river knife, waterproof wrapping, a small charm for safe crossings, and a coil of rope.",
    "origin_insights": [
      "Weather Ear",
      "Breath Before Thought",
      "Patient Mind",
      "Quiet Footsteps"
    ],
    "social_hook": "Boatfolk, fishers, ferrymen, smugglers, and river shrines may know your ways. Landed officials often underestimate people whose homes move.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Sect Servant": {
    "name": "Sect Servant",
    "region": "Campaign origin",
    "description": "You lived near cultivation before you could touch it. You swept courtyards, carried water, cooked rice, copied schedules, cleaned training halls, tended fires, or watched disciples from the edge of the world you wanted.",
    "ability_options": [
      "Wisdom",
      "Dexterity",
      "Charisma"
    ],
    "skills": [
      "Insight",
      "Stealth"
    ],
    "tools": [
      "You gain proficiency with cook’s utensils, calligrapher’s supplies, cleaning tools, or one servant trade from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with cook’s utensils, calligrapher’s supplies, cleaning tools, or one servant trade from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "You know sect life from below. Servants, cooks, guards, and outer disciples may speak freely around you, but inner disciples may resent seeing you rise.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      },
      {
        "id": "3",
        "sphere": "Sect Stewardship",
        "talent": "Senior Brother’s Errand",
        "status": "active",
        "source_text": "Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Senior Brother’s Errand talent."
      },
      {
        "id": "4",
        "sphere": "Ink",
        "talent": "Wet Ink Warning",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Wet Ink Warning talent."
      }
    ],
    "grant_guidance": "Choose one: - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent. - Sect Stewardship Sphere. You gain the Sect Stewardship sphere and the Senior Brother’s Errand talent. - Ink Sphere. You gain the Ink sphere and the Wet Ink Warning talent. At level 0, Sect Stewardship and Ink from this Background represent exposure, memory, chores, routines, hierarchy, and overheard instruction. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as servant-network, outer-court etiquette, copied records, supply hall practice, or low-door sect intelligence.",
    "kit": [
      "You begin with plain sect-issued clothes, a work knife, a cleaning or cooking kit, a copied schedule, a hidden scrap of overheard instruction, and a servant token."
    ],
    "equipment_text": "You begin with plain sect-issued clothes, a work knife, a cleaning or cooking kit, a copied schedule, a hidden scrap of overheard instruction, and a servant token.",
    "origin_insights": [
      "Invisible in Plain Sight",
      "Listen While Serving",
      "Street-Hardened",
      "Patient Mind"
    ],
    "social_hook": "You know sect life from below. Servants, cooks, guards, and outer disciples may speak freely around you, but inner disciples may resent seeing you rise.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Spirit Medium": {
    "name": "Spirit Medium",
    "region": "Campaign origin",
    "description": "Since childhood, you have sensed presences others missed: ancestral murmurs, shrine moods, dream visitors, grave-cold silences, hungry corners, or the pressure of something watching from behind the world.",
    "ability_options": [
      "Wisdom",
      "Charisma",
      "Constitution"
    ],
    "skills": [
      "Insight",
      "Religion"
    ],
    "tools": [
      "You gain one ritual, divination, funerary, shrine, or spirit-custom proficiency from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain one ritual, divination, funerary, shrine, or spirit-custom proficiency from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Some people seek your help. Some call you cursed. Spirits may notice you before you know how to answer them.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Spirit Companions",
        "talent": "Iron Courtesy",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere — Iron Courtesy (preparatory)"
      },
      {
        "id": "2",
        "sphere": "Spirit Companions",
        "talent": "Gentle Offering Method",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere — Gentle Offering Method (preparatory)"
      },
      {
        "id": "3",
        "sphere": "Spirit Companions",
        "talent": "Ancestral Ear",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere — Ancestral Ear (preparatory)"
      },
      {
        "id": "4",
        "sphere": "Spirit Companions",
        "talent": "Vessel Mark",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere — Vessel Mark (preparatory)"
      }
    ],
    "grant_guidance": "You gain the Spirit Companions sphere in a preparatory form. Choose one preparatory Spirit Companions talent: - Iron Courtesy - Gentle Offering Method - Ancestral Ear - Vessel Mark At level 0, Spirit Companions from this Background does not grant a bonded spirit, combat companion, spirit servant, or hosted entity. It represents spirit literacy, shrine etiquette, vessel knowledge, offerings, taboos, and sensitivity to spiritual presence. When you gain Qi, Resonance, or another legal cultivation expression, you may choose one legal spirit relationship and one listed Variant Expression such as ancestor tablet, shrine familiar, dream visitor, household spirit, grave companion, weapon spirit, or pact-bound guide.",
    "kit": [
      "You begin with ritual clothes, incense, a bell or spirit token, chalk or ash, a pouch of offerings, and a charm given by someone who believed you."
    ],
    "equipment_text": "You begin with ritual clothes, incense, a bell or spirit token, chalk or ash, a pouch of offerings, and a charm given by someone who believed you.",
    "origin_insights": [
      "Spirit Pressure",
      "Grave Courtesy",
      "Sincere Offering",
      "Marked by Something"
    ],
    "social_hook": "Some people seek your help. Some call you cursed. Spirits may notice you before you know how to answer them.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Talisman Apprentice": {
    "name": "Talisman Apprentice",
    "region": "Campaign origin",
    "description": "You copied strokes until your fingers cramped and learned that one crooked line can ruin a working. You may not yet know true talisman craft, but you understand ink, paper, seals, focus, and precision.",
    "ability_options": [
      "Intelligence",
      "Dexterity",
      "Wisdom"
    ],
    "skills": [
      "Arcana",
      "Investigation"
    ],
    "tools": [
      "You gain proficiency with calligrapher’s supplies."
    ],
    "tools_text": "You gain proficiency with calligrapher’s supplies.",
    "feature": "Talisman halls, clerks, scribes, and formation assistants may respect clean work. Masters may judge you harshly for small mistakes.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Talismans",
        "talent": "Talisman Master’s Ink",
        "status": "active",
        "source_text": "Talismans Sphere. You gain the Talismans sphere and the Talisman Master’s Ink talent."
      },
      {
        "id": "2",
        "sphere": "Talismans",
        "talent": "Hidden Sleeve Preparation",
        "status": "active",
        "source_text": "Talismans Sphere. You gain the Talismans sphere and the Hidden Sleeve Preparation talent."
      },
      {
        "id": "3",
        "sphere": "Ink",
        "talent": "Vermilion Correction",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Vermilion Correction talent."
      },
      {
        "id": "4",
        "sphere": "Equipment",
        "talent": "Reinforced Robes",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent."
      }
    ],
    "grant_guidance": "Choose one: - Talismans Sphere. You gain the Talismans sphere and the Talisman Master’s Ink talent. - Talismans Sphere. You gain the Talismans sphere and the Hidden Sleeve Preparation talent. - Ink Sphere. You gain the Ink sphere and the Vermilion Correction talent. - Equipment Sphere. You gain the Equipment sphere and the Reinforced Robes talent. At level 0, Talismans and Ink from this Background represent copying, seal literacy, safe handling, material preparation, and recognition of common talisman structures. They do not grant full talismanic battle arts unless the chosen talent explicitly functions at mortal scale. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as paper seal, silk strip, bone tag, jade slip, blood-ink, scripture-stroke, or formation-script practice.",
    "kit": [
      "You begin with work robes, calligrapher’s supplies, blank paper, practice talisman scraps with no supernatural effect, ink, a straightedge, and a sealed lesson you cannot yet read."
    ],
    "equipment_text": "You begin with work robes, calligrapher’s supplies, blank paper, practice talisman scraps with no supernatural effect, ink, a straightedge, and a sealed lesson you cannot yet read.",
    "origin_insights": [
      "Formation Curiosity",
      "Scripture Memory",
      "Paper Trail",
      "Still Hands"
    ],
    "social_hook": "Talisman halls, clerks, scribes, and formation assistants may respect clean work. Masters may judge you harshly for small mistakes.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Wandering Healer": {
    "name": "Wandering Healer",
    "region": "Campaign origin",
    "description": "You treated coughs, fevers, wounds, births, infections, broken bones, and grief before you ever touched cultivation. You know that saving someone often begins with staying calm.",
    "ability_options": [
      "Wisdom",
      "Intelligence",
      "Charisma"
    ],
    "skills": [
      "Medicine",
      "Insight"
    ],
    "tools": [
      "You gain proficiency with the herbalism kit or healer’s kit."
    ],
    "tools_text": "You gain proficiency with the herbalism kit or healer’s kit.",
    "feature": "Common folk may trust healers faster than warriors. Powerful people may value your skill but still treat you as a tool.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Alchemy",
        "talent": "Healing Pill",
        "status": "active",
        "source_text": "Alchemy Sphere. You gain the Alchemy sphere and the Healing Pill recipe."
      },
      {
        "id": "2",
        "sphere": "Alchemy",
        "talent": "Calming Heart Pill",
        "status": "active",
        "source_text": "Alchemy Sphere. You gain the Alchemy sphere and the Calming Heart Pill recipe."
      },
      {
        "id": "3",
        "sphere": "Life",
        "talent": "Clear Physician’s Eye",
        "status": "active",
        "source_text": "Life Sphere. You gain the Life sphere and the Clear Physician’s Eye talent."
      },
      {
        "id": "4",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      }
    ],
    "grant_guidance": "Choose one: - Alchemy Sphere. You gain the Alchemy sphere and the Healing Pill recipe. - Alchemy Sphere. You gain the Alchemy sphere and the Calming Heart Pill recipe. - Life Sphere. You gain the Life sphere and the Clear Physician’s Eye talent. - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. At level 0, Alchemy and Life from this Background represent medicine, diagnosis, stabilizing treatment, pulse reading, and practical care. They do not grant full supernatural healing unless the chosen talent explicitly functions at mortal scale. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as physician’s qi, mercy hand, herb-pulse method, battlefield triage, shrine-healing, or life-thread diagnosis.",
    "kit": [
      "You begin with plain travel clothes, a healer’s kit or herbalism kit, bandages, needle and thread, a small knife, a medicine pouch, and a list of patients you could not save."
    ],
    "equipment_text": "You begin with plain travel clothes, a healer’s kit or herbalism kit, bandages, needle and thread, a small knife, a medicine pouch, and a list of patients you could not save.",
    "origin_insights": [
      "Triage Mind",
      "Steady Hands",
      "Bitter Root Wisdom",
      "Body Is a Shrine"
    ],
    "social_hook": "Common folk may trust healers faster than warriors. Powerful people may value your skill but still treat you as a tool.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "War Refugee": {
    "name": "War Refugee",
    "region": "Campaign origin",
    "description": "War burned your old life down. You fled soldiers, beasts, famine, sect conflict, bandits, imperial punishment, or a battle between powers too large to care who lived below them.",
    "ability_options": [
      "Constitution",
      "Dexterity",
      "Wisdom"
    ],
    "skills": [
      "Survival",
      "Perception"
    ],
    "tools": [
      "You gain one language, vehicle proficiency, or practical trade from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain one language, vehicle proficiency, or practical trade from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Refugees know routes, rumors, cruelty, and kindness that official histories ignore. Your loss may connect you to enemies, survivors, or unfinished revenge.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Equipment",
        "talent": "Sleep in Armor",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Sleep in Armor talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Padded Layers",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Padded Layers talent."
      },
      {
        "id": "3",
        "sphere": "Scoundrel",
        "talent": "Cut and Run",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Cut and Run (CUT AND RUN) talent."
      },
      {
        "id": "4",
        "sphere": "Athletics",
        "talent": "Swift Movement",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Swift Movement talent."
      }
    ],
    "grant_guidance": "Choose one: - Equipment Sphere. You gain the Equipment sphere and the Sleep in Armor talent. - Equipment Sphere. You gain the Equipment sphere and the Padded Layers talent. - Scoundrel Sphere. You gain the Scoundrel sphere and the Cut and Run (CUT AND RUN) talent. - Athletics Sphere. You gain the Athletics sphere and the Swift Movement talent. If Scoundrel or Athletics later awakens into active sphere use, choose an listed Variant Expression that reflects whether your survival came through flight, scavenging, ruined streets, refugee caravans, battlefield escape, or refusing to collapse.",
    "kit": [
      "You begin with patched clothes, a blanket, a small weapon, a family keepsake, travel rations, a waterskin, and something you carried from home when you should have dropped it."
    ],
    "equipment_text": "You begin with patched clothes, a blanket, a small weapon, a family keepsake, travel rations, a waterskin, and something you carried from home when you should have dropped it.",
    "origin_insights": [
      "Sleep Light",
      "No One Saves You",
      "Hunger Memory",
      "Hold the Line"
    ],
    "social_hook": "Refugees know routes, rumors, cruelty, and kindness that official histories ignore. Your loss may connect you to enemies, survivors, or unfinished revenge.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Workshop Apprentice": {
    "name": "Workshop Apprentice",
    "region": "Campaign origin",
    "description": "You worked under a craftsperson: smith, carpenter, potter, weaver, mechanic, shipwright, glassworker, jeweler, printer, painter, or maker of ordinary things that survive ordinary hands.",
    "ability_options": [
      "Dexterity",
      "Intelligence",
      "Constitution"
    ],
    "skills": [
      "Investigation",
      "Sleight of Hand"
    ],
    "tools": [
      "You gain proficiency with one artisan’s tool of your choice."
    ],
    "tools_text": "You gain proficiency with one artisan’s tool of your choice.",
    "feature": "Craft halls, laborers, merchants, and practical people respect useful hands. Sect disciples may overlook you until something important breaks.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Blacksmith",
        "talent": "Field Repair",
        "status": "active",
        "source_text": "Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent."
      },
      {
        "id": "2",
        "sphere": "Blacksmith",
        "talent": "Workman’s Eye",
        "status": "active",
        "source_text": "Blacksmith Sphere. You gain the Blacksmith sphere and the Workman’s Eye talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      },
      {
        "id": "4",
        "sphere": "Ink",
        "talent": "Revealing Script",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Revealing Script talent."
      }
    ],
    "grant_guidance": "Choose one: - Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent. - Blacksmith Sphere. You gain the Blacksmith sphere and the Workman’s Eye talent. - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. - Ink Sphere. You gain the Ink sphere and the Revealing Script talent. At level 0, Blacksmith and Ink from this Background represent tool handling, repair, diagrams, material sense, and workshop discipline. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as forge-hand, repair scripture, weapon maintenance, artifact apprentice, diagram craft, kiln method, or living-tool practice.",
    "kit": [
      "You begin with work clothes, one artisan’s tool, chalk or measuring string, a repair kit, a half-finished project, and a debt or promise owed to your teacher."
    ],
    "equipment_text": "You begin with work clothes, one artisan’s tool, chalk or measuring string, a repair kit, a half-finished project, and a debt or promise owed to your teacher.",
    "origin_insights": [
      "Tool Memory",
      "Still Hands",
      "Patient Mind",
      "Scripture Memory"
    ],
    "social_hook": "Craft halls, laborers, merchants, and practical people respect useful hands. Sect disciples may overlook you until something important breaks.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Village Child": {
    "name": "Village Child",
    "region": "Campaign origin",
    "description": "You were raised in a village, farmstead, orchard, rice field, fishing hamlet, herding camp, or roadside settlement far from the great sects. Your life was ordinary by cultivator standards: work, seasons, elders, hunger, festivals, grudges, and weather. That ordinariness taught you things spoiled disciples often miss.",
    "ability_options": [
      "Constitution",
      "Wisdom",
      "Strength"
    ],
    "skills": [
      "Animal Handling",
      "Survival"
    ],
    "tools": [
      "You gain proficiency with one artisan’s tool, farmer’s tools, or land vehicles."
    ],
    "tools_text": "You gain proficiency with one artisan’s tool, farmer’s tools, or land vehicles.",
    "feature": "Common people recognize you as one of their own. They may feed you, warn you, or ask for help more readily than they would approach a polished sect disciple.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Harvesting and Gathering",
        "talent": "Drying Shed Method",
        "status": "active",
        "source_text": "Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Drying Shed Method talent."
      },
      {
        "id": "2",
        "sphere": "Athletics",
        "talent": "Mighty Conditioning",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Mighty Conditioning talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Padded Layers",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Padded Layers talent."
      }
    ],
    "grant_guidance": "Choose one: - Harvesting and Gathering Sphere. You gain the Harvesting and Gathering sphere and the Drying Shed Method talent. - Athletics Sphere. You gain the Athletics sphere and the Mighty Conditioning talent. - Equipment Sphere. You gain the Equipment sphere and the Padded Layers talent.",
    "kit": [
      "You begin with plain work clothes, a farming tool or staff, a blanket, a waterskin, five days of simple food, a village charm, and a small gift from someone who hoped you would return."
    ],
    "equipment_text": "You begin with plain work clothes, a farming tool or staff, a blanket, a waterskin, five days of simple food, a village charm, and a small gift from someone who hoped you would return.",
    "origin_insights": [
      "Hunger Memory",
      "Weather Ear",
      "Patient Mind",
      "Tool Memory"
    ],
    "social_hook": "Common people recognize you as one of their own. They may feed you, warn you, or ask for help more readily than they would approach a polished sect disciple.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Criminal Runner": {
    "name": "Criminal Runner",
    "region": "Campaign origin",
    "description": "You carried messages, goods, threats, debts, or contraband for people who preferred not to be named. You learned shortcuts, bribes, hidden doors, coded gestures, and how to look harmless while moving something dangerous.",
    "ability_options": [
      "Dexterity",
      "Charisma",
      "Wisdom"
    ],
    "skills": [
      "Stealth",
      "Deception"
    ],
    "tools": [
      "You gain proficiency with thieves’ tools and one coded street language, gang cant, or regional trade argot from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with thieves’ tools and one coded street language, gang cant, or regional trade argot from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Criminals, smugglers, debt collectors, and corrupt guards may know your face or your routes. That can be useful, dangerous, or both.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Scoundrel",
        "talent": "Hidden Tool Cache",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Hidden Tool Cache (HIDDEN TOOL CACHE) talent."
      },
      {
        "id": "2",
        "sphere": "Scoundrel",
        "talent": "Switcheroo",
        "status": "active",
        "source_text": "Scoundrel Sphere. You gain the Scoundrel sphere and the Switcheroo (SWITCHEROO) talent."
      },
      {
        "id": "3",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      }
    ],
    "grant_guidance": "Choose one: - Scoundrel Sphere. You gain the Scoundrel sphere and the Hidden Tool Cache (HIDDEN TOOL CACHE) talent. - Scoundrel Sphere. You gain the Scoundrel sphere and the Switcheroo (SWITCHEROO) talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent.",
    "kit": [
      "You begin with practical dark clothes, thieves’ tools, a small knife, a coded token, a concealed pouch, cheap travel papers, and one sealed message you were never supposed to read."
    ],
    "equipment_text": "You begin with practical dark clothes, thieves’ tools, a small knife, a coded token, a concealed pouch, cheap travel papers, and one sealed message you were never supposed to read.",
    "origin_insights": [
      "Street-Hardened",
      "Quick Hands",
      "Vanishing Step",
      "Paper Trail"
    ],
    "social_hook": "Criminals, smugglers, debt collectors, and corrupt guards may know your face or your routes. That can be useful, dangerous, or both.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Artisan’s Child": {
    "name": "Artisan’s Child",
    "region": "Campaign origin",
    "description": "You were raised in the rhythm of a trade: clay, thread, lacquer, bronze, jade dust, leather, paper, bells, baskets, dyes, glass, bone, or wood. You learned patience, repair, pattern, material quality, and the pride of work that survives the maker.",
    "ability_options": [
      "Dexterity",
      "Intelligence",
      "Wisdom"
    ],
    "skills": [
      "Investigation",
      "Insight"
    ],
    "tools": [
      "You gain proficiency with one artisan’s tool of your choice."
    ],
    "tools_text": "You gain proficiency with one artisan’s tool of your choice.",
    "feature": "Craftspeople may judge your hands before your words. Nobles and disciples may overlook you until something valuable breaks.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Blacksmith",
        "talent": "Field Repair",
        "status": "active",
        "source_text": "Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent."
      },
      {
        "id": "2",
        "sphere": "Equipment",
        "talent": "Field Maintenance",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent."
      },
      {
        "id": "3",
        "sphere": "Ink",
        "talent": "Concealing Script",
        "status": "active",
        "source_text": "Ink Sphere. You gain the Ink sphere and the Concealing Script talent."
      }
    ],
    "grant_guidance": "Choose one: - Blacksmith Sphere. You gain the Blacksmith sphere and the Field Repair talent. - Equipment Sphere. You gain the Equipment sphere and the Field Maintenance talent. - Ink Sphere. You gain the Ink sphere and the Concealing Script talent. If Blacksmith or Ink later becomes a true cultivation expression, choose an listed Variant Expression appropriate to the trade: forge, repair, inscription, seal-work, craft-memory, or material resonance.",
    "kit": [
      "You begin with work clothes, one artisan’s tool, a measuring cord, chalk or charcoal, repair scraps, a half-finished object, and a promise owed to or by your teacher."
    ],
    "equipment_text": "You begin with work clothes, one artisan’s tool, a measuring cord, chalk or charcoal, repair scraps, a half-finished object, and a promise owed to or by your teacher.",
    "origin_insights": [
      "Still Hands",
      "Perfect the Stroke",
      "Tool Memory",
      "Patient Mind"
    ],
    "social_hook": "Craftspeople may judge your hands before your words. Nobles and disciples may overlook you until something valuable breaks.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Border Scout": {
    "name": "Border Scout",
    "region": "Campaign origin",
    "description": "You grew up near a border: empire and steppe, forest and road, sect territory and wilderness, village land and beast range, legal map and lived reality. You learned to move first, report clearly, and distrust quiet horizons.",
    "ability_options": [
      "Dexterity",
      "Wisdom",
      "Constitution"
    ],
    "skills": [
      "Perception",
      "Survival"
    ],
    "tools": [
      "You gain proficiency with cartographer’s tools or land vehicles. You also know one border language, military sign, or tribal language from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with cartographer’s tools or land vehicles. You also know one border language, military sign, or tribal language from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Border folk may respect your caution. Court officials may dislike your habit of describing problems exactly as they are.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Athletics",
        "talent": "Swift Movement",
        "status": "active",
        "source_text": "Athletics Sphere. You gain the Athletics sphere and the Swift Movement talent."
      },
      {
        "id": "2",
        "sphere": "Trap",
        "talent": "Warning Trigger",
        "status": "active",
        "source_text": "Trap Sphere. You gain the Trap sphere and the Warning Trigger talent."
      },
      {
        "id": "3",
        "sphere": "Sniper",
        "talent": "Still-Scope Posture",
        "status": "active",
        "source_text": "Sniper Sphere. You gain the Sniper sphere and the Still-Scope Posture talent."
      }
    ],
    "grant_guidance": "Choose one: - Athletics Sphere. You gain the Athletics sphere and the Swift Movement talent. - Trap Sphere. You gain the Trap sphere and the Warning Trigger talent. - Sniper Sphere. You gain the Sniper sphere and the Still-Scope Posture talent. If Sniper later awakens as a cultivation expression, choose whether it represents bow discipline, breath-killing focus, thrown-weapon precision, firearm-equivalent campaign technology, or another listed Variant Expression.",
    "kit": [
      "You begin with travel clothes, a shortbow or simple ranged weapon, a map case, chalk or trail markers, a weather cloak, five days of rations, and a warning token from a border post."
    ],
    "equipment_text": "You begin with travel clothes, a shortbow or simple ranged weapon, a map case, chalk or trail markers, a weather cloak, five days of rations, and a warning token from a border post.",
    "origin_insights": [
      "Weather Ear",
      "Beast Sign",
      "Open Sky Nerve",
      "Sleep Light"
    ],
    "social_hook": "Border folk may respect your caution. Court officials may dislike your habit of describing problems exactly as they are.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Ancestral Shrine Keeper": {
    "name": "Ancestral Shrine Keeper",
    "region": "Campaign origin",
    "description": "You tended tablets, names, incense, offerings, genealogies, graves, old bells, and family rites. You learned that the dead are not gone merely because they are silent, and that a family’s history can bless, bind, or devour its children.",
    "ability_options": [
      "Wisdom",
      "Charisma",
      "Intelligence"
    ],
    "skills": [
      "Religion",
      "History"
    ],
    "tools": [
      "You gain proficiency with calligrapher’s supplies and know Classical or one ancestral liturgical language from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with calligrapher’s supplies and know Classical or one ancestral liturgical language from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Families, elders, shrine attendants, and spirits may treat you as someone who understands obligation. That respect may also pull you into old debts.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Spirit Companions",
        "talent": "Iron Courtesy",
        "status": "preparatory",
        "source_text": "Spirit Companions Sphere. You gain the Spirit Companions sphere in a preparatory form and the Iron Courtesy talent."
      },
      {
        "id": "2",
        "sphere": "Karma",
        "talent": "Witness Seal",
        "status": "dormant",
        "source_text": "Karma Sphere. You gain the Karma sphere in a dormant form and the Witness Seal talent."
      },
      {
        "id": "3",
        "sphere": "Talismans",
        "talent": "Warding Talisman",
        "status": "active",
        "source_text": "Talismans Sphere. You gain the Talismans sphere and the Warding Talisman talent."
      }
    ],
    "grant_guidance": "Choose one: - Spirit Companions Sphere. You gain the Spirit Companions sphere in a preparatory form and the Iron Courtesy talent. - Karma Sphere. You gain the Karma sphere in a dormant form and the Witness Seal talent. - Talismans Sphere. You gain the Talismans sphere and the Warding Talisman talent. At level 0, Spirit Companions does not grant a companion. Karma remains dormant until the character has a printed activation rule. These choices represent ancestral literacy, rites, taboos, and future access. When the sphere becomes fully active, choose an listed Variant Expression.",
    "kit": [
      "You begin with plain ritual clothes, incense, calligrapher’s supplies, a family or shrine token, a small bell, a pouch of offerings, and a copied list of names."
    ],
    "equipment_text": "You begin with plain ritual clothes, incense, calligrapher’s supplies, a family or shrine token, a small bell, a pouch of offerings, and a copied list of names.",
    "origin_insights": [
      "Shrine Child",
      "Sincere Offering",
      "Family Ledger",
      "Grave Courtesy"
    ],
    "social_hook": "Families, elders, shrine attendants, and spirits may treat you as someone who understands obligation. That respect may also pull you into old debts.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  },
  "Traveling Performer": {
    "name": "Traveling Performer",
    "region": "Campaign origin",
    "description": "You lived by voice, movement, mask, instrument, joke, dance, story, acrobatics, puppets, or staged grief. You learned how crowds breathe, how nobles pretend not to listen, and how truth can survive when dressed as entertainment.",
    "ability_options": [
      "Charisma",
      "Dexterity",
      "Wisdom"
    ],
    "skills": [
      "Performance",
      "Acrobatics"
    ],
    "tools": [
      "You gain proficiency with one musical instrument, disguise kit, or performer’s tools from the campaign’s tool, language, or trade proficiency lists."
    ],
    "tools_text": "You gain proficiency with one musical instrument, disguise kit, or performer’s tools from the campaign’s tool, language, or trade proficiency lists.",
    "feature": "Performers can enter places soldiers cannot, hear what officials deny, and vanish before blame settles. They are welcomed, dismissed, exploited, and suspected in equal measure.",
    "grant_options": [
      {
        "id": "1",
        "sphere": "Music",
        "talent": "Captivating Melody",
        "status": "active",
        "source_text": "Music Sphere. You gain the Music sphere and the Captivating Melody talent."
      },
      {
        "id": "2",
        "sphere": "Jester",
        "talent": "False Opening",
        "status": "active",
        "source_text": "Jester Sphere. You gain the Jester sphere and the False Opening talent."
      },
      {
        "id": "3",
        "sphere": "Puppetry",
        "talent": "Little Servant’s Errand",
        "status": "active",
        "source_text": "Puppetry Sphere. You gain the Puppetry sphere and the Little Servant’s Errand talent."
      },
      {
        "id": "4",
        "sphere": "Equipment",
        "talent": "Hidden Plates",
        "status": "active",
        "source_text": "Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent."
      }
    ],
    "grant_guidance": "Choose one: - Music Sphere. You gain the Music sphere and the Captivating Melody talent. - Jester Sphere. You gain the Jester sphere and the False Opening talent. - Puppetry Sphere. You gain the Puppetry sphere and the Little Servant’s Errand talent. - Equipment Sphere. You gain the Equipment sphere and the Hidden Plates talent. If Music, Jester, or Puppetry later awakens as cultivation, choose an listed Variant Expression: performance, mask, satire, ritual theater, spirit-song, puppet-stage, or another culturally fitting form.",
    "kit": [
      "You begin with performer’s clothes, a costume piece or mask, one instrument or performer’s kit, travel papers, a small blade, a collection bowl, and a rumor learned from an audience member who thought you were not listening."
    ],
    "equipment_text": "You begin with performer’s clothes, a costume piece or mask, one instrument or performer’s kit, travel papers, a small blade, a collection bowl, and a rumor learned from an audience member who thought you were not listening.",
    "origin_insights": [
      "Painted Face",
      "Courtly Caution",
      "Read the Buyer",
      "Vanishing Step"
    ],
    "social_hook": "Performers can enter places soldiers cannot, hear what officials deny, and vanish before blame settles. They are welcomed, dismissed, exploited, and suspected in equal measure.",
    "source": "Tianxia_PHB_Backgrounds_v2_BOOK_CLEAN_ORIGIN_RECONCILED_v0_6.md"
  }
};
