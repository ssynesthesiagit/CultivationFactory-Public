# Complete Character Creation Request

Return exactly one JSON object conforming to RESPONSE_SCHEMA.json. Copy the exact request_sha256 into the response. Do not assert compiled mechanics, readiness, or artifact identities. The local Factory validates and compiles every mechanical choice.
