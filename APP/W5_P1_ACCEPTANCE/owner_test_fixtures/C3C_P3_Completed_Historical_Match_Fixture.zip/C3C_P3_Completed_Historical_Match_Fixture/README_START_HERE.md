# Completed C3C-P3 historical match fixture

This match was created and completed by the accepted C3C-P3 source.

Test only on a copy of `UserData`.

Required repair behavior:

- open as a completed read-only match;
- preserve every match file byte-for-byte;
- return the exact stored final summary;
- verify and replay to the exact final state;
- export without rewriting historical locks, journals, snapshots, or summary;
- reject resume and every new combat/controller action.
