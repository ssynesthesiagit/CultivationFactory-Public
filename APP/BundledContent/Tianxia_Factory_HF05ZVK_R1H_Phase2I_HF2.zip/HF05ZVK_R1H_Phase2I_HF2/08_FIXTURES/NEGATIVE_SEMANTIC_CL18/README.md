These exact CL18 packages are retained as semantic-negative regression fixtures. Both passed R1E structural gates and must fail R1F semantic validation.
