# Optional Command 4B Audit

- Status: `OPTIONAL_COMMAND_4B_IMMORTAL_ARTS_COMPLETE`
- Immortal Arts: 1
- Linked executable actions: 1
- Acquisition event: reconciled at CL13
- Limitations and behavior hooks: complete
