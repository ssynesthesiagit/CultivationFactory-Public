# Phase 2I Production Feedback Regression Fixtures

These ledgers were derived from two independent Phase 2H fresh-chat CL5 productions supplied for factory QA.

- `AnEui_Original` must be rejected for typed action-card field displacement.
- `AnEui_Repaired` must compile with typed variable Stamina cost and canonical talent provenance.
- `BaiMeizhen` must compile with complete multi-producer state provenance and canonical Item Book timing.

These are QA fixtures only and do not constitute real GM Screen release acceptance.
