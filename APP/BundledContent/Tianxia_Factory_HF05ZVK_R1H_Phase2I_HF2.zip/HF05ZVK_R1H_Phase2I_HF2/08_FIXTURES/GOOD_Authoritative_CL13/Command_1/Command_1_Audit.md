# Command 1 Audit

- Blueprint status: `COMMAND_1_BLUEPRINT_LOCKED`
- Source mode: synthetic acceptance fixture
- Target: CL13 Core Formation Qi Cultivation
- GM Screen: HF05ZUI-R2K
- Blocking questions: none
