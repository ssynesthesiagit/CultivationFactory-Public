# Command 5 Audit

- Verdict: `PASS_COMMAND_5_CONTROLLER`
- Candidate: `/mnt/data/P2C_GOOD_Authoritative_CL13_candidate_b.zip`
- Candidate SHA-256: `e4ffc20c565ace7d8fac251308b77469651742fcf48e5c8196d2b44d04fe9e54`
- Compiled files: `43`
- Consumer: `HF05ZUI-R2K`

No derived Build file was manually edited.
