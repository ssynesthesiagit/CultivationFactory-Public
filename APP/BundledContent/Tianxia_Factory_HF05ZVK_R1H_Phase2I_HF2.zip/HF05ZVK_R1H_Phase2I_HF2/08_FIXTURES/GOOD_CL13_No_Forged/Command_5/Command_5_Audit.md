# Command 5 Audit

- Verdict: `PASS_COMMAND_5_CONTROLLER`
- Candidate: `/mnt/data/P2C_GOOD_CL13_No_Forged_candidate_b.zip`
- Candidate SHA-256: `c2c774410dd900dfce614858c67c0cf53aaca08c6064f8feea43d3c462e827c2`
- Compiled files: `43`
- Consumer: `HF05ZUI-R2K`

No derived Build file was manually edited.
