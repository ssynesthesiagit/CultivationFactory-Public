# Phase 2D Feature Coverage Audit

**Verdict:** PASS — indexed feature coverage and suppression export enforced.

- Path features in CL13 acceptance fixture: **13**
- Cinder Heart tier features available by CL13: **3**
- Audited Insights exercised: **1**
- Companion-positive fixtures: **1 Companion**
- Structured Source CL / Realm Suppression rows: **59**
- Anti-shortcut negative tests: **12 / 12 PASS**
- Compile lanes: **4 / 4 PASS**
- GM Screen consumer schema changed: **No**

The validator derives expected Path and Subpath feature sets from the P2A/P2B indexes rather than trusting ledger assertions. Insight IDs resolve against the R4 catalogue. Companion features and independent actions must resolve. Every selected rule has structured Source CL and Realm Suppression data and an exact export row.
