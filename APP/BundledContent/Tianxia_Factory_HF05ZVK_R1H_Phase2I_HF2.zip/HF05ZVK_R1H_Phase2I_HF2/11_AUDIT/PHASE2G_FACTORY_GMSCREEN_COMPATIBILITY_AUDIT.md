# Phase 2G Factory / GM Screen Compatibility Audit

**Verdict:** `PASS — INSTALL READY`  
**Factory:** HF05ZVK-R1F Phase 2G  
**GM Screen:** HF05ZUI-R2K.1  
**Audit date:** July 13, 2026

## Material defects found and repaired

1. **Obsolete Command 6 consumer contract.** The embedded assets were R2K, but the proof harness still expected the former R2H 14-tab interface. Command 5, Command 6, manifests, schemas, and proof tooling now enforce the native 18-tab R2K.1 contract.
2. **Cross-runtime numeric hash mismatch.** Python distinguished integral JSON decimals such as `20.0` from `20`, while Chromium did not. The semantic hash now canonicalizes integral decimals before hashing. Acceptance remains strict; it was not bypassed.

## Fresh Factory-to-screen lanes

| Lane | ZIP entries | Tabs | Sidecars | Browser acceptance |
|---|---:|---:|---:|---|
| GOOD_Authoritative_CL13 | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |
| GOOD_CL13_No_Forged | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |
| GOOD_CL13_Immortal_Art | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |
| GOOD_ITEMBOOK_R1_STORAGE_RING | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |
| GOOD_COMPANION_COVERAGE | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |
| GOOD_BEASTMASTER_BEAST_COVERAGE | 53 | 18 | 26/26 | PASS REAL GMSCREEN ACCEPTANCE |

Every lane imported through native browser decompression and the pako fallback, rendered all 18 tabs, retained all 26 required sidecars, compact-saved and rehydrated, and produced zero page or console errors.

## Stateful compatibility

- Item Book Storage Ring: condition, durability HP, and stored weight preserved after compact save/rehydration.
- Bonded spirit: edited HP and injured status preserved; independent Action remained linked.
- Beastmaster beast: edited HP and resting status preserved; independent Action remained linked.

## Factory validation

- Canonical rules corpus: PASS
- Rules authority: PASS
- Path and Subpath indexes: PASS
- General negative-gate suite: PASS
- Semantic regression suite: PASS
- Feature anti-shortcut: 12/12 PASS
- Item anti-shortcut: 14/14 PASS
- Companion/beast anti-shortcut: 8/8 PASS

## Claim boundary

The browser environment blocked direct `file://` and loopback navigation. The exact production HTML, CSS, JavaScript, and catalogue assets were injected into Chromium, after which the normal ZIP file input, decompression, importer, renderer, interaction, compact save, rehydration, and native acceptance exporter were exercised. The user installation remains the final deployment-environment check.
