# Phase 2E — Item Book R1 Factory Installation Report

**Verdict:** `PASS_ITEMBOOK_R1_FACTORY_INSTALLATION`

## Installed authority

- Source package SHA-256: `7b11efa3376b997ea519195c6083a897c0ed9f64a9861b0e5733261cc63134c9`
- Item definitions: **318**
- Treasure Sets: **9**
- GM projection cards: **318**
- Source Item Schema R2 validation: **PASS, 0 errors, 0 warnings**
- Source bad-fixture regression: **12/12 detected as expected**

The Factory now treats Item Book R1 as active mechanical authority. Immutable definitions remain in the catalog, while mutable character-owned instances live in the R2 Equipment Ledger.

## Event-sourced acquisition

Every permanent Item Book instance must be represented by an advancement allocation using `channel: item`, `grant_type: item`, the instance ID as `grant_id`, `slot_cost: 0`, and the exact Item Book rules-packet IDs. Acquisition CL is provenance; Source CL and Realm floor remain separately exported.

The acceptance fixture records `INST_EXAMPLE_STORAGE_RING_01` through `AL_CL13_ITEM_STORAGE_RING` at CL13. Removing that allocation triggers `ITEM_ALLOCATION_MISSING`.

## Runtime exports

- `Equipment_Ledger.json` — authoritative R2 ledger
- `Equipment_Ledger_Legacy.json` — temporary current-GM-Screen compatibility projection
- `Item_Execution_Coverage.json`
- `Selected_Item_GM_Projection.json`

## Enforcement

The Factory validates Attunement, charges, storage, durability, consumption, Growth, Item Spirits, Set Resonance, mechanic-to-runtime mappings, universal selected-rule coverage, Source CL, Realm Suppression, and acquisition reconciliation.

- Item anti-shortcut suite: **14/14 PASS**
- General negative-gate suite: **78/78 PASS**
- Phase 2D feature anti-shortcut suite: **12/12 PASS**
- Rules authority: **12/12 PASS**
- Canonical rules sources verified: **95**

## Acceptance regression

All five lanes passed schema validation, complete selected-rule coverage, Command 5 compilation, and byte reproducibility:

1. Standard character
2. No-personal-forged character
3. Immortal Art character
4. Companion character
5. Item Book Storage Ring character

The Item Book smoke lane passed Commands 2–5 and produced **52 compiled files**. Its compiled Equipment Ledger passed Item Schema R2 with **0 errors and 0 warnings**.

## Claim boundary

The Factory-side integration is complete. The existing GM Screen schema was not changed, and a real-browser item rendering proof has **not** been claimed. Final R2 item UI, save/reload, and item-card rendering remain GM Screen integration work.
