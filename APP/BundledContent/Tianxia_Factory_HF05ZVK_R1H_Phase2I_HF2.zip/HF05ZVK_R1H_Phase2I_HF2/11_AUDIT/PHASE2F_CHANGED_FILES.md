# Phase 2F Changed Files

## Factory

- `00_READ_FIRST/PHASE2F_COMPANION_SHEET_RELEASE_NOTE.md`
- `01_COMMANDS/COMMAND_3_CHASSIS_AND_FULL_FEATURE_MAPPING.md`
- `01_COMMANDS/COMMAND_4_EXECUTABLE_COMBAT_AND_TECHNIQUE_BUILD.md`
- `02_CONTRACTS/COMPANION_SPIRIT_BEAST_CHARACTER_SHEET_CONTRACT_P2F.md`
- `03_TEMPLATES/Companion_Spirit_Beast_Sheet.examples.json`
- `03_TEMPLATES/Character_Master_Ledger.*.json`
- `04_SCHEMAS/companion_record.schema.json`
- `04_SCHEMAS/character_master_ledger.schema.json`
- `05_COMPILER/compile_character.py`
- `06_VALIDATORS/validate_selected_rule_execution_coverage.py`
- `06_VALIDATORS/run_phase2f_companion_sheet_suite.py`
- `08_FIXTURES/GOOD_COMPANION_COVERAGE/`
- `08_FIXTURES/GOOD_BEASTMASTER_BEAST_COVERAGE/`
- `10_GM_SCREEN_TARGET/` updated to HF05ZUI-R2K presentation patch
- `FACTORY_MANIFEST.json`

## GM Screen

- `index.html`
- `r2i-phase2e.js`
- `r2i-phase2e.css`
- `README.md`
- `GM_SCREEN_BUILD_MANIFEST.json`
- `HF05ZUI_R2K_RELEASE_NOTES.md`
