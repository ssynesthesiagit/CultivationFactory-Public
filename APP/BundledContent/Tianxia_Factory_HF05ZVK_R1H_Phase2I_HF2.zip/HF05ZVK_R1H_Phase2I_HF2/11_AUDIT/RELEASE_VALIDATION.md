# HF05ZVK-R1F Release Validation

- Verdict: `PASS_HF05ZVK_R1F_RELEASE_AUDIT`
- Matching consumer: `HF05ZUI-R2K.1`
- Matching combat admission target: `HF05ZN-R2D`
- Rules corpus: `PASS_HF05ZVK_R1F_RULES_CORPUS` (24 checked files)
- Rules authority: `10/10`
- Negative gates: `77/77`
- Semantic regression: `PASS_HF05ZVK_R1F_SEMANTIC_REGRESSION`
- Fixture lanes: `3/3` deterministic, semantic-pass, local-consumer-pass, and byte-identical through Command 6
- Authoritative Foundations: `30`
- Theoretical Chakra Foundations excluded: `32`

## Evidence boundary

The full serial audit controller exceeded the execution window because it runs multiple browser lanes sequentially. The final verdict is based on the same component suites executed separately. Command 6 local simulation does not authorize `FINAL_RELEASE_READY`; production still requires a real R2H.4 acceptance export bound to the exact candidate ZIP.
