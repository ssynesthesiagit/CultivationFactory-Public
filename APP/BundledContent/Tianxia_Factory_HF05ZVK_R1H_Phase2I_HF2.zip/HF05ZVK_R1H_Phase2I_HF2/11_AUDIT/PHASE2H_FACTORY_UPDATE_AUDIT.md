# Tianxia Phase 2H Factory / GM Screen / Combat Assurance Audit

## Executive verdict

The two independent fresh-chat productions confirmed that the Phase 2G factory required a coordinated assurance update. The failures were reproducible factory-contract defects, not merely inconsistent character-writing quality.

The coordinated successor set is:

- **Factory:** HF05ZVK-R1G — Phase 2H Assurance
- **GM Screen:** HF05ZUI-R2K.2 — Factory Assurance
- **Combat Bootstrap:** HF05ZN-R2F — Phase 2H Assurance

The candidate package schema remains **HF05ZVK-R1F** for compatibility. R1G is the producer release that emits and validates that schema. The GM Screen compact-save schema and the R2D combat-event protocol remain unchanged.

## Evidence received

| Evidence | SHA-256 | Role |
|---|---|---|
| LingQi_CL5_GM_Candidate_R2.zip | `8a603ca15054c91d2db5b077328d1ba673e57be7d1e5a3f0c16cbe6b142b7dee` | Independent fresh production |
| LingQi_Audit.zip | `1e71eb0e14ecc271332814499be2876a33c8419df1c44ba7fcc108e0283c534a` | Independent deep audit |
| LeeJia_CL5_Command6.zip | `557200eaebcfa0800b85dc61d11ab28422733b758024129e0590bfab8d572782` | Independent fresh production |
| LeeJia_Audit.zip | `560a241ef1c139916ccf88fb937f747a3156715119e6ffabf6e181d87059e75b` | Independent deep audit |

The originals were retained as immutable evidence. They were not silently modified or reclassified as Phase 2H releases.

## Confirmed defects and repairs

### 1. Foundation lifecycle contract contradiction — fixed

The Phase 2G master-ledger schema required separate `repair`, `treatment`, `temptations`, and `failure_consequences` lifecycle categories. Its semantic validator instead still demanded the obsolete combined `repair_treatment` field. Both independent productions exposed this same contradiction: schema validation could pass while semantic Command 4 validation failed.

**Phase 2H repair:** schema and semantic validation now use the same thirteen authoritative lifecycle categories. The obsolete combined field is accepted only as a deprecated compatibility alias and cannot replace the required split coverage.

### 2. Historical ability-state arithmetic — fixed

Both productions showed that final ability modifiers could be applied retroactively to earlier level rows.

- Ling Qi recorded CL1–3 Qi maxima as `4/8/12`; the correct pre-CL4 values were `3/6/9`.
- Lee Jia recorded CL1–3 base Qi using the later Intelligence modifier and also used that later modifier in five CL2–3 training records.

**Phase 2H repair:** ability scores and modifiers are reconstructed at each CL. HP, Path resources, ASI effects, and training records are validated against the historical ability state for the level where the event occurred.

### 3. Command 1 normalization and stale consumer assumptions — fixed

Phase 2G Command 1 handling did not consistently accept structured blueprint objects, the current external-inspiration source mode, CL4 ability plans, or the current GM Screen target. It could also defer the Recorded Art depth-floor failure until later commands.

**Phase 2H repair:** Command 1 normalizes structured and legacy-safe values, derives final ability targets including planned ASIs, requires HF05ZUI-R2K.2 and eighteen tabs, and enforces the CL/depth Recorded Art plan floor before the blueprint can lock.

### 4. Command 5 could bypass failed earlier gates — fixed

A later compile could seal even when an earlier command record was stale or failed.

**Phase 2H repair:** Command 5 re-runs and requires Commands 1–4 before compilation. Upstream arithmetic, source, lifecycle, coverage, or projection failures therefore block the deterministic candidate.

### 5. Projection freshness and duplicate rows — fixed

Legacy sphere/talent projections could drift from the canonical ledger or preserve duplicate rows.

**Phase 2H repair:** Command 3 and the compiler create exact deterministic projections from the master ledger. Stale or duplicated projection rows are validation failures rather than cosmetic warnings.

### 6. GM Screen presentation and retention — fixed

The current renderer had two assurance defects relevant to these productions:

- Foundation **Common Expression** could be presented as **Awakened**.
- Mundane or legacy equipment could be hidden when R2 item records were present.

**R2K.2 repair:** Common Expression remains a distinct visible stage, R2 and legacy/mundane equipment are co-visible, and the complete intended sidecar contract is enforced at **26/26** retained files. The permanent tab registry remains **18 tabs**.

### 7. Combat intake alignment — updated without changing combat doctrine

The combat engine itself remained sound. Its boundary was updated to require R2K.2 acceptance, all 26 retained sidecars, and the R1G producer/R1F candidate compatibility model. Attack/save parsing was broadened for current Tianxia phrasing. The R2D turn, segment, freeze, narrative, and final-report protocol is preserved.

## Reproduction against old evidence

The updated factory rejects the old Lee Jia workspace for the defects that the prior process missed:

- `BLUEPRINT_GM_SCREEN_TARGET_MISMATCH:HF05ZUI-R2K.1!=HF05ZUI-R2K.2`
- `RECORDED_ART_PLAN_BELOW_DEPTH_FLOOR:1<4`
- `LEVEL_RESOURCE_BASE_MISMATCH:CL1`
- `LEVEL_RESOURCE_BASE_MISMATCH:CL2`
- `LEVEL_RESOURCE_BASE_MISMATCH:CL3`
- five `TRAINING_ABILITY_MODIFIER_MISMATCH` records at CL2–3

Command 5 also rejects the same unresolved upstream defects, proving that the new cross-command gate cannot be bypassed.

## Repaired production-path regression

Lee Jia was repaired at the authored master-ledger/workspace level and then rebuilt through the normal process. Build outputs were not manually edited. The R2K.2 acceptance report in this QA lane was produced by the automated local Chromium harness to exercise the production contract; it is **QA-only evidence** and does not replace the user-exported desktop acceptance required for an actual release.

- Commands 1–5: **PASS**
- Deterministic candidate / Command 6 final SHA-256: `0be4cce9907c9ce7ee92398ded8b82b764e60ce3873b9b6e810de38cdc41c064`
- Candidate entries: **53**
- Native R2K.2 acceptance: **PASS_REAL_GMSCREEN_ACCEPTANCE**
- Tabs: **18/18**
- Sidecars: **26/26**
- Save/reload: **PASS**
- Projection fidelity: **PASS**
- Browser page errors: **0**
- Browser console errors: **0**
- R2F production combat admission: **PASS**, with **0 errors and 0 warnings**
- Combat actor SHA-256: `9a4b4236b3b155da4e59e7dbf1be764adb032617707eb9b58606bcaa87115c7d`

This repaired package is a regression proof for the update. It does not retroactively alter the user-supplied original.

## Release validation

Final release counts and archive hashes are recorded in `Phase2H_Factory_Update_Results.json` and in each package manifest. The coordinated tests include:

- Python and JavaScript syntax validation
- canonical rules-corpus validation
- rules-authority suite
- negative-gate suite
- semantic regression suite
- all six factory/GM Screen fixture lanes
- deterministic candidate recompilation
- Command 6 non-mutation checks
- real-production Lee Jia regression
- combat compatibility, security, adversarial, Emergency Forging, and 21-round continuity suites
- ZIP extraction and checksum replay

## Operational consequence

Use the Phase 2H combined bundle for all new characters. Existing Phase 2G candidates may still render, but they should not be considered newly assured production outputs. A character intended for production should be rebuilt from its `Character_Master_Ledger.json` under R1G and should receive a fresh R2K.2 acceptance report bound to the exact candidate SHA-256 before R2F production combat admission.
