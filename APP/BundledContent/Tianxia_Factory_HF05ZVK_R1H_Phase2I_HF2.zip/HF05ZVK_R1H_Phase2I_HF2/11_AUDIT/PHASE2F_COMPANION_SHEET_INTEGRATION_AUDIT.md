# Phase 2F Companion, Spirit, and Beast Character-Sheet Integration Audit

**Verdict:** `PASS_COMPANION_SPIRIT_BEAST_SHEETS_PHASE2F`

## Scope

Phase 2F generalizes the Factory's persistent companion record and the GM Screen's companion tab. It supports bonded spirits, Spirit companions, Beastmaster beasts, awakened or trained beasts, mounts, constructs, puppets, Item Spirits, summoned entities, and future persistent companion categories.

## Factory changes

- Generalized `companion_record.schema.json`.
- Required readable descriptive profiles and complete companion stat blocks.
- Added exact turn-control, command, bond/training, care/sustenance, equipment, injury/recovery, progression, and form records.
- Added mutable `status` and `stat_block.hp_current`.
- Added a bonded-spirit fixture and a separate Beastmaster beast fixture.
- Added eight anti-shortcut tests: four spirit and four beast failures.
- Preserved universal execution coverage, Source CL, Realm Suppression, and event-sourced character construction.

## GM Screen changes

The tab is now **Companions, Spirits & Beasts**. Each persistent companion receives:

- a roster entry;
- readable appearance, personality, voice, relationship, origin, goals, fears, loyalties, taboos, and out-of-combat behavior;
- AC, HP, speed, ability scores, saves, skills, senses, languages, defenses, resources, conditions, and injuries;
- Actions and features;
- spirit bond and offerings, or beast training, commands, diet, shelter, and care;
- exact turn model and independent-Action permissions;
- equipment, progression, 0 HP consequences, healing or reconstruction, and forms;
- collapsed technical provenance.

Companion HP and status survive compact save/reload. Companion Actions display source badges and link back to the owning sheet.

## Validation

- Bonded-spirit schema and coverage: **PASS**
- Beastmaster-beast schema and coverage: **PASS**
- Phase 2F anti-shortcut suite: **8/8 PASS**
- Existing Phase 2D anti-shortcut suite: **12/12 PASS**
- Existing Item Book anti-shortcut suite: **PASS**
- General negative-gate suite: **PASS**
- Rules authority and corpus: **PASS**
- Semantic regression: **PASS**
- Path and Subpath indexes: **PASS**
- Chromium companion/beast assertions: **14/14 PASS**
- Chromium item save/reload regression: **PASS**
- Browser page errors: **0**
- Browser console errors: **0**

## Claim boundary

No Path, Subpath, Insight, item, or companion combat mechanics were changed. The update adds structured authoring requirements, validation, display, and mutable campaign-state handling. The base consumer contract remains `HF05ZUI-R2K`; the installed presentation patch is `HF05ZUI-R2K-COMPANION-SPIRIT-BEAST-SHEETS`.
