# Tianxia Methods Master Document v0.1

**Scope:** Methods 1–80  
**Purpose:** player/DM-facing Method catalog for campaign discovery, sect inheritance, scripture rewards, Foundation preparation, and breakthrough compatibility.

Methods are lightweight cultivation profiles. They shape resource depth, breakthrough compatibility, and Foundation compatibility without requiring action packets.

## Source Chunks

| Chunk | Source File | SHA-256 |
|---|---|---|
| 1 | Tianxia_Methods_Creation_Chunk_01_v0_5_FINAL_DRIFT_UNDEFINED_CLEAN.md | 9ff6e670843ee95639f6efaaf3c0fa8738dac43640b70a0f8d85a7dd44ffdb6f |
| 2 | Tianxia_Methods_Creation_Chunk_02_v0_4_FINAL_DRIFT_UNDEFINED_CLEAN.md | 689f5e3294ce0dae646c0a531eea3394e67729b9b9c267c4220fddaff5608377 |
| 3 | Tianxia_Methods_Creation_Chunk_03_v0_3_DRIFT_UNDEFINED_CLEAN.md | 74a51dda7ec59275333695d611c846e3278d5479c6d17c894d3bcb0965b912fd |
| 4 | Tianxia_Methods_Creation_Chunk_04_v0_4_PAIR_AUDIT_CLEAN.md | e3a2f0580a2f7aff4ea23375ffbd5df9c2208a56f6fe352397d906c10837c2d2 |
| 5 | Tianxia_Methods_Creation_Chunk_05_v0_2_FINAL_CLEAN.md | e4f62fbbbcd86ce53b9a59ad16e0db50d37eb47d114be299538679a83d2c2d7d |

## Core Method Rules

- A character may know multiple Methods, but only one Method is the character's **Primary Method** at a time.
- Only the Primary Method applies Resource Shape, Breakthrough Shape, and Foundation Shape.
- Method bonuses do not stack unless a later rule explicitly says otherwise.
- Changing Primary Method is a cultivation opportunity, not a combat or daily-loadout choice.
- A blank starting sect Method can be replaced freely the first time the character gains a specialized Method.
- Changing Method recalculates maximum Path resource but never restores resource by itself.

## Method Shape Reference

### Resource Shape

| Shape | Effect |
|---|---|
| Neutral | No change. |
| Deep Reservoir | Increase max Path resource by PB. |
| Great Reservoir | Increase max Path resource by 2 × PB. |
| Narrow Channel | Decrease max Path resource by PB; gain +PB to compatible breakthrough checks. |
| Strained Reservoir | Increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks. |
| Overdrawn Reservoir | Increase max Path resource by 3 × PB; take –2 × PB on incompatible breakthrough checks or correction checks tied to the Method. |

### Breakthrough Shape

| Shape | Effect |
|---|---|
| Baseline | No modifier. |
| Stable | +PB to compatible breakthrough checks. |
| Profoundly Stable | +2 × PB to compatible breakthrough checks. |
| Harsh | +PB to compatible checks; –PB to incompatible checks. |
| Severe | +2 × PB to compatible checks; –2 × PB to incompatible checks. |
| Corrective | +PB to relevant repair/correction breakthrough checks. |
| Failure-Gated | Can qualify for printed options requiring a prior failure, scar, deviation, hidden injury, or unresolved lesson. |

### Foundation Shape

| Shape | Use |
|---|---|
| Open | No specific Foundation theme. |
| Compatible | Naturally works with listed themes. |
| Focused | Strongly supports listed themes and may be required by later rules. |
| Incompatible | Reserved for later rules that explicitly invoke mismatch. |
| Corrective | Used to repair or stabilize damaged, flawed, or incomplete Foundations. |
| Transformative | Used for changing or redirecting Foundation route. |

## Method Index

| # | Method | Resource | Breakthrough | Foundation |
|---|---|---|---|---|
| 1 | Outer Gate Root Method | Neutral | Baseline | Open |
| 2 | Ash-Breath Furnace Method | Great Reservoir | Harsh | Focused |
| 3 | River-Vein Returning Method | Deep Reservoir | Stable | Compatible |
| 4 | Mountain Root Stillness Method | Narrow Channel | Stable | Focused |
| 5 | Moon-Mirror Quiet Method | Neutral | Profoundly Stable | Focused |
| 6 | Thousand Step Wind Method | Deep Reservoir | Harsh | Compatible |
| 7 | Iron Meridian Hammer Method | Strained Reservoir | Harsh | Focused |
| 8 | Clear Spring Pulse Method | Neutral | Corrective | Corrective |
| 9 | Ghost-Lamp Spirit Method | Deep Reservoir | Harsh | Compatible |
| 10 | Jade Talisman Counting Method | Neutral | Stable | Compatible |
| 11 | Beast-Breath Companion Method | Deep Reservoir | Stable | Compatible |
| 12 | Bitter Root Medicine Method | Narrow Channel | Corrective | Corrective |
| 13 | Thunder Drum Marrow Method | Great Reservoir | Severe | Focused |
| 14 | White Crane Cloud Method | Neutral | Stable | Compatible |
| 15 | Black Sand Burial Method | Deep Reservoir | Harsh | Compatible |
| 16 | Ink-Wash Perception Method | Neutral | Stable | Compatible |
| 17 | Verdant Root Renewal Method | Deep Reservoir | Stable | Compatible |
| 18 | Scarlet Vessel Blood Method | Strained Reservoir | Harsh | Focused |
| 19 | Seven-Star Formation Method | Neutral | Profoundly Stable | Focused |
| 20 | Golden Bell Marrow Method | Narrow Channel | Stable | Focused |
| 21 | Dark Well Sinking Method | Deep Reservoir | Harsh | Compatible |
| 22 | Storm-Lance Sky Method | Great Reservoir | Severe | Focused |
| 23 | Lotus Mercy Pulse Method | Neutral | Corrective | Corrective |
| 24 | Candle-Wax Severance Method | Strained Reservoir | Harsh | Focused |
| 25 | Glass Heart Reflection Method | Neutral | Profoundly Stable | Focused |
| 26 | White Bone Scripture Method | Narrow Channel | Harsh | Compatible |
| 27 | Monkey Mind Unbound Method | Deep Reservoir | Harsh | Compatible |
| 28 | Silent Needle Meridian Method | Neutral | Corrective | Corrective |
| 29 | Red Banner War Method | Great Reservoir | Harsh | Compatible |
| 30 | Nine Bitter Heartfire Method | Strained Reservoir | Failure-Gated | Transformative |
| 31 | Azure Scale Dragon-Wind Method | Deep Reservoir | Stable | Focused |
| 32 | Hollow Gourd Storage Method | Great Reservoir | Harsh | Compatible |
| 33 | Mirror-Beauty Face Method | Neutral | Profoundly Stable | Focused |
| 34 | Ruin-Seal Destruction Method | Strained Reservoir | Severe | Focused |
| 35 | Twin Moon Blades Method | Deep Reservoir | Stable | Compatible |
| 36 | Seven-String Heartsong Method | Neutral | Profoundly Stable | Focused |
| 37 | Iron Ledger Retribution Method | Narrow Channel | Harsh | Focused |
| 38 | Hundred Weapons Index Method | Deep Reservoir | Stable | Compatible |
| 39 | Clear Thread Qiweaving Method | Neutral | Stable | Compatible |
| 40 | North Star Mandate Method | Narrow Channel | Severe | Focused |
| 41 | Fallen Coin Fate Method | Strained Reservoir | Failure-Gated | Transformative |
| 42 | Empty Bowl Void Method | Great Reservoir | Harsh | Focused |
| 43 | Sun-Marrow Yang Method | Strained Reservoir | Harsh | Focused |
| 44 | Hidden Snow Yin Method | Narrow Channel | Harsh | Focused |
| 45 | White Tiger Metal-Bone Method | Great Reservoir | Harsh | Focused |
| 46 | Daemonic Marrow Gate Method | Overdrawn Reservoir | Severe | Transformative |
| 47 | Laughing Mask Jester Method | Neutral | Failure-Gated | Transformative |
| 48 | Ten Thousand Names Sect Method | Neutral | Stable | Compatible |
| 49 | Plague-Seed Disease Method | Strained Reservoir | Harsh | Focused |
| 50 | Hundred Blossom Renewal Method | Deep Reservoir | Stable | Compatible |
| 51 | Falling Mountain Gravity Method | Great Reservoir | Severe | Focused |
| 52 | Lion Gate Guardian Method | Narrow Channel | Stable | Focused |
| 53 | Jade-Current Imbuement Method | Deep Reservoir | Stable | Compatible |
| 54 | Molten Core Magma Method | Strained Reservoir | Severe | Focused |
| 55 | Red Thread Puppet Method | Neutral | Profoundly Stable | Focused |
| 56 | Dawn-Crown Radiance Method | Great Reservoir | Harsh | Focused |
| 57 | Knife-Smile Scoundrel Method | Neutral | Failure-Gated | Transformative |
| 58 | Iron Clinch Wrestling Method | Narrow Channel | Stable | Focused |
| 59 | Turtle-Shell Shield Method | Narrow Channel | Stable | Focused |
| 60 | Incense Veil Smoke Method | Neutral | Harsh | Compatible |
| 61 | Long Eye Sniper Method | Narrow Channel | Harsh | Focused |
| 62 | Folded Door Space Method | Great Reservoir | Severe | Focused |
| 63 | Silk Knot Thread Method | Deep Reservoir | Stable | Compatible |
| 64 | Hidden Snare Trap Method | Neutral | Stable | Compatible |
| 65 | Thousand Dart Barrage Method | Deep Reservoir | Stable | Compatible |
| 66 | Stone Ox Brute Method | Great Reservoir | Harsh | Focused |
| 67 | Iron Chain Binding Method | Narrow Channel | Stable | Compatible |
| 68 | Last Breath Death Method | Neutral | Profoundly Stable | Focused |
| 69 | Wine-Sway Drunken Method | Deep Reservoir | Harsh | Compatible |
| 70 | Invisible Palm Force Method | Strained Reservoir | Harsh | Focused |
| 71 | Hidden Eye Lantern Method | Neutral | Stable | Compatible |
| 72 | Frozen Lake Ice Method | Narrow Channel | Stable | Focused |
| 73 | Meridian Bell Pressure Method | Neutral | Corrective | Corrective |
| 74 | Shrine Nest Companion Method | Deep Reservoir | Stable | Compatible |
| 75 | Silver Needle Killing Method | Narrow Channel | Harsh | Focused |
| 76 | Deep Tide Returning Method | Deep Reservoir | Stable | Compatible |
| 77 | Brass Cauldron Refinement Method | Neutral | Profoundly Stable | Focused |
| 78 | Black Anvil Tempering Method | Great Reservoir | Harsh | Focused |
| 79 | Cloud Herd Weather Method | Strained Reservoir | Harsh | Compatible |
| 80 | Red Furnace Berserker Method | Overdrawn Reservoir | Severe | Transformative |

# Methods Chunk 1: Methods 1–16

## 1. Outer Gate Root Method

**Type:** Sect Foundation / Basic Circulation  
**Common Users:** outer disciples, new initiates, trial survivors, junior attendants  
**Compatible Themes:** sect discipline, basic breathing, safe circulation, posture, scripture literacy, supervised training  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Baseline — no modifier  
**Foundation Shape:** Open — no specific Foundation theme  

The Outer Gate Root Method is the basic cultivation practice taught to new disciples. It teaches safe breathing, posture, circulation awareness, scripture recitation, and the discipline needed to practice without damaging the body, qi, or spirit.

**Use As:** the default sect-level Method for new characters until the campaign grants a more specific Method.

## 2. Ash-Breath Furnace Method

**Type:** Furnace / Breath  
**Common Users:** furnace workers, blacksmith disciples, fire-aspected outer disciples, body temperers  
**Compatible Themes:** Fire, Ash, Blacksmithing, Metal, Earth, body tempering, furnace Foundations  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible fire, ash, forge, furnace, or body-tempering breakthrough checks; –PB to incompatible water, ice, dream, or spirit, dream, or stillness breakthrough checks  
**Foundation Shape:** Focused — Fire, Ash, Metal, Earth, Furnace, Body Tempering  

The Ash-Breath Furnace Method teaches a cultivator to breathe through heat, smoke, pressure, and exhaustion. The body is treated as a furnace: breath vents pressure, pain becomes slag, and unstable heat is refined rather than suppressed.

**Use As:** a focused Method for furnace-style Foundation repair, blacksmith lineage advancement, ash-meridian correction, and fire-aspected body tempering.

## 3. River-Vein Returning Method

**Type:** Circulation / River / Recovery  
**Common Users:** river sect disciples, healers, boat clans, water-route cultivators, wounded apprentices  
**Compatible Themes:** Water, River, Flowing River, Healing, recovery, damaged meridians, gentle Foundation repair  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible water, healing, recovery, or flow-based breakthrough checks  
**Foundation Shape:** Compatible — River, Water, Healing, Qi, Meridians  

The River-Vein Returning Method teaches circulation as a returning current. Power flows out, gathers sediment, and returns clearer than before. It favors patience, repeated correction, and steady recovery over explosive advancement.

**Use As:** a safe Method for wounded cultivators, river sects, healing lines, and Foundations that emphasize circulation repair.

## 4. Mountain Root Stillness Method

**Type:** Stillness / Earth / Body Discipline  
**Common Users:** mountain sect initiates, guards, hermits, resilience cultivators, earth-aspected disciples  
**Compatible Themes:** Earth, Mountain, Stone, stillness, defense, rooted body, pressure bearing  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible earth, mountain, resilience, stillness, or defensive breakthroughs  
**Foundation Shape:** Focused — Earth, Mountain, Body, Stillness, Defense  

The Mountain Root Stillness Method teaches the cultivator to become difficult to move in body, mind, and route. It builds slowly, favors stable Foundations, and resists reckless circulation.

**Use As:** a Method for defensive Body Refiners, earth cultivators, guarded sects, and slow but stable advancement routes.

## 5. Moon-Mirror Quiet Method

**Type:** Stillness / Yin / Reflection  
**Common Users:** moon shrine disciples, dream-touched cultivators, quiet-room students, illusion or perception lines  
**Compatible Themes:** Yin, Moon, Dreams, Illusion, Stillness, perception, reflection, hidden spirit pressure  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible yin, dream, illusion, reflection, or stillness breakthroughs  
**Foundation Shape:** Focused — Yin, Dream, Spirit, Stillness, Reflection  

The Moon-Mirror Quiet Method teaches the cultivator to become a still surface. Breath, thought, and spirit pressure are quieted until the inner image becomes clear enough to study.

**Use As:** a Method for dream sects, illusion lines, moonlit Foundations, and failures caused by emotional turbulence or scattered perception.

## 6. Thousand Step Wind Method

**Type:** Movement / Wind / Lightness  
**Common Users:** scouts, couriers, wandering disciples, cloud-step lineages, border sect runners  
**Compatible Themes:** Air, Wind, movement, scouting, mobility, light body, travel, evasion  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible wind, air, movement, or light-body breakthroughs; –PB to incompatible rooted, heavy, or sealed-route breakthroughs  
**Foundation Shape:** Compatible — Wind, Air, Movement, Body, Travel  

The Thousand Step Wind Method teaches the cultivator to let breath and step move together. The body becomes a route for motion rather than a weight to be dragged forward.

**Use As:** a common Method for scouts, cloud-step disciples, wandering cultivators, and wind-body Foundation routes.

## 7. Iron Meridian Hammer Method

**Type:** Body Tempering / Metal / Impact  
**Common Users:** weapon halls, miners, armor disciples, metal sects, body temperers  
**Compatible Themes:** Metal, Iron, body tempering, impact, pain training, armor, weapon discipline  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible metal, impact, armor, weapon, or body-tempering breakthroughs; –PB to spirit, dream, or water breakthroughs  
**Foundation Shape:** Focused — Metal, Body, Armor, Weapon, Resilience  

The Iron Meridian Hammer Method treats the meridians as metal to be forged by impact. It is direct, painful, and useful for cultivators who expect their bodies to survive pressure before their techniques mature.

**Use As:** a Method for hard-body cultivators, weapon sect disciples, armor specialists, and metal-aspected Foundation development.

## 8. Clear Spring Pulse Method

**Type:** Corrective / Water / Healing  
**Common Users:** healers, wounded disciples, gentle sect physicians, river shrine attendants  
**Compatible Themes:** Healing, Water, River, recovery, hidden injuries, meridian correction, clean circulation  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Corrective — +PB to breakthrough checks made to repair deviation, hidden injury, unstable Foundation, or wrong-route circulation issues  
**Foundation Shape:** Corrective — Healing, Water, Meridians, Recovery, Foundation Repair  

The Clear Spring Pulse Method teaches the cultivator to find impurities by listening to the pulse of circulation. It is less a power route than a way to prevent small mistakes from becoming permanent injuries.

**Use As:** a corrective Method for injured characters, healers, recovery arcs, and unstable Foundation repair.

## 9. Ghost-Lamp Spirit Method

**Type:** Spirit / Shadow / Lantern  
**Common Users:** shrine mediums, ghost-path disciples, night watchers, spirit investigators  
**Compatible Themes:** Spirit, Shadow, Ghosts, Dreams, souls, grave rites, spirit contact, night cultivation  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible spirit, shadow, ghost, dream, or night breakthroughs; –PB to incompatible radiance, furnace, or heavy body-tempering breakthroughs  
**Foundation Shape:** Compatible — Spirit, Shadow, Dream, Soul, Grave, Night  

The Ghost-Lamp Spirit Method teaches the cultivator to keep a small inner flame steady while walking near death, memory, and spirit pressure. It favors careful perception and controlled contact with unseen things.

**Use As:** a Method for spirit mediums, ghost investigators, shadow sects, and haunted Foundation routes.

## 10. Jade Talisman Counting Method

**Type:** Formula / Talisman / Calculation  
**Common Users:** talisman apprentices, formation students, clerks, ritual accountants, scholarly sects  
**Compatible Themes:** Talismans, Formations, counting, geometry, ritual timing, written qi, precision  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible talisman, formation, calculation, scripture, or ritual-precision breakthroughs  
**Foundation Shape:** Compatible — Talismans, Formations, Scripture, Precision, Qi  

The Jade Talisman Counting Method trains the cultivator to count breath, stroke, angle, and timing until power can be written without waste. It is disciplined, exacting, and slow to tolerate sloppy intuition.

**Use As:** a Method for talisman crafters, formation specialists, scholarly sects, and scripture-based Foundation routes.

## 11. Beast-Breath Companion Method

**Type:** Beast / Breath / Bonding  
**Common Users:** beast handlers, mountain hunters, spirit companion students, clan riders, wilderness sect disciples  
**Compatible Themes:** Beastmastery, Spirit Companions, mounts, hunting, animal breath, instinct, pact training  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible beast, companion, mount, instinct, or wilderness breakthroughs  
**Foundation Shape:** Compatible — Beast, Spirit Contact, Body, Wilderness, Companion  

The Beast-Breath Companion Method teaches the cultivator to match breath with another living rhythm. It is used by riders, handlers, hunters, and disciples whose cultivation begins by learning not to disturb the creature beside them.

**Use As:** a Method for beast sects, rider clans, companion users, and Foundations involving animal instinct or spirit bonds.

## 12. Bitter Root Medicine Method

**Type:** Medicine / Poison / Corrective  
**Common Users:** herb-gatherers, poison physicians, wandering healers, bitter-root clans, plague survivors  
**Compatible Themes:** Healing, Poison, Disease, herbs, bitterness, recovery, toxin correction, survival  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Corrective — +PB to breakthrough checks made to repair poison, disease, toxin, or medicinal-route injury  
**Foundation Shape:** Corrective — Healing, Poison, Disease, Body, Recovery  

The Bitter Root Medicine Method teaches that medicine and poison are separated by measure, timing, and constitution. The cultivator studies bitterness until the body learns what to reject and what to refine.

**Use As:** a Method for healers, poison users, plague survivors, herb sects, and toxin-related Foundation correction.

## 13. Thunder Drum Marrow Method

**Type:** Thunder / Marrow / Body Tempering  
**Common Users:** war drummers, storm disciples, body temperers, battlefield sects, harsh training halls  
**Compatible Themes:** Thunder, Storm, Marrow, body tempering, rhythm, pressure, battlefield advancement  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Severe — +2 × PB to compatible thunder, storm, marrow, rhythm, or battlefield breakthroughs; –2 × PB to incompatible stillness, dream, spirit or stillness breakthroughs  
**Foundation Shape:** Focused — Thunder, Storm, Body, Marrow, Battlefield  

The Thunder Drum Marrow Method pounds breath and pulse into one rhythm. It is loud, forceful, and difficult to hide, but it can drive a compatible body route forward with frightening momentum.

**Use As:** a major battlefield Method for storm-body Foundations, thunder sects, war cultivators, and high-risk body-tempering lines.

## 14. White Crane Cloud Method

**Type:** Light Body / Wind / Poise  
**Common Users:** monastery disciples, crane-style martial artists, couriers, cliff sect students  
**Compatible Themes:** Air, Wind, crane style, balance, poise, movement, light body, falling safety  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible wind, air, poise, balance, or light-body breakthroughs  
**Foundation Shape:** Compatible — Wind, Air, Body, Movement, Poise  

The White Crane Cloud Method teaches lift without panic. The cultivator practices balance, breath, and soft step until movement becomes controlled rather than merely fast.

**Use As:** a Method for monastery movement lines, crane-style martial artists, wind Foundations, and light-body training.

## 15. Black Sand Burial Method

**Type:** Earth / Sand / Concealment  
**Common Users:** desert sects, tomb guardians, scouts, assassins, grave-route cultivators  
**Compatible Themes:** Sand, Earth, Shadow, burial, concealment, resilience, tombs, pressure  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible sand, earth, shadow, burial, or resilience breakthroughs; –PB to incompatible river, open sky, or radiance breakthroughs  
**Foundation Shape:** Compatible — Sand, Earth, Shadow, Tomb, Resilience  

The Black Sand Burial Method teaches the cultivator to hide breath like a body beneath dunes. It favors patience, concealment, dry resilience, and power that waits under pressure.

**Use As:** a Method for desert cultivators, tomb sects, ambush lineages, and sand-shadow Foundation routes.

## 16. Ink-Wash Perception Method

**Type:** Ink / Perception / Spirit Discipline  
**Common Users:** painters, calligraphers, illusion students, scholar artists, dream interpreters  
**Compatible Themes:** Ink, Illusion, Dreams, Spirit, perception, calligraphy, memory, image cultivation  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible ink, illusion, dream, perception, memory, or image-based breakthroughs  
**Foundation Shape:** Compatible — Spirit, Ink, Illusion, Dream, Perception  

The Ink-Wash Perception Method teaches the cultivator to observe before acting. Breath follows the brush, spirit follows the image, and the inner world is studied through what the hand cannot help but reveal.

**Use As:** a Method for illusionists, ink cultivators, scholar artists, dream interpreters, and perception-based Foundation development.

# Methods Chunk 2: Methods 17–32

## 17. Verdant Root Renewal Method

**Type:** Wood / Growth / Recovery  
**Common Users:** herb sect disciples, forest hermits, healers, village shrine students, plant-aspected cultivators  
**Compatible Themes:** Verdant Growth, Healing, Harvesting and Gathering, Wood, roots, renewal, patient cultivation  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible wood, healing, growth, root, or recovery breakthroughs  
**Foundation Shape:** Compatible — Wood, Healing, Body, Qi, Root, Renewal  

The Verdant Root Renewal Method teaches the cultivator to grow like a root system: slow, interwoven, and difficult to destroy completely. It favors recovery, patience, and repeated return after injury.

**Use As:** a Method for healers, plant cultivators, recovery Foundations, forest sects, and characters rebuilding after injury..

## 18. Scarlet Vessel Blood Method

**Type:** Blood / Vessel / Body Pressure  
**Common Users:** bloodline heirs, battlefield surgeons, demonic-core hunters, scarred body temperers  
**Compatible Themes:** Blood, vitality, wounds, body pressure, lineage inheritance, dangerous recovery  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible blood, wound, vessel, vitality, or body-pressure breakthroughs; –PB to incompatible stillness, spirit, dream, or stillness breakthroughs  
**Foundation Shape:** Focused — Blood, Body, Vitality, Scars, Lineage  

The Scarlet Vessel Blood Method teaches that blood is not merely life but a route. Breath, pulse, and pain are trained together until the body learns to carry pressure through the vessels rather than breaking under it.

**Use As:** a Method for bloodline cultivators, scarred body routes, battlefield recovery arcs, and risky vitality Foundations..

## 19. Seven-Star Formation Method

**Type:** Formation / Calculation / Star Pattern  
**Common Users:** formation students, astrologer clerks, array apprentices, ritual planners, sect engineers  
**Compatible Themes:** Formations, Stars, Geometry, Talismans, calculation, ritual timing, spatial order  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible formation, star, geometry, ritual-order, or calculation breakthroughs  
**Foundation Shape:** Focused — Formations, Stars, Scripture, Precision, Qi  

The Seven-Star Formation Method trains breath and thought through repeated spatial patterning. The cultivator learns to treat the inner world as an array that must be aligned before power is moved.

**Use As:** a Method for formation specialists, star-pattern sects, ritual engineers, and ordered Foundation routes..

## 20. Golden Bell Marrow Method

**Type:** Body / Bell / Protection  
**Common Users:** monastery guardians, shield disciples, body refiners, temple protectors, heavy-stance martial artists  
**Compatible Themes:** Protection, Body, Metal, Sound, Bell, guarding, marrow tempering, defensive discipline  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible protection, body, bell, metal, guarding, or marrow breakthroughs  
**Foundation Shape:** Focused — Body, Protection, Metal, Sound, Stillness  

The Golden Bell Marrow Method teaches the cultivator to settle breath into the bones until impact rings through the body rather than scattering it. It advances slowly but favors stable defensive Foundations.

**Use As:** a Method for protectors, monastery body routes, shield-bearing cultivators, and defensive Foundation development..

## 21. Dark Well Sinking Method

**Type:** Dark / Stillness / Depth  
**Common Users:** cave sect disciples, night hermits, shadow students, cursed bloodline survivors, underground clans  
**Compatible Themes:** Dark, Shadow, caves, silence, depth, hidden routes, pressure below the surface  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible dark, shadow, depth, cave, or hidden route breakthroughs; –PB to incompatible radiance, open sky, or thunder breakthroughs  
**Foundation Shape:** Compatible — Dark, Shadow, Depth, Spirit, Concealment  

The Dark Well Sinking Method teaches the cultivator to let breath descend until thought becomes quiet and power settles below ordinary perception. It favors depth, secrecy, and patient accumulation.

**Use As:** a Method for shadow sects, hidden cave inheritances, cursed bloodline control, and dark-route Foundations..

## 22. Storm-Lance Sky Method

**Type:** Storm / Spear / Open Sky  
**Common Users:** steppe riders, spear halls, storm disciples, sky-banner clans, mounted cultivators  
**Compatible Themes:** Storm, Lightning, Spear, Horse-Soul, riding, open sky, warband pressure  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Severe — +2 × PB to compatible storm, lightning, spear, rider, or open sky breakthroughs; –2 × PB to incompatible cave, water, stillness, or scripture breakthroughs  
**Foundation Shape:** Focused — Storm, Lightning, Spear, Rider, Open Sky  

The Storm-Lance Sky Method teaches breath through charge, wind, and thunder. It is a route for cultivators whose power matures under open sky and forward pressure rather than enclosed meditation.

**Use As:** a major Method for rider clans, spear cultivators, storm Foundations, and warband inheritance routes..

## 23. Lotus Mercy Pulse Method

**Type:** Healing / Mercy / Soft Pulse  
**Common Users:** temple healers, wandering physicians, lotus shrine disciples, gentle sect caretakers  
**Compatible Themes:** Healing, Life, Lotus, mercy, pulse reading, recovery, gentle correction  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Corrective — +PB to breakthrough checks made to repair healing-route deviation, unstable Foundation, hidden injury, or unstable life-force circulation  
**Foundation Shape:** Corrective — Healing, Life, Lotus, Spirit, Recovery  

The Lotus Mercy Pulse Method teaches the cultivator to listen before correcting. It favors gentleness, measured breath, and recovery routes that mend without forcing the damaged pattern to obey.

**Use As:** a corrective Method for healers, damaged life Foundations, post-deviation recovery, and mercy-oriented cultivation lines..

## 24. Candle-Wax Severance Method

**Type:** Wax / Flame / Severance  
**Common Users:** candle rite disciples, execution shrine students, wax artisans, destruction-aspected ritualists  
**Compatible Themes:** Wax, Fire, Destruction, severance, ritual melting, vow endings, controlled consumption  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible wax, flame, destruction, severance, or vow-ending breakthroughs; –PB to incompatible renewal, healing, or gentle-growth breakthroughs  
**Foundation Shape:** Focused — Wax, Fire, Destruction, Ritual, Severance  

The Candle-Wax Severance Method teaches that some routes must be melted, cut, and sealed before a new shape can hold. It is austere, ritualized, and often used by sects that treat endings as sacred.

**Use As:** a Method for wax cultivators, destruction routes, ritual severance, oath-ending arcs, and harsh Foundation transformation..

## 25. Glass Heart Reflection Method

**Type:** Glass / Heart / Clarity  
**Common Users:** mirror hall disciples, glass artisans, truth-seeking cultivators, perception lineages, court mystics  
**Compatible Themes:** Glass, Illusion, Perception, Heart, clarity, reflection, fragile insight  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible glass, reflection, perception, truth, or illusion-breakthrough checks  
**Foundation Shape:** Focused — Glass, Heart, Perception, Illusion, Spirit  

The Glass Heart Reflection Method trains the cultivator to see distortion without immediately correcting it. Breath is polished through reflection until the inner heart shows what is false, beautiful, or cracked.

**Use As:** a Method for glass Foundations, perception specialists, illusion counters, court mystics, and fragile clarity routes..

## 26. White Bone Scripture Method

**Type:** Bone / Death / Scripture  
**Common Users:** mortuary disciples, grave keepers, battlefield survivors, death-domain students, austere monks  
**Compatible Themes:** Death, Bone, Grave, scripture, mortality, corpse rites, karmic remains  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible death, bone, grave, scripture, or mortality breakthroughs; –PB to incompatible vitality, life, healing, or growth breakthroughs  
**Foundation Shape:** Compatible — Death, Bone, Spirit, Grave, Scripture  

The White Bone Scripture Method teaches the cultivator to study what remains after warmth leaves. It favors austerity, memory, grave courtesy, and routes that do not fear endings.

**Use As:** a Method for death specialists, mortuary sects, grave rites, battlefield survivors, and bone-aspected Foundations..

## 27. Monkey Mind Unbound Method

**Type:** Monkey / Motion / Improvisation  
**Common Users:** wandering martial artists, trickster disciples, forest sect students, polearm fighters, unruly apprentices  
**Compatible Themes:** Monkey Style, movement, improvisation, misdirection, climbing, laughter, sudden insight  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible monkey, movement, trickery, improvisation, or sudden-insight breakthroughs; –PB to incompatible rigid-scripture, sealed-stance, or formal-court breakthroughs  
**Foundation Shape:** Compatible — Movement, Monkey, Body, Trickery, Forest  

The Monkey Mind Unbound Method teaches the cultivator to stop gripping the route too tightly. Breath leaps, posture shifts, and insight arrives sideways rather than through solemn obedience.

**Use As:** a Method for monkey-style cultivators, trickster martial lines, movement Foundations, and unorthodox sect training..

## 28. Silent Needle Meridian Method

**Type:** Needle / Meridian / Precision  
**Common Users:** physicians, assassins, acupuncture students, poison healers, hidden-clinic disciples  
**Compatible Themes:** Meridians, Medicine, Poison, Precision, hidden injury, needle work, soft correction  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Corrective — +PB to breakthrough checks made to repair meridian injury, hidden injury, poison-route deviation, or precision-circulation failure  
**Foundation Shape:** Corrective — Meridians, Medicine, Poison, Precision, Healing  

The Silent Needle Meridian Method teaches that the smallest route may decide the whole body. It favors careful diagnosis, exact pressure, and corrections too precise for brute force.

**Use As:** a Method for physicians, poison healers, hidden injury recovery, and meridian-focused Foundation repair..

## 29. Red Banner War Method

**Type:** Warleader / Banner / Morale  
**Common Users:** battlefield commanders, sect captains, banner disciples, warband heirs, military cultivators  
**Compatible Themes:** Warleader, Banner Raid, morale, command, formation fighting, oath pressure, battlefield rhythm  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible war, banner, command, morale, or battlefield breakthroughs; –PB to incompatible solitude, hermit, dream, or healing breakthroughs  
**Foundation Shape:** Compatible — War, Banner, Command, Body, Spirit  

The Red Banner War Method teaches cultivation through command pressure and shared rhythm. Breath follows the banner, fear becomes order, and the route is strengthened by responsibility to the formation.

**Use As:** a Method for warleaders, military sects, steppe banners, battlefield Foundations, and command-oriented advancement..

## 30. Nine Bitter Heartfire Method

**Type:** Heartfire / Bitterness / Inner Trial  
**Common Users:** survivors, ascetics, rejected disciples, bitter-root lineages, trial-scarred cultivators  
**Compatible Themes:** Heartfire, bitterness, survival, pain memory, failed breakthroughs, inner trial, refusal  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Failure-Gated — can qualify for printed options requiring prior failure, scar, hidden injury, deviation, or unresolved lesson  
**Foundation Shape:** Transformative — Heartfire, Scars, Survival, Body, Spirit  

The Nine Bitter Heartfire Method teaches that some fires only appear after humiliation, loss, and refusal to collapse. It gives shape to cultivators whose routes were born from failure.

**Use As:** a Method for failure-gated power, bitter survival arcs, scar-based Foundations, and transformation after ruined breakthroughs..

## 31. Azure Scale Dragon-Wind Method

**Type:** Dragon-Wind / Breath / Weather Body  
**Common Users:** coastal sect disciples, storm hermits, dragon-blood claimants, wind-body cultivators, river-mouth clans  
**Compatible Themes:** Air, Water, Weather, Dragon-Wind, breath, storms, speed, body quality  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible air, water, weather, dragon-wind, breath, or body-quality breakthroughs  
**Foundation Shape:** Focused — Air, Water, Weather, Body, Dragon-Wind  

The Azure Scale Dragon-Wind Method teaches the cultivator to breathe as if the body were a weather front. Wind moves over water, pressure changes, and the body learns to carry motion without losing structure.

**Use As:** a Method for wind-body Foundations, weather cultivators, coastal sects, and dragon-wind inspired advancement..

## 32. Hollow Gourd Storage Method

**Type:** Gourd / Storage / Containment  
**Common Users:** wandering cultivators, alchemists, pack carriers, gourd sect disciples, resource-poor apprentices  
**Compatible Themes:** Storage, Gourd, Alchemy, containment, preservation, careful circulation, travel  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible storage, containment, alchemy, preservation, or careful-circulation breakthroughs; –PB to incompatible explosive, reckless, or overburning breakthroughs  
**Foundation Shape:** Compatible — Storage, Alchemy, Qi, Travel, Preservation  

The Hollow Gourd Storage Method teaches the cultivator to preserve what others waste. Breath is held without stagnation, qi is stored without arrogance, and the route values capacity over immediate display.

**Use As:** a Method for alchemists, storage-item users, wandering cultivators, preservation Foundations, and careful resource-heavy routes..

# Methods Chunk 3: Methods 33–48

## 33. Mirror-Beauty Face Method

**Type:** Beauty / Mirror / Presence  
**Common Users:** court disciples, flower house cultivators, spirit performers, social sect students, charm-line heirs  
**Compatible Themes:** Beauty, Illusion, Flowers, Spirit, Heart, social pressure, mirrored self, presence refinement  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible beauty, illusion, flower, presence, or heart-reflection breakthroughs  
**Foundation Shape:** Focused — Beauty, Illusion, Flowers, Spirit, Heart  

The Mirror-Beauty Face Method teaches the cultivator to refine expression, breath, posture, gaze, and self-image until presence itself becomes a polished surface. It favors controlled identity, social poise, and breakthroughs that depend on seeing how others see the self.

**Use As:** a Method for beauty cultivators, court mystics, flower lines, illusion-presentations, and spirit routes shaped by appearance or self-image..

## 34. Ruin-Seal Destruction Method

**Type:** Destruction / Seal / Ruin  
**Common Users:** siege disciples, forbidden demolition halls, ruin scholars, anti-barrier specialists, harsh military sects  
**Compatible Themes:** Destruction, Unmaking, Force, Fire, Earth, ruin, anti-barrier pressure, broken seals  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Severe — +2 × PB to compatible destruction, unmaking, ruin, siege, or anti-barrier breakthroughs; –2 × PB to incompatible healing, preservation, or gentle-growth breakthroughs  
**Foundation Shape:** Focused — Destruction, Unmaking, Force, Fire, Earth  

The Ruin-Seal Destruction Method trains the cultivator to study how structures fail. Walls, seals, bones, pride, and false stability are treated as patterns that can be found, stressed, and broken.

**Use As:** a major Method for destructive sects, siege cultivators, Unmaking adjacent routes, anti-barrier Foundations, and dangerous ruin inheritances..

## 35. Twin Moon Blades Method

**Type:** Dual Wielding / Moon / Paired Rhythm  
**Common Users:** paired-blade students, saber twins, wandering duelists, night patrol disciples, close quarters weapon halls  
**Compatible Themes:** Dual Wielding, Sabers, Sword, Weapons, Moon, paired rhythm, alternating pressure  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible dual wielding, saber, sword, paired-weapon, or moon-rhythm breakthroughs  
**Foundation Shape:** Compatible — Dual Wielding, Sabers, Sword, Weapons, Body  

The Twin Moon Blades Method teaches the cultivator to breathe in pairs: one hand opens, the other closes; one blade threatens, the other answers. It favors rhythm, timing, and weapons that become a single alternating route.

**Use As:** a Method for paired-weapon cultivators, saber twins, sword-and-dagger lines, and Foundations based on rhythm, reflection, or two-handed coordination..

## 36. Seven-String Heartsong Method

**Type:** Music / Heart / Resonance  
**Common Users:** musicians, sect chanters, qin students, ritual singers, spirit performers, grief-healers  
**Compatible Themes:** Music, Sound, Spirit, Heart, Dreams, memory, mantra, resonance, emotional cultivation  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible music, sound, spirit, dream, memory, or heart-resonance breakthroughs  
**Foundation Shape:** Focused — Music, Sound, Spirit, Dream, Heart  

The Seven-String Heartsong Method trains breath through tone and silence. The cultivator learns which emotions ring true, which memories answer, and which notes reveal a disturbed route.

**Use As:** a Method for music cultivators, spirit singers, ritual chanters, grief-dream Foundations, and sound-resonance advancement..

## 37. Iron Ledger Retribution Method

**Type:** Retribution / Ledger / Oath  
**Common Users:** judgment halls, oath keepers, magistrate disciples, revenge survivors, sect law enforcers  
**Compatible Themes:** Retribution, Karma, Fate, Law, oaths, debt, punishment, return, consequence  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible retribution, karma, oath, debt, punishment, or consequence breakthroughs; –PB to incompatible mercy, forgetfulness, or self-erasure breakthroughs  
**Foundation Shape:** Focused — Retribution, Karma, Fate, Spirit, Sect Stewardship  

The Iron Ledger Retribution Method teaches that every act leaves a weight. The cultivator records injury, debt, vow, and return until advancement becomes a question of whether consequence has been carried correctly.

**Use As:** a Method for retribution lines, oath-bound characters, karmic debt arcs, magistrate sects, and punishment-as-cultivation Foundations..

## 38. Hundred Weapons Index Method

**Type:** Weapons / Arsenal / Catalog  
**Common Users:** arsenal students, wandering weapon collectors, sect quartermasters, battlefield adapters, military academies  
**Compatible Themes:** Weapons, Imbuement, Blacksmith, Metal, Sword, Spear, Axes, Sabers, flexible arsenal use  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible weapons, arsenal, imbuement, blacksmith, metal, or adaptive-weapon breakthroughs  
**Foundation Shape:** Compatible — Weapons, Imbuement, Blacksmith, Metal, Body  

The Hundred Weapons Index Method teaches the cultivator to classify tools before loving any single one. Edge, haft, chain, bow, shield, and hidden implement each become entries in an inner catalog of use.

**Use As:** a Method for Weapons-sphere cultivators, arsenal sects, adaptable martial artists, item-heavy routes, and characters who change tools without changing identity..

## 39. Clear Thread Qiweaving Method

**Type:** Qiweaving / Thread / Technique Control  
**Common Users:** scripture students, technique editors, formation aides, talisman assistants, cautious qi cultivators  
**Compatible Themes:** Qiweaving, Thread, Talismans, Formations, Scripture, technique shaping, clean circulation  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible qiweaving, thread, talisman, formation, scripture, or technique-shaping breakthroughs  
**Foundation Shape:** Compatible — Qiweaving, Thread, Talismans, Formations, Qi  

The Clear Thread Qiweaving Method teaches the cultivator to handle qi like a line that must not knot. It favors clean transitions, precise shaping, and understanding how a technique is built before it is expanded.

**Use As:** a Method for Qiweaving users, technical sects, formation/talisman hybrids, and characters who specialize in controlled technique construction..

## 40. North Star Mandate Method

**Type:** Stars / Fate / Mandate  
**Common Users:** astrologer disciples, imperial omen readers, sky shrine students, restricted celestial lineages  
**Compatible Themes:** Stars, Fate, Karma, Radiance, mandate, omen reading, celestial order, reincarnation signs  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Severe — +2 × PB to compatible stars, fate, mandate, omen, or celestial-order breakthroughs; –2 × PB to incompatible void, self-erasure, or anti-destiny breakthroughs  
**Foundation Shape:** Focused — Stars, Fate, Karma, Radiance, Spirit  

The North Star Mandate Method teaches the cultivator to align breath with omen and hierarchy. It is restrictive, exacting, and often preserved by sects that believe advancement should answer a visible order in heaven.

**Use As:** a major Method for astrologers, mandate-bearing disciples, reincarnation signs, imperial omen routes, and restricted celestial Foundations..

## 41. Fallen Coin Fate Method

**Type:** Fate / Chance / Price  
**Common Users:** gamblers, omen-touched wanderers, failed heirs, diviners, debt-marked cultivators  
**Compatible Themes:** Fate, Karma, Jester, Retribution, chance, debt, omen, risk, reversal  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Failure-Gated — can qualify for printed options requiring prior bad luck, failed omen, karmic debt, lost wager, or reversal lesson  
**Foundation Shape:** Transformative — Fate, Karma, Jester, Spirit, Dreams  

The Fallen Coin Fate Method teaches that a thrown coin is not random once Heaven has noticed the hand. The cultivator studies loss, debt, chance, and reversal until misfortune becomes a route rather than an interruption.

**Use As:** a Method for fate-touched wanderers, gambler cultivators, karmic reversal arcs, and failure-gated destiny routes..

## 42. Empty Bowl Void Method

**Type:** Void / Hunger / Emptiness  
**Common Users:** ascetics, hollow-body hermits, forbidden scripture seekers, famine survivors, void-route apprentices  
**Compatible Themes:** Void, Hunger, Space, Stillness, emptiness, absence, fasting, self-erasure  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible void, hunger, emptiness, fasting, space, or absence breakthroughs; –PB to incompatible abundance, growth, beauty, or social-presence breakthroughs  
**Foundation Shape:** Focused — Void, Hunger, Space, Stillness, Spirit  

The Empty Bowl Void Method teaches the cultivator to cultivate what is missing. Breath is emptied, appetite is observed, and the self is treated as a vessel whose power begins with absence.

**Use As:** a Method for void cultivators, hunger-adjacent ascetics, fasting routes, hollow-body Foundations, and dangerous self-erasure scriptures..

## 43. Sun-Marrow Yang Method

**Type:** Yang / Marrow / Vital Heat  
**Common Users:** sun shrine disciples, body refiners, vitality heirs, furnace ascetics, martial healers  
**Compatible Themes:** Yang, Radiance, Fire, Life, Blood, marrow, vital heat, body-bound vitality  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible yang, radiance, fire, life, blood, or vital-heat breakthroughs; –PB to incompatible yin, death, cold-preservation, or void breakthroughs  
**Foundation Shape:** Focused — Yang, Radiance, Fire, Life, Body  

The Sun-Marrow Yang Method teaches the cultivator to refine warmth through blood, marrow, breath, and will. It favors open vitality, burning pressure, and body-bound life-fire that must be kept disciplined.

**Use As:** a Method for yang routes, sun-body Foundations, vitality cultivators, radiant body tempering, and furnace-life advancement..

## 44. Hidden Snow Yin Method

**Type:** Yin / Snow / Preservation  
**Common Users:** moon shrine disciples, cold-room students, preservation lineages, quiet assassins, hidden vitality cultivators  
**Compatible Themes:** Yin, Ice, Moon, Death, Shadow, preservation, cold marrow, hidden vitality, stillness  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible yin, ice, moon, preservation, hidden vitality, or stillness breakthroughs; –PB to incompatible yang, fire, thunder, or exuberant life breakthroughs  
**Foundation Shape:** Focused — Yin, Ice, Moon, Shadow, Spirit  

The Hidden Snow Yin Method teaches the cultivator to keep life quiet. Breath slows, heat retreats, and power is preserved in the cold places where enemies assume nothing remains.

**Use As:** a Method for yin routes, preservation Foundations, cold-marrow cultivators, hidden vitality, and moonlit stillness advancement..

## 45. White Tiger Metal-Bone Method

**Type:** Metal / Bone / Killing Edge  
**Common Users:** metal sect disciples, weapon-body cultivators, execution guards, armor halls, White Tiger lineages  
**Compatible Themes:** Metal, Weapons, Axes, Sabers, Sword, Protection, bone tempering, killing edge, armament qi  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible metal, weapon, edge, armor, bone, or White Tiger breakthroughs; –PB to incompatible soft-water, dream, flower, or gentle-healing breakthroughs  
**Foundation Shape:** Focused — Metal, Weapons, Body, Protection, Axes  

The White Tiger Metal-Bone Method teaches the cultivator to refine bone, breath, and weapon intent as one hard route. It favors sharp structure, ringing pressure, armor discipline, and the killing edge held under control.

**Use As:** a Method for updated Metal Qi routes, weapon-body cultivators, armor halls, execution lines, and White Tiger-themed Foundations..

## 46. Daemonic Marrow Gate Method

**Type:** Daemonic / Marrow / Forbidden Gate  
**Common Users:** demonic-core cultivators, mutation survivors, forbidden body students, monster-blood heirs, sect exiles  
**Compatible Themes:** Daemonic Cultivation, Blood, Hunger, Beastmastery, Body, mutation, forbidden marrow, corruption pressure  
**Resource Shape:** Overdrawn Reservoir — increase max Path resource by 3 × PB; take –2 × PB on incompatible breakthrough checks or correction checks tied to the Method  
**Breakthrough Shape:** Severe — +2 × PB to compatible daemonic, mutation, marrow, hunger, blood, or forbidden body breakthroughs; –2 × PB to orthodox healing, purification, or clean-spirit breakthroughs  
**Foundation Shape:** Transformative — Daemonic Cultivation, Blood, Hunger, Beastmastery, Body  

The Daemonic Marrow Gate Method forces the cultivator to treat monstrous pressure as a route rather than an accident. It is powerful, ugly, and difficult to hide from anyone who knows what clean cultivation should feel like.

**Use As:** a forbidden Method for demonic-core routes, mutation arcs, hunger-blood Foundations, exile inheritances, and high-risk transformation..

## 47. Laughing Mask Jester Method

**Type:** Jester / Mask / Reversal  
**Common Users:** trickster disciples, masked performers, rogue spirit students, court fools, rejected omen readers  
**Compatible Themes:** Jester, Illusion, Fate, Beauty, Music, social reversal, mask identity, emotional disruption  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Failure-Gated — can qualify for printed options requiring humiliation, social reversal, broken prophecy, failed performance, or exposed falsehood  
**Foundation Shape:** Transformative — Jester, Illusion, Fate, Spirit, Beauty  

The Laughing Mask Jester Method teaches that shame, absurdity, and reversal can open a route solemn discipline cannot see. The cultivator studies masks until the difference between failure and revelation becomes unstable.

**Use As:** a Method for Jester cultivators, social-spiritual disruption, masked identities, reversal arcs, and failure-born insight routes..

## 48. Ten Thousand Names Sect Method

**Type:** Sect Stewardship / Name / Institution  
**Common Users:** stewards, clerks, sect administrators, lineage registrars, oath keepers, resource managers  
**Compatible Themes:** Sect Stewardship, Karma, Fate, Talismans, Formations, oaths, names, records, institutional cultivation  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible sect stewardship, oath, record, name, institution, or lineage-management breakthroughs  
**Foundation Shape:** Compatible — Sect Stewardship, Karma, Fate, Talismans, Formations  

The Ten Thousand Names Sect Method teaches that a sect is also a body: names are bones, duties are meridians, and records are circulation. The cultivator advances by understanding how people, vows, resources, and authority move through an institution.

**Use As:** a Method for sect stewards, administrator cultivators, oath-ledgers, lineage records, and institutional Foundation routes..

# Methods Chunk 4: Methods 49–64

## 49. Plague-Seed Disease Method

**Type:** Disease / Seed / Corruption  
**Common Users:** plague physicians, exile clinics, corpse-field survivors, poison sect students, forbidden healers  
**Compatible Themes:** Disease, Poison, Medicine, Body, Spirit, contagion, corruption, survival, impurity study  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible disease, poison, medicine, corruption, survival, or impurity breakthroughs; –PB to incompatible purity, radiance, lotus, or life or purification breakthroughs  
**Foundation Shape:** Focused — Disease, Poison, Medicine, Body, Spirit  

The Plague-Seed Disease Method teaches the cultivator to study sickness as a route with roots, seeds, carriers, and seasons. It favors survival through contamination, careful exposure, and the grim discipline of knowing what must not be allowed to bloom.

**Use As:** a Method for disease cultivators, plague survivors, poison physicians, corpse-field sects, and dangerous impurity-correction arcs..

## 50. Hundred Blossom Renewal Method

**Type:** Flowers / Renewal / Soft Growth  
**Common Users:** flower shrine disciples, garden sect students, court healers, mourning houses, spring festival lineages  
**Compatible Themes:** Flowers, Beauty, Life, Verdant Growth, Healing, memory, seasonal renewal, gentle growth  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible flower, beauty, life, verdant, healing, or renewal breakthroughs  
**Foundation Shape:** Compatible — Flowers, Beauty, Life, Verdant Growth, Healing  

The Hundred Blossom Renewal Method teaches the cultivator to advance by seasons rather than force. Bud, bloom, fragrance, fall, and seed each become part of a route that understands beauty as a cycle of return.

**Use As:** a Method for flower cultivators, garden sects, beauty-life hybrids, renewal Foundations, and characters whose growth follows seasonal signs..

## 51. Falling Mountain Gravity Method

**Type:** Gravity / Weight / Descent  
**Common Users:** pressure-hall disciples, mountain sect enforcers, heavy-stance cultivators, prison wardens, stone-body students  
**Compatible Themes:** Gravity, Earth, Mountain, Force, pressure, weight, descent, burden, anchoring  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Severe — +2 × PB to compatible gravity, earth, mountain, burden, pressure, or anchoring breakthroughs; –2 × PB to incompatible wind, light-body, flight, or free-motion breakthroughs  
**Foundation Shape:** Focused — Gravity, Earth, Mountain, Force, Body  

The Falling Mountain Gravity Method teaches that weight is not weakness. Breath descends, posture settles, and the cultivator learns to carry burden until pressure becomes a teacher rather than a cage.

**Use As:** a major Method for gravity routes, mountain-pressure Foundations, prison sects, heavy-body cultivators, and burden-based advancement..

## 52. Lion Gate Guardian Method

**Type:** Guardian / Gate / Vow  
**Common Users:** gate guards, bodyguards, monastery protectors, oath disciples, escort sect students  
**Compatible Themes:** Guardian, Protection, Shield, Warleader, vows, gates, escort duty, standing between danger and others  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible guardian, protection, shield, vow, escort, or gate breakthroughs  
**Foundation Shape:** Focused — Guardian, Protection, Shield, Body, Vow  

The Lion Gate Guardian Method teaches the cultivator to define the self by what cannot be crossed. Breath is trained around duty, posture, and the promise to stand where retreat would be easier.

**Use As:** a Method for guards, oath protectors, escort cultivators, defensive Foundations, and sects that train disciples through watch-duty..

## 53. Jade-Current Imbuement Method

**Type:** Imbuement / Current / Vessel  
**Common Users:** artifact students, weapon-channel cultivators, talisman aides, ritual smiths, qi-flow instructors  
**Compatible Themes:** Imbuement, Weapons, Blacksmith, Talismans, Qiweaving, channels, vessels, stored current  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible imbuement, weapon-channel, talisman, blacksmith, qiweaving, or vessel breakthroughs  
**Foundation Shape:** Compatible — Imbuement, Weapons, Blacksmith, Talismans, Qi  

The Jade-Current Imbuement Method teaches the cultivator to move power into vessels without spilling identity. Weapon, charm, seal, robe, and tool become temporary channels that must be filled cleanly and released cleanly.

**Use As:** a Method for imbuement users, artifact-facing cultivators, weapon-channel routes, talisman hybrids, and item-centered Foundations..

## 54. Molten Core Magma Method

**Type:** Magma / Core / Earth-Fire  
**Common Users:** volcano sect disciples, furnace miners, earth-fire hermits, lava shrine students, pressure-tempered body refiners  
**Compatible Themes:** Magma, Fire, Earth, Metal, Furnace, pressure, molten core, volcanic transformation  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Severe — +2 × PB to compatible magma, fire, earth, furnace, pressure, or molten-core breakthroughs; –2 × PB to incompatible water, ice, stillness, or spirit breakthroughs  
**Foundation Shape:** Focused — Magma, Fire, Earth, Metal, Furnace  

The Molten Core Magma Method teaches the cultivator to endure transformation before releasing it. Heat is held under weight, earth is made fluid, and pressure is refined until the route can change without losing mass.

**Use As:** a major Method for magma cultivators, volcanic sects, furnace-earth Foundations, and high-pressure body or qi transformation..

## 55. Red Thread Puppet Method

**Type:** Puppetry / Thread / Sympathy  
**Common Users:** puppet hall apprentices, soul-doll students, theater sect disciples, sympathetic ritualists, hidden controllers  
**Compatible Themes:** Puppetry, Thread, Spirit, Talismans, control, sympathy, dolls, substitute bodies  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible puppetry, thread, doll, sympathy, soul-vessel, or control breakthroughs  
**Foundation Shape:** Focused — Puppetry, Thread, Spirit, Talismans, Vessel  

The Red Thread Puppet Method teaches the cultivator to understand distance through connection. A thread may be physical, spiritual, symbolic, or written, but the lesson is the same: what is linked can answer.

**Use As:** a Method for puppet cultivators, soul-doll routes, thread techniques, sympathetic rituals, and vessel-based Foundations..

## 56. Dawn-Crown Radiance Method

**Type:** Radiance / Dawn / Purification  
**Common Users:** sun shrine disciples, purification halls, exorcists, royal oath students, radiant sword or spear lines  
**Compatible Themes:** Radiance, Yang, Fire, Life, Protection, purification, dawn, revelation, courage  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible radiance, purification, dawn, courage, protection, or yang breakthroughs; –PB to incompatible shadow, disease, grave, or hidden path breakthroughs  
**Foundation Shape:** Focused — Radiance, Yang, Fire, Life, Protection  

The Dawn-Crown Radiance Method teaches the cultivator to refine power by making it visible. Breath rises like first light, impurity is exposed, and fear is burned by the discipline of standing in the open.

**Use As:** a Method for radiance cultivators, purification sects, exorcists, sun-route Foundations, and courage-based advancement..

## 57. Knife-Smile Scoundrel Method

**Type:** Scoundrel / Knife / Opportunity  
**Common Users:** street sect survivors, rogue disciples, caravan fighters, undercity students, trick-duel apprentices  
**Compatible Themes:** Scoundrel, Jester, Trap, Poison, close work, opportunity, misdirection, survival manners  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Failure-Gated — can qualify for printed options requiring betrayal, lost duel, public humiliation, dirty victory, or underworld debt  
**Foundation Shape:** Transformative — Scoundrel, Jester, Trap, Poison, Body  

The Knife-Smile Scoundrel Method teaches the cultivator to survive where honor is expensive. Breath is hidden behind jokes, posture behind courtesy, and advancement often begins with learning which rule was never real.

**Use As:** a Method for scoundrels, undercity cultivators, trick-fighters, survival arcs, and failure-born social or tactical routes..

## 58. Iron Clinch Wrestling Method

**Type:** Wrestling / Clinch / Body Control  
**Common Users:** grappling halls, arena students, body refiners, prison guards, monster hunters, rough sect enforcers  
**Compatible Themes:** Wrestling, Brute, Athletics, Body, pressure, holds, balance theft, close control  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible wrestling, brute, athletics, clinch, pressure, or body-control breakthroughs  
**Foundation Shape:** Focused — Wrestling, Brute, Athletics, Body, Pressure  

The Iron Clinch Wrestling Method teaches the cultivator to know another body through contact. Breath settles in grip, hip, shoulder, and root until movement can be read before it becomes escape.

**Use As:** a Method for grapplers, arena disciples, body-control Foundations, prison sects, and cultivators who refine power through holds and pressure..

## 59. Turtle-Shell Shield Method

**Type:** Shield / Shell / Guarded Stance  
**Common Users:** shield halls, turtle shrine disciples, caravan guards, fortress sect students, defensive body refiners  
**Compatible Themes:** Shield, Protection, Guardian, Water, Earth, shell, stance, covered advance, guard rhythm  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible shield, protection, guardian, shell, stance, or guarded breakthrough checks  
**Foundation Shape:** Focused — Shield, Protection, Guardian, Body, Earth  

The Turtle-Shell Shield Method teaches the cultivator to advance while protected. Breath stays low, steps stay covered, and the route values patience, angle, and preserved structure.

**Use As:** a Method for shield cultivators, defensive martial halls, fortress sects, turtle-shell Foundations, and guarded body advancement..

## 60. Incense Veil Smoke Method

**Type:** Smoke / Incense / Veil  
**Common Users:** incense shrine students, assassins, mourning houses, smoke dancers, dream-priests, wandering exorcists  
**Compatible Themes:** Smoke, Shadow, Dreams, Ash, Poison, incense, concealment, ritual breath, obscured identity  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Harsh — +PB to compatible smoke, incense, shadow, dream, ash, or obscured-identity breakthroughs; –PB to incompatible radiance, open-sky, or revelation breakthroughs  
**Foundation Shape:** Compatible — Smoke, Shadow, Dreams, Ash, Spirit  

The Incense Veil Smoke Method teaches the cultivator to let breath become atmosphere. The self is softened, identity diffuses, and meaning is carried through scent, haze, and ritual movement.

**Use As:** a Method for smoke cultivators, incense rites, assassins, dream-priests, ash-smoke hybrids, and obscured spirit Foundations..

## 61. Long Eye Sniper Method

**Type:** Sniper / Stillness / Killing Line  
**Common Users:** archer towers, cliff hunters, border scouts, assassination schools, patient battlefield observers  
**Compatible Themes:** Sniper, Barrage, Air, Space, stillness, aim, killing line, distance reading  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible sniper, aim, stillness, air, distance, or killing-line breakthroughs; –PB to incompatible frenzy, crowd-rhythm, or wild motion breakthroughs  
**Foundation Shape:** Focused — Sniper, Barrage, Air, Space, Stillness  

The Long Eye Sniper Method teaches the cultivator to spend breath before the shot exists. Sight, patience, route, and distance are aligned until a single line becomes more important than motion.

**Use As:** a Method for snipers, archer sects, patient scouts, assassination lineages, and distance-focused Foundations..

## 62. Folded Door Space Method

**Type:** Space / Threshold / Door  
**Common Users:** threshold sect students, storage heirs, gate scribes, courier cultivators, boundary shrine disciples  
**Compatible Themes:** Space, Void, Storage, Formations, thresholds, doors, distance law, boundary study  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Severe — +2 × PB to compatible space, threshold, storage, boundary, or distance-law breakthroughs; –2 × PB to incompatible rooted, oath-fixed, or rooted body breakthroughs  
**Foundation Shape:** Focused — Space, Void, Storage, Formations, Threshold  

The Folded Door Space Method teaches the cultivator to notice where distance has seams. Breath pauses at thresholds, thought folds around boundaries, and the inner route learns that near and far are conditions rather than truths.

**Use As:** a major Method for space cultivators, storage routes, gate inheritances, courier sects, and threshold-based Foundations..

## 63. Silk Knot Thread Method

**Type:** Thread / Knot / Binding  
**Common Users:** silk sect disciples, weavers, fate-line students, binding specialists, robe artisans, quiet controllers  
**Compatible Themes:** Thread, Fate, Puppetry, Talismans, binding, knots, connection, silk routes  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible thread, knot, binding, fate-line, talisman, or connection breakthroughs  
**Foundation Shape:** Compatible — Thread, Fate, Puppetry, Talismans, Spirit  

The Silk Knot Thread Method teaches the cultivator that connection is stronger when tied deliberately. Breath follows knot, loop, tension, and release until the route understands what should be bound and what must be let loose.

**Use As:** a Method for thread cultivators, silk sects, fate-line routes, puppet hybrids, binding Foundations, and talisman-thread work..

## 64. Hidden Snare Trap Method

**Type:** Trap / Snare / Preparation  
**Common Users:** hunters, border scouts, battlefield engineers, undercity survivors, sect wardens, monster trackers  
**Compatible Themes:** Trap, Hunting, Formations, Scoundrel, preparation, snares, terrain reading, delayed pressure  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible trap, hunting, preparation, formation, snare, or terrain-reading breakthroughs  
**Foundation Shape:** Compatible — Trap, Formations, Scoundrel, Hunting, Terrain  

The Hidden Snare Trap Method teaches the cultivator to prepare the battlefield before power is visible. Breath is placed into patience, route is placed into terrain, and victory is understood as something prepared early.

**Use As:** a Method for trap users, hunters, terrain tacticians, undercity survivors, monster trackers, and preparation-based Foundations..

# Methods Chunk 5: Methods 65–80

## 65. Thousand Dart Barrage Method

**Type:** Barrage / Volley / Breath Rhythm  
**Common Users:** skirmishers, dart throwers, archer aides, flying-weapon students, militia disciples  
**Compatible Themes:** Barrage, Weapons, Sniper, Air, Metal, volley rhythm, breath timing, projectile discipline  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible barrage, volley, projectile, breath-timing, or flying-weapon breakthroughs  
**Foundation Shape:** Compatible — Barrage, Weapons, Sniper, Air, Metal  

The Thousand Dart Barrage Method trains the cultivator to divide one breath into many releases. It favors rhythm, sequencing, and the ability to keep intent stable while pressure leaves the body in repeated lines.

**Use As:** a Method for projectile cultivators, flying-weapon students, skirmish lines, dart halls, and Foundations based on repeated release..

## 66. Stone Ox Brute Method

**Type:** Brute / Weight / Body Pressure  
**Common Users:** labor gangs, strongman disciples, gate guards, quarry sect students, raw-force body refiners  
**Compatible Themes:** Brute, Earth, Body, Guardian, Wrestling, weight, collision, raw strength, bodily pressure  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible brute, earth, body, collision, weight, or raw-strength breakthroughs; –PB to incompatible dream, illusion, spirit, perception, or precision breakthroughs  
**Foundation Shape:** Focused — Brute, Earth, Body, Guardian, Wrestling  

The Stone Ox Brute Method teaches the cultivator to become the thing that refuses to yield. Breath sinks into weight, posture becomes pressure, and strength is refined into a route rather than left as mere muscle.

**Use As:** a Method for Brute cultivators, quarry sects, strong-body Foundations, gate guardians, and direct pressure routes..

## 67. Iron Chain Binding Method

**Type:** Chains / Binding / Control  
**Common Users:** jail sect disciples, caravan guards, chain-weapon students, law enforcers, restraint specialists  
**Compatible Themes:** Chains, Weapons, Metal, Retribution, Trap, binding, restraint, capture, control routes  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible chains, binding, restraint, capture, metal, or control breakthroughs  
**Foundation Shape:** Compatible — Chains, Weapons, Metal, Retribution, Trap  

The Iron Chain Binding Method teaches the cultivator to value closure over impact. Breath follows loop, lock, pull, and return until the route learns how to hold without tearing itself apart.

**Use As:** a Method for chain-weapon cultivators, jail sects, capture specialists, restraint Foundations, and law-bound control routes..

## 68. Last Breath Death Method

**Type:** Death / Breath / Mortality  
**Common Users:** mortuary disciples, battlefield monks, ghost wardens, plague survivors, death-domain apprentices  
**Compatible Themes:** Death, Ghosts, Spirit, Bone, Grave, last breath, mortality, afterimage of life  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible death, grave, ghost, mortality, last-breath, or spirit-transition breakthroughs  
**Foundation Shape:** Focused — Death, Spirit, Grave, Bone, Ghosts  

The Last Breath Death Method teaches the cultivator to study the boundary where breath stops and meaning remains. It favors composure, rites, and advancement through honest contact with endings.

**Use As:** a Method for death cultivators, mortuary sects, ghost wardens, battlefield monks, and mortality-centered Foundations..

## 69. Wine-Sway Drunken Method

**Type:** Drunken Style / Imbalance / Loose Body  
**Common Users:** wandering martial artists, tavern disciples, rebel students, soft-body duelists, trickster fighters  
**Compatible Themes:** Drunken Style, Jester, Flowing River, Monkey Style, Body, imbalance, looseness, deceptive rhythm  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Harsh — +PB to compatible drunken style, imbalance, loose-body, trickery, or flowing-rhythm breakthroughs; –PB to incompatible stillness, scripture, or guarded-posture breakthroughs  
**Foundation Shape:** Compatible — Drunken Style, Jester, Flowing River, Monkey Style, Body  

The Wine-Sway Drunken Method teaches the cultivator to release the need for a straight line. Breath slips, weight lies, and the body becomes hardest to read when it seems least disciplined.

**Use As:** a Method for drunken-style cultivators, deceptive martial routes, loose-body Foundations, wandering rebels, and trickster duelists..

## 70. Invisible Palm Force Method

**Type:** Force / Palm / Pressure  
**Common Users:** palm hall disciples, pressure students, barrier breakers, invisible-impact lineages, battlefield controllers  
**Compatible Themes:** Force, Brute, Protection, Air, Space, pressure, impact, invisible palm, barrier contest  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible force, pressure, impact, palm, barrier, or invisible-control breakthroughs; –PB to incompatible gentle-healing, flower, or dream breakthroughs  
**Foundation Shape:** Focused — Force, Brute, Protection, Air, Space  

The Invisible Palm Force Method teaches the cultivator to refine contact before contact is seen. Breath gathers at the palm, pressure carries intent, and empty space becomes the messenger of impact.

**Use As:** a Method for force cultivators, palm lineages, pressure-control Foundations, barrier contests, and invisible-impact routes..

## 71. Hidden Eye Lantern Method

**Type:** Hidden Eye / Lantern / Secret Sight  
**Common Users:** investigators, secret watchers, shrine scouts, diviners, hidden-truth disciples  
**Compatible Themes:** The Hidden Eye, Radiance, Shadow, Fate, Spirit, secrets, revealed truth, hidden signs  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Stable — +PB to compatible hidden-eye, revelation, secret-sight, omen, shadow, or spirit-perception breakthroughs  
**Foundation Shape:** Compatible — The Hidden Eye, Radiance, Shadow, Fate, Spirit  

The Hidden Eye Lantern Method teaches the cultivator to carry a small inner light behind ordinary sight. It favors careful watching, secret signs, and the discipline to notice what power tries to conceal.

**Use As:** a Method for investigators, secret watchers, omen readers, hidden-truth Foundations, and perception-focused spirit routes..

## 72. Frozen Lake Ice Method

**Type:** Ice / Still Water / Preservation  
**Common Users:** cold-room disciples, northern sect students, preservation heirs, patient duelists, winter shrine attendants  
**Compatible Themes:** Ice, Water, Yin, Stillness, preservation, cold breath, frozen surface, patient defense  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Stable — +PB to compatible ice, water, yin, preservation, stillness, or cold-breath breakthroughs  
**Foundation Shape:** Focused — Ice, Water, Yin, Stillness, Spirit  

The Frozen Lake Ice Method teaches the cultivator to let motion disappear beneath a calm surface. Breath cools, impulse slows, and power is preserved until pressure can no longer crack the ice.

**Use As:** a Method for ice cultivators, preservation routes, cold-breath Foundations, winter shrines, and water-stillness advancement..

## 73. Meridian Bell Pressure Method

**Type:** Pressure Points / Bell / Meridian Contact  
**Common Users:** pressure-point students, physicians, martial healers, temple duelists, soft-control body refiners  
**Compatible Themes:** Pressure Points, Medicine, Sound, Body, Meridians, contact timing, bell resonance, precise disruption  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Corrective — +PB to breakthrough checks made to repair meridian injury, pressure-route deviation, contact-timing failure, or unstable body-control issues  
**Foundation Shape:** Corrective — Pressure Points, Medicine, Sound, Body, Meridians  

The Meridian Bell Pressure Method teaches that each point rings differently when touched at the correct time. The cultivator studies contact, pulse, breath, and resonance until disruption and correction share one grammar.

**Use As:** a Method for pressure-point cultivators, martial physicians, temple duelists, meridian repair, and precise body-control Foundations..

## 74. Shrine Nest Companion Method

**Type:** Spirit Companions / Shrine / Bonding  
**Common Users:** spirit host students, shrine families, beast-spirit attendants, ancestor-touched disciples, companion cultivators  
**Compatible Themes:** Spirit Companions, Beastmastery, Spirit, Karma, Protection, shrine bonds, offerings, shared rhythm  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible spirit companion, shrine, bond, ancestor, beast-spirit, or offering breakthroughs  
**Foundation Shape:** Compatible — Spirit Companions, Beastmastery, Spirit, Karma, Protection  

The Shrine Nest Companion Method teaches the cultivator to make room inside the route for another presence. Breath becomes hospitality, boundary, and promise rather than solitary circulation.

**Use As:** a Method for companion cultivators, hosted spirits, ancestor shrines, beast-spirit routes, and Foundations based on bonded presence..

## 75. Silver Needle Killing Method

**Type:** The Piercing Needle / Precision / Quiet Line  
**Common Users:** needle students, assassins, hidden physicians, weak-point duelists, sleeve-weapon cultivators  
**Compatible Themes:** The Piercing Needle, Pressure Points, Poison, Medicine, Shadow, precision, weak points, quiet line  
**Resource Shape:** Narrow Channel — decrease max Path resource by PB; gain +PB to compatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible needle, precision, weak-point, poison, medicine, or shadow breakthroughs; –PB to incompatible brute-force, broad-area, or loud-battlefield breakthroughs  
**Foundation Shape:** Focused — The Piercing Needle, Pressure Points, Poison, Medicine, Shadow  

The Silver Needle Killing Method teaches the cultivator that a small opening may matter more than a great blow. Breath thins into a single line, and the route is trained to find the place where defense is weakest.

**Use As:** a Method for needle specialists, hidden physicians, assassins, weak-point Foundations, and precision poison routes..

## 76. Deep Tide Returning Method

**Type:** Water / Tide / Return  
**Common Users:** river sect disciples, sailors, rain shrine students, grief cultivators, wave-step martial artists  
**Compatible Themes:** Water, Flowing River, Weather, Healing, Memory, tide, return, wave pressure, adaptation  
**Resource Shape:** Deep Reservoir — increase max Path resource by PB  
**Breakthrough Shape:** Stable — +PB to compatible water, river, tide, rain, healing, or adaptation breakthroughs  
**Foundation Shape:** Compatible — Water, Flowing River, Weather, Healing, Spirit  

The Deep Tide Returning Method teaches the cultivator that retreat and return are the same motion seen at different times. It favors adaptation, memory, patient pressure, and power that comes back stronger after withdrawal.

**Use As:** a Method for water cultivators, river sects, tide Foundations, sailors, grief-river spirit routes, and adaptive martial lines..

## 77. Brass Cauldron Refinement Method

**Type:** Alchemy / Cauldron / Refinement  
**Common Users:** alchemy apprentices, pill hall students, furnace clerks, field medics, medicinal sect disciples  
**Compatible Themes:** Alchemy, Fire, Medicine, Poison, Healing, cauldron pressure, pill refinement, furnace discipline  
**Resource Shape:** Neutral — no modifier  
**Breakthrough Shape:** Profoundly Stable — +2 × PB to compatible alchemy, cauldron, medicine, poison, pill, or refinement breakthroughs  
**Foundation Shape:** Focused — Alchemy, Fire, Medicine, Poison, Healing  

The Brass Cauldron Refinement Method teaches the cultivator to think like a furnace before touching one. Impurity, timing, heat, and residue are studied as principles that also exist inside the body and spirit.

**Use As:** a Method for alchemists, pill halls, medicinal sects, poison physicians, and refinement-centered Foundation development..

## 78. Black Anvil Tempering Method

**Type:** Blacksmith / Anvil / Forge Discipline  
**Common Users:** blacksmith disciples, forge hall students, armor makers, weapon refiners, metal-body apprentices  
**Compatible Themes:** Blacksmith, Metal, Fire, Earth, Weapons, armor, tempering, craft discipline, anvil rhythm  
**Resource Shape:** Great Reservoir — increase max Path resource by 2 × PB  
**Breakthrough Shape:** Harsh — +PB to compatible blacksmith, metal, forge, armor, weapon, or tempering breakthroughs; –PB to incompatible dream, flower, or spirit breakthroughs  
**Foundation Shape:** Focused — Blacksmith, Metal, Fire, Earth, Weapons  

The Black Anvil Tempering Method teaches that a cultivator and a blade both fail when heat, pressure, and timing are wrong. Breath follows hammer rhythm until refinement becomes bodily instinct.

**Use As:** a Method for blacksmith cultivators, forge sects, armor-body routes, weapon refiners, and metal-fire Foundation advancement..

## 79. Cloud Herd Weather Method

**Type:** Weather / Cloud / Seasonal Breath  
**Common Users:** rain callers, storm shrine disciples, farmers, sky-watchers, wandering weather students  
**Compatible Themes:** Weather, Water, Air, Lightning, Harvesting and Gathering, clouds, rain, seasonal rhythm, sky pressure  
**Resource Shape:** Strained Reservoir — increase max Path resource by 2 × PB; take –PB on incompatible breakthrough checks  
**Breakthrough Shape:** Harsh — +PB to compatible weather, cloud, rain, wind, lightning, or seasonal breakthroughs; –PB to incompatible cave, stillness, cave, or earth breakthroughs  
**Foundation Shape:** Compatible — Weather, Water, Air, Lightning, Harvesting and Gathering  

The Cloud Herd Weather Method teaches the cultivator to guide changing pressure rather than command it crudely. Breath follows cloud, rain, wind, and season until the route learns how change gathers before it falls.

**Use As:** a Method for weather cultivators, rain shrines, sky-watchers, agricultural sects, and cloud-storm Foundation routes..

## 80. Red Furnace Berserker Method

**Type:** Berserker / Furnace / Battle Heat  
**Common Users:** battle-mad disciples, furnace fighters, clan champions, body refiners, trial survivors  
**Compatible Themes:** Berserker, Fire, Blood, Body, Brute, battle heat, refusal, pressure under injury  
**Resource Shape:** Overdrawn Reservoir — increase max Path resource by 3 × PB; take –2 × PB on incompatible breakthrough checks or correction checks tied to the Method  
**Breakthrough Shape:** Severe — +2 × PB to compatible berserker, fire, blood, brute, battle-heat, or refusal breakthroughs; –2 × PB to stillness, preservation, quiet-spirit, or mercy breakthroughs  
**Foundation Shape:** Transformative — Berserker, Fire, Blood, Body, Brute  

The Red Furnace Berserker Method teaches the cultivator to survive the moment when restraint burns away. It is not merely rage; it is a furnace route that turns pain, danger, and refusal into forward pressure.

**Use As:** a high-risk Method for Berserker cultivators, battle furnaces, blood-fire Foundations, trial survivors, and violent transformation routes..
