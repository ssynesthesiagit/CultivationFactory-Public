# Tianxia Central Cultivation Insights — AI Operating Guide R4

The JSON file is machine-primary. Every canonical selectable Insight has passed the ability, prerequisite, execution-profile, cadence, authority, and placeholder gates.

## Mandatory use

1. Select only records listed in `canonical_record_ids`.
2. Enforce every printed prerequisite and `minimum_cl_level_selection`.
3. Apply the printed ability increase only when the Insight is selected through a level ASI/Insight choice.
4. Use `execution_profile` as an index, but resolve the Insight from `full_rules_text`.
5. Compatibility and recommendation tags never grant access.
6. Do not invent a custom lineage gift, weapon profile, project benefit, price, target, duration, or consequence. Use only printed options or another published Source Rule.

## Audit totals

- Canonical selectable Insights: **451**
- Ability options confirmed: **451**
- Execution profiles complete: **451**
- Pending central audit: **0**
- Open GM authority: **0**
- Rest-cadence flags: **0**
- Placeholder records: **0**
