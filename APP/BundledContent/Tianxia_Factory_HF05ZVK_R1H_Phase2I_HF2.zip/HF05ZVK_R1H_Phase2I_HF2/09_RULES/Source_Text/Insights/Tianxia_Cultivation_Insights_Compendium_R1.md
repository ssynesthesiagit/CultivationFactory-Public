# Tianxia: Cultivation Insights Compendium

## Complete Player Catalogue — R1

This volume contains the complete player-facing rules for all 451 canonical selectable Cultivation Insights. The Player’s Handbook contains the general rules, 72 campaign-common Insights, Path recommendations, and a complete index. This Compendium is the controlling player-facing location for every Insight not printed in full in the PHB.

Every Insight also has a canonical machine record in the Central Cultivation Insights AI Reference. Character builders, validators, and the GM Screen should use the canonical ID printed with each entry.

# 01. Using This Book

Cultivation Insights are one central character-option system shared across Paths, Spheres, Subpaths, inheritances, offices, pacts, scars, mutations, and cultivated realizations. A Path may provide Insight selection levels, but no Path owns a separate Insight subsystem.

## Level selection

At CL4, CL8, CL12, CL16, and CL19, when a Path progression offers an Ability Score Improvement or Cultivation Insight, choose one:

- take the normal Ability Score Improvement; or
- select one Cultivation Insight for which you meet every prerequisite.

A level-selected Insight grants its printed benefit and increases one ability score listed in **Ability Increase (Level Selection)** by 1, to the maximum permitted by the character's current Realm.

An Insight gained through a manual, tribulation, relic, shrine, spirit pact, sect instruction, bloodline awakening, reincarnated memory, office, experimentation, story reward, or another non-level source grants only its cultivation benefit unless that source expressly grants the ability increase.

## General limits

- Meet every printed prerequisite when the Insight is gained.
- Unless marked **Repeatable**, select an Insight once.
- A Path affinity, role tag, suggested Subpath, or AI recommendation is search metadata only and never grants access.
- If an Insight grants a new Sphere, gain the normal free talent granted whenever a character learns a new Sphere. The Insight does not waive Secret, Restricted, inherited, ethical, initiation, or narrative access.
- Use the effective Source CL identified by the Insight. If none is printed, use the Source CL of the Path, Sphere, Subpath, item, pact, or other Source Rule supplying the effect.
- A Path-resource or Cultivation Point cost cannot be reduced below 1 unless a rule expressly permits 0. Cost reductions do not stack on one activation unless expressly allowed.
- Copying, repeating, accelerating, or extending a technique does not waive consumed materials, sacrifices, Corruption, Impurity, item charges, maximum-resource costs, vows, Offerings, or other nonstandard prices.
- An Insight does not duplicate a weapon, Artifact, consumable, Companion, spirit, Formation Anchor, body Asset, or other cultivated Asset.
- One activation cannot deliver the same attack, poison, weapon rider, Insight rider, or Forged Technique rider multiple times unless the Source Rule expressly authorizes and prices each delivery.

## Body-linked rules

Body-linked Insights use Chapter 04 for Path features and the Body Refining player procedures and Subpath compendium for anatomy, Injury, reconstruction, transformation, natural weapons, integrated weapons, bodily Assets, mitigation, movement, restraint, external projection, Realm Suppression, Foundation interaction, and Subpath-specific states.

A Body-linked Insight does not create external projection unless it records an origin, range, legal target, action and cost, attack or save, duration, line of effect, medium, Source CL, and suppression procedure. Additional limbs or anatomy do not create extra actions or attacks unless printed. Regeneration and body-material production cannot be farmed for unlimited resources.

## Spirit-linked rules

Spirit-linked Insights use Chapter 06, the Spirit Awakening Rules Reference, the Bonded Companions rules, and the Spirit Companions Sphere where applicable.

## Central Insight execution definitions

These definitions apply whenever an Insight uses one of the following terms.

### Qualifying hostile source

A creature, hazard, Asset, Anchor, or effect is a **qualifying hostile source** when all of the following are true:

- it is not controlled by you or a willing ally;
- it was not created, invited, or damaged solely to trigger the Insight;
- it is acting against you, an ally, or a scene objective; and
- its Source CL is no more than 5 lower than yours, or it can inflict Hit Point loss, a condition, forced movement, resource loss, objective loss, or another printed consequence that matters in the current scene.

### Qualifying creature

A **qualifying creature** is an independent creature with a complete creature record that is not an illusory duplicate, disposable training construct, harmless summon, or closed-loop resource source. It qualifies if its Source CL is no more than 5 lower than yours or it is named, controls a scene objective, carries a relevant oath or relationship, or can impose a printed consequence on the scene.

### Qualifying event or meaningful scene

An event or scene qualifies when at least one of the following is true:

- a qualifying hostile source participates;
- failure can cause Hit Point loss, Cultivation Point loss, a condition, item or Asset loss, positional loss, mission failure, legal or sectarian consequence, or a change to an oath, debt, Bond, or custody record;
- the event creates, ends, or materially changes a project, relationship, Injury, transformation, or spiritual state; or
- a Source Rule expressly identifies it as qualifying.

Staged exchanges, willing damage loops, repeated harmless tests, and effects created solely to refund their own cost do not qualify.

### Recorded legal access

A choice that requires **recorded legal access** must identify the manual, teacher, lineage, office, license, relic, pact, sect permission, bloodline, or other Source Rule that grants access. A Path affinity, recommendation, or thematic similarity is not access.

### Project contribution

An Insight that contributes a principle, Mandate, presentation, technique, or tool to a project does not create the project by itself. The project record must state its objective, work time, materials, contributors, Source CL, maintenance, and vulnerability. Unless the Insight prints another benefit, one qualifying contribution grants one of the following once per project phase:

- Advantage on one project check made by a contributor;
- a reduction of 10 percent in the remaining ordinary labor time; or
- qualification as one required trained contributor or required conceptual component.

The same Insight cannot grant more than one of these benefits to the same project phase.

### Ordinary, higher-authority, and stronger effects

An **ordinary** effect is a non-Secret effect whose Source CL is no higher than yours. A **higher-authority** or **stronger** effect has a higher Source CL, is Secret or Artifact authority, or expressly overrides the relevant defense. These terms never permit the adjudicator to invent a new immunity or cost.

### Insight dormancy and restitution

When an Insight states that violating its discipline makes it dormant, its ability-score increase remains. Its cultivation benefit becomes inactive until the listed restitution is completed. Unless the Insight prints another restitution, the default is a Full Cultivation Session devoted to reflection plus one concrete corrective act toward a creature or community harmed by the violation.

### Insight cadence

- **Once per scene** resets when a new scene begins.
- **Once between Full Cultivation Sessions** resets only after completing a Full Cultivation Session.
- A **10-minute preparation or recovery procedure** requires uninterrupted work and cannot be completed during Initiative unless a rule expressly permits it.
- A prepared choice that lasts until the next Full Cultivation Session remains active through ordinary rests.

## Publication and access

- Appearing in this Compendium does not make a Rare, Forbidden, Secret, bloodline, lineage, organization, pact, or Sphere-locked Insight freely available.
- Meet every printed prerequisite and record any required legal access source.
- The PHB’s 72 Core Insights and this Compendium use the same canonical records. Where an Insight appears in both books, the wording is generated from the same source record.
- Canonical IDs are rules-maintenance identifiers and do not need to be spoken during play.

# 02. Catalogue

# 03. Qi Cultivation Insights

## Qi — General Qi Insights

### Expanded Dantian

**Canonical ID:** `insight.expanded-dantian`

**Prerequisite:** Qi Cultivation, CL4+  
**Repeatable:** Twice

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase your maximum Qi by:

`2 × your Proficiency Bonus`

Recalculate this increase whenever your Proficiency Bonus changes.

If selected twice, both increases apply.

### Meridian Economy

**Canonical ID:** `insight.meridian-economy`

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, after a Qi-powered feature resolves successfully and you actually paid at least 2 Qi for that activation, regain 1 Qi.

Meridian Economy:

- Resolves after the complete feature.
- Does not reduce the feature's cost.
- Does not trigger from refunded Qi.
- Does not trigger when the final amount actually paid was 0 or 1 Qi.
- Cannot trigger itself or create a closed refund loop.
- Functions alongside Golden Core Efficiency because it is recovery rather than a cost reduction.

### Thunderstep

**Canonical ID:** `insight.thunderstep`

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, immediately after you spend Qi on a feature that resolves successfully, move up to 10 feet without provoking Opportunity Attacks.

At CL12, this movement may:

- Travel vertically along a wall.
- Cross an unsupported gap.
- Move across a liquid surface.

You must end on a legal supporting surface unless another feature supports you.

If Circulating Golden Core also triggers, you may use both movements or combine them into one continuous movement.

### Fivefold Conversion

**Canonical ID:** `insight.fivefold-conversion`

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When activating a Qi-powered feature that deals Acid, Cold, Fire, Lightning, or Thunder damage, spend 1 additional Qi to change any amount of that damage to another type from the same list.

Declare the conversion before attack rolls or saving throws are resolved.

The conversion:

- Changes damage type.
- Does not automatically change the feature's Sphere, elemental, weather, or metaphysical tags.
- Does not add a rider belonging to the new damage type.
- Applies once across a Barrage, area, or multiattack activation.
- May convert technique damage delivered through a weapon, but does not convert ordinary weapon damage unless the delivery rule explicitly permits it.

At CL16, you may instead spend 2 additional Qi to convert the chosen damage to Force.

### Meridian Overchannel

**Canonical ID:** `insight.meridian-overchannel`

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature deals damage or restores Hit Points, spend additional Qi up to your Proficiency Bonus.

Add `1d8` to one damage or healing roll for each additional Qi spent.

For every Qi spent beyond the first 2, take `1d8` Force strain after the feature resolves.

Force strain from this Insight:

- Cannot be reduced.
- Cannot be prevented.
- Cannot be redirected.
- Cannot be converted into another damage type.
- Cannot generate Qi, charges, Temporary Hit Points, or retaliatory effects.

Meridian Overchannel adds dice to one roll, not once per target, projectile, attack, or healing recipient.

### Elemental Counterflow

**Canonical ID:** `insight.elemental-counterflow`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You take Acid, Cold, Fire, Lightning, or Thunder damage.  
**Cost:** 2 Qi

Gain Resistance to the triggering damage type against that damage packet.

After damage resolves, choose one:

- Move 10 feet without provoking Opportunity Attacks.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.
- Your next damaging Qi-powered feature before the end of your next turn may deal the triggering damage type.
- Move your Domain Armament up to 20 feet.

Elemental Counterflow cannot respond to damage you willingly dealt to yourself solely to trigger it.

### Qi Devourer

**Canonical ID:** `insight.qi-devourer`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When an essence-bearing creature within 60 feet is reduced to 0 Hit Points after you damaged it during the current scene, you may consume a portion of its escaping cultivated essence without using an action.

Regain Qi equal to the lower of:

- Your Proficiency Bonus.
- The creature's CL, minimum 1.

You may use Qi Devourer once per round.

A creature yields essence to you once until its life-force, spirit, or cultivation has been fully restored. Repeatedly reviving the same depleted creature does not refresh it unless the restoration effect explicitly rebuilds the consumed essence.

A construct, illusion, projected clone, summoned disposable body, or creature you created solely as a refund engine does not yield essence unless it possesses an independent genuine soul, life-force, or cultivation source.

Qi Devourer can be used on captives, condemned enemies, sacrificial victims, or willing donors when they genuinely possess consumable essence. Such use may be criminal, forbidden, praised, tolerated, or condemned according to the culture involved; it does not automatically gain the Daemonic tag.

### Heaven's Conduit

**Canonical ID:** `insight.heaven-s-conduit`

**Prerequisite:** Qi Cultivation, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Limit:** Once per scene

Regain 10 Qi and gain 1 level of Exhaustion.

The Exhaustion:

- Cannot be prevented.
- Cannot be transferred.
- Cannot be removed before the current scene ends.
- Can accumulate if you use Heaven's Conduit in later scenes before recovering.

If the regained Qi would exceed your maximum, the excess becomes unstable overflow that disappears at the end of the current turn.

### Meridian Fortress

**Canonical ID:** `insight.meridian-fortress`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws and Cultivation Checks against:

- Qi drain.
- Maximum-Qi reduction.
- Meridian sealing.
- Forced cost increases.
- Cultivation Point theft.
- Effects preventing Qi recovery.

Once per round, when a hostile effect would reduce your current Qi or maximum Qi, reduce that loss by your Proficiency Bonus.

If you possess Stable Golden Core, add this reduction to Stable Golden Core's reduction. This is an explicit stacking exception.

Meridian Fortress does not reduce Qi you willingly spend or sacrifice.

### Refined Meridian Regulation

**Canonical ID:** `insight.refined-meridian-regulation`

**Prerequisite:** Meridian Regulation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Meridian Regulation gains a range of 10 feet when used through direct Qi projection, a needle, a medical implement, or your Domain Armament.

You may also target:

- Charmed caused by a poison, drug, disease, bodily parasite, or meridian disturbance.
- Blinded or Deafened caused by smoke, ash, poison, pressure, or a directly impaired organ.
- One ordinary Bleeding effect.
- One temporary meridian blockage.

Against an effect whose Source CL is lower than yours, a successful repeated save also suppresses its ongoing damage until the end of the target's next turn.

This Insight does not allow Meridian Regulation to remove a Curse, Tribulation, Foundation Injury, Hidden Injury, permanent transformation, completed possession, Soul Damage, or conceptual severance unless another Source Rule expressly expands it.

### Restorative Circulation

**Canonical ID:** `insight.restorative-circulation`

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature restores Hit Points to one or more creatures, choose one recipient.

Increase the healing it receives by your Proficiency Bonus.

If the target is already at maximum Hit Points after the healing, it instead gains Temporary Hit Points equal to your Proficiency Bonus.

At CL12, when the chosen target is at 0 Hit Points, increase the healing by `2 × your Proficiency Bonus` instead.

Restorative Circulation applies once per activation, not once per healing die, target, pulse, or repeated tick.

### Qi-Tempered Concentration

**Canonical ID:** `insight.qi-tempered-concentration`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You fail a Constitution saving throw to maintain a Qi-powered feature.  
**Cost:** 2 Qi

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency and cannot modify the same saving throw more than once.

At CL15, this Insight improves Independent Concentration:

- Independent Concentration may protect any cultivation feature you maintain, not only a Qi feature.
- When Independent Concentration turns failure into success, choose one: move 5 feet without provoking Opportunity Attacks, move your Domain Armament 10 feet, or gain Temporary Hit Points equal to your Proficiency Bonus.

## Qi — Martial and Domain Armament Insights

### Cultivated Weapon Channel

**Canonical ID:** `insight.cultivated-weapon-channel`

**Prerequisite:** Qi Cultivation, proficiency with the chosen weapon group, CL4+  
**Repeatable:** Choose a different weapon group each time

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one weapon group with which you are proficient.

When you make a weapon attack specifically to deliver a Qi-powered cultivation technique through a weapon from that group, you may use your Qi Cultivation key ability instead of Strength or Dexterity for:

- The delivery attack roll.
- The weapon's damage modifier on that qualifying attack.

This Insight does not change ordinary attacks made without weapon delivery.

### Weapon-and-Technique Weave

**Canonical ID:** `insight.weapon-and-technique-weave`

**Prerequisite:** Qi Cultivation, proficiency with at least one weapon, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, gain one Weave benefit:

- After you hit with a weapon attack, gain +1 to the next Cultivation Attack you make before the end of your next turn.
- After a creature fails a saving throw against your Qi-powered technique, gain +1 to the next weapon attack you make before the end of your next turn.
- After you activate a Qi-powered technique through a weapon, move 5 feet without provoking Opportunity Attacks from the target struck or affected.

Only one Weave benefit may be active at a time. Gaining another replaces the previous benefit.

### Armored Meridian Circulation

**Canonical ID:** `insight.armored-meridian-circulation`

**Prerequisite:** Qi Cultivation, proficiency with medium armor, heavy armor, or shields, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

This Insight grants no armor or shield proficiency.

While wearing armor or using a shield with which you are proficient:

- Gain Advantage on saving throws against being knocked Prone.
- Reduce forced movement affecting you by 5 feet.
- Once per round, after you spend Qi on a feature that resolves successfully, reduce the next damage packet you take before the start of your next turn by your Proficiency Bonus.

High-quality armor, heavy armor, and shields do not interfere with your Qi techniques unless a specific item, curse, Method, or Source Rule says otherwise.

### Heavy Armament Conduction

**Canonical ID:** `insight.heavy-armament-conduction`

**Prerequisite:** Qi Cultivation, proficiency with a two-handed heavy weapon or another weapon classified as a heavy armament, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when you hit with a heavy weapon while delivering a Qi-powered cultivation technique, spend 1 additional Qi to apply Heavy Conduction.

Add the weapon's base damage dice one additional time to that hit.

Against an unattended object, vehicle, structure, temporary barrier, Formation Anchor, or Cultivation Asset, also choose one:

- Treat Damage Threshold as 0 for the hit.
- Ignore ordinary Resistance to the weapon's damage.
- Push or displace the target section 5 feet when physically possible.
- Deal an additional `2d8` Force damage.

Heavy Conduction applies only to the first qualifying attack unless another rule expressly extends it.

### Barrage Conduction

**Canonical ID:** `insight.barrage-conduction`

**Prerequisite:** Qi Cultivation, CL12+, and a Barrage Sphere talent, multiattack Recorded Art, or another authorized multiattack cultivation procedure

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a weapon-delivered cultivation technique would normally apply only to the first qualifying attack in an authorized Barrage, volley, or multiattack sequence, you may extend it.

Before making any attacks, pay:

`1 additional Qi for each additional attack that will carry the technique`

You may extend the technique to a maximum number of attacks equal to your Proficiency Bonus.

Unless the technique explicitly states otherwise:

- A once-per-activation rider still applies once.
- Qi Technique Potency still applies once.
- A missed attack does not deliver the technique.
- Each attack must satisfy the weapon and target requirements.
- Additional attacks cannot generate more additional attacks.

### Armament Commander

**Canonical ID:** `insight.armament-commander`

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Domain Armament improves:

- Control range increases by 30 feet.
- Movement increases by 15 feet.
- Calling or releasing a bound item may occur at any point during your turn without using an action, once per turn.

Once per turn when your Domain Armament hits, choose one:

- Push or pull the target 5 feet.
- The target cannot take Reactions until the start of its next turn.
- Move yourself 5 feet without provoking Opportunity Attacks.
- Move the Armament 10 feet.
- Reveal the target with visible Qi until the start of your next turn; Invisible does not conceal it from you.
- Gain Advantage on your next Cultivation Attack against that target before the end of your next turn.

### Elemental Armament

**Canonical ID:** `insight.elemental-armament`

**Prerequisite:** Domain Armament, one elemental Sphere or an elemental Qi Subpath, CL12+  
**Repeatable:** Choose a different element each time

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one damage type associated with an elemental Sphere you know.

Your projected Domain Armament may deal that damage type. A bound real item may apply the elemental damage to its Domain Armament Attack without changing its ordinary wielded damage.

Once per turn when the Armament hits with the chosen damage type, choose one:

- Deal additional damage equal to your Proficiency Bonus.
- Push or pull the target 5 feet.
- Reduce its Speed by 10 feet until the start of your next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Move the Armament 10 feet.

The rider must be thematically and mechanically compatible with the selected element as recorded when the Insight is gained.

### Guardian Armament

**Canonical ID:** `insight.guardian-armament`

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When your Domain Armament is in Guard Mode, its protected creature may remain within 10 feet of it rather than 5 feet.

**Reaction**  
**Trigger:** The protected creature is hit by an attack roll.  
**Cost:** 1 Qi

Reduce the triggering damage by:

`2d8 + your Qi Cultivation key ability modifier`

At CL17, the reduction becomes:

`3d8 + your Qi Cultivation key ability modifier`

If the damage is reduced to 0, move the protected creature or the Armament 5 feet without provoking Opportunity Attacks.

Guardian Armament can protect against melee or ranged attack rolls, but it does not apply to saving-throw effects or automatic damage.

### Named Treasure Recall

**Canonical ID:** `insight.named-treasure-recall`

**Prerequisite:** Qi Cultivation, one named weapon, shield, instrument, or cultivation implement that recognizes your bond, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You always know the direction of the named treasure while it is on the same plane.

**Bonus Action**  
**Cost:** 1 Qi

Call the treasure to a legal free hand or floating Domain Armament position from up to 1 mile away.

The call is supernatural movement and may cross ordinary intervening distance, but it is blocked by:

- A sealed Formation.
- A spatial lock.
- An artifact restraint.
- A higher-authority ownership or control effect.
- A planar boundary.

Once per scene, while holding or controlling the treasure, add your Proficiency Bonus to one failed saving throw, potentially turning it into success.

The item is never duplicated.

### Shield Orbit Discipline

**Canonical ID:** `insight.shield-orbit-discipline`

**Prerequisite:** Domain Armament capable of Guard Mode, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

A shield or defensive Domain Armament may change its protected creature once per turn without using an action.

**Reaction**  
**Trigger:** A creature within 15 feet of the Armament is hit by an attack roll.  
**Cost:** 1 Qi

Move the Armament up to 15 feet to a legal point adjacent to that creature and increase its AC against the triggering attack by 2.

This can cause the attack to miss.

After the reaction, the creature becomes the Armament's protected creature until the start of your next turn.

The Armament must have a legal path and cannot cross a sealed Formation, spatial lock, or solid barrier.

### Remote Weapon Conduction

**Canonical ID:** `insight.remote-weapon-conduction`

**Prerequisite:** Domain Armament Link, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a floating bound weapon delivers a cultivation technique, waive the 1-Qi Remote Technique Origin surcharge once per turn.

At CL15, this free use is separate from Nascent Armament Conduction. You may therefore waive the surcharge for:

- One weapon-delivered remote technique through this Insight.
- One other remote-origin technique through Nascent Armament Conduction.

A single technique still uses one origin unless it expressly permits multiple origins.

### Companion Armament

**Canonical ID:** `insight.companion-armament`

**Prerequisite:** Domain Armament, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You may maintain two Domain Armaments before CL20.

Manifest or release both through the same Bonus Action for 2 Qi.

Before CL20:

- Move both during your turn.
- One may attack through your Domain Armament Bonus Action.
- The other may remain in Guard Mode or serve as a technique origin.
- You cannot make two Domain Armament Attacks from the same Bonus Action.
- A technique uses one origin unless expressly permitted otherwise.

At CL20, Immortal of Qi upgrades both Armaments to the full Twin Domain Armament rules. This Insight then allows you to maintain a third Armament, but only two may attack during the same turn and the third must Guard, carry an authorized field, or act as an origin.

### Armament Formation Node

**Canonical ID:** `insight.armament-formation-node`

**Prerequisite:** Domain Armament and the Formations Sphere, Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another Formation-authorized Source Rule, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Domain Armament may serve as one movable Formation Anchor.

When used as an Anchor:

- It uses the better of its item durability or `AC equal to your Cultivation Save DC` and `Hit Points equal to 3 × your CL`.
- It may move normally unless the Formation expressly requires a fixed Anchor.
- Moving it repositions only effects that the Formation permits to move.
- If it is suppressed, restrained, or forced out of legal range, the anchored portion is suppressed.
- A real bound item is not duplicated or made indestructible.

Once per turn after moving the Anchor, gain one of the following until the start of your next turn:

- +1 AC for one ally inside the Formation.
- Move one willing creature in the Formation 5 feet.
- Extend one Formation line by 5 feet.
- Reveal one creature touching a Formation boundary.

### Armament Reversal

**Canonical ID:** `insight.armament-reversal`

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** A creature within 5 feet of your Domain Armament misses you or its protected creature with an attack roll.  
**Cost:** 2 Qi

Make one Domain Armament Attack against the triggering creature.

On a hit, choose one:

- Push it 10 feet.
- It cannot take Reactions until the start of its next turn.
- Move the protected creature 5 feet without provoking Opportunity Attacks.
- Change the Armament between Assault and Guard Mode.

Armament Reversal cannot trigger another additional attack or repeat a weapon-delivered cultivation technique unless that technique expressly permits reaction delivery.

## Qi — Elemental Refinement Insights

### Elemental Mastery

**Canonical ID:** `insight.elemental-mastery`

**Prerequisite:** Qi Cultivation, access to the chosen damage type, CL4+  
**Repeatable:** Choose a different damage type each time

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose Acid, Cold, Fire, Lightning, Necrotic, Poison, Radiant, or Thunder.

Once per activation, when a Qi-powered feature deals the chosen damage type, add your Proficiency Bonus to one damage roll.

At CL12, the activation ignores ordinary Resistance to the chosen type.

At CL18, ordinary Immunity to the chosen type is treated as Resistance instead.

Elemental Mastery does not bypass:

- Artifact protection.
- Secret authority.
- Conceptual Immunity.
- An effect explicitly described as absolute or higher-order.

### Elemental Fusion Body

**Canonical ID:** `insight.elemental-fusion-body`

**Prerequisite:** Elemental Mastery, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to the damage type selected for one Elemental Mastery Insight.

Once per round, after a qualifying hostile source damages you with that type, choose one:

- Regain 1 Qi.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Move 5 feet without provoking Opportunity Attacks.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.

A harmless source, willing ally, environmental loop you arranged, or damage you dealt to yourself solely to trigger this Insight does not qualify.

If another feature already grants Resistance to the selected type, reduce the first damage packet of that type each round by your Proficiency Bonus instead.

### Elemental Core Mutation

**Canonical ID:** `insight.elemental-core-mutation`

**Prerequisite:** Qi Cultivation, one elemental Sphere, CL8+  
**Repeatable:** Choose a different elemental Sphere each time

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one elemental Sphere you know.

At the end of a Full Cultivation Session, choose one mutation. It remains until you complete another Full Cultivation Session and choose again.

### Resistant Mutation

Gain Resistance to one damage type directly associated with the Sphere.

### Violent Mutation

Once per turn, one damaging feature from the Sphere deals additional damage equal to your Proficiency Bonus.

### Driving Mutation

Increase one forced movement caused by the Sphere by 10 feet once per turn.

### Flowing Mutation

Once per turn after activating a feature from the Sphere, move 10 feet without provoking Opportunity Attacks.

### Sheltering Mutation

Once per turn after activating a feature from the Sphere, you or one affected ally gains Temporary Hit Points equal to `2 × your Proficiency Bonus`.

### Expansive Mutation

Once per turn, increase one radius or cone by 5 feet or one line by 10 feet.

A single activation benefits from one mutation granted by this Insight.

### Dual-Element Golden Core

**Canonical ID:** `insight.dual-element-golden-core`

**Prerequisite:** Two elemental Spheres, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose two elemental Spheres you know.

When you activate a Qi-powered feature from one chosen Sphere, your next feature from the other chosen Sphere before the end of your next turn gains one Fusion benefit:

- Reduce its Qi cost by 1, minimum 1.
- Add your Proficiency Bonus to one damage or healing roll.
- Increase one forced movement by 10 feet.
- Move 10 feet without provoking Opportunity Attacks after it resolves.
- Grant one affected ally Temporary Hit Points equal to `2 × your Proficiency Bonus`.

Use one Fusion benefit per turn.

Repeatedly using the same element does not generate Fusion.

### Five-Element Meridian Cycle

**Canonical ID:** `insight.five-element-meridian-cycle`

**Prerequisite:** Five Elements Cultivator or at least three elemental Spheres, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you activate Qi-powered features carrying three different elemental alignments during the same scene, gain 1 Cycle Charge after the third resolves.

- Maximum Cycle Charges: Your Proficiency Bonus.
- Each distinct activation can count toward one sequence.
- Repeating an element before completing the sequence does not erase progress but does not advance it.
- A new sequence begins after a charge is gained.

Spend 1 Cycle Charge when activating a Qi-powered feature to choose one:

- Reduce its Qi cost by 1, minimum 1.
- Add `2d8` to one damage or healing roll.
- Increase one forced movement by 10 feet.
- Increase one radius or cone by 5 feet or one line by 10 feet.
- Grant one affected ally Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain +2 AC until the start of your next turn.

Unused Cycle Charges disappear when the scene ends.

### Elemental Dominion

**Canonical ID:** `insight.elemental-dominion`

**Prerequisite:** Elemental Mastery, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

**Action**  
**Range:** 90 feet  
**Area:** 20-foot-radius, 20-foot-high cylinder  
**Duration:** 1 minute  
**Concentration:** Required  
**Cost:** 6 Qi

Create a Dominion of the damage type chosen for Elemental Mastery.

For the duration:

- Your Qi-powered features of the selected type may originate from any point inside the Dominion.
- Allies you choose gain Resistance to the selected type while inside.
- The first time during each turn that a hostile creature takes the selected damage inside, it takes additional damage equal to your Proficiency Bonus.
- An ordinary environmental expression of the element obeys your printed direction inside the area.

When a hostile persistent elemental effect of an opposing or incompatible type overlaps the Dominion:

- If its Source CL is lower than yours, suppress it in the overlap.
- If its Source CL is equal to or higher than yours, make a Cultivation Check against its save DC. On success, suppress it in the overlap until the start of your next turn.

Elemental Dominion is a Qi field, not a Spirit Awakening Domain.

## Qi — Golden Core and Nascent Soul Insights

### Stable Core Refinement

**Canonical ID:** `insight.stable-core-refinement`

**Prerequisite:** Stable Golden Core, CL10+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When Stable Golden Core reduces hostile Qi loss, gain Temporary Hit Points equal to your Proficiency Bonus.

**Reaction**  
**Trigger:** You fail a saving throw or Cultivation Check against meridian sealing, Golden Core damage, Qi theft, maximum-Qi reduction, or forced cost increase.  
**Cost:** 1 Qi

Add your Proficiency Bonus to the roll, potentially turning failure into success.

When Stable Golden Core becomes Perfected, this Reaction costs 0 Qi once per round.

### Circulating Core Refinement

**Canonical ID:** `insight.circulating-core-refinement`

**Prerequisite:** Circulating Golden Core, CL10+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Whenever Circulating Golden Core triggers, choose one additional different benefit.

Before Perfected Circulating Golden Core, choose two different benefits instead of one.

After it becomes Perfected, choose three different benefits instead of two.

You may also change one Domain Armament between Assault and Guard Mode as part of the trigger.

A single named benefit cannot be selected twice from the same trigger.

### Reservoir Core Refinement

**Canonical ID:** `insight.reservoir-core-refinement`

**Prerequisite:** Golden Core Reservoir, CL10+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Golden Core Reservoir gains a second use during each scene.

When you use it a second time during the same scene:

- Regain the normal amount.
- Gain 1 level of Exhaustion after the Qi is restored.

This Exhaustion:

- Cannot be prevented.
- Cannot be transferred.
- Cannot be removed before the scene ends.

After Golden Core Reservoir becomes Perfected, the second use restores the Perfected amount.

### Compressed Golden Core

**Canonical ID:** `insight.compressed-golden-core`

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when you activate a Qi-powered feature, compress it in one of these ways:

### Single-Target Compression

If the feature affects exactly one target, add your Proficiency Bonus to one damage or healing roll and increase its save DC by 1.

### Area Compression

Reduce one printed area dimension by at least 5 feet. Add your Proficiency Bonus to one damage or healing roll against one target in the reduced area and subtract 1 from the first saving throw made against it.

### Line Compression

Reduce a line's width to 5 feet or reduce its length by at least 20 feet. The line ignores Half Cover and Three-Quarters Cover.

A feature cannot benefit from Compressed and Expansive Golden Core during the same activation.

### Expansive Golden Core

**Canonical ID:** `insight.expansive-golden-core`

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, spend 1 additional Qi to increase one area dimension of a Qi-powered feature:

- Radius: +10 feet.
- Cone length: +10 feet.
- Line length: +20 feet.
- Cube side: +10 feet.
- Aura radius: +5 feet.
- Wall length: +20 feet.

Expansive Golden Core cannot increase:

- A Self-only feature into an area.
- A strategic-scale area.
- A permanent structure beyond its printed material.
- An area whose Source Rule explicitly cannot be expanded.

A feature cannot benefit from Compressed and Expansive Golden Core during the same activation.

### Core-Sheltering Scripture

**Canonical ID:** `insight.core-sheltering-scripture`

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws and Cultivation Checks against:

- Golden Core damage.
- Core extraction.
- Forced Core mutation.
- Core imprisonment.
- Suppression of your Golden Core Form.
- Effects attempting to replace your Golden Core.

Once per round, when a hostile effect suppresses or damages a Golden Core function, choose one:

- Spend 2 Qi to delay the suppression until the end of your current turn.
- Reduce its duration by one round, minimum one round.
- Move 10 feet without provoking Opportunity Attacks before the suppression fully takes hold.
- Transfer the effect's Anchor mark to your Domain Armament when the effect can legally target it; the Armament becomes the affected Anchor instead.

A Secret or higher-authority effect may require a Cultivation Check against its save DC to use the final option.

### Nascent Soul Reserve

**Canonical ID:** `insight.nascent-soul-reserve`

**Prerequisite:** Nascent Soul, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Nascent Continuity restores:

`2 × your Proficiency Bonus Qi`

instead of your Proficiency Bonus.

When Nascent Continuity activates, choose one:

- End Charmed or Frightened when its Source CL is no higher than yours.
- End Grappled or Restrained when its Source CL is no higher than yours.
- Move 15 feet without provoking Opportunity Attacks.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.
- Restore a suppressed Domain Armament to a legal point within 30 feet when the suppressing Source CL is lower than yours.

Against a higher-CL condition, you may immediately repeat its saving throw with Advantage instead of ending it.

### Borrowed Golden Form

**Canonical ID:** `insight.borrowed-golden-form`

**Prerequisite:** Qi Cultivation, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Cost:** 4 Qi  
**Limit:** Once per scene  
**Duration:** Until the scene ends

Choose one Golden Core Form you do not currently possess.

Gain its unperfected benefits for the duration.

At CL17, the borrowed Form remains unperfected unless another Source Rule explicitly perfects it.

At CL20, when you permanently possess two Perfected Forms, Borrowed Golden Form may grant the third Form in its Perfected state for the scene.

A borrowed Golden Core Reservoir begins unused, but its use disappears when the borrowed Form ends.

### Nascent Soul Externalization

**Canonical ID:** `insight.nascent-soul-externalization`

**Prerequisite:** Nascent Soul, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Cost:** 4 Qi  
**Duration:** 1 minute

Project your Nascent Soul into an unoccupied point within 30 feet.

The projection:

- Is not a separate creature.
- Occupies no space.
- Has Fly Speed 30 feet and Hover.
- Moves up to 30 feet once during each of your turns without using an action.
- May serve as the origin of a non-Self Qi-powered technique once per turn.
- May maintain line of sight for your Domain Armament.
- Reveals your spiritual position to Qi Sensing.

If the projection is struck by an effect that explicitly targets souls, Nascent Souls, or projected cultivation structures, use your statistics and Source CL. On a failed save, take the effect normally and the projection ends.

The projection ends if it moves more than 60 feet from you, you become Unconscious, or it is successfully sealed.

## Qi — Preparation and Strategic Insights

### Formation Apprentice

**Canonical ID:** `insight.formation-apprentice`

**Prerequisite:** Formations Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain +2 on Cultivation Checks involving:

- Formation design.
- Formation identification.
- Formation repair.
- Formation disruption.
- Anchor placement.
- Formation maintenance.

During a 10-minute preparation procedure, create one temporary Minor Anchor from available materials.

The Anchor:

- Uses your Source CL.
- Has AC equal to your Cultivation Save DC.
- Has Hit Points equal to `2 × your CL`.
- Lasts until destroyed, dismissed, or you complete a Full Cultivation Session.
- Can support only a Formation effect that explicitly accepts a Minor or temporary Anchor.

You may maintain one temporary Minor Anchor from this Insight.

### Formation Engineer

**Canonical ID:** `insight.formation-engineer`

**Prerequisite:** Formation Apprentice, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

One Formation Anchor you create or maintain gains:

- Additional Hit Points equal to your CL.
- Damage Threshold equal to your Proficiency Bonus when it lacks a higher threshold.
- Advantage on saving throws against forced movement and suppression.

Reduce ordinary material requirements and preparation time for non-Secret Formations by 25 percent.

**Reaction**  
**Trigger:** One visible Formation Anchor within 60 feet would be reduced to 0 Hit Points.  
**Cost:** 2 Qi

The Anchor remains at 1 Hit Point instead.

An Anchor can benefit from this reaction once per scene.

### Talisman Savant

**Canonical ID:** `insight.talisman-savant`

**Prerequisite:** Talismans Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when activating a non-ritual talisman that normally requires an Action, spend 1 additional Qi to activate it as a Bonus Action instead.

This Insight cannot accelerate:

- A permanent inscription.
- A strategic-scale talisman.
- A Secret talisman.
- A resurrection effect.
- A talisman requiring more than one Action of continuous activation.
- An item whose printed activation cannot be accelerated.

All charges, consumed materials, target limits, and other costs remain unchanged.

### Seal Breaker

**Canonical ID:** `insight.seal-breaker`

**Prerequisite:** Talismans Sphere, Cultivator of Seals, Puzzle Cultivator, Calligraphy Cultivator, or another seal-authorized Source Rule, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on Cultivation Checks to detect, identify, weaken, solve, or remove seals.

**Reaction**  
**Trigger:** A visible seal, lock, binding script, or cultivation prison within 60 feet activates.  
**Cost:** 2 Qi

Make a Cultivation Check against its save DC.

- **Success:** Suppress the activation until the end of the current turn. If the effect requires a target decision, movement, payment, or attack, that portion fails for the turn.
- **Failure:** The effect activates normally, but you learn its Source CL, Anchor direction, and one printed escape or release condition.

Against a seal whose Source CL is 6 or more lower than yours, you may instead break one nonpermanent layer automatically.

### Jade Inscription Master

**Canonical ID:** `insight.jade-inscription-master`

**Prerequisite:** Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another durable-inscription Source Rule, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Increase the number of durable inscriptions you may maintain by 2.

Choose one durable inscription you create. It may store two charges instead of one.

When its normal recovery procedure would restore charges:

- It restores one charge.
- A Full Cultivation Session performed while touching it restores all missing charges.

A second charge does not duplicate a consumed material, permanent sacrifice, or irreplaceable item component.

### Cauldron Heart

**Canonical ID:** `insight.cauldron-heart`

**Prerequisite:** Alchemy and Pill Forging Sphere or Alchemical Cultivator, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain +2 on Cultivation Checks involving:

- Brewing.
- Pill diagnosis.
- Ingredient substitution.
- Cauldron stabilization.
- Poison identification.
- Medicine refinement.

Once during each distinct crafting procedure, after failing a crafting or stabilization check, reroll it.

You must use the new result.

If the reroll also fails, choose one consequence reduction:

- Prevent the cauldron or workshop from being destroyed.
- Preserve half of the ordinary ingredients.
- Contain the failure to a 5-foot area.
- Learn the exact failed stage and required corrective material.

This Insight cannot preserve a Secret ingredient, permanent sacrifice, or irreplaceable relic consumed by the procedure.

### Portable Workshop

**Canonical ID:** `insight.portable-workshop`

**Prerequisite:** One preparation-based Sphere or Subpath, CL8+  
**Repeatable:** Choose a different workshop type each time

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one workshop type, such as:

- Alchemical cauldron.
- Talisman desk.
- Formation bench.
- Smithing forge.
- Medical clinic.
- Calligraphy table.
- Inscription frame.
- Culinary station.
- Kiln.

You possess or construct a portable version.

Benefits:

- Setup and breakdown time are halved.
- Routine downtime work may continue during ordinary travel when the environment permits.
- The workshop counts as proper tools for trained procedures.
- It protects ordinary materials from weather and travel damage.

It does not permit major projects while moving, waive rare facilities, or replace a required ley line, furnace, laboratory, spirit spring, or strategic Formation.

### Imperial Quartermaster Training

**Canonical ID:** `insight.imperial-quartermaster-training`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain proficiency in one of the following: Animal Handling, Investigation, Persuasion, land vehicles, water vehicles, navigator's tools, cartographer's tools, or one merchant or appraisal tool printed by the equipment rules. If already proficient, gain a +2 bonus to checks with the chosen proficiency.

During expedition preparation, choose two Quartermaster benefits:

- reduce ordinary supply costs by 20 percent;
- acquire one Common consumable listed as normally sold, gathered, or produced in the current settlement or region without a separate search procedure;
- identify the most likely logistical failure from food, water, transport, shelter, storage, customs, route security, or medical supply;
- establish one concealed mundane cache holding up to `50 × your CL` pounds of ordinary supplies;
- gain Advantage on one bureaucracy, requisition, customs, or military-supply check during the expedition; or
- increase the carrying capacity of one vehicle or storage Formation by 25 percent through correct loading.

The chosen benefits last for that expedition or operation and do not create Rare, Restricted, or Secret goods.

### Field Refinement Doctrine

**Canonical ID:** `insight.field-refinement-doctrine`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

After completing a 10-minute cultivation preparation procedure, you may perform one 10-minute Field Refinement on an existing non-Secret Cultivation Asset, Domain Armament, Formation Anchor, talisman, medical implement, or prepared vessel.

Choose one benefit lasting until the end of the next scene:

- Increase its Hit Points by `2 × your Proficiency Bonus`.
- Increase its movement by 10 feet.
- Increase one operating range by 10 feet.
- Grant it Advantage on the first saving throw it makes.
- Allow it to ignore the first ordinary suppression effect whose Source CL is lower than yours.
- Reduce the Qi cost of its first activation by 1, minimum 1.

An object or asset may hold one Field Refinement.

## Qi — Imperial Training Insights

### Imperial Academy Graduate

**Canonical ID:** `insight.imperial-academy-graduate`

**Prerequisite:** Recognized academy access, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain proficiency in Arcana and History. If already proficient in either, gain +2 on checks using that skill instead.

Also gain one:

- Language.
- Script.
- Tool proficiency.
- Bureaucratic credential.

Once per scene, reroll one failed institutional, legal, historical, scholarly, or technical Cultivation Check.

You must use the new result.

Academy status creates obligations, records, superiors, rivals, and possible service requirements according to the institution.

### Imperial Examination Laureate

**Canonical ID:** `insight.imperial-examination-laureate`

**Prerequisite:** Imperial Academy Graduate, successful examination or equivalent recorded recognition, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Sphere listed in the academy curriculum tied to your examination record and for which you possess recorded legal access.

Learn that Sphere and gain its normal free first talent under the universal new-Sphere rule.

In addition:

- training time for talents listed in that curriculum is reduced by 25 percent;
- gain Advantage on checks to obtain legal manuals, teachers, archives, and licenses from officials recognizing your rank; and
- once per CL, one training attempt for a listed talent may be retried after half the normal failed-training delay.

Rank does not waive Secret access, inheritance requirements, sect exclusivity, or political obligations.

### Imperial Officer's Circulation

**Canonical ID:** `insight.imperial-officer-s-circulation`

**Prerequisite:** Military, guard, administrative, or command training, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When Initiative is rolled, choose one ally within 30 feet.

That ally gains +2 to its Initiative result for the scene. This may change order immediately.

**Reaction**  
**Trigger:** An ally within 30 feet fails a saving throw.  
**Cost:** 2 Qi

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency and cannot modify death, breakthrough, or training rolls.

If the save succeeds after this bonus, move the ally 5 feet without provoking Opportunity Attacks or allow it to stand from Prone.

### Provincial Ley-Line Familiarity

**Canonical ID:** `insight.provincial-ley-line-familiarity`

**Prerequisite:** Qi Cultivation, CL8+  
**Repeatable:** Choose a different recorded ley-line region each time

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one province, watershed, mountain chain, city network, or other ley-line region whose boundaries are recorded on a campaign map or regional ledger.

Within that region:

- you know the direction of the nearest major usable ambient-Qi source within 10 miles when one exists;
- a Full Cultivation Session requires 1 hour instead of 2 hours at a healthy local source;
- when Initiative is rolled while directly connected to an active local ley line, regain Qi equal to your Proficiency Bonus once per scene; and
- gain Advantage on checks to identify local Formations, spirit roads, Qi pollution, and regional cultivation traditions.

A damaged, poisoned, sealed, or hostile ley line applies only the benefits permitted by its recorded state.

### Imperial Archivist

**Canonical ID:** `insight.imperial-archivist`

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, prepare one **Archive Question** concerning a named creature, place, item, technique, sect, historical event, law, lineage, Formation, or cultivation phenomenon.

Before your next Full Cultivation Session, when the question becomes relevant, choose one result category:

- direct clue;
- documented precedent;
- investigation avenue;
- known weakness category;
- historical relationship;
- legal or sectarian obligation; or
- scholarly inference.

Resolve the question from records that actually exist in the setting. The adjudicator provides one truthful result in the chosen category. If no relevant record exists, the result is: **No surviving record**, followed by the nearest documented lead that can be investigated. A scholarly inference must be labeled as inference.

This Insight cannot fabricate lost knowledge, reveal a Secret erased from every record, or provide information no archive, witness record, or documented precedent could contain.

### Imperial Armory Certification

**Canonical ID:** `insight.imperial-armory-certification`

**Prerequisite:** Imperial, military, sect-armory, or equivalent authorization, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Intelligence score by 1, to the maximum allowed by your current Realm.

Choose one weapon group, armor category, shield category, vehicle weapon, siege implement, or military cultivation implement for which you possess access.

Gain one of the following:

- Proficiency with the chosen weapon group.
- Proficiency with the chosen armor or shield category.
- Tool proficiency needed to operate the chosen siege or vehicle implement.
- A +2 bonus if already proficient.

This Insight represents formal training and certification rather than Path chassis proficiency.

When using an authorized item, gain Advantage on checks to inspect, maintain, requisition, safely store, or identify sabotage affecting it.

## Qi — Cross-Sphere Insights

### Might-Sphere Discipline

**Canonical ID:** `insight.might-sphere-discipline`

**Prerequisite:** Recorded legal access to one Might Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Might Sphere identified by your access record. Learn that Sphere and gain its normal free first talent.

For each talent from that Sphere, record whether it operates through cultivated Qi or requires transformed anatomy.

A talent recorded as Qi-compatible uses:

- Qi as its Cultivation Point resource;
- your Qi Cultivation key ability; and
- your Qi Cultivation Save DC and Attack Modifier.

This Insight does not grant Body Refining Hit Dice, Body Refining attack progression, Stamina, Body-only external projection, a Body Refining Foundation, or another Body chassis feature.

A talent whose printed premise requires transformed anatomy remains unusable until a Method, Foundation, item, bloodline, or explicit Qi adaptation supplies that anatomy.

### Hybrid-Sphere Refinement

**Canonical ID:** `insight.hybrid-sphere-refinement`

**Prerequisite:** One Hybrid Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose the Power expression of one Hybrid Sphere you know.

You may use that expression through Qi and your Qi Cultivation key ability where the Sphere permits.

Retraining between its Might and Power expressions requires:

- 7 days of training;
- a qualified master, manual, lineage, or equivalent recorded source;
- the normal training check; and
- every Restricted, Secret, inherited, ethical, or license requirement printed by the Sphere.

The retraining does not erase talents that remain legal in both expressions.

### Spirit-Adjacent Scripture

**Canonical ID:** `insight.spirit-adjacent-scripture`

**Prerequisite:** Recorded legal access to one Spirit-adjacent Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Spirit-adjacent Sphere identified by your access record. Learn that Sphere and gain its normal free first talent.

Use Qi and your Qi Cultivation key ability for legal Power expressions from that Sphere.

This Insight does not grant Resonance, Spirit Awakening Domains, Spirit Companion chassis rules, or identity-based spiritual authority unless the chosen Sphere expressly grants it.

### Restricted Sphere License

**Canonical ID:** `insight.restricted-sphere-license`

**Prerequisite:** Imperial, sectarian, hereditary, professional, or equivalent authorization; CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Restricted Sphere to which the license grants access.

Learn the Sphere and its normal free first talent if the authorization includes instruction. If it grants legal use only, this Insight instead grants access to training.

Once per scene, gain Advantage on one check involving the licensed Sphere's:

- Learning.
- Research.
- Identification.
- Stabilization.
- Repair.
- Countering.
- Legal deployment.

The license provides its recorded social and legal benefits but may impose reporting, service, inspection, or geographic restrictions.

## Qi — Bloodline Insights

### Ancestral Bloodline Awakening

**Canonical ID:** `insight.ancestral-bloodline-awakening`

**Prerequisite:** A recorded bloodline source gained through discovered heritage, absorbed ancestral essence, bloodline event, or another explicit Source Rule

**Ability Increase (Level Selection):** Increase your Constitution or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one gift below that matches the recorded lineage.

### Dragon Gift

Choose Acid, Cold, Fire, Lightning, Poison, Radiant, or Thunder as the lineage damage type. Gain Resistance to that type. Spend 2 Qi as a Bonus Action to gain a Fly Speed of 30 feet until the end of your turn.

### Phoenix Gift

When reduced to 0 Hit Points without being killed outright, spend 4 Qi to remain at 1 Hit Point. Hostile creatures within 5 feet take `2d8` Fire or Radiant damage, chosen when the gift is gained; each makes a Dexterity saving throw against your Qi Cultivation Save DC, taking half damage on a success. Once per scene.

### Demon-Blood Gift

Choose Necrotic, Psychic, Poison, or one damage type printed by the lineage source. Once per turn, one damaging Qi-powered feature deals an additional `1d6` damage of that type.

### Jade Tortoise Gift

Gain +1 AC and reduce forced movement applied to you by 5 feet, to a minimum of 0 feet.

### Fox Gift

Gain proficiency in Deception, Insight, Performance, or Persuasion; if already proficient in the chosen skill, gain a +2 bonus to checks with it. As a Reaction when a creature you can perceive within 30 feet makes an attack roll, spend 1 Qi to impose Disadvantage on that roll.

A lineage not represented above requires a separate published lineage-gift record before this Insight can select it. The gift's social classification depends on the lineage and culture; it is not automatically Daemonic.

### Deepened Ancestral Memory

**Canonical ID:** `insight.deepened-ancestral-memory`

**Prerequisite:** A bloodline feature, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain proficiency in one skill, tool, language, script, weapon group, or ritual practice associated with your lineage. If already proficient, gain +2 instead.

Once per scene, after failing a check directly connected to your ancestry, inherited culture, bloodline enemy, ancestral territory, or lineage technique, reroll it.

You must use the new result.

During a Full Cultivation Session, you may ask one question of ancestral memory. The answer is limited to knowledge a genuine ancestor could have possessed and may be symbolic, incomplete, or biased, but it cannot be deliberately false unless the ancestral source itself is deceptive.

### Bloodline-Core Fusion

**Canonical ID:** `insight.bloodline-core-fusion`

**Prerequisite:** Bloodline Cultivator, Ancestral Bloodline Awakening, or another active bloodline engine; CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you activate a bloodline feature explicitly tagged **Surge**, **Transformation**, or **Release**, choose two different Fusion benefits:

- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`;
- move 10 feet without provoking Opportunity Attacks;
- regain 2 Qi;
- gain Advantage on your next saving throw before the end of your next turn;
- end ordinary Frightened or Charmed when its Source CL is lower than yours;
- move your Domain Armament 20 feet; or
- your next lineage-tagged attack or technique before the end of your next turn deals additional damage equal to your Proficiency Bonus.

One bloodline activation triggers Bloodline-Core Fusion once.

### Ancestral Treasure Bond

**Canonical ID:** `insight.ancestral-treasure-bond`

**Prerequisite:** A bloodline feature and one genuine ancestral weapon, shield, artifact, implement, or relic; CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

The ancestral treasure may serve as your Domain Armament even when its form would not ordinarily qualify, provided it is a noncreature item and consents when sentient.

While bound:

- You always know its direction on the same plane.
- It gains Advantage on saving throws against suppression, theft, and severing the bond.
- You may use your Qi Cultivation key ability for Cultivation Checks involving its lineage properties.
- Once per scene, when one of its lineage properties would fail because your CL is too low by 2 or less, treat your CL as 2 higher for that property only.

This does not waive attunement, bloodline identity, permanent prices, or item charges.

## Qi — Forbidden, Condemned, and Predatory Insights

### Soul-Devouring Scripture

**Canonical ID:** `insight.soul-devouring-scripture`

**Prerequisite:** Qi Devourer, access to a forbidden or predatory manual, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When Qi Devourer consumes essence from a sentient creature, you may take a deeper soul fragment.

If you do:

- regain 4 additional Qi;
- learn one dominant emotion, unresolved oath, major fear, or active spiritual allegiance carried by the victim; and
- the victim suffers **Soul Depletion**.

### Soul Depletion

Until repaired, the victim has Disadvantage on its first saving throw in each scene against possession, dream intrusion, emotional manipulation, or soul damage; cannot yield another soul fragment to you; and displays a visible spiritual wound to Qi Sensing.

Soul Depletion is repaired by one of the following:

- a 1-hour spiritual treatment that succeeds on a Medicine or Cultivation Check against your Qi Cultivation Save DC;
- Spiritual Exorcism whose Source CL is at least yours;
- a Full Cultivation Session performed under a soul-repair Method, Foundation, Spirit, or Samsara Source Rule whose Source CL is at least yours; or
- another Source Rule that expressly repairs Soul Depletion.

This Insight does not trap the complete soul or prevent resurrection unless another higher-authority Source Rule expressly does so.

### Cremation-Furnace Core

**Canonical ID:** `insight.cremation-furnace-core`

**Prerequisite:** Cinder Heart Cultivator or Fire/Ash cultivation access, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a qualifying creature is reduced to 0 Hit Points within 30 feet after taking Fire, Radiant, or Ash-tagged damage from you during the current turn, gain 1 Ash Charge.

- Maximum Ash Charges: Your Proficiency Bonus.
- A creature yields one Ash Charge until its body, spirit, or cultivation is genuinely restored.
- Ash Charges disappear after a Full Cultivation Session unless incorporated into another printed procedure.

Spend 1 Ash Charge when activating a Qi-powered feature to choose one:

- Add `1d8` Fire or Necrotic damage to one roll.
- Reduce its Qi cost by 1, minimum 1.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Move 10 feet without provoking Opportunity Attacks.
- Prevent one damaged target from regaining Hit Points until the start of your next turn.

Using this Insight leaves visible cremation residue on your Golden Core and victims.

### Heart-Stealing Resonance

**Canonical ID:** `insight.heart-stealing-resonance`

**Prerequisite:** Emotion Cultivator or access to Mind, Emotion, or Spirit manipulation; CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature fails a saving throw against one of your emotional cultivation effects, spend 2 additional Qi to choose one:

- Learn its current dominant emotion.
- Learn one emotional vulnerability presently influencing its decisions.
- Give it Disadvantage on its next saving throw against Charmed or Frightened before the end of your next turn.
- Prevent it from receiving emotional support, morale bonuses, or another creature's reassurance until the start of your next turn.
- Extract one surface emotion into a visible Heart Fragment lasting until the scene ends.

A Heart Fragment may be used as a focus, evidence, ritual component, or emotional key under an authorized Source Rule.

Permanent emotional theft, transplantation, removal, or rewriting requires an effect that explicitly authorizes it, such as the Heart-Stealing forbidden Subpath, a helpless or properly bound target, a ritual, sufficient authority, and printed recovery consequences.

This Insight is not automatically Daemonic.

### Nightmare Feaster

**Canonical ID:** `insight.nightmare-feaster`

**Prerequisite:** Dream Qi Cultivator or Dreams Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature fails a saving throw against one of your Dream-, Nightmare-, Sleep-, Fear-, or dream-illusion effects, gain Temporary Hit Points equal to your Proficiency Bonus once per round.

### Predatory Dream Harvest

**Ritual Time:** 10 minutes  
**Range:** Touch or shared dream connection  
**Target:** One sleeping, unconscious, restrained, willing, or otherwise accessible genuine dreamer

Drain the target's active dream substance.

The target makes a Wisdom or Charisma saving throw, its choice, unless willing.

- **Failed Save:** Regain Qi equal to your Proficiency Bonus. The target suffers one Dream Trauma.
- **Successful Save:** Regain 1 Qi. The target wakes and knows an intrusion occurred.

A Dream Trauma imposes one of the following, chosen when harvested:

- `2d8` Psychic damage that cannot be healed until the target completes a Full Cultivation Session devoted to recovery.
- Maximum Hit Points reduced by your Proficiency Bonus until cultivated treatment.
- One level of Exhaustion.
- Loss of one specific recent memory until dream therapy or restoration.
- Disadvantage on the next saving throw against Dreams or Fear.

A creature may suffer a number of Dream Traumas equal to its Proficiency Bonus.

When its Dream Traumas reach that maximum:

- It becomes comatose and cannot wake naturally until at least one Trauma is removed.
- A further failed harvest deals `4d8` Psychic damage and reduces its Hit Point maximum by the same amount.
- If this maximum-Hit-Point reduction reaches its normal Hit Point maximum, the creature dies and its dreaming consciousness is consumed or scattered.

A Dream Trauma is removed by one of the following: a 1-hour dream-therapy procedure that succeeds on a Wisdom (Medicine), Wisdom (Insight), or Cultivation Check against your Qi Cultivation Save DC; Spiritual Exorcism or memory restoration whose Source CL is at least yours; a Full Cultivation Session under a Dreams or Samsara Source Rule whose Source CL is at least yours; or another Source Rule that expressly repairs Dream Trauma.

A self-created dream construct, illusory sleeper, or closed refund loop provides no Qi unless it possesses independent genuine consciousness.

The practice may be called demonic by the Empire or other institutions, but it gains the Daemonic tag only from a separate rule.

### Poisoned-Meridian Scripture

**Canonical ID:** `insight.poisoned-meridian-scripture`

**Prerequisite:** Poison Cultivator or Poison Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once per turn when a creature fails a saving throw against your Poison Touch, cultivated poison, or Poison-tagged Qi technique, spend 2 additional Qi to infect one meridian function until the start of your next turn.

Choose one:

- Reduce Speed by an additional 10 feet.
- Prevent Hit Point recovery and Temporary Hit Points.
- Give Disadvantage on the target's next Constitution saving throw.
- Increase the Qi cost of its next feature by 1.
- Prevent Qi recovery.
- Reveal its direction to you while within 1 mile and on the same plane.

Against a target whose Source CL is 6 or more lower than yours, you may spend 4 additional Qi to extend the chosen infection until the scene ends. The target repeats the original poison saving throw at the end of each turn, ending it on a success unless the underlying poison states otherwise.

A higher-authority Venomous Poison feature may convert the temporary infection into an indefinite cultivation poison.

## Qi — Secret-Law Insights

### Void-Touched Core

**Canonical ID:** `insight.void-touched-core`

**Prerequisite:** Void Sphere, Void-Touched Cultivator, survival of genuine Void exposure, or equivalent Secret access

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one permanent visible or metaphysical Void Sign, such as:

- Missing reflection.
- Silent footsteps.
- A shadow with a gap.
- Records that fade at the edges.
- A cold absence in Qi Sensing.

Gain Advantage on saving throws and Cultivation Checks against:

- Void damage.
- Banishment.
- Unwilling teleportation.
- Planar displacement.
- Spatial erasure.
- Effects removing you from reality.

Once per scene, when an effect would teleport, banish, or remove you from your current plane, remain in place instead if its Source CL is lower than yours.

Against an equal or higher Source CL, make a Cultivation Check against its save DC. On success, remain.

### Hollow-Meridian Circulation

**Canonical ID:** `insight.hollow-meridian-circulation`

**Prerequisite:** Void Sphere or Void-Touched Cultivator, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, after activating a Void-tagged feature, choose one:

- Reduce its Qi cost by 1, minimum 1.
- Move 10 feet through a visible gap without provoking Opportunity Attacks.
- Gain Advantage on your next Cultivation Check before the end of your next turn.
- Suppress ordinary sound in your space until the start of your next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Ignore one ordinary physical barrier no more than 1 foot thick when measuring the feature's line of effect.

The final option cannot bypass lead, artifacts, sealed Formations, spatial locks, or higher-authority barriers.

### Missing-Step Technique

**Canonical ID:** `insight.missing-step-technique`

**Prerequisite:** Void Sphere, Void-Touched Cultivator, or Missing-Step inheritance; CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You are targeted by an attack roll or a line, cone, or area whose boundary you can perceive.  
**Cost:** 3 Qi

Teleport up to 15 feet to a visible legal space.

- An attack roll fails if you are no longer a legal target.
- A line, cone, or area affects you only if the destination remains inside it.
- The attacker cannot choose another target for the same attack.

Missing-Step Technique is blocked by spatial locks, sealed Formations, planar boundaries, and effects explicitly preventing Void movement.

### Erased Name

**Canonical ID:** `insight.erased-name`

**Prerequisite:** Void Sphere or Void-Touched Cultivator, CL16+, and recorded Secret access

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one permanent cost when gaining this Insight:

- unfamiliar people struggle to remember your face;
- mundane records of you fade unless renewed during each Full Cultivation Session;
- your reflection is absent;
- resurrection requires a personal Anchor bearing your true identity;
- wards and ancestral sites treat you as an unknown presence; or
- one former title or identity permanently disappears from ordinary memory.

Gain Advantage on saving throws and opposed checks against Divination, tracking cultivation, dream intrusion, memory alteration, possession, name-based curses, and oath effects that do not possess your true-identity Anchor.

An effect whose Source CL is lower than yours cannot learn your exact location through remote divination unless it already possesses a personal Anchor tied to your true identity.

### Samsara Memory

**Canonical ID:** `insight.samsara-memory`

**Prerequisite:** Samsara-Wheel Cultivator, reincarnation inheritance, or genuine former-life awakening; CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, choose one Former-Life Memory:

- one skill proficiency;
- one tool proficiency;
- one language or script;
- one weapon-group proficiency;
- one narrow historical field; or
- one non-Secret Sphere talent from a Sphere you already know and for which you meet every prerequisite.

The Memory remains until you replace it during another Full Cultivation Session.

A talent selected this way uses your Qi and Qi Cultivation statistics when legal and cannot be inherited, permanent, identity-exclusive, or dependent on anatomy or an Asset you do not possess.

Once per scene, reroll one failed roll that directly uses the active Former-Life Memory. You must use the new result.

### Wheel Refuses the End

**Canonical ID:** `insight.wheel-refuses-the-end`

**Prerequisite:** Samsara-Wheel Cultivator or reincarnation Secret authority, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you die and your soul remains capable of entering Samsara, create a Samsara Anchor at your place of death.

For the next 1 minute:

- Your soul cannot be involuntarily consumed or redirected by an effect whose Source CL is lower than yours.
- An ally may touch the Anchor and spend an Action to preserve it.
- A resurrection, soul-return, or Samsara feature may originate from the Anchor.

When the Anchor is created, you may return through it with 1 Hit Point at the start of your next turn.

After doing so, mark this Insight **Wheel Exhausted**. It cannot create another returning Anchor until one of the following occurs:

- You complete a successful Realm breakthrough.
- You complete a 7-day reincarnation rite using the rare materials required by your Samsara source.
- You permanently reduce your maximum Qi by your Proficiency Bonus.

A permanent maximum-Qi reduction paid this way can be repaired only by a feature explicitly capable of restoring permanent cultivation sacrifice.

This does not overcome conceptual erasure, a severed Samsara connection, destruction of the soul, or an effect of superior authority without a successful Source CL contest.

### Karmic Ledger Within the Core

**Canonical ID:** `insight.karmic-ledger-within-the-core`

**Prerequisite:** Karma-Thread Cultivator, Oath-Ledger Cultivator with Karma access, or genuine Karma Secret authority; CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

You may hold Karmic Marks equal to your Proficiency Bonus.

Gain one Mark when a creature you can perceive during a qualifying scene:

- Directly harms you or an ally.
- Saves your life.
- Breaks an oath to you.
- Pays a genuine debt.
- Accepts a major sacrifice from you.

The event must carry actual consequence; staged exchanges and closed loops do not qualify.

Spend one Mark when interacting with that creature to choose one:

- Add `2d8` damage or healing to one result.
- Move it or an ally 10 feet through causal redirection.
- Add or subtract `1d4` from one saving throw.
- Reveal the direction of the creature on the same plane.
- Force an immediate Cultivation Check against one concealed oath, debt, or Karmic bond.

Marks persist until settled, purified, transferred, or consumed.

### Conceptual Edge

**Canonical ID:** `insight.conceptual-edge`

**Prerequisite:** Heaven-Splitting Conceptual Severance or equivalent Secret authority, CL16+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use a feature that severs, cuts, suppresses, or separates a relationship, spend 3 additional Qi to name one eligible conceptual connection:

- Weapon from owner.
- Technique from source.
- Soul from body.
- Name from authority.
- Formation from Anchor.
- Qi from meridian.
- Memory from identity.
- Oath from beneficiary.
- Regeneration from injury.

Against a target whose Source CL is lower than yours, the connection is suppressed until the scene ends unless the feature already grants a longer result.

Against an equal or higher Source CL, make a Cultivation Check against its save DC. On success, suppress it until the end of your next turn.

This Insight cannot create a permanent severance unless the underlying Secret feature already authorizes permanence and its price is paid.

### Secret Authority Contention

**Canonical ID:** `insight.secret-authority-contention`

**Prerequisite:** One Secret Law, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When one of your Secret effects directly contests another Secret, artifact, Immortal, or conceptual authority, add your Proficiency Bonus to the first Cultivation Check you make in that contest.

If the check still fails, choose one concession instead of total failure when logically possible:

- Reduce the opposing effect's duration by one round.
- Preserve one Anchor from destruction at 1 Hit Point.
- Prevent one permanent consequence from becoming irreversible until the scene ends.
- Learn the opposing authority's exact Source CL and one recovery condition.
- Move 10 feet without provoking Opportunity Attacks before the consequence resolves.

A concession cannot negate a price already willingly paid or recreate something conceptually erased.

## Qi — Tribulation Insights

### Lightning-Scarred Meridians

**Canonical ID:** `insight.lightning-scarred-meridians`

**Prerequisite:** Survive a Lightning or Heaven-Thunder Tribulation

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Lightning damage.

Once per round, after a qualifying hostile source deals Lightning damage to you, regain 1 Qi.

If another feature grants Lightning Resistance, reduce the first Lightning damage packet each round by your Proficiency Bonus instead.

Your meridians remain visibly scarred to Qi Sensing and may react to approaching tribulation weather.

### Furnace-Core Survivor

**Canonical ID:** `insight.furnace-core-survivor`

**Prerequisite:** Survive a Fire, Magma, Ash, or Meridian-Flame Tribulation

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Fire damage.

Once per round when you deal Fire, Magma, or Ash-tagged damage after having taken damage during the current round, gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.

If another feature grants Fire Resistance, reduce the first Fire damage packet each round by your Proficiency Bonus instead.

### Frozen Golden Core

**Canonical ID:** `insight.frozen-golden-core`

**Prerequisite:** Survive a Cold, Yin, Ice, or Stillness Tribulation

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Cold damage.

Once per turn, when a creature fails a saving throw against your Cold-, Yin-, Ice-, or Stillness-tagged feature, reduce its Speed by an additional 10 feet until the start of your next turn.

If the feature already reduces Speed to 0, the creature also cannot take Reactions until the start of its next turn.

### Storm-Eye Meditation

**Canonical ID:** `insight.storm-eye-meditation`

**Prerequisite:** Survive a Weather, Air, Wind, Storm, or Lightning Tribulation

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Being knocked Prone.
- Wind.
- Forced movement.
- Weather-based disorientation.

Once per turn, after spending Qi on a movement feature, move an additional 10 feet without provoking Opportunity Attacks.

This movement may cross open air but must end in a legal supported space unless another feature supports you.

### Mountain-Core Stability

**Canonical ID:** `insight.mountain-core-stability`

**Prerequisite:** Survive an Earth, Gravity, Mountain, pressure, or crushing Tribulation

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Forced movement.
- Being knocked Prone.
- Unwilling teleportation.
- Crushing pressure.

Reduce all forced movement affecting you by 10 feet.

Once per round, when an effect whose Source CL is lower than yours would move you, reduce that movement to 0 instead.

### Heart-Demon Vanquisher

**Canonical ID:** `insight.heart-demon-vanquisher`

**Prerequisite:** Survive a Heart-Demon, mental, Dream, Illusion, emotional, or identity Tribulation

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Charmed.
- Frightened.
- Dreams.
- Illusions.
- Emotional manipulation.
- Forced identity alteration.

**Reaction**  
**Trigger:** You fail one of those saving throws.  
**Cost:** 2 Qi

Reroll it and use the new result.

The same saving throw cannot be rerolled more than once.

### Formation-Collapse Survivor

**Canonical ID:** `insight.formation-collapse-survivor`

**Prerequisite:** Survive a Formation collapse, spatial collapse, teleportation disaster, or prison Formation Tribulation

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on checks and saving throws to:

- Escape Formations.
- Resist unwilling teleportation.
- Locate spatial faults.
- Survive collapsing pocket spaces.

When trapped, sealed, or spatially isolated, you immediately learn the direction of the nearest vulnerable Anchor, boundary fault, exit route, or unstable spatial seam within 300 feet, if one exists.

Once per scene, spend 3 Qi to move up to 15 feet through one Formation boundary or spatial seam whose Source CL is lower than yours.

Against an equal or higher Source CL, make a Cultivation Check against its save DC.

### Sword-Tribulation Survivor

**Canonical ID:** `insight.sword-tribulation-survivor`

**Prerequisite:** Survive a Sword, Saber, Blade, Weapon, or Killing-Intent Tribulation

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

While wielding or controlling a named weapon:

- Gain Advantage on saving throws against Frightened and weapon-disarming effects.
- A hostile effect whose Source CL is lower than yours cannot permanently sever your bond to that weapon.
- Once per scene, activate one known weapon field, weapon stance, or weapon Domain-style feature without paying its base Qi cost. Optional surcharges and non-Qi costs remain.

This does not grant a weapon Sphere or proficiency.

### Twice-Tribulated

**Canonical ID:** `insight.twice-tribulated`

**Prerequisite:** Survive two different Realm Tribulations

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase maximum Hit Points by 10.

Gain +1 on Cultivation Checks made during breakthroughs, Tribulations, and attempts to stabilize Realm damage.

When a Tribulation begins, gain Temporary Hit Points equal to `2 × your Proficiency Bonus` and regain Qi equal to your Proficiency Bonus.

These benefits occur once per Tribulation event, not once per phase.

### Heaven's Scar

**Canonical ID:** `insight.heaven-s-scar`

**Prerequisite:** Survive an extraordinary, unique, Secret, Immortal, or Heaven-recognized Tribulation and record the Tribulation's Source CL and authority

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Scar expression that directly matches the recorded Tribulation:

1. **Resistant Scar.** Gain Resistance to one damage type dealt by the Tribulation. Once per round after a qualifying hostile source deals that type to you, gain Temporary Hit Points equal to your Proficiency Bonus.
2. **Unbowed Scar.** Gain Advantage on saving throws against one named category of suppression used by the Tribulation.
3. **Scar-Step.** Once during each of your turns after you spend Qi, move 10 feet without provoking Opportunity Attacks.
4. **Heaven-Refusing Scar.** Once per scene, when a lower-Source-CL effect would forcibly transform, banish, possess, or kill you, make a Cultivation Check against its save DC. On a success, the effect fails against you.
5. **Witness Scar.** You can perceive one specific heavenly, spatial, karmic, or elemental phenomenon demonstrated by the Tribulation within 1 mile when it is not concealed by a higher-Source-CL effect.
6. **Matching Feature Scar.** Choose one printed feature from a Tribulation Subpath you possess. Increase one printed once-per-scene use by one, or improve one numerical result by your Proficiency Bonus. Record the exact feature and improvement when this Insight is gained.

Record the Scar's visible sign, mechanical tag, Source CL, expression, and any ongoing price printed by the Tribulation source. No unlisted custom expression is available without a separate published record.

# 04. Body Refining Insights

## Body — General Body Refining Insights

### Mountain-Forged Frame

**Canonical ID:** `insight.mountain-forged-frame`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Gain Proficiency in Athletics. If you already have Athletics Proficiency, instead gain a +2 Insight bonus to Athletics checks. This bonus does not count as a second Proficiency and does not multiply with Expertise.

Immediately after Stamina Guard resolves, you gain Advantage on the next saving throw or ability check you make before the start of your next turn to resist being pushed, pulled, knocked Prone, Grappled, or Restrained. The benefit ends after one qualifying roll.

### Meridian-Breath Discipline

**Canonical ID:** `insight.meridian-breath-discipline`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You have Advantage on Constitution saving throws caused by suffocation, smoke, altitude, inhaled hazards, or environmental pressure, and you can hold your breath for 1 hour.

**Breath Recovery — Once per scene.** Immediately after you use Stomping Step and its movement or Disengage benefit resolves, regain 1 Stamina, not above your maximum. An invalid or prevented Stomping Step does not trigger this recovery.

### Iron-Blood Circulation

**Canonical ID:** `insight.iron-blood-circulation`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You have Advantage on saving throws against Bleeding, Poison, Disease, and Exhaustion caused by physical injury.

**Blood-Circulation Procedure.** After at least 10 uninterrupted minutes of breathing, pressure-point work, bandaging, or medicinal circulation, regain Hit Points equal to `2 × your Proficiency Bonus`. You can benefit from this procedure once between Full Cultivation Sessions. It does not remove an Injury, restore missing anatomy, or replace required treatment.

### Living Siege Engine

**Canonical ID:** `insight.living-siege-engine`

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Your unarmed strikes deal triple damage, rather than double damage, to unattended ordinary objects, structures, vehicles, temporary barriers, Formation Anchors, and defined terrain sections. Against those targets, ignore the first 10 points of ordinary hardness or damage threshold.

This Insight does not bypass an Artifact, Immortal material, Secret protection, world-law barrier, explicit indestructibility, or a target whose rule prohibits structural multipliers.

### Brutal Momentum

**Canonical ID:** `insight.brutal-momentum`

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Trigger — Once per turn:** You push a hostile creature at least 10 feet, knock a hostile creature Prone, reduce a hostile creature to 0 Hit Points, break an object or structure with a complete AC and Hit Point record, or one that controls a current scene objective, destroy a barrier or Formation Anchor, or escape a hostile Grapple or Restrained effect.

After the triggering event fully resolves, move up to 10 feet without provoking Opportunity Attacks. This is granted movement; it requires a legal destination and cannot pass through a barrier or occupied space unless another rule permits it. Repeatedly breaking trivial objects or cooperating with allies does not qualify.

### Unyielding Grip

**Canonical ID:** `insight.unyielding-grip`

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

A creature Grappled by you has Disadvantage on checks or saving throws it makes to escape that Grapple.

Once per turn, when a creature fails a roll to escape your Grapple, it takes Bludgeoning damage equal to your Proficiency Bonus. This damage is attributed to you but is not an attack and cannot trigger itself.

### Tempered Reflexes

**Canonical ID:** `insight.tempered-reflexes`

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Reflexive Reversal — Once per scene:** When you fail a Dexterity saving throw, reroll it and use the new result. A die cannot be rerolled more than once by this Insight.

After you use Stomping Step to Disengage, you have Advantage on the next Dexterity saving throw you make before the start of your next turn. This Advantage may apply to the reroll if its timing is legal.

### Refined Natural Weapon

**Canonical ID:** `insight.refined-natural-weapon`

**Prerequisite:** Body Refining, CL4+

**Repeatable:** Multiple; choose a different bodily weapon each time

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one recorded bodily weapon and choose Bludgeoning, Piercing, or Slashing damage. That bodily weapon is a natural weapon and may be used for Iron Fist attacks. Record its anatomical structure and whether an Injury to that structure disables it.

Once per turn when you hit with the chosen bodily weapon, choose one:

- deal additional damage of the weapon's selected type equal to your Proficiency Bonus;
- push the target 5 feet;
- prevent the target from taking Reactions until the start of its next turn; or
- gain Advantage on your next Grapple or Shove roll against that target before the end of the current turn.

Choose only one option for one hit. The additional damage is part of the hit and cannot be delivered again by copying the same attack.

### Internal Weapon Scripture

**Canonical ID:** `insight.internal-weapon-scripture`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one printed weapon group or one recorded bodily-weapon tradition. You may use Constitution instead of Strength or Dexterity for attack and damage rolls with a weapon in that group or tradition.

At CL5, those attacks count as magical and cultivation-powered for overcoming ordinary Resistance. At CL17, Heavenly Fist also causes them to count as adamantine and grants its other printed benefits.

This Insight grants no weapon Proficiency, Sphere, extra attack, reach, or damage die. If the selected group is too broad to identify mechanically, record the exact weapons included when the Insight is gained.

### Refined Golden Bell

**Canonical ID:** `insight.refined-golden-bell`

**Prerequisite:** Golden Bell Circulation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Whenever you activate Golden Bell Circulation, choose one refinement for that activation. It lasts until that activation ends:

- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`;
- gain Advantage on all checks and saving throws against forced movement and being knocked Prone;
- gain Resistance to Force damage; or
- reduce the first damage packet applied to you during each round by your Proficiency Bonus.

The last reduction resolves in the normal damage-ordering procedure after percentage modifiers and before other flat reductions unless a rule states otherwise. Reactivating Golden Bell Circulation replaces the selected refinement.

### Blood-Furnace Heart

**Canonical ID:** `insight.blood-furnace-heart`

**Prerequisite:** Blood Pump, CL16+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When Blood Pump successfully replaces a reduction to 0 Hit Points, choose one benefit after you are set to 1 Hit Point:

- move up to 10 feet without provoking Opportunity Attacks;
- end one ordinary Frightened condition affecting you;
- end one ordinary Grappled or Restrained condition affecting you;
- regain Stamina equal to your Proficiency Bonus, not above your maximum; or
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.

An equal- or higher-Source-CL effect that explicitly prevents the chosen removal is not ended. Movement requires a legal destination.

### Heavenly Meridian Reconstruction

**Canonical ID:** `insight.heavenly-meridian-reconstruction`

**Prerequisite:** Body Refining, CL16+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When you complete a Full Cultivation Session, you may also complete one reconstruction treatment using Body Refining Shared Procedures R1.

- Automatically remove one Tier I ordinary lasting physical Injury whose Source CL is no higher than your Body Refining Source CL.
- For a Tier II Hidden Injury, you may make its treatment check as part of the session and have Advantage if it was already diagnosed.
- A Tier III crippled structure or Tier IV missing limb or organ still requires its printed Reconstruction Progress, project time, a treatment environment meeting the requirements of Body Refining Shared Procedures R1, medicine, ritual aid, and required components. Your personal work counts as a valid Body Refining treatment source.

This Insight cannot automatically reverse Tier V erasure, divine or Immortal authority, Secret effects, Artifacts, soul destruction, heavenly punishment, Foundation destruction, or an effect that expressly requires a breakthrough or story-scale cure.

## Body — Internalizing Power Spheres

### Internalized Sphere Insight

**Canonical ID:** `insight.internalized-sphere-insight`

**Prerequisite:** Body Refining, access to one Power Sphere, CL4+

**Repeatable:** Multiple; choose a different Power Sphere each time

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for the chosen internalized Sphere.

Choose one Power Sphere to which you have legal access. You may learn and use that Sphere through Body Refining, using Constitution as its key ability and Stamina as its Cultivation Point resource.

Record the bodily medium through which the Sphere functions: anatomy, breath, blood, marrow, organ furnace, scars, natural weapon, integrated weapon, or another explicit bodily structure. The Sphere uses Body Refining Source CL when used through this Insight.

If this is a new Sphere for you, gain the normal free talent granted whenever a character learns a new Sphere. This Insight does not grant every talent, waive Secret or inherited access, remove printed costs or actions, or authorize external projection beyond the Sphere and Body Refining rules.

### Deep Internalization

**Canonical ID:** `insight.deep-internalization`

**Prerequisite:** Internalized Sphere Insight, CL8+

**Repeatable:** Multiple; choose a different internalized Sphere each time

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one Sphere internalized through Internalized Sphere Insight. Once per turn when you activate one talent from that Sphere and it successfully resolves, choose one:

- reduce the Stamina actually paid by 1, minimum 1;
- increase one forced-movement distance produced by the activation by 5 feet;
- gain Temporary Hit Points equal to your Proficiency Bonus;
- move 5 feet without provoking Opportunity Attacks; or
- gain Advantage on the next saving throw you make before the start of your next turn against one damage type or condition produced by that activation.

Choose after legal targets are declared but before dice are rolled. One activation receives one benefit from this Insight. A cost reduction cannot stack with another reduction unless a rule explicitly allows it.

### Embodied Domain

**Canonical ID:** `insight.embodied-domain`

**Prerequisite:** Internalized Sphere Insight, access to one Domain talent, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When you activate a Domain belonging to an internalized Sphere, choose one bodily manifestation for that activation. It lasts while the Domain remains active:

- +1 AC;
- Speed increases by 10 feet;
- Advantage on Strength saving throws;
- Advantage on Constitution saving throws;
- Resistance to one damage type the Domain itself can deal;
- ignore difficult terrain created by that Domain; or
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus` when the Domain begins.

Only one manifestation from this Insight applies to a Domain activation. The Temporary Hit Points are gained once, not each round. Domain suppression also suppresses the manifestation.

### Dual-Body Synthesis

**Canonical ID:** `insight.dual-body-synthesis`

**Prerequisite:** Two Internalized Sphere Insights, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose two different internalized Spheres and record one physical synthesis joining them.

Once per turn, after you successfully resolve a talent from one Sphere in the pair, the next talent you activate from the other Sphere before the end of your next turn costs 1 less Stamina, minimum 1.

You can hold only one pending reduction. Triggering the synthesis again replaces the pending reduction and its expiration. It cannot trigger from a refunded or invalid activation, cannot reduce a cost below 1, and cannot create a closed resource loop. You may maintain only one Dual-Body Synthesis unless another rule explicitly permits more.

## Body — Common Might-Sphere Insights

### Brute-Body Adept

**Canonical ID:** `insight.brute-body-adept`

**Prerequisite:** Brute Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Once per turn when you activate a Brute talent, choose one benefit for that activation:

- count as one size larger for one Grapple or Shove resolved by the talent;
- add your Constitution modifier to one Strength check made as part of the talent;
- increase one push produced by the talent by 5 feet; or
- gain Temporary Hit Points equal to your Proficiency Bonus after the talent resolves.

One roll cannot receive the Constitution modifier more than once, and the size increase does not alter occupied space or reach.

### Guardian-Body Adept

**Canonical ID:** `insight.guardian-body-adept`

**Prerequisite:** Guardian Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When a Guardian talent legally causes you to use Stamina Guard to reduce damage taken by an ally, roll one additional Stamina Guard die and discard the lowest die before totaling the reduction.

**Interposed Guard — Once per scene:** When an ally within 5 feet would take damage and a Guardian talent makes that ally a legal target for your Stamina Guard, you may use Stamina Guard without spending your Reaction. You still pay Stamina and follow the normal damage-ordering procedure. This does not grant a second Stamina Guard against the same packet.

### Flowing-River Adept

**Canonical ID:** `insight.flowing-river-adept`

**Prerequisite:** Flowing River Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Once per turn, after you successfully redirect an attack, push, Grapple, or movement effect through a Flowing River talent, move 5 feet without provoking Opportunity Attacks. Resolve the redirection first. The movement requires a legal destination.

After you use Stomping Step to Disengage, you have Advantage on the next Flowing River Cultivation Check you make before the end of the current turn.

### Wrestling-Body Adept

**Canonical ID:** `insight.wrestling-body-adept`

**Prerequisite:** Wrestling Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You count as one size larger for Grapple eligibility, carrying a Grappled creature, and Wrestling talent size comparisons. This does not change your occupied space or reach.

Once per turn, when you successfully Grapple, throw, or pin a hostile creature through a Wrestling talent or the normal Grapple rules, deal Bludgeoning damage equal to your Proficiency Bonus after the maneuver resolves. One maneuver triggers this damage once.

### Reeling-Immortal Adept

**Canonical ID:** `insight.reeling-immortal-adept`

**Prerequisite:** Reeling Immortal Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Standing from Prone costs you 0 movement.

Once per turn, immediately after you willingly become Prone, move up to 5 feet without provoking Opportunity Attacks and gain +1 AC until the start of your next turn. This movement does not stand you up, requires a legal destination, and does not trigger when another creature or effect knocks you Prone.

### Spear-Body Adept

**Canonical ID:** `insight.spear-body-adept`

**Prerequisite:** Spear Sphere, proficiency with at least one spear-like weapon, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one spear-like weapon with which you are proficient. You may use Constitution for attack and damage rolls with that weapon.

For Opportunity Attacks triggered by a creature entering your reach, treat your reach with the chosen weapon as 5 feet greater. This does not increase your reach for normal attacks or other Reactions.

Once per turn when you hit a creature with such an entering-reach Opportunity Attack, reduce its Speed by 5 feet until the start of its next turn. Multiple applications refresh rather than stack.

### Monkey-Body Adept

**Canonical ID:** `insight.monkey-body-adept`

**Prerequisite:** Monkey Style Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Gain a Climb Speed equal to your walking Speed and Advantage on Acrobatics checks involving climbing, swinging, vaulting, or balancing. You may use Stomping Step while climbing if you have a legal surface or support for its movement.

Once per turn, after your elevation changes by at least 5 feet through voluntary movement, your next unarmed strike before the end of the turn deals additional damage equal to your Proficiency Bonus. Falling involuntarily does not qualify unless you regain control before the attack.

## Body — Common Hybrid-Sphere Insights

### Blood-Meridian Refinement

**Canonical ID:** `insight.blood-meridian-refinement`

**Prerequisite:** Blood Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Once per turn when you actually spend Stamina on a Blood talent that successfully resolves, choose one:

- gain Temporary Hit Points equal to your Proficiency Bonus;
- move 5 feet without provoking Opportunity Attacks;
- gain Advantage on your next saving throw before the start of your next turn against Bleeding, Poison, or Disease; or
- reduce one Hit Point cost you willingly pay as part of that activation by your Proficiency Bonus, minimum 1.

The Hit Point reduction applies only to a printed self-cost, not incoming damage, maximum-Hit-Point loss, or a sacrifice that says it cannot be reduced.

### Bone-Tempering Insight

**Canonical ID:** `insight.bone-tempering-insight`

**Prerequisite:** Bones Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You have Advantage on saving throws against being knocked Prone, forced transformation, bone-breaking effects, and physical paralysis.

Once per turn, when a Bones talent creates one barrier, weapon, armor Asset, or manifestation with Hit Points, increase both its current and maximum Hit Points by your Proficiency Bonus. If one activation creates several objects, choose one. This increase ends with the created object and cannot be repeatedly harvested through recreation.

### Flesh-Reconstruction Insight

**Canonical ID:** `insight.flesh-reconstruction-insight`

**Prerequisite:** Flesh Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Once per turn, when a Flesh talent restores Hit Points to you or another creature, increase that healing by your Proficiency Bonus. This applies after the talent's normal dice and modifiers and does not multiply across several targets unless the talent rolls healing separately for each target.

You have Advantage on saving throws against bodily corruption, mutation, forced transformation, and Disease. Injury and reconstruction still use Body Refining Shared Procedures R1.

### Sword-Bone Insight

**Canonical ID:** `insight.sword-bone-insight`

**Prerequisite:** Sword Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Your Iron Fist attacks may deal Slashing damage.

Once per turn when you hit with an unarmed strike or sword-like weapon, choose one:

- move 5 feet without provoking Opportunity Attacks;
- reduce the target's Speed by 5 feet until the start of its next turn;
- prevent the target from taking Reactions until the start of its next turn; or
- deal additional Slashing damage equal to your Proficiency Bonus.

Choose one option for one hit. The additional damage is part of that hit.

### Transformation-Stability Insight

**Canonical ID:** `insight.transformation-stability-insight`

**Prerequisite:** Transformation Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When you activate a self-targeting Transformation talent, gain Temporary Hit Points equal to `2 × your Proficiency Bonus`. Temporary Hit Points from this Insight do not stack with themselves.

While that transformation lasts, you have Advantage on saving throws and checks against involuntary transformation, form replacement, or forced reversion. You retain normal speech, memory, mental ability scores, and decision-making unless you choose otherwise or the specific transformation explicitly states that one of those faculties changes.

This Insight does not create additional limbs, attacks, equipment slots, or movement modes beyond the transformation's printed record.

## Body — Advanced Subpath Insights

### Giant-Marrow Refinement

**Canonical ID:** `insight.giant-marrow-refinement`

**Prerequisite:** Flesh Crucible, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

While Titan's Frame is active, you count as one additional size larger for carrying, dragging, lifting, Grapple eligibility, and Shove eligibility. This functional size does not change occupied space, reach, or actual size.

You have Advantage on saving throws against forced transformation. Once per turn, when you push a creature or object, increase that push by 5 feet.

### Bell-Skin Discipline

**Canonical ID:** `insight.bell-skin-discipline`

**Prerequisite:** Iron Shirt, CL8+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When Stamina Guard reduces a damage packet to 0, gain +1 AC until the start of your next turn.

You also regain 1 Stamina, not above your maximum. You can regain Stamina from this Insight once per round. If several packets are reduced to 0 in the same round, the AC benefit refreshes but the Stamina recovery does not repeat.

### Formation-Smasher Palm

**Canonical ID:** `insight.formation-smasher-palm`

**Prerequisite:** Stone Fist, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Your unarmed strikes deal triple damage to temporary barriers and Formation Anchors instead of any lower structural multiplier.

**Formation-Breaking Blow — Once per scene:** When you hit a temporary barrier or Formation Anchor with an unarmed strike, ignore ordinary hardness and damage threshold for that hit and deal additional damage equal to `3 × your Cultivation Level`. This does not bypass an Artifact, Immortal material, Secret immunity, or explicit indestructibility.

### Earth-Ring Discipline

**Canonical ID:** `insight.earth-ring-discipline`

**Prerequisite:** Sumo, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

While Rooted Stance is active, spaces within 5 feet of you are difficult terrain for hostile creatures. You have Advantage on saving throws and Cultivation Checks against hostile teleportation or spatial displacement.

Once per turn, when you push a creature into a wall, barrier, occupied space, or other solid obstruction and the push ends because of that obstruction, deal additional Bludgeoning damage equal to your Proficiency Bonus. This does not create a separate Injury.

### Wine-Gourd Immortal

**Canonical ID:** `insight.wine-gourd-immortal`

**Prerequisite:** Drunken Fist, CL8+

**Ability Increase (Level Selection):** Increase your Constitution or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Shared Draught Procedure.** After 10 uninterrupted minutes sharing wine, tea, medicine, or another ritual drink with at least one willing creature, regain 1 Stamina, not above your maximum. You can benefit from this procedure once per scene. The drink need not be alcoholic and cannot be repeatedly sipped to trigger the recovery.

Once per round, after a creature misses you with an attack, move 5 feet without provoking Opportunity Attacks. This movement requires a legal destination and resolves after the attack.

### Meridian-Pincer Method

**Canonical ID:** `insight.meridian-pincer-method`

**Prerequisite:** Mantis Style, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When a creature fails its saving throw against Joint Lock, its Speed becomes 0 and it has Disadvantage on Concentration saving throws until the start of your next turn.

This is temporary functional impairment, not anatomical severance or a lasting Injury. A creature immune to the underlying Joint Lock remains immune.

### Returning-Tide Body

**Canonical ID:** `insight.returning-tide-body`

**Prerequisite:** Jujutsu, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Returning Tide — Once per scene:** Immediately after you successfully redirect or throw a hostile creature through a Jujutsu feature, regain 1 Stamina, move up to 5 feet without provoking Opportunity Attacks, and gain Advantage on the next Grapple roll you make before the end of your next turn.

Resolve the throw or redirection first. Movement requires a legal destination.

### Ironwood Staff Scripture

**Canonical ID:** `insight.ironwood-staff-scripture`

**Prerequisite:** Bojutsu and Wood or Metal Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose the staff recorded by your Bojutsu weapon-integration feature. It gains a +1 bonus to attack and damage rolls, has Advantage on checks or saving throws against being destroyed or Disarmed, and counts as Wood or Metal, chosen when this Insight is gained, for relevant Sphere and material interactions.

This Insight does not duplicate the staff, grant a second material at the same time, or raise a total item enhancement above a printed cap. Change the chosen material only through a Full Cultivation Session and a 1-hour reforging or regrowth procedure using Blacksmith, Wood, Life, or Body Refining tools that can work the chosen material.

### One-Breath Discipline

**Canonical ID:** `insight.one-breath-discipline`

**Prerequisite:** Karate, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

If you voluntarily move no more than 5 feet during your turn, the first unarmed strike you hit with before the end of that turn deals additional damage equal to your Constitution modifier and grants +1 AC until the start of your next turn.

Forced movement does not count against the 5-foot limit. Teleportation, granted movement, standing from Prone, and other voluntary relocation do count. The damage applies once per turn.

### Ten-Thousand-Step Pilgrimage

**Canonical ID:** `insight.ten-thousand-step-pilgrimage`

**Prerequisite:** Yamabushi, CL8+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When you complete a Full Cultivation Session in a natural environment, gain the following benefits until you complete your next Full Cultivation Session:

- Advantage on Survival checks;
- ignore nonmagical difficult terrain; and
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus` when the session ends.

The Temporary Hit Points do not refresh each scene and do not stack with themselves. A constructed garden, ship, city park, or artificial cave qualifies only if it provides a genuine natural environment for the entire session.

### Graveyard Sovereign

**Canonical ID:** `insight.graveyard-sovereign`

**Prerequisite:** Bone Monarch and Bones or Death Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Your Bone Guard's maximum and current Hit Points increase by `2 × your Cultivation Level`, and it gains Resistance to Necrotic damage. It may move through allied creatures' spaces but cannot end there.

The Bone Guard gains the following legal command options in addition to its normal actions: attempt a Grapple, attempt a Shove, guard one doorway or threshold, or carry one willing creature it has capacity to carry. These commands use the Bone Guard's normal command economy and do not grant an additional action.

### Sword-Line Meridian

**Canonical ID:** `insight.sword-line-meridian`

**Prerequisite:** Kensei and Sword Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Once per turn, when you voluntarily move at least 10 feet immediately before an unarmed or sword-like attack and hit, deal additional damage equal to your Proficiency Bonus. After the attack resolves, move up to 5 feet without provoking Opportunity Attacks.

Teleportation does not satisfy the 10-foot movement requirement unless a Source Rule counts it as traveled movement. The post-attack movement requires a legal destination.

### Breathless Heart Method

**Canonical ID:** `insight.breathless-heart-method`

**Prerequisite:** Shinobi, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

While you remain motionless and take no Action, Bonus Action, or Reaction that creates obvious sound or movement, creatures have Disadvantage on checks to detect you, ordinary heartbeat detection fails, and you can hold your breath indefinitely. The benefit ends immediately when you move or take a disallowed action.

**Silent Opening — Once per scene:** When you roll Initiative while Hidden from every hostile creature that can perceive your space, regain 2 Stamina, not above your maximum.

### Divine Statue Meditation

**Canonical ID:** `insight.divine-statue-meditation`

**Prerequisite:** Gōruden, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Divine Statue Procedure.** Spend 10 uninterrupted minutes in a statue-like posture. At the end, choose one:

- regain 2 Stamina, not above your maximum;
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`; or
- gain Advantage on the next saving throw you make before the end of the next scene against Frightened, Disease, Poison, or Necrotic damage.

You can benefit from this procedure once per scene. Taking damage, moving, or performing another cultivation activation interrupts it.

### Dragon-Pearl Heart

**Canonical ID:** `insight.dragon-pearl-heart`

**Prerequisite:** Ryūjin, CL12+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Dragon-Pearl Release — Once per scene:** Immediately after you deal Lightning or Thunder damage with a Ryūjin or Body Refining feature, choose one:

- regain 2 Stamina, not above your maximum;
- gain a Fly Speed of 30 feet until the end of the current turn; or
- push one creature damaged by the triggering effect 5 feet directly away from you.

The push follows normal forced-movement and Source CL procedures. The flight does not prevent falling after the turn ends unless another effect supports you.

### Empty-Meridian Refinement

**Canonical ID:** `insight.empty-meridian-refinement`

**Prerequisite:** Kūkishin, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Empty Meridian — Once per scene:** When you activate Phase Flesh, reduce the Stamina cost of that activation to 0, move up to 10 feet without provoking Opportunity Attacks after it resolves, and gain Advantage on the next attack roll you make before the end of your next turn.

The movement uses Phase Flesh's legal passage permissions but must end in a legal unoccupied space. This Insight does not waive phasing backlash or higher-authority barriers.

### Crimson Restraint Broken

**Canonical ID:** `insight.crimson-restraint-broken`

**Prerequisite:** Oni Blood, Demonic Cultivation Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Forbidden Insight.** When you knowingly choose to fail the control procedure required by Blood Hunger, gain the following benefits until the end of your next turn:

- Advantage on your next unarmed attack roll;
- that hit deals additional Necrotic damage equal to your Proficiency Bonus; and
- immediately move up to 10 feet toward a hostile creature by the safest legal route.

After the scene ends, make a Wisdom saving throw against your own Cultivation Save DC. On a failure, gain 1 Exhaustion. This save cannot be voluntarily failed or rerolled by the same effect that caused Blood Hunger.

### Ashura Furnace

**Canonical ID:** `insight.ashura-furnace`

**Prerequisite:** Jigoku and Fire, Ash, or Demonic Cultivation Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Forbidden Insight.** While you are below half your maximum Hit Points:

- once per turn, one unarmed strike that hits deals additional Fire or Necrotic damage equal to your Proficiency Bonus, chosen for that hit;
- you ignore ordinary difficult terrain; and
- you have Advantage on saving throws against the Frightened condition.

The additional damage is part of the hit. An effect that conceals your current Hit Points does not prevent you from knowing whether this Insight is active.

# 05. Sphere and Discipline Insights

## Sphere — Air

### Cloud-Step Novice

**Canonical ID:** `insight.cloud-step-novice`

**Prerequisite:** Air sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Feather-Fall Breath on yourself, you may also move 10 feet horizontally before landing.

Once per scene, when you would fall after ending your turn in the air, you may delay the fall until the end of your next turn.

### Living Bellows Body

**Canonical ID:** `insight.living-bellows-body`

**Prerequisite:** Air Sphere, Body Refining, CL6+

**Ability Increase (Level Selection):** Increase your Constitution, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Bellows Refusal; normal Air Source CL for Air talents.

Your lungs and ribs can act as a temporary Air Source. When you create a Current centered on yourself, you may make it a Driving Current even if you are not Foundation Realm, but only until the start of your next turn.

**Bellows Refusal — Once per scene:** When you fail a saving throw against inhaled Poison, suffocation, smoke, bad air, or breath disruption, choose to succeed instead. This does not remove an ongoing source, restore a destroyed breath organ, or bypass an effect that explicitly cannot be resisted.

### Wind-Line Archer

**Canonical ID:** `insight.wind-line-archer`

**Prerequisite:** Air sphere, Sniper or Barrage sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you make a ranged weapon attack through one of your Air Currents, ignore Disadvantage from long range for that attack.

Once per turn, if the attack hits, you may move the target 5 feet in the direction of the Current if it is no more than one size larger than you.

### Four-Wind Adept

**Canonical ID:** `insight.four-wind-adept`

**Prerequisite:** Air sphere, Breath Beyond the Skin, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Gather Current, you may choose two Vectors instead of one. A creature or projectile can be affected by only one of those Vectors each time it enters the Current.

Once per scene, when you roll initiative, you may create one Light Current centered on yourself without using an action.

### Storm-Eye Disciple

**Canonical ID:** `insight.storm-eye-disciple`

**Prerequisite:** Air sphere, Court of the Four Winds, CL 12+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you activate Court of the Four Winds, choose one allied creature. That creature may ignore the first instance of Difficult Terrain created by your Air talents each round.

In addition, when a hostile creature fails a saving throw against one of your Air talents inside the court, you may move one Current 10 feet.

### Breath-Thread Listener

**Canonical ID:** `insight.breath-thread-listener`

**Prerequisite:** Air sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Use your Spirit Awakening CL for Breath Reading and the normal Air Source CL for Air talents.

You hear the spiritual thread carried by breath, speech, and suppressed panic.

You have Advantage on Wisdom (Insight) checks against a creature within 30 feet that you can hear breathing or speaking.

### Breath Reading

**Action Type:** No Action  
**Trigger:** A creature within 30 feet that you can hear knowingly speaks a false statement, begins an audible command or compulsion technique, or attempts to conceal immediate fear or panic  
**Limit:** Once per scene

Learn which one of the following states best describes the triggering breath:

- **Steady:** The creature's breath does not reveal deliberate falsehood, immediate panic, or coercive command pressure.
- **Strained:** The creature is afraid, under duress, injured, or suppressing panic.
- **False:** The spoken statement deliberately conflicts with what the creature presently believes. This does not detect omission, metaphor, mistake, or technically true misdirection.
- **Absent:** The creature has no living breath, is using an artificial voice, or is speaking through a body that does not breathe normally.
- **Spiritually Masked:** A cultivation effect is concealing or falsifying the breath-thread.

If a masking effect has lower Source CL than you, you identify both the underlying state and that it was masked. Otherwise, make a Spirit Awakening Cultivation Check against the masking effect's Cultivation Save DC. On a success, identify the underlying state. On a failure, learn only **Spiritually Masked**.

Breath Reading does not read thoughts, reveal the complete truth, identify an unknown technique by name, or force the creature to speak.

## Sphere — Alchemy

### Body as Cauldron

**Canonical ID:** `insight.body-as-cauldron`

**Prerequisite:** Body Refining, CL4+, Constitution 15+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Body-as-Cauldron Alchemy.

You may learn Alchemy despite it being a Restricted Power Sphere. If this is a new Sphere for you, gain the normal free talent granted when learning a new Sphere.

When using Alchemy through this Insight, use Constitution as the key ability and Stamina for its Cultivation Point costs. Your body is the cauldron, but you still require all printed ingredients, work time, tools or bodily substitutes, saturation checks, Impurity, and recipe access.

### Alchemical Prodigy

**Canonical ID:** `insight.alchemical-prodigy`

**Prerequisite:** Alchemy, CL 4+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once between Full Cultivation Sessions, when you successfully refine a Common or Uncommon recipe, you may create a second product of the same recipe.

You must provide ingredients for both products.

At CL 10, this Insight may affect Rare recipes.

### Alchemical Constitution

**Canonical ID:** `insight.alchemical-constitution`

**Prerequisite:** Alchemy or Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** The Source CL of the pill or Alchemy effect; Body Refining Source CL for your resistance to backlash.

You have Advantage on saving throws against Poison and alchemical backlash.

**Extra Assimilation — Once between Full Cultivation Sessions:** You may consume one additional Cultivation or Enhancement pill beyond your normal saturation allowance without making the Pill Saturation saving throw for that pill. You still gain 1 Pill Impurity and pay every other cost. This does not permit simultaneous incompatible pills or ignore a pill's explicit absolute limit.

### Pill Master’s Eyes

**Canonical ID:** `insight.pill-master-s-eyes`

**Prerequisite:** Alchemy, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You automatically identify Common and Uncommon pills, poisons, alchemical ingredients, and obvious alchemical contamination after 1 minute of study.

You have Advantage on checks to identify Rare or higher alchemical substances.

### Medicine Saint

**Canonical ID:** `insight.medicine-saint`

**Prerequisite:** Alchemy, CL 12+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you administer a Medicinal pill to a creature, you may do so as a Bonus Action.

If the pill restores HP, add your Alchemy key ability modifier to the healing.

The target gains Advantage on one Constitution saving throw it makes before the end of its next turn.

### Furnace-Tyrant’s Stomach

**Canonical ID:** `insight.furnace-tyrant-s-stomach`

**Prerequisite:** Alchemy, CL 12+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Resistance to Poison damage.

When you take Poison damage from your own Alchemy talent or product, reduce the damage by your Proficiency Bonus.

If you already have Resistance to Poison damage, gain Advantage on saving throws against the Poisoned condition.

### Pill Sovereign’s Ledger

**Canonical ID:** `insight.pill-sovereign-s-ledger`

**Prerequisite:** Alchemy, CL 12+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you invest at least 1,000 gp in ingredients during downtime, record one Ledger Credit.

You may hold Ledger Credits equal to your Proficiency Bonus.

When you fail an Alchemy Check, spend one Ledger Credit to reduce the failure margin by 2. If this changes a failure by more than 5 into a failure by 5 or less, create a Broken product instead of losing the ingredients.

Ledger Credits represent extra stabilizers, backup reagents, assistant labor, and redundant furnace preparation. They cannot turn a failed check into a success.

## Sphere — Axes

### Shieldhook Adept

**Canonical ID:** `insight.shieldhook-adept`

**Prerequisite:** Axes sphere, Shield-Catching Beard, CL 4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Shield-Catching Beard, you may choose to move the target's shield aside for one ally instead of yourself.

On a failed save, the chosen ally's next attack against the target before the start of your next turn ignores Shield AC.

On a successful save, the chosen ally's next attack before the end of your current turn ignores Shield AC.

### Logging Breath Body

**Canonical ID:** `insight.logging-breath-body`

**Prerequisite:** Axes Sphere, Body Refining, Work-Axe Eye, CL6+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Dexterity score by 1, to the maximum allowed by your current Realm.

**Source CL:** Axes Source CL for Hewing Strike; Body Refining Source CL for Rooted Hewing.

When you hit an unattended object or a creature bearing Bite with Hewing Strike, gain Temporary Hit Points equal to your Proficiency Bonus. These Temporary Hit Points do not stack with themselves.

**Rooted Hewing — Once per scene:** While wielding an axe, when you fail a Strength saving throw against being pushed, pulled, knocked Prone, or Disarmed, choose to succeed instead.

### Poleaxe Door-Guard

**Canonical ID:** `insight.poleaxe-door-guard`

**Prerequisite:** Axes sphere, Poleaxe Gate, CL 6+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

While wielding a Poleaxe-profile weapon, creatures provoke Opportunity Attacks from you when they move from a space within your reach to another space within your reach if they are bearing Bite from you.

If the opportunity attack hits, the creature's Speed becomes 0 until the end of the current turn.

### Red Execution Discipline

**Canonical ID:** `insight.red-execution-discipline`

**Prerequisite:** Axes sphere, Execution Mark, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When a creature bearing Execution Mark from you drops to 0 HP, teleports, or becomes Invisible before the mark ends, you may regain Martial Focus if it is absent.

In addition, once between Full Cultivation Sessions, when you hit a creature bearing Execution Mark with Headsman's Mandate or Rending Hew, you may reroll one damage die and use either result.

### Formation-Wedge Cutter

**Canonical ID:** `insight.formation-wedge-cutter`

**Prerequisite:** Axes sphere, Axe Bites the Formation, CL 12+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When you succeed on Axe Bites the Formation, you may choose one ally within 30 feet.

Before the start of your next turn, that ally may ignore the suppressed section, panel, or node for one movement, attack, or technique, provided the effect's scale allows a person-sized opening.

If you succeeded by 5 or more, two allies may benefit instead.

### Ceremonial Yue Bearer

**Canonical ID:** `insight.ceremonial-yue-bearer`

**Prerequisite:** Axes sphere, Mandate Axe Presence, CL12+, and Spirit Awakening, Warleader sphere, Sovereign Will, or another printed mandate doctrine

**Ability Increase (Level Selection):** Increase your Strength, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** The Source CL of Mandate Axe Presence.

When you make a public declaration through **Mandate Axe Presence**, name one lawful group, sect, clan, office, army, sworn band, protected settlement, or another recorded authority with defined membership and jurisdiction that you actually represent.

You have Advantage on the Axes Check if at least one listener satisfies either condition:

- **Recognized Authority:** The listener knows your office or affiliation, has been shown a genuine credential, standard, seal, witness, or insignia, or has previously seen that authority lawfully exercised.
- **Feared Consequences:** The listener reasonably believes the named authority can investigate, punish, protect, mobilize, or retaliate within the current situation.

### Dishonored Mandate

If you knowingly use this Insight to pronounce a materially false judgment and the falsehood is publicly exposed, you gain **Dishonored Mandate** and cannot benefit from this Insight.

Remove Dishonored Mandate by completing one public restitution scene that includes:

1. acknowledging or correcting the false judgment before the harmed party, represented group, or a recognized witness; and
2. completing one of the following: material compensation, an accepted office punishment, a formal apology and retraction, or a Karma or purification procedure that expressly settles the abuse.

A declaration made from incomplete information is not a false judgment unless you knowingly represented uncertain information as established fact.

## Sphere — Beauty

### Courtly Presentation

**Canonical ID:** `insight.courtly-presentation`

**Prerequisite:** Beauty sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Gain proficiency in one of Performance, Persuasion, Insight, or Deception. If you already have proficiency in the chosen skill, gain Expertise with that skill for checks involving etiquette, presentation, reputation, sincere confession, formal challenge, or public poise.

This Insight does not make a hostile creature friendly by itself.

### Poise-Tempered Presence

**Canonical ID:** `insight.poise-tempered-presence`

**Prerequisite:** Beauty sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Once per scene, when you succeed on a saving throw against being Charmed, Frightened, humiliated, magically compelled to lose face, or forced to kneel, bow, grovel, or flee, you may place one Beauty Mark on the source if the source is within 60 feet and can perceive you.

This mark lasts until the end of your next turn.

### Unbroken Grace

**Canonical ID:** `insight.unbroken-grace`

**Prerequisite:** Beauty sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When a creature succeeds on a saving throw against one of your Beauty talents, you may keep one existing Beauty Mark on that creature until the end of your next turn instead of losing it.

Use this Insight once per round.

### Blade-Hesitation Adept

**Canonical ID:** `insight.blade-hesitation-adept`

**Prerequisite:** Beauty sphere, Turn the Blade Aside or another Beauty reaction talent, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When a creature with your Beauty Mark misses you with an attack after one of your Beauty talents imposed Disadvantage, you may move 5 feet without provoking Opportunity Attacks from that creature.

This movement must preserve visible spatial causality; it is poise, footwork, or hesitation, not teleportation.

### Face Without Falsehood

**Canonical ID:** `insight.face-without-falsehood`

**Prerequisite:** Beauty sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When you reveal a painful truth, keep a vow, confess a real identity, accept blame, or refuse to beautify a lie, gain Advantage on the next Beauty check or Beauty saving throw DC contest you make before the end of the scene.

Once this benefit is used, you cannot use it again until you complete a Full Cultivation Session.

### Beauty-Script Custodian

**Canonical ID:** `insight.beauty-script-custodian`

**Prerequisite:** Beauty sphere and one of Formations, Talismans, Ink, Music, or Sect Stewardship sphere; CL10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

You may contribute presentation, costume, ritual posture, music, fragrance, calligraphy, rank tokens, banners, or ceremonial arrangement to a noncombat Formation, sect ceremony, oath scene, morale rite, diplomatic entrance, memorial, or performance project.

After contributing at least 1 hour during a project phase, choose one Project Contribution benefit from the central Insight execution definitions. A project phase can benefit from Beauty-Script Custodian once.

This Insight never bypasses consent, materials, work time, maintenance, Source CL, or a project's printed vulnerability.

## Sphere — Blacksmith

### External Hammer Breakthrough

**Canonical ID:** `insight.external-hammer-breakthrough`

**Prerequisite:** Blacksmith Sphere, Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for the projected Blacksmith talent.

You may learn one Projected Blacksmith talent for which you meet all prerequisites. When you use that talent through this Insight, its range is 15 feet or its printed shorter range. You must hold a hammer, tool, weapon, or anvil-token, and the workpiece must be visible and within line of effect.

The projection originates from your held implement or striking motion. This Insight does not grant broad Qi projection, affect an unseen workpiece, or waive materials, tools, time, or other Blacksmith requirements.

### Fire-Metal Furnace Understanding

**Canonical ID:** `insight.fire-metal-furnace-understanding`

**Prerequisite:** Blacksmith sphere, Metal sphere or Fire sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose Metal or Fire when you gain this Insight.

If you choose Metal, gain Advantage on one Blacksmith check per scene involving metal resonance, edge, armor, bell, chain, blade, or ore.

If you choose Fire, gain Advantage on one Blacksmith check per scene involving heat, refining, purifying, quenching, tempering, or furnace control.

If you later learn both Metal and Fire, use this Insight twice per scene, once for each category.

This is not a formal affinity system.

### Named Tool Custodian

**Canonical ID:** `insight.named-tool-custodian`

**Prerequisite:** Blacksmith sphere, Name the Purpose, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one personal tool, hammer, anvil, file, tongs, needle, chisel, whetstone, furnace plate, or similar implement.

While using that named tool:

gain Advantage on Read the Flaw once per scene;

the tool can hold one Forge Mark;

if the tool would be destroyed, reduce the damage to it by 5 x Proficiency Bonus once between Full Cultivation Sessions.

Replacing the named tool requires a short quest, inheritance, purchase, or 8 hours of personal work.

### Master of Repairs

**Canonical ID:** `insight.master-of-repairs`

**Prerequisite:** Blacksmith sphere, Close the Crack, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Close the Crack outside combat, repair two compatible damaged objects in the same scene instead of one.

When you use Close the Crack in combat, add an extra 1d6 to the object HP restored.

At CL 10+, increase the extra restoration to 2d6.

### Item-Spirit Midwife

**Canonical ID:** `insight.item-spirit-midwife`

**Prerequisite:** Blacksmith sphere, Spirit-Listening Tap, CL 10+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

When working on an item with an item spirit seed, you may spend 1 hour coaxing it.

Choose one:

calm a hostile or fearful seed for one scene;

learn one material it desires;

learn one use it dislikes;

grant its bearer Advantage on one roll made with the item before the next Full Cultivation Session;

prevent one minor item-spirit complication from worsening until the next Full Cultivation Session.

This does not force obedience.

## Sphere — Chains

### Soul Shackles

**Canonical ID:** `insight.soul-shackles`

**Prerequisite:** Spirit Awakening, Chains sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You may use Wisdom as your Chains key ability.

If you can perceive the target through Spiritual Sense, Soul Gaze, or another legal sense, your Chains talents can target and restrain:

- manifested or unbodied spirits;
- ghosts and Incorporeal creatures;
- astral bodies and projections;
- possessing Intruders and visible possession links;
- spiritual manifestations that are valid creatures or Assets.

This permission does not make an untargetable Complete Soul destructible and does not let a mundane chain cross planes or enter a sealed vessel unless the Chains talent or another Source Rule permits it.

When you apply **Chain-Script Seal** to a possessing Intruder or its possession link, the Host has Advantage on the next saving throw it makes against that possession before the end of its next turn.

### Chain-Walking Immortal

**Canonical ID:** `insight.chain-walking-immortal`

**Prerequisite:** Chains sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You may move along your own chains as though they were stable ground.

You gain the following benefits:

climb at full Speed using chains;

swing across gaps without checks when a valid chain route exists;

use Chain Bridge once per scene without spending CP;

ignore ordinary falling damage if a valid anchor exists within 60 feet and you are not incapacitated.

### Prison Warden

**Canonical ID:** `insight.prison-warden`

**Prerequisite:** Chains sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Your prison techniques are harder to break.

Shackling Chain, Chain Prison, Chain the Door, and Prison of Nine Gates gain:

+2 AC for their Chain Objects or bound structures;

additional Hit Points equal to 5 x your Proficiency Bonus;

a creature escaping one of your Chains talents cannot teleport until the start of its next turn.

### Hook Master

**Canonical ID:** `insight.hook-master`

**Prerequisite:** Chains sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Your hooks are fast, cruel, and accurate.

Restraining Hook gains:

range increases by 30 feet;

on a failed save, you may also pull the target 5 feet;

once per scene, you may use Restraining Hook without spending CP.

### Living Anchor

**Canonical ID:** `insight.living-anchor`

**Prerequisite:** Chains sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You can anchor others through your own stance and body.

When Anchor the Link protects an ally:

reduce forced movement by an additional 10 feet;

grant Advantage on one saving throw against Prone, Grappled, Restrained, or forced movement;

the ally may move 5 feet toward you without provoking opportunity attacks.

Body Refiners often use this Insight as a signature protector method.

### Lawful Captor

**Canonical ID:** `insight.lawful-captor`

**Prerequisite:** Chains sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you reduce a creature to 0 Hit Points with Chain Lash or a Chains talent, you may choose to knock it unconscious and immediately bind it with mundane chains, rope, or Manacle Method if you have a free hand, chain, or equivalent tool.

In addition, you have Advantage on Charisma checks made to justify lawful capture, prisoner transfer, bounty custody, or sect discipline when your use of Chains was witnessed and proportionate.

### Chain-Tool Familiarity

**Canonical ID:** `insight.chain-tool-familiarity`

**Prerequisite:** Chains sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain proficiency with chain weapons, manacles, prison tools, and one artisan’s tool or martial tool related to chains, locks, hooks, or restraints.

If you already have the relevant proficiency, you may add half your Proficiency Bonus to checks made to repair chains, disable shackles, evaluate prison equipment, or identify chain-based techniques.

## Sphere — Daemonic Cultivation

### Sealed Demon Seed

**Canonical ID:** `insight.sealed-demon-seed`

**Prerequisite:** Daemonic Cultivation, CL 1+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You bind the demon seed with chains, sutras, needles, talismans, or vows.

Gain:

maximum Corruption increases to 12;

visible signs of Corruption appear two points later;

once between Full Cultivation Sessions, when you would gain Corruption, reduce the amount by 1.

Drawback:

if the seal is broken by a major story event, immediately gain 2 Corruption.

### Devil-Qi Circulation

**Canonical ID:** `insight.devil-qi-circulation`

**Prerequisite:** Daemonic Cultivation, CL 4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When Demon Seed is active, choose one damage type from Necrotic, Psychic, Poison, Fire, Acid, or Force.

Your Daemonic talents may use that damage type until the end of the scene.

Once per scene, when a creature fails a save against a Daemonic talent of that type, gain 1 Devoured Essence.

### Heart-Devil Negotiator

**Canonical ID:** `insight.heart-devil-negotiator`

**Prerequisite:** Daemonic Cultivation and either Spirit Awakening or Wisdom 14+, CL5+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

### Bargain with the Inner Demon

**Action Type:** No Action  
**Trigger:** You would gain one or more Corruption from a single event  
**Limit:** Once per scene

Make a Wisdom (Insight) check against `DC 12 + your current Corruption` before applying the triggering Corruption.

**Success:** Delay the triggering Corruption until the current scene ends. Record its amount and source. When the scene ends, gain all Corruption delayed by this Insight simultaneously. Ending, suppressing, or bargaining with the source does not erase the delayed amount unless that Source Rule expressly removes Corruption already incurred.

**Failure:** Gain the Corruption immediately and record one **Temptation**. Choose or roll `1d6`:

| d6 | Temptation |
|---:|---|
| 1 | Conceal the Corruption or its source from an ally or authority. |
| 2 | Seize, consume, protect, or study the object or essence that caused it. |
| 3 | Accept a further offer of power, knowledge, or access from the source. |
| 4 | Isolate yourself from anyone likely to interfere. |
| 5 | Spare, obey, imitate, or bargain with the entity behind the Corruption. |
| 6 | Prove your superiority through an unnecessary risk, contest, or display. |

A Temptation is a recorded impulse, not control. It cannot compel an action, impose a condition, or create additional Corruption unless another Source Rule says so. It ends with the scene.

An effect that expressly says its Corruption cannot be delayed overrides this Insight.

### Demon-Slaying Demon

**Canonical ID:** `insight.demon-slaying-demon`

**Prerequisite:** Daemonic Cultivation, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You refine demons by hunting demons.

When you damage a fiend, demon, possessed creature, demonic beast, inner demon manifestation, or creature using Daemonic Cultivation:

add Proficiency Bonus to one damage roll, once per turn;

if the creature drops to 0 HP, reduce your Corruption by 1 or gain 2 Devoured Essence.

### Orthodox Mask of the Black Scripture

**Canonical ID:** `insight.orthodox-mask-of-the-black-scripture`

**Prerequisite:** Daemonic Cultivation, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You have learned to hide forbidden power beneath ordinary cultivation signs.

Gain Advantage on checks to conceal Daemonic Cultivation from casual observers.

When entering a sect gate, consecrated site, or heavenly ward, you may spend 1 CP or 1 Devoured Essence to avoid automatic detection by ordinary wards. Powerful wards may still call for a contested check.

### Feed the Breakthrough Furnace

**Canonical ID:** `insight.feed-the-breakthrough-furnace`

**Prerequisite:** Profane Breakthrough Pressure, CL 10+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Profane Breakthrough Pressure and the check succeeds, choose one:

gain Temporary HP equal to your CL after the cultivation session;

regain all missing CP up to half your maximum CP;

reduce Corruption by 1 if the breakthrough involved defeating or purifying an inner demon;

gain Advantage on your next saving throw against tribulation backlash.

If the check fails, gain 2 Corruption instead of 1.

### Name-Sealing Demon Chain

**Canonical ID:** `insight.name-sealing-demon-chain`

**Prerequisite:** Demon Mark, Fate or Ink sphere, CL 10+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature fails its saving throw against Demon Mark, you may write, speak, brand, or stitch a partial name-chain.

Until the mark ends:

the creature has Disadvantage on checks to magically disguise itself from you;

if it teleports within 60 feet, you know the direction of its destination but not exact distance;

the first time it damages you, it takes Psychic damage equal to Proficiency Bonus.

This is not full Fate name control.

### Demon Emperor’s Price

**Canonical ID:** `insight.demon-emperor-s-price`

**Prerequisite:** Demon Emperor Incarnation, CL 15+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When Demon Emperor Incarnation ends, you may reduce Corruption gained by 1.

If you do, choose one price:

lose one Hit Die until your next Full Cultivation Session;

suffer Disadvantage on the next social check against an orthodox cultivator;

gain 1 Demonic Debt recorded against you;

one visible demonic sign remains until purified.

## Sphere — Death

### Corpse-Tempered Body

**Canonical ID:** `insight.corpse-tempered-body`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL when Death is used through this Insight.

You may learn the Death Sphere through the Corpse-Tempered Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

You are not Undead. Your body can store grave essence without ordinary rejection.

**Grave Tempering — Once per scene:** When you activate a Death talent or would take Necrotic damage, gain Resistance to Necrotic damage for 1 minute. If triggered by damage, the Resistance applies to the triggering packet. Reactivating it refreshes the duration.

### Gravekeeper

**Canonical ID:** `insight.gravekeeper`

**Prerequisite:** Death, CL 4+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You are trained in lawful funeral practice.

Gain Advantage on checks made to investigate death, identify undead, recognize possession, prepare corpses, locate hidden graves, or determine whether remains have been desecrated.

Funerary Preservation no longer costs CP for Common corpses.

### Bone General

**Canonical ID:** `insight.bone-general`

**Prerequisite:** Corpse Servant, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase your Death Control Limit by 1, but the extra capacity can be used only for Corpse Servants or Lesser Corpse Servants.

When you use a Bonus Action to command Death servants, one commanded servant may move up to 10 feet before taking its action.

### Merciful Reaper

**Canonical ID:** `insight.merciful-reaper`

**Prerequisite:** Death, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature dies within 30 feet, you may use your Reaction to choose one:

prevent its corpse from being animated for 24 hours;

preserve its soul from ordinary destruction for 24 hours;

allow it to speak one final sentence;

end one ordinary possession affecting its corpse;

grant one ally who can hear the final breath Temporary HP equal to your Proficiency Bonus.

This Insight is favored by orthodox Death cultivators.

### Tomb Architect

**Canonical ID:** `insight.tomb-architect`

**Prerequisite:** Death, Formations or Protection, CL 10+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When designing a tomb, mausoleum, graveyard, ancestor hall, corpse vault, or battlefield burial array, you may use one Death talent as a project seed.

This does not create the project automatically. It provides a valid conceptual anchor for Formation, Protection, Spirit, Radiance, or Qiweaving design.

### Black-Lantern Commander

**Canonical ID:** `insight.black-lantern-commander`

**Prerequisite:** Death, Grave Formation, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you control a Grave Formation, increase its Speed by 10 feet and its maximum HP by your CL.

Once per scene, when a Grave Formation you control drops to 0 HP, it may make one Grave Assault before collapsing.

### Psychopomp’s Courtesy

**Canonical ID:** `insight.psychopomp-s-courtesy`

**Prerequisite:** Death sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use **Soul Funeral** or **Quiet Burial** against a ghost, undead creature, possessing Intruder, or another target those talents legally affect, you may declare **Courtesy** before resolving damage.

If you do:

- the activation deals no damage;
- a target currently possessing an unwilling Host, desecrating remains, or preventing a soul from following its lawful afterlife or reincarnation route has Disadvantage on its saving throw against the activation; and
- if the target fails but remains a Complete Soul, it may communicate one final sentence and ask one brief question before it departs, is expelled, or enters the legal state produced by the talent.

The question does not compel an answer, suspend hostile action beyond the talent's normal resolution, reveal hidden information automatically, or change the target's legal destination.

## Sphere — Destruction

### Breach-Reader

**Canonical ID:** `insight.breach-reader`

**Prerequisite:** Destruction sphere

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Spend 1 minute studying one visible object, wall, barrier, lock, Formation Anchor, gate, or structural defense within 30 feet.

Make an Intelligence (Investigation) check or Cultivation Check against the target's Cultivation Save DC. If it has no save DC, use `10 + its Source CL + its quality modifier`, where the quality modifier is 0 for ordinary construction, +2 for reinforced or cultivated construction, and +5 for Artifact, Secret, or masterwork construction.

On a success, choose and learn one:

- the most vulnerable visible section;
- whether it has Resistance or Immunity to one damage type you can deal;
- whether destroying it is likely to create a breach, collapse, alarm, or printed backlash; or
- one tool, Sphere, or damage category that bypasses a printed defense it possesses.

On a failure, learn only whether its Source CL is lower than, equal to, or higher than yours.

### Calamity Control

**Canonical ID:** `insight.calamity-control`

**Prerequisite:** Destruction sphere

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use a Blast Shape that affects an area, you may choose one creature you can see in the area. That creature has Advantage on its saving throw against the blast.

At Core Formation Realm, you may choose two creatures instead.

### Impact Tempering

**Canonical ID:** `insight.impact-tempering`

**Prerequisite:** Destruction Sphere, Body Refining

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Destruction Source CL, using Body Refining CL when the talent is internalized through Body Refining.

When you deliver Destructive Blast through an unarmed strike, natural weapon, or melee weapon, you may use Constitution for the Cultivation Attack roll.

Once per turn, after such an attack damages an unattended object, structure, vehicle, temporary barrier, Formation Anchor, or defined terrain section, deal additional damage equal to your Proficiency Bonus to that same target. The additional damage is part of the attack and does not create another hit.

### Ruin Pearl Handler

**Canonical ID:** `insight.ruin-pearl-handler`

**Prerequisite:** Destruction sphere, Calamity Pearl

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks made to conceal, place, throw, sling, recover, or safely disarm your own Sealed Pearls.

When a creature attempts to identify one of your Sealed Pearls before it triggers, the DC increases by 2.

### Formation Breaker

**Canonical ID:** `insight.formation-breaker-destruction`

**Prerequisite:** Destruction sphere, Foundation Realm

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you damage a barrier, ward, or formation anchor with Destructive Blast, you may immediately learn whether the target was meaningfully harmed, resisted the damage, ignored the damage, or retaliated through a backlash effect.

## Sphere — Disease

### Plague-Bearing Body Insight

**Canonical ID:** `insight.plague-bearing-body-insight`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Disease talents used through this Insight.

You may learn the Disease Sphere through the Plague-Bearing Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your body is a legal carrier and cultivation medium, but you must still follow every Disease rule for exposure, incubation, immunity, transmission, safety, and Source CL. This Insight does not make allies immune to your diseases.

### Plague Physician

**Canonical ID:** `insight.plague-physician`

**Prerequisite:** Disease, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Purging Breath may be used as a Bonus Action.

Purging Breath may target a willing creature within 30 feet.

When you use Purging Breath, you may remove two Contagion Tokens instead of one.

If the target immediately repeats a saving throw against a Disease effect, it has Advantage.

You automatically identify ordinary disease when using Diagnose the Sickness.

### Epidemic Master

**Canonical ID:** `insight.epidemic-master`

**Prerequisite:** Disease, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

The maximum number of your Contagion Tokens a creature can hold increases by 2.

Once per turn, when a creature gains one of your Contagion Tokens, reduce its Speed by 5 feet until the start of your next turn.

### Quarantine Adept

**Canonical ID:** `insight.quarantine-adept`

**Prerequisite:** Disease, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Raise the Quarantine Veil no longer requires Concentration when used in Containment Mode.

The veil radius increases by 5 feet.

As a Bonus Action, you may move one Quarantine Veil you created up to 10 feet.

Your Containment Mode prevents ordinary Disease effects from spreading beyond the ward unless you allow it.

### Hidden Carrier Insight

**Canonical ID:** `insight.hidden-carrier-insight`

**Prerequisite:** Disease sphere, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Diagnose-like effects must succeed on a Cultivation Check against your Cultivation Save DC to identify you as the source of one of your Disease effects.

Your Contagion Tokens may remain visually hidden, and you may suppress visible symptoms caused by your Disease talents until their printed trigger occurs.

Parasite Seed lasts for 1 hour outside Initiative. It can spread outside the scene only if its own Source Rule prints an out-of-scene transmission method, range, and target limit.

### Clean Quarantine Reputation

**Canonical ID:** `insight.clean-quarantine-reputation`

**Prerequisite:** Disease sphere

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You are known as a plague handler rather than a plague criminal.

When you openly assist a community, sect, caravan, village, military camp, or clinic with diagnosis or containment, you gain Advantage on one social check made to request cooperation, access to patients, quarantine authority, or emergency supplies.

This Insight does not protect you if you are caught weaponizing disease against innocents.

## Sphere — Drunken Style

### Fool’s Balance

**Canonical ID:** `insight.fool-s-balance`

**Prerequisite:** Drunken Style sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you roll Initiative, you may immediately use Reeling Step before the first turn begins.

If this applies Off-Rhythm to a creature, you regain Martial Focus if you did not already have it.

### Fall Seven Ways

**Canonical ID:** `insight.fall-seven-ways`

**Prerequisite:** Drunken Style sphere, Falling-Leaf Drop or Bent-Reed Recovery, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Standing from Prone costs you only 5 feet of movement.

Once per scene, when you would take falling damage, you may reduce that damage to 0 and move 10 feet to a legal space at the end of the fall.

### Prop Scripture Initiate

**Canonical ID:** `insight.prop-scripture-initiate`

**Prerequisite:** Drunken Style sphere, Accidental Weapon, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Your improvised weapons used for Drunken Style talents count as magical for the purpose of overcoming resistance and immunity to nonmagical attacks.

In addition, once per turn when an improvised weapon used for a Drunken Style talent breaks, is thrown away, or is dropped, you may draw or pick up another Tiny or Small mundane object within reach.

### Impossible Recovery

**Canonical ID:** `insight.impossible-recovery`

**Prerequisite:** Drunken Style sphere, Swaying Guard, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When Swaying Guard causes an attack to miss you, you may stand from Prone, escape nonmagical Difficult Terrain, or end one effect reducing your Speed by 10 feet or less.

Once per scene, you may use Swaying Guard even when your Speed is 0.

### Broken-Rhythm Adept

**Canonical ID:** `insight.broken-rhythm-adept`

**Prerequisite:** Drunken Style sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Once per turn when you hit a creature that is Off-Rhythm from you, you may apply one additional Mortal Realm Rhythm talent that does not require expending Martial Focus.

You cannot apply the same talent twice to the same hit.

### Crooked-Court Custodian

**Canonical ID:** `insight.crooked-court-custodian`

**Prerequisite:** Drunken Style sphere, Court of Broken Rhythm, Formations sphere, CL 12+

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When designing a Formation, training hall, ambush route, safehouse, dueling stage, or sect obstacle course, you may use one Drunken Style technique as a seed concept.

Examples include false floors, misleading footstep patterns, rotating doors, staggered pressure plates, misleading practice dummies, or a courtyard whose safe route changes with rhythm.

This Insight does not create a project automatically. It provides a valid conceptual seed for Formation design, Forged Techniques, sect defenses, or campaign projects.

## Sphere — Dual Wielding

### Empty-Hand Twin Form

**Canonical ID:** `insight.empty-hand-twin-form`

**Prerequisite:** Dual Wielding sphere, one Unarmed Strike, natural weapon, or body weapon granted by a recorded Source Rule; CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one Unarmed Strike, natural weapon, or body weapon you possess.

For Dual Wielding sphere requirements only, the chosen attack form counts as one one-handed melee weapon that lacks the Two-Handed property.

Empty-Hand Twin Form does not cause your body to hold an object, grant the Light property for unrelated features, create a free hand, allow the same hand to wield a weapon and count as a separate body weapon simultaneously, grant a natural weapon you do not possess, or alter the attack's ordinary damage or damage type.

If you know Greater Blades, the chosen attack form may qualify for the Light-property extra attack only for the limited purposes printed by Greater Blades.

### Paired-Weapon Instructor

**Canonical ID:** `insight.paired-weapon-instructor`

**Prerequisite:** Dual Wielding sphere, CL6+

**Ability Increase (Level Selection):** Increase your Dexterity, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

When you instruct a creature in a Dual Wielding talent you know, record that talent as the training subject.

During each day of training in which you provide at least 4 hours of instruction:

- the trainee has Advantage on its training check for that talent; and
- on a successful training check, that day counts as 2 days of training progress instead of 1.

This Insight does not grant the talent automatically, waive its prerequisites, reduce the minimum training time below 2 days, or bypass Restricted, Secret, inherited, ethical, or lineage access.

### Two-Moons Focus

**Canonical ID:** `insight.two-moons-focus`

**Prerequisite:** Dual Wielding sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, when you would expend Martial Focus on a Dual Wielding talent, retain Martial Focus instead.

## Sphere — Earth

### External Foundation Breakthrough

**Canonical ID:** `insight.external-foundation-breakthrough`

**Prerequisite:** Body Refining, Earth Sphere, CL5+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for this external-projection permission.

You may use non-Domain Earth features with a printed range of 30 feet or less when the effect originates from your body, a stomp, a strike, a held object, or a continuous surface connected to your footing. At CL10, Foundation-Realm Earth talents used this way may reach 60 feet.

You cannot create Earth in open air, originate from an unseen or disconnected surface, or ignore line of effect unless the Earth feature expressly permits it. The permission ends if no legal bodily or surface route remains.

### Burden-Mark Adept

**Canonical ID:** `insight.burden-mark-adept`

**Prerequisite:** Earth sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

Increase your Burden Mark limit by 1.

Once per round when you spend a Burden Mark, move 5 feet without provoking Opportunity Attacks from the marked creature, provided both of you are touching the same surface.

### Road-and-Wall Adept

**Canonical ID:** `insight.road-and-wall-adept`

**Prerequisite:** Earth sphere, one Settlement talent, CL 6+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you create a wall, road, ramp, shelter, ridge, or seal with an Earth talent, choose one:

increase its Hit Points by your Cultivation Level;

increase its duration by one step, from 1 minute to 10 minutes, 10 minutes to 1 hour, or 1 hour to 24 hours;

create one additional 5-foot section or space.

Use this Insight once per scene.

### Tremor-Reader Adept

**Canonical ID:** `insight.tremor-reader-adept`

**Prerequisite:** Earth sphere, Tremor-Listening Palm, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When using Tremor-Listening Palm, you can distinguish between Small, Medium, Large, and Huge or larger creatures by weight and rhythm.

You also gain Advantage on Wisdom (Survival) and Intelligence (Investigation) checks made to read tracks, collapsed ground, battle movement, digging, marching, falling, or dragging.

### Burden-Bearing Companion

**Canonical ID:** `insight.burden-bearing-companion`

**Prerequisite:** Earth sphere, Companion feature or bonded companion, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

Your bonded companion can share your Foundation.

While your companion is touching one of your Foundation Spaces:

it gains Advantage on checks and saving throws against being moved or knocked Prone;

once per round when it hits a creature, it may place one Burden Mark for you if you can perceive the target;

when you use Bear the Blow on your companion, add your Proficiency Bonus to the damage reduction.

### Foundation Array Custodian

**Canonical ID:** `insight.foundation-array-custodian`

**Prerequisite:** Earth sphere, Formations sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When designing a Formation, road, gate, wall, tomb, courtyard, sect foundation, battlefield camp, or long-term terrain project, use one Earth Foundation, Burden, or Settlement principle as a seed concept.

This does not create the project automatically.

The project still requires:

terrain physically connected to the project footprint;

preparation time;

material costs;

labor or Formation anchors;

maintenance;

a clear vulnerability or counterplay condition.

## Sphere — Fate

### Fortune-Tempered Body

**Canonical ID:** `insight.fortune-tempered-body`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Fate talents used through this Insight.

You may learn the Fate Sphere through the Fortune-Tempered Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your Fate effects must remain visibly embodied through scars, pulse, stance, breath, impact, blood, or another recorded bodily sign unless a Fate talent grants subtler authority. This does not grant automatic knowledge of fate or remove a Fate talent's requirements.

### Gambler’s Instinct

**Canonical ID:** `insight.gambler-s-instinct`

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks made to recognize cheating, manipulated wagers, altered lots, loaded dice, cursed games, or supernatural probability influence.

You cannot be Surprised by ordinary ambushes while conscious if the ambush relies on a game of chance, random patrol timing, or manipulated coincidence.

### Loaded Destiny

**Canonical ID:** `insight.loaded-destiny`

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, roll 1d20 and record the result.

Before your next Full Cultivation Session, you may replace one attack roll, ability check, or saving throw you make with the recorded result.

Using the recorded result does not count as rolling a natural 1 or natural 20 unless the recorded result was actually 1 or 20.

### Auspicious Companion

**Canonical ID:** `insight.auspicious-companion`

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, choose one willing creature.

Once before your next Full Cultivation Session, when that creature fails an attack roll, ability check, or saving throw, it may roll 1d8 and add the result, potentially turning failure into success.

### Name-Sheltering Talisman

**Canonical ID:** `insight.name-sheltering-talisman`

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

You learn a minor rite for protecting names.

At the end of a Full Cultivation Session, choose yourself or one willing creature whose name you write, seal, or ritually conceal. Until the next Full Cultivation Session, the chosen creature has Advantage on saving throws against Fate, curse, possession, domination, and name-targeting effects.

### Mandate-Bearing Voice

**Canonical ID:** `insight.mandate-bearing-voice`

**Prerequisite:** Fate, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use a Word talent, increase its range by 30 feet.

Once per scene, if a creature succeeds on a saving throw against one of your Word talents, you may force it to subtract your Fate Die from the result. This can turn success into failure.

Using this Insight to affect a natural 20 gains 1 Heaven’s Notice.

## Sphere — Flowing River

### Student of the Returning Current

**Canonical ID:** `insight.student-of-the-returning-current`

**Prerequisite:** Flowing River sphere

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain one Flowing River talent for which you meet the prerequisites.

You also gain proficiency in Dexterity (Acrobatics) or Wisdom (Insight). If already proficient in the chosen skill, gain Expertise instead.

### Double Current Method

**Canonical ID:** `insight.double-current-method`

**Prerequisite:** Flowing River sphere, CL 5+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, when Flowing Response succeeds, apply two different Response talents you know without expending Martial Focus.

Both talents must be legal for the same trigger.

### Body Like Water

**Canonical ID:** `insight.body-like-water`

**Prerequisite:** Flowing River sphere

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you are Grappled or Restrained, you may use a Bonus Action to attempt to escape.

If you escape a Grapple or Restraint this way, regain Martial Focus.

You regain Martial Focus only if it is currently absent.

### River Without Edges

**Canonical ID:** `insight.river-without-edges`

**Prerequisite:** Flowing River sphere, CL10+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When Flowing Response grants movement, you may cross liquid surfaces, loose rubble, narrow branches, collapsing terrain, or a hostile creature's occupied space as Difficult Terrain if there is a continuous physical path no wider than your normal reach from one supporting surface to the next.

You do not need the surface to support your full weight during this movement, but you must end in a legal space that can support you. This is not flight, teleportation, or general water walking outside movement granted by Flowing Response.

## Sphere — Gravity

### Gravitic Soul

**Canonical ID:** `insight.gravitic-soul`

**Prerequisite:** Spirit Awakening, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You may learn Gravity as a Spirit Awakening Sphere. If this is a new Sphere for you, gain the normal free talent granted when learning a new Sphere.

When using Gravity through Spirit Awakening:

- use Resonance for Gravity talents;
- use Wisdom as your Gravity key ability;
- use Wisdom instead of Strength when resisting forced movement, being knocked Prone, or resisting supernatural anchoring;
- your Gravity talents can express the weight of vows, souls, fear, obligation, judgment, and identity when the target and talent are otherwise legal; and
- when a creature fails a saving throw against **Weight of the Mountain**, **Black-Star Grip**, or **Heaven's Weight**, it has Disadvantage on Concentration saving throws until the start of its next turn.

This Insight changes access, key ability, resource, and expression. It does not let Gravity damage or rewrite a soul, vow, memory, or identity unless the specific Gravity talent or another Source Rule grants that authority.

### Mountain Stance

**Canonical ID:** `insight.mountain-stance`

**Prerequisite:** Gravity sphere, CL 4+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

While touching a solid surface and Body Heavying is active:

You have Advantage against forced movement.

You have Advantage against being knocked Prone.

You count as one size larger for Grapple and Shove.

You reduce forced movement affecting you by 5 feet.

If you already have Anchor Stance, increase the total reduction by 5 feet.

### Falling Star Footwork

**Canonical ID:** `insight.falling-star-footwork`

**Prerequisite:** Gravity sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When using Reverse Gravity Step, Feather Body, or Body Lightening:

you do not provoke Opportunity Attacks from creatures whose reach you leave during the first 10 feet of movement;

you may move across liquid surfaces during your turn;

you may move across fragile surfaces without breaking them;

once per scene, you may use Reverse Gravity Step without spending CP or Stamina.

### Crushing Focus

**Canonical ID:** `insight.crushing-focus`

**Prerequisite:** Gravity sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once per turn when a creature fails a save against your Gravity talent, deal additional Force damage equal to your Proficiency Bonus.

If the failed save was caused by a Weight Art delivered through a melee attack, you may instead regain Martial Focus, if your table uses Martial Focus.

### Body as Center

**Canonical ID:** `insight.body-as-center`

**Prerequisite:** Body Refining, Gravity Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Gravity Source CL, using Body Refining CL when Gravity is internalized through Body Refining.

When you use Gravitic Pull, Gravity Well, Crushing Field, or Flight Suppression, you may center the effect on your body. If you do, reduce the Stamina actually paid by 1, minimum 1.

The area moves with you only until the start of your next turn unless the Gravity talent itself says the area moves. After that point it remains at its current location for the rest of its duration. Centering the effect does not make you immune to it unless the talent says so.

### Moon-Thread Weight

**Canonical ID:** `insight.moon-thread-weight`

**Prerequisite:** Gravity sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When Body Lightening is active, you may treat one weapon you hold as lighter than it is.

Choose one benefit at the start of your turn:

A two-handed melee weapon you wield does not prevent you from climbing, balancing, or moving across fragile surfaces.

A non-heavy melee weapon you wield may be used with your Gravity key ability for attack and damage rolls until the start of your next turn.

One thrown weapon you throw returns to your hand at the end of the turn by curving through a small orbit.

### Anchor Between Heaven and Earth

**Canonical ID:** `insight.anchor-between-heaven-and-earth`

**Prerequisite:** Gravity sphere, CL 12+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you would be moved against your will, knocked Prone, or dropped from flight, you may use your Reaction and spend 2 CP or Stamina to anchor yourself.

Until the start of your next turn:

your Speed becomes 0;

you cannot be moved against your will by effects of Core Formation or lower;

you do not fall unless the surface supporting you is destroyed;

attacks against you have Advantage until the start of your next turn.

## Sphere — Harvesting Gathering

### Herb-Gatherer’s Foundation

**Canonical ID:** `insight.herb-gatherer-s-foundation`

**Prerequisite:** Harvesting and Gathering, CL 4+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one Sign or Cut talent you know. Once per scene, when you use that talent and roll a Gathering Check, add a d4 to the roll after seeing the d20 but before knowing the outcome.

At CL 10, the die becomes a d6.

### Body of Thorns and Spores

**Canonical ID:** `insight.body-of-thorns-and-spores`

**Prerequisite:** Body Refining, Harvesting and Gathering Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for bodily resistance; normal Sphere Source CL for harvesting talents.

You gain the Body Refining path synergy for Harvesting and Gathering.

You have Advantage on saving throws against Poison, Disease, spores, irritating pollen, mundane thorns, environmental heat and cold, hunger, thirst, bad air, and harvest-site hazards. This does not grant Resistance to damage unless a rule applies a saving throw and says success reduces that damage.

### Medicine-Field Steward

**Canonical ID:** `insight.medicine-field-steward`

**Prerequisite:** Harvesting and Gathering, CL 4+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain Farmer’s Eye or Sect Medicine-Field Steward as a bonus talent. If you do not yet meet the prerequisite for Sect Medicine-Field Steward, gain it when you reach CL 5.

When you supervise a mundane farm or medicine field during downtime, workers under you have Advantage on ordinary checks to harvest without waste.

### Beast-Core Butcher

**Canonical ID:** `insight.beast-core-butcher`

**Prerequisite:** Harvesting and Gathering, Simple Beast Dressing, CL 8+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain Beast-Core Dressing as a bonus talent when you meet its prerequisites.

When you harvest beast materials from a creature whose CR is no higher than your CL, a failure by 5 or less creates a Bruised Lot instead of losing the material.

### Sect Supply Officer

**Canonical ID:** `insight.sect-supply-officer`

**Prerequisite:** Harvesting and Gathering, Field Ledger, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

You may maintain twice as many active recorded sites in your Field Ledger.

When you deliver at least one complete Harvest Lot to a sect, clan, army, village, market, or pill hall, choose one settlement benefit:

- increase the ordinary sale or mission-credit value of the delivered Lots by 10 percent;
- secure safe lodging and ordinary meals for a number of creatures up to your Proficiency Bonus for 7 days;
- obtain one non-Secret factual lead concerning local demand, danger, or resource sites; or
- gain Advantage on the next requisition, supply, or mission-credit check made with that organization before the end of the next scene.

One delivery can grant one settlement benefit. The Insight does not create Restricted goods, Secret information, political authority, or credit beyond the delivered Lots' ordinary value.

### Jade-Seal Preserver

**Canonical ID:** `insight.jade-seal-preserver`

**Prerequisite:** Harvesting and Gathering, Spirit-Sealing Wax, CL 8+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

When you Seal the Essence of a Common or Uncommon Lot, you may treat one Bruised Lot as Normal quality.

At CL 10, you may use this on Rare Lots.

### Thousand-Mile Forager

**Canonical ID:** `insight.thousand-mile-forager`

**Prerequisite:** Harvesting and Gathering, CL 8+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Your travel pace is not reduced while foraging, mapping, or searching for Common Resource Sites in ordinary wilderness.

During a journey, once per journey segment you may make one Read the Sign check for the region without slowing the group.

### Ethical Gatherer

**Canonical ID:** `insight.ethical-gatherer`

**Prerequisite:** Harvesting and Gathering, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

When you preserve a living source that could legally have been destroyed for a greater Harvest yield, record one **Preservation Merit**. You can hold one Preservation Merit.

Spend it to gain Advantage on one Gathering Check using Root-Left-Alive Method or Source-Sparing Harvest. A source cannot grant another Preservation Merit until it has naturally recovered or completed a cultivation cycle.

Staged, owned, summoned, or repeatedly regenerated sources do not grant Preservation Merit.

## Sphere — Hunger

### Clean-Tongued Disciple

**Canonical ID:** `insight.clean-tongued-disciple`

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you use Taste the Qi on food, drink, or medicine, you may also detect mundane spoilage, common poison, and obvious disease without rolling unless the substance is deliberately concealed.

### Camp Kitchen Adept

**Canonical ID:** `insight.camp-kitchen-adept`

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

During a 10-minute recovery procedure, if you prepare food for the party, choose one willing creature who eats it. That creature gains Temporary HP equal to your Proficiency Bonus.

A creature can benefit from Camp Kitchen Adept only once between Full Cultivation Sessions.

### Iron Belly Foundation

**Canonical ID:** `insight.iron-belly-foundation`

**Prerequisite:** Hunger sphere, Foundation Realm

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you fail a Constitution saving throw against Poisoned, you may spend 1 CP to reroll the save. You must use the new result.

You can use this Insight once per scene.

### Monster-Taste Scholar

**Canonical ID:** `insight.monster-taste-scholar`

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain proficiency in Nature or Survival. If you already have both, choose Medicine or Cook's Utensils.

When you use Taste the Qi on a beast, monstrosity, dragon, demon beast, or strange corpse, gain a +1 bonus to the Hunger Check if a roll is required.

### Banquet Etiquette of the Outer Court

**Canonical ID:** `insight.banquet-etiquette-of-the-outer-court`

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain proficiency in Persuasion or Cook's Utensils.

When you share a legally prepared Hunger meal with a neutral or friendly cultivator, gain Advantage on one Charisma check made during that meal to discuss travel, supplies, hospitality, safe passage, or sect introductions.

### Refuse the Forbidden Bowl

**Canonical ID:** `insight.refuse-the-forbidden-bowl`

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain Advantage on saving throws and ability checks made to resist Forbidden Hunger, daemonic appetite, cursed food, cannibal scriptures, ghost famine, or another effect tagged Hunger, Daemonic, Curse, Possession, or spiritual predation.

If you willingly use a Forbidden Hunger talent on an unwilling creature, this Insight becomes dormant after that activation. Restore it by completing a Full Cultivation Session devoted to restraint and providing food, medicine, restitution, or protection whose ordinary value is at least `10 × your CL` silver pieces to creatures harmed by predatory hunger.

### Open the Outer Maw

**Canonical ID:** `insight.open-the-outer-maw`

**Prerequisite:** Hunger Sphere, Body Refining, Foundation Realm, Constitution 16+, Stomach Furnace Scripture

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for external Hunger used through Stomach Furnace Scripture.

You remove **Body as the Only Bowl** from Stomach Furnace Scripture. You may use Hunger talents at their listed ranges and may learn or use Banquet, external Taste, external Meal, external Secret Hunger, and external Forbidden Hunger options if you otherwise meet every prerequisite.

Every external Hunger effect must visibly originate from breath, blood-steam, stomach thunder, cooking smoke, furnace heat, appetite pressure, thrown food, a prepared dish, a held utensil or weapon, a bite mark, or another recorded body-furnace sign.

**First Projection Risk — Once per scene:** When an external Hunger effect costs Cultivation Points and affects another creature, increase one damage roll, Temporary Hit Point grant, Cultivation Point restoration, Satiety-created benefit, or Hunger Check from that activation by your Proficiency Bonus. After the effect resolves, gain 1 Impurity.

This Insight does not grant Qi Cultivation, waive ingredients, remove Appetite Stain, or make external Hunger subtle.

## Sphere — Ice

### Ice-Sure Footwork

**Canonical ID:** `insight.ice-sure-footwork`

**Prerequisite:** Ice sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

You ignore difficult terrain caused by mundane ice and snow. If you already have Sure-Footed Disciple, you may also stand from Prone while on one of your Lattice Spaces by spending only 5 feet of movement.

### Lattice Scholar

**Canonical ID:** `insight.lattice-scholar`

**Prerequisite:** Ice sphere, Qi Cultivation or Intelligence 13+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Crystallize Path, you may create one additional Lattice Space, but that additional space lasts only until the end of your next turn.

You also have Advantage on Intelligence (Arcana or Investigation) checks made to understand magical terrain, ice structures, crystalline formations, or battlefield arrays that use lines, angles, or repeating patterns.

### Winter Tempered Body

**Canonical ID:** `insight.winter-tempered-body`

**Prerequisite:** Ice Sphere and either Body Refining or Constitution 13+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Ice Source CL for Ice effects; Body Refining Source CL for Sure Foot on Winter.

Whenever an Ice feature grants you Temporary Hit Points, increase that grant by your Proficiency Bonus. Apply this increase once per activation, not once per target or round.

**Sure Foot on Winter — Once per scene:** When you would be knocked Prone while standing on ice, snow, or your Frost Lattice, choose not to become Prone. This does not prevent forced movement or damage unless those effects depend entirely on becoming Prone.

### Mirror of Frozen Breath

**Canonical ID:** `insight.mirror-of-frozen-breath`

**Prerequisite:** Ice sphere and either Spirit Awakening or Wisdom 13+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

### Frozen-Breath Mirror

**Action Type:** Bonus Action  
**Target:** One of your Lattice Spaces within 30 feet  
**Duration:** Until the start of your next turn  
**Cost:** 0 CP  
**Limit:** Once per scene

The chosen Lattice Space becomes a temporary **Rime Mirror Surface**. For the duration, you can see and hear from that space as though standing there. While using those senses, you are Blinded and Deafened to your body's senses unless you end the perception at any time.

A creature can identify the mirror as a sensory focus through the normal **Rime Mirror Surface** Study procedure.

If you already know **Rime Mirror Surface**, increase its normal range by 30 feet for you. This range increase applies to every normal activation and is separate from the free once-per-scene use above.

### Shatter Without Waste

**Canonical ID:** `insight.shatter-without-waste`

**Prerequisite:** Ice sphere, Foundation Realm

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per turn, when one of your Lattice Spaces would end because you used Shatter Space or Shatter Bloom, you may instead set its remaining duration to the end of your next turn. If it would already end at or before that time, this Insight has no effect.

Razor Rime Scripture can benefit only when the affected Lattice Space was created by a non-Secret Ice feature whose Source CL is no higher than yours.

## Sphere — Imbuement

### Careful Inscription

**Canonical ID:** `insight.careful-inscription`

**Prerequisite:** Imbuement sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you place a Mandate on a willing target outside combat, its duration is doubled, to a maximum of 1 hour.

In addition, you have Advantage on checks to identify your own Mandates and on checks to teach another creature what your Mandate does.

### Vessel-Body Scripture

**Canonical ID:** `insight.vessel-body-scripture`

**Prerequisite:** Imbuement Sphere, Body Refining, CL6+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Imbuement Source CL, using Body Refining CL for a Body Refining Imbuement.

You may externalize a Body Refining Imbuement through a held weapon, armor, shield, tattoo, scar, wrapped talisman-strip, or another recorded bodily or worn vessel.

Your range for Place Mandate and Fray Mandate is 15 feet when the target is connected to you by a chain, rope, weapon strike, thrown object, blood mark, armor plate, sash, or direct line of contact.

**Hold the Mandate — Once per scene:** When a Mandate on your body or worn gear would end because your Concentration breaks, take damage equal to `your Proficiency Bonus × your Cultivation Level` to keep it active until the end of your next turn. This damage cannot be reduced, redirected, transferred, delayed, converted, or absorbed by Temporary Hit Points.

### Efficient Mandate

**Canonical ID:** `insight.efficient-mandate`

**Prerequisite:** Imbuement sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Once per scene, when you spend CP to set a Mandate, reduce the CP cost by 1, minimum 0.

At CL 11, you may use this Insight twice per scene.

### Hidden Command

**Canonical ID:** `insight.hidden-command`

**Prerequisite:** Imbuement sphere, Quiet and Resound or Read the Vessel, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Mandates can be made subtle. When you place a Mandate, you may hide its visible signs. A creature must use Study or magical detection to notice it.

If the Mandate is hostile and the target fails its first saving throw, it does not automatically know you placed the Mandate unless the effect is obvious, such as sudden weight, speech loss, weapon dulling, or armor rebellion.

### Dual Mandate Adept

**Canonical ID:** `insight.dual-mandate-adept`

**Prerequisite:** Layered Mandate, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Mandate Load increases by 1.

When you use Layered Mandate, reduce the CP cost by 1, minimum 0.

### Awakener of Tools

**Canonical ID:** `insight.awakener-of-tools`

**Prerequisite:** Animate Minor Vessel or Speak to the Vessel, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

You may keep one Tiny or Small animated object active without it counting against Mandate Load. It cannot attack while excluded from Mandate Load, but it can follow, carry, fetch, point, open simple doors, hold a lantern, ring a bell, write simple marks, or assist with tool use.

### Mandate Breaker

**Canonical ID:** `insight.mandate-breaker`

**Prerequisite:** Counter-Mandate, CL 10+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Counter-Mandate and fail the Imbuement Check, you may spend 1 CP to turn the failure into a partial success. The target effect is suppressed until the start of your next turn, but not ended.

Once between Full Cultivation Sessions, when you succeed on Counter-Mandate by 5 or more, you may immediately place a matching opposite Mandate without spending additional CP.

### Sect Imbuement Seal

**Canonical ID:** `insight.sect-imbuement-seal`

**Prerequisite:** Imbuement sphere, Talismans or Formations sphere, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When contributing to a talisman, Formation Node, training hall, armory seal, vault mark, or ritual-vessel project, choose one Imbuement Mandate you know and record it as the project's Mandate source.

After contributing at least 1 hour during a project phase, choose one Project Contribution benefit from the central Insight execution definitions. The project may invoke the recorded Mandate only through effects printed in its completed project record.

This Insight does not mass-produce permanent magic items, waive materials or maintenance, or grant a Mandate to a creature that does not possess the project or item.

## Sphere — Ink

### Inked Body

**Canonical ID:** `insight.inked-body`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Dexterity score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Ink talents used through this Insight.

You may learn the Ink Sphere through the Inked Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your body is a legal writing surface, but every Ink talent still requires its printed mark, medium, action, duration, visibility, and removal procedure. Injury to inscribed anatomy follows Body Refining Shared Procedures R1.

### Master Calligrapher

**Canonical ID:** `insight.master-calligrapher`

**Prerequisite:** Ink sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: Increase your active Ink Mark maximum by +2. Your Ink Marks last 8 hours instead of 1 hour unless the talent has a shorter duration.

### Living Illustration Adept

**Canonical ID:** `insight.living-illustration-adept`

**Prerequisite:** Painted Beast, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: Painted Beast gains +2 AC, additional HP equal to 2 x your CL, and one additional form benefit from Living Illustration.

### Scripture Breaker

**Canonical ID:** `insight.scripture-breaker`

**Prerequisite:** Ink sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: Gain Advantage on checks made to read magical writing, disable runes, identify seals, remove Ink Marks, break written curses, understand Formation inscriptions, or contest talismanic scripts.

Reaction: Once per scene, when a written magical effect activates within 30 feet, you may use your Reaction to attempt to suppress it. Make a Cultivation Check against the effect’s save DC. On a success, the effect is suppressed until the start of your next turn.

### Red Seal Authority

**Canonical ID:** `insight.red-seal-authority`

**Prerequisite:** Ink sphere, CL 10+.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: When you create a Seal talent, you may mark it with vermilion authority. The first creature that fails a check or saving throw against that Seal takes Psychic damage equal to your Proficiency Bonus + your key ability modifier.

Additional Benefit: You have Advantage on social checks made to present official, sect, bureaucratic, or ritual written authority when your claim is at least partly true.

### Brush-Armed Guard

**Canonical ID:** `insight.brush-armed-guard`

**Prerequisite:** Brushstroke Shield, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: When Brushstroke Shield reduces damage to 0, you may place a simple Ink Mark on the attacker if it is within 60 feet and you can see it. An unwilling creature makes a Dexterity saving throw to avoid the Mark.

### Patient Inscription

**Canonical ID:** `insight.patient-inscription`

**Prerequisite:** Ink sphere.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: When you spend at least 10 minutes creating an Ink Mark or Seal, choose one.

Increase its duration by one step, from 1 hour to 8 hours, or from 8 hours to 24 hours.

Give one creature Disadvantage on its first check to find or remove it.

Allow it to survive ordinary rain, dust, handling, and minor abrasion.

Hide one mundane message inside it that only a chosen creature or group can read.

## Sphere — Iron Fist

### Tempered Knuckles

**Canonical ID:** `insight.tempered-knuckles`

**Prerequisite:** Iron Fist sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When your Unarmed Strike deals damage to an object, temporary Barrier, or creature wearing manufactured armor, add your Proficiency Bonus to the damage once per turn.

When you take damage from striking a hard surface or armored creature, reduce that damage by your Proficiency Bonus.

### Flowing Combination Adept

**Canonical ID:** `insight.flowing-combination-adept`

**Prerequisite:** Iron Fist sphere, Flowing Combination, CL 6+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When Flowing Combination grants a free Grapple or Shove attempt:

increase that technique's Save DC by 1;

on a failed save, move 5 feet without provoking Opportunity Attacks from the target;

if the target was already Opened, regain Martial Focus if absent.

Use this Insight once per turn.

### Meridian Student

**Canonical ID:** `insight.meridian-student`

**Prerequisite:** Iron Fist sphere, Meridian-Sealing Palm, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When a creature succeeds on its saving throw against Meridian-Sealing Palm, choose one:

it still cannot take Reactions until the start of your next turn;

reduce its Speed by 5 feet until the start of your next turn;

learn whether Strength, Dexterity, or Constitution is its weakest saving throw.

Once per scene, when a creature fails against Meridian-Sealing Palm, extend one chosen seal until the end of your next turn.

### Iron Shirt Adept

**Canonical ID:** `insight.iron-shirt-adept`

**Prerequisite:** Iron Fist sphere, Body Conditioning or Iron Shirt Practice, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

While holding Martial Focus and wearing no Heavy armor:

reduce falling damage by 5 × your Proficiency Bonus;

gain Advantage on one Constitution saving throw against a physical shock, poison, or bodily disruption once per scene;

when a hostile creature damages you with an Unarmed Strike or natural weapon, it takes Bludgeoning damage equal to your Proficiency Bonus.

### Clinch-Gate Adept

**Canonical ID:** `insight.clinch-gate-adept`

**Prerequisite:** Iron Fist sphere, Dragon-Step Clinch, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When you maintain a body clinch:

the target no longer has Advantage on checks to escape solely because the clinch is maintained without a hand;

you may use Rising Knee once per turn without requiring the target to already be Grappled by hand;

when the target misses you with a melee attack, reduce its Speed by 5 feet until the start of its next turn.

### Form-Script Custodian

**Canonical ID:** `insight.form-script-custodian`

**Prerequisite:** Iron Fist sphere, Formations sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When designing a Formation or martial training project, use one Iron Fist Form, Opening, Meridian, or Guard principle you know as a seed concept.

This does not create the project automatically.

Normal project requirements still apply.

### Empty-Hand Weapon Master

**Canonical ID:** `insight.empty-hand-weapon-master`

**Prerequisite:** Iron Fist sphere, Open-Hand Disarm, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When you successfully disarm a creature with Open-Hand Disarm, choose one:

catch the item if you have a free hand;

kick the item up to 15 feet into a legal space;

immediately use one Unarmed Strike against the disarmed creature;

if you possess Scoundrel, immediately plant a Tiny object on the target without spending an Action.

Use this Insight once per round.

## Sphere — Karma

### Karmic Body

**Canonical ID:** `insight.karmic-body`

**Prerequisite:** Body Refining, CL4+, secret karmic initiation

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Karma talents used through this Insight.

You may learn the Karma Sphere despite following Body Refining. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your Karma effects are visibly embodied as scars, bruises, breath marks, bone inscriptions, blood-red veins, impact echoes, or oath tattoos. A creature studying the sign may identify it with a successful Wisdom or Intelligence check against your Cultivation Save DC.

This Insight does not waive the secret initiation or conceal the karmic sign.

### Oathkeeper

**Canonical ID:** `insight.oathkeeper`

**Prerequisite:** Karma sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you knowingly fulfill a difficult promise despite personal cost, gain one Grace Imprint on yourself. Maximum: one Grace Imprint between Full Cultivation Sessions.

You have Advantage on checks made to recognize magically binding promises, coerced oaths, and oath loopholes.

### Debt Collector

**Canonical ID:** `insight.debt-collector`

**Prerequisite:** Karma sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When a creature with at least three of your Debt Imprints drops to 0 Hit Points within 60 feet of you, regain CP equal to your Proficiency Bonus.

Once you use this Insight, you cannot use it again until you finish a scene.

### Heaven’s Witness

**Canonical ID:** `insight.heaven-s-witness`

**Prerequisite:** Karma sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Record the Deed on a creature that breaks an oath, betrays a willing ally, murders a helpless creature, or violates hospitality, you may spend 1 CP to make the Imprint persistent. A persistent Imprint lasts for 7 days or until spent.

You may maintain only one persistent Imprint through this Insight at a time.

### Grace-Bearing Soul

**Canonical ID:** `insight.grace-bearing-soul`

**Prerequisite:** Karma sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Limit:** Once per scene

When you spend one of your Grace Imprints to reduce damage, grant Temporary Hit Points, or improve a saving throw for a creature, that creature may also end one **Charmed** or **Frightened** condition affecting it if the condition's Source CL is lower than your Karma Source CL.

This rider resolves after the Grace effect. It does not remove a vow, Bond, memory, personality trait, willing emotional state, or effect that merely resembles Charmed or Frightened without applying that condition.

### Merciless Accountant

**Canonical ID:** `insight.merciless-accountant`

**Prerequisite:** Karma sphere, CL 10+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When a creature carrying one of your Debt Imprints creates another Debt Cause, you may move one Debt Imprint from another creature within 60 feet onto it. The receiving creature cannot exceed your normal Imprint maximum.

Once you use this Insight, you cannot use it again until the start of your next turn.

### Borrowed Merit

**Canonical ID:** `insight.borrowed-merit`

**Prerequisite:** Karma sphere, CL 10+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When a willing creature carrying one of your Grace Imprints would fail an attack roll, ability check, or saving throw, another willing creature within 30 feet carrying one of your Grace Imprints may expend its Imprint to add 1d4 to the roll.

This can occur once per round.

### Ledger-Safe Tongue

**Canonical ID:** `insight.ledger-safe-tongue`

**Prerequisite:** Karma sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have Advantage on Charisma checks made to word clear oaths, negotiate fair terms, identify hidden traps in bargains, and persuade creatures that a consequence is just.

When you create Minor Oath, you may include one simple exception clause without making the oath unclear.

## Sphere — Life

### Battlefield Physician

**Canonical ID:** `insight.battlefield-physician`

**Prerequisite:** Life sphere.

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Read the Pulse in combat, you may move up to 10 feet before or after using it without provoking opportunity attacks from the target of your treatment.

In addition, when you stabilize a creature, that creature gains Temporary HP equal to your Proficiency Bonus.

### Clean-Handed Healer

**Canonical ID:** `insight.clean-handed-healer`

**Prerequisite:** Life sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Purify the Pulse to remove a disease or poison, you have Advantage for 24 hours on Cultivation Checks to identify, suppress, or prepare an ordinary treatment for that same disease or poison.

If you successfully treat at least three creatures suffering from the same disease or poison during one scene, learn its ordinary treatment requirements: required Medicine proficiency, one available mundane ingredient category, treatment time, and the check DC. This does not reveal a Secret cure or bypass a higher-Source-CL affliction.

### Iron Mercy

**Canonical ID:** `insight.iron-mercy`

**Prerequisite:** Life Sphere and Body Refining

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Life Source CL for Empathic Transfer; Body Refining Source CL for the temporary bodily buffer.

When you use Empathic Transfer and legally accept an affliction, gain Temporary Hit Points equal to `your Constitution modifier + your Proficiency Bonus` after the transfer resolves.

Record the transferred affliction. These Temporary Hit Points can absorb only damage or Hit Point loss caused directly by that recorded affliction. They cannot absorb unrelated attacks, costs, maximum-Hit-Point loss, or a different affliction, and expire when the recorded affliction ends.

### Pulse-Thread Memory

**Canonical ID:** `insight.pulse-thread-memory`

**Prerequisite:** Life sphere.

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

You can maintain one additional Pulse Seal.

When you use Read the Pulse on a creature bearing your Pulse Seal, you may learn whether the creature has taken damage since the start of your last turn.

### Sect Infirmary Disciple

**Canonical ID:** `insight.sect-infirmary-disciple`

**Prerequisite:** Life sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

During a 10-minute medical recovery procedure, treat a number of willing creatures up to your Proficiency Bonus.

Each treated creature may spend one or more Hit Dice and regains additional Hit Points equal to your key ability modifier.

If the campaign uses cultivation Injuries, reduce one ordinary nonmagical recovery interval for each treated creature by 25 percent, to a minimum reduction of 1 day. This does not accelerate Hidden Injury, severance, destroyed cultivation structures, or reconstruction unless another Source Rule permits it.

### Soul-Return Witness

**Canonical ID:** `insight.soul-return-witness`

**Prerequisite:** Life sphere, Spirit Awakening

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use **Read the Pulse** on a corpse that has been dead no longer than 1 day, also diagnose the soul's apparent return state. Learn one:

- **Willing:** A Complete Soul appears willing and ordinarily capable of return.
- **Unwilling:** The soul appears to refuse ordinary return.
- **Absent:** No returnable Complete Soul is present or reachable by the examined pattern.
- **Trapped:** A creature, vessel, location, Domain, Spiritual Anchor, or custody effect is restraining the soul.
- **Consumed or Destroyed:** The pattern shows loss beyond ordinary absence; this diagnosis does not itself prove permanent destruction.
- **Blocked:** An authority, reincarnation route, afterlife custody, oath, Secret, artifact, or other effect prevents ordinary return.

If the restraining or blocking source has lower Source CL than the higher of your Life and Spirit Awakening Source CL, also learn whether it is sustained by a creature, vessel, location, Domain, Bond, or Spiritual Anchor.

If the source is within 2 Source CL of you, learn its broad category and whether it is present, distant, or outside the current plane.

If the source is 3 or more Source CL higher, Secret, Immortal, divine, or world-law authority, learn only that a higher authority is involved and whether ordinary return is presently possible.

This Insight does not identify an unknown captor by name, reveal a hidden release condition, return the soul, or establish that reconstruction is possible.

## Sphere — Lightning

### Electric Fist Adept

**Canonical ID:** `insight.electric-fist-adept`

**Prerequisite:** Lightning sphere, Electric Fist Method, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Electric Fist Method, you may deal lightning damage equal to your Proficiency Bonus to the target on a failed save.

Once per scene, when a creature fails its save against Electric Fist Method, you may move 5 feet without provoking Opportunity Attacks.

### Lightning-God Disciple

**Canonical ID:** `insight.lightning-god-disciple`

**Prerequisite:** Lightning sphere, Lightning-God Body, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you activate Lightning-God Body, choose Speed, Reflex, or Shock.

Speed: Your Speed increases by an additional 5 feet.

Reflex: Once during the duration, when you fail a Dexterity saving throw, you may reroll it.

Shock: The first time each turn you deal Lightning-God Body bonus damage, increase that bonus by 1d8.

### Thunder Archer

**Canonical ID:** `insight.thunder-archer`

**Prerequisite:** Lightning sphere, Crackling Arrow or Thunder Arrow, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you hit a Charged target with a ranged weapon attack, you may move the Charge to another creature within 10 feet of the target instead of consuming it.

Once per scene, when your Thunder Arrow misses, you may still trigger its thunder report centered on the target’s space.

### Formation Breaker

**Canonical ID:** `insight.formation-breaker-lightning`

**Prerequisite:** Lightning sphere, Overload Ward, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You have Advantage on Study checks to identify Conductive formation nodes, talisman circuits, ward anchors, qi construct cores, and prepared counter arrays.

Once per scene, when you fail a Lightning Check made to Overload a non-Secret effect, you may reroll the check. You must use the new result.

### Storm Instrumentalist

**Canonical ID:** `insight.storm-instrumentalist`

**Prerequisite:** Lightning sphere, Spark-Instrument Method, Music or Sound sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Spark-Instrument Method, you may choose one ally who can hear the sound within 30 feet. That ally gains Advantage on the next saving throw it makes against being Frightened, Deafened, or unable to take Reactions before the start of your next turn.

This Insight requires Music or Sound to use the ally benefit. Without those spheres, Spark-Instrument Method remains a personal focus only.

### Grounded Rod Body

**Canonical ID:** `insight.grounded-rod-body`

**Prerequisite:** Lightning Sphere and either Body Refining or Grounded Conductor Method, CL6+

**Ability Increase (Level Selection):** Increase your Constitution, Dexterity, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Lightning Source CL for the Charge; Body Refining Source CL for the damage reduction.

A **qualifying conductor** is earth, stone, metal, wet ground, conductive liquid, a metal structure, or another material the Lightning rules expressly treat as conductive. While physically supported by one, you have Resistance to Lightning damage from non-Secret effects.

**Ground the Stroke — Once per scene:** When Lightning damage would be applied to you, reduce that damage by your Cultivation Level after Resistance and before other flat reductions, then place one Charge on a visible conductive object or unoccupied conductive space within 10 feet. The Charge uses the Lightning Sphere's normal Charge rules. If no legal location exists, the damage reduction still applies but no Charge is placed.

### Flash-Step Duelist

**Canonical ID:** `insight.flash-step-duelist`

**Prerequisite:** Lightning sphere, Flash Step, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

After you use Flash Step, your next melee attack before the end of your turn has Advantage if the target is Charged or Conductive.

If that attack hits, you may choose not to deal bonus lightning damage and instead prevent the target from taking Opportunity Attacks until the start of its next turn.

### Conductive Preservation Artist

**Canonical ID:** `insight.conductive-preservation-artist`

**Prerequisite:** Lightning sphere, Spark Lattice Preservation, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Your preservation lattices can safely hold unstable lightning-aspected, storm-aspected, talismanic, or formation materials.

When you use Spark Lattice Preservation, you may also preserve one volatile alchemical reagent, charged crystal, storm herb, lightning beast scale, or damaged talisman component. The item remains stable for 7 days.

Once between Full Cultivation Sessions, you may open such a lattice as a Bonus Action and gain one temporary Charge on yourself or a held object.

### Storm Partner

**Canonical ID:** `insight.storm-partner`

**Prerequisite:** Lightning sphere, Weather sphere or an allied Weather cultivator, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you are inside natural storm weather, a Weather-created Gather Weather field, or a scene with active thundercloud pressure, you may treat one target damaged by your Lightning talent each turn as Conductive until the start of your next turn.

This Insight does not grant Weather talents, Sky Mantles, Cloud Shrouds, Weather severity, or storm creation.

### Meridian Lightning Physician

**Canonical ID:** `insight.meridian-lightning-physician`

**Prerequisite:** Lightning sphere, Medicine proficiency, Life sphere or Pressure Points sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You can use carefully measured Lightning Qi to restart, test, or interrupt bodily channels.

During a 10-minute recovery procedure, you may treat one willing creature. The creature may immediately repeat one saving throw against paralysis, Speed reduction, or a meridian-blocking effect that allows repeated saves.

Once between Full Cultivation Sessions, when a willing creature within 5 feet fails a death saving throw, you may use your Reaction to apply a harmless shock. The creature rerolls the death saving throw and must use the new result.

This Insight does not restore HP unless another feature says so.

## Sphere — Magma

### Furnace-Soul Awakening

**Canonical ID:** `insight.furnace-soul-awakening`

**Prerequisite:** Spirit Awakening, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

You may learn Magma despite its ordinary Path restrictions. If this is a new Sphere for you, gain the normal free talent granted when learning a new Sphere.

When using Magma through Spirit Awakening:

- use Resonance for Magma talents;
- use Wisdom as your Magma key ability;
- your Magma talents may affect spirits, ghosts, Incorporeal creatures, possessing Intruders, soul-bound creatures, and spiritual parasites when those targets are otherwise legal;
- when a Magma talent deals Fire damage to one of those spiritual targets, you may change that Fire damage to Radiant or Psychic damage before resistances and immunities are applied; and
- once per round when a spirit, ghost, or possessing Intruder takes damage from your Magma talent, choose one result until the start of its next turn:
  - it cannot take Reactions;
  - it cannot willingly enter a creature's body;
  - it becomes visible as a heat shimmer and cannot benefit from ordinary Invisible; or
  - it suffers one Heat Pressure effect allowed by the Magma rules.

Furnace-Soul Magma is obvious to Spiritual Sense unless concealed by another Source Rule. Spirit courts, ghost sects, and karmic entities may recognize its pressure.

This Insight does not make ordinary lava spiritual, allow external projection that the Magma talent does not already permit, or authorize soul destruction.

### Lava-Walking Immortal

**Canonical ID:** `insight.lava-walking-immortal`

**Prerequisite:** Magma sphere, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

Gain:

- Immunity to damage from your own Molten Terrain;
- Resistance to Fire damage;
- the ability to cross ordinary lava without sinking or taking ordinary lava damage for up to 1 minute at a time;
- Immunity to ordinary extreme heat; and
- the ability to leave temporary obsidian footholds behind you while crossing lava, each lasting until the start of your next turn.

A lava, magma, or fire effect bypasses these protections only if its Source CL is higher than yours or it is Artifact, Secret, divine, Immortal, or explicitly states that it bypasses Fire Immunity or environmental protection.

### Siege-Magma Adept

**Canonical ID:** `insight.siege-magma-adept`

**Prerequisite:** Magma, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

Once per turn when damaging an object, structure, vehicle, Barrier, or Formation Anchor through a Magma talent, choose one:

• add your Proficiency Bonus to one damage roll;

• deal double damage to an unattended ordinary object or mundane structure;

• ignore ordinary hardness;

• reveal a visible crack, weak point, pressure seam, or load-bearing failure.

This does not automatically destroy artifacts, permanent Formations, Domains, or Realm-defining structures.

### Obsidian Sculptor

**Canonical ID:** `insight.obsidian-sculptor`

**Prerequisite:** Magma, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

When one of your Magma talents ends, choose one affected 10-foot area.

Transform it into one:

• obsidian barrier;

• jagged difficult terrain;

• short staircase;

• defensive ridge;

• Half Cover position;

• simple obsidian platform;

• sealed volcanic cap over a pit, vent, or fissure.

The structure lasts 1 hour unless destroyed.

### Furnace-Heart Discipline

**Canonical ID:** `insight.furnace-heart-discipline`

**Prerequisite:** Magma, CL 4+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have learned not to be consumed by your own heat.

Gain:

• Advantage on saving throws against Burning;

• Advantage on checks to maintain Concentration caused by Fire, Cold, smoke, or environmental heat;

• once per scene when you fail a Constitution saving throw caused by heat, smoke, poison gas, or volcanic pressure, reroll the save and use the new result.

### Volcanic Collateral Control

**Canonical ID:** `insight.volcanic-collateral-control`

**Prerequisite:** Magma, CL 6+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

You can restrain your most destructive terrain.

When creating Molten Terrain, choose a number of creatures up to your Proficiency Bonus.

Those creatures ignore the first damage roll from that terrain before the start of your next turn.

In addition, when a Magma talent would ignite ordinary unattended objects, you may exclude one 10-foot area from incidental ignition.

### Blackglass Executioner

**Canonical ID:** `insight.blackglass-executioner`

**Prerequisite:** Obsidian Glass Scripture or Cinderglass Shards, CL 10+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

Once per turn when a hostile creature takes Slashing damage from your Obsidian Terrain or Cinderglass Shards, choose one:

• reduce its Speed by 10 feet until the start of your next turn;

• prevent Reactions until the start of your next turn;

• mark it with black-glass residue, preventing ordinary Invisible from benefiting it until the start of your next turn;

• add your Proficiency Bonus to the damage.

## Sphere — Metal

### Alloy-Sense Disciple

**Canonical ID:** `insight.alloy-sense-disciple`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Metal Appraisal on a mundane metal object, armor, weapon, gate, lock, chain, bell, coin, or tool, you may also learn whether it is iron, steel, bronze, silver, gold, copper, tin, lead, meteor metal, spirit metal, alloyed, plated, or false.

### Proper Weight of the Tool

**Canonical ID:** `insight.proper-weight-of-the-tool`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

You gain proficiency with Smith's Tools, Jeweler's Tools, Tinker's Tools, or one published weapon profile whose striking head, blade, chain, ammunition, or load-bearing frame is primarily metal.

If you already have the chosen proficiency, gain Advantage on the next ability check involving that proficiency before your next Full Cultivation Session.

This Insight does not grant Blacksmith sphere crafting.

### Hard-Meridian Breathing

**Canonical ID:** `insight.hard-meridian-breathing`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

Once per scene, when you fail a Strength or Constitution saving throw against forced movement, Prone, Grappled, or Restrained, you may spend 1 CP to reroll the save. You must use the new result.

### Clean Edge Discipline

**Canonical ID:** `insight.clean-edge-discipline`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you reduce a creature to 0 HP with a Metal talent, you may choose to make the wound clean and controlled. If you do, you have Advantage on the next Medicine check or social check made to prove that you did not use Forbidden Metal, poison, Blood, Death, or Daemonic Cultivation.

### Conductor's Eye

**Canonical ID:** `insight.conductor-s-eye`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

You can tell whether a visible object or creature is obviously wet, metallic, grounded, insulated, lightning-charged, or conductive without spending an action, unless the condition is deliberately concealed.

### White Tiger Restraint

**Canonical ID:** `insight.white-tiger-restraint`

**Prerequisite:** Metal sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

You gain Advantage on saving throws and ability checks made to resist White Tiger frenzy, execution pressure, forbidden sealing temptation, killing-intent backlash, or another Metal effect that compels needless killing or cruelty.

If you willingly use a Forbidden Metal talent on a helpless unwilling creature, this Insight becomes dormant after that activation. Restore it by completing a Full Cultivation Session devoted to restraint and then sparing, protecting, repairing, or compensating a creature or community harmed by the violation.

### Mine-Warden's Ear

**Canonical ID:** `insight.mine-warden-s-ear`

**Prerequisite:** Metal sphere, Foundation Realm

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you are underground, in a mine, near a forge district, inside a weapon hall, or standing on obvious mineral ground, you gain Advantage on Wisdom (Perception) or Intelligence (Investigation) checks made to notice buried metal, hidden weapon caches, unstable supports, hollow walls, or ore-bearing stone.

### Open the Outer Ore Insight

**Canonical ID:** `insight.open-the-outer-ore-insight`

**Prerequisite:** Metal Sphere, Body Refining, Foundation Realm, Iron Body Only Scripture

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** The Source CL of Open the Outer Ore.

You qualify for **Open the Outer Ore** with Constitution 14 instead of 16. If you gain Open the Outer Ore, reduce each instance of its **First Projection Risk** self-damage by your Proficiency Bonus, minimum 1.

This Insight does not itself grant Open the Outer Ore, remove its other prerequisites, or reduce any other cost or self-damage.

## Sphere — Music

### Battle Musician

**Canonical ID:** `insight.battle-musician`

**Prerequisite:** Body Refining, Music Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Music Source CL, using Body Refining CL for talents used as Embodied Cadence.

Use Constitution as your Music key ability for Cadence talents. You may spend Stamina instead of Cultivation Points for Battle Cadence, Rhythmic Guard, Echoing Step, March of the Immortal Host, and any other Music talent whose printed activation can be performed entirely through voice, breath, heartbeat, footwork, weapon impact, body percussion, or movement and does not require a separate instrument, fixed installation, or external performer.

A qualifying embodied performance may be maintained through those bodily media. If a Music talent expressly requires a particular instrument or installation, this Insight does not remove that requirement.

When you take the Attack action while Keeping the Measure, you may use Opening Phrase once during that turn without spending its Bonus Action. You still pay every resource and cannot use Opening Phrase more times than its own rule permits.

### Perfect Pitch

**Canonical ID:** `insight.perfect-pitch`

**Prerequisite:** Music sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Gain Advantage on checks made to:

identify a voice;

detect imitation;

recognize supernatural sound;

notice concealed listeners;

break silence effects;

analyze musical techniques;

recognize whether a Music effect is mortal, spiritual, Formation-supported, or artifact-supported.

### Spirit Instrument

**Canonical ID:** `insight.spirit-instrument`

**Prerequisite:** Music sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Choose one instrument, bell, drum, trained voice method, weapon expressly built as an instrument, or recorded body-rhythm focus that you possess or can perform.

It becomes spiritually bound to you.

You may summon it to your hand or ready it from within 1 mile as a Bonus Action, unless it is sealed by a stronger effect.

It cannot be damaged by ordinary means while you are conscious.

Once per scene, add +1 to one Music Attack roll or increase your Music Save DC by +1 for one talent before the roll is made.

### Unshaken Rhythm

**Canonical ID:** `insight.unshaken-rhythm`

**Prerequisite:** Music sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Once between Full Cultivation Sessions, when you fail a Concentration saving throw for a Music talent, succeed instead.

When you use this benefit, you may also immediately use Opening Phrase on yourself without spending an action.

### Ensemble Leader

**Canonical ID:** `insight.ensemble-leader`

**Prerequisite:** Music sphere, Shared Measure, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When you use Shared Measure, choose one additional willing creature.

Once per round while Shared Measure is active, when an affected creature misses with an attack, another affected creature may move 5 feet without provoking Opportunity Attacks.

### Resonance Breaker

**Canonical ID:** `insight.resonance-breaker`

**Prerequisite:** Music sphere, Disruptive Harmony or Silence-Breaking Note, CL 10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When you succeed on a Music Check to suppress, disrupt, or identify a Sound, Music, War, Formation, or Spirit effect, gain one benefit:

regain 1 CP;

regain Martial Focus;

grant one ally within 30 feet Temporary HP equal to your Proficiency Bonus;

impose Disadvantage on the next Concentration saving throw made by the disrupted creature before the start of your next turn.

Use Resonance Breaker once per scene.

### Heartstring Physician

**Canonical ID:** `insight.heartstring-physician`

**Prerequisite:** Music sphere, Healing Hymn, CL 10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When a creature receives healing from your Healing Hymn, choose one:

it ends one nonmagical Frightened effect;

it gains Advantage on the next death saving throw before the end of its next turn;

it reduces its Exhaustion penalty for one roll before the end of its next turn, but does not remove Exhaustion;

it gains Temporary HP equal to your Proficiency Bonus.

A creature can benefit from Heartstring Physician only once per scene.

### Bell-and-Formation Custodian

**Canonical ID:** `insight.bell-and-formation-custodian`

**Prerequisite:** Music sphere, Formations sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When designing a Formation, ritual hall, bell tower, drum terrace, concert court, funeral rite, or morale project, use one Music principle you know as a seed concept.

Choose one principle from:

Measure;

Tone;

Chord;

Dissonance;

Echo Performer;

Battle Cadence;

Soul-Sound;

Silence-Breaking Note.

This does not create the project automatically.

The project still requires time, materials, site access, a power source whose Source CL is at least the project's Source CL, and maintenance.

### Song-Soul Oathbearer

**Canonical ID:** `insight.song-soul-oathbearer`

**Prerequisite:** Spirit Awakening, Music sphere, CL10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When one of your Music talents with the **Soul-Sound** tag affects a willing ally, that ally may voluntarily reveal one oath, fear, grief, vow, or emotional burden through symbolic sound.

Record only the category the ally chose and any details it willingly communicates. The sound cannot expose undisclosed memories, compel confession, or reveal thoughts.

If the ally reveals a burden, choose one benefit for that activation:

- it has Advantage on one saving throw against Frightened made before the end of its next turn;
- it gains Temporary Hit Points equal to `2 × your Proficiency Bonus`; or
- you have Advantage on your next Wisdom check made before the scene ends to understand, counsel, reconcile with, or negotiate with that ally concerning the revealed subject.

A single Music activation grants no more than one benefit from this Insight, even if it affects the ally multiple times.

## Sphere — Puppetry

### External Thread Breakthrough

**Canonical ID:** `insight.external-thread-breakthrough`

**Prerequisite:** Body Refining, Puppetry Sphere, CL5+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Dexterity score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for the projected Puppetry permission.

You gain limited Projected Puppetry permission. Your Projected Puppetry range is 30 feet, increasing to 60 feet at CL10.

The permission applies only to puppet vessels you prepared during a Full Cultivation Session or objects bearing a current physical mark made from your blood, hair, tendon-fiber, or body-refining seal. Record each prepared vessel or mark. A removed or destroyed mark ends the permission for that object.

This Insight does not grant general Qi projection, create a puppet action, or waive Puppetry command and line-of-effect rules.

### Puppet Artisan

**Canonical ID:** `insight.puppet-artisan`

**Prerequisite:** Puppetry sphere, proficiency with carpenter's tools, leatherworker's tools, smith's tools, tinker's tools, weaver's tools, or woodcarver's tools, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Charisma score by 1, to the maximum allowed by your current Realm.

During a Full Cultivation Session, prepare one additional basic puppet vessel.

When you repair a broken puppet vessel, reduce the time and material cost by half.

Once between Full Cultivation Sessions, when one of your puppet vessels is reduced to 0 Hit Points, leave it at 1 Hit Point instead.

### Nine-Finger Director

**Canonical ID:** `insight.nine-finger-director`

**Prerequisite:** Puppetry sphere, Two-Body Control, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Charisma score by 1, to the maximum allowed by your current Realm.

When you maintain more than one active puppet vessel, choose one vessel at the start of each turn as your leading hand.

The leading hand gains one of the following benefits until the start of your next turn:

+10 feet Speed;

+2 AC;

Advantage on the next Strength or Dexterity save it makes;

the next Puppet Strike made through it deals extra damage equal to your Proficiency Bonus.

### Severed Thread Recovery

**Canonical ID:** `insight.severed-thread-recovery`

**Prerequisite:** Puppetry sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Charisma score by 1, to the maximum allowed by your current Realm.

When a control thread ends because a vessel leaves range, a line is severed, or the vessel is reduced to 0 Hit Points, regain 1 CP.

Use Severed Thread Recovery once per scene.

At CL 15+, use it twice per scene.

### Stage of Ten Thousand Hands

**Canonical ID:** `insight.stage-of-ten-thousand-hands`

**Prerequisite:** Puppetry sphere, Puppet Theater Domain, CL 12+

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Charisma score by 1, to the maximum allowed by your current Realm.

When you create Puppet Theater Domain, choose one type of stage anchor present in the area: ropes, rafters, trees, banners, pillars, chains, furniture, corpses, puppet debris, roots, or Formation lines.

While at least one chosen anchor remains, your puppet vessels inside the Domain gain +10 feet Speed.

If all chosen anchors are destroyed, moved, burned, severed, or removed, this Insight stops functioning until you create the Domain again.

## Sphere — Qiweaving

### Circuit Scholar

**Canonical ID:** `insight.circuit-scholar`

**Prerequisite:** Qiweaving sphere

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you make an Intelligence check to identify a spell, sphere technique, talisman effect, or Active Qi Pattern, add your Proficiency Bonus if you are not already proficient.

If you are proficient, add double your Proficiency Bonus.

### Calm Hands, Clear Current

**Canonical ID:** `insight.calm-hands-clear-current`

**Prerequisite:** Qiweaving sphere

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you fail a Concentration saving throw for a Qiweaving talent or a technique modified by a Modulation talent, you may reroll the save.

Use the new result.

Once you use this Insight, you cannot use it again until you finish a scene.

### Shared Breath Method

**Canonical ID:** `insight.shared-breath-method`

**Prerequisite:** Qi Bond Package

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you grant Temporary CP to a willing creature with Feed Current, that creature also gains Temporary HP equal to your Proficiency Bonus.

### Counter-Script Reflex

**Canonical ID:** `insight.counter-script-reflex`

**Prerequisite:** Counterweave, CL 5+

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you roll Initiative, you may regain Martial Focus if you know at least one hostile creature in the encounter can use magical or cultivation techniques.

### Stable Wild Meridian

**Canonical ID:** `insight.stable-wild-meridian`

**Prerequisite:** Turbulence Package

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

You have Advantage on saving throws against your own Turbulent Field and against wild Qi or Qi-deviation effects you created.

### Harmonic Memory

**Canonical ID:** `insight.harmonic-memory`

**Prerequisite:** Harmonic Package, CL 10+

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one Harmonic talent you know.

Once between Full Cultivation Sessions, when you activate that talent, reduce its CP cost by 1, minimum 0.

## Sphere — Radiance

### Radiance’s Blessing

**Canonical ID:** `insight.radiance-s-blessing`

**Prerequisite:** Radiance

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, at the start of your turn, regain CP equal to your Proficiency Bonus.

You may use this Insight only if you are conscious and able to circulate Radiance.

The recovery may appear as sunlight entering the meridians, a halo reigniting, a prayer answered by dawn, or inner brilliance refusing to gutter.

### Diamond Light Body

**Canonical ID:** `insight.diamond-light-body`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Radiance talents used through this Insight.

You may learn the Radiance Sphere through the Diamond Light Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your Glow may originate from skin, bones, eyes, scars, breath, or meridians. This origin does not make the Glow invisible, grant additional range, or prevent it from being suppressed with the originating anatomy.

### Solar Heart

**Canonical ID:** `insight.solar-heart`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Radiant damage.

When you use a Radiance talent that restores HP, grants Temporary HP, or reduces damage, add your Proficiency Bonus to one healing, Temporary HP, or damage-reduction roll.

If the target is currently Charmed, Frightened, possessed, or affected by corruption, it also gains Advantage on its next saving throw against that effect before the end of your next turn.

### Unhidden Path

**Canonical ID:** `insight.unhidden-path`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Your Revealing Light and Consecrated Lantern become better at showing what refuses dawn.

Gain the following benefits:

you have Advantage on checks made to notice possession signs, spiritual contamination, undead traces, concealed writing, and corruption marks while in your own Bright Light;

when you apply Dawnmark to a creature, you may immediately make one Wisdom (Insight), Intelligence (Investigation), or Cultivation Check to determine whether it is Unclean;

your Glow can be made visible only to creatures you designate.

### Dawn Physician

**Canonical ID:** `insight.dawn-physician`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Gentle Dawn or Purifying Radiance on a willing creature, you may also grant Temporary HP equal to your Proficiency Bonus.

Once per scene, when you use Purifying Radiance to end Poisoned, Charmed, or Frightened, you may use it as a Bonus Action instead of an Action.

### Demon-Revealing Eyes

**Canonical ID:** `insight.demon-revealing-eyes`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You may use Unhidden Stain Sight as part of the same Action when you use Radiance Strike against a creature.

If the Radiance Strike hits and the target is Unclean, you learn that it is Unclean even if the check would fail. You do not learn the source unless the check succeeds.

### Dawn-Ward Adept

**Canonical ID:** `insight.dawn-ward-adept`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Dawn Ward, choose one:

increase the damage reduction by 1d8;

the protected creature gains Advantage on its next saving throw against Charmed, Frightened, possession, or corruption before the end of your next turn;

if the damage is reduced to 0, the attacker becomes Dawnmarked until the start of your next turn.

### Thousand-Lamp Meditation

**Canonical ID:** `insight.thousand-lamp-meditation`

**Prerequisite:** Radiance, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

During a Full Cultivation Session, you may maintain a circle of harmless dawn lamps.

Choose up to a number of willing creatures equal to your Proficiency Bonus.

Each chosen creature gains one of the following benefits until it completes a 10-minute recovery procedure:

Advantage on the first saving throw it makes against Frightened;

Advantage on the first saving throw it makes against Charmed;

Advantage on the first saving throw it makes against possession or spiritual contamination;

Temporary HP equal to your Proficiency Bonus.

A creature can benefit from only one Thousand-Lamp Meditation at a time.

## Sphere — Sabers

### Dao Guard Veteran

**Canonical ID:** `insight.dao-guard-veteran`

**Prerequisite:** Sabers sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you use Guard-Cutting Parry, reduce the incoming damage by an additional 2.

### Red Sash Pursuer

**Canonical ID:** `insight.red-sash-pursuer`

**Prerequisite:** Sabers sphere, Red Trail Pursuit

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When Red Trail Pursuit lets you move, increase that movement by 5 feet.

### Butcher’s Mercy

**Canonical ID:** `insight.butcher-s-mercy`

**Prerequisite:** Sabers sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain proficiency in Medicine or Intimidation.

When you bind a Saber Wound, you may end one Saber Wound without a roll if the target is willing or helpless.

### Cavalry Cut Familiarity

**Canonical ID:** `insight.cavalry-cut-familiarity`

**Prerequisite:** Sabers sphere, Cavalry Crescent Method

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to remain mounted, leap from a saddle, cut while moving on a mount, or identify cavalry saber doctrine.

### Shield-Breaking Eye

**Canonical ID:** `insight.shield-breaking-eye`

**Prerequisite:** Sabers sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you Study a creature with a shield, guard stance, or obvious defensive posture, you may learn whether Strength, Dexterity, or Wisdom is most likely to resist your Sabers pressure.

### Execution Restraint

**Canonical ID:** `insight.execution-restraint`

**Prerequisite:** Sabers sphere, Execution Saber Method

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once per scene, when you would add bonus damage against a Bloodied target through Sabers, you may forgo that bonus to impose Disadvantage on the target’s next Opportunity Attack before the start of your next turn.

### Crescent Projection Student

**Canonical ID:** `insight.crescent-projection-student`

**Prerequisite:** Sabers sphere, Qi Cultivation Path

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you use a projected Sabers talent with a range or area, increase its range or area by 5 feet once per scene.

### Named Blade Listener

**Canonical ID:** `insight.named-blade-listener`

**Prerequisite:** Sabers sphere, Spirit Awakening, one named saber focus

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

### Blade-Listening Rite

**Action Type:** Cultivation Procedure  
**Time:** 10 uninterrupted minutes while holding or touching your named saber focus  
**Limit:** Once per scene for each named saber

Ask one question concerning a battle, execution, oath, fear, pursuit, wielder, or target connected to the saber within the last 7 days.

The saber answers through one symbolic omen chosen from the following forms:

- **Direction:** toward, away, above, below, encircling, or nowhere.
- **Pressure:** safe, threatened, dominant, wounded, restrained, or absent.
- **Relationship:** hunter, quarry, ally, betrayer, witness, or stranger.
- **Outcome:** victory, escape, capture, death, interruption, or unresolved.
- **Emotion:** duty, fear, hatred, grief, loyalty, or hunger.

The omen must reflect information the saber genuinely witnessed, carried, spiritually recorded, or received through its recognized bond. If it has no qualifying information, the answer is **silent**. A sealed, altered, or higher-authority memory may instead answer **obscured**.

The rite does not provide names, exact locations, complete conversations, hidden statistics, or facts the saber never perceived.

## Sphere — Sand

### Sand-Born Footwork

**Canonical ID:** `insight.sand-born-footwork`

**Prerequisite:** Sand sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

You gain the following benefits:

Sand Terrain you create is never Difficult Terrain for you.

Once per scene, when a creature misses you with an Opportunity Attack, you may create one Shallow Sand Terrain square in a space adjacent to you.

You have Advantage on Dexterity (Stealth) checks made to hide in dusty, sandy, desert, ruin, or dry-earth environments.

### Gourd of the First Dune

**Canonical ID:** `insight.gourd-of-the-first-dune`

**Prerequisite:** Sand sphere, Hidden Cache of Grains or Gourd-Bound Sand Scripture, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

Your prepared sand cache becomes a minor cultivation vessel.

Once per scene, you may use Gather Sand without spending CP even if no Sand Source exists. If you already could do so, you instead create two additional 5-foot squares of Sand Terrain with that use.

If your vessel is lost or broken, recreating it requires a 1-hour reconstruction procedure and access to dry mineral material.

### Glass-Cutting Palm

**Canonical ID:** `insight.glass-cutting-palm`

**Prerequisite:** Sand sphere, Glass Edge Scripture, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you hit a creature with an unarmed strike or melee weapon attack while both you and the target are touching Sand Terrain or glass you created, you may deal additional Piercing damage equal to your Proficiency Bonus.

You may use this benefit once per turn.

At CL 15+, if the target is Buried, the additional damage becomes equal to your Proficiency Bonus + your key ability modifier.

### Dune Court Architect

**Canonical ID:** `insight.dune-court-architect`

**Prerequisite:** Sand sphere, Court of Ten Thousand Dunes, CL 12+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you design a Formation, battlefield, desert fortress, burial pit, glass garden, caravan route, training ground, or ambush site, you may use one Sand technique as the conceptual seed.

The project may include one Sand-themed benefit, such as:

warning tracks;

collapsing dunes;

sand-hidden vault doors;

glass alarm chimes;

concealed burial traps;

heat-mirage screens;

quicksand corridors;

sand-memory witness zones.

This Insight does not create the project automatically. It requires materials, time, anchors, labor, maintenance, and at least one vulnerability chosen from exposed Anchor, water saturation, high wind, excavation, disrupted maintenance, or a weakness printed by the project rules.

### Dune-Sovereign’s Mercy

**Canonical ID:** `insight.dune-sovereign-s-mercy`

**Prerequisite:** Sand sphere, Sand-Sovereign Incarnation, CL 15+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use a Sand Burial talent, you may choose any number of creatures affected by it to be preserved rather than crushed.

A preserved creature does not take Scouring or compression damage from that talent, has Advantage on death saving throws while Buried by you, and can breathe through a narrow thread of sand for up to 1 minute.

In addition, once between Full Cultivation Sessions when you would be reduced to 0 Hit Points while touching Sand Terrain you control, you may fall apart into sand and re-form in an unoccupied Sand Terrain square within 30 feet. You instead drop to 1 Hit Point. You cannot use this benefit if you are Incapacitated before the damage resolves, sealed in a Barrier that blocks Sand movement, or prevented from transforming.

## Sphere — Sect Stewardship

### Proper Seniority

**Canonical ID:** `insight.proper-seniority`

**Prerequisite:** Sect Stewardship, CL 4+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You instinctively know how to address seniors, peers, juniors, guests, servants, deacons, elders, and strangers without causing unnecessary offense.

Gain proficiency in Insight or Persuasion. If you already have proficiency, gain a flat +2 bonus to checks with the chosen skill when navigating hierarchy, etiquette, or institutional duty.

Once between Full Cultivation Sessions, when a social scene would worsen because you used the wrong title, gesture, bow, seating order, or speaking order, you may reroll the check that caused the mistake.

### Ledger-Bound Memory

**Canonical ID:** `insight.ledger-bound-memory`

**Prerequisite:** Sect Stewardship, CL 4+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You keep records that other people can actually use.

You always know where your own mission writs, receipts, duty notes, petitions, and contribution records are unless they are stolen, destroyed, or sealed by a stronger effect.

When you make a Sect Check involving records you personally maintained, roll one Merit Die and add it without expending it. You can use this benefit once between Full Cultivation Sessions.

### Outer Gate Beloved

**Canonical ID:** `insight.outer-gate-beloved`

**Prerequisite:** Sect Stewardship, CL 4+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You are known for treating low-status people as people.

Servants, workers, outer disciples, farmers, cooks, porters, and clerks who have heard of you begin one step friendlier unless you or your allies have harmed them.

When you Petition the Hall through low-status channels, you may include one extra creature per point of your Proficiency Bonus.

### Mission-Born Reputation

**Canonical ID:** `insight.mission-born-reputation`

**Prerequisite:** Sect Stewardship, Notice Board Reader, CL 8+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Your completed missions speak before you do.

When you complete a mission or Duty with witnesses and file a clean report, choose one institution involved. For the next 30 days, you have Advantage on one Sect Check there when requesting a similar mission, asking for related information, or defending the truth of your report.

You may maintain a number of active Mission-Born Reputations equal to your Proficiency Bonus.

### Hall Insider

**Canonical ID:** `insight.hall-insider`

**Prerequisite:** Sect Stewardship, Hall Apprenticeship, CL 8+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one hall for which you have Hall Apprenticeship.

Your Merit Die increases by one step, maximum d8, for Sect Stewardship checks made inside that hall or directly involving its procedures.

When you spend one Merit Die to Petition that hall, treat a result of 1 as a 3.

You may take this Insight multiple times, choosing a different hall each time.

### Deacon’s Patience

**Canonical ID:** `insight.deacon-s-patience`

**Prerequisite:** Sect Stewardship, CL 12+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You have learned that most crises become worse when the first person with authority panics.

When you fail a Sect Check related to mediation, emergency organization, audit, records, logistics, or duty assignment, you may spend one Merit Die after seeing the result and add it to the roll, even if you already spent a Merit Die on that check.

You can use this Insight once between Full Cultivation Sessions.

### Branch Founder

**Canonical ID:** `insight.branch-founder`

**Prerequisite:** Sect Stewardship, Courtyard Grant or Department Ledger, CL12+

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you establish a courtyard, classroom, workroom, small hall, field office, or branch project, reduce its ordinary work time by 25 percent.

The completed project begins with one loyal mundane assistant chosen from clerk, worker, student, caretaker, porter, cook, messenger, or guard. Record the assistant's name, role, and one relevant proficiency. The assistant uses a Commoner or Guard stat block of Source CL 1, is not a combat companion, does not gain Path features, and will not enter an active dangerous scene unless assigned protection and given a clear noncombat duty.

## Sphere — Sniper

### Patient Trigger

**Canonical ID:** `insight.patient-trigger`

**Prerequisite:** Sniper sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you Ready a Snipe Shot, you may keep Martial Focus if the triggering event does not occur.

Once per scene, when the trigger occurs and your Readied Snipe Shot hits, you may apply Deadly Aim even if the attack did not have Advantage.

### Ricochet Savant

**Canonical ID:** `insight.ricochet-savant`

**Prerequisite:** Bouncing Shot, CL 6+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When using Bouncing Shot, you may choose the bounced surface after making the attack roll but before knowing whether the attack hits.

Once per scene, if a Bouncing Shot misses, you may make a Scoot Shot against one unattended Tiny object within 10 feet of the missed target.

### Spotter’s Thread

**Canonical ID:** `insight.spotter-s-thread`

**Prerequisite:** Sniper sphere, CL6+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

As a Bonus Action, choose one willing ally you can see or hear. Until the start of your next turn, if that ally can perceive a target and communicate its exact occupied space to you, treat the ally's perception as sufficient for Rangefinding Breath, Star-Scraper Line, or another Sniper talent that requires exact location. Normal range, line of effect, concealment, and cover still apply.

At CL11, the communication may pass through one linked spirit, Formation, paired token, signal flag, or Forged Technique that expressly transmits exact location. The transmitting link must be active, within its printed range, and not suppressed.

### Quiet After the Shot

**Canonical ID:** `insight.quiet-after-the-shot`

**Prerequisite:** Sniper sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you make a Snipe Shot while Hidden or behind cover and the attack misses, you do not reveal your location automatically unless the target or observers can perceive the projectile’s origin, hear the shot, or otherwise trace it.

When the attack hits, you may expend Martial Focus to impose Disadvantage on the first Wisdom (Perception) or Intelligence (Investigation) check made before the end of the next round to locate you by the shot.

### Trap-Sniper Method

**Canonical ID:** `insight.trap-sniper-method`

**Prerequisite:** Trap Technician, CL 8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

You gain proficiency with thieves’ tools. If you already have it, you gain Expertise with thieves’ tools.

When using Trap Technician, you may target a trap component behind Half Cover without penalty, and you may use Deadly Aim on the attack if you have Advantage from careful study or scouting.

### One Breath, One Line

**Canonical ID:** `insight.one-breath-one-line`

**Prerequisite:** Perfect Shot, CL 10+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Perfect Shot, you may also ignore Disadvantage from one of the following for that attack:

long range;

Prone attacker;

light obscurement;

a hostile creature within 5 feet of you;

firing through a narrow opening.

You must still have a legal target and route.

### Formation Piercer

**Canonical ID:** `insight.formation-piercer`

**Prerequisite:** Formation Anchor Shot, CL 10+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to identify exposed formation anchors, ward pins, talisman nodes, and similar physical foci.

When you hit such a focus with a Snipe Shot, add your Proficiency Bonus to the damage or suppression check.

### Heaven’s Distance Student

**Canonical ID:** `insight.heaven-s-distance-student`

**Prerequisite:** Star-Scraper Line, CL 12+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When using Star-Scraper Line, you no longer impose Disadvantage if you have an Aimed Line from a spotter, mark, formation, divination, or direct perception.

Once between Full Cultivation Sessions, you may use Star-Scraper Line without spending your Bonus Action.

## Sphere — Sound

### Bell-Bone Adept

**Canonical ID:** `insight.bell-bone-adept`

**Prerequisite:** Body Refining, Sound Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Body Resonance Strike and Thundering Voice used through this Insight.

Use Constitution as your Sound key ability. Learn Body Resonance Strike if you do not already know it; if Sound is a new Sphere, also gain the normal free talent under the new-Sphere rule. You may spend Stamina instead of Cultivation Points for Body Resonance Strike and Thundering Voice.

Once per round, reduce one instance of Thunder damage applied to you by your Proficiency Bonus after Resistance and before other flat reductions. This is damage reduction, not Resistance, and cannot reduce damage below 0.

### Harmonic Analyst

**Canonical ID:** `insight.harmonic-analyst`

**Prerequisite:** Sound sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain Advantage on checks to identify:

brittle objects;

hollow walls;

hidden bells or alarms;

damaged barriers;

unstable bridges;

resonant Formation Anchors;

creatures using voice-based magic.

Once per scene, when you succeed on Read the Vibration, ask one additional question from its list.

### Silent Foundation

**Canonical ID:** `insight.silent-foundation`

**Prerequisite:** Dampen Sound or Muffle Footfall, CL 5+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, when you would fail a Dexterity (Stealth) check because of sound, reroll the check.

If you are inside your own Dampen Sound or True Silence area, add your Proficiency Bonus to the reroll.

### Counter-Chant Specialist

**Canonical ID:** `insight.counter-chant-specialist`

**Prerequisite:** Counter-Chant, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Counter-Chant:

increase range by 30 feet;

if the opposed check succeeds, regain 1 CP;

if the target bears your Resonance, it has Disadvantage on its opposing check.

### World-Ringing Bell Keeper

**Canonical ID:** `insight.world-ringing-bell-keeper`

**Prerequisite:** Resonant Shatter, CL 10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You may prepare one large bell, gong, drum, cliff-face, shrine chime, gate bell, or resonant stone during downtime.

While within 1 mile of that prepared object:

Thousand-Pace Call can target it without CP cost once per journey segment;

Sound talents used to defend the site gain +1 to their Save DC;

Read the Vibration can detect major impacts, gate openings, battle, or structural damage affecting the site.

This Insight does not create a permanent Formation by itself.

### Soul-Hearing Listener

**Canonical ID:** `insight.soul-hearing-listener`

**Prerequisite:** Soul-Echo Hearing, Spirit Awakening, CL10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use **Soul-Echo Hearing**, choose one willing creature whose natural or spiritual voice you have heard within the last day. Establish a **Listening Link** with that creature.

The link lasts until you establish it with another creature, the creature withdraws consent while able to communicate that choice, or a Source Rule severs it.

While the linked creature is within 1 mile and on the same plane, you become aware when its state changes into or out of any of the following:

- **Possessed:** It is under unwilling Possession or coercive Hosting.
- **Silenced:** It is unable to produce its normal voice because of a condition, restraint, injury, Silence effect, or spiritual suppression.
- **Screaming:** It audibly or spiritually cries out because of immediate pain, terror, soul harm,.
- **Fallen:** It is reduced to 0 Hit Points.

You learn the state and the direction of the link, but not exact distance or location.

A ward, Domain, planar boundary, or concealment effect can block the link. If the blocking source has lower Source CL than the higher of your Sound and Spirit Awakening Source CL, you know the link is blocked and its direction immediately before the block. Otherwise, you know only that contact was lost.

The link does not transmit speech, thoughts, ordinary emotions, damage details, or continuous sensory information.

## Sphere — Space

### Spatial Meridian Body

**Canonical ID:** `insight.spatial-meridian-body`

**Prerequisite:** Body Refining, CL4+, Constitution 15+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for self-only Fold Arts used through this Insight.

You may learn the Space Sphere through the Spatial Meridian Body variant. Use Constitution as its key ability. If this is a new Sphere, gain the normal free talent.

You may spend Stamina instead of Cultivation Points on Fold Arts that target only you and your worn or carried equipment. A Fold Art targeting another creature, unattended object, area, Anchor, or destination beyond its normal permissions uses its ordinary resource and key ability unless another rule says otherwise.

### Anchored Soul

**Canonical ID:** `insight.anchored-soul`

**Prerequisite:** Space sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

You gain Advantage on saving throws against:

teleportation imposed against your will;

banishment;

forced entry into a pocket space;

possession through spatial displacement;

planar travel imposed against your will.

Once between Full Cultivation Sessions, when you are teleported unwillingly, you may return to your previous space immediately after the effect resolves if that space is unoccupied and within 60 feet.

### Spatial Artisan

**Canonical ID:** `insight.spatial-artisan`

**Prerequisite:** Space sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Your spatial infrastructure improves.

Benefits:

Spatial Storage capacity doubles.

Creating Spatial Anchors takes 1 minute instead of 10 minutes.

Anchor Gate setup time is halved.

You may maintain one additional Spatial Anchor.

### Folded Reflexes

**Canonical ID:** `insight.folded-reflexes`

**Prerequisite:** Space sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Once per scene, use Fold Step as a Reaction when targeted by an attack.

If your new position leaves the attack’s range, the attack misses.

This is separate from Blink Guard and does not require Blink Guard.

### Gatekeeper’s Eye

**Canonical ID:** `insight.gatekeeper-s-eye`

**Prerequisite:** Space sphere, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Your Spatial Awareness range increases to 120 feet.

When you actively inspect a portal, anchor, pocket entrance, extradimensional storage, or teleportation residue, you may learn one additional fact on a success.

You also gain Advantage on checks made to identify whether a gate leads somewhere dangerous, trapped, unstable, or sealed.

### No Road Behind Me

**Canonical ID:** `insight.no-road-behind-me`

**Prerequisite:** Space sphere, CL 10+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

When you use Fold Step, Short Swap, Blink Guard, Close Gate, or another Space effect to leave a space, you may erase the visible trace of your departure.

Until the start of your next turn, creatures have Disadvantage on checks made to track your immediate spatial path unless they possess Spatial Awareness, Divination, Stars, or an equivalent sense.

Once between Full Cultivation Sessions, you may also use Cut the Road Behind You without spending CP.

## Sphere — Spirit Companions

### Courteous Medium

**Canonical ID:** `insight.courteous-medium`

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per spirit per scene, when you first address it respectfully after successfully reading its Spirit Nature, reduce the DC of your next social check made toward that spirit during the scene by 2.

If, before making the check, you provide one Offering that matches the spirit's recorded appetite, Minor Offering, custom, office, or acknowledged need, reduce the DC by 5 instead.

An Offering qualifies only if it is actually delivered or made available on the terms stated. The same object, promise, service, or sacrifice cannot qualify simultaneously for multiple spirits unless each spirit's record permits shared use.

This Insight improves the opening position; it does not force cooperation, waive a Taboo, erase Bond Strain, or make an insulting or impossible request acceptable.

### Ethical Exorcist

**Canonical ID:** `insight.ethical-exorcist`

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on the Cultivation Check for **Break the Cruel Seal**, **Exorcist's Mercy**, or **True Name Mercy** when your declared purpose is one of the following:

- free a spirit from coercive control;
- calm a maddened, frightened, wounded, or contaminated spirit;
- separate a spirit and Host without destroying either;
- release a spirit to a legal vessel, manifestation, afterlife route, reincarnation route, shrine, or other state accepted by its Source Rule.

If another Source Rule expressly says it uses one of those Spirit Companions procedures, the Advantage applies to that use as well.

The benefit does not apply when your actual purpose is enslavement, extraction of involuntary service, destruction of a Complete Soul, theft of a spirit's vessel or Name, or conversion of an unwilling spirit into your companion.

### Inner Vessel Discipline

**Canonical ID:** `insight.inner-vessel-discipline`

**Prerequisite:** Spirit Companions Sphere, Body Refining

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Source CL:** The Source CL of the Hosted spirit expression, using Body Refining CL only where the expression is expressly used through your body.

Choose one spirit currently joined to you through a legal Hosting Bond and record it as your **Inner Vessel spirit**.

When you use one of that spirit's body-bound Nature Expressions, you may use Constitution as the expression's key ability. The expression must be self-only, touch-only, weapon-bound, blood-bound, body-bound, or modify your natural weapons, anatomy, movement, senses, skin, blood, breath, organs, or embodied cultivation.

This Insight does not authorize external projection, create an additional action, or let Constitution replace the spirit's own ability when it acts independently.

You may designate a different legally Hosted spirit after a Full Cultivation Session and recording the new Hosting terms, or immediately when the previous Hosting Bond ends and a new legal Hosting Bond is formed.

### Spirit-Broker Reputation

**Canonical ID:** `insight.spirit-broker-reputation`

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

Use the following **Spirit Negotiation Position** ladder:

`Hostile → Unwilling → Wary → Open → Favorable`

When a spirit knows your reputation for keeping spirit covenants, begin its first negotiation with you during a scene one position more favorable than its ordinary starting position, to a maximum of Favorable.

A spirit knows your reputation if one of the following is true:

- it has dealt with you before;
- a spirit, shrine, court, ancestor, broker, sect, or witness it trusts has vouched for you;
- your relevant office, seal, lineage, or public covenant record is recognized in its community.

### Broken Reputation

If you have an unresolved breach of a Covenant Bond, Offering, Taboo, spirit-court judgment, or other recorded spirit agreement, this Insight provides no benefit to spirits that know of that breach.

Restore the benefit for that breach by completing its recorded Restitution. If no Restitution was recorded, complete all three:

1. acknowledge the breach to the harmed spirit or its recognized representative;
2. provide the missed Offering, compensation, service, or release that reasonably repairs the terms; and
3. receive acceptance from the harmed spirit, its lawful successor, or a recognized neutral spirit authority.

This Insight never changes a spirit's consent, core Nature, sworn hostility, or response to an impossible request.

### Vessel Artisan

**Canonical ID:** `insight.vessel-artisan`

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to prepare, repair, disguise, identify, or reinforce a spirit vessel, shrine, charm, mask, weapon, puppet, reliquary, or Spiritual Anchor.

### Craft Minor Vessel

**Action Type:** Downtime Procedure  
**Time:** 8 hours of work  
**Materials:** ordinary clay, wood, stone, cloth, metal, glass, bone, wax, inked paper, or another material listed in the spirit's Nature record; no rare cultivation material is required

Create one Tiny or Small minor vessel whose material matches at least one tag in the willing minor spirit's Nature record or one Minor Spirit Agreement.

Record:

- the vessel's object type and material;
- the spirit or Nature it is intended to receive;
- its entrance and release procedure;
- one visible or spiritual sign that it is occupied; and
- its ordinary object AC and Hit Points. If no object rule supplies them, use AC 12 and Hit Points equal to `5 + 2 × your Proficiency Bonus`.

The vessel:

- can shelter, transport, conceal, or localize its recorded spirit;
- does not grant a combat body, attack, independent turn, Nature Expression, resistance, or Companion statistics;
- cannot contain an unwilling Complete Soul without a legal Binding source; and
- expels its occupant into the nearest legal state if destroyed, unless another Source Rule governs destruction.

You may repair a minor vessel during 1 hour of work with ordinary materials, restoring all of its Hit Points if its spiritual structure has not been destroyed by a higher-authority effect.

### Shared Breath Guardian

**Canonical ID:** `insight.shared-breath-guardian`

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

**Action Type:** Reaction  
**Trigger:** A spirit joined to you by a Covenant Bond, Hosting Bond, Major Spirit Bond, or full Spirit Companion relationship and within 30 feet would take damage

Transfer half of the triggering damage to yourself.

Resolve the transfer in this order:

1. Determine the damage after modifiers that apply to the original damage source but before applying the spirit's Resistance, Immunity, or Vulnerability.
2. If the spirit is Hosted in you, reduce that damage by your Proficiency Bonus, minimum 0.
3. Divide the remaining damage in half. You receive the smaller half, rounded down; the spirit receives the remainder.
4. Apply your own Resistance, Immunity, and Vulnerability to your share and the spirit's to its share.

The transferred share retains its original damage type and source. It is not a new attack or activation, cannot trigger this Insight again, and cannot be redirected a second time unless a Source Rule expressly permits recursive transfer.

If either recipient is not a legal target for the original damage because of planar separation or a higher-authority ward, the transfer fails and the spirit takes the original damage normally.

## Sphere — Stars

### Star-Blooded Body

**Canonical ID:** `insight.star-blooded-body`

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL for Stars talents used through this Insight.

You may learn the Stars Sphere through the Star-Blooded Body variant. Use Constitution as its key ability and Stamina for its Cultivation Point costs. If this is a new Sphere, gain the normal free talent.

Your Star Anchors must be physical marks, scars, weapons, armor plates, star-metal nails, bone inscriptions, or visible talismanic points unless another Source Rule permits a different Anchor. Record the Anchor's position and destruction procedure.

### Celestial Navigator

**Canonical ID:** `insight.celestial-navigator`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Celestial Bearings no longer costs CP, lasts until your next Full Cultivation Session, and may affect twice as many creatures.

In addition, Celestial Bearings grants Advantage on checks made to navigate through portals, strange realms, distorted landscapes, moving islands, mist seas, and false-sky territories.

### Star-Walking Immortal

**Canonical ID:** `insight.star-walking-immortal`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Starpath Step range increases by 20 feet. Once per scene, when you use Starpath Step, you may carry one willing creature of your size or smaller.

You may end Starpath Step adjacent to one of your active Star Anchors within range without ordinary visibility, but the path cannot cross Total Cover or a spatial barrier.

### Comet Adept

**Canonical ID:** `insight.comet-adept`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once per turn when you deal Radiant, Force, or Cold damage through a Stars talent, add your Proficiency Bonus to one damage roll.

If the target bears your Stellar Mark, you may also push it 5 feet.

### Constellation Keeper

**Canonical ID:** `insight.constellation-keeper`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You may maintain two additional Star Anchors. Astral Survey range increases to 20 miles. When one of your Star Anchors is destroyed, you immediately know which anchor was destroyed and the direction from you.

### Astral Cartographer

**Canonical ID:** `insight.astral-cartographer`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you create a Star Map, you may include one layer of supernatural information you have personally confirmed, such as known portals, known Star Anchors, known ley lines, known sect boundaries, known forbidden zones, or known celestial disturbances.

Your Star Maps have Advantage on checks made to resist being falsified by ordinary illusion or mundane forgery.

### Seven-Star Battle Rhythm

**Canonical ID:** `insight.seven-star-battle-rhythm`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Starpath Step or Seven-Star Step, your next attack before the end of your turn gains +1 to hit. If the attack hits a creature bearing your Stellar Mark, you may move 5 feet without provoking Opportunity Attacks.

### Cold Star Heart

**Canonical ID:** `insight.cold-star-heart`

**Prerequisite:** Stars, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You gain resistance to Cold damage. When you deal Cold damage with a Stars talent, you may ignore resistance to Cold damage once per turn.

If a creature is immune to Cold damage, this Insight does not bypass the immunity unless a Secret effect or Forged Technique says otherwise.

### Name the Distant Enemy

**Canonical ID:** `insight.name-the-distant-enemy`

**Prerequisite:** Stars, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you successfully apply Stable Stellar Mark to a creature, you may learn one of the following:

its current direction from you;

whether it is on the same plane;

whether it is under a teleportation, invisibility, or concealment effect;

whether it has damaged you or an ally during the current scene;

whether it is protected by a Star Anchor, Formation, or spatial ward.

You can use this Insight a number of times equal to your Proficiency Bonus between Full Cultivation Sessions.

### Observatory Heir

**Canonical ID:** `insight.observatory-heir`

**Prerequisite:** Stars, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You may treat one permanent observatory, sect tower, star platform, or celestial altar you helped create as one of your Star Anchors without counting against your normal limit.

At the end of a Full Cultivation Session there, choose one Stars talent you know with a CP cost of 2 or less. You may use that talent once before your next Full Cultivation Session without spending CP.

## Sphere — Talismans

### Talisman Body

**Canonical ID:** `insight.talisman-body`

**Prerequisite:** Body Refining, Talismans Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Talismans Source CL, using Body Refining CL when paid with Stamina through this Insight.

You may inscribe temporary talismans on your skin, scars, armor, nails, bones, weapon wraps, or clothing seams. A skin talisman takes 1 hour to inscribe, uses normal materials, and remains until activated, destroyed, removed, or you complete your next Full Cultivation Session.

Skin talismans do not count against your Prepared Talisman Limit, but you may maintain no more than your Proficiency Bonus at once. They cannot be transferred to another creature.

When you take damage, you may use your Reaction to activate one skin talisman whose printed activation is a Reaction or defensive response. You may spend Stamina instead of Cultivation Points for that activation. The talisman still obeys all target, trigger, material, and Source CL rules.

### Talisman Thief

**Canonical ID:** `insight.talisman-thief`

**Prerequisite:** Talismans sphere or Scoundrel sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

As a Bonus Action, attempt to steal one accessible talisman within 5 feet.

Make a Dexterity (Sleight of Hand) check contested by the target’s Wisdom (Perception) or Dexterity (Sleight of Hand), target’s choice.

On a success, you take the talisman if you have a free hand or cause it to fall into an unoccupied space within 5 feet.

This does not let you safely activate, identify, or suppress the talisman.

### Formula Archivist

**Canonical ID:** `insight.formula-archivist`

**Prerequisite:** Talismans sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You gain one additional Common formula and one additional Uncommon formula.

When you discover a formula in play, reduce reverse-engineering time by half.

### Hidden Sleeve Adept

**Canonical ID:** `insight.hidden-sleeve-adept`

**Prerequisite:** Hidden Sleeve Preparation, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase your Prepared Talisman Limit by 1.

Once per scene, when you roll Initiative, you may immediately ready one unprepared talisman you are carrying.

### Counterseal Reflex

**Canonical ID:** `insight.counterseal-reflex`

**Prerequisite:** Seal Breaker, CL 10+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you suppress a talisman with Seal Breaker, you may immediately use Read the Script against that talisman without an Action.

If you learn its family, you have Advantage on the next saving throw you make against a talisman of that family before your next Full Cultivation Session.

## Sphere — Thread

### Silk-Reeling Foundation

**Canonical ID:** `insight.silk-reeling-foundation`

**Prerequisite:** Thread sphere.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Your body is trained in coiling silk force. When you use Draw the Line or Threaded Strike, you may move 5 feet once per round without provoking Opportunity Attacks from the target of that feature.

### Hidden Spool Discipline

**Canonical ID:** `insight.hidden-spool-discipline`

**Prerequisite:** Thread sphere.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You can hide thread tools on your body even under inspection. You have advantage on Dexterity (Sleight of Hand) checks to conceal thread, needles, thin wire, hooks, or small spools. Once between Full Cultivation Sessions, if deprived of equipment, you may reveal that you retained enough thread stock to use one mundane Thread talent.

### Threaded Weapon Adept

**Canonical ID:** `insight.threaded-weapon-adept`

**Prerequisite:** Thread sphere and proficiency with at least one melee or thrown weapon.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one weapon you are proficient with. It is always thread-eligible for you. Once per turn when you use Threaded Strike with that weapon, you may choose both Follow the Sleeve and Draw the Guard instead of one benefit.

### Meridian Needle Training

**Canonical ID:** `insight.meridian-needle-training`

**Prerequisite:** Thread sphere and Surgeon’s Stitch.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You can use healer’s kit, acupuncture needles, tailor’s tools, or weaver’s tools as a focus for Thread healing talents. When you use Surgeon’s Stitch, the target may reroll one Hit Die result of 1 and must use the new result.

### Red Thread Sensitivity

**Canonical ID:** `insight.red-thread-sensitivity`

**Prerequisite:** Thread sphere and Spirit Awakening, Karma sphere, Heartbinder, Knot Weaver, or another printed Source Rule authorizing relationship perception

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Action Type:** Action  
**Range:** 60 feet  
**Targets:** Two creatures you can see

Study the relationship threads between the targets. Learn whether at least one genuine, active relationship recorded through kinship, oath, debt, affection, command, mentorship, ownership, custody, hostility, worship, or a Spirit Bond from the following list connects them:

- affection or loyalty;
- debt or obligation;
- rivalry or hatred;
- fear or coercive dependence;
- oath, vow, contract, or formal duty;
- familial, ancestral, teacher-disciple, sect, office, or companion bond.

If more than one category applies, learn the category with the strongest current spiritual pressure; if tied, learn all tied categories.

You do not learn exact terms, memories, hidden names, who is morally correct, or whether either creature intends to honor the relationship.

If the relationship is concealed by a ward, Fate effect, false thread, Secret, Domain, or another cultivation source, make a Thread Cultivation Check against that source's Cultivation Save DC. On a success, read the relationship normally and learn that it was concealed. On a failure, learn only **Obscured Relationship**.

This Insight detects genuine relationships; it does not create consent or let you perceive a relationship that no longer exists merely because it existed in the past.

### Cut the Snare

**Canonical ID:** `insight.cut-the-snare`

**Prerequisite:** Thread sphere.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you are Grappled, Restrained, or physically tied, you may use a Bonus Action to make a Dexterity, Strength, or Cultivation Check against the effect’s DC. On a success, you end one physical binding effect on yourself. Once you succeed with this Insight, you cannot use it again until you complete a 10-minute recovery procedure.

### Thousand-Knot Memory

**Canonical ID:** `insight.thousand-knot-memory`

**Prerequisite:** Thread sphere.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You can encode information into knots, braids, stitch patterns, or thread colors. You can store a short message, map route, password, technique clue, or emotional warning in a thread object. A creature trained in Thread or given the key can read it. Others must succeed on an Intelligence (Investigation), Wisdom (Insight), or a check using weaver's tools, calligrapher's supplies, jeweler's tools, or another Thread tool printed by the source against your Cultivation Save DC.

### No Loose Ends

**Canonical ID:** `insight.no-loose-ends`

**Prerequisite:** Thread sphere, CL 10+.

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When one of your Thread Lines ends, you may choose to have it leave no mundane trace. If the line was magical, observers must succeed on an Intelligence (Arcana), Wisdom (Perception), or Cultivation Check against your Cultivation Save DC to reconstruct where it was anchored.

## Sphere — Unmaking

### Black-Vein Initiate

**Canonical ID:** `insight.black-vein-initiate`

**Prerequisite:** Unmaking sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You can survive the first bite of your own qi.

When you would gain Black Vein Strain while you have no Black Vein Strain, you may take Ruin self-damage equal to your Proficiency Bonus instead.

You may use this benefit once per scene.

### Ruin-Safe Grip

**Canonical ID:** `insight.ruin-safe-grip`

**Prerequisite:** Unmaking sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When an External Channel would gain its first Crack from your Unmaking talent, roll a d6. On a 5 or 6, it does not gain that Crack.

At CL 10, this succeeds on a 4, 5, or 6.

### Asura-Hand Tempering

**Canonical ID:** `insight.asura-hand-tempering`

**Prerequisite:** Unmaking Sphere, Body Refining, CL6+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Unmaking Source CL, using Body Refining CL for an Internal Channel activation.

When you use Black-Vein Palm or an Internal Channel Unmaking talent, add your Proficiency Bonus to the first Ruin damage roll you make during that turn.

If an attack used to deliver the talent misses, you do not gain Black Vein Strain from that missed attack unless the talent explicitly states that Strain is gained on a miss or on activation. This Insight does not remove Strain from a successful hit or other source.

### Clean Severance Scholar

**Canonical ID:** `insight.clean-severance-scholar`

**Prerequisite:** Unmaking sphere, Qi Cultivation Path, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use an Unmaking talent against an object, barrier, temporary qi structure, or formation node, you may spend 1 CP to gain Advantage on the Unmaking Check or impose Disadvantage on the target’s saving throw.

If the attempt fails, take Ruin self-damage equal to 2d6.

### The Hand That Pays

**Canonical ID:** `insight.the-hand-that-pays`

**Prerequisite:** Unmaking sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you Overdraw, you may choose to add the Overdraw bonus damage before seeing the total damage roll.

If you do, increase the Overdraw bonus damage by 2d6.

After resolving the talent, gain 1 additional Black Vein Strain.

### Ruin Without Hatred

**Canonical ID:** `insight.ruin-without-hatred`

**Prerequisite:** Unmaking sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When an Unmaking talent damages a possessed creature, bound spirit, cursed victim, puppet vessel, controlled summon, or another target joined to a hostile controlling link, you may direct that activation's **extra Ruin damage** at the controlling link instead of the Host, body, or vessel.

Resolve the link as follows:

- If it has Hit Points, Seal layers, Strain, Integrity, or another printed durability track, apply the extra Ruin damage to that track.
- If it has a printed breaking or suppression procedure but no damage track, treat the Ruin delivery as one successful qualifying hit for that procedure.
- If it has neither, after the Unmaking talent resolves, make an Unmaking Cultivation Check against the controlling source's Cultivation Save DC.

On a successful fallback check:

- a temporary ordinary link at least 6 Source CL lower ends;
- a link 3–5 Source CL lower is suppressed for up to 1 minute while you maintain Concentration;
- a link within 2 Source CL is suppressed until the end of the target's next turn; or
- a link 3 or more Source CL higher is not suppressed, but its direction and sustaining Anchor are exposed to your Spiritual Sense until the end of your next turn.

On a failed fallback check, the link remains and the redirected extra Ruin damage does not return to the Host or vessel.

This Insight cannot destroy a Complete Soul, sever a willing stable Covenant Bond without the parties' consent, or bypass a named material, rite, Secret, artifact, divine, or world-law release requirement.

### Star-Sundering Preparation

**Canonical ID:** `insight.star-sundering-preparation`

**Prerequisite:** Unmaking sphere, CL 14+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, choose one External Channel or one Internal Channel.

Until your next Full Cultivation Session, the chosen Channel can absorb the first 1 Crack or Black Vein Strain it would gain from an Unmaking talent.

If you use Sixth Ruin Form: Star-Sundering Cut through the prepared Channel, increase its damage by 2d10.

## Sphere — Void

### Void-Body Initiate

**Canonical ID:** `insight.void-body-initiate`

**Prerequisite:** Body Refining, Void Sphere, and a recorded Void initiation, lineage, manual, teacher, tribulation, or other legal access source

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Void Source CL, using Body Refining CL where Hollow-Meridian Body explicitly permits it.

You may learn the Hollow-Meridian Body variant. Record the legal Void access source that taught or awakened the variant.

If you already possess Hollow-Meridian Body, instead gain one Mortal-Realm Void talent for which you meet every prerequisite. If that talent introduces Corruption, a Void Price, an Anchor, or a special recovery procedure, record those elements when the Insight is gained.

This Insight does not waive Secret, Forbidden, lineage, ethical, or story access requirements and cannot be selected solely by thematic preference.

### Empty Step Adept

**Canonical ID:** `insight.empty-step-adept`

**Prerequisite:** Void sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Empty Step, you may move through one occupied space during the teleportation’s visual path.

You still must arrive in an unoccupied space you can see, and this does not allow passage through Total Cover or a sealed Barrier.

### Void Ward Adept

**Canonical ID:** `insight.void-ward-adept`

**Prerequisite:** Void Ward

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When Void Ward reduces damage to 0, you may apply one Void Pressure from Void Needle to the source if it is within 60 feet.

Use this once per round.

### Null-Script Adept

**Canonical ID:** `insight.null-script-adept`

**Prerequisite:** Erode Technique

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Erode Technique, Return to Zero, or Cause-Emptying Reversal, increase the range by 30 feet.

### Hollow-Script Custodian

**Canonical ID:** `insight.hollow-script-custodian`

**Prerequisite:** CL 10+, Void sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you teach, copy, seal, or defend a Void scripture during downtime, gain Advantage on one relevant Cultivation Check.

Once between Full Cultivation Sessions, when a creature fails a saving throw against one of your Void talents, you may extend Hollowed on that creature until the end of your next turn.

## Sphere — Warleader

### Standard Bearer Adept

**Canonical ID:** `insight.standard-bearer-adept`

**Prerequisite:** Warleader sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you Set the Standard, choose one Commanded ally.

That ally gains Temporary HP equal to your Proficiency Bonus.

If the ally fulfills your Standard before the start of your next turn, gain 1 Momentum Mark.

Use this Insight once per round.

### Voice That Carries

**Canonical ID:** `insight.voice-that-carries`

**Prerequisite:** Warleader sphere, one Shout talent, CL 6+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

Increase the radius of your Shouts by 5 feet.

When you use a Shout, choose one affected ally that cannot hear you because of Deafened, magical silence, or overwhelming noise.

If the ally can see you, it still gains the beneficial portion of the Shout.

### Order Ledger Disciple

**Canonical ID:** `insight.order-ledger-disciple`

**Prerequisite:** Warleader sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When combat ends, if you have at least 1 Momentum Mark remaining, choose one ally who followed your Standard during the encounter.

That ally gains Advantage on the first ability check it makes before the end of the next hour to repair, track, regroup, treat wounds, scout a retreat path, or explain the battle.

### Iron Captain

**Canonical ID:** `insight.iron-captain`

**Prerequisite:** Warleader sphere, Shieldbrothers or Ironclad Line, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When a Commanded ally adjacent to another Commanded ally is hit by a critical hit, spend 1 Momentum Mark.

The attack is treated as a normal hit instead of a critical hit.

Use Iron Captain once per scene.

### Emergency Commander

**Canonical ID:** `insight.emergency-commander`

**Prerequisite:** Warleader sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When Initiative is rolled, immediately Set the Standard without spending a Bonus Action.

If you are Surprised, this Standard begins at the start of your first turn instead.

### Battlefield Scribe

**Canonical ID:** `insight.battlefield-scribe`

**Prerequisite:** Warleader sphere, Qi Cultivation or proficiency with calligrapher’s supplies, cartographer’s tools, or painter’s supplies, CL 8+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

During a 10-minute recovery procedure, draw a battlefield note, flag-code sheet, sand map, or written order.

Choose one Standard you know.

Before your next scene, when you first Set that Standard, gain 1 Momentum Mark.

### No-Rout Commander

**Canonical ID:** `insight.no-rout-commander`

**Prerequisite:** Warleader sphere, Rallying Speech or Harangue, CL 10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When a Commanded ally fails a saving throw against Frightened, spend 1 Momentum Mark.

The ally may move up to 10 feet toward you or another Commanded ally without provoking Opportunity Attacks, then reroll the saving throw.

The ally must use the new roll.

## Sphere — Water

### Tidal Body

**Canonical ID:** `insight.tidal-body`

**Prerequisite:** Water sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When you become Soaked by your own Water talent, you may choose not to end the Soaked state until the start of your next turn.

While willingly Soaked this way, you gain Temporary HP equal to your Proficiency Bonus at the start of your turn.

### Water-Walking Immortal

**Canonical ID:** `insight.water-walking-immortal`

**Prerequisite:** Water sphere, CL 6+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

You can stand and move across liquid surfaces as if they were solid ground during your turn. If you end your turn on liquid without support, you sink unless another feature sustains you.

While moving across a Water Source, Basin, or Current, your Speed increases by 10 feet.

### Eroding Current

**Canonical ID:** `insight.eroding-current`

**Prerequisite:** Water sphere, Cutting Current or River Cuts the Gate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per turn, when you damage an object, Barrier, or unattended structure with Water Lash or a Pressure talent, you may apply Scouring Erosion without spending CP.

### Cleansing Adept

**Canonical ID:** `insight.cleansing-adept`

**Prerequisite:** Water sphere, Cleansing Water, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When a creature benefits from your Cleansing Basin, choose one additional benefit:

it may immediately repeat a saving throw against Poisoned or disease;

it gains Advantage on its next death saving throw before the start of your next turn;

it removes one mundane contamination, smoke effect, or environmental grime.

### Tide-Court Footwork

**Canonical ID:** `insight.tide-court-footwork`

**Prerequisite:** Water sphere, Court of the Endless Tide, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

While inside your Court of the Endless Tide, allies of your choice may move through spaces occupied by hostile creatures if they do not end movement there.

Once per round, when an ally moves through a hostile creature’s space this way, that hostile creature becomes Soaked.

### Spring-Founding Adept

**Canonical ID:** `insight.spring-founding-adept`

**Prerequisite:** Water sphere, Sacred Spring, CL 12+

**Ability Increase (Level Selection):** Increase your Wisdom, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Your Sacred Spring lasts 7 days instead of 24 hours if you spend 1 hour performing the rite and provide a stationary Small or larger Anchor with AC equal to your Cultivation Save DC and Hit Points equal to `2 × your CL`.

A long-term spring still requires project rules for permanent settlement, agriculture, sect infrastructure, or regional drought relief.

## Sphere — Wax

### Wax-Tempered Body

**Canonical ID:** `insight.wax-tempered-body`

**Prerequisite:** Body Refining or a recorded Wax inheritance, manual, teacher, transformation, or other legal access source

**Ability Increase (Level Selection):** Increase your Constitution, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL or the Source CL of the legal Wax access source.

Your flesh can soften under pressure and set before breaking.

**Yielding Wax — Once per scene:** When you would be Grappled, Restrained, pushed, pulled, or knocked Prone, gain Advantage on the saving throw or ability check made to resist or escape that effect. Declare this before rolling.

If you succeed, you may leave a harmless wax Impression on the creature or object that attempted to restrain or move you. The Impression is visible, has no mechanical effect by itself, and lasts until cleaned, melted, or the scene ends.

### Master Seal Engraver

**Canonical ID:** `insight.master-seal-engraver`

**Prerequisite:** Wax sphere.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You gain proficiency with calligrapher’s supplies, seal-carving tools, or a similar artisan’s tool. If you already have the proficiency, you may add your Proficiency Bonus twice to checks made to create, identify, preserve, or verify seals.

Once between Full Cultivation Sessions, you may place a Witness Seal or Preserving Seal without spending CP.

### Keeper of the Funeral Wick

**Canonical ID:** `insight.keeper-of-the-funeral-wick`

**Prerequisite:** Wax sphere or Spirit Awakening

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks concerning funeral etiquette, respectful corpse handling, disturbed remains, funerary wax, and preservation of final messages or identifying signs.

### Funeral Wick

**Action Type:** Reaction  
**Trigger:** A creature you can perceive dies within 30 feet  
**Limit:** Once per scene

Create one harmless funeral candle in an unoccupied space within 5 feet of the corpse or remains. The candle lasts for 1 hour and records one **Final Impression** that was perceptible at death. Choose one:

- visible name, seal, crest, or written mark;
- handprint, footprint, blood pattern, or weapon grip;
- last visible breath, gesture, expression, or direction of attention;
- one symbolic spiritual image produced by the dying creature's own soul-pattern; or
- one brief final sound of no more than six words that the creature actually uttered.

The candle is a Tiny Spirit Asset with AC 10 and 1 Hit Point. It emits dim light for 5 feet. Destroying it ends the record.

A Final Impression is evidence, not a Soul Fragment or Complete Soul. It cannot answer questions, reveal unperceived thoughts, repeat an activation, serve as a resurrection substitute, or be compelled as the dead creature.

### Sect Waxwright

**Canonical ID:** `insight.sect-waxwright`

**Prerequisite:** Wax sphere, CL5+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

For mundane construction, repair, cataloging, evidence preservation, medical wax work, temporary walls, candle paths, seals, labels, archives, or ritual fixtures, halve the ordinary work time when wax is the primary structural, sealing, preserving, marking, or recording medium.

Wax is not a valid primary medium for load-bearing construction, permanent high-temperature structures, weapons, armor, or a project whose printed materials exclude wax.

### Sympathetic Effigy Worker

**Canonical ID:** `insight.sympathetic-effigy-worker`

**Prerequisite:** Wax sphere, CL5+, and recorded legal access to one Spirit, Fate, Blood, Dream, Curse, Divination, or Formation technique that requires a sympathetic link

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you create a Wax Effigy from a true Impression, choose one technique identified by the prerequisite access record. The effigy counts as a valid sympathetic-link focus for that technique.

The effigy does not waive the technique's range, action, cost, attack, saving throw, consent, Source CL, maintenance, or destruction rules. This Insight grants no Sphere or technique by itself.

### Unmelting Temper

**Canonical ID:** `insight.unmelting-temper`

**Prerequisite:** Wax sphere, CL 10.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once between Full Cultivation Sessions, when one of your Set Wax structures or Wax Seals would be destroyed by fire damage, you may cause it to survive with 1 hit point instead.

When you use this Insight, the wax becomes visibly changed: blackened, white, glassy, fragrant, or script-covered. Anyone who examines it can tell it endured supernatural heat.

## Sphere — Weapons

### Careful Grip Disciple

**Canonical ID:** `insight.careful-grip-disciple`

**Prerequisite:** Weapons sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to avoid being disarmed of your Conduit Weapon or chosen profile weapon.

### Profile Archivist

**Canonical ID:** `insight.profile-archivist`

**Prerequisite:** Weapons sphere, Profile Specialist

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain proficiency in History, Investigation, or smith's tools.

If you already possess all three, gain proficiency in one of the following instead: calligrapher's supplies, carpenter's tools, jeweler's tools, leatherworker's tools, tinker's tools, weaver's tools, or woodcarver's tools.

### Conduit Safety Lesson

**Canonical ID:** `insight.conduit-safety-lesson`

**Prerequisite:** Armament Conduit Initiate

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, when a failed attack with your Conduit Weapon would trigger a printed backlash, overdraw, dropped-weapon consequence, or Conduit Strain increase, reduce one numerical consequence by one step:

- reduce damage by one damage die;
- reduce forced movement by 5 feet;
- reduce Strain, Crack, Corruption, or a similar counted state by 1; or
- prevent the weapon from being dropped.

If the complication has none of those components, this Insight cannot reduce it.

### Heirloom Etiquette

**Canonical ID:** `insight.heirloom-etiquette`

**Prerequisite:** Spirit Heirloom Method

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on one social check between Full Cultivation Sessions when presenting, explaining, honoring, or negotiating around a named weapon, ancestor weapon, trophy weapon, or sect armament.

### Weapon Exchange Drill

**Canonical ID:** `insight.weapon-exchange-drill`

**Prerequisite:** Weapons sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per turn, you may draw or stow one weapon as part of using a Weapons talent or profile specialty.

### Conduit Hand Correction

**Canonical ID:** `insight.conduit-hand-correction`

**Prerequisite:** Casting-Hand Weapon Method

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

If you miss with your Conduit Weapon by 1 or 2, you may choose to deal no damage but maintain your stance. Until the start of your next turn, you have Advantage on the next saving throw against being disarmed or losing concentration on a weapon-mediated technique.

### Arsenal Memory

**Canonical ID:** `insight.arsenal-memory`

**Prerequisite:** Weapons sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one weapon family from the Weapon Catalogue. During a 10-minute recovery procedure, you may drill with one weapon from that family. Until your next Full Cultivation Session, you may use Weapon Literacy and Apply Weapon Method with that weapon even if it is unusual for your sect or background.

This does not grant proficiency with every weapon in the family, and it does not grant a specialist sphere such as Sword, Spear, Dual Wielding, Sniper, or Chains.

### Hidden Implement Discipline

**Canonical ID:** `insight.hidden-implement-discipline`

**Prerequisite:** Weapons sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

You gain Advantage on one Dexterity (Sleight of Hand), Wisdom (Perception), or Intelligence (Investigation) check per scene to conceal, notice, identify, or ready a small legal weapon.

If the weapon will be used as an attack in combat, it must still be listed on the character sheet before the fight begins.

### Strange Weapon Familiarity

**Canonical ID:** `insight.strange-weapon-familiarity`

**Prerequisite:** Weapons sphere, CL6+, and possession of or access to one published legal weapon profile

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one published weapon profile that is not normally part of your sect, background, or Path training. Treat that profile as familiar for Weapon Literacy and include it in your normal combat action list.

This Insight does not create the weapon, grant proficiency beyond Weapon Literacy, bypass rarity or legal restrictions, or authorize an unpublished custom profile.

### Method-Bearing Grip

**Canonical ID:** `insight.method-bearing-grip`

**Prerequisite:** Weapons sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per round, when you switch from one legal weapon to another legal weapon before making an attack, you may carry one non-damaging Weapon Method benefit from the first weapon's posture into the next attack.

The carried benefit must be defensive, positional, disarming, hooking, measuring, concealing, or setup-based. It cannot add extra damage dice unless a talent explicitly says so.

### Arsenal-Script Custodian

**Canonical ID:** `insight.arsenal-script-custodian`

**Prerequisite:** Weapons sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

During downtime, you may create a weapon ledger, rack map, carrying kit, sect arsenal register, or training catalogue.

A completed project can help allies identify, maintain, transport, or choose legal mundane weapons. It does not create magic items, rare materials, formations, or free forged techniques.

### Ten Thousand Tools Mind

**Canonical ID:** `insight.ten-thousand-tools-mind`

**Prerequisite:** Weapons sphere, CL 10+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per scene, when you begin your turn holding a legal weapon that is poorly suited to the immediate tactical problem, you may use Ready the Implement without spending your Bonus Action if another legal weapon is already on your person and accessible.

This does not increase the number of attacks you make, and it does not allow a hidden or inaccessible weapon to appear from nowhere.

# 06. General Spirit Insights

## General Spirit

### Exorcist's Calling

**Canonical ID:** `insight.exorcist-s-calling`

**Prerequisite:** Spirit Awakening, CL4+, Spiritual Sense  
**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.  
**Source CL:** Your Spirit Awakening CL.

You have learned to diagnose and interrupt invasive spiritual influences before gaining the Path's complete exorcism feature.

## Lesser Exorcism

**Action Type:** Action  
**Range:** 30 feet  
**Cost:** 2 Resonance  
**Target:** One creature, object, location, manifested spirit, or Spiritual Anchor that you can perceive with Spiritual Sense or Soul Gaze, or one target bearing your Resonance Mark

Choose one **Intrusion** attached to the target that you can perceive:

- unwilling Possession;
- unwilling or coercive Hosting;
- dream intrusion;
- spiritual contamination;
- imposed emotional corruption;
- memory interference;
- hostile spirit presence; or
- a curse whose Source Rule has a spiritual component.

You cannot target:

- a willing stable Covenant Bond unless both bonded parties consent to separation;
- integrated spirit ancestry or a legal Species, Path, Subpath, Foundation, Method, Origin Insight, or ordinary memory;
- completed death, reincarnation, permanent soul destruction, or divine custody; or
- an artifact, Secret, Immortal, or world-law effect unless its Source Rule permits ordinary exorcism.

### Resolution

Make a Spirit Awakening Cultivation Check against the Intrusion's Cultivation Save DC. If it has no printed DC, use the possessing spirit's or creator's Cultivation Save DC. If neither exists, use the Rules Reference fallback Authority DC for the source's Realm.

On a failed check, the Intrusion remains. Learn its broad category, its Source CL band relative to you, and whether it is sustained by a creature, Bond, vessel, location, Domain, or Spiritual Anchor.

On a successful check, compare Source CL:

- **6 or More Lower:** End one ordinary temporary Intrusion. For Possession, achieve Grade 2 Separation and place the Intruder in its legal adjacent manifestation, legal vessel, or visible noncontrolling outline. A permanent, Secret, artifact, divine, or explicitly anchored Intrusion is suppressed until the scene ends and reveals one printed release requirement instead.
- **3–5 Lower:** Suppress the Intrusion for up to 1 minute while you maintain Concentration. The Host immediately repeats one saving throw the Intrusion allows with Advantage. The Intruder becomes perceptible and cannot conceal its link during suppression.
- **Within 2:** Suppress the Intrusion until the end of the target's next turn. The Host immediately repeats one allowed saving throw with Advantage. If no repeat save exists, suppression is the complete result.
- **3 or More Higher:** Do not suppress it. The Host immediately repeats one allowed saving throw with Advantage. Expose the Intrusion's manifestation and the direction of its sustaining Anchor to your Spiritual Sense until the end of your next turn.

A willing Host may waive resistance made on its behalf. A willing Intruder does not resist separation. If both Host and Intruder oppose separation, use the higher relevant Cultivation Save DC; if only one opposes, use that opponent's DC.

### Limits

- A specific Intrusion can be targeted by your Lesser Exorcism only once per round.
- Lesser Exorcism cannot destroy a Complete Soul, transfer spirit ownership, create a Companion Bond, strip integrated ancestry, or remove legal character options.
- It cannot bypass a named rite, material, location, authority, or higher Source CL requirement unless the result expressly satisfies it.

## CL13 Improvement

When you gain **Spiritual Exorcism** from Spirit Awakening:

- Lesser Exorcism costs 1 Resonance;
- its range becomes 60 feet;
- successful suppression against a lower-Source-CL Intrusion does not require Concentration; and
- when you expose an equal- or higher-authority Intrusion, the target has Advantage on its next saving throw against it before the scene ends.

This Insight does not grant the Spirit Companions Sphere and does not replace the Exorcist tradition.

# 07. Complete Alphabetical Index

| Insight | Minimum CL | Prerequisite | Ability increase options | Category | PHB core? |
|---|---:|---|---|---|---|
| Alchemical Constitution | 8 | Alchemy or Body Refining, CL8+ | Constitution, Intelligence, Wisdom | Sphere — Alchemy | No |
| Alchemical Prodigy | 4 | Alchemy, CL 4+. | Intelligence, Wisdom, Constitution | Sphere — Alchemy | Yes |
| Alloy-Sense Disciple | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Ancestral Bloodline Awakening | 4 | Discovered heritage, absorbed ancestral essence, bloodline event, or equivalent approval | Constitution, Charisma | Qi — Bloodline Insights | No |
| Ancestral Treasure Bond | 8 | A bloodline feature and one genuine ancestral weapon, shield, artifact, implement, or relic; CL8+ | Constitution, Wisdom, Charisma | Qi — Bloodline Insights | No |
| Anchor Between Heaven and Earth | 12 | Gravity sphere, CL 12+. | Strength, Intelligence, Wisdom | Sphere — Gravity | No |
| Anchored Soul | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Sphere — Space | No |
| Armament Commander | 12 | Domain Armament, CL12+ | Intelligence, Wisdom, Charisma | Qi — Martial and Domain Armament Insights | No |
| Armament Formation Node | 12 | Domain Armament and the Formations Sphere, Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another Formation-authorized Source Rule, CL12+ | Intelligence, Wisdom, Charisma | Qi — Martial and Domain Armament Insights | No |
| Armament Reversal | 12 | Domain Armament, CL12+ | Dexterity, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Armored Meridian Circulation | 4 | Qi Cultivation, proficiency with medium armor, heavy armor, or shields, CL4+ | Strength, Constitution, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Arsenal Memory | 4 | Weapons sphere, CL 4+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Arsenal-Script Custodian | 8 | Weapons sphere, CL 8+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Ashura Furnace | 12 | Jigoku and Fire, Ash, or Demonic Cultivation Sphere, CL 12+ | Strength, Constitution, Charisma | Body — Advanced Subpath Insights | No |
| Astral Cartographer | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Asura-Hand Tempering | 6 | Unmaking Sphere, Body Refining, CL6+ | Constitution, Strength, Wisdom | Sphere — Unmaking | No |
| Auspicious Companion | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Fate | Yes |
| Awakener of Tools | 8 | Animate Minor Vessel or Speak to the Vessel, CL 8+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Banquet Etiquette of the Outer Court | 4 | Hunger sphere | Constitution, Strength, Wisdom | Sphere — Hunger | No |
| Barrage Conduction | 12 | Qi Cultivation, CL12+, and a Barrage Sphere talent, multiattack Recorded Art, or another authorized multiattack cultivation procedure | Dexterity, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Battle Musician | 4 | Body Refining, Music Sphere, CL4+ | Constitution, Charisma, Wisdom | Sphere — Music | No |
| Battlefield Physician | 4 | Life sphere. | Wisdom, Constitution, Charisma | Sphere — Life | Yes |
| Battlefield Scribe | 8 | Warleader sphere, Qi Cultivation or proficiency with calligrapher’s supplies, cartographer’s tools, or painter’s supplies, CL 8+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Beast-Core Butcher | 8 | Harvesting and Gathering, Simple Beast Dressing, CL 8+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | No |
| Beauty-Script Custodian | 10 | Beauty sphere, Formations, Talismans, Ink, Music, or Sect Stewardship sphere, CL 10+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | No |
| Bell-and-Formation Custodian | 8 | Music sphere, Formations sphere, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Bell-Bone Adept | 4 | Body Refining, Sound Sphere, CL4+ | Constitution, Wisdom, Charisma | Sphere — Sound | No |
| Bell-Skin Discipline | 8 | Iron Shirt, CL 8+ | Constitution | Body — Advanced Subpath Insights | No |
| Black-Lantern Commander | 12 | Death, Grave Formation, CL 12+ | Wisdom, Intelligence, Charisma | Sphere — Death | No |
| Black-Vein Initiate | 4 | Unmaking sphere, CL 4+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Blackglass Executioner | 10 | Obsidian Glass Scripture or Cinderglass Shards, CL 10+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| Blade-Hesitation Adept | 8 | Beauty sphere, Turn the Blade Aside or another Beauty reaction talent, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | No |
| Blood-Furnace Heart | 16 | Blood Pump, CL 16+ | Constitution | Body — General Body Refining Insights | Yes |
| Blood-Meridian Refinement | 4 | Blood Sphere, CL 4+ | Constitution, Charisma | Body — Common Hybrid-Sphere Insights | No |
| Bloodline-Core Fusion | 12 | Bloodline Cultivator, Ancestral Bloodline Awakening, or another active bloodline engine; CL12+ | Constitution, Intelligence, Charisma | Qi — Bloodline Insights | No |
| Body as Cauldron | 4 | Body Refining, CL4+, Constitution 15+ | Constitution, Intelligence, Wisdom | Sphere — Alchemy | No |
| Body as Center | 8 | Body Refining, Gravity Sphere, CL8+ | Constitution, Strength, Intelligence | Sphere — Gravity | No |
| Body Like Water | 4 | Flowing River sphere | Dexterity, Wisdom, Constitution | Sphere — Flowing River | Yes |
| Body of Thorns and Spores | 4 | Body Refining, Harvesting and Gathering Sphere, CL4+ | Constitution, Wisdom, Intelligence | Sphere — Harvesting Gathering | No |
| Bone General | 8 | Corpse Servant, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Death | No |
| Bone-Tempering Insight | 4 | Bones Sphere, CL 4+ | Constitution | Body — Common Hybrid-Sphere Insights | No |
| Borrowed Golden Form | 16 | Qi Cultivation, CL16+ | Intelligence, Wisdom, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Borrowed Merit | 10 | Karma sphere, CL 10+ | Wisdom, Charisma, Intelligence | Sphere — Karma | No |
| Branch Founder | 12 | Sect Stewardship, Courtyard Grant or Department Ledger, CL 12+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Breach-Reader | 4 | Destruction sphere | Strength, Intelligence, Charisma | Sphere — Destruction | Yes |
| Breath-Thread Listener | 8 | Air sphere, Spirit Awakening, CL8+ | Dexterity, Wisdom, Intelligence | Sphere — Air | Yes |
| Breathless Heart Method | 12 | Shinobi, CL 12+ | Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Broken-Rhythm Adept | 8 | Drunken Style sphere, CL 8+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Brush-Armed Guard | 8 | Brushstroke Shield, CL 8+. | Intelligence, Dexterity, Wisdom | Sphere — Ink | No |
| Brutal Momentum | 8 | Body Refining, CL 8+ | Strength, Dexterity, Constitution | Body — General Body Refining Insights | Yes |
| Brute-Body Adept | 4 | Brute Sphere, CL 4+ | Strength, Constitution | Body — Common Might-Sphere Insights | No |
| Burden-Bearing Companion | 8 | Earth sphere, Companion feature or bonded companion, CL 8+ | Constitution, Strength, Wisdom | Sphere — Earth | No |
| Burden-Mark Adept | 4 | Earth sphere, CL 4+ | Constitution, Strength, Wisdom | Sphere — Earth | Yes |
| Butcher’s Mercy | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Calamity Control | 4 | Destruction sphere | Strength, Intelligence, Charisma | Sphere — Destruction | Yes |
| Calm Hands, Clear Current | 4 | Qiweaving sphere | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | Yes |
| Camp Kitchen Adept | 4 | Hunger sphere | Constitution, Strength, Wisdom | Sphere — Hunger | Yes |
| Careful Grip Disciple | 4 | Weapons sphere | Strength, Dexterity, Constitution | Sphere — Weapons | Yes |
| Careful Inscription | 4 | Imbuement sphere, CL 4+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Cauldron Heart | 8 | Alchemy and Pill Forging Sphere or Alchemical Cultivator, CL8+ | Constitution, Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Cavalry Cut Familiarity | 4 | Sabers sphere, Cavalry Crescent Method | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Celestial Navigator | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Ceremonial Yue Bearer | 12 | Axes sphere, Mandate Axe Presence, CL12+, and Spirit Awakening, Warleader sphere, Sovereign Will, or another printed mandate doctrine | Strength, Wisdom, Charisma | Sphere — Axes | No |
| Chain-Tool Familiarity | 4 | Chains sphere | Strength, Dexterity, Wisdom | Sphere — Chains | Yes |
| Chain-Walking Immortal | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Sphere — Chains | No |
| Circuit Scholar | 4 | Qiweaving sphere | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | Yes |
| Circulating Core Refinement | 10 | Circulating Golden Core, CL10+ | Dexterity, Intelligence, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Clean Edge Discipline | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Clean Quarantine Reputation | 4 | Disease sphere | Constitution, Intelligence, Wisdom | Sphere — Disease | No |
| Clean Severance Scholar | 6 | Unmaking sphere, Qi Cultivation Path, CL 6+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Clean-Handed Healer | 4 | Life sphere. | Wisdom, Constitution, Charisma | Sphere — Life | Yes |
| Clean-Tongued Disciple | 4 | Hunger sphere | Constitution, Strength, Wisdom | Sphere — Hunger | Yes |
| Cleansing Adept | 8 | Water sphere, Cleansing Water, CL 8+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Clinch-Gate Adept | 8 | Iron Fist sphere, Dragon-Step Clinch, CL 8+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Cloud-Step Novice | 4 | Air sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Sphere — Air | Yes |
| Cold Star Heart | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Comet Adept | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Companion Armament | 16 | Domain Armament, CL16+ | Intelligence, Wisdom, Charisma | Qi — Martial and Domain Armament Insights | No |
| Compressed Golden Core | 12 | Qi Cultivation, CL12+ | Constitution, Intelligence, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Conceptual Edge | 16 | Heaven-Splitting Conceptual Severance or equivalent Secret authority, CL16+ | Dexterity, Intelligence, Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Conductive Preservation Artist | 8 | Lightning sphere, Spark Lattice Preservation, CL 8+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Conductor's Eye | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Conduit Hand Correction | 4 | Casting-Hand Weapon Method | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Conduit Safety Lesson | 4 | Armament Conduit Initiate | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Constellation Keeper | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Core-Sheltering Scripture | 12 | Qi Cultivation, CL12+ | Constitution, Wisdom, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Corpse-Tempered Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Intelligence | Sphere — Death | No |
| Counter-Chant Specialist | 8 | Counter-Chant, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Sound | No |
| Counter-Script Reflex | 5 | Counterweave, CL 5+ | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | No |
| Counterseal Reflex | 10 | Seal Breaker, CL 10+ | Intelligence, Wisdom, Charisma | Sphere — Talismans | No |
| Courteous Medium | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Sphere — Spirit Companions | Yes |
| Courtly Presentation | 4 | Beauty sphere, CL 4+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | Yes |
| Cremation-Furnace Core | 8 | Cinder Heart Cultivator or Fire/Ash cultivation access, CL8+ | Constitution, Intelligence, Charisma | Qi — Forbidden, Condemned, and Predatory Insights | No |
| Crescent Projection Student | 4 | Sabers sphere, Qi Cultivation Path | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Crimson Restraint Broken | 12 | Oni Blood and Demonic Cultivation Sphere, CL 12+ | Strength, Constitution, Charisma | Body — Advanced Subpath Insights | No |
| Crooked-Court Custodian | 12 | Drunken Style sphere, Court of Broken Rhythm, Formations sphere, CL 12+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Crushing Focus | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Sphere — Gravity | No |
| Cultivated Weapon Channel | 4 | Qi Cultivation, proficiency with the chosen weapon group, CL4+ | Strength, Dexterity, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Cut the Snare | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Dao Guard Veteran | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Dawn Physician | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Dawn-Ward Adept | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Deacon’s Patience | 12 | Sect Stewardship, CL 12+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Debt Collector | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Karma | No |
| Deep Internalization | 8 | Internalized Sphere Insight; CL8+ | Constitution, Intelligence, Wisdom | Body — Internalizing Power Spheres | No |
| Deepened Ancestral Memory | 8 | A bloodline feature, CL8+ | Intelligence, Wisdom, Charisma | Qi — Bloodline Insights | No |
| Demon Emperor’s Price | 15 | Demon Emperor Incarnation, CL 15+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Demon-Revealing Eyes | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Demon-Slaying Demon | 8 | Daemonic Cultivation, CL 8+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Devil-Qi Circulation | 4 | Daemonic Cultivation, CL 4+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Diamond Light Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Charisma | Sphere — Radiance | No |
| Divine Statue Meditation | 12 | Gōruden, CL 12+ | Constitution, Wisdom, Charisma | Body — Advanced Subpath Insights | No |
| Double Current Method | 5 | Flowing River sphere, CL 5+ | Dexterity, Wisdom, Constitution | Sphere — Flowing River | No |
| Dragon-Pearl Heart | 12 | Ryūjin, CL 12+ | Strength, Constitution, Charisma | Body — Advanced Subpath Insights | No |
| Dual Mandate Adept | 8 | Layered Mandate, CL 8+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Dual-Body Synthesis | 12 | Two Internalized Sphere Insights; CL12+ | Constitution, Intelligence, Wisdom | Body — Internalizing Power Spheres | No |
| Dual-Element Golden Core | 8 | Two elemental Spheres, CL8+ | Intelligence, Charisma | Qi — Elemental Refinement Insights | No |
| Dune Court Architect | 12 | Sand sphere, Court of Ten Thousand Dunes, CL 12+ | Dexterity, Wisdom, Intelligence | Sphere — Sand | No |
| Dune-Sovereign’s Mercy | 15 | Sand sphere, Sand-Sovereign Incarnation, CL 15+ | Dexterity, Wisdom, Intelligence | Sphere — Sand | No |
| Earth-Ring Discipline | 8 | Sumo, CL 8+ | Strength, Constitution | Body — Advanced Subpath Insights | No |
| Efficient Mandate | 6 | Imbuement sphere, CL 6+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Electric Fist Adept | 4 | Lightning sphere, Electric Fist Method, CL 4+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Elemental Armament | 12 | Domain Armament, one elemental Sphere or an elemental Qi Subpath, CL12+ | Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Elemental Core Mutation | 8 | Qi Cultivation, one elemental Sphere, CL8+ | Constitution, Intelligence, Charisma | Qi — Elemental Refinement Insights | No |
| Elemental Counterflow | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Elemental Dominion | 16 | Elemental Mastery, CL16+ | Intelligence, Charisma | Qi — Elemental Refinement Insights | No |
| Elemental Fusion Body | 12 | Elemental Mastery, CL12+ | Constitution, Intelligence, Charisma | Qi — Elemental Refinement Insights | No |
| Elemental Mastery | 4 | Qi Cultivation, access to the chosen damage type, CL4+ | Intelligence, Charisma | Qi — Elemental Refinement Insights | No |
| Embodied Domain | 12 | Internalized Sphere Insight and access to one Domain Talent; CL12+ | Constitution, Wisdom, Charisma | Body — Internalizing Power Spheres | No |
| Emergency Commander | 8 | Warleader sphere, CL 8+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Empty Step Adept | 4 | Void sphere | Wisdom, Intelligence, Charisma | Sphere — Void | No |
| Empty-Hand Twin Form | 4 | Dual Wielding sphere, an approved unarmed or natural-weapon discipline, CL 4+ | Dexterity, Strength, Constitution | Sphere — Dual Wielding | No |
| Empty-Hand Weapon Master | 8 | Iron Fist sphere, Open-Hand Disarm, CL 8+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Empty-Meridian Refinement | 12 | Kūkishin, CL 12+ | Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Ensemble Leader | 8 | Music sphere, Shared Measure, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Epidemic Master | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Sphere — Disease | No |
| Erased Name | 16 | Void Sphere or Void-Touched Cultivator, CL16+, Secret approval | Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Eroding Current | 8 | Water sphere, Cutting Current or River Cuts the Gate, CL 8+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Ethical Exorcist | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Sphere — Spirit Companions | Yes |
| Ethical Gatherer | 8 | Harvesting and Gathering, CL 8+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | Yes |
| Execution Restraint | 4 | Sabers sphere, Execution Saber Method | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Exorcist's Calling | 4 | Spirit Awakening, CL4+, Spiritual Sense | Wisdom, Intelligence, Charisma | General Spirit | Yes |
| Expanded Dantian | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Expansive Golden Core | 12 | Qi Cultivation, CL12+ | Constitution, Intelligence, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| External Foundation Breakthrough | 5 | Body Refining, Earth Sphere, CL5+ | Constitution, Strength, Wisdom | Sphere — Earth | No |
| External Hammer Breakthrough | 8 | Blacksmith Sphere, Body Refining, CL8+ | Strength, Constitution, Intelligence | Sphere — Blacksmith | No |
| External Thread Breakthrough | 5 | Body Refining, Puppetry Sphere, CL5+ | Constitution, Intelligence, Dexterity | Sphere — Puppetry | No |
| Face Without Falsehood | 8 | Beauty sphere, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | No |
| Fall Seven Ways | 6 | Drunken Style sphere, Falling-Leaf Drop or Bent-Reed Recovery, CL 6+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Falling Star Footwork | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Sphere — Gravity | No |
| Feed the Breakthrough Furnace | 10 | Profane Breakthrough Pressure, CL 10+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Field Refinement Doctrine | 8 | Qi Cultivation, CL8+ | Dexterity, Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Fire-Metal Furnace Understanding | 6 | Blacksmith sphere, Metal sphere or Fire sphere, CL 6+ | Intelligence, Strength, Constitution | Sphere — Blacksmith | No |
| Five-Element Meridian Cycle | 12 | Five Elements Cultivator or at least three elemental Spheres, CL12+ | Constitution, Intelligence, Wisdom | Qi — Elemental Refinement Insights | No |
| Fivefold Conversion | 4 | Qi Cultivation, CL4+ | Intelligence, Wisdom, Charisma | Qi — General Qi Insights | Yes |
| Flash-Step Duelist | 8 | Lightning sphere, Flash Step, CL 8+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Flesh-Reconstruction Insight | 4 | Flesh Sphere, CL 4+ | Constitution, Wisdom | Body — Common Hybrid-Sphere Insights | No |
| Flowing Combination Adept | 6 | Iron Fist sphere, Flowing Combination, CL 6+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Flowing-River Adept | 4 | Flowing River Sphere, CL 4+ | Dexterity, Constitution, Wisdom | Body — Common Might-Sphere Insights | No |
| Folded Reflexes | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Sphere — Space | No |
| Fool’s Balance | 4 | Drunken Style sphere, CL 4+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Form-Script Custodian | 8 | Iron Fist sphere, Formations sphere, CL 8+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Formation Apprentice | 4 | Formations Sphere, CL4+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Formation Breaker | 5 | Destruction sphere, Foundation Realm | Strength, Intelligence, Charisma | Sphere — Destruction | No |
| Formation Breaker | 8 | Lightning sphere, Overload Ward, CL 8+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Formation Engineer | 8 | Formation Apprentice, CL8+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Formation Piercer | 10 | Formation Anchor Shot, CL 10+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Formation-Collapse Survivor | 4 | Survive a Formation collapse, spatial collapse, teleportation disaster, or prison Formation Tribulation | Constitution, Intelligence, Wisdom | Qi — Tribulation Insights | No |
| Formation-Smasher Palm | 8 | Stone Fist, CL 8+ | Strength, Constitution | Body — Advanced Subpath Insights | No |
| Formation-Wedge Cutter | 12 | Axes sphere, Axe Bites the Formation, CL 12+ | Strength, Dexterity, Constitution | Sphere — Axes | No |
| Formula Archivist | 6 | Talismans sphere, CL 6+ | Intelligence, Wisdom, Charisma | Sphere — Talismans | No |
| Fortune-Tempered Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Charisma | Sphere — Fate | No |
| Foundation Array Custodian | 8 | Earth sphere, Formations sphere, CL 8+ | Constitution, Strength, Wisdom | Sphere — Earth | No |
| Four-Wind Adept | 8 | Air sphere, Breath Beyond the Skin, CL 8+ | Dexterity, Wisdom, Intelligence | Sphere — Air | No |
| Frozen Golden Core | 4 | Survive a Cold, Yin, Ice, or Stillness Tribulation | Constitution, Wisdom, Charisma | Qi — Tribulation Insights | No |
| Furnace-Core Survivor | 4 | Survive a Fire, Magma, Ash, or Meridian-Flame Tribulation | Strength, Constitution, Charisma | Qi — Tribulation Insights | No |
| Furnace-Heart Discipline | 4 | Magma, CL 4+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| Furnace-Soul Awakening | 4 | Spirit Awakening, CL4+ | Constitution, Wisdom, Intelligence | Sphere — Magma | No |
| Furnace-Tyrant’s Stomach | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Sphere — Alchemy | No |
| Gambler’s Instinct | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Fate | Yes |
| Gatekeeper’s Eye | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Sphere — Space | No |
| Giant-Marrow Refinement | 8 | Flesh Crucible, CL 8+ | Strength, Constitution | Body — Advanced Subpath Insights | No |
| Glass-Cutting Palm | 8 | Sand sphere, Glass Edge Scripture, CL 8+ | Dexterity, Wisdom, Intelligence | Sphere — Sand | No |
| Gourd of the First Dune | 6 | Sand sphere, Hidden Cache of Grains or Gourd-Bound Sand Scripture, CL 6+ | Dexterity, Wisdom, Intelligence | Sphere — Sand | No |
| Grace-Bearing Soul | 8 | Karma sphere, Spirit Awakening, CL8+ | Wisdom, Charisma, Intelligence | Sphere — Karma | No |
| Gravekeeper | 4 | Death, CL 4+ | Wisdom, Intelligence, Charisma | Sphere — Death | Yes |
| Graveyard Sovereign | 12 | Bone Monarch and Bones or Death Sphere, CL 12+ | Constitution, Intelligence, Wisdom | Body — Advanced Subpath Insights | No |
| Gravitic Soul | 4 | Spirit Awakening, CL4+ | Strength, Intelligence, Wisdom | Sphere — Gravity | No |
| Grounded Rod Body | 6 | Lightning Sphere and either Body Refining or Grounded Conductor Method, CL6+ | Constitution, Dexterity, Intelligence | Sphere — Lightning | No |
| Guardian Armament | 12 | Domain Armament, CL12+ | Constitution, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Guardian-Body Adept | 4 | Guardian Sphere, CL 4+ | Constitution, Wisdom | Body — Common Might-Sphere Insights | No |
| Hall Insider | 8 | Sect Stewardship, Hall Apprenticeship, CL 8+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Hard-Meridian Breathing | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Harmonic Analyst | 4 | Sound sphere, CL 4+ | Charisma, Wisdom, Constitution | Sphere — Sound | No |
| Harmonic Memory | 10 | Harmonic Package, CL 10+ | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | No |
| Heart-Demon Vanquisher | 4 | Survive a Heart-Demon, mental, Dream, Illusion, emotional, or identity Tribulation | Wisdom, Charisma | Qi — Tribulation Insights | No |
| Heart-Devil Negotiator | 5 | Daemonic Cultivation and either Spirit Awakening or Wisdom 14+, CL5+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Heart-Stealing Resonance | 12 | Emotion Cultivator or access to Mind, Emotion, or Spirit manipulation; CL12+ | Wisdom, Charisma | Qi — Forbidden, Condemned, and Predatory Insights | No |
| Heartstring Physician | 10 | Music sphere, Healing Hymn, CL 10+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Heaven's Conduit | 16 | Qi Cultivation, CL16+ | Constitution, Wisdom, Charisma | Qi — General Qi Insights | Yes |
| Heaven's Scar | 4 | Survive an extraordinary, unique, Secret, Immortal, or Heaven-recognized Tribulation; approval | Constitution, Wisdom, Charisma | Qi — Tribulation Insights | No |
| Heavenly Meridian Reconstruction | 16 | Body Refining, CL 16+ | Constitution, Wisdom | Body — General Body Refining Insights | Yes |
| Heaven’s Distance Student | 12 | Star-Scraper Line, CL 12+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Heaven’s Witness | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Karma | No |
| Heavy Armament Conduction | 8 | Qi Cultivation, proficiency with a two-handed heavy weapon or another weapon classified as a heavy armament, CL8+ | Strength, Constitution, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Heirloom Etiquette | 4 | Spirit Heirloom Method | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Herb-Gatherer’s Foundation | 4 | Harvesting and Gathering, CL 4+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | Yes |
| Hidden Carrier Insight | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Sphere — Disease | No |
| Hidden Command | 8 | Imbuement sphere, Quiet and Resound or Read the Vessel, CL 8+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Hidden Implement Discipline | 4 | Weapons sphere, CL 4+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Hidden Sleeve Adept | 6 | Hidden Sleeve Preparation, CL 6+ | Intelligence, Wisdom, Charisma | Sphere — Talismans | No |
| Hidden Spool Discipline | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Hollow-Meridian Circulation | 12 | Void Sphere or Void-Touched Cultivator, CL12+ | Constitution, Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Hollow-Script Custodian | 10 | CL 10+, Void sphere | Wisdom, Intelligence, Charisma | Sphere — Void | No |
| Hook Master | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Sphere — Chains | No |
| Hybrid-Sphere Refinement | 4 | One Hybrid Sphere, CL4+ | Intelligence, Wisdom, Charisma | Qi — Cross-Sphere Insights | No |
| Ice-Sure Footwork | 4 | Ice sphere | Wisdom, Intelligence, Constitution | Sphere — Ice | No |
| Impact Tempering | 4 | Destruction Sphere, Body Refining | Strength, Constitution, Intelligence | Sphere — Destruction | No |
| Imperial Academy Graduate | 4 | Recognized academy access, CL4+ | Intelligence, Wisdom, Charisma | Qi — Imperial Training Insights | No |
| Imperial Archivist | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom | Qi — Imperial Training Insights | No |
| Imperial Armory Certification | 4 | Imperial, military, sect-armory, or equivalent authorization, CL4+ | Strength, Dexterity, Intelligence | Qi — Imperial Training Insights | No |
| Imperial Examination Laureate | 8 | Imperial Academy Graduate, successful examination or equivalent recognition, CL8+ | Intelligence, Wisdom, Charisma | Qi — Imperial Training Insights | No |
| Imperial Officer's Circulation | 8 | Military, guard, administrative, or command training, CL8+ | Constitution, Intelligence, Charisma | Qi — Imperial Training Insights | No |
| Imperial Quartermaster Training | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom, Charisma | Qi — Preparation and Strategic Insights | No |
| Impossible Recovery | 8 | Drunken Style sphere, Swaying Guard, CL 8+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Inked Body | 4 | Body Refining, CL4+ | Constitution, Intelligence, Dexterity | Sphere — Ink | No |
| Inner Vessel Discipline | 4 | Spirit Companions Sphere, Body Refining | Constitution, Wisdom, Charisma | Sphere — Spirit Companions | No |
| Internal Weapon Scripture | 4 | Body Refining, CL 4+ | Strength, Dexterity, Constitution | Body — General Body Refining Insights | Yes |
| Internalized Sphere Insight | 4 | Body Refining and access to one Power sphere; CL4+ | Constitution, Intelligence, Wisdom, Charisma | Body — Internalizing Power Spheres | No |
| Iron Belly Foundation | 5 | Hunger sphere, Foundation Realm | Constitution, Strength, Wisdom | Sphere — Hunger | No |
| Iron Captain | 8 | Warleader sphere, Shieldbrothers or Ironclad Line, CL 8+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Iron Mercy | 4 | Life Sphere and Body Refining | Constitution, Wisdom, Charisma | Sphere — Life | No |
| Iron Shirt Adept | 8 | Iron Fist sphere, Body Conditioning or Iron Shirt Practice, CL 8+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Iron-Blood Circulation | 4 | Body Refining, CL 4+ | Constitution | Body — General Body Refining Insights | Yes |
| Ironwood Staff Scripture | 8 | Bojutsu and Wood or Metal Sphere, CL 8+ | Strength, Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Item-Spirit Midwife | 10 | Blacksmith sphere, Spirit-Listening Tap, CL 10+ | Intelligence, Strength, Constitution | Sphere — Blacksmith | No |
| Jade Inscription Master | 12 | Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another durable-inscription Source Rule, CL12+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Jade-Seal Preserver | 8 | Harvesting and Gathering, Spirit-Sealing Wax, CL 8+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | No |
| Karmic Body | 4 | Body Refining, CL4+, secret karmic initiation | Constitution, Wisdom, Charisma | Sphere — Karma | No |
| Karmic Ledger Within the Core | 12 | Karma-Thread Cultivator, Oath-Ledger Cultivator with Karma access, or genuine Karma Secret authority; CL12+ | Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Keeper of the Funeral Wick | 4 | Wax sphere or Spirit Awakening | Intelligence, Wisdom, Constitution | Sphere — Wax | Yes |
| Lattice Scholar | 4 | Ice sphere, Qi Cultivation or Intelligence 13+ | Wisdom, Intelligence, Constitution | Sphere — Ice | No |
| Lava-Walking Immortal | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| Lawful Captor | 4 | Chains sphere | Strength, Dexterity, Wisdom | Sphere — Chains | Yes |
| Ledger-Bound Memory | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Ledger-Safe Tongue | 4 | Karma sphere, CL 4+ | Wisdom, Charisma, Intelligence | Sphere — Karma | Yes |
| Lightning-God Disciple | 6 | Lightning sphere, Lightning-God Body, CL 6+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Lightning-Scarred Meridians | 4 | Survive a Lightning or Heaven-Thunder Tribulation | Dexterity, Constitution, Charisma | Qi — Tribulation Insights | No |
| Living Anchor | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Sphere — Chains | No |
| Living Bellows Body | 6 | Air Sphere, Body Refining, CL6+ | Constitution, Dexterity, Wisdom | Sphere — Air | No |
| Living Illustration Adept | 8 | Painted Beast, CL 8+. | Intelligence, Dexterity, Wisdom | Sphere — Ink | No |
| Living Siege Engine | 8 | Body Refining, CL 8+ | Strength, Constitution | Body — General Body Refining Insights | Yes |
| Loaded Destiny | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Fate | No |
| Logging Breath Body | 6 | Axes Sphere, Body Refining, Work-Axe Eye, CL6+ | Strength, Constitution, Dexterity | Sphere — Axes | No |
| Mandate Breaker | 10 | Counter-Mandate, CL 10+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Mandate-Bearing Voice | 12 | Fate, CL 12+ | Wisdom, Charisma, Intelligence | Sphere — Fate | No |
| Master Calligrapher | 8 | Ink sphere, CL 8+. | Intelligence, Dexterity, Wisdom | Sphere — Ink | No |
| Master of Repairs | 6 | Blacksmith sphere, Close the Crack, CL 6+ | Intelligence, Strength, Constitution | Sphere — Blacksmith | Yes |
| Master Seal Engraver | 4 | Wax sphere. | Intelligence, Wisdom, Constitution | Sphere — Wax | No |
| Medicine Saint | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Sphere — Alchemy | No |
| Medicine-Field Steward | 4 | Harvesting and Gathering, CL 4+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | No |
| Merciful Reaper | 8 | Death, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Death | Yes |
| Merciless Accountant | 10 | Karma sphere, CL 10+ | Wisdom, Charisma, Intelligence | Sphere — Karma | No |
| Meridian Economy | 4 | Qi Cultivation, CL4+ | Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Meridian Fortress | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Meridian Lightning Physician | 8 | Lightning sphere, Medicine proficiency, Life sphere or Pressure Points sphere, CL 8+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Meridian Needle Training | 4 | Thread sphere and Surgeon’s Stitch. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Meridian Overchannel | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Meridian Student | 8 | Iron Fist sphere, Meridian-Sealing Palm, CL 8+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | No |
| Meridian-Breath Discipline | 4 | Body Refining, CL 4+ | Constitution, Wisdom | Body — General Body Refining Insights | Yes |
| Meridian-Pincer Method | 8 | Mantis Style, CL 8+ | Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Method-Bearing Grip | 8 | Weapons sphere, CL 8+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Might-Sphere Discipline | 4 | Narrative access to one approved Might Sphere, CL4+ | Strength, Constitution, Intelligence, Charisma | Qi — Cross-Sphere Insights | No |
| Mine-Warden's Ear | 5 | Metal sphere, Foundation Realm | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Mirror of Frozen Breath | 4 | Ice sphere and either Spirit Awakening or Wisdom 13+ | Wisdom, Intelligence, Constitution | Sphere — Ice | No |
| Missing-Step Technique | 12 | Void Sphere, Void-Touched Cultivator, or Missing-Step inheritance; CL12+ | Dexterity, Intelligence, Charisma | Qi — Secret-Law Insights | No |
| Mission-Born Reputation | 8 | Sect Stewardship, Notice Board Reader, CL 8+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Monkey-Body Adept | 4 | Monkey Style Sphere, CL 4+ | Dexterity, Constitution | Body — Common Might-Sphere Insights | No |
| Monster-Taste Scholar | 4 | Hunger sphere | Constitution, Strength, Wisdom | Sphere — Hunger | No |
| Moon-Thread Weight | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Sphere — Gravity | No |
| Mountain Stance | 4 | Gravity sphere, CL 4+. | Strength, Intelligence, Wisdom | Sphere — Gravity | Yes |
| Mountain-Core Stability | 4 | Survive an Earth, Gravity, Mountain, pressure, or crushing Tribulation | Strength, Constitution, Wisdom | Qi — Tribulation Insights | No |
| Mountain-Forged Frame | 4 | Body Refining, CL 4+ | Strength, Constitution | Body — General Body Refining Insights | Yes |
| Name the Distant Enemy | 12 | Stars, CL 12+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Name-Sealing Demon Chain | 10 | Demon Mark, Fate or Ink sphere, CL 10+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Name-Sheltering Talisman | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Fate | No |
| Named Blade Listener | 4 | Sabers sphere, Spirit Awakening, one named saber focus | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Named Tool Custodian | 4 | Blacksmith sphere, Name the Purpose, CL 4+ | Intelligence, Strength, Constitution | Sphere — Blacksmith | Yes |
| Named Treasure Recall | 8 | Qi Cultivation, one named weapon, shield, instrument, or cultivation implement that recognizes your bond, CL8+ | Intelligence, Wisdom, Charisma | Qi — Martial and Domain Armament Insights | No |
| Nascent Soul Externalization | 16 | Nascent Soul, CL16+ | Intelligence, Wisdom, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Nascent Soul Reserve | 16 | Nascent Soul, CL16+ | Constitution, Wisdom, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Nightmare Feaster | 12 | Dream Qi Cultivator or Dreams Sphere, CL12+ | Wisdom, Charisma | Qi — Forbidden, Condemned, and Predatory Insights | No |
| Nine-Finger Director | 8 | Puppetry sphere, Two-Body Control, CL 8+ | Intelligence, Dexterity, Charisma | Sphere — Puppetry | No |
| No Loose Ends | 10 | Thread sphere, CL 10+. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| No Road Behind Me | 10 | Space sphere, CL 10+. | Intelligence, Wisdom, Dexterity | Sphere — Space | No |
| No-Rout Commander | 10 | Warleader sphere, Rallying Speech or Harangue, CL 10+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Null-Script Adept | 4 | Erode Technique | Wisdom, Intelligence, Charisma | Sphere — Void | No |
| Oathkeeper | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Sphere — Karma | Yes |
| Observatory Heir | 12 | Stars, CL 12+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Obsidian Sculptor | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| One Breath, One Line | 10 | Perfect Shot, CL 10+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| One-Breath Discipline | 8 | Karate, CL 8+ | Strength, Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Open the Outer Maw | 5 | Hunger Sphere, Body Refining, Foundation Realm, Constitution 16+, Stomach Furnace Scripture | Constitution, Strength, Wisdom | Sphere — Hunger | No |
| Open the Outer Ore Insight | 5 | Metal Sphere, Body Refining, Foundation Realm, Iron Body Only Scripture | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Order Ledger Disciple | 6 | Warleader sphere, CL 6+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Orthodox Mask of the Black Scripture | 8 | Daemonic Cultivation, CL 8+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Outer Gate Beloved | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | No |
| Paired-Weapon Instructor | 6 | Dual Wielding sphere, CL 6+ | Dexterity, Strength, Constitution | Sphere — Dual Wielding | No |
| Patient Inscription | 4 | Ink sphere. | Intelligence, Dexterity, Wisdom | Sphere — Ink | Yes |
| Patient Trigger | 4 | Sniper sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Perfect Pitch | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Pill Master’s Eyes | 8 | Alchemy, CL 8+. | Intelligence, Wisdom, Constitution | Sphere — Alchemy | Yes |
| Pill Sovereign’s Ledger | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Sphere — Alchemy | No |
| Plague Physician | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Sphere — Disease | Yes |
| Plague-Bearing Body Insight | 4 | Body Refining, CL4+ | Constitution, Intelligence, Wisdom | Sphere — Disease | No |
| Poise-Tempered Presence | 4 | Beauty sphere, CL 4+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | Yes |
| Poisoned-Meridian Scripture | 12 | Poison Cultivator or Poison Sphere, CL12+ | Constitution, Intelligence, Wisdom | Qi — Forbidden, Condemned, and Predatory Insights | No |
| Poleaxe Door-Guard | 6 | Axes sphere, Poleaxe Gate, CL 6+ | Strength, Dexterity, Constitution | Sphere — Axes | No |
| Portable Workshop | 8 | One preparation-based Sphere or Subpath, CL8+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Prison Warden | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Sphere — Chains | No |
| Profile Archivist | 4 | Weapons sphere, Profile Specialist | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Prop Scripture Initiate | 6 | Drunken Style sphere, Accidental Weapon, CL 6+ | Dexterity, Constitution, Charisma | Sphere — Drunken Style | No |
| Proper Seniority | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Sphere — Sect Stewardship | Yes |
| Proper Weight of the Tool | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Provincial Ley-Line Familiarity | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom | Qi — Imperial Training Insights | No |
| Psychopomp’s Courtesy | 8 | Death sphere, Spirit Awakening, CL8+ | Wisdom, Intelligence, Charisma | Sphere — Death | Yes |
| Pulse-Thread Memory | 4 | Life sphere. | Wisdom, Constitution, Charisma | Sphere — Life | No |
| Puppet Artisan | 4 | Puppetry sphere, proficiency with one appropriate tool, CL 4+ | Intelligence, Dexterity, Charisma | Sphere — Puppetry | No |
| Qi Devourer | 8 | Qi Cultivation, CL8+ | Constitution, Wisdom, Charisma | Qi — General Qi Insights | Yes |
| Qi-Tempered Concentration | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Quarantine Adept | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Sphere — Disease | Yes |
| Quiet After the Shot | 8 | Sniper sphere, CL 8+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Radiance’s Blessing | 4 | Radiance | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Red Execution Discipline | 8 | Axes sphere, Execution Mark, CL 8+ | Strength, Dexterity, Constitution | Sphere — Axes | No |
| Red Sash Pursuer | 4 | Sabers sphere, Red Trail Pursuit | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Red Seal Authority | 10 | Ink sphere, CL 10+. | Intelligence, Dexterity, Wisdom | Sphere — Ink | No |
| Red Thread Sensitivity | 4 | Thread sphere and Spirit Awakening, Karma sphere, Heartbinder, Knot Weaver, or another printed Source Rule authorizing relationship perception | Dexterity, Intelligence, Wisdom | Sphere — Thread | Yes |
| Reeling-Immortal Adept | 4 | Reeling Immortal Sphere, CL 4+ | Dexterity, Constitution, Charisma | Body — Common Might-Sphere Insights | No |
| Refined Golden Bell | 12 | Golden Bell, CL 12+ | Constitution, Wisdom | Body — General Body Refining Insights | Yes |
| Refined Meridian Regulation | 4 | Meridian Regulation, CL4+ | Constitution, Intelligence, Wisdom | Qi — General Qi Insights | Yes |
| Refined Natural Weapon | 4 | Body Refining, CL 4+ | Strength, Dexterity, Constitution | Body — General Body Refining Insights | Yes |
| Refuse the Forbidden Bowl | 4 | Hunger sphere | Constitution, Strength, Wisdom | Sphere — Hunger | No |
| Remote Weapon Conduction | 12 | Domain Armament Link, CL12+ | Dexterity, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Reservoir Core Refinement | 10 | Golden Core Reservoir, CL10+ | Constitution, Intelligence, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Resonance Breaker | 10 | Music sphere, Disruptive Harmony or Silence-Breaking Note, CL 10+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Restorative Circulation | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Wisdom | Qi — General Qi Insights | Yes |
| Restricted Sphere License | 8 | Imperial, sectarian, hereditary, professional, or equivalent authorization; CL8+ | Intelligence, Wisdom, Charisma | Qi — Cross-Sphere Insights | No |
| Returning-Tide Body | 8 | Jujutsu, CL 8+ | Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Ricochet Savant | 6 | Bouncing Shot, CL 6+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| River Without Edges | 10 | Flowing River sphere, CL 10+ | Dexterity, Wisdom, Constitution | Sphere — Flowing River | No |
| Road-and-Wall Adept | 6 | Earth sphere, one Settlement talent, CL 6+ | Constitution, Strength, Wisdom | Sphere — Earth | No |
| Ruin Pearl Handler | 4 | Destruction sphere, Calamity Pearl | Strength, Intelligence, Charisma | Sphere — Destruction | No |
| Ruin Without Hatred | 8 | Unmaking sphere, Spirit Awakening, CL8+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Ruin-Safe Grip | 4 | Unmaking sphere, CL 4+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Samsara Memory | 8 | Samsara-Wheel Cultivator, reincarnation inheritance, or genuine former-life awakening; CL8+ | Intelligence, Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Sand-Born Footwork | 4 | Sand sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Sphere — Sand | No |
| Scripture Breaker | 8 | Ink sphere, CL 8+. | Intelligence, Dexterity, Wisdom | Sphere — Ink | No |
| Seal Breaker | 8 | Talismans Sphere, Cultivator of Seals, Puzzle Cultivator, Calligraphy Cultivator, or another seal-authorized Source Rule, CL8+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Sealed Demon Seed | 4 | Daemonic Cultivation, CL 1+ | Constitution, Wisdom, Charisma | Sphere — Daemonic Cultivation | No |
| Secret Authority Contention | 16 | One Secret Law, CL16+ | Intelligence, Wisdom, Charisma | Qi — Secret-Law Insights | No |
| Sect Imbuement Seal | 12 | Imbuement sphere, Talismans or Formations sphere, CL 12+ | Intelligence, Constitution, Charisma | Sphere — Imbuement | No |
| Sect Infirmary Disciple | 4 | Life sphere. | Wisdom, Constitution, Charisma | Sphere — Life | No |
| Sect Supply Officer | 8 | Harvesting and Gathering, Field Ledger, CL 8+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | No |
| Sect Waxwright | 5 | Wax sphere, CL 5. | Intelligence, Wisdom, Constitution | Sphere — Wax | No |
| Seven-Star Battle Rhythm | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Severed Thread Recovery | 8 | Puppetry sphere, CL 8+ | Intelligence, Dexterity, Charisma | Sphere — Puppetry | No |
| Shared Breath Guardian | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Sphere — Spirit Companions | Yes |
| Shared Breath Method | 4 | Qi Bond Package | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | No |
| Shatter Without Waste | 5 | Ice sphere, Foundation Realm | Wisdom, Intelligence, Constitution | Sphere — Ice | No |
| Shield Orbit Discipline | 8 | Domain Armament capable of Guard Mode, CL8+ | Constitution, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Shield-Breaking Eye | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Sphere — Sabers | No |
| Shieldhook Adept | 4 | Axes sphere, Shield-Catching Beard, CL 4+ | Strength, Dexterity, Constitution | Sphere — Axes | No |
| Siege-Magma Adept | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| Silent Foundation | 5 | Dampen Sound or Muffle Footfall, CL 5+ | Charisma, Wisdom, Constitution | Sphere — Sound | No |
| Silk-Reeling Foundation | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Solar Heart | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Song-Soul Oathbearer | 10 | Spirit Awakening, Music sphere, CL10+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Soul Shackles | 4 | Spirit Awakening, Chains sphere, CL4+ | Strength, Dexterity, Wisdom | Sphere — Chains | No |
| Soul-Devouring Scripture | 12 | Qi Devourer, access to a forbidden or predatory manual, CL12+ | Constitution, Wisdom, Charisma | Qi — Forbidden, Condemned, and Predatory Insights | No |
| Soul-Hearing Listener | 10 | Soul-Echo Hearing, Spirit Awakening, CL10+ | Charisma, Wisdom, Constitution | Sphere — Sound | Yes |
| Soul-Return Witness | 4 | Life sphere, Spirit Awakening | Wisdom, Constitution, Charisma | Sphere — Life | Yes |
| Spatial Artisan | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Sphere — Space | No |
| Spatial Meridian Body | 4 | Body Refining, CL4+, Constitution 15+ | Constitution, Intelligence, Wisdom | Sphere — Space | No |
| Spear-Body Adept | 4 | Spear Sphere and suitable training, CL 4+ | Strength, Dexterity, Constitution | Body — Common Might-Sphere Insights | No |
| Spirit Instrument | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Spirit-Adjacent Scripture | 8 | Narrative access to one approved Spirit-adjacent Sphere, CL8+ | Intelligence, Wisdom, Charisma | Qi — Cross-Sphere Insights | No |
| Spirit-Broker Reputation | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Sphere — Spirit Companions | Yes |
| Spotter’s Thread | 6 | Sniper sphere, CL 6+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Spring-Founding Adept | 12 | Water sphere, Sacred Spring, CL 12+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Stable Core Refinement | 10 | Stable Golden Core, CL10+ | Constitution, Intelligence, Charisma | Qi — Golden Core and Nascent Soul Insights | No |
| Stable Wild Meridian | 4 | Turbulence Package | Intelligence, Charisma, Wisdom | Sphere — Qiweaving | No |
| Stage of Ten Thousand Hands | 12 | Puppetry sphere, Puppet Theater Domain, CL 12+ | Intelligence, Dexterity, Charisma | Sphere — Puppetry | No |
| Standard Bearer Adept | 4 | Warleader sphere, CL 4+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Star-Blooded Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Intelligence | Sphere — Stars | No |
| Star-Sundering Preparation | 14 | Unmaking sphere, CL 14+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Star-Walking Immortal | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Sphere — Stars | No |
| Storm Instrumentalist | 6 | Lightning sphere, Spark-Instrument Method, Music or Sound sphere, CL 6+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Storm Partner | 8 | Lightning sphere, Weather sphere or an allied Weather cultivator, CL 8+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Storm-Eye Disciple | 12 | Air sphere, Court of the Four Winds, CL 12+ | Dexterity, Wisdom, Intelligence | Sphere — Air | No |
| Storm-Eye Meditation | 4 | Survive a Weather, Air, Wind, Storm, or Lightning Tribulation | Intelligence, Wisdom, Charisma | Qi — Tribulation Insights | No |
| Strange Weapon Familiarity | 6 | Weapons sphere, CL 6+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Student of the Returning Current | 4 | Flowing River sphere | Dexterity, Wisdom, Constitution | Sphere — Flowing River | Yes |
| Sword-Bone Insight | 4 | Sword Sphere, CL 4+ | Strength, Dexterity, Constitution | Body — Common Hybrid-Sphere Insights | No |
| Sword-Line Meridian | 12 | Kensei and Sword Sphere, CL 12+ | Dexterity, Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| Sword-Tribulation Survivor | 4 | Survive a Sword, Saber, Blade, Weapon, or Killing-Intent Tribulation | Dexterity, Constitution, Wisdom | Qi — Tribulation Insights | No |
| Sympathetic Effigy Worker | 5 | Wax sphere, CL 5, GM permission. | Intelligence, Wisdom, Constitution | Sphere — Wax | No |
| Talisman Body | 4 | Body Refining, Talismans Sphere, CL4+ | Constitution, Intelligence, Wisdom | Sphere — Talismans | No |
| Talisman Savant | 8 | Talismans Sphere, CL8+ | Intelligence, Wisdom | Qi — Preparation and Strategic Insights | No |
| Talisman Thief | 4 | Talismans sphere or Scoundrel sphere, CL 4+ | Intelligence, Wisdom, Charisma | Sphere — Talismans | No |
| Tempered Knuckles | 4 | Iron Fist sphere, CL 4+ | Strength, Dexterity, Constitution | Sphere — Iron Fist | Yes |
| Tempered Reflexes | 8 | Body Refining, CL 8+ | Dexterity, Constitution | Body — General Body Refining Insights | Yes |
| Ten Thousand Tools Mind | 10 | Weapons sphere, CL 10+ | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Ten-Thousand-Step Pilgrimage | 8 | Yamabushi, CL 8+ | Constitution, Wisdom | Body — Advanced Subpath Insights | No |
| The Hand That Pays | 8 | Unmaking sphere, CL 8+ | Intelligence, Wisdom, Charisma | Sphere — Unmaking | No |
| Thousand-Knot Memory | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Thousand-Lamp Meditation | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Thousand-Mile Forager | 8 | Harvesting and Gathering, CL 8+. | Wisdom, Intelligence, Constitution | Sphere — Harvesting Gathering | No |
| Threaded Weapon Adept | 4 | Thread sphere and proficiency with at least one melee or thrown weapon. | Dexterity, Intelligence, Wisdom | Sphere — Thread | No |
| Thunder Archer | 6 | Lightning sphere, Crackling Arrow or Thunder Arrow, CL 6+ | Dexterity, Intelligence, Charisma | Sphere — Lightning | No |
| Thunderstep | 4 | Qi Cultivation, CL4+ | Dexterity, Intelligence, Charisma | Qi — General Qi Insights | Yes |
| Tidal Body | 4 | Water sphere, CL 4+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Tide-Court Footwork | 12 | Water sphere, Court of the Endless Tide, CL 12+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Tomb Architect | 10 | Death, Formations or Protection, CL 10+ | Wisdom, Intelligence, Charisma | Sphere — Death | No |
| Transformation-Stability Insight | 8 | Transformation Sphere, CL 8+ | Constitution, Wisdom | Body — Common Hybrid-Sphere Insights | No |
| Trap-Sniper Method | 8 | Trap Technician, CL 8+ | Dexterity, Wisdom, Intelligence | Sphere — Sniper | No |
| Tremor-Reader Adept | 8 | Earth sphere, Tremor-Listening Palm, CL 8+ | Constitution, Strength, Wisdom | Sphere — Earth | Yes |
| Twice-Tribulated | 4 | Survive two different Realm Tribulations | Constitution, Wisdom, Charisma | Qi — Tribulation Insights | No |
| Two-Moons Focus | 8 | Dual Wielding sphere, CL 8+ | Dexterity, Strength, Constitution | Sphere — Dual Wielding | No |
| Unbroken Grace | 6 | Beauty sphere, CL 6+ | Charisma, Wisdom, Dexterity | Sphere — Beauty | No |
| Unhidden Path | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Sphere — Radiance | No |
| Unmelting Temper | 10 | Wax sphere, CL 10. | Intelligence, Wisdom, Constitution | Sphere — Wax | No |
| Unshaken Rhythm | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Sphere — Music | No |
| Unyielding Grip | 8 | Body Refining, CL 8+ | Strength, Constitution | Body — General Body Refining Insights | Yes |
| Vessel Artisan | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Sphere — Spirit Companions | Yes |
| Vessel-Body Scripture | 6 | Imbuement Sphere, Body Refining, CL6+ | Constitution, Intelligence, Charisma | Sphere — Imbuement | No |
| Voice That Carries | 6 | Warleader sphere, one Shout talent, CL 6+ | Charisma, Wisdom, Intelligence | Sphere — Warleader | No |
| Void Ward Adept | 4 | Void Ward | Wisdom, Intelligence, Charisma | Sphere — Void | No |
| Void-Body Initiate | 4 | Body Refining, Void Sphere, and a recorded Void initiation, lineage, manual, teacher, tribulation, or other legal access source | Constitution, Wisdom, Intelligence | Sphere — Void | No |
| Void-Touched Core | 4 | Void Sphere, Void-Touched Cultivator, survival of genuine Void exposure, or equivalent Secret access | Constitution, Intelligence, Charisma | Qi — Secret-Law Insights | No |
| Volcanic Collateral Control | 6 | Magma, CL 6+ | Constitution, Strength, Intelligence | Sphere — Magma | No |
| Water-Walking Immortal | 6 | Water sphere, CL 6+ | Wisdom, Dexterity, Constitution | Sphere — Water | No |
| Wax-Tempered Body | 4 | Body Refining or a recorded Wax inheritance, manual, teacher, transformation, or other legal access source | Constitution, Dexterity, Wisdom | Sphere — Wax | No |
| Weapon Exchange Drill | 4 | Weapons sphere | Strength, Dexterity, Constitution | Sphere — Weapons | No |
| Weapon-and-Technique Weave | 4 | Qi Cultivation, proficiency with at least one weapon, CL4+ | Dexterity, Intelligence, Charisma | Qi — Martial and Domain Armament Insights | No |
| Wheel Refuses the End | 16 | Samsara-Wheel Cultivator or reincarnation Secret authority, CL16+ | Constitution, Wisdom, Charisma | Qi — Secret-Law Insights | No |
| White Tiger Restraint | 4 | Metal sphere | Constitution, Strength, Intelligence | Sphere — Metal | No |
| Wind-Line Archer | 6 | Air sphere, Sniper or Barrage sphere, CL 6+ | Dexterity, Wisdom, Intelligence | Sphere — Air | No |
| Wine-Gourd Immortal | 8 | Drunken Fist, CL 8+ | Constitution, Charisma | Body — Advanced Subpath Insights | No |
| Winter Tempered Body | 4 | Ice Sphere and either Body Refining or Constitution 13+ | Constitution, Wisdom, Intelligence | Sphere — Ice | No |
| World-Ringing Bell Keeper | 10 | Resonant Shatter, CL 10+ | Charisma, Wisdom, Constitution | Sphere — Sound | No |
| Wrestling-Body Adept | 4 | Wrestling Sphere, CL 4+ | Strength, Constitution | Body — Common Might-Sphere Insights | No |
