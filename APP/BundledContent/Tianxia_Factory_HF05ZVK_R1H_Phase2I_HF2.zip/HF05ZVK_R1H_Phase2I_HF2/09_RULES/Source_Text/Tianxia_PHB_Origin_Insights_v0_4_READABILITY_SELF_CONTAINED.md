# Tianxia PHB — Origin Insights v0.4

An **Origin Insight** is the first truth a character brings into cultivation. It is chosen at level 0, before the sect trial, and represents a habit, wound, instinct, lesson, oath, talent, or way of seeing the world formed before the character becomes a cultivator.

Origin Insights are not Paths, spheres, Foundations, cultivation methods, or manuals. They do not make a character a cultivator. They show what kind of mortal is about to step into the trial.

## How to Use Origin Insights

Choose one Origin Insight at level 0 unless another rule says otherwise. Your Origin Insight remains part of the character after the sect trial and continues to function as you advance.

Use an Origin Insight whenever its trigger applies. If an Insight says it works once per long rest, once per scene, or during a short rest, use that limit exactly. If more than one reroll could apply to the same d20 test, use only one reroll and use the new result.

## Design Rules

Most Origin Insights grant two simple benefits:

1. a training benefit, such as proficiency, expertise, tool access, language, or trade proficiency; and
2. a defining edge, such as contextual advantage, a specific reroll, a concrete information question, passive survival logic, or clear narrative permission.

Origin Insights avoid new resource pools, combat rotations, bonus dice, sphere access, Path features, Foundation access, or routine active supernatural effects.

If an Origin Insight grants proficiency in a skill, tool, language, or trade proficiency you already have, you may gain expertise in that proficiency instead, unless the Insight says otherwise.

## Core Vocabulary Used by Origin Insights

Origin Insights use normal 5.5e terms such as d20 test, ability check, saving throw, skill, tool, proficiency, expertise, advantage, action, Hit Dice, condition names such as Incapacitated or Frightened, short rest, and long rest. Expertise means you double your Proficiency Bonus for checks that use that proficiency.

A **trade proficiency** is a Background-style proficiency representing a local craft, labor role, ritual practice, coded social language, or practical profession that is narrower than a full skill and broader than a single tool. When a trade proficiency applies, add your Proficiency Bonus to the check. If a normal tool proficiency or skill already covers the task, use the most specific applicable proficiency; do not add your Proficiency Bonus twice.

A **campaign language** is any language, cant, sign system, court language, liturgical language, trade language, clan language, or regional language available in the campaign.

A **Secret effect** is any effect tagged or treated as Secret by a Tianxia rule. An **artifact-backed effect** is an effect created, hidden, protected, or altered by a magic item, spiritual item, talismanic item, legacy item, or other artifact. A **higher-Realm effect** is an effect produced by a creature, object, method, or technique above the character's current Realm.

A **scene** is a single continuous stretch of play focused on one conflict, challenge, investigation, negotiation, journey segment, or other meaningful situation. A scene usually lasts until the immediate situation is resolved, the location or objective meaningfully changes, the party takes a rest, or the GM declares that a new scene has begun. Effects that last “for the scene” or can be used “once per scene” persist through the current situation but do not automatically carry into later encounters, unrelated conversations, downtime, or a new combat.

## Verifiable Information Benefits

Some Origin Insights let you ask a question. When an Origin Insight lets you ask a question, the answer is based on observable evidence, memory, training, symbolic impression, or the current scene. The answer does not reveal hidden facts without evidence, override deception, expose Secret effects automatically, or replace a required check unless the Insight says so.

If no relevant clue, sign, irregularity, or answer exists, the answer can be "none," "unclear," "blocked," or "no obvious sign." That is still a valid result.

## Ordinary and Supernatural Effects

An **ordinary** effect is mundane, non-cultivation, non-artifact, non-Secret, and not protected by a stronger supernatural source.

An Origin Insight can help against ordinary danger when it says so. It does not automatically defeat cultivation techniques, spirit powers, artifacts, Secret effects, higher-Realm abilities, or deliberate magical concealment.

## Reroll Rule

Some Origin Insights allow a reroll. When you use an Origin Insight reroll, you must use the new roll. You cannot use more than one Origin Insight reroll on the same d20 test.

Unless stated otherwise, an Origin Insight reroll refreshes when you finish a long rest.

---

## 1. Street-Hardened

You learned to survive where law arrives late and hunger arrives early.

**Benefit.** You gain proficiency in Deception or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

While in a settlement, ruin, market, alley, dock, slum, or crowded public space, you have advantage on initiative rolls and Wisdom (Perception) checks made against ordinary ambushes, pickpockets, tailing, lookout signals, and sudden street violence.

You cannot be surprised by an ordinary ambush in those places if you are awake, able to move, and not deliberately ignoring danger. This protection does not apply against supernatural concealment, cultivation techniques, artifacts, or an enemy already inside your trusted group.

You also know the fastest obvious route toward an exit, crowd, guard post, hiding place, or immediate shelter in a public space you can perceive.

---

## 2. Hunger Memory

You know what the body becomes when comfort is gone.

**Benefit.** You gain proficiency in Survival or Athletics. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to endure hunger, thirst, exposure, forced marches, sleep deprivation, or ordinary deprivation.

You can always tell when food, water, warmth, or shelter is being wasted, hidden, rationed, poisoned, or controlled as leverage, unless the truth is concealed by a cultivation effect, artifact, or deliberate false trail.

---

## 3. No One Saves You

You learned that waiting for rescue is another way to die.

**Benefit.** You gain proficiency in Acrobatics, Athletics, or thieves' tools. If you already have proficiency in the chosen option, gain expertise in it.

Once per long rest, when you fail a d20 test made to escape restraints, flee pursuit, break free from a grapple, survive a trap, avoid capture, or act before immediate danger closes around you, you may reroll the d20.

You also have advantage on checks made to notice weak restraints, careless guards, unsecured doors, loose bindings, or bad prison habits.

---

## 4. Quick Hands

Your hands move before hesitation can catch them.

**Benefit.** You gain proficiency in Sleight of Hand or thieves' tools. If you already have proficiency in the chosen option, gain expertise in it.

You can conceal, palm, draw, retrieve, or pass a small object on your person without obvious fumbling. If another creature is watching for theft, concealment, contraband, or sleight of hand, make the normal contested check.

You have advantage on checks made to hide small tools, keys, charms, notes, blades, pills, coins, or similar hand-sized objects on your body.

---

## 5. Sleep Light

You never fully trusted safety.

**Benefit.** You gain proficiency in Perception or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

While resting or sleeping lightly, you have advantage on Wisdom (Perception) checks made to notice ordinary noise, movement, light, touch, nearby voices, a change in camp rhythm, or an approaching creature.

If you are sleeping lightly and not Incapacitated, you cannot be surprised by ordinary intruders who must cross open ground, open a door, disturb your belongings, touch you, or enter your immediate sleeping space. This protection does not apply against supernatural concealment, teleportation, dream attacks, or a creature already accepted into the camp.

---

## 6. Unsettling Blood

Something in your presence makes ordinary people hesitate.

**Benefit.** You gain proficiency in Intimidation. If you already have proficiency in Intimidation, gain expertise in it.

When someone senses that your bloodline, aura, curse, ancestry, or nature is strange, you have advantage on Charisma checks made to make them pause, back down, take you seriously, or admit fear.

Spirit-sensitive creatures, trained cultivators, shrine officials, and occult specialists can usually tell that something about you is unusual after interacting with you for 1 minute, unless you are actively concealing it.

---

## 7. Hide the Stain

You grew up concealing a mark, curse, bloodline, shame, or secret.

**Benefit.** You gain proficiency in Deception or disguise kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to hide visible signs of lineage, curse, injury, social origin, spiritual abnormality, fear, shame, or forbidden contact.

When someone studies you for a hidden stigma, you can identify what sign they are focusing on: body, clothing, accent, behavior, documents, aura, blood, family name, or rumor.

---

## 8. Marked by Something

Your life carries a sign others may not understand.

**Benefit.** You gain proficiency in Religion, Arcana, or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify whether a mark, scar, dream-sign, birthmark, curse, omen, strange aura, or spirit pressure is natural, inherited, ritual, spiritual, or cultivation-made.

When a creature reacts strongly to your mark, you can tell whether the reaction is fear, recognition, disgust, reverence, hunger, curiosity, or trained caution.

---

## 9. Born Under Suspicion

People accused you before they knew your name.

**Benefit.** You gain proficiency in Deception or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to detect when someone has already judged you, is looking for an excuse to blame you, or is pretending to ask questions while expecting guilt.

Once per long rest, when you fail a Charisma or Wisdom check made to avoid false blame, deflect suspicion, or prove you are not the immediate threat, you may reroll the d20.

---

## 10. Dream Listener

Your dreams are not always yours alone.

**Benefit.** You gain proficiency in Insight, Perception, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

After each long rest, choose one current danger, mystery, spirit, oath, person, or future opportunity known to your character. Ask one question:

- What emotion clung to it in my dream?
- What symbol repeated around it?
- Did the dream warn me toward it, away from it, or deeper into it?
- Did the dream feel mortal, spiritual, ancestral, demonic, or unclear?

The answer is symbolic, not a complete prediction. If the subject is shielded by stronger magic, cultivation, or secrecy, the answer may be "blocked," "distorted," or "unclear."

You have advantage on checks made to interpret dreams, recognize recurring symbols, resist dream confusion, or notice when a dream is being influenced by an outside force.

---

## 11. Old Dream

Some dreams feel older than your current life.

**Benefit.** You gain proficiency in History, Insight, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail an Intelligence or Wisdom check related to a place, person, symbol, technique, enemy, route, or danger that feels strangely familiar, you may reroll the d20.

When a place, person, symbol, or threat feels tied to a life before this one, choose one impression: danger, debt, loss, promise, betrayal, or unfinished work. You know that impression is emotionally true to your character's echo, even if it is not literal history.

---

## 12. Omen Sense

You notice the world's small warnings.

**Benefit.** You gain proficiency in Insight or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to notice symbolic warnings, unnatural animal behavior, bad-luck patterns, ritual disturbances, weather signs, strange silences, or repeated coincidences.

Once per scene, when you pause to read the situation, ask whether there is an obvious omen, warning pattern, disturbed sign, or repeated symbol present. The answer identifies the sign if one exists; it does not explain the entire danger.

---

## 13. Half-Awake

You learned to live between sleep and waking.

**Benefit.** You gain proficiency in Perception or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to recognize illusions, dreams, possession signs, memory gaps, false awakenings, or attempts to confuse whether you are asleep, awake, or entranced.

When you wake from sleep, trance, unconsciousness, or magical confusion, you can immediately recall the last clear sensory detail before the state began.

---

## 14. Beast Sign

You learned to read the body language of things with teeth.

**Benefit.** You gain proficiency in Animal Handling, Survival, or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify whether a beast is hungry, afraid, territorial, wounded, trained, corrupted, protecting young, defending a den, or preparing to flee.

When a beast tracks, watches, stalks, circles, or tests you, you can tell which behavior it is using if you can observe it for at least 1 round.

---

## 15. Weather Ear

You learned to hear the sky before it speaks.

**Benefit.** You gain proficiency in Nature or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to predict ordinary weather, identify storm signs, read river rise, notice dangerous wind shifts, track seasonal hazards, or prepare camp against exposure.

With 1 minute of observation, you can tell whether the next few hours are likely to bring worsening weather, clearing weather, dangerous travel, or no meaningful change.

---

## 16. Quiet Footsteps

You learned that sound is a kind of confession.

**Benefit.** You gain proficiency in Stealth or Acrobatics. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to move quietly across ordinary floors, stairs, roofs, alleys, underbrush, camps, halls, or sleeping areas.

When you fail a Stealth check by 5 or less while moving slowly, you may choose to stop in place before entering the exposed space, if there is a legal place to stop.

---

## 17. Bitter Root Wisdom

You learned medicine from things that taste bad and save lives.

**Benefit.** You gain proficiency in Nature, Survival, herbalism kit, or Medicine. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to identify common herbs, roots, fungi, teas, poultices, field remedies, spoiled medicine, and ordinary plant toxins.

During a short rest in a natural or stocked environment, you can prepare simple bitter remedies. One creature who spends Hit Dice during that rest may ignore disadvantage on one Constitution check or saving throw caused by ordinary sickness, nausea, bad food, or exposure before its next long rest.

---

## 18. Bureaucratic Eye

You know where power leaves paperwork.

**Benefit.** You gain proficiency in Investigation, History, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to understand permits, seals, rosters, court documents, sect records, tax lists, travel papers, ledgers, or official instructions.

After studying a document, office, queue, gate, or checkpoint for 1 minute, you can identify the person, seal, office, bribe point, missing form, or procedural step most likely to matter next.

---

## 19. Scripture Memory

You were trained to hold exact words inside your mind.

**Benefit.** You gain proficiency in History, Religion, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You can perfectly recall any ordinary, non-artifact text, law, poem, oath, formula, prayer, map, inscription, or instruction you have spent at least 10 minutes studying.

You have advantage on checks made to detect altered wording, missing lines, false quotations, forged doctrine, or corrupted scripture. Magical, Secret, artifact-backed, or mind-altering texts may require a normal check.

---

## 20. Paper Trail

You know that lies become weaker when written down.

**Benefit.** You gain proficiency in Investigation, Insight, or forgery kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to compare handwriting, identify forged seals, track transactions, find contradictions in testimony, or connect people through receipts, travel papers, ledgers, or letters.

After 10 minutes studying a set of mundane records, you can identify one inconsistency, missing document, suspicious repetition, or unusual signature if such a clue is present.

---

## 21. Courtly Caution

You learned that manners are armor.

**Benefit.** You gain proficiency in Insight, Persuasion, or one court or formal campaign language. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to avoid giving offense in formal settings, recognize status order, follow etiquette, identify who should speak first, or notice when politeness hides a threat.

When entering a formal meeting, court, hall, audience, or banquet, you know the safest obvious person to greet first and the most dangerous obvious person to ignore.

---

## 22. Breath Before Thought

You learned to take one breath before the mistake.

**Benefit.** You gain proficiency in Insight, Perception, or meditation, breath, or discipline practice as a trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

Once per long rest, when you fail a Wisdom saving throw or Wisdom ability check because of fear, anger, panic, temptation, distraction, insult, or social pressure, you may reroll the d20.

You have advantage on checks made to remain still, keep silence, wait patiently, or avoid reacting to deliberate provocation.

---

## 23. Body Is a Shrine

You were taught that flesh remembers discipline.

**Benefit.** You gain proficiency in Athletics, Medicine, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify training injuries, strain, poor posture, breath disruption, fasting weakness, overtraining, exhaustion signs, or ordinary body-conditioning mistakes.

During a short rest, you may examine one willing creature. Until its next long rest, that creature has advantage on the next check it makes to continue training, march safely, recover posture, or avoid worsening an ordinary strain.

---

## 24. Formation Curiosity

Patterns have always bothered you until they made sense.

**Benefit.** You gain proficiency in Arcana, Investigation, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to study diagrams, floor patterns, ritual layouts, ward marks, talisman grids, architectural symmetry, or repeated spatial arrangements.

After 1 minute studying a visible pattern, you can tell whether it is decorative, instructional, logistical, ritual, defensive, or deliberately misleading, unless it is concealed by a stronger effect.

---

## 25. Patient Mind

You are difficult to rush when the answer matters.

**Benefit.** You gain proficiency in Investigation, Insight, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

When you spend at least 10 minutes studying a noncombat problem, text, object, route, mechanism, person, negotiation, or social situation, ask one question:

- What detail here is easiest to overlook?
- What part of this seems out of place?
- What would haste most likely get wrong?
- What should be checked before acting?

The answer identifies a real observable clue, risk, or absence of such a clue. It does not reveal hidden information without evidence.

You have advantage on checks made to resist being hurried into a bad decision.

---

## 26. Everything Has a Price

You were taught that money is only one kind of payment.

**Benefit.** You gain proficiency in Persuasion or Investigation. If you already have proficiency in the chosen skill, gain expertise in it.

When bargaining with a creature you can understand, you can identify whether it seems to value coin, favor, safety, status, revenge, secrecy, recognition, protection, or relief more than the thing it is asking for. A creature can conceal this with a contested Deception check against your Insight.

You have advantage on checks made to negotiate trades where you can offer a non-monetary benefit.

---

## 27. Read the Buyer

You know how desire moves across a face.

**Benefit.** You gain proficiency in Insight or Persuasion. If you already have proficiency in the chosen skill, gain expertise in it.

During bargaining, bribery, gift exchange, haggling, trade negotiations, auction scenes, or a similar exchange, you may study one creature for 1 minute and ask one question:

- Does this creature truly want the item or outcome it claims to want?
- Is this creature more afraid of losing face, money, safety, time, or control?
- Is this creature pretending indifference?
- Would a better offer need coin, secrecy, status, protection, or speed?

The answer reflects observable behavior and does not reveal magically concealed thoughts.

You have advantage on Insight checks made during the same exchange.

---

## 28. Family Ledger

You learned that debts outlive the people who create them.

**Benefit.** You gain proficiency in History, Insight, or Investigation. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to remember debts, marriages, grudges, favors, inheritances, old disputes, clan obligations, and who benefited from a past arrangement.

When you learn a family, clan, sect, shop, or patron name, you can tell whether you have heard of any obvious debt, feud, alliance, or reputation tied to it. If none is known to you, you know that as well.

---

## 29. Drill Instinct

Your body remembers command before fear can argue.

**Benefit.** You gain proficiency in Athletics or Intimidation. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on saving throws and checks made to resist fear, intimidation, panic, forced retreat, or effects that would make you abandon an assigned position.

In a chaotic noncombat scene, you can issue one short, clear command to frightened commoners, recruits, servants, or untrained allies who can understand you. Creatures who are not hostile and have no stronger order will follow that command for 1 round if it does not clearly endanger them.

---

## 30. Hold the Line

You know how to stay steady when others flinch.

**Benefit.** You gain proficiency in Athletics or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail a saving throw or ability check to resist being frightened, shoved, knocked prone, intimidated, separated from an ally, or forced to abandon your position, you may reroll the d20.

You have advantage on checks made to brace doors, hold barricades, keep formation, maintain footing, or protect someone directly behind you.

---

## 31. Pain Familiarity

Pain is not new to you.

**Benefit.** You gain proficiency in Athletics or Medicine. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to continue working, moving, climbing, carrying, crawling, marching, or completing a simple physical task while injured, sick, or in physical discomfort. This does not reduce damage or ignore conditions.

You can tell whether pain is likely to be dangerous injury, ordinary strain, deliberate torture, training discomfort, poison, or sickness after observing the symptoms for 1 minute.

---

## 32. Born in the Saddle

You learned distance from the back of a mount.

**Benefit.** You gain proficiency in Animal Handling or land vehicles. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to ride, calm, guide, mount, dismount, evaluate, or care for ordinary riding animals.

When travel depends on mounts, you can identify the most tired mount, the best lead animal, and the first obvious sign of lameness, fear, thirst, or bad terrain.

---

## 33. Open Sky Nerve

You learned courage from wide places and no walls.

**Benefit.** You gain proficiency in Survival, Perception, or Animal Handling. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to resist fear, hesitation, vertigo, weather panic, battlefield noise, or intimidation while outdoors, mounted, in open terrain, or under a visible sky.

When you can see the horizon or a large open route, you know the safest obvious direction to scatter, retreat, regroup, or signal allies.

---

## 34. Painted Face

You learned that a mask can tell the truth safely.

**Benefit.** You gain proficiency in Performance, Deception, or disguise kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to perform a role, hide emotion behind costume, use satire to criticize safely, or make an audience accept a symbolic truth as entertainment.

While performing for a crowd, you can tell whether the crowd is amused, offended, frightened, restless, or waiting for permission to react.

---

## 35. Still Hands

Your hands do not shake when precision matters.

**Benefit.** You gain proficiency in Sleight of Hand, calligrapher's supplies, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made for delicate tool use, fine repair, careful handling, needlework, brushwork, inscription copying, lock manipulation, or small-object placement when time pressure is not immediate danger.

If your hands are free and you are not restrained, ordinary fear, insult, or social pressure does not impose disadvantage on your precision tool checks.

---

## 36. Vanishing Step

You learned to leave the moment before attention arrives.

**Benefit.** You gain proficiency in Stealth or Acrobatics. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail a Dexterity check made to hide, slip away, break line of sight, escape pursuit, or pass through a crowded or cluttered space without being stopped, you may reroll the d20.

You have advantage on checks made to identify the nearest cover, crowd, corner, doorway, window, or obstruction you could use to leave someone's direct attention.

---

## 37. Patient Shadow

You can wait longer than suspicion.

**Benefit.** You gain proficiency in Stealth, Perception, or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to remain hidden, keep watch, tail someone slowly, observe a routine, or wait without fidgeting for at least 10 minutes.

After observing a person, guard post, shop, camp, or route for 10 minutes, you can identify one repeated habit, blind spot, timing pattern, or change from the expected pattern.

---

## 38. Poison Familiarity

You learned that poison is a tool before it is a crime.

**Benefit.** You gain proficiency in poisoner's kit, Medicine, or Nature. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to identify ordinary poisons, venom, bad antidotes, tainted food, toxic plants, dangerous powders, and symptoms of poisoning.

Once per long rest, when you fail a saving throw against an ordinary poison or poisoned food or drink, you may reroll the d20. This does not apply to Secret, artifact-backed, or higher-Realm poisons unless another rule says so.

---

## 39. Shrine Child

You grew up where incense meant listening.

**Benefit.** You gain proficiency in Religion, Insight, or Performance. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to recognize shrine etiquette, household gods, local taboos, offering customs, ancestor tablets, ritual spaces, and signs of neglect or recent worship.

When entering a shrine, graveyard, ancestor hall, or sacred place, you can identify the most obvious respectful first action: bow, silence, incense, cleansing, offering, removal of shoes, avoiding a boundary, or asking permission.

---

## 40. Sincere Offering

You understand that spirits notice form, respect, and intention.

**Benefit.** You gain proficiency in Religion, Insight, or Performance. If you already have proficiency in the chosen skill, gain expertise in it.

When you make a respectful offering, apology, prayer, or request to a minor spirit, ancestor, shrine, or sacred place using appropriate form, your approach does not count as an insult unless you have already offended it, violated its nature, or entered as an enemy.

Once per scene, after making such an offering, ask one question:

- Was the offering accepted, rejected, ignored, or blocked?
- Did the place or spirit react with welcome, warning, hunger, anger, grief, or silence?
- What part of the form mattered most here?

This does not force a spirit to answer, help, forgive, or reveal itself.

---

## 41. Triage Mind

You know what must be treated first.

**Benefit.** You gain proficiency in Medicine or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to assess who is most injured, poisoned, panicking, bleeding, exhausted, or in immediate danger.

As an action, you may examine a creature you can touch or clearly observe. You learn whether its most urgent visible problem is injury, poison, sickness, fear, exhaustion, spiritual pressure, or no obvious emergency.

---

## 42. Steady Hands

Your hands know how to help under pressure.

**Benefit.** You gain proficiency in Medicine, herbalism kit, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to stabilize a creature, bind wounds, hold a patient still, administer medicine, remove a visible irritant, or perform careful work while others are panicking.

Once per long rest, when you fail a Medicine check or tool check made to prevent immediate harm from worsening, you may reroll the d20.

---

## 43. Tool Memory

You remember how a tool is supposed to feel.

**Benefit.** You gain proficiency in one artisan's tool, smith's tools, carpenter's tools, or tinker's tools. If you already have proficiency in the chosen tool, gain expertise in it.

You have advantage on checks made to identify damaged tools, bad repairs, poor materials, missing pieces, unsafe construction, or whether a tool has been used recently.

After 1 minute handling a mundane tool, weapon, lock, harness, hinge, wheel, or mechanism, you can identify the most obvious fault or confirm that no obvious fault is present.

---

## 44. Family Name

Your name arrives before you do.

**Benefit.** You gain proficiency in Persuasion, History, or one language tied to your family, clan, or region. If you already have proficiency in the chosen option, gain expertise in it.

In places where your family, clan, patron, sect, or lineage is recognized, you can usually secure one reasonable courtesy appropriate to your status: an audience, lodging, basic introductions, temporary shelter, formal acknowledgment, or a chance to explain yourself.

This help creates expectations, scrutiny, requests, political consequences, or obligations tied to the name you used. You know before accepting the courtesy whether the expected price is public, private, immediate, or delayed.

---

## 45. Fallen House

You learned nobility from the shape it leaves behind.

**Benefit.** You gain proficiency in History, Insight, or Persuasion. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to recognize ruined families, lost titles, old banners, confiscated estates, fallen patrons, court disgrace, or people pretending their decline has not happened.

When someone invokes old status, you can tell whether they are relying on current power, remembered respect, hidden allies, debt, fear, or empty habit.

---

## 46. Invisible in Plain Sight

You learned that servants see what masters ignore.

**Benefit.** You gain proficiency in Stealth, Insight, or one service trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

In kitchens, halls, dormitories, courtyards, storehouses, stables, and servant spaces, you have advantage on checks made to move without drawing attention while dressed and behaving appropriately for the role.

You have advantage on checks made to overhear routine information while performing a believable task. This does not hide you from a creature actively searching for you or from someone who knows you do not belong.

---

## 47. Listen While Serving

You learned that important people speak freely near the useful and ignored.

**Benefit.** You gain proficiency in Insight, Perception, or one service trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to overhear conversations, read household moods, notice who gives orders, identify who is actually obeyed, or learn routine information while performing a believable service task.

After serving, cleaning, carrying, waiting, cooking, grooming animals, or performing another believable task for 10 minutes, you can identify one person who seems more important than their official role suggests, if such a person is present.

---

## 48. Spirit Pressure

You know the feeling of being watched by what is not flesh.

**Benefit.** You gain proficiency in Religion, Insight, or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to notice possession signs, spiritual pressure, haunted spaces, shrine moods, hostile ancestor attention, spirit residue, or the sense that an unseen presence is observing the scene.

When you enter a place with obvious spiritual pressure, you can tell whether the pressure feels welcoming, hostile, hungry, grieving, watchful, sleeping, or disturbed.

---

## 49. Grave Courtesy

You know the dead are not furniture.

**Benefit.** You gain proficiency in Religion, History, or Medicine. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify burial customs, corpse handling errors, grave taboos, ancestor rites, battlefield dead, missing remains, or signs that a body has been moved after death.

When you spend 1 minute respectfully examining a corpse, grave, memorial, or ancestor tablet, you can identify one obvious irregularity: wrong placement, missing offering, improper name, disturbed soil, old injury, recent movement, or no obvious irregularity.

---

## 50. Perfect the Stroke

You learned that one line can hold a lifetime of correction.

**Benefit.** You gain proficiency in calligrapher's supplies, painter's supplies, or one artisan's tool. If you already have proficiency in the chosen tool, gain expertise in it.

You have advantage on checks made to copy a symbol, repair a line, reproduce a diagram, match handwriting, trace a seal, or identify whether a visible mark was made by a careful, rushed, forged, damaged, or trembling hand.

After studying a mundane written mark, painted line, seal, inscription, or diagram for 1 minute, you can reproduce its visible shape accurately enough for ordinary comparison. This does not copy magical power, cultivation function, or hidden meaning.
