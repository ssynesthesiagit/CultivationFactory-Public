# Factory Canon Conflict Resolutions — Phase 1

This file is an authority overlay for the HF05ZVK-R1F Canon Corpus Phase 1 integration. It does not grant character abilities. It resolves source precedence when retained support books contain older text.

## Controlling Path and resource rules

1. `Canonical/PHB/Tianxia_PHB_Chapter_03_Paths_and_Shared_Path_Rules_R2.md` controls shared Path mathematics, Cultivation Points, recovery, multi-Path cultivation, Source CL, and Realm Suppression.
2. The current Body R8, Qi R19, and Spirit R7 player chapters control their respective Path features and resource rules.
3. The generic downtime sentence in PHB v0.7 saying a cultivation session restores a full Path resource does not override Chapter 03 or the individual Path chapters.

## Cultivation Insights

The R4 Central Cultivation Insights records and Compendium R1 are the sole current Insight authority. Older Path-specific Insight lists and Insight entries embedded in the Sphere Compendium are retained only as historical source provenance where the R4 record says they were inherited. They do not override the R4 text.

## Spirit Companions

The Spirit Awakening Rules Reference R3, Bonded Companions Universal Combat Chassis R2, and Spirit Companions Integration Overlay R1 control where they conflict with older Spirit Companions text in the Sphere Compendium or PHB.

## Subpaths and variants

Qi R19, Body R8, and Spirit R7 compendia control their current Subpaths and traditions. Chapter 08 controls player-facing access classification and selection. Qi parent/variant relationship documents control Qi replacement relationships.

## Retained support sources

The retained Foundations, Methods, Backgrounds, Origin Insights, manuals, GM Guide, and Sphere Compendium remain active for subjects not superseded above. An older support source cannot override a newer controlling source merely because it contains similar wording.
