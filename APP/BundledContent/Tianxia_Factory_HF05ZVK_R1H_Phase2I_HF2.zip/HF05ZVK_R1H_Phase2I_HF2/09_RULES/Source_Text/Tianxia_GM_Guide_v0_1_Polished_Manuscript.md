# Tianxia: Cultivation - The Immortal’s Path
## GM Guide v0.1 Full Manuscript Assembly

## Editorial Assembly Note

This polished manuscript integrates Chapters 0-18, including the bridge chapters for Running Cultivation Scenes and Training. Repeated internal audit language has been reduced, chapter transitions have been smoothed, and terminology/table style has been normalized while preserving Core Rules Reference v0.3 authority.

## Chapter List

- Chapter 0 - Authority, Scope, and How to Use This Guide
- Chapter 1 - GM Adjudication Core
- Chapter 2 - Character State and Records for GMs
- Chapter 3 - Running Cultivation Scenes
- Chapter 4 - Training, Spheres, Talents, Manuals, and Lineages
- Chapter 5 - Advancement, AP, Breakthroughs, and Bottlenecks
- Chapter 6 - Consequences, Failure, and Recovery
- Chapter 7 - Foundations and Methods in Play
- Chapter 8 - Realm Suppression, Teaching Duels, and Trials
- Chapter 9 - Combat, Encounters, and Cultivation Effects
- Chapter 10 - Tribulations and Cultivation Weight
- Chapter 11 - Sects, Factions, Oaths, and Social Play
- Chapter 12 - Exploration, Spirit Sites, Travel, and Downtime
- Chapter 13 - Treasure, Items, Pills, Talismans, Materials, and Crafting
- Chapter 14 - Secret, Forbidden, Restricted, and Late-Game Power
- Chapter 15 - GM Records and Campaign Ledger
- Chapter 16 - Optional Modules and Variant Pacing
- Chapter 17 - Appendix A: GM Procedure Cards
- Chapter 18 - Appendix B: Expansion Order and Final Assembly


---
# Chapter 0 - Authority, Scope, and How to Use This Guide

## 0.1 What This Book Is

This book is the GM-facing procedure guide for **Tianxia: Cultivation - The Immortal’s Path**. It teaches the GM how to run cultivation scenes, records, breakthroughs, consequences, sect play, exploration, treasure, combat, and campaign ledgers under the current rules spine.

This book is not the primary rules authority. The primary rules authority is **Tianxia Core Rules Reference v0.3**.

The AI-facing procedure support layer is **AI-Facing Tianxia Pure Mechanics Core v0.3**.

The GM Guide explains, operationalizes, and organizes those rules for play.

## 0.2 Authority Order

Use this authority order.

```yaml
authority_order:
 1: Tianxia Core Rules Reference v0.3
 2: AI-Facing Tianxia Pure Mechanics Core v0.3 for procedure and schema support
 3: Tianxia PHB v0.3 for player-facing explanation
 4: current subsystem catalogs inside their scopes
 5: this GM Guide for GM procedures and campaign operations
 6: local rulings recorded by the GM
```

If this GM Guide and Core v0.3 conflict, Core v0.3 controls.

If a local ruling and this GM Guide conflict, the GM should review the local ruling and either narrow, retire, or rewrite it as a campaign-specific variant.

## 0.3 Source Rule Discipline

A **Source Rule** is the specific rule, feature, item, hazard, formation, manual, Method, Foundation, consequence, monster ability, or local ruling that creates a mechanical effect.

Use this rule:

```text
Description can justify a question. It does not create a mechanic by itself.
```

This principle protects the game from hidden mechanics.

A place can be holy without granting CP recovery.
A manual can be ancient without granting instant mastery.
An elder can be terrifying without imposing a condition.
A treasure can be famous without granting a Sphere.
A trial can be dramatic without granting a CL.

When a mechanical change matters, write a record.

## 0.4 Records Are the Campaign Memory

Tianxia is a persistent cultivation game. Characters carry forward:

- AP;
- CP state;
- known Spheres;
- talents;
- Recorded Arts;
- Forged Techniques;
- Foundation;
- Method;
- consequences;
- items;
- social access;
- oaths;
- bottlenecks;
- local rulings.

If it changes future play, record it.

## 0.5 How to Use This Book

Use Chapters 1-2 first. They define the GM’s adjudication loop and the character state model.

Use Chapters 3-4 when running cultivation scenes, training, Spheres, talents, manuals, lineages, and Recorded Arts.

Use Chapters 5-6 for advancement, breakthroughs, bottlenecks, failure, consequences, and recovery.

Use Chapters 7-10 for the core high-impact play structures: Foundations, Methods, Realm suppression, combat, encounters, and tribulations.

Use Chapters 11-13 for campaign infrastructure: sects, exploration, downtime, Spirit Sites, treasure, items, pills, talismans, materials, and crafting.

Use Chapters 14-16 for rare power, campaign ledgers, optional modules, and pacing variants.

Use Chapter 17 as table-ready procedure cards.

Use Chapter 18 for final assembly and audit guidance.

## 0.6 GM Guide Boundary Checklist

```yaml
chapter_0_audit:
 core_v0_3_controls_rules: true
 ai_v0_3_supports_procedure: true
 Source_Rule_discipline_present: true
 records_as_campaign_memory_present: true
 no_mechanics_from_description_only: true
 no_hidden_universal_subsystems: true
```

# Chapter 1 - GM Adjudication Core

## 1.1 Chapter Purpose

Tianxia uses a lot of character records: Path, CP, Spheres, talents, Recorded Arts, Forged Techniques, Foundation, Method, consequences, manuals, items, spirit sites, sect access, and local rulings. The GM’s first job is not to make every dramatic description into mechanics. The GM’s first job is to identify which records and Source Rules actually apply.

This chapter gives the GM a repeatable adjudication procedure.

Use it whenever a player asks:

- “Can I do this with my cultivation?”
- “Does this aura pressure them?”
- “Can this manual teach me that?”
- “Can this item restore my qi?”
- “Can my Foundation help here?”
- “Can I improvise a technique?”
- “Does this failure injure my dantian?”
- “Does this sect relationship give me access?”
- “Can I convert, swap, repair, seal, or change this record?”

The answer must come from one of three places:

1. a current Source Rule;
2. Core Rules Reference v0.3;
3. a narrow local ruling record.

If none of those supports the effect, the answer is unsupported.

## 1.2 The Adjudication Principle

Use this principle:

```text
Description can justify a question. It does not create a mechanic by itself.
```

A cultivator can radiate pressure, have terrifying killing intent, hold an ancient jade slip, stand in a holy cave, or carry a priceless sword. None of that automatically creates damage, disadvantage, Frightened, AP, CP recovery, training success, breakthrough bonuses, item powers, or character record changes.

Mechanics require a Source Rule or a local ruling record.

## 1.3 GM Adjudication Loop

Use this loop whenever a case is uncertain.

```yaml
gm_adjudication_loop:
 - identify_player_intent
 - identify_relevant_character_records
 - identify_relevant_scene_records
 - identify_relevant_Source_Rule
 - check_Core_v0_3_default
 - classify_result
 - define_required_fields
 - resolve_roll_or_effect
 - update_records
 - record_local_ruling_if_needed
```

### Step 1: Identify Player Intent

Ask what the player is trying to accomplish mechanically.

| Player Statement | Intent to Identify |
|---|---|
| “I release my pressure.” | Intimidate? Frighten? Force movement? Reveal Realm? Start combat? |
| “I study the jade slip.” | Learn a Recorded Art? Identify a manual? Gain AP? Detect danger? |
| “I circulate my Method harder.” | Spend CP? Break a limit? Attempt recovery? Trigger strain? |
| “I lean on my Foundation.” | Apply a passive bonus? Use an active effect? Resist consequence? |
| “I use spirit stones to recover.” | Restore CP? Fuel an item? Pay for a ritual? Substitute materials? |

If the player’s intent has no mechanical consequence, the GM can narrate it without creating a rule.

### Step 2: Identify Relevant Character Records

Look at the character sheet and records.

Relevant records can include:

- Path;
- CL and Realm;
- Path key ability;
- current CP and max CP;
- known Spheres;
- talents;
- Recorded Arts;
- Forged Techniques;
- Foundation;
- Primary Method;
- consequences;
- items;
- lineage;
- sect access;
- local rulings.

Do not assume a record exists because it sounds appropriate. If it is not on the character sheet or granted by Source Rule, it is not available.

### Step 3: Identify Scene Records

Scene records include:

- spirit site;
- formation;
- hazard;
- suppression field;
- sect trial;
- manual inheritance;
- item state;
- social restriction;
- vow or oath;
- current local ruling;
- environmental effect.

A scene can have mechanics only if the GM has defined them or a Source Rule provides them.

### Step 4: Identify the Source Rule

Find the narrowest current rule that applies.

```yaml
source_priority:
 - specific current Source Rule
 - Core Rules Reference v0.3
 - current subsystem catalog within its scope
 - AI Mechanics Core v0.3 for procedure/schema support
 - local ruling record
```

The AI Mechanics Core does not override Core v0.3. It tells you how to run and record procedures.

### Step 5: Check Core v0.3 Defaults

If no specific Source Rule exists, apply Core defaults.

```yaml
core_defaults:
 no_default_retraining: true
 no_default_respec: true
 no_default_refund: true
 no_default_record_replacement: true
 no_default_ambient_CP_recovery: true
 no_default_spirit_stone_CP_recovery: true
 no_default_spirit_stone_AP_award: true
 no_universal_pressure_mechanic: true
 no_universal_aura_reading_DC: true
 no_universal_reputation_face_karma_score: true
 no_universal_item_binding_limit: true
 no_universal_Harvest_Lot_quality_ladder: true
 no_full_tribulation_for_every_breakthrough: true
```

### Step 6: Classify the Result

Classify the case before resolving it.

| Classification | Meaning |
|---|---|
| Rules-confirmed | A rule directly resolves the case |
| Source-rule-required | The effect could exist, but not without specific rule text |
| Local-ruling-required | Play needs a narrow ruling because no source defines it |
| Unsupported | No current rule grants the effect |
| Invalid | The request violates current rules |

### Step 7: Define Required Fields

If the effect is mechanical, define the fields.

```yaml
required_effect_fields:
 actor: required_if_anyone_uses_it
 source: required
 trigger: required_if_reactive_or_conditional
 activation: required_if_used
 cost: required_if_any
 target_range_area: required_if_external
 roll_DC_save: required_if_uncertain_or_resisted
 success_effect: required
 failure_effect: required_if_failure_has_special_result
 duration: required_if_not_instant
 limit: required_if_repeatable_or_restricted
 record_update: required_if_persistent
```

If a field is missing, do not fill it with the strongest plausible interpretation. Either find a source, narrow the ruling, or reject the effect.

### Step 8: Resolve Roll or Effect

Use normal 5.5e procedures unless Tianxia changes the case.

For cultivation procedures, common rolls include:

```yaml
common_tianxia_rolls:
 cultivation_check: d20 + Path key ability modifier + Proficiency Bonus
 cultivation_save_DC: 8 + Proficiency Bonus + Path key ability modifier
 new_sphere_learning_DC: 10 + 1d4 + number of different Spheres known
 known_sphere_talent_training_DC: 10 + talents already known from that Sphere
 recorded_art_training_DC: 10 + Difficulty + 2 × arts learned at current CL
 technique_forging_DC: 10 + final Complexity + number of Spheres used
```

Use a standard ability or tool check only when the case is mundane or the Source Rule calls for it.

### Step 9: Update Records

Update records immediately if the ruling creates persistent change.

Record changes can include:

- CP spent or restored;
- AP awarded;
- talent learned;
- Recorded Art learned;
- consequence added;
- item expended;
- spirit site depleted;
- local ruling created;
- bottleneck created;
- social access changed;
- trial result recorded.

If no record changes, state that the result is scene-only.

### Step 10: Record the Local Ruling

If the GM created a ruling that may repeat, write it down.

```yaml
local_ruling_record:
 title: string
 scene: string
 source_gap: string
 ruling: string
 affected_records: []
 activation: null_or_string
 cost: null_or_record
 roll_or_DC: null_or_record
 success_result: string
 failure_result: string
 duration: string
 precedent: none | local_only | campaign_precedent | review_after_session
 expires: null_or_condition
```

A local ruling should be narrow. Do not let one ruling create a broad subsystem.

## 1.4 Common Adjudication Cases

### 1.4.1 “I Use Pressure”

Pressure is descriptive unless a Source Rule defines mechanics.

Allowed without a Source Rule:

- describe oppressive presence;
- signal Realm difference;
- intimidate through roleplay;
- narrate weaker mortals reacting;
- create a social cue.

Not allowed without a Source Rule:

- damage;
- Frightened;
- disadvantage;
- forced movement;
- action denial;
- automatic detection;
- suppression;
- CP loss;
- universal pressure DC.

If a player wants mechanical pressure, ask which talent, Path feature, Recorded Art, Forged Technique, item, Foundation, Method, monster ability, hazard, or Source Rule creates it.

### 1.4.2 “This Manual Should Teach Me More”

A manual is a source. It grants only what it says.

A manual can:

- teach a Recorded Art;
- provide training access;
- reveal a clue;
- impose a restriction;
- contain false theory;
- create risk;
- grant AP if its Source Rule says so.

A manual does not automatically grant:

- a Sphere;
- a talent;
- a Method;
- a Foundation;
- AP;
- breakthrough bonus;
- modification rights;
- prerequisite bypass.

### 1.4.3 “This Spirit Site Should Restore Me”

A Spirit Site requires a Source Rule for benefits.

It can provide CP recovery, AP, training bonuses, breakthrough bonuses, materials, risks, tribulations, or consequences only if its record says so.

If the site record has no mechanics, it is descriptive.

### 1.4.4 “This Item Is Powerful”

An item does what its Source Rule says.

A powerful item does not automatically:

- restore CP;
- grant AP;
- grant a Sphere;
- grant a talent;
- grant a Recorded Art;
- grant Method access;
- change Foundation;
- remove consequences;
- create binding limits.

If the item has unclear text, define activation, cost, target, duration, limit, risk, and record update before use.

### 1.4.5 “Can I Change My Build?”

No default rule permits free character editing.

The GM can allow transformation, correction, sealing, successor states, recovery, or source-rule replacement only within a defined procedure.

If the player wants a different direction, create an in-world project rather than a free record edit.

### 1.4.6 “Can I Improvise a Technique?”

Use Emergency Forging only if there is real crisis and meaningful risk.

Routine improvisation in safe conditions is not Emergency Forging.

If there is no immediate crisis, use normal Forged Technique research or a local scene ruling without creating a permanent technique.

### 1.4.7 “Does Failure Give Me a Bonus?”

Failure can create insight or a failure-born option only if a Source Rule or local ruling defines it.

Failure does not automatically grant:

- AP;
- Enlightenment die;
- talent;
- bonus Insight;
- scar-boon;
- technique seed;
- retry advantage.

When failure creates a benefit, it should also preserve the cost, wound, scar, delay, burden, or risk that made the failure meaningful.

## 1.5 Local Ruling Discipline

### 1.5.1 Make Rulings Narrow

A local ruling should answer the specific case.

Bad ruling:

```text
Any broad rule claiming that Core Formation presence frightens all mortals on its own is invalid.
```

Better ruling:

```text
In this sect trial chamber, the elder’s formation amplifies Realm pressure. Mortals who try to lie while standing in the formation must pass a Wisdom save or become unable to speak the false answer for 1 round.
```

The better ruling has a source, place, trigger, effect, duration, and limit.

### 1.5.2 Do Not Invent Hidden Subsystems

Avoid creating universal systems accidentally.

Do not create:

- universal pressure score;
- aura-reading DC ladder;
- universal face/reputation/karma score;
- universal item binding limit;
- universal Harvest Lot quality ladder;
- universal spirit site reward table;
- universal manual risk table;
- universal automatic scar-boon table.

Optional modules can exist later, but they must be labeled as optional modules and must say what they replace.

### 1.5.3 Review Precedent

At the end of a session, review local rulings.

| Precedent | Meaning |
|---|---|
| none | one-time scene resolution |
| local only | applies only in this location/source/event |
| campaign precedent | repeatable rule for this campaign |
| needs rewrite | should become a Source Rule or be removed |
| invalid after review | should not be used again |

## 1.6 GM Examples

### Example A: Pressure in a Duel

A CL10 cultivator says, “I release my Core Formation pressure to make the bandits flee.”

```yaml
intent: frighten_or_force_retreat
source_rule_found: none
core_default: pressure_descriptive_unless_Source_Rule
classification: unsupported_as_mechanical_pressure
allowed_result: intimidating_description_or_normal_social_check
record_update: none
```

GM ruling:

```text
You can describe your aura flaring and make a normal Charisma check if you are trying to intimidate them. It does not automatically impose Frightened or force movement without a Source Rule.
```

### Example B: Jade Slip with No Difficulty

A player wants to learn a Recorded Art from a jade slip. The slip names the art but has no Difficulty.

```yaml
intent: learn_Recorded_Art
source_rule_found: partial
missing_field: Recorded Art Difficulty
classification: local_ruling_required
gm_action: assign_Difficulty_before_training
record_update: jade_slip_record_updated
```

GM ruling:

```text
This art is Difficulty 3 because it is complete but written in dense sect notation. You can train it using the Recorded Art DC formula.
```

### Example C: Spirit Cave Recovery

Players rest inside a dense qi cave and ask for full CP.

```yaml
intent: recover_CP
source_rule_found: none
core_default: no_default_environment_CP_recovery
classification: unsupported
allowed_result: normal_rest_or_Cultivation_Session_recovery
record_update: none
```

GM ruling:

```text
The cave feels rich, but it has no defined recovery rule yet. You recover only through your normal rest and Cultivation Session rules.
```

### Example D: Failed Breakthrough

A character fails a Realm breakthrough.

```yaml
intent: resolve_failed_breakthrough
source_rule_found: Core_v0_3
AP_after: floor(required_AP_for_attempted_next_CL / 2)
CL_change: false
consequence: only_if_Source_Rule_or_local_ruling
free_respec: false
record_update: breakthrough_record
```

GM ruling:

```text
Your CL does not increase. Your AP progress drops to half the required amount for the attempted breakthrough. I am adding a bottleneck only if the failure result or scene consequence defines one.
```

# Chapter 2 - Character State and Records for GMs

## 2.1 Chapter Purpose

Tianxia is record-heavy because cultivation changes the character over time. A character is not only a class, level, and inventory. A character also has a cultivation route, known Spheres, talents, manual knowledge, Foundation, Method, consequences, AP state, item state, faction access, and local rulings.

The GM needs a stable record model so that:

- advancement is fair;
- consequences persist;
- failures matter;
- no one receives untracked free benefits;
- source access is clear;
- future sessions can resume cleanly;
- AI tools and factory validators can import the same character state.

This chapter defines what the GM should track.

## 2.2 The Character State Record

Every Tianxia character should have a character state record.

```yaml
character_state:
 identity:
 character_id: string
 name: string
 player: string
 cultivation:
 CL: integer
 Realm: string
 Path: Body Refining | Qi Cultivation | Spirit Awakening
 Path_key_ability: string
 Path_key_modifier: integer
 PB: integer
 durability:
 hit_die: string
 maximum_HP: integer
 current_HP: integer
 hit_dice_current: string
 resource:
 CP_type: Stamina | Qi | Resonance
 maximum_CP: integer
 current_CP: integer
 base_formula: "CL × Path key ability modifier"
 method_modifier: integer
 other_modifiers: []
 temporary_modifiers: []
 zero_CP_incidents: []
 recovery_limits: []
 growth:
 AP_progress: integer
 AP_threshold: integer
 breakthrough_state: null_or_record
 choices:
 background: record
 origin_insights: []
 known_spheres: []
 talents: []
 level_talents_by_CL: {}
 trained_choices_by_CL: {}
 new_sphere_bonus_talents: []
 arts:
 manuals_and_lineages: []
 recorded_arts: []
 forged_techniques: []
 cultivation_architecture:
 foundation: null_or_record
 primary_method: null_or_record
 non_primary_methods: []
 state_pressure:
 consequences: []
 conditions: []
 suppression: null_or_record
 assets:
 items: []
 materials: []
 currency: []
 campaign:
 faction_records: []
 social_records: []
 local_rulings: []
 unresolved_questions: []
```

This record can be kept in a sheet, JSON, campaign notebook, GM Screen import, or character package. The format can vary. The fields should not vanish.

## 2.3 Identity and Authority Fields

### 2.3.1 Identity

Track:

```yaml
identity:
 character_id: string
 name: string
 player: string
 source_package: null_or_string
 current_authority:
 rules_spine: Tianxia_Core_Rules_Reference_v0_3
 ai_layer: AI_Facing_Tianxia_Pure_Mechanics_Core_v0_3
```

A character ID matters when importing to tools or resolving same-name characters.

### 2.3.2 Source Package

If the character came from a package, record the package name and hash.

```yaml
source_package:
 filename: string
 sha256: string
 audit_verdict: string
```

This prevents later confusion over whether a character is using old rules.

## 2.4 CL, Realm, Path, and PB

### 2.4.1 CL and Realm

Track CL and Realm directly.

```yaml
CL_to_Realm:
 0: Level 0 / pre-cultivation
 1-4: Mortal / early cultivation
 5-9: Foundation
 10-14: Core Formation
 15-19: Nascent Soul
 20: True Immortality / final standard Realm
```

If Realm and CL conflict, CL determines the baseline Realm unless a Source Rule creates an exception.

### 2.4.2 Path

Track one Path.

```yaml
paths:
 Body Refining:
 key_ability: Constitution
 hit_die: d12
 CP_type: Stamina
 Qi Cultivation:
 key_ability_options: [Intelligence, Charisma]
 hit_die: d8
 CP_type: Qi
 Spirit Awakening:
 key_ability: Wisdom
 hit_die: d8
 CP_type: Resonance
```

There is no multipathing by default.

### 2.4.3 Proficiency Bonus

Track PB by CL.

```yaml
PB_by_CL:
 1-4: 2
 5-8: 3
 9-12: 4
 13-16: 5
 17-20: 6
```

If a character is under full Realm suppression, record the suppressed PB separately. Do not overwrite the character’s actual PB.

## 2.5 CP and Recovery State

### 2.5.1 CP Record

```yaml
cp_record:
 type: Stamina | Qi | Resonance
 maximum: integer
 current: integer
 base_formula: "CL × Path key ability modifier"
 method_modifier: integer
 other_modifiers: []
 temporary_modifiers: []
 zero_CP_incidents: []
 recovery_limits: []
```

### 2.5.2 Maximum CP

Calculate maximum CP from Core v0.3:

```yaml
maximum_CP: CL × Path key ability modifier
```

Then apply Method and Source Rule modifiers.

Do not add flat CL to maximum CP unless a Source Rule says so.

### 2.5.3 Current CP

Current CP is separate from maximum CP.

When max CP rises, current CP does not refill by default.

When max CP falls below current CP, reduce current CP to the new maximum unless a Source Rule says otherwise.

### 2.5.4 0 CP Incidents

Track when a character is newly reduced to 0 CP.

```yaml
zero_CP_incident:
 scene: string
 source: string
 CP_before: integer
 CP_after: 0
 exhaustion_added: 1
```

Do not repeatedly trigger the 0 CP rule unless the character rose above 0 CP and was reduced to 0 again.

### 2.5.5 Recovery Limits

Track limited recovery uses.

```yaml
recovery_limits:
 body_refining_short_rest_stamina_recoveries_used: integer
 body_refining_short_rest_stamina_recoveries_limit: 2
 cultivation_session_used_since_long_rest: boolean
```

Qi and Resonance do not have default short-rest recovery.

## 2.6 Background, Origin Insight, Spheres, and Talents

### 2.6.1 Background Record

```yaml
background:
 name: string
 equipment: []
 background_sphere: null_or_record
 background_talent: null_or_record
 alternate_benefit: null_or_record
```

A Background Sphere and Background Talent do not consume trained choices, the level talent, or the New-Sphere Bonus Talent.

### 2.6.2 Origin Insights

Track Origin Insights as persistent records.

```yaml
origin_insight:
 name: string
 source: string
 effect: string
 status: active | sealed | dormant | transformed | removed
```

### 2.6.3 Known Sphere Record

```yaml
known_sphere:
 name: string
 source: string
 base_ability: string
 talents_known: []
 access_status: active | known | sealed | dormant | unstable | transformed | suppressed | removed
 restrictions: []
 notes: []
```

There is no maximum-known-Spheres rule.

### 2.6.4 Talent Record

```yaml
talent:
 name: string
 sphere: string
 source: string
 acquisition_method: background | sect_trial | level_talent | trained_choice | New-Sphere Bonus Talent | Source Rule
 activation: string
 CP_cost: null_or_integer
 roll_DC_save: null_or_record
 effect: string
 duration: string
 limits: []
 status: active | passive | known | sealed | dormant | unstable | transformed | suppressed | removed
```

### 2.6.5 Level Talents

Track level talents by CL.

```yaml
level_talents_by_CL:
 CL1: talent_id
 CL2: talent_id
 CL3: talent_id
```

The CL1 sect-trial talent counts as the CL1 level talent unless a Source Rule says otherwise.

### 2.6.6 Trained Choices

Track trained choices by CL.

```yaml
trained_choices_by_CL:
 CL3:
 used: 2
 limit: 3
 entries:
 - type: known_sphere_talent
 result: success
 record_added: talent_id
 - type: Recorded_Art
 result: failure
 record_added: null
```

Unused trained choices do not carry forward by default and do not convert to other benefits.

## 2.7 Manuals, Lineages, and Recorded Arts

### 2.7.1 Manual Record

```yaml
manual:
 name: string
 type: manual | jade_slip | mural | inheritance | journal | teacher_record | other
 source: string
 contents:
 recorded_arts: []
 methods: []
 warnings: []
 recipes: []
 theory: []
 false_routes: []
 restrictions: []
 risks: []
 mechanics_granted: []
```

A manual grants only what its Source Rule grants.

### 2.7.2 Lineage Record

```yaml
lineage:
 name: string
 source: string
 relationship_type: teacher | sect | inheritance | bloodline | spirit | manual_tradition | route | other
 access_grants: []
 restrictions: []
 obligations: []
 risks: []
 mechanics: []
```

Lineage access is not a universal entitlement. Track exact benefits and restrictions.

### 2.7.3 Recorded Art Record

```yaml
recorded_art:
 name: string
 source: string
 Difficulty: integer
 CL_learned: integer
 status: active | known | sealed | dormant | unstable | transformed | suppressed | removed
 activation: string
 cost: null_or_record
 range_target_area: null_or_record
 roll_DC_save: null_or_record
 effect: string
 duration: string
 limits: []
 component_tags: []
 notes: []
```

A Recorded Art does not grant component Spheres or talents by default.

### 2.7.4 Recorded Art Count by CL

Track how many Recorded Arts the character learned at the current CL.

```yaml
recorded_arts_learned_by_CL:
 CL5: 2
 CL6: 0
```

This count affects Recorded Art training DC and resets when CL changes.

## 2.8 Forged Techniques

### 2.8.1 Forged Technique Record

```yaml
forged_technique:
 name: string
 source: string
 creator_or_learner: string
 CL_learned: integer
 Realm: string
 Complexity: integer
 Base_Form: string
 source_expressions: []
 Primary_Sphere_Effect: string
 Secondary_Sphere_Effects: []
 action: string
 CP_cost: integer
 range_target_area: string
 roll_DC_save: null_or_record
 success_effect: string
 failure_effect: null_or_string
 duration: string
 limits: []
 drawbacks: []
 evolution_state: base | evolved | unstable | sealed | suppressed | transformed
 notes: []
```

### 2.8.2 Known Limit

Maximum known Forged Techniques:

```yaml
known_forged_technique_limit: Proficiency Bonus
```

A sealed, unstable, or suppressed Forged Technique still counts unless a Source Rule says otherwise.

### 2.8.3 Evolution State

Track evolution state separately from the technique’s identity.

Evolution is not retraining.

If a new result is fundamentally different, it should be a new Forged Technique record.

## 2.9 Foundation and Method Records

### 2.9.1 Foundation Record

```yaml
foundation:
 name: string
 source: string
 status: absent | forming | active | dormant | sealed | unstable | damaged | transformed | suppressed | removed
 family_type: null_or_string
 grade_depth: null_or_string
 passive_effects: []
 active_effects: []
 compatibility: []
 incompatibility: []
 burdens: []
 breakthrough_effects: []
 recovery_effects: []
 tribulation_weight: null_or_integer
 transformation_conditions: []
 repair_correction_conditions: []
 notes: []
```

A Foundation is not a flavor trick. It is a cultivation architecture.

### 2.9.2 Method Record

```yaml
method:
 name: string
 source: string
 status: known | Primary | dormant | sealed | unstable | transformed | suppressed | removed
 Path_compatibility: []
 Resource_Shape: string
 Breakthrough_Shape: string
 Foundation_Shape: string
 requirements: []
 effects: []
 incompatibilities: []
 change_conditions: []
 risks: []
 notes: []
```

Only one Primary Method applies by default.

Known non-primary Methods do not stack by default.

### 2.9.3 Method Change Record

```yaml
method_change:
 old_method: string
 old_method_final_status: known | dormant | sealed | transformed | removed
 new_method: string
 new_method_status: Primary | known
 source: string
 procedure: string
 maximum_CP_before: integer
 maximum_CP_after: integer
 current_CP_before: integer
 current_CP_after: integer
 risks: []
 consequences: []
```

Changing a Method does not refill current CP by default.

## 2.10 Consequences and Recovery Records

### 2.10.1 Consequence Record

```yaml
consequence:
 name: string
 type: Hidden Injury | Deviation | Burden | Cultivation Scar | Cultivation Strain
 tags: []
 source: string
 severity: Minor | Moderate | Major | Severe | Catastrophic | null
 affected_record: string
 trigger: string
 mechanical_effect: string
 duration: string
 recovery_mode: Purify | Repair | Integrate | other | none
 recovery_procedure: null_or_record
 failure_result: null_or_string
 success_result: null_or_string
 escalation: null_or_string
 visibility: obvious | hidden | diagnosable | secret | social | spiritual | other
 notes: []
```

A consequence without a mechanical effect is not a mechanical consequence.

### 2.10.2 Unstable Tag

```yaml
unstable_tag:
 attached_to: string
 trigger: string
 risk: string
 roll_or_DC: null_or_record
 failure_result: string
 removal_or_stabilization_condition: string
```

Unstable is a tag, not a standalone consequence type.

### 2.10.3 Recovery Project

```yaml
recovery_project:
 consequence_addressed: string
 mode: Purify | Repair | Integrate | other
 time: string
 check_or_DC: null_or_record
 requirements: []
 cost: []
 helper_rules: []
 success_result: string
 failure_result: string
 escalation: null_or_string
 partial_progress: boolean
```

Recovery should update the consequence record when it succeeds, fails, worsens, or transforms.

## 2.11 AP, Breakthrough, and Bottleneck Records

### 2.11.1 AP Record

```yaml
AP:
 current_progress: integer
 threshold_to_next_CL: integer
 restricted_AP: []
 awards: []
```

### 2.11.2 AP Award

```yaml
AP_award:
 amount: integer
 source: string
 characters: []
 CL_at_award: integer
 restrictions: []
 repeatability: string
 notes: []
```

### 2.11.3 Breakthrough Record

```yaml
breakthrough_record:
 character: string
 current_CL: integer
 target_CL: integer
 current_Realm: string
 target_Realm: string
 AP_before: integer
 AP_threshold: integer
 type: Same-Realm | Realm
 DC: integer
 roll:
 d20: integer
 modifiers: []
 total: integer
 advantage_state: none | advantage | disadvantage | cancelled
 enlightenment_dice_used: []
 preparation: []
 method_modifiers: []
 foundation_modifiers: []
 consequence_modifiers: []
 tribulation_interface: none | omen | light | standard | heavy | severe | heaven-offending | other
 result: success | failure
 AP_after: integer
 CL_after: integer
 new_records: []
 source_references: []
```

### 2.11.4 Bottleneck Record

```yaml
bottleneck:
 source: string
 affected_character: string
 affected_record: string
 effect: string
 resolution_condition: string
 can_create_AP_or_enlightenment: boolean
 notes: []
```

A bottleneck must have a resolution condition.

## 2.12 Suppression Records

### 2.12.1 Suppression Record

```yaml
suppression_record:
 source: voluntary | Source Rule
 suppressed_CL: integer
 suppressed_Realm: string
 scope: full | partial | item-only | aura-only | technique-only | other
 PB_used: integer
 features_unavailable: []
 effects_retained: []
 duration: string
 consequences: []
 notes: []
```

### 2.12.2 Suppression Reminder

Suppression is restraint, not equalization.

Do not overwrite actual CL, Realm, PB, CP, Foundation, Method, AP, or consequences when recording suppression.

## 2.13 Items, Materials, and Treasure Records

### 2.13.1 Item Record

```yaml
item:
 name: string
 type: weapon | armor | tool | pill | talisman | treasure | manual | material | spirit_stone | artifact | other
 rarity_grade: null_or_string
 source: string
 owner_bearer: string
 status: carried | equipped | bound | sealed | dormant | active | expended | damaged | suppressed | lost
 requirements: []
 activation: null_or_string
 cost: []
 effect: string
 duration: null_or_string
 limits: []
 risk: []
 record_created: null_or_record
 notes: []
```

### 2.13.2 Pill Impurity Record

```yaml
pill_impurity:
 stacks: integer
 penalty: -1_to_breakthrough_checks_per_stack
 source_pills: []
 removal_method: null_or_record
```

Pill Impurity does not expire on long rest by default.

### 2.13.3 Material and Harvest Lot Records

```yaml
harvest_lot:
 name: string
 source: string
 quantity: string
 quality: null_or_string
 tags: []
 value: null_or_string
 use: string
 stability_or_spoilage: null_or_string
```

There is no universal Harvest Lot quality ladder.

## 2.14 Social, Faction, Oath, and Access Records

### 2.14.1 Social Record

```yaml
social_record:
 name: string
 type: faction | oath | vow | debt | law | reputation_record | title | relationship | access | other
 source: string
 affected_character: string
 mechanical_effect: null_or_string
 access_changes: []
 obligations: []
 risks: []
 duration: string
 removal_condition: null_or_string
```

There is no universal reputation, face, or karma score.

### 2.14.2 Access Record

```yaml
access_record:
 source: string
 access_type: teacher | manual | market | sect_area | spirit_site | item | trial | restricted_art | other
 granted_to: string
 requirements: []
 duration: string
 revoked_by: null_or_condition
 mechanical_effect: null_or_string
```

Access is not the same as ownership or mastery.

## 2.15 GM Session Ledger

### 2.15.1 Session Ledger

```yaml
session_ledger:
 session_id: string
 date: string
 characters_present: []
 AP_awards: []
 training_progress: []
 records_added: []
 records_changed: []
 consequences_added_or_resolved: []
 items_gained_or_lost: []
 local_rulings: []
 unresolved_questions: []
```

### 2.15.2 End-of-Session Procedure

```yaml
end_of_session_update:
 - confirm_AP_awards
 - update_CP_and_recovery_state
 - update_training_choices
 - update_breakthrough_or_bottleneck_records
 - update_consequences
 - update_items_and_materials
 - update_social_records
 - write_local_rulings
 - list_unresolved_questions
```

### 2.15.3 Unresolved Question Record

```yaml
unresolved_question:
 question: string
 affected_character_or_record: string
 temporary_resolution: null_or_string
 source_needed: string
 deadline: next_session | before_use | before_level_up | none
```

## 2.17 GM Examples

### Example A: Current CP After Method Change

A character changes to a Method that increases maximum CP.

```yaml
maximum_CP_before: 30
current_CP_before: 5
maximum_CP_after: 35
current_CP_after: 5
```

Current CP does not refill by default.

### Example B: Suppressed Duel

A CL10 character suppresses to CL5 for a teaching duel.

```yaml
actual_CL: 10
suppressed_CL: 5
actual_PB: 4
suppressed_PB: 3
maximum_CP: unchanged
Foundation_identity: retained
higher_Realm_features: unavailable
```

Do not reduce HP or erase records.

### Example C: Consequence Without Recovery

A failed breakthrough creates “Cracked Meridian Pain” but no recovery condition was written.

Audit result:

```yaml
valid: false
missing_field: recovery_or_duration
repair_needed: define_recovery_project_or_duration
```

A consequence should not remain mechanically vague.

### Example D: Manual Access

A character owns a manual that lists three arts.

```yaml
manual_owned: true
recorded_arts_learned: []
training_required: true
component_Spheres_granted: false
```

Ownership is not mastery.

# Chapter 3 - Running Cultivation Scenes

## 3.1 Chapter Purpose

Cultivation scenes are the ordinary engine of a Tianxia campaign. They include meditation, instruction, duels, sect trials, dangerous study, recovery, wilderness insight, manual interpretation, teacher correction, item refinement, and spirit-site exploration.

A cultivation scene should not be a vague request for power. It should have:

- a character intent;
- a source or situation;
- stakes;
- a time scale;
- relevant records;
- a resolution procedure;
- a record update if anything persists.

Use this chapter when the table asks, “What does this cultivation moment actually do?”

## 3.2 What Counts as a Scene

A scene is a single continuous stretch of play focused on one conflict, challenge, investigation, negotiation, journey segment, or other meaningful situation.

A scene usually lasts until:

- the immediate situation is resolved;
- the location or objective meaningfully changes;
- the party takes a rest;
- the GM declares that a new scene has begun.

Some Tianxia features last “for the scene” or can be used “once per scene.” Record the scene boundary when those limits matter.

## 3.3 Cultivation Scene Record

Use this record:

```yaml
cultivation_scene:
 name: string
 scene_type: meditation | training | duel | trial | research | recovery | breakthrough_prep | spirit_site | item_refinement | social | other
 participants: []
 location: string
 time_scale: rounds | minutes | hours | days | downtime
 intent: string
 source: string
 relevant_records: []
 stakes: []
 procedure: string
 checks_or_rolls: []
 success_result: string
 failure_result: string
 record_updates: []
 unresolved_questions: []
```

If the scene has no stakes and creates no records, resolve it narratively.

## 3.4 Framing a Cultivation Scene

Use this procedure:

```yaml
cultivation_scene_procedure:
 - identify_character_intent
 - identify_source_or_opportunity
 - define_time_scale
 - identify_relevant_records
 - define_stakes
 - choose_resolution_method
 - resolve_check_or_scene
 - apply_success_or_failure
 - update_records
```

### 3.4.1 Intent

The intent should be mechanical or campaign-relevant.

Examples:

- learn a talent;
- train a Recorded Art;
- diagnose a Hidden Injury;
- stabilize an Unstable tag;
- prepare for a breakthrough;
- test Method compatibility;
- interpret a manual;
- unlock teacher access;
- harvest a material;
- enter a Spirit Site;
- resist a Burden;
- correct a Deviation.

### 3.4.2 Source or Opportunity

A scene needs a source or opportunity.

Possible sources:

- teacher;
- manual;
- jade slip;
- Spirit Site;
- sect trial;
- local ruling;
- item;
- wound;
- consequence;
- Foundation;
- Method;
- enemy technique;
- research clue;
- social access record.

No source means the GM should treat the scene as ordinary practice unless the player is using a defined self-training procedure.

## 3.5 Resolution Methods

A cultivation scene can resolve through:

```yaml
resolution_methods:
 automatic_if_requirements_met: source_defined
 ability_or_skill_check: mundane_or_social_cases
 Cultivation_Check: d20 + Path key ability modifier + PB
 save: source_defined
 extended_project: downtime_or_multi_scene
 combat_or_duel: tactical_scene
 breakthrough_check: only_for_breakthroughs
 local_ruling: narrow_and_recorded
```

Use the narrowest appropriate resolution method.

Do not use a breakthrough check for ordinary cultivation scenes.

## 3.6 Stakes

Stakes should be known before the roll or scene resolution.

```yaml
scene_stakes:
 success: string
 failure: string
 cost: null_or_record
 risk: null_or_record
 partial_success: null_or_string
```

Failure does not have to injure the character. It can mean lost time, no progress, resource cost, social complication, damaged material, delayed access, or a new unresolved question.

Use Chapter 6 if failure creates a consequence.

## 3.7 Time Scale

Choose the time scale that matches the action.

| Time Scale | Use |
|---|---|
| rounds | combat, duel, immediate hazard |
| minutes | brief test, emergency stabilization, ritual moment |
| hours | meditation, teacher session, Spirit Site use |
| days | downtime, research, recovery, crafting |
| arc | major Foundation repair, Method change, sect campaign |

Do not compress a project into a single roll if the project requires time, materials, teaching, or repeated exposure.

## 3.8 Cultivation Checks

When a scene calls for a Cultivation Check, use:

```yaml
cultivation_check:
 roll: d20
 modifier: Path key ability modifier + Proficiency Bonus
```

The Path key ability is determined by the character’s Path.

Use a skill or tool check when the task is mundane, social, investigative, or craft-specific and not primarily cultivation.

## 3.9 Scene Outcomes

A scene outcome should state what changes.

```yaml
scene_outcome:
 result: success | failure | partial | interrupted
 records_created: []
 records_updated: []
 resources_spent: []
 consequences: []
 follow_up_options: []
```

If nothing mechanical changed, say that no record update occurs.

## 3.10 Common Cultivation Scene Types

### 3.10.1 Meditation

Meditation can be narrative, preparation, recovery, or a defined procedure.

A 10-hour meditation grants Advantage on a breakthrough unless a Source Rule says otherwise. Other meditation benefits require a Source Rule or local ruling.

### 3.10.2 Teacher Correction

Teacher correction can support training, repair, Method change, Foundation correction, or bottleneck resolution.

```yaml
teacher_correction:
 teacher: string
 student: string
 target_record: string
 procedure: string
 success_result: string
 failure_result: string
```

### 3.10.3 Dangerous Study

Dangerous study can involve manuals, forbidden texts, unstable inheritances, or false routes.

Define the risk before the roll.

### 3.10.4 Spirit-Site Use

Use Chapter 12’s Spirit Site record. A site gives only record-defined benefits.

### 3.10.5 Rival Demonstration

A rival demonstrating a technique can create information, intimidation, access clue, or future training opportunity. It does not grant the technique by itself.

## 3.11 GM Examples

### Example A: Manual Interpretation Scene

```yaml
intent: determine_Recorded_Art_Difficulty
source: damaged_jade_slip
time_scale: hours
check: Intelligence check with cultivation context
success_result: learn that the art is Difficulty 4 and water-compatible
failure_result: no clear result; may retry after finding teacher
record_updates:
 - manual_record_updated
```

### Example B: Foundation Stabilization Scene

```yaml
intent: stabilize_Unstable_tag_on_Foundation
source: Foundation consequence record
time_scale: days
procedure: recovery_project
success_result: remove Unstable tag
failure_result: tag remains and project cost is spent
```

### Example C: Rival Pressure Scene

```yaml
intent: intimidate rival with presence
source: no mechanical pressure Source Rule
resolution: ordinary social check if needed
mechanical_pressure_effect: none
```

The description can matter socially, but it does not create a pressure mechanic.

# Chapter 4 - Training, Spheres, Talents, Manuals, and Lineages

## 4.1 Chapter Purpose

Training is one of the main ways Tianxia characters grow between breakthroughs. The GM needs to track what the character is learning, which source permits it, how long it takes, what DC applies, and what record changes after success.

This chapter covers:

- known Spheres;
- new Spheres;
- talents;
- level talents;
- trained choices;
- manuals;
- lineages;
- Recorded Arts;
- teacher support;
- self-training;
- research support;
- failed learning attempts.

Boundary:

```text
Learning creates records only through a defined training, level-up, Source Rule, or reward procedure.
```

## 4.2 Training Records

Use a training record for any mechanical learning.

```yaml
training_record:
 character: string
 training_type: new_Sphere | known_Sphere_talent | level_talent | Recorded_Art | support_project | other
 source: string
 CL: integer
 time_required: string
 time_spent: string
 DC: null_or_integer
 roll: null_or_record
 success_result: string
 failure_result: string
 record_added_or_updated: null_or_record
```

If the activity is only practice with no mechanical learning, no training record is required.

## 4.3 Level Talent

Each CL grants one free level talent from a Sphere the character already knows.

At CL1, the sect-trial Dao Sphere talent counts as the CL1 level talent unless a Source Rule says otherwise.

```yaml
level_talent_record:
 CL: integer
 talent: string
 Sphere: string
 source: level_talent | sect_trial_CL1
 counts_against_trained_choices: false
```

A level talent does not require a training check.

## 4.4 Trained Choices

Each CL allows up to 3 trained choices.

```yaml
trained_choices_by_CL:
 CL: integer
 limit: 3
 used: integer
 entries: []
```

A trained choice can be used only for a procedure the character has access to.

Unused trained choices do not convert into AP, items, rerolls, or other rewards by default.

## 4.5 New Sphere Training

A character can learn a new Sphere through a valid source.

```yaml
new_sphere_training:
 source: teacher | manual | lineage | self_training | trial | item | spirit | other
 DC: 10 + 1d4 + number_of_different_Spheres_known
 time: 1d6 + PB - Intelligence_or_Wisdom_modifier_minimum_2_days
 success:
 - gain_base_Sphere_ability
 - gain_one_New_Sphere_Bonus_Talent
 failure:
 - no_new_Sphere_record
 - time_spent_or_partial_progress_as_defined
```

The New-Sphere Bonus Talent does not count against trained choices.

There is no maximum-known-Spheres rule.

## 4.6 Known-Sphere Talent Training

A character can train a talent in a Sphere they already know.

```yaml
known_sphere_talent_training:
 DC: 10 + number_of_talents_already_known_from_that_Sphere
 time: 1d6 + PB - Intelligence_or_Wisdom_modifier_minimum_2_days
 success:
 - gain_talent_record
 failure:
 - no_talent_record_unless_Source_Rule_says_otherwise
```

Use Intelligence or Wisdom according to the training method, source, and table ruling.

## 4.7 Training Time

Default training time:

```yaml
training_time:
 formula: 1d6 + PB - Intelligence_or_Wisdom_modifier
 minimum: 2 days
 day_length: 8 hours_of_training
```

Manuals, teachers, Spirit Sites, items, consequences, or local rulings can modify time only if their records say so.

## 4.8 Manuals and Lineages

Manuals and lineages are sources. They can give access, information, requirements, risks, or fixed arts.

They do not automatically grant Spheres, talents, Methods, Foundations, AP, breakthrough bonuses, or mastery.

### 4.8.1 Manual Record

```yaml
manual:
 name: string
 type: manual | jade_slip | mural | inheritance | journal | teacher_record | other
 source: string
 contents:
 recorded_arts: []
 methods: []
 warnings: []
 recipes: []
 theory: []
 false_routes: []
 restrictions: []
 risks: []
 mechanics_granted: []
```

### 4.8.2 Lineage Record

```yaml
lineage:
 name: string
 source: string
 relationship_type: teacher | sect | inheritance | bloodline | spirit | manual_tradition | route | other
 access_grants: []
 restrictions: []
 obligations: []
 risks: []
 mechanics: []
```

Access to a manual or lineage allows the next defined procedure. It does not bypass that procedure unless the Source Rule says so.

## 4.9 Recorded Arts

A Recorded Art is a fixed technique learned from a manual, jade slip, mural, inheritance, teacher record, or similar source.

It reproduces its written effect. It does not grant component Spheres or talents by default.

### 4.9.1 Recorded Art Training DC

Use this formula.

```yaml
recorded_art_training_DC: 10 + Recorded_Art_Difficulty + 2 * number_of_Recorded_Arts_already_learned_at_current_CL
```

The count resets when CL changes.

### 4.9.2 Recorded Art Record

```yaml
recorded_art:
 name: string
 source: string
 Difficulty: integer
 CL_learned: integer
 activation: string
 cost: null_or_record
 effect: string
 duration: string
 limits: []
 status: active | known | sealed | dormant | unstable | transformed | suppressed | removed
```

If Difficulty is missing, the GM must define it before training.

## 4.10 Teacher Support

Teachers can provide access, reduce uncertainty, reveal requirements, support training, diagnose consequences, or define a local ruling.

```yaml
teacher_support:
 teacher: string
 student: string
 topic: string
 benefit: string
 limit: string
 record_update: null_or_record
```

Teacher support does not create an automatic success unless the teacher’s Source Rule says so.

## 4.11 Self-Training

Self-training is allowed for known-Sphere talents and other cases allowed by Core v0.3 or a Source Rule.

Self-training still uses the appropriate DC and time.

```yaml
self_training:
 allowed: true_or_false
 training_type: string
 source_basis: existing_knowledge | observation | experiment | other
 risk: null_or_record
```

Secret, Forbidden, restricted, inherited, or teacher-locked material may require a source.

## 4.12 Failed Training

Failure should have a defined result.

Possible failure results:

- no record gained;
- time spent;
- partial progress if the procedure says so;
- material cost spent;
- teacher requires a new task;
- manual risk triggers;
- consequence if defined;
- bottleneck revealed.

Do not grant the learned record on failure unless a Source Rule says so.

## 4.13 Training Examples

### Example A: New Sphere

```yaml
different_Spheres_known: 3
DC: 10 + 1d4 + 3
success:
 - gain new Sphere
 - gain one New-Sphere Bonus Talent
```

### Example B: Known-Sphere Talent

```yaml
talents_already_known_from_Sphere: 2
DC: 12
success:
 - gain talent record
```

### Example C: Recorded Art

```yaml
Recorded_Art_Difficulty: 4
Recorded_Arts_already_learned_at_current_CL: 1
DC: 10 + 4 + 2
DC_value: 16
```

### Example D: Manual Access

```yaml
manual_access: granted
automatic_learning: false
next_procedure: Recorded Art training
```

# Chapter 5 - Advancement, AP, Breakthroughs, and Bottlenecks

## 5.1 Chapter Purpose

Advancement in Tianxia is not just “gain enough points and level up.” A cultivator accumulates Attainment Points, reaches a threshold, attempts a breakthrough, and then changes state only if the breakthrough succeeds. The GM’s job is to keep AP, preparation, Method, Foundation, consequences, tribulation interface, and character records separate.

This chapter gives the GM a complete table procedure for:

- awarding AP;
- checking advancement eligibility;
- resolving same-Realm and Realm breakthroughs;
- validating preparation;
- applying Enlightenment dice;
- handling failure;
- creating bottlenecks;
- updating records after success or failure.

This chapter does not create a new advancement economy. It operationalizes Core Rules Reference v0.3.

## 5.2 Advancement Overview

The advancement flow is:

```yaml
advancement_flow:
 - award_AP
 - update_AP_record
 - check_threshold
 - identify_target_CL
 - classify_breakthrough_type
 - calculate_breakthrough_DC
 - validate_preparation
 - apply_legal_modifiers
 - determine_tribulation_interface_if_called
 - roll_breakthrough_check
 - apply_success_or_failure
 - update_character_state
 - write_breakthrough_record
```

Do not skip the breakthrough check unless a Source Rule specifically replaces it.

Do not grant the new CL until the breakthrough succeeds.

Do not grant the level talent until the new CL is gained.

## 5.3 AP Records

AP means **Attainment Points**.

Track AP as a character record.

```yaml
AP_record:
 character: string
 current_CL: integer
 current_AP_progress: integer
 threshold_to_next_CL: integer
 restricted_AP: []
 awards: []
 notes: []
```

AP progress is not a general-purpose currency. It measures progress toward the next CL.

### 5.3.1 AP Award Record

Each award should be recorded.

```yaml
AP_award:
 amount: integer
 source: string
 scene: string
 characters: []
 CL_at_award: integer
 restrictions: []
 repeatability: one_time | repeatable | limited | unknown
 notes: []
```

### 5.3.2 When to Award AP

AP can come from:

- adventures;
- cultivation scenes;
- breakthrough-relevant discoveries;
- teacher instruction;
- sect trial rewards;
- manuals if a Source Rule grants AP;
- pills if the pill grants AP;
- tribulation rewards if defined;
- major route discoveries;
- campaign milestones.

Do not give AP merely because a scene sounded mystical. The GM should identify what the character actually learned, overcame, refined, or attained.

### 5.3.3 Restricted AP

Restricted AP can exist when a Source Rule says the AP applies only to a route, Sphere, Method, Foundation, recovery, breakthrough, or other defined use.

```yaml
restricted_AP:
 amount: integer
 source: string
 restriction: string
 expires: null_or_condition
 notes: []
```

Restricted AP cannot be used outside its restriction.

## 5.4 AP Thresholds

Use the Core v0.3 AP threshold table.

```yaml
AP_needed_to_next_CL:
 1: 300
 2: 600
 3: 1800
 4: 3800
 5: 7500
 6: 9000
 7: 11000
 8: 14000
 9: 16000
 10: 18000
 11: 20000
 12: 20000
 13: 25000
 14: 30000
 15: 35000
 16: 35000
 17: 40000
 18: 45000
 19: 50000
 20: null
```

The key is the current CL. The value is the AP required to attempt the next CL.

Example:

```yaml
current_CL: 4
target_CL: 5
required_AP: 3800
breakthrough_type: Realm
```

## 5.5 Breakthrough Eligibility

Before rolling, confirm eligibility.

```yaml
breakthrough_eligibility:
 AP_threshold_met: true
 target_CL_valid: true
 character_alive_and_capable: true
 no_unresolved_bottleneck_blocking_attempt: true
 required_materials_or_conditions_met_if_any: true
 required_scene_or_time_available_if_any: true
```

If a bottleneck blocks the attempt, do not roll. Resolve or bypass the bottleneck through its defined procedure.

If a Source Rule adds a requirement, record it.

## 5.6 Breakthrough Type

Classify the attempt.

```yaml
breakthrough_type:
 Same-Realm:
 examples: CL2, CL3, CL4, CL6, CL7, CL8, CL9
 DC_formula: 10 + new_CL
 Realm:
 examples: CL5, CL10, CL15, CL20
 DC_formula: 10 + 2 * new_CL
```

Realm breakthroughs usually matter more because they can interact with Foundation, Core Formation, Nascent Soul, True Immortality, tribulation, sect recognition, and cultivation weight.

Full tribulation is not the default for every breakthrough. Use tribulation assessment only when called for.

## 5.7 Breakthrough DCs

Use these formulas:

```yaml
same_realm_breakthrough_DC: 10 + new_CL
realm_breakthrough_DC: 10 + 2 * new_CL
```

Examples:

| Current CL | Target CL | Type | DC |
|---:|---:|---|---:|
| 1 | 2 | Same-Realm | 12 |
| 4 | 5 | Realm | 20 |
| 9 | 10 | Realm | 30 |
| 12 | 13 | Same-Realm | 23 |
| 14 | 15 | Realm | 40 |

A Source Rule can modify the check. Record the modifier and source.

## 5.8 Breakthrough Check

Use a Cultivation Check unless a Source Rule says otherwise.

```yaml
cultivation_check:
 roll: d20
 modifier: Path key ability modifier + Proficiency Bonus
```

Record:

```yaml
breakthrough_roll:
 d20: integer
 path_key_modifier: integer
 PB: integer
 other_modifiers: []
 enlightenment_dice: []
 total: integer
```

Do not use a different ability because it feels appropriate unless a Source Rule changes the check.

## 5.9 Preparation

Preparation can help only if it has mechanical definition.

Valid preparation can include:

- 10-hour meditation;
- Enlightenment die;
- teacher instruction;
- manual guidance;
- Method compatibility;
- Foundation compatibility;
- recovery project completion;
- spirit site benefit if defined;
- item or pill benefit if defined;
- tribulation boon if defined;
- route-specific Source Rule.

### 5.9.1 10-Hour Meditation

A 10-hour meditation grants Advantage unless a Source Rule says otherwise.

Record it.

```yaml
breakthrough_preparation:
 type: ten_hour_meditation
 benefit: Advantage
 completed: true
```

### 5.9.2 Preparation That Does Nothing Yet

If preparation has no mechanical rule, it can still be narrated, but it does not modify the roll.

Example:

```yaml
preparation:
 description: meditated_beneath_waterfall
 Source_Rule: none
 mechanical_effect: none
```

## 5.10 Enlightenment Dice

An Enlightenment die is a persistent record unless its Source Rule says it is temporary or consumed.

```yaml
enlightenment_die:
 die: d4 | d6 | d8 | d10 | other
 source: string
 restriction: null_or_string
 temporary: boolean
 consumed_on_use: boolean
 used_on_roll: null_or_record
```

Do not restrict an Enlightenment die to a Sphere, discipline, or narrow route unless the die’s Source Rule says so.

The Dao is connected.

### 5.10.1 Using Enlightenment

When a character uses an Enlightenment die:

```yaml
use_enlightenment:
 die_record: string
 breakthrough_record: string
 roll_added: integer
 consumed_or_retained: according_to_Source_Rule
```

If the record does not say the die is consumed, do not delete it.

## 5.11 Method and Foundation Modifiers

### 5.11.1 Method

Only the Primary Method applies by default.

A Primary Method can modify:

- maximum CP through Resource Shape;
- breakthrough checks through Breakthrough Shape;
- Foundation interaction through Foundation Shape.

Record Method compatibility.

```yaml
method_breakthrough_modifier:
 method: string
 shape: Stable | Profoundly Stable | Harsh | Severe | Corrective | Baseline | other
 compatible: true_or_false
 modifier: integer
 source: string
```

Known non-primary Methods do not stack by default.

### 5.11.2 Foundation

A Foundation can modify breakthroughs only if its Source Rule says so.

Record:

```yaml
foundation_breakthrough_modifier:
 foundation: string
 condition_met: true_or_false
 modifier: integer
 risk: null_or_string
 source: string
```

Do not grant a Foundation bonus because the theme sounds relevant.

## 5.12 Consequence Modifiers

Consequences can modify breakthroughs when their records say so.

Examples:

- Pill Impurity applies a penalty to breakthrough checks.
- Hidden Injury can impose a penalty if its record says so.
- A repaired scar can grant a scar-boon if defined.
- A Deviation can block or alter a breakthrough if defined.

Record each modifier.

```yaml
consequence_breakthrough_modifier:
 consequence: string
 effect: string
 modifier: integer_or_other
 source: string
```

Do not invent a penalty from a consequence name alone.

## 5.13 Tribulation Interface

A breakthrough can call for tribulation assessment, but full tribulation is not default for every breakthrough.

When assessment is called, record:

```yaml
tribulation_interface:
 assessment_called: true
 base_weight: integer
 modifiers: []
 total_weight: integer
 band: omen_only | light | standard | heavy | severe | heaven_offending
 timing: before | during | after | separate_scene
 mechanical_challenges: []
 rewards: []
 consequences: []
```

A tribulation can happen before, during, after, or outside the breakthrough check.

Do not let tribulation replace the breakthrough check unless a Source Rule says it does.

## 5.14 Breakthrough Success

On success:

```yaml
breakthrough_success:
 CL_after: target_CL
 Realm_after: derived_from_target_CL
 PB_after: derived_from_target_CL
 maximum_CP_after: recalculate
 current_CP_after: unchanged_unless_Source_Rule
 level_talent_available: true
 AP_state_updated: true
 new_records: []
```

Important points:

- Increase CL.
- Update Realm if needed.
- Update PB if CL crosses a PB threshold.
- Recalculate maximum CP.
- Do not refill current CP by default.
- Grant the level talent only after success.
- Record any Source Rule result.

### 5.14.1 Success Record

```yaml
breakthrough_success_record:
 breakthrough_record_id: string
 changes:
 CL: new_value
 Realm: new_value
 PB: new_value
 maximum_CP: new_value
 current_CP: unchanged_or_Source_Rule_value
 level_talent_pending: true
 notes: []
```

## 5.15 Breakthrough Failure

On failure:

```yaml
breakthrough_failure:
 CL_after: unchanged
 AP_progress_after_failure: floor(required_AP_for_attempted_next_CL / 2)
 retry_requires_regaining_lost_AP: true
 consequence_or_bottleneck: only_if_defined
 free_record_editing: false
```

The character does not gain the new CL.

The character does not gain the level talent.

The character does not get a free rebuild.

### 5.15.1 Failure Record

```yaml
breakthrough_failure_record:
 breakthrough_record_id: string
 AP_before: integer
 required_AP_for_attempted_next_CL: integer
 AP_after: floor(required_AP_for_attempted_next_CL / 2)
 CL_after: unchanged
 consequence_added: null_or_record
 bottleneck_added: null_or_record
 retry_condition: regain_lost_AP_and_resolve_blocks
```

### 5.15.2 Failure Does Not Automatically Mean Injury

A failed breakthrough can create a consequence, but only if a Source Rule, tribulation result, hazard, or local ruling defines it.

If no consequence is defined, the failure still matters because AP progress drops and the breakthrough is not achieved.

## 5.16 Bottlenecks

A bottleneck is a recorded barrier to advancement or route development.

It is not a vague statement that the character is “stuck.”

```yaml
bottleneck:
 name: string
 source: string
 affected_character: string
 affected_record: string
 effect: string
 resolution_condition: string
 can_create_AP_or_enlightenment: boolean
 notes: []
```

### 5.16.1 When to Create a Bottleneck

Create a bottleneck when:

- a Source Rule requires it;
- a failed breakthrough defines it;
- a consequence blocks advancement;
- a Method or Foundation incompatibility creates a barrier;
- a teacher or sect imposes a specific trial;
- a local ruling creates a clear route condition.

Do not create a bottleneck just because the player rolled poorly unless the result says so.

### 5.16.2 Bottleneck Effects

A bottleneck can:

- block breakthrough attempts;
- impose a penalty;
- require a recovery project;
- require a teacher;
- require a manual;
- require a trial;
- require a spirit site;
- require an item or material;
- require a social or sect condition;
- transform a route if resolved through integration.

### 5.16.3 Resolution Conditions

Every bottleneck needs a resolution condition.

Good conditions:

```yaml
resolution_examples:
 - complete_teacher_guided_correction
 - repair_hidden_injury
 - acquire_missing_manual_section
 - survive_sect_trial
 - purify_Pill_Impurity_to_zero
 - integrate_cultivation_scar
 - defeat_inner_demon_scene
 - reconcile_Method_Foundation_incompatibility
```

Bad conditions:

```text
Figure it out eventually.
```

### 5.16.4 Bottleneck Rewards

A bottleneck can create AP, Enlightenment, scar-boon, access, or route transformation only if its record says so.

A bottleneck should not become a reward faucet.

## 5.17 Breakthrough Record Template

Use this complete template.

```yaml
breakthrough_record:
 character: string
 current_CL: integer
 target_CL: integer
 current_Realm: string
 target_Realm: string
 AP_before: integer
 AP_threshold: integer
 type: Same-Realm | Realm
 DC: integer
 roll:
 d20: integer
 path_key_modifier: integer
 PB: integer
 other_modifiers: []
 enlightenment_dice: []
 total: integer
 advantage_state: none | advantage | disadvantage | cancelled
 preparation: []
 method_modifiers: []
 foundation_modifiers: []
 consequence_modifiers: []
 tribulation_interface: none | omen | light | standard | heavy | severe | heaven_offending | other
 result: success | failure
 AP_after: integer
 CL_after: integer
 CP_max_after: integer
 CP_current_after: integer
 new_records: []
 source_references: []
```

## 5.18 GM Examples

### Example A: Same-Realm Breakthrough

A CL6 cultivator attempts CL7.

```yaml
current_CL: 6
target_CL: 7
type: Same-Realm
DC: 17
AP_threshold_met: true
roll_total: 21
result: success
```

Result:

```yaml
CL_after: 7
Realm_after: Foundation
maximum_CP_after: recalculate
current_CP_after: unchanged_unless_Source_Rule
level_talent_pending: true
```

### Example B: Realm Breakthrough Failure

A CL9 cultivator attempts CL10.

```yaml
current_CL: 9
target_CL: 10
type: Realm
DC: 30
required_AP: 16000
roll_total: 27
result: failure
```

Result:

```yaml
CL_after: 9
AP_after: floor(16000 / 2)
AP_after_value: 8000
level_talent_gained: false
consequence: none_unless_defined
```

### Example C: Pill Impurity Penalty

A cultivator has 3 Pill Impurity.

```yaml
pill_impurity_stacks: 3
breakthrough_penalty: -3
```

The penalty applies because Pill Impurity has a defined rule.

### Example D: Bottleneck from a Failed Foundation Attempt

A Foundation attempt fails and creates a bottleneck.

```yaml
bottleneck:
 name: Misaligned Foundation Breath
 affected_record: Foundation
 effect: cannot_attempt_Foundation_breakthrough_again_until_resolved
 resolution_condition: complete_7_day_teacher_guided_breath_correction
 can_create_AP_or_enlightenment: false
```

The bottleneck is clear because it has a record, effect, and resolution condition.

# Chapter 6 - Consequences, Failure, and Recovery

## 6.1 Chapter Purpose

Failure in Tianxia should matter, but it should not be arbitrary. A failed breakthrough, corrupted pill, dangerous manual, bad Method match, damaged Foundation, tribulation wound, or cursed item can leave a mark. That mark should be a record, not a vague punishment.

This chapter gives the GM procedures for:

- assigning consequences;
- distinguishing consequence types;
- using the Unstable tag;
- creating recovery projects;
- creating scar-boons;
- integrating failure-born options;
- auditing whether failure has mechanical teeth without becoming unfair.

## 6.2 Consequence Types

Use the Core v0.3 consequence categories.

```yaml
consequence_types:
 Hidden_Injury: internal damage, subtle structural harm, concealed wound, diagnostic problem
 Deviation: wrong-route distortion, unstable cultivation pattern, incorrect circulation, warped expression
 Burden: carried cost, vow weight, karmic load, oath pressure, predatory debt, inherited demand
 Cultivation_Scar: lasting mark from trauma, breakthrough, tribulation, technique, item, or failure
 Cultivation_Strain: short-to-medium stress, overload, fatigue of cultivation structure, unstable pressure
```

Unstable is a tag. It is not a standalone consequence type.

## 6.3 When to Assign a Consequence

Assign a consequence when a Source Rule, hazard, item, failed breakthrough, tribulation, local ruling, or campaign event calls for it.

Do not assign a consequence merely because a scene is dramatic.

Good triggers:

- failed breakthrough with defined consequence;
- pill overload failure;
- dangerous manual backlash;
- technique Backlash with consequence text;
- tribulation failure;
- Forbidden power cost;
- Method/Foundation incompatibility;
- failed recovery project;
- cursed item;
- local ruling after a risky action.

Bad triggers:

- the character took ordinary HP damage;
- the GM wants the scene to feel serious but has no mechanical source;
- the character’s theme sounds fragile;
- a player described fear or pain but no rule calls for consequence.

## 6.4 Consequence Assignment Procedure

Use this procedure:

```yaml
assign_consequence:
 - identify_source_event
 - confirm_mechanical_authority
 - choose_consequence_type
 - choose_severity_if_used
 - define_affected_record
 - define_trigger
 - define_mechanical_effect
 - define_duration_or_recovery_mode
 - define_visibility
 - define_escalation_if_any
 - define_success_or_failure_interactions
 - write_consequence_record
```

A consequence is not complete until it has a mechanical effect and either duration or recovery path.

## 6.5 Consequence Record

Use this record:

```yaml
consequence:
 name: string
 type: Hidden Injury | Deviation | Burden | Cultivation Scar | Cultivation Strain
 tags: []
 source: string
 severity: Minor | Moderate | Major | Severe | Catastrophic | null
 affected_record: string
 trigger: string
 mechanical_effect: string
 duration: string
 recovery_mode: Purify | Repair | Integrate | other | none
 recovery_procedure: null_or_record
 failure_result: null_or_string
 success_result: null_or_string
 escalation: null_or_string
 visibility: obvious | hidden | diagnosable | secret | social | spiritual | other
 notes: []
```

### 6.5.1 Required Fields

Required fields:

```yaml
required_consequence_fields:
 name: true
 type: true
 source: true
 affected_record: true
 trigger: true
 mechanical_effect: true
 duration_or_recovery_mode: true
```

If a consequence lacks these fields, it is not ready for use.

## 6.6 Severity

Severity is optional but useful.

```yaml
severity_ladder:
 Minor:
 use: small penalty, narrow trigger, easy recovery
 Moderate:
 use: noticeable penalty, repeated trigger, defined recovery project
 Major:
 use: route-shaping penalty, significant downtime, special help required
 Severe:
 use: blocks major advancement or key feature until resolved
 Catastrophic:
 use: campaign-defining damage, transformation, near-loss, or major route change
```

Severity should match the source event.

Do not use severity to smuggle in undefined mechanics. Write the actual mechanical effect.

## 6.7 Hidden Injuries

A Hidden Injury is internal harm that may not be obvious.

Examples:

- cracked meridian;
- bruised dantian;
- damaged soul channel;
- unstable breath route;
- internal poison residue;
- concealed tribulation wound.

Record visibility carefully.

```yaml
hidden_injury:
 visibility: hidden | diagnosable | secret
 diagnosis_requirement: null_or_record
 mechanical_effect: string
 recovery_mode: Repair | Purify | other
```

A Hidden Injury can be unknown to the character if the GM records it privately. If it has mechanical effect, the GM must still apply it consistently.

## 6.8 Deviations

A Deviation is a wrong-route or distorted cultivation pattern.

Examples:

- reversed circulation;
- incompatible Method imprint;
- warped Sphere expression;
- unstable Forbidden pattern;
- misread manual route;
- failed integration of a scar.

A Deviation should have a trigger and effect.

```yaml
deviation:
 route_error: string
 trigger: string
 effect: string
 correction_condition: string
 escalation: null_or_string
```

Do not treat unusual Dao expression as a flaw by taste alone. A Deviation is mechanical, not aesthetic.

## 6.9 Burdens

A Burden is a carried cost.

Examples:

- vow burden;
- karmic debt;
- spirit contract;
- Forbidden appetite;
- lineage demand;
- sect law mark;
- item obligation;
- inherited trial.

A Burden should state what it demands.

```yaml
burden:
 demand: string
 trigger: string
 effect: string
 relief_condition: string
 violation_result: null_or_string
```

A Burden can be powerful and tempting if it comes from Forbidden or Secret power. Cost does not mean weakness.

## 6.10 Cultivation Scars

A Cultivation Scar is a lasting mark.

Examples:

- lightning scar;
- soul-burn scar;
- meridian split;
- body-tempering crack;
- beast-core mark;
- dream wound;
- oath brand.

A scar can be purely harmful, neutral, or eventually integrated.

```yaml
cultivation_scar:
 mark: string
 source: string
 effect: string
 integration_possible: boolean
 scar_boon: null_or_record
```

A scar-boon is not automatic. It must be defined.

## 6.11 Cultivation Strain

Cultivation Strain is stress or overload.

Examples:

- overdrawn qi;
- breath instability;
- Method strain;
- Foundation pressure;
- item backlash;
- excessive pill stress;
- forced circulation.

Strain is often shorter than injury, but it still needs a duration or recovery rule.

```yaml
cultivation_strain:
 trigger: string
 effect: string
 duration: string
 recovery_mode: Repair | Purify | Integrate | rest | other
```

Do not use Strain as a vague penalty bucket.

## 6.12 Unstable Tag

Unstable attaches to another record.

```yaml
unstable_tag:
 attached_to: string
 trigger: string
 risk: string
 roll_or_DC: null_or_record
 failure_result: string
 stabilization_condition: string
```

Examples:

- unstable Forged Technique;
- unstable Foundation;
- unstable Method change;
- unstable item bond;
- unstable scar-boon;
- unstable manual inheritance.

Unstable needs a trigger. If it never triggers, it is not a mechanic.

## 6.13 Recovery Modes

Use three main recovery modes.

| Mode | Use |
|---|---|
| Purify | remove contamination, impurity, wrong residue, hostile qi, poison, corruptive trace |
| Repair | mend damage, structure, meridian, dantian, soul, Foundation, item channel |
| Integrate | accept, stabilize, transform, or use a scar, burden, deviation, or altered route |

A recovery project can use more than one mode if the record says so.

## 6.14 Recovery Project Procedure

Use this procedure:

```yaml
recovery_project:
 - identify_consequence
 - choose_recovery_mode
 - define_time
 - define_requirements
 - define_cost
 - define_check_or_auto_resolution
 - define_success_result
 - define_failure_result
 - define_partial_progress_if_any
 - update_consequence_record
```

### 6.14.1 Recovery Project Record

```yaml
recovery_project_record:
 consequence_addressed: string
 mode: Purify | Repair | Integrate | other
 time: string
 check_or_DC: null_or_record
 requirements: []
 cost: []
 helper_rules: []
 success_result: string
 failure_result: string
 escalation: null_or_string
 partial_progress: boolean
```

### 6.14.2 Recovery Success

On success:

- remove the consequence;
- reduce severity;
- transform it;
- integrate it;
- convert it to a scar-boon if defined;
- unlock a retry;
- remove a bottleneck;
- stabilize an Unstable tag.

Choose only the results defined by the recovery project.

### 6.14.3 Recovery Failure

On failure:

- no progress;
- partial progress;
- cost lost;
- consequence worsens;
- new strain;
- bottleneck remains;
- item or helper suffers risk.

Choose only defined failure results.

## 6.15 Purify, Repair, Integrate Examples

### 6.15.1 Purify Example

```yaml
consequence: Pill Impurity
mode: Purify
requirement: rare cleansing decoction and 2 days of controlled circulation
check: Constitution save or Cultivation Check, DC defined by Source Rule
success_result: remove 1 Pill Impurity
failure_result: no removal and gain Cultivation Strain until long rest
```

### 6.15.2 Repair Example

```yaml
consequence: Cracked Meridian
mode: Repair
requirement: healer, quiet room, silver needles, 3 downtime days
success_result: remove penalty to breakthrough checks
failure_result: consequence remains
```

### 6.15.3 Integrate Example

```yaml
consequence: Lightning Scar
mode: Integrate
requirement: survive controlled storm meditation
success_result: scar becomes defined scar-boon
failure_result: scar remains and gains Unstable tag
```

## 6.16 Scar-Boons

A scar-boon is a transformed scar that provides benefit and cost.

```yaml
scar_boon:
 source_scar: string
 benefit: string
 trigger: string
 limit: string
 cost_or_risk: string
 suppression_or_removal_condition: null_or_string
```

A scar-boon should not be pure upside unless the source explicitly says so.

### 6.16.1 Scar-Boon Boundary

Do not convert every injury into a boon.

Use scar-boons when:

- the character paid a meaningful cost;
- recovery used Integration;
- a Source Rule or local ruling supports the transformation;
- the boon remains tied to the scar’s identity.

## 6.17 Failure-Born Options

A failure-born option is a new option that exists because of a specific failure.

It can be:

- recovery route;
- scar-boon;
- restricted teacher access;
- special manual clue;
- corrective Method project;
- emergency seed;
- Foundation transformation path;
- altered breakthrough approach.

Record it.

```yaml
failure_born_option:
 source_failure: string
 option: string
 requirement: string
 benefit: string
 cost_or_limit: string
 expires: null_or_condition
```

Failure-born options do not replace normal choices unless a Source Rule says so.

## 6.18 Consequences and Bottlenecks

A consequence can create or support a bottleneck.

Example:

```yaml
consequence:
 name: Misaligned Core Spiral
 type: Deviation
 effect: cannot_attempt_Core_Formation_breakthrough_until_corrected

bottleneck:
 affected_record: breakthrough_to_CL10
 resolution_condition: correct_Misaligned_Core_Spiral
```

Keep both records if both matter.

## 6.19 Consequences and Items

Items can cause consequences only if their Source Rule says so.

Possible item-linked consequences:

- curse burden;
- backlash strain;
- oath mark;
- item addiction;
- soul tether;
- meridian burn;
- forbidden appetite;
- impurity.

Record item state and consequence state separately.

## 6.20 Consequences and Social Records

Some consequences are social or spiritual.

Examples:

- sect taboo mark;
- oath violation;
- forbidden cultivation exposure;
- lineage rejection;
- spirit debt;
- faction warrant.

If it has social mechanics, create a social record as well as a consequence record.

## 6.21 GM Examples

### Example A: Failed Breakthrough With No Injury Rule

A cultivator fails a same-Realm breakthrough.

```yaml
source_event: failed_breakthrough
defined_consequence: none
result:
 AP_after: floor(required_AP / 2)
 CL_after: unchanged
 consequence: none
```

The GM should not invent a wound just because the roll failed.

### Example B: Failed Breakthrough With Hidden Injury

A Realm breakthrough failure defines a Hidden Injury.

```yaml
consequence:
 name: Cracked Dantian Wall
 type: Hidden Injury
 source: failed_Foundation_breakthrough
 affected_record: CP
 mechanical_effect: -2 to future breakthrough checks until repaired
 recovery_mode: Repair
 visibility: diagnosable
```

This is valid because it has type, source, affected record, effect, and recovery mode.

### Example C: Deviation From a False Manual

A player studies a false circulation diagram.

```yaml
consequence:
 name: Reversed River Circulation
 type: Deviation
 affected_record: Method
 trigger: using_water_or_flowing_qi_techniques
 mechanical_effect: on a natural 1, gain Cultivation Strain until scene end
 recovery_mode: Repair
```

The Deviation is not a taste judgment about the route. It is a specific mechanical distortion.

### Example D: Integrating a Scar

A tribulation scar is integrated.

```yaml
scar_boon:
 source_scar: Thunder-Opened Palm
 benefit: once per scene, add thunder description to a legal unarmed lightning-compatible technique
 trigger: after taking lightning damage or passing a storm trial check
 limit: no extra damage unless a Source Rule grants it
 cost_or_risk: visible storm mark draws attention
```

The scar-boon is bounded. It does not create free damage.

# Chapter 7 - Foundations and Methods in Play

## 7.1 Chapter Purpose

Foundations and Methods are not decorative labels. They are major cultivation records that shape how a character grows, recovers, strains, breaks through, and expresses power.

This chapter helps the GM answer questions such as:

- What does a Foundation record actually do?
- When does a Foundation grant a benefit?
- How does a damaged or unstable Foundation affect play?
- What does the Primary Method apply to?
- Can a character know more than one Method?
- When can a Method change?
- How do Method shapes interact with CP, breakthroughs, and Foundations?
- How do Foundations and Methods create consequences, bottlenecks, or transformation projects?

The GM’s baseline rule is simple:

```text
A Foundation or Method grants only the mechanics written in its Source Rule or current catalog record.
```

Do not grant an extra benefit because the name sounds relevant. Do not remove a burden because the character later wants a cleaner route.

## 7.2 Foundation Role at the Table

A Foundation is a cultivation architecture.

It can represent:

- body structure;
- dantian formation;
- meridian pattern;
- soul vessel;
- qi sea;
- bloodline integration;
- route compatibility;
- survival quality;
- breakthrough profile;
- future transformation seed.

A Foundation can support broad narrative identity, but its mechanics must be tracked.

### 7.2.1 Foundation Is Not a Flavor Trick

A Foundation should not be reduced to one small trick.

A wind-body Foundation might affect speed, balance, breath, falling, storm resistance, or wind-compatible techniques if its Source Rule says so. It is not only “can fly” or “gets advantage in air.”

A body-vessel Foundation might increase toughness, resource flow, recovery profile, or compatibility if written. It is not only a combat bonus.

### 7.2.2 Foundation Is Not a Universal Bonus

Do not grant Foundation benefits by theme alone.

Unsupported rulings:

```yaml
unsupported_foundation_benefits:
 theme_matches_scene: no_mechanical_bonus_by_itself
 impressive_name: no_mechanical_bonus_by_itself
 high_grade: no_undefined_bonus_by_itself
 compatible_flavor: no_undefined_bonus_by_itself
```

Supported use requires a record.

## 7.3 Foundation Record

Use a Foundation record whenever a character has, forms, damages, repairs, seals, suppresses, or transforms a Foundation.

```yaml
foundation:
 name: string
 source: string
 status: absent | forming | active | dormant | sealed | unstable | damaged | transformed | suppressed | removed
 family_type: null_or_string
 grade_depth: null_or_string
 passive_effects: []
 active_effects: []
 compatibility: []
 incompatibility: []
 burdens: []
 breakthrough_effects: []
 recovery_effects: []
 tribulation_weight: null_or_integer
 transformation_conditions: []
 repair_correction_conditions: []
 notes: []
```

### 7.3.1 Required Foundation Fields

A usable Foundation record should identify:

```yaml
required_foundation_fields:
 name: true
 source: true
 status: true
 passive_effects_or_none: true
 active_effects_or_none: true
 compatibility_or_none: true
 burdens_or_none: true
 breakthrough_effects_or_none: true
```

If a Foundation lacks mechanical text, the GM should treat it as identity only until a Source Rule defines more.

### 7.3.2 Foundation Status

| Status | Meaning |
|---|---|
| forming | being built, not fully active |
| active | functioning normally |
| dormant | present but not currently expressing mechanics |
| sealed | blocked by rule, condition, item, oath, injury, or suppression |
| unstable | has an Unstable tag or equivalent risk |
| damaged | injured or structurally impaired |
| transformed | changed by Source Rule or project |
| suppressed | restrained by suppression procedure |
| removed | no longer present as a record |

Changing status is a record update. Do not erase the history unless the Source Rule says the record is removed.

## 7.4 Foundation Benefits

Foundation benefits can be passive, active, conditional, or breakthrough-facing.

### 7.4.1 Passive Foundation Benefits

Passive benefits apply when their condition is met.

```yaml
passive_foundation_benefit:
 source: string
 condition: string
 effect: string
 stacking_rule: null_or_string
 suppressed_by: []
```

Examples of possible passive benefit types:

- speed increase;
- resistance to a defined hazard;
- improved recovery under defined conditions;
- improved compatibility with a route;
- toughness increase;
- detection of a specific phenomenon;
- reduced penalty from a defined burden.

The GM should not invent the magnitude.

### 7.4.2 Active Foundation Benefits

Active Foundation benefits need normal effect fields.

```yaml
active_foundation_benefit:
 activation: action | bonus_action | reaction | no_action | downtime | other
 cost: null_or_record
 target_range_area: null_or_record
 roll_DC_save: null_or_record
 success_effect: string
 failure_effect: null_or_string
 duration: string
 limit: null_or_string
```

If activation or cost is missing, resolve it before use.

### 7.4.3 Conditional Foundation Benefits

Some Foundations apply only when a condition is true.

Examples:

- while Bloodied;
- when making a breakthrough;
- during recovery;
- against poison;
- in storm conditions;
- when using a compatible Sphere;
- when resisting forced movement;
- when repairing a specific injury.

Record the condition clearly.

## 7.5 Foundation Burdens and Damage

A Foundation can carry burdens or damage.

Do not treat a burden as pure flavor if it has mechanical consequences.

```yaml
foundation_burden:
 name: string
 source: string
 trigger: string
 mechanical_effect: string
 relief_condition: string
 escalation: null_or_string
```

```yaml
foundation_damage:
 name: string
 source: string
 affected_foundation: string
 effect: string
 recovery_mode: Repair | Purify | Integrate | other
 recovery_project: null_or_record
```

A damaged Foundation can also create a Hidden Injury, Deviation, Burden, Cultivation Scar, or Cultivation Strain.

Use Chapter 6 records when the damage persists.

## 7.6 Foundation and Breakthroughs

A Foundation can affect breakthroughs only if its Source Rule says so.

Possible interactions:

- bonus to compatible breakthrough;
- penalty to incompatible breakthrough;
- required repair before attempt;
- altered tribulation weight;
- bottleneck if damaged;
- special success record;
- special failure consequence;
- route transformation.

Record each interaction.

```yaml
foundation_breakthrough_interface:
 foundation: string
 target_CL_or_Realm: string
 compatible: true_or_false
 modifier: null_or_integer
 requirement: null_or_string
 risk: null_or_string
 success_result: null_or_string
 failure_result: null_or_string
 source: string
```

Do not grant a Foundation bonus because the breakthrough “fits the theme” unless the Foundation record says it does.

## 7.7 Foundation Repair, Correction, and Transformation

### 7.7.1 Repair

Repair addresses damage.

```yaml
foundation_repair_project:
 foundation: string
 damage_or_burden: string
 mode: Repair
 time: string
 requirements: []
 check_or_DC: null_or_record
 success_result: string
 failure_result: string
```

### 7.7.2 Correction

Correction addresses wrong fit, unstable route, or Method/Foundation conflict.

```yaml
foundation_correction_project:
 foundation: string
 conflict: string
 mode: Repair | Purify | Integrate | other
 procedure: string
 success_result: string
 failure_result: string
```

### 7.7.3 Transformation

Transformation changes the Foundation through Source Rule or major project.

Transformation is not a convenience rebuild.

```yaml
foundation_transformation:
 old_foundation: string
 new_state: string
 source: string
 requirements: []
 costs: []
 retained_records: []
 lost_records: []
 new_records: []
 risks: []
```

If the transformation creates a new Foundation identity, the Source Rule should say whether the old record is transformed, sealed, removed, or retained as history.

## 7.8 Method Role at the Table

A Method is a cultivation method, scripture, route engine, or practice system.

A character can know multiple Methods, but only one is the **Primary Method** by default.

The Primary Method can affect:

- Resource Shape;
- Breakthrough Shape;
- Foundation Shape;
- compatibility;
- risks;
- correction procedures;
- route identity.

Known non-primary Methods are records. Their shapes remain inactive by default.

## 7.9 Method Record

Use this Method record.

```yaml
method:
 name: string
 source: string
 status: known | Primary | dormant | sealed | unstable | transformed | suppressed | removed
 Path_compatibility: []
 Resource_Shape: Neutral | Deep Reservoir | Great Reservoir | Narrow Channel | Strained Reservoir | Overdrawn Reservoir | other
 Breakthrough_Shape: Baseline | Stable | Profoundly Stable | Harsh | Severe | Corrective | other
 Foundation_Shape: Open | Compatible | Focused | Incompatible | Corrective | Transformative | other
 requirements: []
 effects: []
 incompatibilities: []
 change_conditions: []
 risks: []
 notes: []
```

### 7.9.1 Primary Method Requirement

Exactly one Method is Primary if the character has a Method that currently shapes cultivation.

```yaml
primary_method_rule:
 one_Primary_Method_only: true
 non_primary_Methods_do_not_stack: true
 Primary_Method_applies_shapes: true
```

If no Method is active, record that the character has no Primary Method.

## 7.10 Resource Shape

Resource Shape modifies maximum CP when the Method is Primary.

```yaml
resource_shapes:
 Neutral:
 max_CP_modifier: 0
 Deep_Reservoir:
 max_CP_modifier: +PB
 Great_Reservoir:
 max_CP_modifier: +2PB
 Narrow_Channel:
 max_CP_modifier: -PB
 compatible_breakthrough_modifier: +PB
 Strained_Reservoir:
 max_CP_modifier: +2PB
 incompatible_breakthrough_modifier: -PB
 Overdrawn_Reservoir:
 max_CP_modifier: +3PB
 incompatible_breakthrough_modifier: -2PB
 correction_risk: defined_by_Method
```

When Resource Shape changes, recalculate maximum CP.

Current CP does not refill by default.

## 7.11 Breakthrough Shape

Breakthrough Shape affects breakthrough checks only when conditions match.

```yaml
breakthrough_shapes:
 Baseline:
 modifier: 0
 Stable:
 compatible_modifier: +PB
 Profoundly_Stable:
 compatible_modifier: +2PB
 Harsh:
 compatible_modifier: +PB
 incompatible_modifier: -PB
 Severe:
 compatible_modifier: +2PB
 incompatible_modifier: -2PB
 Corrective:
 repair_or_correction_modifier: +PB_if_relevant
```

Record compatibility before applying the modifier.

Do not apply both compatible and incompatible modifiers at once unless the Method record defines a special case.

## 7.12 Foundation Shape

Foundation Shape describes how the Method interacts with Foundations.

```yaml
foundation_shapes:
 Open:
 effect: broad compatibility, no special modifier unless defined
 Compatible:
 effect: supports specified Foundation families or traits
 Focused:
 effect: strongly supports a narrow range and may resist others
 Incompatible:
 effect: creates risk or penalty with specified Foundations
 Corrective:
 effect: supports repair or correction
 Transformative:
 effect: can alter Foundation through a defined project
```

Foundation Shape does not automatically grant a new Foundation or rewrite an old one. It defines interaction.

## 7.13 Method Change

Changing Method is a cultivation project, not a routine scene preparation choice.

Use a Method change record.

```yaml
method_change:
 old_method: string
 old_method_final_status: known | dormant | sealed | transformed | removed
 new_method: string
 new_method_status: Primary | known
 source: string
 procedure: string
 maximum_CP_before: integer
 maximum_CP_after: integer
 current_CP_before: integer
 current_CP_after: integer
 risks: []
 consequences: []
```

### 7.13.1 Valid Method Change Sources

A Method change can come from:

- teacher;
- manual;
- sect ritual;
- corrective project;
- Foundation transformation;
- consequence integration;
- item;
- breakthrough result;
- local ruling with narrow scope;
- Source Rule.

### 7.13.2 Invalid Method Change Reasons

Do not change a Method merely because:

- the next fight favors another shape;
- the player wants a cleaner sheet;
- another Method has better numbers;
- a known non-primary Method would help this scene;
- the character rested.

A Method is a cultivation route, not a scene-by-scene preparation list.

## 7.14 Method/Foundation Compatibility

When Method and Foundation interact, classify the relation.

```yaml
method_foundation_relation:
 method: string
 foundation: string
 relation: compatible | focused | incompatible | corrective | transformative | neutral
 effect: string
 source: string
 risk: null_or_string
```

### 7.14.1 Compatible

Compatible means the Method supports the Foundation as written.

### 7.14.2 Incompatible

Incompatible means the Method and Foundation create a defined penalty, risk, bottleneck, consequence, or blocked route.

Do not invent a penalty from flavor alone.

### 7.14.3 Corrective

Corrective means the Method can help repair or realign the Foundation under a defined procedure.

### 7.14.4 Transformative

Transformative means the Method can alter the Foundation through a defined project.

Transformative does not mean instant replacement.

## 7.15 GM Examples

### Example A: Method Raises Maximum CP

A CL8 Qi cultivator with Path key modifier +4 has maximum CP 32 before Method.

The Primary Method has Deep Reservoir.

```yaml
base_max_CP: 8 * 4
PB: 3
Resource_Shape: Deep_Reservoir
maximum_CP_after: 35
current_CP_after: unchanged
```

### Example B: Known Non-Primary Method

A character knows two Methods.

```yaml
Primary_Method: River-Sutra
known_non_primary_Method: Iron-Breath Manual
applied_shapes: River-Sutra only
```

The non-primary Method is a record, but its Resource Shape, Breakthrough Shape, and Foundation Shape do not apply.

### Example C: Damaged Foundation

A Foundation is damaged by a failed correction ritual.

```yaml
foundation_damage:
 name: Split Lotus Base
 affected_foundation: Lotus Root Foundation
 effect: -PB to compatible breakthrough checks until repaired
 recovery_mode: Repair
```

This is valid because it has an effect and recovery mode.

### Example D: Method/Foundation Incompatibility

A harsh fire Method is paired with a water Foundation.

```yaml
relation: incompatible
effect: -PB to breakthrough checks involving water-aligned Foundation expansion
source: Method record
risk: on failed breakthrough, add Cultivation Strain
```

The penalty applies because the Method record defines it, not because the GM dislikes the pairing.

# Chapter 8 - Realm Suppression, Teaching Duels, and Trials

## 8.1 Chapter Purpose

Realm suppression is common in cultivation fiction and useful at the table. Elders suppress themselves to teach. Rivals agree to equal terms. Sects test disciples. Tournaments restrict Realm expression. Powerful cultivators hide their true strength.

This chapter explains how to run suppression without rewriting the character.

Principle:

```text
Suppression is restraint, not equalization.
```

Suppression limits what the character can express. It does not erase the character’s history, body, Foundation, Method, AP, or consequences.

## 8.2 What Suppression Does

Suppression can restrict:

- effective CL for feature use;
- Realm-locked options;
- Proficiency Bonus used for suppressed actions;
- higher-Realm talents;
- Forged Technique complexity;
- item or Method expression if the suppression scope includes them;
- aura presentation;
- training trial conditions;
- tournament legality.

Suppression should be recorded.

## 8.3 What Suppression Does Not Do by Default

Suppression does not reduce by default:

- maximum HP;
- current HP;
- Hit Dice;
- ability scores;
- actual CL record;
- actual Realm record;
- maximum CP;
- current CP;
- AP progress;
- Foundation identity;
- Method identity;
- known Spheres;
- talents known as records;
- Recorded Arts known as records;
- Forged Techniques known as records;
- consequences;
- item ownership.

A suppressed character may be unable to use some records, but the records still exist.

## 8.4 Suppression Record

Use this record:

```yaml
suppression_record:
 source: voluntary | Source Rule | trial | formation | oath | item | tournament | other
 actual_CL: integer
 actual_Realm: string
 suppressed_CL: integer
 suppressed_Realm: string
 scope: full | partial | item-only | aura-only | technique-only | trial-only | other
 PB_used: integer
 features_unavailable: []
 effects_retained: []
 duration: string
 ending_condition: string
 consequences: []
 notes: []
```

### 8.4.1 Required Fields

```yaml
required_suppression_fields:
 source: true
 actual_CL: true
 suppressed_CL: true
 scope: true
 PB_used: true
 duration_or_ending_condition: true
```

If the GM cannot define the scope, use full suppression or do not use suppression.

## 8.5 Full Suppression Procedure

Use this procedure:

```yaml
full_suppression:
 - record_actual_CL_and_Realm
 - choose_suppressed_CL
 - derive_suppressed_Realm
 - derive_suppressed_PB
 - list_features_unavailable
 - list_effects_retained
 - define_duration
 - define_ending_condition
 - update_scene_state
```

### 8.5.1 Suppressed PB

Use the PB appropriate to the suppressed CL for suppressed actions.

Do not overwrite actual PB.

```yaml
actual_CL: 13
actual_PB: 5
suppressed_CL: 5
suppressed_PB: 3
```

### 8.5.2 Features Above Suppressed CL

A fully suppressed character cannot use features, talents, Path features, Recorded Arts, Forged Techniques, or item expressions locked above the suppressed CL or Realm, unless the suppression record says otherwise.

### 8.5.3 Passive Body Quality

Suppression does not remove passive body quality by default.

If the GM needs a trial to suppress passive body quality, define it as a trial rule, formation effect, oath, item, or local ruling.

## 8.6 Partial Suppression

Partial suppression limits only part of the character.

Examples:

- aura-only;
- technique-only;
- item-only;
- movement-only;
- CP-output-only;
- trial-specific action list;
- tournament ban list.

Use a partial suppression record.

```yaml
partial_suppression:
 scope: string
 suppressed_records: []
 retained_records: []
 legal_actions: []
 illegal_actions: []
 detection: null_or_record
```

Partial suppression is useful for tests that focus on skill rather than raw cultivation.

## 8.7 Ending Suppression

Voluntary suppression can end according to its record.

```yaml
ending_suppression:
 source: voluntary | forced | trial | item | other
 action_required: none_on_own_turn_unless_record_says_otherwise
 blocked_by: []
 effects_restored: []
 costs: []
```

If suppression is caused by a formation, item, oath, or trial, use that source’s ending condition.

Do not assume forced suppression can be ended freely.

## 8.8 Teaching Duels

A teaching duel is a structured fight or contest meant to reveal, train, test, or correct.

Teaching duels often use suppression.

### 8.8.1 Teaching Duel Procedure

```yaml
teaching_duel:
 - identify_teacher_and_student
 - define_goal
 - define_suppression_if_any
 - define_legal_actions
 - define_safety_limits
 - define_success_conditions
 - define_failure_conditions
 - define_rewards_or_records
 - define_consequence_limits
 - run_scene
 - record_results
```

### 8.8.2 Teaching Duel Goals

Goals can include:

- test a new Sphere;
- diagnose a deviation;
- reveal a bottleneck;
- teach a Recorded Art;
- assess Foundation stability;
- test Method compatibility;
- identify combat habits;
- create AP if the duel reward says so;
- create Enlightenment if the duel result defines it.

Do not grant a reward simply because the duel was dramatic.

### 8.8.3 Safety Limits

A teaching duel can include safety limits.

```yaml
safety_limits:
 killing_blow_prohibited: true
 lethal_techniques_prohibited: []
 elder_intervention_trigger: string
 formation_buffer: null_or_record
 consequence_limit: null_or_string
```

If the duel uses safety formation mechanics, define them.

## 8.9 Sect Trials

A sect trial is a structured challenge tied to access, rank, training, reward, or judgment.

### 8.9.1 Sect Trial Record

```yaml
sect_trial:
 name: string
 source: string
 sponsor: string
 participants: []
 eligibility: []
 suppression_rules: null_or_record
 legal_actions: []
 forbidden_actions: []
 success_conditions: []
 failure_conditions: []
 rewards: []
 consequences: []
 records_created: []
 repeatability: one_time | repeatable | seasonal | unknown
```

### 8.9.2 Trial Rewards

A trial reward can include:

- AP;
- access to teacher;
- access to manual;
- sect rank;
- item;
- material;
- Spirit Site access;
- Recorded Art training opportunity;
- Method access;
- social record;
- bottleneck clue;
- consequence recovery.

Rewards must be written.

### 8.9.3 Trial Failure

Trial failure can mean:

- no reward;
- delayed retry;
- social mark;
- consequence if defined;
- loss of deposit or item;
- duty assigned;
- teacher rejection;
- new bottleneck clue;
- rival complication.

Failure should not create undefined punishment.

## 8.10 Tournament Restrictions

Tournament fights often need clear restriction records.

```yaml
tournament_restriction:
 name: string
 CL_band: string
 suppression_required: null_or_record
 banned_actions: []
 banned_items: []
 lethal_force_rule: string
 ring_boundary_rule: string
 victory_conditions: []
 judge_intervention: null_or_record
 prize_records: []
```

Restrictions should be known before the match.

Do not change restrictions mid-fight unless the tournament has a rule for intervention.

## 8.11 Trials as Advancement Support

Trials can support advancement, but they do not replace advancement rules unless a Source Rule says so.

A trial can:

- award AP;
- reveal a bottleneck;
- resolve a bottleneck;
- grant a teacher;
- unlock a manual;
- grant a defined breakthrough preparation benefit;
- call for tribulation assessment;
- create a consequence;
- grant an Enlightenment die if defined.

A trial grants a CL only if a Source Rule explicitly says it does.

## 8.12 Suppression and Items

Suppression can affect items only if its scope includes items.

Examples:

```yaml
item_suppression:
 item: string
 scope: item-only | full | trial-specific
 unavailable_properties: []
 retained_properties: []
 reason: string
```

A low-Realm trial might seal an artifact’s high-Realm property while leaving it as an ordinary weapon.

Define which properties remain.

## 8.13 Suppression and Foundations / Methods

Suppression does not erase Foundation or Method identity.

It can limit expression.

```yaml
suppressed_foundation_method:
 foundation_identity_retained: true
 method_identity_retained: true
 higher_realm_expression_unavailable: true_or_false
 passive_effects_retained: []
 passive_effects_blocked: []
 active_effects_unavailable: []
 source: string
```

If a trial wants to block passive Foundation quality, record that rule.

## 8.14 Detection and Concealment

Suppression can be used to conceal Realm.

Detection requires a Source Rule, item, talent, formation, or local ruling.

```yaml
realm_detection:
 observer: string
 target: string
 source: string
 roll_or_DC: null_or_record
 information_revealed: []
 false_information_risk: null_or_string
```

Do not create a universal aura-reading DC ladder by default.

## 8.15 GM Examples

### Example A: Elder Suppresses for Training

A CL13 elder suppresses to CL5.

```yaml
actual_CL: 13
actual_PB: 5
suppressed_CL: 5
suppressed_PB: 3
maximum_CP: unchanged
current_CP: unchanged
higher_Realm_features: unavailable
Foundation_identity: retained
Method_identity: retained
```

The elder teaches at Foundation scale but remains physically durable unless the duel has a safety rule that further limits durability.

### Example B: Trial Seals Items

A sect trial permits only mundane weapons.

```yaml
suppression_scope: item-only
sealed_item_properties:
 - flight
 - automatic_defense
 - high_Realm_damage_expression
retained_properties:
 - mundane_weapon_form
```

The item remains owned but its special properties are unavailable in the trial.

### Example C: Partial Aura Suppression

A cultivator hides their Realm signature.

```yaml
scope: aura-only
mechanical_effect: observers cannot identify Realm without a detection Source Rule
combat_features: unchanged
duration: until_released_or_detected
```

This does not lower CL for combat.

### Example D: Sect Trial Reward

A trial grants access to a manual, not instant mastery.

```yaml
reward:
 access_record: Inner Hall Jade Slip
 benefit: may train the listed Recorded Art
 automatic_learning: false
```

The character still trains normally unless the trial reward says otherwise.

# Chapter 9 - Combat, Encounters, and Cultivation Effects

## 9.1 Chapter Purpose

Tianxia combat uses the normal 5.5e combat frame unless a Tianxia Source Rule changes the case. The GM should not turn every cultivation description into a combat rule. A blade can glow, a dantian can roar, an elder can feel oppressive, and a battlefield can tremble without creating damage, conditions, movement loss, CP loss, or suppression unless a Source Rule says so.

This chapter gives the GM a procedure for:

- validating combat actions;
- handling CP costs;
- applying cultivation effects;
- resolving pressure and aura descriptions;
- using consequences in combat;
- building encounters;
- running hazards and formations;
- managing monsters and NPC abilities;
- tracking tournaments and battle records.

The goal is consistency: if an effect changes the board state, it needs a rule and a record.

## 9.2 Combat Baseline

Use normal 5.5e combat structure:

```yaml
combat_baseline:
 initiative: normal
 turns_and_rounds: normal
 actions: normal_unless_Source_Rule_changes
 bonus_actions: normal_unless_Source_Rule_changes
 reactions: normal_unless_Source_Rule_changes
 movement: normal_unless_Source_Rule_changes
 concentration_or_sustain: use_Source_Rule_if_present
 conditions: normal_condition_rules_unless_modified
```

Tianxia adds cultivation records, CP, Spheres, talents, Recorded Arts, Forged Techniques, Foundations, Methods, consequences, suppression, items, formations, and tribulation hazards. These additions do not replace the baseline unless they say they do.

## 9.3 Combat Source Rule Validation

Before resolving a combat effect, validate the source.

```yaml
combat_source_validation:
 actor_has_record: true
 record_status_allows_use: true
 activation_available: true
 cost_payable: true
 target_range_area_defined: true
 roll_save_or_check_defined_if_needed: true
 effect_defined: true
 duration_defined: true
 repeat_limit_defined_if_repeatable: true
 record_update_defined_if_persistent: true
```

If one of these fields is missing, the GM should pause and resolve the gap before the effect enters combat.

### 9.3.1 Legal Source Types

A combat effect can come from:

- Path feature;
- Sphere talent;
- Recorded Art;
- Forged Technique;
- Emergency Forging result;
- Foundation feature;
- Method feature;
- item;
- talisman;
- pill;
- formation;
- hazard;
- monster or NPC feature;
- sect trial rule;
- tournament rule;
- local ruling record.

Descriptive intensity is not a legal source by itself.

## 9.4 Combat Action Record

For repeatable or complex effects, record a combat action.

```yaml
combat_action:
 name: string
 source_type: Path | Sphere | talent | Recorded_Art | Forged_Technique | Foundation | Method | item | hazard | monster | local
 source_id: string
 activation: action | bonus_action | reaction | free_object_interaction | no_action | start_of_turn | end_of_turn | other
 cost: null_or_record
 range: null_or_string
 target_or_area: null_or_string
 roll_save_check: null_or_record
 damage_or_effect: string
 condition_applied: null_or_string
 duration: string
 sustain_or_concentration: null_or_record
 limit: null_or_string
 record_update: null_or_record
```

A combat action should be clear enough that a different GM could run it the same way.

## 9.5 CP in Combat

CP is a tracked resource.

```yaml
combat_CP_update:
 actor: string
 CP_type: Stamina | Qi | Resonance
 CP_before: integer
 cost_paid: integer
 CP_after: integer
 source: string
```

A character cannot pay a CP cost they cannot afford unless a Source Rule permits overdraw.

### 9.5.1 0 CP in Combat

When a character is newly reduced to 0 CP, apply the Core v0.3 0 CP rule.

```yaml
zero_CP_combat_event:
 actor: string
 source: string
 CP_before: integer
 CP_after: 0
 exhaustion_added: 1
 repeated_trigger_allowed: only_after_CP_rises_above_0_then_drops_again
```

Do not keep applying the same trigger while the character remains at 0 CP.

### 9.5.2 CP Recovery in Combat

CP recovery in combat requires a Source Rule.

No default rule allows recovery because the battlefield has rich qi, a spirit stone is nearby, or the scene is dramatic.

## 9.6 Reactions and Timing

Use normal reaction timing unless a Source Rule changes it.

A reaction is normally used outside the character’s own turn when its trigger occurs.

```yaml
reaction_validation:
 trigger_occurred: true
 actor_has_reaction_available: true
 source_allows_reaction: true
 cost_payable: true
 timing_legal: true
```

If a feature says it is a Reaction, it cannot be used as a free interrupt unless the feature says so.

### 9.6.1 Defensive Reactions

For defensive reactions, define when they apply.

Examples:

```yaml
defensive_reaction_timing:
 before_attack_roll: rare_and_source_defined
 after_hit_before_damage: source_defined
 when_damage_is_first_applied: source_defined
 after_damage: source_defined
```

Do not move a defensive reaction to a better timing window unless the Source Rule permits it.

## 9.7 Damage, Conditions, and Movement

### 9.7.1 Damage

Damage requires a damage expression or defined effect.

```yaml
damage_record:
 dice_or_amount: string
 damage_type: string
 source: string
 modifiers: []
 resistance_immunity_vulnerability: []
```

Cultivation description does not add damage without a rule.

### 9.7.2 Conditions

A condition requires a Source Rule or normal rules basis.

```yaml
condition_application:
 condition: string
 source: string
 save_or_check: null_or_record
 duration: string
 end_condition: string
```

Do not impose Frightened, Restrained, Prone, Stunned, Poisoned, Exhaustion, or other conditions from aura description alone.

### 9.7.3 Movement

Movement changes require defined mechanics.

Examples:

- forced movement;
- teleportation;
- slowed speed;
- flight;
- falling modification;
- terrain bypass;
- movement denial.

Each needs a Source Rule.

## 9.8 Pressure, Aura, and Spiritual Presence

Pressure, aura, killing intent, spiritual presence, and Realm weight are descriptive unless a Source Rule defines mechanics.

Allowed without mechanics:

- intimidating narration;
- visible spiritual manifestation;
- NPC reaction based on story;
- hinting at Realm difference;
- sensory description;
- social tension.

Not created without a Source Rule:

- damage;
- condition;
- movement loss;
- disadvantage;
- forced action;
- CP loss;
- suppression;
- universal save DC;
- universal detection ladder.

The GM can call for a normal social check if the player is attempting intimidation through ordinary social means.

## 9.9 Consequences in Combat

Ordinary HP damage does not create cultivation consequences by default.

A combat consequence needs a Source Rule.

Possible sources:

- technique with consequence text;
- item backlash;
- monster ability;
- formation hazard;
- Forbidden power cost;
- failed Emergency Forging;
- tribulation hazard;
- local ruling after a declared high-risk action.

Use Chapter 6 records for persistent consequences.

```yaml
combat_consequence_event:
 source: string
 trigger: string
 consequence_record: string
 immediate_effect: string
 recovery_or_duration: string
```

Do not add a Hidden Injury because the attack looked severe unless a rule supports it.

## 9.10 Hazards, Formations, and Battlefield Effects

A hazard or formation can create mechanics if it has a record.

```yaml
battlefield_effect:
 name: string
 type: hazard | formation | terrain | spirit_site | tribulation | item_field | other
 source: string
 area: string
 trigger: string
 effect: string
 save_or_check: null_or_record
 duration: string
 counterplay: []
 depletion_or_end: null_or_string
```

### 9.10.1 Counterplay

Good encounter effects include counterplay.

Counterplay can include:

- leaving the area;
- breaking a focus;
- damaging a formation node;
- using a compatible Sphere;
- making a check;
- spending CP;
- disrupting a caster;
- using an item;
- satisfying a trial condition.

### 9.10.2 Formation Hazards

Formation hazards should state whether they are:

- visible;
- hidden;
- diagnosable;
- interruptible;
- destructible;
- suppressive;
- damaging;
- movement-altering;
- consequence-bearing.

Avoid vague “the formation weakens you” text. Define the effect.

## 9.11 Monsters and NPC Cultivators

NPCs can use simplified records, but their abilities still need fields.

```yaml
npc_cultivator_combat_record:
 name: string
 CL: integer
 Realm: string
 Path_or_monster_role: string
 HP: integer
 AC: integer
 CP_or_limited_uses: null_or_record
 actions: []
 bonus_actions: []
 reactions: []
 traits: []
 consequences_or_burdens: []
 morale_or_goal: string
```

NPCs do not need full player progression records unless they become recurring or playable.

### 9.11.1 Monster Ability Record

```yaml
monster_ability:
 name: string
 activation: string
 recharge_or_limit: string
 target_or_area: string
 roll_save_check: null_or_record
 effect: string
 duration: string
 counterplay: []
```

Simplified does not mean undefined.

## 9.12 Encounter Construction

Build encounters from goals, not only enemy count.

```yaml
encounter_record:
 name: string
 scene_goal: string
 enemies: []
 hazards: []
 formations: []
 terrain: []
 social_constraints: []
 suppression_or_trial_rules: null_or_record
 victory_conditions: []
 failure_conditions: []
 rewards: []
 consequences: []
 retreat_or_deescalation: []
```

### 9.12.1 Encounter Goals

Possible goals:

- defeat enemy;
- survive rounds;
- protect target;
- break formation;
- diagnose technique;
- reach exit;
- force surrender;
- pass trial;
- hold ground;
- interrupt ritual;
- rescue ally;
- acquire item;
- prove mastery.

A clear goal prevents every encounter from becoming a death match.

### 9.12.2 Failure Conditions

Failure should be recorded.

Failure can mean:

- enemy escapes;
- AP reward lost;
- item damaged;
- social record worsens;
- consequence if defined;
- trial failed;
- bottleneck remains;
- resource spent;
- new danger appears.

Avoid undefined punishment.

## 9.13 Tournament and Duel Records

Duel and tournament scenes need clear boundaries.

```yaml
duel_or_tournament_record:
 name: string
 participants: []
 CL_band: string
 suppression_rules: null_or_record
 legal_actions: []
 banned_actions: []
 banned_items: []
 arena_rules: []
 victory_conditions: []
 safety_rules: []
 judge_intervention: null_or_record
 rewards: []
 consequences: []
```

### 9.13.1 Safety Rules

Safety rules should say when judges intervene and what damage or consequences are prevented.

```yaml
safety_rule:
 trigger: string
 intervention: string
 prevented_effects: []
 not_prevented_effects: []
```

A tournament with safety rules can still be dangerous if the rules say what remains dangerous.

## 9.14 Combat Logging

For important fights, especially tests and tournaments, record a combat log.

```yaml
combat_log_round:
 round: integer
 initiative_order: []
 turns:
 - actor: string
 action: string
 roll: null_or_record
 cost: null_or_record
 result: string
 damage: null_or_record
 conditions: []
 reactions: []
 record_updates: []
 end_of_round_state:
 HP: []
 CP: []
 conditions: []
 positioning_notes: []
 unresolved_triggers: []
```

This is especially useful for AI-assisted combat, tournament reports, and later audits.

## 9.15 GM Examples

### Example A: Aura Without Mechanics

A cultivator flares aura before attacking.

```yaml
source_rule: none
mechanical_effect: none
allowed: description
```

The attack resolves normally unless a talent, art, or other Source Rule adds a mechanic.

### Example B: Technique With Missing Duration

A Forged Technique says it blinds the target but does not give duration.

```yaml
missing_field: duration
classification: incomplete_for_combat
gm_action: define_local_ruling_or_return_to_design
```

The GM should not assume the longest useful duration.

### Example C: Formation Hazard

```yaml
battlefield_effect:
 name: Four-Gate Suppression Array
 type: formation
 area: central_ring
 trigger: start_of_turn_inside_area
 effect: reduce_speed_by_10_feet_until_start_of_next_turn
 save_or_check: Strength save DC 15 negates
 counterplay:
 - destroy_any_gate_node_AC_15_HP_20
 - leave_area
```

The formation is usable because it has area, trigger, effect, save, duration, and counterplay.

### Example D: Ordinary Damage

A sword critical hit deals high damage.

```yaml
HP_damage: yes
cultivation_consequence: none_by_default
```

The GM records HP damage only unless a Source Rule adds more.

# Chapter 10 - Tribulations and Cultivation Weight

## 10.1 Chapter Purpose

Tribulation is not a random punishment. It is a recognition event: the world, Heaven, spirits, fate, law, enemies, vows, the body, the soul, or the Dao reacts to cultivation weight.

This chapter helps the GM:

- decide when to assess tribulation;
- calculate cultivation weight;
- choose a band;
- build a tribulation scene;
- separate omens from full tribulations;
- connect tribulation to breakthroughs without replacing breakthrough rules;
- record rewards, scars, consequences, and reputation events;
- keep stronger tribulations worth facing.

Full tribulation is not the default for all breakthroughs. Use assessment when a Realm transition, Source Rule, campaign procedure, or recorded weight calls for it.

## 10.2 Tribulation Principles

Use these principles:

```yaml
tribulation_principles:
 recognition_not_punishment: true
 stronger_weight_can_draw_stronger_response: true
 stronger_response_can_allow_stronger_reward: true
 full_tribulation_not_default_for_all_breakthroughs: true
 breakthrough_check_not_replaced_unless_Source_Rule_says_so: true
 reward_and_consequence_must_be_recorded: true
```

Tribulations should feel dangerous, but they should also feel meaningful. A severe tribulation that offers only punishment teaches players to avoid interesting cultivation. If a character draws heavier recognition because their route is denser, stranger, more forbidden, or more ambitious, the possible reward should scale too.

## 10.3 When to Assess Tribulation

Assess tribulation when one of these applies:

- Realm breakthrough calls for it;
- Foundation, Core Formation, Nascent Soul, or final Realm transition has weight;
- Source Rule calls for assessment;
- Forbidden or Secret power draws response;
- a Method, Foundation, item, oath, or spirit site says to assess;
- campaign procedure uses tribulation weight;
- character is attempting an unusually dense, broad, or dangerous cultivation act;
- a previous consequence, scar, or vow calls for it.

Do not assess tribulation for every training scene.

Do not use tribulation to punish normal character improvement.

## 10.4 Cultivation Weight

Cultivation weight measures how much metaphysical pressure a character’s current act draws.

It can come from:

- CL and Realm;
- Foundation depth;
- Method intensity;
- number and density of route pillars;
- Secret power;
- Forbidden power;
- Dao Aspects or late-game authority;
- major scars or burdens;
- spirit contracts;
- Heaven-defying acts;
- item or artifact involvement;
- setting location;
- repeated breakthrough strain;
- unusual breadth of cultivation.

### 10.4.1 Base Weight

Use these base weights for Realm transitions unless a Source Rule says otherwise.

```yaml
base_weight:
 CL5_Foundation: 3
 CL10_Core_Formation: 6
 CL15_Nascent_Soul: 9
 CL20_final_standard: 12
```

Same-Realm breakthroughs usually do not need full tribulation assessment unless a Source Rule calls for it.

## 10.5 Weight Modifiers

Apply only modifiers that are justified by records.

```yaml
weight_modifier_record:
 source: string
 reason: string
 modifier: integer
 evidence_record: string
```

Possible modifier sources:

| Source | Example |
|---|---|
| High-grade Foundation | unusually dense Foundation record |
| Severe Method | Overdrawn, Severe, Harsh, or heavily corrective Method |
| Forbidden power | predatory, taboo, corruptive, or illegal cultivation |
| Secret power | hidden inheritance, rare route, sealed art |
| Major burden | oath, spirit debt, karmic demand, lineage pressure |
| Major scar | integrated tribulation scar or unstable scar |
| Artifact | item explicitly calls attention or weight |
| Spirit Site | site record says it intensifies response |
| Broad route | many pillars or unusual combination |
| Late-game authority | Dao Aspect, Immortal Art, Mandate, or equivalent |
| Repeated stress | recent failed breakthrough or unresolved strain |

Do not add a modifier because the character is impressive in general. Tie it to a record.

## 10.6 Weight Bands

After total weight is calculated, choose a band.

```yaml
tribulation_weight_bands:
 0_to_5: omen_only_or_no_full_tribulation
 6_to_10: light
 11_to_15: standard
 16_to_20: heavy
 21_to_25: severe
 26_plus: heaven_offending
```

### 10.6.1 Band Meaning

| Band | Use |
|---|---|
| Omen only / no full tribulation | signs, dreams, pressure, minor recognition, no full scene |
| Light | small hazard or brief test |
| Standard | normal structured tribulation scene |
| Heavy | multi-stage test or severe hazard |
| Severe | major scene with real consequence and reward potential |
| Heaven-offending | campaign-significant event, major recognition, danger, and reward potential |

A band describes intensity. It does not define exact mechanics by itself.

## 10.7 Tribulation Assessment Procedure

Use this procedure:

```yaml
tribulation_assessment:
 - identify_trigger
 - identify_character_or_group
 - identify_base_weight
 - list_weight_modifiers
 - total_weight
 - determine_band
 - choose_timing
 - decide_omen_or_full_scene
 - define_challenges
 - define_counterplay
 - define_success_results
 - define_failure_results
 - define_rewards
 - define_consequences
 - write_tribulation_record
```

### 10.7.1 Timing

Tribulation can occur:

- before the breakthrough check;
- during the breakthrough scene;
- after the breakthrough check;
- as a separate scene;
- as a delayed omen;
- as a campaign event.

Timing must be recorded.

### 10.7.2 Group Tribulations

If multiple characters share a tribulation, record why.

```yaml
group_tribulation:
 participants: []
 shared_trigger: string
 individual_weights: []
 shared_modifiers: []
 total_or_highest_weight_method: string
 individual_rewards: []
 shared_consequences: []
```

Do not merge character consequences unless the tribulation record says so.

## 10.8 Omen-Only Results

Not every assessment creates a full scene.

Omen-only results can include:

- thunder without strike;
- dream warning;
- spirit recoil;
- sect instruments reacting;
- item cracking;
- aura bloom;
- bloodline tremor;
- local weather change;
- a teacher noticing;
- a prophecy mark;
- social attention.

Omen-only results can create records if defined.

```yaml
omen_record:
 trigger: string
 sign: string
 mechanical_effect: null_or_string
 future_hook: null_or_string
 duration: string
```

If there is no mechanical effect, say so.

## 10.9 Building a Tribulation Scene

A tribulation scene should have structure.

```yaml
tribulation_scene:
 name: string
 band: omen_only | light | standard | heavy | severe | heaven_offending
 trigger: string
 timing: string
 battlefield_or_internal_space: string
 stages: []
 hazards: []
 checks_or_saves: []
 allowed_counterplay: []
 success_results: []
 failure_results: []
 rewards: []
 consequences: []
 end_condition: string
```

### 10.9.1 Stages

A standard or higher tribulation often benefits from stages.

Possible stages:

- arrival;
- recognition;
- first strike;
- internal trial;
- external hazard;
- memory trial;
- body test;
- soul test;
- law test;
- temptation;
- final strike;
- aftermath.

Stages should not become padding. Each stage needs a purpose.

### 10.9.2 Counterplay

Tribulations should have counterplay.

Counterplay can include:

- saving throws;
- Cultivation Checks;
- using a compatible Sphere;
- spending CP;
- sacrificing an item;
- accepting a scar;
- protecting an ally;
- enduring without resistance;
- redirecting through Foundation;
- stabilizing through Method;
- invoking a vow;
- rejecting Forbidden temptation;
- integrating a burden.

Counterplay should be visible enough for meaningful choice.

## 10.10 Tribulation Challenges

Challenges can target:

- HP;
- CP;
- action economy;
- movement;
- concentration or sustain;
- senses;
- social exposure;
- Foundation stability;
- Method compatibility;
- consequence triggers;
- bottleneck resolution;
- item state;
- spirit or oath records.

Use records.

```yaml
tribulation_challenge:
 stage: string
 target_record: string
 trigger: string
 roll_or_DC: null_or_record
 effect_on_success: string
 effect_on_failure: string
 counterplay: []
```

Do not create unclear “Heaven rejects you” mechanics. Define the effect.

## 10.11 Tribulation Success

Success can mean:

- breakthrough proceeds;
- hazard ends;
- weight is recognized;
- reward unlocked;
- scar integrated;
- bottleneck cleared;
- Foundation stabilized;
- Method accepted;
- item awakened;
- social or spiritual recognition gained.

Success should be recorded.

```yaml
tribulation_success:
 result: string
 rewards: []
 consequences_removed_or_transformed: []
 new_records: []
 notes: []
```

Tribulation success does not automatically replace the breakthrough check unless a Source Rule says so.

## 10.12 Tribulation Failure

Failure can mean:

- damage;
- CP loss;
- consequence;
- damaged Foundation;
- Method strain;
- scar;
- item damage;
- social exposure;
- delayed breakthrough;
- bottleneck;
- partial reward with cost;
- retreat from the attempt.

Failure should be meaningful and defined.

```yaml
tribulation_failure:
 result: string
 consequences: []
 bottlenecks: []
 AP_effect: null_or_record
 breakthrough_effect: null_or_record
 recovery_path: null_or_record
```

Do not use failure to erase player choices unless a Source Rule explicitly permits it.

## 10.13 Tribulation Rewards

Stronger tribulations should permit stronger rewards.

Possible rewards:

- AP;
- Enlightenment die;
- breakthrough modifier;
- scar-boon;
- Foundation stabilization;
- Method compatibility;
- item awakening;
- spirit recognition;
- sect recognition;
- omen record;
- access to teacher or manual;
- bottleneck resolution;
- Dao or late-game recognition when appropriate.

Rewards must be bounded.

```yaml
tribulation_reward:
 source_tribulation: string
 reward_type: string
 benefit: string
 limit: string
 cost_or_risk: null_or_string
 record_created: string
```

A reward should not be a vague promise of future power.

## 10.14 Tribulation Consequences

Consequences use Chapter 6 records.

Possible consequence types:

- Hidden Injury;
- Deviation;
- Burden;
- Cultivation Scar;
- Cultivation Strain;
- Unstable tag attached to a record.

```yaml
tribulation_consequence:
 source_tribulation: string
 consequence_record: string
 recovery_or_integration_path: string
```

A severe consequence should also have a recovery, repair, purification, integration, or transformation route unless the campaign intentionally uses permanent harm.

## 10.15 Forbidden Power and Tribulation

Forbidden power can draw heavier response.

That response should not make Forbidden power worthless. If the character accepts a serious taboo, danger, social cost, corruption risk, predatory burden, or tribulation weight, the power should be tempting enough to matter.

```yaml
forbidden_tribulation_interface:
 forbidden_source: string
 weight_modifier: integer
 taboo_or_cost: string
 special_challenge: string
 possible_reward: string
 possible_consequence: string
```

Forbidden power should have both bite and attraction.

## 10.16 Secret Power and Tribulation

Secret power can draw recognition or concealment problems.

Examples:

- hidden inheritance reacts;
- Heaven notices a concealed route;
- sect formation detects anomaly;
- spirit debt awakens;
- old enemy senses the art;
- sealed manual demands price.

Secret does not mean Forbidden. Record the difference.

## 10.17 Tribulation and Social Records

Tribulation can create social records.

Examples:

- sect recognizes achievement;
- rival clan marks the character;
- teacher takes interest;
- forbidden exposure causes warrant;
- spirit lineage opens;
- prophecy rumor begins.

```yaml
tribulation_social_record:
 source_tribulation: string
 faction_or_observer: string
 relationship_change: string
 access_or_risk: []
 duration: string
```

Do not use a universal reputation score.

## 10.18 Tribulation Record Template

Use this full record.

```yaml
tribulation_record:
 name: string
 trigger: string
 character_or_group: []
 timing: before | during | after | separate_scene | delayed_omen
 base_weight: integer
 modifiers:
 - source: string
 reason: string
 value: integer
 evidence_record: string
 total_weight: integer
 band: omen_only | light | standard | heavy | severe | heaven_offending
 scene_required: boolean
 stages: []
 challenges: []
 counterplay: []
 success_results: []
 failure_results: []
 rewards: []
 consequences: []
 social_records: []
 breakthrough_interaction: null_or_record
 notes: []
```

## 10.19 GM Examples

### Example A: Omen at Foundation

A CL4 character attempts CL5 with ordinary weight.

```yaml
base_weight: 3
modifiers: []
total_weight: 3
band: omen_only_or_no_full_tribulation
result: distant_thunder_and_teacher_notice
mechanical_effect: none
```

The breakthrough still uses the normal Realm breakthrough DC.

### Example B: Heavy Core Formation

A CL9 character attempts CL10 with dense Foundation, Severe Method, and an unresolved Burden.

```yaml
base_weight: 6
modifiers:
 - dense_Foundation: +4
 - Severe_Method: +3
 - unresolved_Burden: +4
total_weight: 17
band: heavy
```

The GM builds a heavy tribulation scene with defined stages, counterplay, reward, and consequence.

### Example C: Forbidden Breakthrough

A cultivator uses Forbidden power to force a breakthrough.

```yaml
forbidden_source: Blood-Eating Furnace
weight_modifier: +6
taboo_or_cost: predatory appetite and sect exposure risk
special_challenge: resist consuming allied blood
possible_reward: powerful scar-boon if resisted
possible_consequence: Burden if indulged
```

The Forbidden path is dangerous, but the reward can be strong enough to tempt.

### Example D: Tribulation Scar

A severe lightning trial leaves a scar.

```yaml
consequence:
 type: Cultivation Scar
 name: Heaven-Split Shoulder
 effect: -PB on checks to conceal Realm during storms
 recovery_mode: Integrate
```

Later integration can create a defined scar-boon if the recovery project says so.

# Chapter 11 - Sects, Factions, Oaths, and Social Play

## 11.1 Chapter Purpose

Cultivation campaigns need sects, clans, schools, courts, gangs, temples, merchant houses, spirit lineages, noble families, black markets, wandering teacher networks, rival disciples, oaths, debts, laws, ranks, and taboos. These structures should matter, but they should not collapse into one global social number.

This chapter gives the GM procedures for:

- creating sect and faction records;
- handling access;
- tracking obligations;
- tracking oaths and vows;
- recording social consequences;
- running missions;
- awarding social benefits;
- avoiding hidden universal social systems.

Boundary:

```text
There is no universal reputation, face, or karma score.
```

Use specific records instead.

## 11.2 Social Records Instead of Universal Scores

A character can be respected by one sect, hunted by another, indebted to a spirit, unknown in a city, and beloved by a village at the same time. A single universal score cannot express that.

Use records.

```yaml
social_record:
 name: string
 type: faction | oath | vow | debt | law | title | relationship | access | taboo | warrant | favor | other
 source: string
 affected_character: string
 faction_or_observer: null_or_string
 mechanical_effect: null_or_string
 access_changes: []
 obligations: []
 risks: []
 duration: string
 removal_condition: null_or_string
```

If a social state has no mechanical effect, it can remain narrative. If it affects access, training, prices, danger, law, teacher support, missions, or consequences, record it.

## 11.3 Faction Record

A faction can be a sect, clan, guild, temple, court, gang, market, army, academy, lineage, or spirit network.

```yaml
faction:
 name: string
 type: sect | clan | guild | court | temple | market | academy | army | spirit_lineage | other
 territory: []
 public_identity: string
 hidden_identity: null_or_string
 values: []
 taboos: []
 resources: []
 ranks: []
 known_NPCs: []
 allies: []
 enemies: []
 access_rules: []
 mission_types: []
 punishments: []
 rewards: []
```

A faction record should tell the GM what the faction can actually do in play.

### 11.3.1 Faction Power Is Not Automatic Mechanics

A great sect can have enormous narrative weight, but its mechanical effects should be specific.

Examples:

- access to a manual hall;
- teacher appointment;
- market discount;
- restricted item purchase;
- trial permission;
- protective status;
- legal immunity;
- oath burden;
- warrant;
- forbidden art suspicion.

Do not give a blanket bonus because a character is “high status” unless the record says so.

## 11.4 Access Records

Access is one of the most important social mechanics in Tianxia.

```yaml
access_record:
 source: string
 access_type: teacher | manual | market | sect_area | spirit_site | item | trial | restricted_art | method | healer | other
 granted_to: string
 granting_faction_or_NPC: string
 requirements: []
 duration: string
 revoked_by: null_or_condition
 mechanical_effect: null_or_string
```

Access grants permission; mastery still requires the relevant learning procedure.

A character with access to a manual can study it. Learning its contents requires the relevant training or Source Rule procedure.

A character with access to a teacher can receive instruction. They do not automatically gain AP, talents, or Recorded Arts unless the lesson procedure grants them.

## 11.5 Sect Rank

Sect rank can structure permissions.

```yaml
sect_rank:
 faction: string
 rank_name: string
 character: string
 permissions: []
 obligations: []
 restrictions: []
 monthly_support: []
 promotion_conditions: []
 demotion_conditions: []
```

Rank should create specific permissions and duties, not a universal bonus.

Possible permissions:

- outer hall access;
- library shelf access;
- teacher hours;
- pill stipend;
- mission board access;
- spirit site entry;
- market purchase tier;
- dormitory;
- legal protection;
- tournament eligibility.

## 11.6 Oaths, Vows, Debts, and Burdens

Oaths and vows can be social records, consequences, or both.

```yaml
oath_record:
 name: string
 source: string
 sworn_by: string
 sworn_to: string
 terms: []
 benefit: null_or_string
 obligation: string
 violation_trigger: string
 violation_result: string
 duration: string
 release_condition: null_or_string
```

If an oath affects cultivation, also create a Burden or related consequence record.

### 11.6.1 Oath Design

A good oath has:

- clear terms;
- meaningful benefit or access;
- meaningful violation result;
- release condition;
- witness or enforcement source if relevant.

Do not use vague oath text as an excuse for arbitrary punishment.

## 11.7 Laws, Taboos, and Forbidden Exposure

Sects and regions can have laws and taboos.

```yaml
taboo_record:
 faction_or_region: string
 prohibited_action: string
 detection_method: null_or_record
 consequence: string
 enforcement: []
 appeal_or_repair: null_or_string
```

Forbidden power can trigger social danger if witnessed, detected, or exposed.

Forbidden does not have to mean weak. It should be tempting, dangerous, and socially costly when relevant.

## 11.8 Missions and Duties

Faction play often runs through missions.

```yaml
mission_record:
 name: string
 source_faction: string
 sponsor: string
 participants: []
 objective: string
 constraints: []
 opposition: []
 success_rewards: []
 failure_results: []
 deadlines: []
 social_records_created: []
```

Rewards must be specific.

Possible mission rewards:

- AP;
- item;
- pill;
- material;
- teacher access;
- manual access;
- rank promotion;
- debt cancellation;
- spirit site access;
- social protection;
- bottleneck clue;
- consequence treatment.

## 11.9 Negotiation and Social Checks

Use normal social checks unless a Tianxia Source Rule changes the case.

A social check can influence NPC behavior, but it should not rewrite faction records unless the stakes were defined.

```yaml
social_check:
 actor: string
 target: string
 intent: string
 ability_or_skill: string
 DC_or_contest: string
 leverage: []
 risk: []
 success_result: string
 failure_result: string
 record_update: null_or_record
```

A successful Persuasion check does not automatically grant restricted manuals, sect rank, forbidden arts, item ownership, or political immunity.

## 11.10 Faction Consequences

Social failure can create consequences if defined.

Examples:

- warrant;
- debt;
- loss of access;
- trial requirement;
- oath burden;
- teacher rejection;
- rival challenge;
- market ban;
- sect suspicion;
- forbidden exposure record.

Use records, not vague hostility.

```yaml
faction_consequence:
 name: string
 source: string
 affected_character: string
 faction: string
 effect: string
 duration: string
 removal_condition: string
```

## 11.11 Social Play Examples

### Example A: Manual Hall Access

```yaml
access_record:
 access_type: manual
 granted_to: disciple
 granting_faction_or_NPC: Cloud River Sect
 requirements:
 - outer_disciple_rank
 - one_merit_token
 mechanical_effect: may train one listed Recorded Art
```

The character gains permission to train; mastery still requires the relevant learning procedure.

### Example B: Forbidden Exposure

```yaml
taboo_record:
 faction_or_region: Jade Law City
 prohibited_action: public use of predatory blood refinement
 detection_method: city formation notices blood-qi surge
 consequence: warrant and market ban
```

The social consequence is specific.

### Example C: Oath Burden

```yaml
oath_record:
 name: Three-Year Protection Vow
 benefit: access to elder instruction
 obligation: protect the sponsor's heir during missions
 violation_result: lose access and gain Burden record
```

If violated, create the named social and cultivation records.

# Chapter 12 - Exploration, Spirit Sites, Travel, and Downtime

## 12.1 Chapter Purpose

Tianxia play is not only combat and breakthroughs. Much of cultivation happens during travel, study, recovery, wandering, sect service, spirit site exploration, market searching, ruin investigation, teacher pursuit, and downtime.

This chapter gives the GM tools for:

- structuring exploration;
- defining regions;
- creating Spirit Site records;
- running travel;
- using downtime;
- tracking projects;
- handling research;
- avoiding automatic rewards from mystical locations.

Boundary:

```text
A Spirit Site does not grant CP recovery, AP, breakthrough bonuses, training bonuses, materials, or tribulations unless its Source Rule or site record says so.
```

## 12.2 Exploration Records

Use an exploration record for meaningful non-combat scenes.

```yaml
exploration_record:
 name: string
 location: string
 objective: string
 party: []
 time_scale: rounds | minutes | hours | days | downtime
 relevant_records: []
 hazards: []
 discoveries: []
 checks: []
 rewards: []
 consequences: []
 unresolved_questions: []
```

Exploration should have stakes. If there are no stakes and no record changes, handle the scene narratively.

## 12.3 Region Record

A region can have mechanical effects only if defined.

```yaml
region_record:
 name: string
 type: wilderness | city | sect_domain | ruin | battlefield | spirit_domain | mountain | river | desert | other
 access: []
 travel_risks: []
 environmental_effects: []
 factions: []
 markets: []
 spirit_sites: []
 encounter_tables: []
 harvest_sources: []
 laws_or_taboos: []
```

Region description can be rich without granting mechanics.

## 12.4 Spirit Site Record

A Spirit Site is a location with meaningful cultivation energy, history, spirits, formation, material concentration, omen, law, or inheritance.

Use this record:

```yaml
spirit_site:
 name: string
 source: string
 location: string
 access_requirements: []
 mechanical_effects: []
 limits: []
 risks: []
 AP_rewards: []
 CP_recovery: []
 breakthrough_modifiers: []
 training_modifiers: []
 harvest_lots: []
 depletion_or_duration: null_or_string
 controlling_faction: null_or_string
 notes: []
```

### 12.4.1 Spirit Site Boundary

A Spirit Site provides only what its record says.

If the record has no CP recovery, it provides no CP recovery.

If the record has no AP reward, it provides no AP reward.

If the record has no breakthrough modifier, it provides no breakthrough modifier.

### 12.4.2 Site Limits

Every mechanical site should have limits.

Possible limits:

- once per character;
- once per season;
- limited charges;
- depletion;
- requires access token;
- requires teacher supervision;
- dangerous after first use;
- faction controlled;
- only helps a specific recovery project;
- only helps a specific Method or Foundation.

## 12.5 Travel Procedure

Use travel when movement across space has stakes.

```yaml
travel_procedure:
 - define_route
 - define_distance_or_time
 - define_party_state
 - define_navigation_method
 - define_hazards
 - define_encounters
 - define_resource_pressure
 - define discoveries
 - resolve_checks
 - update_records
```

### 12.5.1 Travel Record

```yaml
travel_record:
 route: string
 start: string
 destination: string
 time_scale: string
 navigation_check: null_or_record
 hazards: []
 encounters: []
 discoveries: []
 costs: []
 consequences: []
 arrival_state: string
```

Travel does not need to be rolled if no meaningful uncertainty exists.

## 12.6 Exploration Hazards

Hazards need records.

```yaml
exploration_hazard:
 name: string
 source: string
 trigger: string
 detection: null_or_record
 effect: string
 save_or_check: null_or_record
 duration: string
 counterplay: []
 consequence: null_or_record
```

Possible hazards:

- weather;
- poison fog;
- formation remnant;
- predatory beast territory;
- unstable ruin;
- social patrol;
- oath boundary;
- spirit test;
- corrupted material deposit;
- dangerous manual echo.

Do not rely on vague danger. Define the effect.

## 12.7 Downtime

Downtime is structured time spent on projects.

```yaml
downtime_project:
 name: string
 character: string
 type: training | research | recovery | crafting | sect_work | market_search | travel | social | item_refinement | other
 time_required: string
 progress: string
 requirements: []
 checks: []
 costs: []
 success_result: string
 failure_result: string
 partial_progress: boolean
```

Downtime creates only the records its project says it creates. It is not an alternate advancement economy.

## 12.8 Research and Investigation

Research can reveal rules, access, risks, histories, or routes.

```yaml
research_project:
 topic: string
 sources: []
 time_required: string
 check_or_DC: null_or_record
 cost: []
 success_information: []
 failure_information: []
 record_unlocked: null_or_record
```

Research does not automatically grant a talent, Recorded Art, Method, or item recipe unless the project says it does.

## 12.9 Downtime Training Support

Downtime can support training by satisfying requirements.

Examples:

- finding teacher;
- securing practice room;
- copying manual;
- buying materials;
- resolving access;
- completing prerequisite scene;
- stabilizing injury.

Downtime support is not the same as successful training.

Use Chapter 4 training rules when the character actually learns a Sphere, talent, or Recorded Art.

## 12.10 Downtime Recovery Support

Downtime can host recovery projects from Chapter 6.

```yaml
downtime_recovery:
 consequence: string
 recovery_project: string
 days_spent: integer
 checks_made: []
 result: string
 record_update: string
```

If a recovery project has no time scale, define it before play.

## 12.11 Market and Search Downtime

Searching for items, manuals, teachers, or materials can be downtime.

```yaml
market_search:
 desired_object: string
 location: string
 legality: open | restricted | illegal | secret
 time_spent: string
 check_or_DC: null_or_record
 cost: []
 success_result: string
 complication: null_or_string
```

A successful search can locate an opportunity. It does not automatically grant ownership, access, or mastery unless the result says so.

## 12.12 Harvest Sources

Harvesting materials uses a source record.

```yaml
harvest_source:
 name: string
 location: string
 material: string
 access: []
 danger: []
 harvest_check: null_or_record
 harvest_lot: null_or_record
 depletion: null_or_string
```

Harvest Lots are item/material records, not a universal quality ladder.

## 12.13 Exploration Examples

### Example A: Spirit Pool With Defined Benefit

```yaml
spirit_site:
 name: Blue Reed Pool
 CP_recovery:
 - once_per_character_restore_2_Qi_after_1_hour_meditation
 limits:
 - depletes_for_one_month_after_three_uses
```

This site restores CP because the record says so.

### Example B: Spirit Cave With No Mechanical Record

```yaml
spirit_site:
 name: Old Wind Cave
 mechanical_effects: []
```

The cave can be narratively important, but it grants no mechanical benefit yet.

### Example C: Downtime Research

```yaml
research_project:
 topic: identify_missing_section_of_jade_slip
 time_required: 3 days
 success_information:
 - art_is_Difficulty_4
 - requires_water-compatible_teacher
```

The research reveals requirements. It does not teach the art.

# Chapter 13 - Treasure, Items, Pills, Talismans, Materials, and Crafting

## 13.1 Chapter Purpose

Items in Tianxia should be useful, concrete, and easy to run. The GM Guide should explain how to adjudicate items and treasure without turning every impressive object into an undefined bundle of powers.

This chapter covers:

- item specificity;
- item records;
- pills;
- talismans;
- spirit stones;
- materials;
- Harvest Lots;
- crafting projects;
- treasure parcels;
- item risks;
- simple item stat blocks;
- source boundaries for later item-book work.

Boundary:

```text
An item does what its Source Rule says it does.
```

## 13.2 Item Specificity

A treasure can be ancient, famous, terrifying, beautiful, or Realm-shaking in lore. Its mechanics still need fields.

An item does not automatically grant:

- Spheres;
- talents;
- Recorded Arts;
- Methods;
- Foundations;
- AP;
- CP recovery;
- breakthrough bonuses;
- consequence removal;
- item-binding protection;
- crafting knowledge.

If the item grants one of those, the item record must say so.

## 13.3 Simple Item Stat Block

Use a simple stat block for GM-facing and player-facing readability.

```yaml
item_stat_block:
 name: string
 type: string
 rarity_or_grade: null_or_string
 requirement: null_or_string
 activation: null_or_string
 effect: string
 limit: null_or_string
 risk: null_or_string
 value_or_cost: null_or_string
 source_rule: string
```

Long import packets can exist elsewhere. The visible stat block should stay readable.

### 13.3.1 Example

```yaml
name: Reed-Wind Talisman
type: talisman
rarity_or_grade: uncommon
requirement: none
activation: bonus action
effect: Until the end of your turn, ignore nonmagical difficult terrain caused by wind, reeds, shallow water, or mud.
limit: consumed on use
risk: none
source_rule: talisman item record
```

## 13.4 Item Record

Use a fuller item record for GM ledger and tool import.

```yaml
item:
 name: string
 type: weapon | armor | tool | pill | talisman | treasure | manual | material | spirit_stone | artifact | other
 rarity_grade: null_or_string
 source: string
 owner_bearer: string
 status: carried | equipped | bound | sealed | dormant | active | expended | damaged | suppressed | lost
 requirements: []
 activation: null_or_string
 cost: []
 effect: string
 duration: null_or_string
 limits: []
 risk: []
 record_created: null_or_record
 notes: []
```

### 13.4.1 Missing Fields

If an item lacks activation, duration, target, limit, or risk, define those fields before combat or persistent use.

Do not assume the strongest interpretation.

## 13.5 Pills

Pills can grant AP, recovery, buffs, purification, breakthroughs support, or other effects only if their record says so.

### 13.5.1 Pill Record

```yaml
pill:
 name: string
 type: cultivation | enhancement | recovery | purifying | poison | special | other
 grade: null_or_string
 activation: ingest
 effect: string
 limit: string
 impurity_interaction: null_or_record
 risk: []
 value: null_or_string
```

### 13.5.2 Pill Overload

One Cultivation or Enhancement pill per long rest is safe by default.

Additional Cultivation or Enhancement pills require the overload procedure.

```yaml
pill_overload:
 save: Constitution
 DC: 10 + 2 * Cultivation_or_Enhancement_pills_already_consumed_since_last_long_rest
 success: pill works and gain 1 Pill Impurity
 failure: pill fails, gain 1 Pill Impurity, Poisoned until long rest
 failure_by_5_or_more: also gain 1 Exhaustion
```

### 13.5.3 Pill Impurity

```yaml
pill_impurity:
 stack_effect: -1_to_breakthrough_checks_per_stack
 duration: until_removed_by_defined_process
```

Pill Impurity does not vanish on long rest by default.

## 13.6 Talismans

A talisman is a prepared item effect.

A talisman can be used without granting the user the Talisman Sphere or crafting knowledge unless the item says otherwise.

```yaml
talisman:
 name: string
 activation: string
 effect: string
 target_or_area: null_or_string
 duration: string
 consumed: boolean
 requirements: []
 risk: []
```

### 13.6.1 Talisman Use vs. Talisman Knowledge

Using a talisman is not the same as knowing how to make it.

A talisman can:

- create one effect;
- be consumed;
- require a trigger;
- require a target;
- have a risk;
- have a Realm or Path restriction.

It does not teach the crafter’s art by default.

## 13.7 Spirit Stones

Spirit stones are currency, fuel, material, treasure, component, or ritual input as defined by Source Rules.

They do not provide default CP recovery.

They do not provide default AP awards.

```yaml
spirit_stone:
 grade_or_value: string
 use: currency | fuel | material | ritual_component | item_charge | other
 conversion_rate: null_or_string
 restrictions: []
 depletion: null_or_string
```

If a specific spirit-stone item restores CP or grants AP, write that effect as a Source Rule.

## 13.8 Materials and Harvest Lots

A material is a crafting input, trade good, ritual component, medicine ingredient, monster part, mineral, plant, spirit residue, or other useful substance.

```yaml
material:
 name: string
 source: string
 tags: []
 use: []
 value: null_or_string
 stability: null_or_string
```

### 13.8.1 Harvest Lot

```yaml
harvest_lot:
 name: string
 source: string
 quantity: string
 quality: null_or_string
 tags: []
 value: null_or_string
 use: string
 stability_or_spoilage: null_or_string
```

There is no universal Harvest Lot quality ladder.

Quality can exist inside a specific material system, adventure, or item book rule, but it is not global by default.

## 13.9 Crafting Project

Crafting should be a project record.

```yaml
crafting_project:
 item_goal: string
 crafter: string
 recipe_or_design: string
 requirements: []
 materials: []
 tools_or_workspace: []
 time_required: string
 check_or_DC: null_or_record
 cost: []
 success_result: string
 failure_result: string
 risk: []
 partial_progress: boolean
```

### 13.9.1 Recipe Requirement

The GM can require a recipe, teacher, manual, design, sect permission, item sample, or research project before crafting.

Do not let a character craft any item just because they own materials.

### 13.9.2 Crafting Failure

Failure can mean:

- no item;
- partial progress;
- material loss;
- flawed item;
- unstable item;
- backlash;
- consequence if defined;
- need for repair project.

Failure results should be written before the check.

## 13.10 Treasure Parcels

Treasure should be placed as parcels.

```yaml
treasure_parcel:
 name: string
 source: string
 contents: []
 access: []
 risks: []
 identified: boolean
 hidden_properties: []
 value: null_or_string
 records_created: []
```

Treasure parcels can include currency, spirit stones, manuals, pills, talismans, materials, maps, access tokens, keys, item fragments, and social leverage.

### 13.10.1 Identification

If an item has hidden properties, use an identification record.

```yaml
identification_record:
 item: string
 method: study | teacher | spell | talent | market_appraisal | trial | other
 time: string
 check_or_DC: null_or_record
 success_information: []
 failure_information: []
```

Identification reveals information. It does not automatically activate the item.

## 13.11 Item Risks

Items can have risks.

```yaml
item_risk:
 trigger: string
 effect: string
 save_or_check: null_or_record
 duration: string
 recovery_or_repair: null_or_record
```

Possible risks:

- backlash;
- impurity;
- curse;
- oath mark;
- attention;
- item hunger;
- instability;
- spirit rejection;
- sect illegality;
- material spoilage;
- formation alarm.

Risk should be known, discoverable, or fairly telegraphed unless secrecy is part of the item design.

## 13.12 Item Examples

### Example A: Pill With AP

```yaml
name: Minor Attainment Pill
type: cultivation pill
effect: gain 50 AP
limit: one Cultivation or Enhancement pill per long rest is safe
impurity_interaction: follows pill overload rules
```

The pill grants AP because the record says so.

### Example B: Spirit Stone Fuel

```yaml
spirit_stone:
 grade_or_value: low
 use: item_charge
 effect: fuels one activation of a listed formation lantern
```

It fuels the item. It does not restore CP.

### Example C: Harvest Lot

```yaml
harvest_lot:
 name: Ironleaf Serpent Scales
 quantity: 6 usable scales
 tags:
 - metal
 - poison-resistant
 use: armor reinforcement or antidote ingredient
```

This lot has tags because the record says so.

# Chapter 14 - Secret, Forbidden, Restricted, and Late-Game Power

## 14.1 Chapter Purpose

Tianxia needs powers that are rare, dangerous, hidden, taboo, sect-locked, bloodline-bound, spirit-gated, or too large for ordinary play. These powers should feel meaningful without breaking the base rules.

This chapter defines how the GM should handle:

- Secret power;
- Forbidden power;
- Restricted power;
- late-game systems;
- access records;
- taboo and exposure records;
- temptation and cost;
- strong rewards with real risk;
- endgame import boundaries.

Boundary:

```text
Rare power needs a Source Rule, access record, or explicit campaign procedure.
```

A hidden name, ancient origin, or frightening reputation has no mechanical effect unless a Source Rule, access record, or campaign procedure defines one.

## 14.2 Categories

Use these categories.

```yaml
rare_power_categories:
 Secret:
 meaning: hidden, concealed, rare, restricted by knowledge or access
 legality: may be legal or illegal depending on faction/context
 Forbidden:
 meaning: taboo, corruptive, predatory, illegal, spiritually dangerous, morally compromising, or socially catastrophic
 legality: usually dangerous or unlawful in at least one meaningful context
 Restricted:
 meaning: gated by rank, Realm, lineage, sect, vow, item, teacher, location, or Source Rule
 legality: often legal for approved users
 Late_Game:
 meaning: endgame-scale authority such as Dao Aspect, Immortal Art, Mandate, Heaven-scale law, or equivalent
 legality: depends on source
```

The categories can overlap. A power can be Secret and Forbidden, or Restricted and late-game.

## 14.3 Secret Power

Secret power is hidden or access-limited.

Possible Secret sources:

- hidden teacher;
- sealed manual;
- lineage inheritance;
- secret sect vault;
- jade slip with missing key;
- spirit contract;
- disguised item;
- hidden trial;
- old battlefield remnant;
- dream instruction;
- lost recipe;
- bloodline memory.

### 14.3.1 Secret Power Record

```yaml
secret_power:
 name: string
 source: string
 access_method: string
 knowledge_state: unknown | rumored | identified | partially_understood | learned | sealed
 restrictions: []
 risks: []
 mechanics: []
 exposure_risk: null_or_record
 teaching_or_training_procedure: null_or_record
```

A Secret power can be mechanically ordinary once learned. Its secrecy does not automatically make it stronger.

### 14.3.2 Discovery Procedure

```yaml
secret_discovery:
 - identify_clue
 - identify_required_source
 - define_check_or_scene
 - define_success_information
 - define_failure_information
 - define_access_record_if_successful
 - define_risk_if_any
```

Discovery can grant access or information. It does not grant mastery unless the Source Rule says so.

## 14.4 Forbidden Power

Forbidden power should be tempting.

It should not be so weak that no one would ever use it, and it should not be free power with no consequences.

Forbidden power can have:

- high efficiency;
- strong effect;
- unusual access;
- bypassed social limits;
- fast growth;
- predatory strength;
- dangerous recovery;
- taboo transformation;
- severe tribulation response;
- moral or social cost;
- corruption risk;
- burden;
- hidden injury;
- faction pursuit.

### 14.4.1 Forbidden Power Record

```yaml
forbidden_power:
 name: string
 source: string
 taboo: string
 attraction: string
 mechanical_benefit: string
 cost: string
 risk: []
 exposure_condition: string
 social_consequence: null_or_record
 cultivation_consequence: null_or_record
 recovery_or_integration: null_or_record
```

The attraction field matters. Forbidden power should have a reason a character would consider it.

### 14.4.2 Forbidden Use Procedure

```yaml
forbidden_use:
 - identify_forbidden_source
 - confirm_character_access
 - define_immediate_benefit
 - apply_cost
 - check_exposure
 - check_corruption_or_burden_if_applicable
 - update_social_records
 - update_consequence_records
 - update_tribulation_weight_if_relevant
```

### 14.4.3 Exposure

Forbidden exposure is not automatic unless a Source Rule, witness, formation, item, faction law, spirit, or scene record detects it.

```yaml
forbidden_exposure:
 source_power: string
 observer_or_system: string
 detection_method: string
 information_revealed: []
 social_result: string
 repair_or_concealment_path: null_or_string
```

## 14.5 Restricted Power

Restricted power is gated.

Gates can include:

- CL;
- Realm;
- sect rank;
- teacher permission;
- lineage status;
- vow;
- oath;
- item;
- spirit;
- trial;
- Method;
- Foundation;
- Path;
- manual access;
- location;
- material;
- campaign milestone.

### 14.5.1 Restricted Power Record

```yaml
restricted_power:
 name: string
 source: string
 restriction_type: []
 requirements: []
 access_granted_by: []
 access_lost_by: []
 mechanics: []
 misuse_result: null_or_record
```

If a character lacks the restriction requirement, they do not have access unless a Source Rule creates an exception.

### 14.5.2 Restricted Access Is Not Mastery

Access allows the next relevant procedure. It does not bypass training, breakthrough, item activation, crafting, or consequence rules unless the restriction record says so.

## 14.6 Late-Game Power

Late-game power includes Dao Aspects, Immortal Arts, Mandate-scale effects, Heaven-scale law, and other endgame systems.

These systems should not leak into ordinary play by implication.

```yaml
late_game_power:
 name: string
 source: string
 scale: Nascent | Immortal | Earth_Immortal | Heaven_Immortal | True_Immortal | other
 access_requirement: []
 construction_rules: []
 mandate_threshold: null_or_integer
 effect: string
 limits: []
 risks: []
 campaign_permission: required
```

### 14.6.1 Import Boundary

Late-game power enters a campaign only when the GM intentionally imports it.

Do not treat late-game references in lore as available player options.

### 14.6.2 Dao Aspect / Immortal Art Boundary

Dao Aspects and Immortal Arts are late-game construction tools and DM/AI-facing material unless explicitly made player-facing by a current Source Rule.

Use the current late-game source package only inside its defined scope.

## 14.7 Temptation Design

A good temptation has both attraction and price.

```yaml
temptation_design:
 offered_power: string
 immediate_gain: string
 long_term_gain: null_or_string
 immediate_cost: string
 long_term_risk: string
 social_risk: null_or_string
 recovery_or_redemption_path: null_or_string
```

The player should understand enough of the risk to make a meaningful choice, unless secrecy is part of the specific item or entity design.

## 14.8 Misuse, Overreach, and Correction

Misusing rare power can create:

- no effect;
- failed activation;
- item backlash;
- consequence;
- burden;
- exposure;
- bottleneck;
- unstable tag;
- damaged Foundation;
- Method strain;
- spirit debt;
- social record.

Use records.

```yaml
rare_power_misuse:
 source_power: string
 misuse_trigger: string
 result: string
 consequence_or_record: null_or_record
 correction_path: null_or_record
```

Correction should be possible when the campaign wants recovery, but it should not erase the history of the choice for free.

## 14.9 GM Examples

### Example A: Secret Manual

```yaml
secret_power:
 name: Moon-Under-Reed Hand
 access_method: decode hidden margin marks in manual
 knowledge_state: partially_understood
 mechanics: may train one listed Recorded Art after decoding
```

Decoding grants training access, not automatic mastery.

### Example B: Forbidden Appetite

```yaml
forbidden_power:
 name: Red Furnace Hunger
 attraction: gain strong temporary power from predatory refinement
 cost: social taboo and Burden risk
 exposure_condition: witnessed use or blood-qi detection formation
```

The power is tempting because it is strong, not because it is safe.

### Example C: Restricted Sect Art

```yaml
restricted_power:
 name: Inner Gate Cloud Seal
 restriction_type:
 - sect_rank
 - teacher_permission
 requirements:
 - inner_disciple_rank
 - Cloud Hall elder approval
```

A stolen copy may create access to information, but legal use, training, and social safety remain separate records.

# Chapter 15 - GM Records and Campaign Ledger

## 15.1 Chapter Purpose

Tianxia campaigns create many records. Without a ledger, the campaign will drift: AP awards are forgotten, consequences vanish, local rulings become invisible, items gain undefined powers, and social access becomes inconsistent.

This chapter gives the GM a practical record system.

Use as much of it as the campaign needs, but do not leave persistent mechanical changes unrecorded.

## 15.2 Core Ledger

```yaml
campaign_ledger:
 campaign_name: string
 current_rules_authority: Tianxia_Core_Rules_Reference_v0_3
 characters: []
 AP_awards: []
 breakthroughs: []
 consequences: []
 local_rulings: []
 items: []
 manuals_and_lineages: []
 foundations_and_methods: []
 sects_and_factions: []
 spirit_sites: []
 downtime_projects: []
 tribulations: []
 encounters: []
 unresolved_questions: []
```

The ledger can be a spreadsheet, JSON file, notebook, campaign wiki, folder of markdown files, GM Screen import, or character package.

## 15.3 Character Ledger

```yaml
character_ledger_entry:
 character_id: string
 name: string
 player: string
 current_CL: integer
 current_Realm: string
 Path: string
 current_AP: integer
 current_CP: integer
 maximum_CP: integer
 active_consequences: []
 active_social_records: []
 active_items: []
 open_projects: []
 last_updated_session: string
```

This is an index, not the full character sheet.

## 15.4 Session Ledger

Use a session ledger after every session.

```yaml
session_ledger:
 session_id: string
 date: string
 characters_present: []
 scenes: []
 AP_awards: []
 CP_changes: []
 HP_changes_if_relevant: []
 records_added: []
 records_changed: []
 consequences_added_or_resolved: []
 items_gained_or_lost: []
 social_records_changed: []
 local_rulings: []
 unresolved_questions: []
```

### 15.4.1 End-of-Session Procedure

```yaml
end_of_session_procedure:
 - confirm_AP_awards
 - confirm_training_or_project_progress
 - confirm_breakthrough_records
 - update_consequences
 - update_items_and_materials
 - update_social_and_access_records
 - classify_local_rulings
 - identify_unresolved_questions
 - prepare_next_session_state
```

## 15.5 Local Ruling Ledger

Local rulings should not live only in memory.

```yaml
local_ruling:
 title: string
 session_id: string
 scene: string
 source_gap: string
 ruling: string
 affected_records: []
 activation: null_or_string
 cost: null_or_record
 roll_or_DC: null_or_record
 success_result: string
 failure_result: string
 duration: string
 precedent: none | local_only | campaign_precedent | review_after_session
 expires: null_or_condition
```

Review local rulings before they accidentally become hidden universal systems.

## 15.6 Consequence Ledger

```yaml
consequence_ledger_entry:
 character: string
 consequence: string
 type: Hidden Injury | Deviation | Burden | Cultivation Scar | Cultivation Strain
 source: string
 active: boolean
 effect: string
 recovery_or_duration: string
 linked_projects: []
 last_checked: string
```

Consequences should not vanish without a recovery, duration, transformation, or source-defined removal.

## 15.7 Item and Treasure Ledger

```yaml
item_ledger_entry:
 item_id: string
 name: string
 owner_or_location: string
 status: carried | equipped | stored | hidden | lost | expended | damaged | sealed
 source: string
 known_properties: []
 hidden_properties: []
 risks: []
 last_updated: string
```

Use this for recurring treasures, artifacts, manuals, talismans, pills, materials, and spirit stones.

## 15.8 Faction and Access Ledger

```yaml
faction_access_ledger:
 character: string
 faction: string
 rank_or_status: null_or_string
 access_records: []
 obligations: []
 risks: []
 warrants_or_taboos: []
 last_updated: string
```

This prevents “I thought I had library access” disputes.

## 15.9 Project Ledger

Use a project ledger for recovery, crafting, research, training support, Method change, Foundation repair, travel, and social projects.

```yaml
project_ledger_entry:
 project_id: string
 type: recovery | crafting | research | training_support | Method_change | Foundation_repair | travel | social | other
 character_or_party: []
 goal: string
 requirements: []
 progress: string
 checks_made: []
 costs_paid: []
 success_result: string
 failure_result: string
 status: open | complete | failed | abandoned | paused
```

## 15.10 Unresolved Question Ledger

```yaml
unresolved_question:
 question: string
 affected_character_or_record: string
 temporary_resolution: null_or_string
 source_needed: string
 urgency: before_next_use | before_next_session | before_breakthrough | no_deadline
```

Use this when the GM makes a temporary ruling or discovers missing source text.

## 15.11 Ledger Audit Cycle

Run this audit periodically.

```yaml
ledger_audit:
 AP_totals_match_character_records: true
 CP_maximums_match_current_formula: true
 active_consequences_have_effects: true
 open_projects_have_progress: true
 local_rulings_classified: true
 items_have_defined_effects_if_used: true
 social_access_records_are_current: true
 unresolved_questions_reviewed: true
```

# Chapter 16 - Optional Modules and Variant Pacing

## 16.1 Chapter Purpose

Campaigns can differ. Some groups want fast advancement. Some want harsh consequence play. Some want sect politics, item crafting, tournaments, wilderness survival, or high treasure. Optional modules let the GM support these campaigns without changing default canon.

Boundary:

```text
An optional module changes only what it says it changes.
```

Keep optional rules explicitly labeled and opt-in.

## 16.2 Optional Module Record

```yaml
optional_module:
 name: string
 purpose: string
 scope: campaign | arc | region | faction | trial | scene | character_specific
 changes: []
 unchanged_rules: []
 records_created: []
 activation_condition: string
 deactivation_condition: string
 player_notice_required: boolean
 compatibility_notes: []
```

Every module must state what it changes and what it does not change.

## 16.3 Module Design Rules

A module should:

- identify its scope;
- preserve Core v0.3 unless explicitly changed;
- create records when it changes mechanics;
- avoid hidden universal systems;
- tell players if it affects advancement or character risk;
- say how to turn it off.

A module should not:

- rewrite character records secretly;
- create untracked AP or CP recovery;
- grant free record editing;
- bypass Source Rules silently;
- stack with other modules without permission.

## 16.4 Pacing Modules

### 16.4.1 Fast Advancement

```yaml
module:
 name: Fast Advancement
 changes:
 - increase AP awards by chosen campaign multiplier
 unchanged_rules:
 - breakthrough checks still required
 - failed breakthrough AP reset still applies
 - no level talent until successful CL gain
```

### 16.4.2 Slow Sect Campaign

```yaml
module:
 name: Slow Sect Campaign
 changes:
 - fewer AP awards from combat
 - more AP from sect duties, training, and discoveries
 unchanged_rules:
 - AP remains AP
 - breakthrough rules unchanged
```

### 16.4.3 Tournament-Forward Campaign

```yaml
module:
 name: Tournament-Forward Campaign
 changes:
 - tournament records and combat logs are required
 - safety rules are defined before each bracket
 unchanged_rules:
 - suppression still preserves actual records
```

## 16.5 Risk Modules

### 16.5.1 Harsher Consequence Campaign

```yaml
module:
 name: Harsher Consequence Campaign
 changes:
 - failed high-risk cultivation scenes more often create defined consequences
 unchanged_rules:
 - consequences still require records
 - ordinary HP damage still does not create cultivation consequences by default
```

### 16.5.2 Forbidden Temptation Campaign

```yaml
module:
 name: Forbidden Temptation Campaign
 changes:
 - Forbidden options appear more often
 - exposure and taboo records matter more
 unchanged_rules:
 - Forbidden power still needs Source Rules
 - cost and benefit must both be defined
```

## 16.6 Treasure and Crafting Modules

### 16.6.1 High-Treasure Campaign

```yaml
module:
 name: High-Treasure Campaign
 changes:
 - treasure parcels appear more often
 - item identification and risk records matter more
 unchanged_rules:
 - items grant only written mechanics
 - spirit stones do not provide default CP recovery or AP awards
```

### 16.6.2 Crafting-Forward Campaign

```yaml
module:
 name: Crafting-Forward Campaign
 changes:
 - crafting projects are central downtime
 - recipes, materials, workspaces, and teachers are major rewards
 unchanged_rules:
 - owning materials does not bypass recipe or project requirements
```

## 16.7 Social and Exploration Modules

### 16.7.1 Sect Politics Campaign

```yaml
module:
 name: Sect Politics Campaign
 changes:
 - faction access, rank, oaths, missions, and taboos are central records
 unchanged_rules:
 - no universal reputation, face, or karma score
```

### 16.7.2 Wilderness Cultivation Campaign

```yaml
module:
 name: Wilderness Cultivation Campaign
 changes:
 - region, travel, hazard, harvest, and Spirit Site records are central
 unchanged_rules:
 - Spirit Sites still provide only record-defined benefits
```

## 16.8 Module Compatibility

When using more than one module, write a compatibility note.

```yaml
module_compatibility:
 modules: []
 compatible: true_or_false
 conflict: null_or_string
 resolution: null_or_string
```

Example conflict:

```yaml
conflict:
 modules:
 - Fast Advancement
 - Slow Sect Campaign
 resolution: Fast Advancement applies only to breakthrough-relevant discoveries, not combat awards.
```

# Chapter 17 - Appendix A: GM Procedure Cards

## A.1 Purpose

These cards condense the GM Guide into short procedures.

They are not replacement rules. They are quick-use references. When a card conflicts with a current Source Rule or Core v0.3, use the Source Rule or Core v0.3.

## A.2 Adjudication Card

```yaml
adjudication_card:
 - identify_player_intent
 - identify_relevant_records
 - identify_Source_Rule
 - check_Core_v0_3_default
 - classify: rules_confirmed | source_rule_required | local_ruling_required | unsupported | invalid
 - define_missing_fields
 - resolve_effect
 - update_records
 - write_local_ruling_if_repeatable
```

## A.3 Local Ruling Card

```yaml
local_ruling_card:
 title: string
 source_gap: string
 ruling: string
 activation: null_or_string
 cost: null_or_record
 roll_or_DC: null_or_record
 success_result: string
 failure_result: string
 duration: string
 precedent: none | local_only | campaign_precedent | review_after_session
```

## A.4 Training Card

```yaml
training_card:
 training_type: new_Sphere | known_Sphere_talent | Recorded_Art | support_project
 source: string
 time: string
 DC: string
 roll: null_or_record
 success_result: string
 failure_result: string
 record_update: string
```

## A.5 Breakthrough Card

```yaml
breakthrough_card:
 - confirm_AP_threshold
 - classify_same_Realm_or_Realm
 - calculate_DC
 - validate_preparation
 - apply_legal_modifiers
 - assess_tribulation_if_called
 - roll_Cultivation_Check
 - on_success_update_CL_Realm_PB_CP_max
 - on_failure_reset_AP_to_floor_required_AP_over_2
 - write_breakthrough_record
```

## A.6 Consequence Card

```yaml
consequence_card:
 source: string
 type: Hidden Injury | Deviation | Burden | Cultivation Scar | Cultivation Strain
 affected_record: string
 trigger: string
 mechanical_effect: string
 duration_or_recovery: string
 visibility: string
 escalation: null_or_string
```

## A.7 Recovery Project Card

```yaml
recovery_project_card:
 consequence: string
 mode: Purify | Repair | Integrate | other
 time: string
 requirements: []
 check_or_DC: null_or_record
 cost: []
 success_result: string
 failure_result: string
 partial_progress: boolean
```

## A.8 Foundation / Method Card

```yaml
foundation_method_card:
 record: Foundation | Method
 status: string
 active_effects: []
 passive_effects: []
 compatibility: []
 incompatibility: []
 burdens_or_risks: []
 project_needed: null_or_string
```

## A.9 Suppression / Trial Card

```yaml
suppression_trial_card:
 actual_CL: integer
 suppressed_CL: integer
 PB_used: integer
 scope: string
 unavailable_records: []
 retained_records: []
 duration_or_end: string
 trial_success: []
 trial_failure: []
```

## A.10 Combat Effect Card

```yaml
combat_effect_card:
 actor_has_record: true
 activation_available: true
 cost_payable: true
 target_range_area_defined: true
 roll_save_check_defined_if_needed: true
 effect_defined: true
 duration_defined: true
 record_update_defined_if_persistent: true
```

## A.11 Encounter Card

```yaml
encounter_card:
 scene_goal: string
 enemies: []
 hazards: []
 formations: []
 terrain: []
 restrictions: []
 victory_conditions: []
 failure_conditions: []
 rewards: []
 consequences: []
```

## A.12 Tribulation Card

```yaml
tribulation_card:
 trigger: string
 base_weight: integer
 modifiers: []
 total_weight: integer
 band: omen_only | light | standard | heavy | severe | heaven_offending
 timing: string
 stages: []
 counterplay: []
 success_results: []
 failure_results: []
 rewards: []
 consequences: []
```

## A.13 Social / Access Card

```yaml
social_access_card:
 faction_or_NPC: string
 access_type: string
 granted_to: string
 requirements: []
 duration: string
 obligations: []
 risks: []
 learning_or_use_procedure_required: true
```

## A.14 Spirit Site Card

```yaml
spirit_site_card:
 name: string
 access_requirements: []
 mechanical_effects: []
 limits: []
 risks: []
 AP_rewards: []
 CP_recovery: []
 breakthrough_modifiers: []
 training_modifiers: []
 harvest_lots: []
```

## A.15 Item / Crafting Card

```yaml
item_crafting_card:
 item_goal_or_item: string
 source_rule: string
 activation_or_project_time: string
 requirements: []
 materials_or_cost: []
 effect_or_success_result: string
 limit: null_or_string
 risk_or_failure_result: null_or_string
```

## A.16 Session Review Card

```yaml
session_review_card:
 AP_awards_recorded: true
 CP_changes_recorded: true
 training_or_project_progress_recorded: true
 breakthroughs_recorded: true
 consequences_recorded: true
 items_updated: true
 social_records_updated: true
 local_rulings_classified: true
 unresolved_questions_listed: true
```

# Chapter 18 - Appendix B: Expansion Order and Final Assembly

## B.1 Purpose

The GM Guide is now built from expanded chapter packages. This appendix defines how to assemble, audit, and polish the final manuscript.

This appendix is not a new rules chapter. It is the assembly and quality-control guide.

## B.2 Current Expanded Chapter Set

```yaml
expanded_chapters:
 - Chapter_1_GM_Adjudication_Core
 - Chapter_2_Character_State_and_Records
 - Chapter_5_Advancement_AP_Breakthroughs_Bottlenecks
 - Chapter_6_Consequences_Failure_Recovery
 - Chapter_7_Foundations_and_Methods
 - Chapter_8_Realm_Suppression_Teaching_Duels_Trials
 - Chapter_9_Combat_Encounters_Cultivation_Effects
 - Chapter_10_Tribulations_Cultivation_Weight
 - Chapter_11_Sects_Factions_Oaths_Social_Play
 - Chapter_12_Exploration_Spirit_Sites_Travel_Downtime
 - Chapter_13_Treasure_Items_Pills_Talismans_Materials_Crafting
 - Chapter_14_Secret_Forbidden_Restricted_Late_Game_Power
 - Chapter_15_GM_Records_Campaign_Ledger
 - Chapter_16_Optional_Modules_Variant_Pacing
 - Chapter_17_GM_Procedure_Cards
 - Chapter_18_Expansion_Order_Final_Assembly
```

Chapters 3 and 4 remain spine-defined but not separately expanded in this GM Guide chapter run. Their material is partially covered by Chapters 1, 2, 5, 6, 7, 11, 12, and 17. They can be expanded later if the GM Guide needs more front-half tutorial flow.

## B.3 Recommended Final Manuscript Order

```yaml
gm_guide_final_order:
 0: Authority_and_Introduction
 1: GM_Adjudication_Core
 2: Character_State_and_Records
 3: Running_Cultivation_Scenes
 4: Training_Spheres_Talents_Manuals_Lineages
 5: Advancement_AP_Breakthroughs_Bottlenecks
 6: Consequences_Failure_Recovery
 7: Foundations_and_Methods
 8: Realm_Suppression_Teaching_Duels_Trials
 9: Combat_Encounters_Cultivation_Effects
 10: Tribulations_Cultivation_Weight
 11: Sects_Factions_Oaths_Social_Play
 12: Exploration_Spirit_Sites_Travel_Downtime
 13: Treasure_Items_Pills_Talismans_Materials_Crafting
 14: Secret_Forbidden_Restricted_Late_Game_Power
 15: GM_Records_Campaign_Ledger
 16: Optional_Modules_Variant_Pacing
 17: Appendix_A_GM_Procedure_Cards
 18: Appendix_B_Expansion_Order_Final_Assembly
```

## B.4 Final Assembly Inputs

Use these as current chapter inputs:

```yaml
assembly_inputs:
 chapter_01_02_package: Tianxia_GMG_Ch01_Ch02_Expanded_v0_1
 chapter_05_06_package: Tianxia_GMG_Ch05_Ch06_Expanded_v0_1
 chapter_07_08_package: Tianxia_GMG_Ch07_Ch08_Expanded_v0_1
 chapter_09_10_package: Tianxia_GMG_Ch09_Ch10_Expanded_v0_1
 chapter_11_13_package: Tianxia_GMG_Ch11_Ch13_Expanded_v0_1
 chapter_14_18_package: Tianxia_GMG_Ch14_Ch18_Expanded_v0_1
```

Use the GM Guide spine to supply any missing frontmatter and spine-defined bridge chapters.

## B.5 Completion Gates

Before declaring the GM Guide manuscript complete, every chapter should pass these gates.

```yaml
chapter_completion_gate:
 authority_note_present: true
 Core_v0_3_alignment: true
 AI_v0_3_procedure_compatibility: true
 no_deprecated_terms: true
 no_hidden_universal_subsystems: true
 procedure_present: true
 record_template_present_if_mechanical: true
 example_present: true
 chapter_audit_checklist_present: true
```

## B.6 Cross-Chapter Consistency Checks

Run these checks across the full manuscript.

```yaml
cross_chapter_checks:
 AP_means_Attainment_Points_everywhere: true
 Maximum_CP_formula_current: true
 no_default_record_editing: true
 Recorded_Art_term_consistent: true
 no_universal_pressure_mechanic: true
 no_universal_social_score: true
 Spirit_Site_record_boundary_consistent: true
 spirit_stone_no_default_CP_or_AP_consistent: true
 one_Primary_Method_rule_consistent: true
 suppression_preserves_actual_state: true
 ordinary_HP_damage_no_cultivation_consequence_by_default: true
 full_tribulation_not_default_for_all_breakthroughs: true
 Harvest_Lot_no_universal_quality_ladder: true
```

## B.7 Redundancy and Polish Pass

The chapter packages intentionally repeat key boundaries. The final manuscript should keep critical reminders but reduce excessive repetition.

Polish pass targets:

- reduce duplicate definitions;
- move repeated record templates to appendices where useful;
- keep chapter-specific procedure text in chapters;
- keep quick cards in Appendix A;
- preserve all critical boundaries;
- add page references after final layout;
- add examples only where they teach a distinct procedure.

## B.8 Missing or Optional Future Expansions

The following can be expanded later if needed:

```yaml
optional_future_expansions:
 Chapter_3_Running_Cultivation_Scenes:
 status: spine_defined
 need: full tutorial chapter if GM Guide wants more scene-facing guidance
 Chapter_4_Training_Spheres_Talents_Manuals_Lineages:
 status: spine_defined
 need: full training/manual chapter if GM Guide wants more learning examples
 Monster_Building_Appendix:
 status: future
 Encounter_Tables_Appendix:
 status: future
 Treasure_Table_Appendix:
 status: future_item_book_interface
 Sect_Generator_Appendix:
 status: future
```

## B.9 Final Manifest Requirements

A final GM Guide package should include:

```yaml
final_package:
 manuscript_md: required
 source_map_json: required
 manifest_json: required
 audit_md: required
 checksum_txt: required
 package_zip: required
 optional_docx_or_pdf: optional
```

If creating DOCX or PDF later, follow the document/PDF artifact requirements before generation.

## B.10 Final Audit Verdict Target

The desired final audit verdict is:

```text
PASS_TIANXIA_GM_GUIDE_V0_1_FULL_MANUSCRIPT_AUDIT
```

The audit should check:

- ZIP integrity;
- file hashes;
- source map completeness;
- chapter presence;
- old term absence;
- formula consistency;
- authority consistency;
- no unsupported universal systems;
- record template availability;
- assembly order.
