# Tianxia: Cultivation — The Immortal’s Path

## Player Handbook Manuscript v0.7 — Subpath Selection and Access Inserted

This controlled manuscript revision contains the shared orthodox Path rules, the finalized player-facing core chapters for Body Refining, Qi Cultivation, and Spirit Awakening, the central Cultivation Insight rules with 72 core options and a complete 451-entry index, and the complete player-facing rules for Subpath access, lineages, Variants, multi-Path progression, and Realm Suppression. Full Subpath and Insight catalogues remain in their separate compendium volumes.

## Contents

- [00. Cultivation for Beginners](#00-cultivation-for-beginners)
- [01. Level 0 Character Creation](#01-level-0-character-creation)
- [02. Sect Trial and Becoming CL 1](#02-sect-trial-and-becoming-cl-1)
- [03. Paths and Shared Path Rules](#03-paths-and-shared-path-rules)
- [04. Body Refining](#04-body-refining)
- [05. Qi Cultivation](#05-qi-cultivation)
- [06. Spirit Awakening](#06-spirit-awakening)
- [07. Cultivation Insights](#07-cultivation-insights)
- [08. Subpaths, Traditions, and Cultivation Lineages](#08-subpaths-traditions-and-cultivation-lineages)
- [09. Spheres and Talents Overview](#09-spheres-and-talents-overview)
- [10. Advancement and Realms Overview](#10-advancement-and-realms-overview)
- [11. Foundations Overview](#11-foundations-overview)
- [12. Methods Overview](#12-methods-overview)
- [13. Backgrounds](#13-backgrounds)
- [14. Origin Insights](#14-origin-insights)
- [15. Manuals, Lineages, and Recorded Arts](#15-manuals-lineages-and-recorded-arts)
- [16. Cultivation Resources, Rest, and Recovery](#16-cultivation-resources-rest-and-recovery)
- [17. Breakthroughs and Attainment](#17-breakthroughs-and-attainment)
- [18. Forged Techniques and Emergency Forging](#18-forged-techniques-and-emergency-forging)
- [19. Injuries, Deviations, Burdens, and Cultivation Scars](#19-injuries-deviations-burdens-and-cultivation-scars)
- [20. Equipment, Items, Treasures, and Crafting](#20-equipment-items-treasures-and-crafting)
- [21. Combat and Cultivation Actions](#21-combat-and-cultivation-actions)
- [22. Exploration, Travel, Sects, and Downtime](#22-exploration-travel-sects-and-downtime)
- [23. Social Play, Reputation, Karma, and Factions](#23-social-play-reputation-karma-and-factions)
- [A. Common Player Records and Templates](#common-player-records-and-templates)
- [Glossary. Backmatter Glossary](#backmatter-glossary)

---

# 00. Cultivation for Beginners

Tianxia uses the language of cultivation stories: sects, Realms, breakthroughs, manuals, elders, juniors, Dao, face, and the pursuit of immortality.

You do not need to know the genre to play. This section gives you the basic ideas and common table language so the rest of the book feels natural.

## Cultivation and the Dao

Cultivation fantasy draws from many sources: Chinese mythology, martial arts fiction, Daoist thought, Buddhist and folk religious imagery, alchemy, medicine, folklore, and modern xianxia novels.

Daoism is a Chinese religious and philosophical tradition centered on the **Dao**, often translated as “the Way.” The Dao is not just a path someone chooses. It can mean the deep pattern of reality, the natural course of things, the source beneath names, or the way a person aligns with the world.

Some Daoist traditions also include practices of longevity, inner transformation, meditation, breathing, ritual, talismans, alchemy, and the pursuit of transcendence or immortality. The fantasy idea of a cultivator refining body, spirit, and inner power until they become an immortal has roots in these older ideas, but Tianxia is not a historical or religious manual. It is a game inspired by that imagination: the dream that discipline, danger, insight, and transformation can carry a person beyond ordinary limits.

## What Is Cultivation?

Cultivation is the practice of refining yourself beyond ordinary mortal life.

A cultivator may train the body, gather inner power, awaken the spirit, study old teachings, learn techniques, survive trials, and attempt breakthroughs into higher Realms. Some cultivators are martial artists. Some are scholars, healers, talisman writers, spirit mediums, sword disciples, wandering rogues, or heirs to strange bloodlines.

In Tianxia, your character’s cultivation is represented by Path, CL, Realm, CP, Spheres, talents, Foundations, Methods, Recorded Arts, Forged Techniques, and breakthroughs.

Chapter 1 begins with character creation and introduces these pieces step by step.

## The Shape of the Path

A cultivator is someone walking a path.

They may seek strength, immortality, freedom, revenge, family safety, sect honor, a perfect sword art, a cure for an old injury, or proof that their way is real. Cultivation stories are about progress, but progress is rarely clean. A character may need training, insight, medicine, manuals, teachers, rare materials, dangerous trials, and the courage to attempt a breakthrough when failure still matters.

Power is part of the path. So are restraint, pride, debt, rivalry, loyalty, fear, ambition, and the question of what the character is willing to become.

## Common Words

| Word | Meaning |
|---|---|
| Cultivator | Someone who trains beyond ordinary mortal limits. |
| Realm | A major stage of cultivation, such as Mortal, Foundation, Core Formation, Nascent Soul, or True Immortality. |
| CL | Cultivation Level. Your level in the rules. |
| Breakthrough | An attempt to advance to a new CL or Realm. |
| Foundation | The cultivation base that supports future growth. |
| Method | The main way your cultivation develops and circulates. |
| Sphere | A field of cultivation expression, such as Sword, Fire, Dreams, or Talismans. |
| Talent | A specific ability learned within a Sphere. |
| Manual | A book, jade slip, mural, scripture, inheritance, or other teaching source. |
| Recorded Art | A fixed technique learned from a teaching source. |
| Dao | A principle, path, truth, or way of understanding cultivation. |
| Sect | A cultivation organization, school, clan, temple, academy, or lineage. |
| Face | Public standing, dignity, and social reputation. |

## Realms

Realms are the great stages of cultivation.

A Mortal-Realm cultivator is still close to ordinary limits, though already exceptional. At Foundation, the character’s cultivation base becomes stable and begins to shape their future. At Core Formation, deeper power condenses and more complex techniques become possible. At Nascent Soul, the character’s soul, identity, and higher cultivation matter at a much greater scale. True Immortality is the highest standard player-facing stage in the core PHB.

A higher Realm is not just a larger number. It usually means a stronger body, deeper reserves, better control, more dangerous techniques, and greater pressure from the world.

## How Cultivators Speak

Cultivators often speak with attention to rank and relationship.

In the same sect, someone above you might be called **Senior Brother**, **Senior Sister**, or **Senior Disciple**. Someone below you might be called **Junior Brother**, **Junior Sister**, or **Junior Disciple**. These terms usually describe sect relationship, not blood family.

A respectful junior might say:

> “Senior Sister, may I ask for guidance?”

> “This disciple greets Elder.”

> “Fellow Daoist, shall we cooperate?”

Use this style when it adds flavor, respect, tension, or humor at the table. It is not a script players must follow every time they speak.

## Teachers, Elders, and Fellow Daoists

A **Master** is usually your personal teacher. An **Elder** is a senior authority in a sect, clan, temple, academy, or lineage. A **Sect Master** leads a sect. A **Hall Master** leads a branch, hall, or department.

When speaking to cultivators outside your sect, **Fellow Daoist** or **Daoist Friend** is a common polite address. If someone is clearly stronger, older, or higher status, calling them **Senior** is usually safer than guessing wrong.

Rank changes with context. A younger cultivator may be senior because they entered the sect earlier. An older cultivator may be junior because they are lower Realm. A guest may deserve respect because of who sent them.

## Courtesy and Face

Cultivation society can be dangerous because public respect matters.

Bowing, using titles, returning borrowed manuals, asking permission before entering a hall, and thanking a teacher are ordinary signs of respect. Ignoring etiquette can be funny, brave, insulting, or disastrous depending on the audience.

Face is the public side of respect. A character can gain face through skill, restraint, courage, loyalty, generosity, or proper conduct. A character can lose face by breaking promises, insulting seniors, failing public duties, or humiliating the wrong person.

Face has no universal score in the PHB. It matters when the scene, faction, or rule makes it matter.

## Sects

A sect is not only a place to learn techniques.

A sect has teachers, rivals, rules, libraries, medicine halls, missions, trial grounds, factions, elders, servants, secrets, and politics. It controls access to training, manuals, pills, safe lodging, teachers, and protection.

A character may know that a powerful manual exists and still lack permission to read it. They may have enough money for a pill and still lack the rank to buy it. In cultivation society, access is often as important as wealth.

## Manuals and Inheritances

A manual can be more valuable than gold.

Manuals, jade slips, murals, inheritance tablets, and cultivation journals may teach techniques, explain Methods, preserve warnings, reveal old mistakes, or point toward hidden routes.

Owning a manual is not the same as mastering it. A character still uses the rules for learning what it contains.

An inheritance is a preserved legacy left by a cultivator, sect, spirit, ruin, ancestor, or ancient power. It may be generous, dangerous, incomplete, testing, deceptive, cursed, or tied to old karma.

## Closed-Door Cultivation

Closed-door cultivation means withdrawing from ordinary activity to focus deeply on training, study, healing, or breakthrough preparation.

It is a common story phrase, not a separate rule by itself. Use the relevant training, recovery, downtime, or breakthrough rules.

## Bottlenecks

A bottleneck is a point where progress stalls.

A character might be blocked by a failed breakthrough, weak understanding, injury, missing teacher, incomplete manual, lack of materials, or fear. A bottleneck is often a signpost. It tells the player what kind of training, story, or correction the character may need next.

## Dao Heart

A cultivator’s Dao Heart is their inner conviction and relationship to their path.

A strong Dao Heart does not mean the character is morally good. It means they are hard to shake from the path they have chosen.

Dao Heart is not a universal PHB score unless a specific rule gives it mechanics.

## Tribulation

A Heavenly Tribulation is a dangerous trial or pressure that may appear during major cultivation moments.

Tribulation is not only punishment. It can also be recognition, transformation, warning, scar, or proof that the character has reached beyond ordinary limits.

Not every breakthrough requires a full tribulation. The rules explain when tribulation matters.

## Playing a Cultivator

When you play a cultivator, think about what your character is pursuing and what they refuse to abandon.

They might want immortality, revenge, freedom, family safety, sect honor, a perfect sword art, a cure for an old injury, or proof that their path is real. They might bow to a teacher, defy an elder, spare a rival, hide a forbidden secret, or risk everything for one breakthrough.

Useful questions:

| Question | Purpose |
|---|---|
| What does my character seek? | Gives them direction. |
| Who taught them? | Connects them to the world. |
| Who do they owe? | Creates pressure and story. |
| What would make them bow? | Shows what they respect. |
| What would make them draw a blade? | Shows what they will risk. |

## Quick Speech Examples

A respectful junior might say:

> “Disciple greets Elder. This disciple requests guidance.”

A polite outsider might say:

> “Fellow Daoist, this ruin is dangerous. Cooperation may spare us trouble.”

A senior warning a junior might say:

> “Junior Sister, that manual is incomplete. Do not circulate its route without a teacher present.”

A rival might say:

> “You defeated me once. At the next sect trial, I will ask for another match.”

## Summary

Cultivation language is about relationship, rank, effort, danger, and ambition.

A sect is not just a school.  
A manual is not just a book.  
A breakthrough is not just leveling up.  
A rival is not just an enemy.  
A teacher is not just a trainer.  
A Dao is not just an idea.

Your character is walking a path. Learn who walks ahead, who follows behind, who watches from the side, and what your character is willing to risk to keep going.

---

# 01. Level 0 Character Creation

Level 0 characters are mortal people standing at the edge of cultivation. They have training, instincts, wounds, family history, tools, and strange possibilities, but they are not yet full cultivators.

This chapter gives the short procedure for making a level 0 Tianxia character before the sect trial.

## Level 0 Assumptions

At level 0, your character has:

- no Path;
- no Foundation;
- no cultivation Method;
- no sect-trial Dao Sphere;
- no normal cultivation resource pool;
- no full cultivation technique access unless a printed rule explicitly says otherwise.

Your Background and Origin Insight are the main sources of level 0 identity.

## Creation Steps

1. Choose a mortal concept.
2. Choose Human as your species.
3. Generate ability scores; default Tianxia uses 27-point buy.
4. Choose one Background.
5. Apply your Background ability score increase.
6. Record your Background proficiencies, equipment, Background Sphere, and Background Talent.
7. Choose one Origin Insight.
8. Record level 0 combat statistics.
9. Note what changes after the sect trial.

## Step 1: Mortal Concept

Start with a simple mortal identity. You do not need to know the character’s full Dao yet.

Useful questions:

- What did you do before the sect trial?
- What are you good at?
- What tool, trade, weapon, or habit shaped your training?
- Who would recognize your name, face, or work?
- What problem do people usually bring to you?

Keep this short. The Background and Origin Insight will carry most of the mechanical weight.

## Step 2: Species

For the current Tianxia PHB baseline, all starting characters are **Human**.

A Human character is a Medium Humanoid with a walking speed of 30 feet. This chapter does not use alternate species traits. Future species expansions may replace this step, but the rest of the level 0 procedure remains the same unless that expansion says otherwise.

## Step 3: Ability Scores

The default Tianxia option is standard 5.5e point buy: start with 8 in each ability score and spend 27 points using the standard point-buy costs. A campaign may instead use standard array, random generation, or another normal 5.5e method.

After generating ability scores, apply your Background ability score increase:

- increase one of the Background’s listed ability scores by 2; or
- increase two of the Background’s listed ability scores by 1 each.

This increase cannot raise a score above 20. The current Human baseline does not add a separate species ability score increase.

## Step 4: Background

Choose one Background from the Backgrounds chapter.

Your Background grants:

- skill proficiencies;
- tool, language, or trade proficiencies;
- starting equipment;
- one Background Sphere and Background Talent package, unless the Background says otherwise;
- suggested Origin Insight options.

### Background Spheres at Level 0

A Background Sphere represents mortal training, dormant exposure, inherited practice, or practical technique.

At level 0, a Background Sphere functions only as described by the Backgrounds chapter:

- active Background Spheres function at mortal scale;
- dormant Background Spheres grant recognition, knowledge, signs, and future access;
- preparatory Background Spheres grant literacy, etiquette, vessel knowledge, relationship preparation, or training habits;
- Background Talents use only their safe level 0 portions unless a printed rule unlocks more.

A Background Sphere is not the same as the sect-trial Dao Sphere.

## Step 5: Origin Insight

Choose one Origin Insight.

An Origin Insight is the first truth your character brings into cultivation. It is not a Path, Sphere, Foundation, Method, manual, Recorded Art, or Dao Sphere.

Your Origin Insight remains part of the character after the sect trial.

You may choose from your Background’s suggested list or choose another legal Origin Insight that fits the character.

## Step 6: Level 0 Statistics

Record the following level 0 statistics.

| Statistic | Level 0 Value |
|---|---|
| Character Level | 0 |
| Species | Human |
| Creature Type | Humanoid |
| Size | Medium |
| Speed | 30 feet |
| Hit Dice | 1d6 |
| Hit Points | 6 + Constitution modifier, minimum 1 |
| Proficiency Bonus | +0 |
| Saving Throw Proficiencies | None until a Path or printed rule grants them |
| Weapon and Armor Proficiencies | From Backgrounds, Background Spheres/Talents, equipment rules, or other printed features |
| Cultivation Path | None |
| Foundation | None |
| Method | None |
| Sect-Trial Dao Sphere | None |
| Cultivation Resource | None, unless a printed rule explicitly grants one |
| Background Sphere | From Background |
| Background Talent | From Background |
| Origin Insight | One |

If a Background or Origin Insight grants proficiency, record it normally. If an Origin Insight grants expertise in a proficiency you already have, double your Proficiency Bonus for checks that use that proficiency.

A level 0 character has no default weapon or armor proficiency beyond the sources listed in the table.

At level 0, a +0 Proficiency Bonus means proficiency usually matters through future scaling, expertise preparation, narrative permissions, training identity, and any printed rules that reference proficiency. It does not add a numerical bonus until the character gains a positive Proficiency Bonus.

## Step 7: What You Cannot Do Yet

A level 0 character cannot normally:

- spend CP, Stamina, Resonance, or another cultivation resource;
- use full active sphere techniques;
- make breakthrough checks;
- choose a Path feature;
- gain a Foundation benefit;
- learn a cultivation Method;
- claim a sect-trial Dao Sphere;
- use talents that require a higher Realm;
- treat dormant or preparatory sphere access as full sphere use.

Specific printed rules can override this, but the default is mortal scale.

## Step 8: The Sect Trial

The sect trial is the transition from mortal identity to cultivation.

After the trial, the character normally becomes CL 1 and gains access to the next creation layer:

- choose or confirm a Path;
- gain that Path’s hit die and resource rules;
- receive the sect-trial Dao Sphere according to the Sect Trial chapter, gaining its base ability and one talent that counts as your CL 1 level talent;
- begin normal Sphere and talent progression;
- apply the Background Sphere rule: an active Background Sphere counts as a known Sphere at CL 1 unless another printed rule says otherwise;
- activate dormant or preparatory Background Spheres only when a printed rule supports that activation.

The trial should not erase the level 0 character. It should reveal how the mortal life becomes a cultivation route.

## Quick Checklist

Before play begins, the character sheet should show:

- Human;
- ability scores after Background increase;
- Background;
- Background proficiencies;
- Background equipment;
- Background Sphere and Background Talent;
- Origin Insight;
- level 0 HP;
- Proficiency Bonus +0;
- no Path, Foundation, Method, or sect-trial Dao Sphere yet.

## Glossary

**Background Sphere.** A Sphere granted by a Background before the sect trial. It represents mortal training, dormant exposure, or preparatory practice. It is not the sect-trial Dao Sphere.

**Active Sphere Technique.** A sphere use that spends a cultivation resource, creates a supernatural effect, uses a sphere action, or otherwise relies on the sphere’s full cultivation rules. Level 0 characters cannot use active sphere techniques unless a printed rule explicitly allows it.

**Active Background Sphere.** A Background Sphere that grants its base ability and listed Background Talent at mortal scale before the sect trial. At CL 1, it counts as a known Sphere unless another printed rule says otherwise.

**Dormant Background Sphere.** A Background Sphere that grants recognition, knowledge, signs, and future access but not active sphere techniques until a printed rule supports activation.

**Preparatory Background Sphere.** A Background Sphere that grants literacy, etiquette, vessel knowledge, relationship preparation, or training habits but not a companion, servant, hosted entity, summon, or active sphere action until a printed rule supports activation.

**Mortal Scale.** Passive knowledge, proficiency, recognition, ordinary tool use, mundane preparation, non-resource practice, or non-supernatural training.

**Origin Insight.** A level 0 personal truth, instinct, habit, wound, or way of seeing the world. It remains part of the character after the sect trial.

**Recorded Art.** A fixed named technique learned from a manual, jade slip, journal, mural, inheritance, or similar source. Level 0 characters do not normally learn or use Recorded Arts unless a printed rule explicitly says otherwise.

**Sect-Trial Dao Sphere.** The first sphere revealed or granted by the sect trial. It is separate from a Background Sphere.

---

# 02. Sect Trial and Becoming CL 1

The sect trial is the point where a mortal character becomes a cultivator.

This chapter does not design the trial encounter itself. It explains what changes on the character sheet when the trial is complete.

## What the Sect Trial Does

When the sect trial is complete, the character normally becomes **CL 1**.

The trial does five mechanical things:

1. ends level 0 play;
2. confirms the character’s Path;
3. awakens the character’s sect-trial Dao Sphere;
4. replaces level 0 statistics with CL 1 statistics;
5. turns on the CL 1 rules that the Path, Sphere, and later chapters provide.

The trial is not a breakthrough check. It is the transition from mortal character creation into the cultivation rules.

## The Initiation Pill

At the end of the trial, the sect invests in each accepted disciple by giving them a powerful initiation pill.

This pill floods the disciple with cultivated energy. In that moment, the disciple expresses the Dao they showed during the trial. The energy takes shape through that expression, and the disciple spontaneously awakens one legal player-facing Sphere.

This Sphere is the character’s **sect-trial Dao Sphere**.

The initiation pill is the normal exception to the rule that new Spheres require training. Later Spheres must be learned through training, a feature, a manual, an inheritance, or another printed rule.

## Trial Result

At the end of the trial, record these results:

- **Path.** Choose or confirm Body Refining, Qi Cultivation, or Spirit Awakening.
- **Sect-Trial Dao Sphere.** Record one legal player-facing Sphere based on the Dao the character represented during the trial.
- **Sect-Trial Talent.** Record one talent from the sect-trial Dao Sphere. This talent counts as the character’s CL 1 level talent.
- **CL 1 Sheet Update.** Replace the level 0 statistics with CL 1 statistics.
- **Background Carryover.** Keep the character’s Background, Background proficiencies, Background equipment, Background Sphere, Background talent, and Origin Insight.

A campaign can decide whether the sect-trial Dao Sphere is chosen freely, chosen from trial offers, chosen by the GM from the character’s trial behavior, or fixed by the sect premise. Once the result is recorded, it is a real character feature.

## Choose or Confirm Path

Choose one Path.

| Path | Key Ability | Hit Die | Resource |
|---|---|---:|---|
| Body Refining | Constitution | d12 | Stamina |
| Qi Cultivation | Intelligence or Charisma | d8 | Qi |
| Spirit Awakening | Wisdom | d8 | Resonance |

Qi Cultivation chooses either Intelligence or Charisma as its key ability when the Path is chosen. Once chosen, use that ability for Qi Cultivation features unless another printed rule says otherwise.

A character begins with one starting Path. A character can later add another Path only through the **Multi-Path Cultivation** rules in Chapter 03 or another explicit Source Rule.

## CL 1 Statistics Update

When the character becomes CL 1, update the sheet as follows.

| Statistic | CL 1 Update |
|---|---|
| Character Level | 1 |
| Proficiency Bonus | +2 |
| Hit Dice | Replace level 0 Hit Dice with the Path Hit Die |
| Hit Points | Maximum value of the Path Hit Die + Constitution modifier, minimum 1 |
| Saving Throw Proficiencies | None from the orthodox Paths; another explicit rule can grant one |
| Weapon and Armor Proficiencies | From Backgrounds, Background Spheres, Background talents, Path rules, equipment rules, or other printed features |
| Cultivation Resource | The Path resource turns on using the Path rules |
| Path Features | Gain the CL 1 features listed in the Path chapter |
| Sect-Trial Dao Sphere | Gain the Sphere awakened by the initiation pill |
| Sect-Trial Talent | Gain one talent from the sect-trial Dao Sphere; this counts as the CL 1 level talent |

Do not add level 0 hit points to CL 1 hit points. Level 0 Hit Dice and hit points are replaced by the Path’s CL 1 values.

When Proficiency Bonus becomes +2, existing level 0 proficiencies begin adding +2 to relevant checks. Existing expertise doubles that bonus to +4.

## Sect-Trial Dao Sphere

The sect-trial Dao Sphere is the first full cultivation Sphere awakened by the sect trial.

Record one legal player-facing Sphere. At CL 1, this Sphere counts as a known Sphere and uses the normal Sphere rules for the character’s Realm, Path, talents, costs, actions, and restrictions.

When you gain your sect-trial Dao Sphere, you gain both of the following:

- the Sphere’s base ability;
- one talent from that Sphere.

The talent gained this way counts as your CL 1 level talent. You do not also gain a second level talent at CL 1 unless another rule says you do.

The sect-trial Dao Sphere is separate from a Background Sphere.

If the sect-trial Dao Sphere and an active Background Sphere are the same Sphere, the character knows that Sphere once. Do not count the same Sphere twice or gain an extra Sphere unless another printed rule says otherwise.

If the sect-trial talent would duplicate a Background talent, choose a different legal talent from the sect-trial Dao Sphere if one is available.

## Background Carryover at CL 1

A character keeps all level 0 Background and Origin elements after the trial.

At CL 1:

- Background skill, tool, language, and trade proficiencies remain;
- Background equipment remains unless lost in play;
- Origin Insight remains active;
- an active Background Sphere counts as a known Sphere unless another printed rule says otherwise;
- a Background talent remains usable if its requirements are met;
- the Background Sphere and Background talent do not count against the character’s CL 1 level talent or trained choices;
- dormant or preparatory Background Spheres remain limited until activated by a printed rule.

Background identity should remain visible after the trial. The trial changes the character’s cultivation status; it does not erase the mortal life that produced the character.

## What Does Not Automatically Unlock

Becoming CL 1 does not automatically grant:

- a Foundation;
- a cultivation Method;
- a manual or lineage technique;
- a breakthrough reward;
- a Secret or Forbidden Sphere;
- access to higher-Realm talents;
- full use of dormant or preparatory Background Spheres;
- extra talents beyond those granted by the Background, sect trial, level talent, training rules, or another printed rule.

Those systems are handled by their own chapters or by printed features.

## Quick CL 1 Checklist

After the sect trial, the character sheet should show:

- CL 1;
- Proficiency Bonus +2;
- one Path;
- Path Hit Dice and CL 1 hit points;
- the Path resource;
- Path CL 1 features;
- one sect-trial Dao Sphere;
- one sect-trial talent from that Sphere, counted as the CL 1 level talent;
- Background and Origin Insight retained;
- active Background Sphere interaction resolved;
- Background talent retained if its requirements are met;
- no Foundation, Method, Recorded Art, Secret Sphere, Forbidden Sphere, or higher-Realm talent unless a printed rule grants it.

## Glossary

**CL.** Cultivation Level. CL 1 is the first full cultivator level.

**Initiation Pill.** The powerful pill given by the sect at the end of the trial. It floods the accepted disciple with cultivated energy and awakens the sect-trial Dao Sphere.

**Known Sphere.** A Sphere whose base ability your character has learned.

**Path.** One of the primary cultivation routes: Body Refining, Qi Cultivation, or Spirit Awakening.

**Path Resource.** The resource used by a Path: Stamina for Body Refining, Qi for Qi Cultivation, and Resonance for Spirit Awakening.

**Sect-Trial Dao Sphere.** The first full cultivation Sphere awakened at the end of the sect trial. It counts as a known Sphere at CL 1.

**Sect-Trial Talent.** The talent gained from the sect-trial Dao Sphere. This talent counts as the character’s CL 1 level talent.

**Trial Result.** The final mechanical record of the sect trial: Path, sect-trial Dao Sphere, sect-trial talent, and CL 1 sheet update.

---

# 03. Paths and Shared Path Rules

A **Path** is the main cultivation chassis that carries a character from CL 1 through CL 20. It determines the character's Hit Die, key ability, Cultivation Points, basic training, core progression, and access to a Path-specific Subpath.

The three orthodox Paths are:

- **Body Refining**, which makes the cultivator's body the primary vessel and instrument of power;
- **Qi Cultivation**, which refines internal qi into repeatable martial, technical, elemental, and externalized arts;
- **Spirit Awakening**, which cultivates soul, perception, identity, spiritual pressure, relationships, and conceptual authority.

A Path is not a Background, Origin Insight, Sphere, talent, Foundation, Method, manual, Recorded Art, Forged Technique, item, or Dao. Those systems interact with a Path, but they do not replace it.

This chapter contains the rules shared by all three orthodox Paths. The individual Body Refining, Qi Cultivation, and Spirit Awakening chapters provide their complete CL 1-20 features and Path-specific exceptions.

## Choosing Your Starting Path

Do not choose a Path at level 0.

When you complete the sect trial and become CL 1, choose one starting Path. Record its key ability, Hit Die, Cultivation Point pool, training, skills, and CL 1 features.

Most cultivators follow one Path. A character can later add another Path through the **Multi-Path Cultivation** rules in this chapter. Beginning another Path is a major cultivation decision, not an ordinary training choice.

Qi Cultivation uses Intelligence or Charisma. Choose one of those abilities when you gain the Path. That choice remains your Qi Cultivation key ability unless an explicit Source Rule changes it.

## The Three Orthodox Paths

| Path | Key Ability | Hit Die | Cultivation Points | Armor Training | Weapon Training | Path Identity |
|---|---|---:|---|---|---|---|
| **Body Refining** | Constitution | d12 | Stamina | Light armor, medium armor, shields | Simple and martial weapons | Durability, physical force, bodily transformation, restraint, movement, and embodied martial cultivation |
| **Qi Cultivation** | Intelligence or Charisma | d8 | Qi | Light armor | Simple weapons | Qi circulation, projected techniques, weapon-and-technique cultivation, Fields, Formations, armaments, and supernatural craft |
| **Spirit Awakening** | Wisdom | d8 | Resonance | None | Simple weapons | Spiritual perception, soul authority, exorcism, spirit relations, conceptual martial practice, and Domains |

### Path Skills

When you gain your starting Path at CL 1, choose two skills from its list.

- **Body Refining:** Acrobatics, Athletics, Intimidation, Perception, Survival
- **Qi Cultivation:** Arcana, History, Insight, Investigation, Medicine, Nature, Perception, Persuasion, Religion
- **Spirit Awakening:** Deception, Insight, Investigation, Medicine, Perception, Persuasion, Religion

Adding another Path later does not grant additional skill proficiencies unless an explicit rule says otherwise.

## Shared Cultivation Mathematics

Each Path has its own key ability. Use the key ability of the Path that powers the feature.

**Cultivation Save DC**

`8 + Proficiency Bonus + Path key ability modifier`

**Cultivation Attack Modifier**

`Proficiency Bonus + Path key ability modifier`

**Cultivation Check**

`d20 + Proficiency Bonus + Path key ability modifier`

A character with more than one Path calculates these values separately for each Path.

A feature may print a different ability, attack modifier, save DC, or check. Use the feature's printed rule for that feature.

## Saving Throws

The orthodox Paths grant **no saving throw proficiencies**.

Each Path instead grants cultivated defensive features. These defenses require their printed trigger, action, cost, and limit.

A feature that adds Proficiency Bonus to a failed saving throw is not saving throw proficiency. It does not stack with proficiency or another feature that adds Proficiency Bonus to the same saving throw unless an explicit rule says that it does.

## Hit Dice and Hit Points

A single-Path character uses the Hit Die and Hit Point progression of that Path.

| Path | Hit Points at CL 1 | Hit Points at Later CLs |
|---|---|---|
| **Body Refining** | `12 + Constitution modifier` | `1d12 or 7 + Constitution modifier` per CL after CL 1 |
| **Qi Cultivation** | `8 + Constitution modifier` | `1d8 or 5 + Constitution modifier` per CL after CL 1 |
| **Spirit Awakening** | `8 + Constitution modifier` | `1d8 or 5 + Constitution modifier` per CL after CL 1 |

Minimum Hit Points gained at a CL are 1 unless an explicit rule says otherwise.

Multi-Path characters use the rules in **Multi-Path Hit Dice and Hit Points** below.

## Cultivation Points

**Cultivation Points**, abbreviated **CP**, are the spendable reserves used by cultivation features.

Each Path names its own CP pool:

- Body Refining uses **Stamina**.
- Qi Cultivation uses **Qi**.
- Spirit Awakening uses **Resonance**.

When a Path feature says to spend CP, spend from that Path's pool. A non-Path feature must identify its **Powering Path** or explicitly allow a choice of pools.

### Maximum Cultivation Points

| Path | Maximum CP |
|---|---|
| **Body Refining** | `Body Refining CL x Constitution modifier` |
| **Qi Cultivation** | `Qi Cultivation CL x chosen key ability modifier`, minimum `2 x Qi Cultivation CL` |
| **Spirit Awakening** | `Spirit Awakening CL x Wisdom modifier`, minimum `2 x Spirit Awakening CL` |

A CP pool cannot have a negative maximum. Body Refining has no additional minimum floor unless an explicit rule creates one.

A cultivation Method is the ordinary permanent way to modify maximum CP. A Foundation, Insight, item, injury, condition, or other source changes maximum CP only when its own rule expressly says so.

### Spending Cultivation Points

You spend CP when a rule tells you to do so.

Unless the Source Rule says otherwise:

- pay the cost when you activate the feature;
- you cannot activate the feature without enough CP;
- current CP cannot exceed maximum CP;
- if a feature permits spending "up to" a value, choose the amount as part of activation;
- a failed attack roll or successful saving throw does not refund the cost;
- an invalid declared target prevents the activation, and the Source Rule determines whether a cost was already committed.

### Reaching 0 Cultivation Points

When one of your CP pools is reduced from above 0 to exactly 0, gain 1 level of Exhaustion.

If you later regain points in that pool and reduce it to 0 again, you can gain another level of Exhaustion. Different CP pools are tracked separately for this purpose.

Beginning a scene at 0 CP does not trigger additional Exhaustion by itself.

### Recovery by Path

| Path | Short Rest | Long Rest | Full Cultivation Session |
|---|---|---|---|
| **Body Refining** | Recover half maximum Stamina, rounded down; usable twice between Long Rests | Recover all missing Stamina | Recover all missing Stamina; once per Long Rest |
| **Qi Cultivation** | Recover Qi equal to Qi Cultivation CL; once per Long Rest | Recover half maximum Qi, rounded down | Recover all missing Qi; once per Long Rest |
| **Spirit Awakening** | Recover Resonance equal to Spirit Awakening CL; once per Long Rest | Recover half maximum Resonance, rounded down | Recover all missing Resonance; once per Long Rest |

A **Full Cultivation Session** takes 2 uninterrupted hours and requires a reasonably safe environment and a practice appropriate to the Path, Method, and current condition.

A multi-Path cultivator can restore all active Path pools during one Full Cultivation Session if the session includes an appropriate practice for each Path. A Source Rule can prevent or modify recovery only to the extent it expressly states.

## Powering Path Records

A character with one Path normally has no ambiguity about which pool powers a feature.

A character with more than one Path must record a **Powering Path** for every Sphere ability, talent, Cultivation Insight, Recorded Art, Forged Technique, item property, or other feature that costs generic CP without naming a pool.

Use these rules:

1. A Path feature is always powered by its own Path.
2. A feature that names Stamina, Qi, or Resonance uses that pool.
3. A feature that names a required Path uses that Path's pool.
4. If more than one of your Paths can legally power the feature, choose one when you learn, create, bind, or gain the feature and record that choice.
5. You cannot split one cost between pools unless the feature expressly permits it.
6. Changing a recorded Powering Path requires retraining, reconstruction, a Method change, or another explicit rule.
7. A feature that expressly says "any CP" or "any Path resource" follows its own rule instead.

A Powering Path record does not grant access to a feature. It only resolves which legal pool pays its cost.

## Activations, Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, spirit expression, or other Source Rule. The activation includes every attack, target, pulse, echo, projectile, rider, and repeated output that the declared use expressly creates.

A **cultivation technique** is a supernatural procedure authorized by a Source Rule. It is not automatically a spell, weapon attack, condition, companion action, or ordinary ability check. The Source Rule states which resolution procedure it uses.

A cultivation effect requires Concentration only when its Source Rule says so. A creature normally has one Concentration limit, regardless of how many Paths, Soul Fragments, Companions, Assets, manifestations, or remote origins it possesses.

An independent creature may have its own Concentration only if its rules give it its own turn, actions, and Concentration capacity.

## Effective CL and Source CL

**Effective CL** determines which features you can use and how those features scale.

Your normal effective CL is your character's CL. Realm Suppression or another explicit rule can lower the effective CL used by a Path or feature.

**Source CL** measures the authority of an effect when it collides with another cultivation effect, suppression, reconstruction, permanent harm, an Anchor, a Domain, or another high-authority rule.

Unless a Source Rule states otherwise, a feature's Source CL equals the effective CL used to activate it.

Source CL does not replace:

- an attack roll;
- a saving throw;
- a Cultivation Check;
- a CP cost;
- an action or Reaction;
- an Anchor or Asset profile;
- a repeated save;
- a recovery procedure;
- a reconstruction requirement.

Use Source CL only when a rule calls for an authority comparison or when the universal authority procedures expressly require it.

## Shared Path Progression

The three orthodox Paths use the following shared progression events.

| CL | Shared Event |
|---:|---|
| **1** | Gain starting Path chassis and CL 1 Path features; gain the sect-trial Dao Sphere and its talent under Chapter 02 |
| **3** | Choose one legal Subpath for each Path you possess |
| **4** | Ability Score Improvement or Cultivation Insight |
| **6** | Subpath feature |
| **8** | Ability Score Improvement or Cultivation Insight |
| **10** | Subpath feature |
| **12** | Ability Score Improvement or Cultivation Insight |
| **14** | Subpath feature |
| **16** | Ability Score Improvement or Cultivation Insight |
| **18** | Subpath feature |
| **19** | Ability Score Improvement or Cultivation Insight |

The individual Path chapters provide all other Path features.

### Level Talents and Training

A character gains one level talent at each CL under the Spheres and Talents rules. At CL 1, the sect-trial talent counts as that level talent.

A multi-Path character does not gain extra level talents, training choices, Background benefits, or sect-trial benefits merely for possessing additional Paths.

Whenever a character legally learns a new Sphere, they also gain the normal free first talent from that Sphere. The Background Sphere and Background Talent remain separate free benefits under the Background rules.

## Ability Score Improvements and Cultivation Insights

At CL 4, CL 8, CL 12, CL 16, and CL 19, choose one of the following:

- **Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by the character's current Realm.
- **Cultivation Insight:** Choose one entry from the **Central Cultivation Insights** catalogue for which you meet every prerequisite. Gain its printed cultivation benefit and increase one ability score listed in its **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained from a manual, tribulation, relic, sect office, spirit pact, bloodline awakening, inheritance, story reward, or another non-level source does not grant the level-selection ability increase unless that source expressly says so.

These are character-level choices. A multi-Path character makes one choice at each listed CL, not one choice per Path.

## Subpaths and Access

At CL3, choose one legal Subpath for each Path you possess. You gain that Subpath's later features at CL6, CL10, CL14, and CL18. **Subpath** is the universal term; individual Paths use names such as School, Scripture, Method, Inheritance, Tradition, Lineage, or Law.

Chapter 09 provides the complete player rules for Open, Restricted, Rare, Forbidden, Secret, Inherited, and Variant access; delayed selection; legal access sources; one Subpath per active Path; parent and Variant replacement; Source CL; multi-Path progression; and Realm Suppression.

A Subpath does not grant a thematically similar Sphere unless its rule expressly says that it does.

## Paths and Other Character Systems

### Backgrounds and Origin Insights

Choosing or adding a Path does not erase the character's Background, Background equipment, Background Sphere, Background Talent, proficiencies, or Origin Insight.

A Path explains how the character cultivates. The Background explains what the character brought into cultivation.

### Spheres and Talents

A Path supplies cultivation math, resources, and permissions. A Sphere supplies a field of expression. A talent modifies or expands a Sphere.

A Path does not automatically grant a Sphere because its Subpath uses similar imagery. A sword cultivator does not automatically know the Sword Sphere; a Dreamweaver does not automatically know Dreams; a blood-based Body Refiner does not automatically know Blood.

### Foundations

A Foundation is the character's deep cultivation architecture. It is not a Path and is not chosen automatically at CL 1.

A Foundation can interact with multiple Paths when its own rule permits that interaction. Realm Suppression does not automatically remove a Foundation's passive bodily quality, identity, or existing damage.

### Methods

A Method is the character's primary circulation, refinement, stabilization, or cultivation procedure.

A multi-Path cultivator must record whether a Method applies to one Path, several Paths, or an integrated route. A Method modifies only the pools and features its own rule identifies.

### Manuals, Recorded Arts, and Forged Techniques

A manual can teach a Path feature only when its rule expressly grants or reproduces that feature. Recorded Arts remain fixed expressions and do not grant their component Spheres or talents.

A Forged Technique must identify its legal component expressions and the Path or Path resources that power it.

### Items

An item does not grant a Path, Subpath, Sphere, talent, Method, Foundation, or Recorded Art merely because its description resembles one. It grants only the authority printed in its item rule.

## Path Identity Boundaries

The Paths are not interchangeable power labels.

### Body Refining

Body Refining normally acts through the cultivator's own body, a natural bodily weapon, an integrated weapon, bodily material expressly separated by a Source Rule, or a space the body physically occupies, touches, strikes, crosses, or directly affects.

It does not automatically grant remote technique origin, free-standing Fields, independent projected creatures, detached acting body parts, or control of separated bodily material. Every external projection requires a printed exception.

### Qi Cultivation

Qi Cultivation can externalize power through printed techniques, Domain Armaments, weapons, armor, items, Fields, Formations, talismans, arrays, remote origins, and other legal sources.

Externalized imagery does not bypass the printed range, line of effect, action economy, Source CL, Anchor, or target rules.

### Spirit Awakening

Spirit Awakening cultivates soul, identity, spiritual pressure, perception, exorcism, spirit relationships, and conceptual authority.

It does not automatically grant a full Companion, ownership of a spirit, possession authority, another spirit's Spheres, extra actions, an independent resource pool, or permission to destroy or rewrite a soul. Those permissions require explicit Source Rules.

## Multi-Path Cultivation

Cultivating more than one Path is legal, powerful, and extremely demanding.

A multi-Path character has one character CL. Every Path the character possesses advances at that CL and grants its core features for that CL. The increased AP requirement represents the difficulty of advancing several complete cultivation systems together.

### Standard Multi-Path Combinations

| Path Combination | AP Requirement Multiplier |
|---|---:|
| One orthodox Path | x1 |
| Two orthodox Paths | x3 |
| Chakra plus one orthodox Path | x4 |
| All three orthodox Paths | x5 |

The multiplier applies to the AP required for the next CL in Chapter 17. It does not multiply AP awards.

Other Path combinations require an explicit Source Rule or campaign option.

### Beginning an Additional Path

To add another Path, you must have:

- a legal teacher, manual, inheritance, bloodline awakening, spirit event, bodily transformation, cultivation accident, or other access source;
- any prerequisites imposed by that source;
- enough AP for the next CL after applying the multiplier of the resulting Path combination.

Declare the additional Path before attempting the breakthrough. On a successful breakthrough:

1. your character gains the new CL;
2. the new Path immediately advances to that CL;
3. gain the new Path's core features through that CL;
4. make every mandatory Path-specific choice through that CL, such as a Qi key ability, Soul Anchor, Golden Core Form, Core Tempering Expression, Domain Armament, or similar choice;
5. if the character is CL 3 or higher, choose one legal Subpath for the new Path;
6. gain the new Path's armor and weapon training;
7. gain no additional Path skills, Background benefits, sect-trial benefits, level talents, trained choices, Ability Score Improvements, or Cultivation Insights unless an explicit rule grants them.

You cannot add a Path after reaching maximum standard CL unless an explicit post-CL-20 rule permits it.

### Multi-Path Features

A multi-Path character gains the complete core progression and one legal Subpath progression for each possessed Path.

Distinct Path features coexist. Identically named universal benefits do not stack unless an explicit rule says otherwise.

If two features could add Proficiency Bonus to the same saving throw, use only one unless a rule expressly permits stacking.

Extra Attack and other features that use the same standard nonstacking rule do not stack unless a Source Rule says that they do.

### Multi-Path Hit Dice and Hit Points

Use one Hit Die per character CL: the largest Hit Die among your active Paths.

Among the three orthodox Paths, Body Refining supplies the largest Hit Die. If a d8 character adds Body Refining, increase maximum Hit Points by:

`4 + 2 x (current CL - 1)`

This replaces the difference between the fixed d8 and d12 values for existing CLs. Do not reroll previous Hit Dice.

Adding Qi Cultivation or Spirit Awakening to a character who already uses a d8 or d12 Hit Die does not change existing Hit Points.

### Multi-Path Cultivation Points

Track each Path's CP pool separately. Calculate each maximum using the full character CL and that Path's key ability.

A cost is paid from the feature's recorded Powering Path. You cannot move points between pools unless an explicit rule permits conversion.

Each pool uses its own Short Rest and Long Rest recovery limit. One Full Cultivation Session can restore all active pools if it includes a valid practice for each Path.

Reaching 0 in one pool does not reduce another pool, but it can still cause Exhaustion under the normal 0-CP rule.

### Multi-Path Advancement Benefits

Character-level benefits are gained once, not once per Path:

- one Proficiency Bonus;
- one Hit Die per CL;
- one level talent per CL;
- up to three trained choices per CL;
- one Ability Score Improvement or Cultivation Insight at CL 4, 8, 12, 16, and 19;
- one Background package;
- one Origin Insight;
- one sect-trial Dao Sphere and sect-trial talent unless another rule grants more.

Path-level benefits are gained for every possessed Path:

- each Path's core features;
- each Path's CP pool;
- each Path's mandatory selections;
- one Subpath progression for each Path;
- armor and weapon training granted by each Path.

### Multi-Path Realm Suppression

Ordinary Realm Suppression applies one effective CL to all of the character's Paths.

A Source Rule can suppress only one Path, one pool, one Subpath, one transformation, one Soul Anchor expression, one Domain, or another narrower cultivation structure when it expressly says so.

Suppressing one Path does not transfer its CP to another Path or allow another Path to activate the suppressed feature.

## Realm Suppression

A cultivator can voluntarily suppress their Realm under the Realm Suppression rules.

While suppressed:

- use the suppressed effective CL;
- use the Proficiency Bonus for the suppressed CL where required;
- do not activate or benefit from features, higher-Realm options, talents, Insights, Recorded Arts, Method expressions, Foundation expressions, or item powers above the suppressed CL;
- use lower-CL scaling where the source provides it.

Realm Suppression does not recalculate:

- maximum Hit Points;
- Hit Dice;
- maximum CP;
- permanent anatomy;
- identity or ancestry;
- Soul Anchors or Bonds;
- Foundations or existing Foundation damage;
- injuries, scars, debts, contracts, or other persistent consequences.

An unavailable maintained effect ends or becomes dormant according to its Source Rule. Suppression does not refund costs or retroactively reduce the authority of an already resolved consequence.

## Rule Resolution Order

Resolve Path rules in this order:

1. The explicit Source Rule creating or modifying the effect.
2. A dependency expressly named by that Source Rule.
3. The relevant Path core.
4. The relevant Path player procedure or Subpath procedure addendum.
5. This shared Path chapter and other universal cultivation rules.
6. The underlying fifth-edition procedure where Tianxia has not replaced it.

Description, reputation, analogy, conventional spell comparison, and thematic similarity never grant unprinted authority.

## CL 1 Path Checklist

When the sect trial makes a character CL 1, record:

- starting Path;
- Path key ability;
- Hit Die and maximum Hit Points;
- Path CP pool and maximum;
- armor and weapon training;
- two Path skills;
- CL 1 Path features;
- sect-trial Dao Sphere and talent;
- continuing Background benefits;
- Origin Insight.

## Shared Path Glossary

**Activation.** One declared use of a Source Rule, including every attack, target, pulse, echo, projectile, rider, and repeated output expressly created by that use.

**Cultivation Attack Modifier.** `Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Check.** `d20 + Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Points (CP).** The spendable resource used by cultivation features: Stamina, Qi, Resonance, or another explicitly defined Path resource.

**Cultivation Save DC.** `8 + Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Effective CL.** The CL currently used for access and scaling after Realm Suppression or another explicit modifier.

**Multi-Path Cultivator.** A character who legally possesses more than one complete Path progression.

**Path.** A character's main CL 1-20 cultivation chassis.

**Powering Path.** The recorded Path whose resource and cultivation mathematics power a feature when more than one Path could legally do so.

**Source CL.** The authority level of a cultivation source, normally equal to the effective CL used to activate it unless a rule says otherwise.


**Access Class.** The universal availability classification of a Subpath: Open, Restricted, Rare, Forbidden, or Secret.

**Inherited.** A Subpath access tag indicating transmission through ancestry, reincarnation, awakening, mutation, relic or spirit integration, or another nonordinary source.

**Parent Subpath.** The base progression named by a Variant.

**Variant.** An alternate progression that occupies its parent's Subpath slot and replaces the named parent features one for one.

**Subpath.** The universal term for a Path-specific progression gained at CL 3, with later features at CL 6, 10, 14, and 18.

---

# 04. Body Refining

Body Refining cultivates the body itself as vessel, weapon, defense, and foundation for transcendence. Constitution governs its Path features, Stamina fuels its exertions, and its strongest expressions remain embodied unless a Source Rule explicitly permits projection.

## Activation, Body Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, or other Source Rule, including every attack, target, repeated strike, movement, and rider that the use expressly creates. Once-per-activation limits apply across the entire use.

A **Body Refining technique** is a supernatural procedure authorized by a Source Rule and expressed through the cultivated body, a natural bodily weapon, an integrated weapon, or another printed bodily medium. It is not automatically an ordinary weapon attack, spell, maneuver, or ability check. Its Source Rule states which resolution procedure it uses.

A Body Refining feature requires Concentration only when its Source Rule says so. Bodily effort, pain, transformation, maintaining a stance, or spending Stamina does not create Concentration by implication.

## Effective CL and Source CL

Your normal effective CL is your Body Refining CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature. Source CL determines authority and interaction; it does not replace attack rolls, saving throws, Stamina costs, Asset profiles, injury procedures, or recovery procedures printed by the Source Rule.

## Body Refining Origin and Projection Boundary

Body Refining normally acts through your own body, a natural bodily weapon, an integrated weapon, bodily material expressly separated by a Source Rule, or a space your body physically occupies, touches, strikes, crosses, or directly affects.

Body Refining does not automatically grant remote technique origin, independent projected creatures, detached acting body parts, free-standing Fields, ranged energy projection, or control of blood, bone, hair, skin, organs, or other bodily material after separation. A Subpath, Insight, Sphere, Method, Foundation, item, Recorded Art, Forged Technique, or other explicit Source Rule may grant a defined exception.

A printed breath, roar, shockwave, thrown bodily weapon, blood spray, bone projection, hair technique, afterimage, or similar effect functions exactly as printed. Its imagery does not grant additional range, targets, persistence, action economy, or external control.

---

## Body Refining at a Glance

| Rule | Body Refining |
|---|---|
| **Key Ability** | Constitution |
| **Hit Die** | d12 |
| **Cultivation Points** | Stamina |
| **Primary Roles** | Durable martial combatant, grappler, frontline protector, mobile physical threat |
| **Saving-Throw Proficiencies** | None |
| **Armor Training** | Light armor, medium armor, shields |
| **Weapon Training** | Simple weapons, martial weapons |
| **Skills** | Choose two: Acrobatics, Athletics, Intimidation, Perception, Survival |

### Hit Points

**Hit Points at CL1:** 12 + your Constitution modifier

**Hit Points at later CLs:** 1d12 - or 7 - plus your Constitution modifier for each Body Refining level after CL1

### Cultivation Mathematics

**Cultivation Save DC:** `8 + Proficiency Bonus + Constitution modifier`

**Cultivation Attack Modifier:** `Proficiency Bonus + Constitution modifier`

**Cultivation Check:** `d20 + Proficiency Bonus + Constitution modifier`

---

## Stamina

A Body Refiner's Cultivation Points are called **Stamina**.

Stamina represents the body's ability to exert cultivated force through physical conditioning, pain tolerance, reinforced flesh, hardened bone, refined blood, controlled breathing, meridian circulation, and supernatural bodily exertion.

### Maximum Stamina

Your maximum Stamina equals:

`Body Refining CL x Constitution modifier`

Only a Source Rule that explicitly modifies maximum Cultivation Points changes this amount.

### Spending Stamina

You spend Stamina when a feature says that you do.

Unless a feature states otherwise:

- Stamina is spent when the feature is activated.
- You cannot activate a feature without enough Stamina to pay its cost.
- Current Stamina cannot exceed maximum Stamina.
- A feature that fails because its declared target was invalid does not resolve.
- Whether its cost is spent follows the feature's printed cost timing.

### Reaching 0 Stamina

When your current Stamina is reduced from a value above 0 to exactly 0, you gain 1 level of Exhaustion.

If you later regain Stamina and are reduced to 0 again, this consequence can occur again.

Beginning a scene at 0 Stamina does not trigger another level of Exhaustion by itself.

### Recovering Stamina

#### Short Rest

During a short rest, you may recover half your maximum Stamina, rounded down.

You can use this short-rest recovery twice between long rests.

#### Long Rest

Completing a long rest restores all missing Stamina.

#### Full Cultivation Session

A full Cultivation Session requires 2 uninterrupted hours.

Completing one restores all missing Stamina. You can receive this full restoration from one Cultivation Session per long rest unless another Source Rule states otherwise.

---

## Body Refining Attacks

A **Body Refining attack** is either:

- An unarmed strike; or
- A weapon attack that a Path, Subpath, Sphere, Recorded Art, Forged Technique, Foundation, Method, or item feature explicitly integrates into your Body Refining cultivation.

A weapon does not become a Body Refining weapon merely because you are proficient with it.

When a rule refers to an **integrated weapon**, it means a weapon currently benefiting from an explicit Body Refining integration feature.

---

## Body Refining Progression

| CL | Features |
|---:|---|
| **1** | Tempered Response, Unarmored Defense, Iron Fist, Stomping Step |
| **2** | Stamina Guard |
| **3** | Body Refining Subpath |
| **4** | Ability Score Improvement or Cultivation Insight |
| **5** | Extra Attack, Body Tempering, Refined Iron Fist |
| **6** | Subpath Feature |
| **7** | Meridian Reinforcement |
| **8** | Ability Score Improvement or Cultivation Insight |
| **9** | Iron Voice |
| **10** | Core Tempering Expression, Subpath Feature |
| **11** | Extra Attack Improvement |
| **12** | Ability Score Improvement or Cultivation Insight |
| **13** | Indomitable Body |
| **14** | Subpath Feature |
| **15** | Blood Pump |
| **16** | Ability Score Improvement or Cultivation Insight |
| **17** | Extra Attack Improvement, Heavenly Fist, Perfected Core Tempering |
| **18** | Subpath Feature |
| **19** | Ability Score Improvement or Cultivation Insight |
| **20** | Immortal Body, Second Core Tempering Expression |

---

## Core Path Features

### CL1 - Tempered Response

Body Refiners do not receive saving-throw proficiencies from their Path. Instead, they cultivate an active physical response against danger.

Choose one Defensive Discipline.

#### Rooted Frame

Your chosen saving throw is Strength.

#### Flowing Frame

Your chosen saving throw is Dexterity.

#### Enduring Frame

Your chosen saving throw is Constitution.

When you fail a saving throw using your chosen ability, you may spend 1 Stamina to add your Proficiency Bonus to the result, potentially turning the failure into a success.

- No action is required.
- You may use it once per round.
- You may use it after learning that the saving throw failed.
- You may use it only once on the same saving throw.
- This bonus is not saving-throw proficiency.
- It does not stack with saving-throw proficiency from another source.
- It cannot modify death saving throws, breakthrough checks, training checks, or another roll that is not a saving throw.

You gain a second Defensive Discipline through Indomitable Body at CL13.

### CL1 - Unarmored Defense

While you are not wearing armor, your Armor Class equals:

`10 + Constitution modifier + Proficiency Bonus`

You may use a shield and retain this Armor Class calculation.

You choose whether to use Unarmored Defense or another available AC calculation. You cannot combine multiple base AC calculations.

### CL1 - Iron Fist

Your body is a cultivated weapon.

Your unarmed strikes deal:

`1d8 + Strength or Constitution modifier`

Choose Strength or Constitution separately for each attack. You may use the chosen ability for both the attack roll and damage roll.

Your unarmed strike may deal Bludgeoning, Piercing, or Slashing damage. Choose the damage type when you make the attack.

For Tianxia features, an Iron Fist attack is both an unarmed strike and a Body Refining melee attack. It does not become a held weapon or an unattended object.

### CL1 - Stomping Step

**Bonus Action**

Take either the Dash action or Disengage action.

Stomping Step represents explosive footwork, controlled bodily release, tendon refinement, practiced breathing, and the ability to place the body exactly where its force is required.

It does not require Stamina.

### CL2 - Stamina Guard

**Reaction**

**Trigger:** Damage is first applied to you.  
**Cost:** Up to your Proficiency Bonus in Stamina

After the damage amount is determined but before your Hit Points are reduced, spend up to your Proficiency Bonus in Stamina.

Reduce the triggering damage by:

`1d10 per Stamina spent`

Roll all dice and total the reduction.

#### Damage Procedure

1. Determine the attack or effect's damage.
2. Apply Immunity, Resistance, Vulnerability, and other modifiers that resolve before flat damage reduction.
3. Activate Stamina Guard.
4. Subtract the Stamina Guard result.
5. Reduce your Hit Points by any remaining damage.

If the damage contains multiple damage types, subtract the reduction from the total damage. You choose which damage types are reduced first when that distinction matters.

If Stamina Guard reduces the damage to 0:

- A rider requiring the target to **take damage** does not occur.
- A rider requiring only that the attack **hit** still occurs.
- A condition imposed regardless of damage still occurs.
- The triggering attack or effect is not treated as having missed.

Stamina Guard cannot reduce maximum-Hit-Point loss, Cultivation Point loss, a cost willingly paid, damage that explicitly cannot be reduced or prevented, or a consequence that is not expressed as damage.

### CL3 - Body Refining Subpath

Choose one Body Refining Subpath for which you have legal access. Your Subpath represents the school, scripture, inheritance, bodily transformation, martial focus, or forbidden method through which your cultivated body develops its defining expression.

You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Classification | Meaning |
|---|---|
| **Open School** | Commonly teachable or institutionally available. Open access does not imply low power. |
| **Restricted Scripture** | Controlled military, medical, sect, weapon, technical, political, inherited, or hazardous instruction. |
| **Rare Inheritance** | Uncommon bloodline, transformed anatomy, destiny, treasure, vessel, species, or singular transmission. |
| **Forbidden Method** | A bodily cultivation method carrying a prohibited, condemned, predatory, corruptive, or physically catastrophic price. Forbidden does not automatically mean Daemonic. |

A campaign may alter access requirements without changing a Subpath's mechanics. A Subpath does not automatically grant a Sphere or Sphere talent unless its rules explicitly state otherwise.

### CL4, CL8, CL12, CL16, and CL19 - Ability Score Improvement or Cultivation Insight

At each listed CL, choose one of the following:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight's **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, sect instruction, bloodline awakening, experimentation, bodily transformation, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise. Background ability-score increases and Origin Insights are separate character-creation benefits and do not activate this increase.

Use the current **Tianxia Central Cultivation Insights** catalogue as the rules authority. Path, Sphere, and Subpath access tags are prerequisites only when the Insight expressly prints them. Advisory affinity or recommendation tags never grant access.

If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

### CL5 - Extra Attack

When you take the Attack action, you may make two attacks instead of one.

This increases to three attacks at CL11 and four attacks at CL17.

An attack granted outside the ordinary attacks of your Attack action cannot itself trigger another feature that grants an additional attack unless that feature explicitly overrides this rule.

### CL5 - Body Tempering

Your body has passed beyond ordinary mortal frailty.

You gain Resistance to nonmagical Bludgeoning, Piercing, and Slashing damage.

This Resistance applies to qualifying damage from mundane weapon attacks, falling, collisions, nonmagical traps, rubble, cave-ins, ordinary machinery, and nonmagical environmental hazards.

An attack or hazard is cultivation-powered rather than mundane when its damage is created or empowered by a Path feature, Subpath feature, Sphere talent, Recorded Art, Forged Technique, Immortal Art, Foundation feature, Method feature, supernatural item power, or another rule explicitly identifying it as magical or cultivation-powered.

Body Tempering does not grant Resistance against cultivation-powered physical damage unless another feature states otherwise.

In addition:

- You have Advantage on saving throws against extreme heat, extreme cold, high altitude, forced marches, starvation, dehydration, and suffocation.
- You can hold your breath for ten times the normal duration.
- Ordinary caltrops, thorns, splinters, and similarly minor environmental hazards cannot damage you unless they are supernatural or part of an active attack or trap.

### CL5 - Refined Iron Fist

Your unarmed strikes count as magical and cultivation-powered for the purpose of overcoming Resistance and Immunity.

A weapon integrated into your Body Refining cultivation also gains this property while you wield it.

This feature does not cause a mundane attack made by another creature to bypass your Body Tempering.

### CL7 - Meridian Reinforcement

Your meridians, organs, blood, and nervous system resist contamination and physical collapse.

You gain Advantage on saving throws against the Poisoned condition, disease, Exhaustion caused by physical exertion or environmental exposure, effects that obstruct breathing, and effects that directly disrupt your bodily meridians.

At the end of your turn, if you are Poisoned or affected by a disease with a printed saving throw DC, you may spend 1 Stamina to repeat the original saving throw against the original DC.

- No action is required.
- You may make this additional saving throw once per round.
- On a success, the Poisoned condition or disease ends if the original effect would end on a successful repeated save.
- If the disease normally requires multiple successful saves, this success counts as one such success.

Meridian Reinforcement cannot remove or suppress Exhaustion gained from reaching 0 Cultivation Points, Hidden Injuries, Foundation damage, Tribulation scars, curses, possession, permanent corruption, or a condition whose Source Rule states that ordinary saves cannot remove it.

### CL9 - Iron Voice

**Bonus Action**

**Range:** 30 feet  
**Target:** One creature that can hear you  
**Cost:** 1 Stamina  
**Saving Throw:** Constitution

On a failed save, the creature is Frightened of you until the end of your next turn. On a successful save, it suffers no effect.

A creature immune to the Frightened condition automatically succeeds.

Iron Voice is blocked by total silence, an effect preventing the target from hearing, total cover that also prevents sound from passing, or a feature explicitly suppressing cultivation pressure or bodily sound.

Iron Voice does not require shared language.

### CL10 - Core Tempering Expression

When you enter Core Formation Realm, your accumulated bodily refinement settles into a stable internal expression.

Choose one Core Tempering Expression. Your choice is permanent until you complete a later Realm breakthrough. When you successfully enter Nascent Soul Realm at CL15, you may replace your chosen expression with another before using any CL15 feature.

At CL17, your chosen expression becomes Perfected.

At CL20, choose a second expression. Both expressions function simultaneously, and both use their Perfected benefits.

#### Golden Bell Circulation

**Bonus Action**  
**Cost:** 3 Stamina  
**Duration:** 1 minute

For the duration:

- Gain +2 AC.
- You have Advantage on checks and saving throws against being pushed, pulled, or knocked Prone.
- Once per round, when Stamina Guard reduces a damage packet to 0, gain Temporary Hit Points equal to your Proficiency Bonus.

The effect ends early if you become Unconscious. Activating Golden Bell Circulation again replaces and refreshes its duration.

##### Perfected Golden Bell - CL17

While Golden Bell Circulation is active:

- Stamina Guard uses d12s instead of d10s.
- Your Temporary Hit Points from Golden Bell equal twice your Proficiency Bonus.
- You cannot be moved against your will by a creature whose CL is lower than yours unless its feature explicitly ignores bodily anchoring.

A creature of equal or higher CL resolves forced movement normally.

#### Blood-Furnace Circulation

Once per turn, immediately after you spend one or more Stamina on a feature that successfully resolves, regain Hit Points equal to your Proficiency Bonus.

If you are at your maximum Hit Points, gain Temporary Hit Points equal to your Proficiency Bonus instead.

Blood-Furnace Circulation does not function while you are at 0 Hit Points, cannot be triggered by refunded Stamina or an invalid activation, and functions no more than once per turn.

##### Perfected Blood Furnace - CL17

The Hit Points or Temporary Hit Points gained become `2 x Proficiency Bonus`.

When this feature restores Hit Points, you may also end one ongoing Bleeding state affecting you if that state has a Source CL no higher than your CL.

#### Mountain-Rending Pulse

Once per turn, immediately after you spend one or more Stamina on a feature that successfully resolves, empower your next Body Refining melee attack before the end of your next turn.

On a hit:

- Deal an additional `1d8` Force damage.
- Choose either to push the target 5 feet or prevent it from taking Reactions until the start of its next turn.

If the empowered attack misses, the empowerment remains until its duration expires.

You cannot hold more than one Mountain-Rending empowerment at a time. Gaining another replaces the previous one.

##### Perfected Mountain-Rending Pulse - CL17

The additional damage becomes `2d8` Force damage.

On a hit, choose one:

- Push the target 10 feet.
- Knock the target Prone if it fails a Strength saving throw.
- Prevent it from taking Reactions until the start of its next turn.
- Deal double damage to an unattended object, temporary barrier, vehicle, structure, or Formation Anchor.

### CL11 - Extra Attack Improvement

When you take the Attack action, you may make three attacks instead of two.

### CL13 - Indomitable Body

Choose a second Defensive Discipline from Tempered Response.

In addition, when you fail a saving throw, you may spend 3 Stamina to reroll it.

- No action is required.
- You may use Indomitable Body once per round.
- You must use the new result.
- A die cannot be rerolled more than once.
- You may use Indomitable Body after Tempered Response failed to turn the original roll into a success.
- If you used Tempered Response on the original roll, you cannot use it again on the reroll.
- Indomitable Body cannot reroll a death saving throw, breakthrough check, training check, or another roll that is not a saving throw.

### CL15 - Blood Pump

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 6 Stamina  
**Limit:** Once per scene  
**Action:** None

You are reduced to 1 Hit Point instead.

Blood Pump resolves after all damage reduction has been applied.

Blood Pump cannot prevent instant death, total bodily destruction, an effect explicitly stating that reaching 0 Hit Points cannot be prevented, unavoidable damage from a feature that prohibits zero-Hit-Point substitution, death caused by a non-damage effect, or maximum-Hit-Point reduction that leaves your maximum at 0.

Only one feature that replaces or prevents the same reduction to 0 Hit Points can resolve. If several are available, choose one.

### CL17 - Extra Attack Improvement

When you take the Attack action, you may make four attacks instead of three.

### CL17 - Heavenly Fist

Your unarmed strikes and integrated weapons:

- Count as magical.
- Count as cultivation-powered.
- Count as adamantine.
- May deal Force damage instead of their normal damage type.
- Ignore ordinary Resistance to damage from nonmagical weapons.
- Cannot be broken or rendered unusable by a mundane disarm, rust, dulling, or weapon-breaking effect while you wield them.

Against an unattended object, vehicle, structure, temporary barrier, terrain section, or Formation Anchor whose Source CL is no higher than yours:

- Your Body Refining attacks deal double damage.
- Ignore Resistance to Bludgeoning, Piercing, Slashing, and Force damage.
- Treat its Damage Threshold as 0.

Against a target with a higher Source CL, resolve its Resistance and Damage Threshold normally.

Heavenly Fist does not automatically bypass Immunity, permanent artifact properties, Immortal protections, Void protections, or a Source Rule explicitly stating that physical force cannot damage the target.

### CL17 - Perfected Core Tempering

Your chosen Core Tempering Expression gains its Perfected benefits.

### CL20 - Immortal Body

Your physical vessel no longer obeys ordinary mortal limitations.

#### Immortal Regeneration

At the start of each of your turns, if you have at least 1 Hit Point, regain 20 Hit Points.

#### Body Recalls Life

At the start of your turn, if you are at 0 Hit Points, alive, and have at least 10 Stamina, you may spend 10 Stamina to regain 20 Hit Points.

- No action is required.
- You may use this benefit once per scene.
- You immediately regain consciousness.
- You may stand by spending 5 feet of movement.
- Failed death saving throws remain until removed under the normal rules.
- This cannot restore you after death.
- It cannot function if your body has been completely destroyed.
- It cannot function while an effect explicitly prevents healing or bodily reconstruction.

#### Immortal Reconstruction

- A severed body part held against its original location reattaches after 1 uninterrupted minute.
- A missing body part regrows during a full 2-hour Cultivation Session.
- A regrown body part is fully functional when the session ends.
- This reconstruction does not restore Hit Points unless another rule says so.
- It does not repair Foundation damage, soul damage, core destruction, Hidden Injuries, or permanent identity alteration.

#### Transcended Mortal Needs

You cease aging unless you choose to continue aging, cannot die from old age, do not require food, drink, air, or sleep, and are immune to mundane disease and ordinary bodily poison.

You must still complete rests or Cultivation Sessions to gain their mechanical benefits.

Cultivation-powered disease, curses, corruption, Tribulation effects, Foundation injuries, and poisons with a Source CL remain capable of affecting you unless another feature protects you.

#### Complete Defensive Tempering

You gain all three Defensive Disciplines from Tempered Response.

#### Second Core Tempering Expression

Choose a second Core Tempering Expression. Both are active and use their Perfected CL17 benefits.

---

## Realm Suppression — Body Summary

Use the universal Realm Suppression procedure unless an explicit Body Refining Source Rule states otherwise.

- Use the suppressed Proficiency Bonus and effective CL for attacks, saving throw DCs, scaling, Source CL, and feature access.
- You cannot activate a Body Refining feature gained above the suppressed CL.
- A transformation, stance, projected bodily Asset, or other state granted solely by an unavailable feature is suppressed for the duration rather than destroyed.
- Maximum Hit Points, Hit Dice, maximum Stamina, and permanent anatomy are not recalculated solely because of Realm Suppression.
- Passive bodily durability and an existing Foundation are not automatically removed. A Source Rule that suppresses a named feature, bodily system, transformation, Foundation benefit, or complete Body Refining cultivation applies only to the authority it expressly states.
- A suppressed severed limb, organ, mutation, or embodied Asset is not healed or reconstructed merely because its feature is unavailable.

The Body Refining GM Authority module governs collisions involving complete bodily suppression, Foundation damage, destroyed cultivation systems, altered anatomy, and reconstruction.

---

## Realm Integration

| Realm | CL | Core Body Refining Expression |
|---|---:|---|
| **Mortal** | 1-4 | Iron Fist, Stomping Step, Stamina Guard, initial Subpath |
| **Foundation** | 5-9 | Extra Attack, Body Tempering, refined cultivation attacks, reinforced meridians |
| **Core Formation** | 10-14 | Core Tempering Expression, three attacks, Indomitable Body |
| **Nascent Soul** | 15-19 | Blood Pump, perfected circulation, four attacks, Heavenly Fist |
| **Immortal** | 20 | Immortal regeneration, bodily reconstruction, second Core Tempering Expression |

Realm entry does not automatically waive a Heavenly Tribulation, breakthrough requirement, AP requirement, or another universal advancement rule.

---

## Universal Subpath Rules

These rules apply to every Body Refining Subpath in this document.

### Cultivation Save DC

Unless stated otherwise, a Subpath saving throw uses your Body Refining Cultivation Save DC.

### Bloodied

A creature is **Bloodied** while it has half its maximum Hit Points or fewer.

### Qualifying Hostile Creature

A **qualifying hostile creature** must be actively hostile to you or your allies, must not be controlled or created by you or a willing ally, must not be deliberately captured or repeatedly revived to generate resources, and must have a CL no more than 5 lower than yours.

A creature without a CL qualifies when its encounter rank or threat is intended to challenge a character within 5 CL of you.

### Qualifying Hostile Damage

**Qualifying hostile damage** is damage caused by a hostile creature, active trap, or active environmental hazard.

Damage caused by yourself, a willing ally, a harmless object, or a deliberately staged interaction does not qualify.

Where a feature requires substantial damage, the damage must equal or exceed your Proficiency Bonus after all reductions.

### Source CL

A creature feature uses its user's CL as its Source CL.

An item, trap, Formation, hazard, or other independent effect uses its printed Source CL. If none is printed, use the encounter's CL.

When a feature automatically overcomes an opposing effect whose Source CL is no higher than yours, a higher-CL effect remains unaffected unless the feature provides a contest.

### Failed Spatial Movement

When teleportation, phasing, or spatial movement fails because of a Body Refining feature:

- The action, Bonus Action, Reaction, or movement expenditure used to activate it is spent.
- All Cultivation Point and limited-use costs are spent.
- The creature remains in the nearest legal space on the original side of the obstruction.

When a contest is required, the moving creature rolls `d20 + Proficiency Bonus + Path key ability modifier` against your Cultivation Save DC.

### Granted Attack Rule

An attack granted outside the normal attacks of the Attack action cannot trigger another feature that grants an attack.

A named once-per-turn damage or control rider can affect only one attack during the same turn unless its rule explicitly states otherwise.

### Unique States

A unique state is not a standard condition unless its rule says otherwise.

Unless a state states differently:

- One creature can bear only one instance of that state from you.
- Reapplying it replaces and refreshes the previous instance.
- Different cultivators track their states separately.
- The state ends immediately if its printed duration expires or its removal procedure succeeds.

### Transformations

A Subpath transformation with a once-per-scene limit cannot be activated more than once during the same scene, cannot be refreshed by paying its cost again, and ends if you become Unconscious unless stated otherwise.

### Weapon Groups

| Weapon group | Included weapons |
|---|---|
| **Bow** | Shortbow, longbow, and a weapon carrying the Bow tag |
| **Draw Blade** | Dagger, shortsword, saber, scimitar, one-handed sword, and a weapon carrying the Draw Blade tag |
| **Polearm** | Spear, staff, glaive, halberd, and a weapon carrying the Polearm tag |
| **Chain Weapon** | Chain, whip, flail, rope dart, meteor hammer, and a weapon carrying the Chain Weapon tag |
| **Blade** | Dagger, sword, saber, axe with a cutting edge, and a weapon carrying the Blade tag |
| **Hafted Weapon** | Axe, mace, hammer, club, and a weapon carrying the Hafted Weapon tag |
| **Thrown Weapon** | A weapon with the Thrown property |
| **Staff** | Quarterstaff and a weapon carrying the Staff tag |
| **Unarmed Form** | Unarmed strike or natural bodily weapon |

Custom weapons must list their weapon group in their item statistics.

---

# 05. Qi Cultivation

Qi Cultivation refines internal energy into techniques, armaments, fields, formations, and remote expressions. Intelligence or Charisma governs its Path features, and Qi is shaped through deliberate circulation and externalized authority.

## Qi Cultivation at a Glance

| Rule | Qi Cultivation |
|---|---|
| **Key Ability** | Intelligence or Charisma, chosen at CL1 |
| **Hit Die** | d8 |
| **Cultivation Points** | Qi |
| **Primary Roles** | Martial combatant, hybrid weapon-and-technique cultivator, ranged combatant, controller, healer, artisan, scholar, and supernatural specialist |
| **Saving Throw Proficiencies** | None |
| **Armor Training** | Light armor |
| **Weapon Training** | Simple weapons |
| **Skills** | Choose two: Arcana, History, Insight, Investigation, Medicine, Nature, Perception, Persuasion, Religion |

### Choosing Your Key Ability

At CL1, choose Intelligence or Charisma. This becomes your Qi Cultivation key ability.

Use Intelligence for formulae, arrays, scripture interpretation, medicine, alchemy, calligraphy, formation design, technical weapon methods, and methodical comprehension.

Use Charisma for instinctive circulation, willpower, bloodline expression, emotional intensity, innate affinity, command presence, and overwhelming spiritual force.

### Cultivation Math

**Cultivation Save DC**  
`8 + Proficiency Bonus + Qi Cultivation key ability modifier`

**Cultivation Attack Modifier**  
`Proficiency Bonus + Qi Cultivation key ability modifier`

**Cultivation Check**  
`d20 + Proficiency Bonus + Qi Cultivation key ability modifier`

### Activation, Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, or other Source Rule, including every attack, projectile, repeated target, and rider that the use expressly creates. Once-per-activation limits apply across that whole use.

A **cultivation technique** is a supernatural procedure authorized by a Source Rule. It is not automatically a spell, weapon attack, or ordinary ability check. The Source Rule states which D&D resolution procedure it uses.

A Qi-powered feature requires Concentration only when its Source Rule says so. Use the normal Concentration limit and ending conditions unless a cultivation rule expressly changes them. Nascent Soul's **Independent Concentration** improves a failed Concentration saving throw; it does not create a second Concentration slot.

### Effective CL and Source CL

Your normal effective CL is your Qi Cultivation CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature. Source CL determines authority and interaction; it does not replace attack rolls, saving throws, Anchors, costs, or recovery procedures printed by the Source Rule.

---

## Qi

Qi represents refined spiritual energy stored within meridians, dantian, breath, blood, Golden Core, Nascent Soul, elemental affinities, prepared techniques, items, weapons, armor, and internal formations.

### Maximum Qi

`Qi Cultivation CL × Qi Cultivation key ability modifier`

Your maximum Qi cannot be lower than:

`2 × Qi Cultivation CL`

### Recovering Qi

| Recovery Method | Qi Recovered | Limit |
|---|---:|---|
| **Short Rest** | Qi equal to your CL | Once per long rest |
| **Long Rest** | Half your maximum Qi | No additional limit |
| **Full Cultivation Session** | All missing Qi | Once per long rest |

A Full Cultivation Session requires 2 uninterrupted hours, a reasonably calm environment, and sufficient ambient spiritual energy or an appropriate substitute. It may occur during an eligible meditative long rest.

### Reaching 0 Qi

When you are reduced from more than 0 Qi to exactly 0 Qi, gain 1 level of Exhaustion.

Repeatedly reaching 0 Qi can add further Exhaustion under the universal Cultivation Point rules.

---

## Qi Cultivation Progression

| CL | Features |
|---:|---|
| 1 | Cultivated Response, Qi Sensing, Qi Technique Potency |
| 2 | Meridian Regulation |
| 3 | Qi Cultivation Subpath |
| 4 | Ability Score Improvement or Cultivation Insight |
| 5 | Qi Armor |
| 6 | Subpath Feature |
| 7 | Featherfall |
| 8 | Ability Score Improvement or Cultivation Insight |
| 9 | Domain Armament |
| 10 | Golden Core Form, Subpath Feature |
| 11 | Golden Core Efficiency |
| 12 | Ability Score Improvement or Cultivation Insight |
| 13 | Domain Armament Link |
| 14 | Subpath Feature |
| 15 | Nascent Soul |
| 16 | Ability Score Improvement or Cultivation Insight |
| 17 | Nine Heavens Gaze, Perfected Golden Core, Domain Armament damage increase |
| 18 | Subpath Feature |
| 19 | Ability Score Improvement or Cultivation Insight |
| 20 | Immortal of Qi, Second Golden Core Form |

### Ability Score Improvement or Cultivation Insight

At CL4, CL8, CL12, CL16, and CL19, choose one of the following:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight's **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, sect instruction, imperial office, bloodline awakening, experimentation, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise. Background ability-score increases and Origin Insights are separate character-creation benefits and do not activate this increase.

Use the **Central Cultivation Insights** chapter as the sole Insight catalogue authority. If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

---


## Qi Cultivation Subpaths

At CL3, choose one Qi Cultivation Subpath for which you have legal access. You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Catalog classification | Meaning |
|---|---|
| **Open School** | Commonly teachable or institutionally available. Open access does not imply low power. |
| **Restricted Scripture** | Controlled technical, political, military, medical, inherited, or hazardous instruction. |
| **Rare Inheritance** | Uncommon structural access, bloodline, vessel, destiny, treasure, or singular transmission. A **Rare Variant** is a parent-lineage conversion inside this category. |
| **Forbidden Variant** | A parent-lineage conversion carrying a prohibited, condemned, hazardous, predatory, or politically unacceptable price. Forbidden is not automatically Daemonic. |
| **Secret Law** | Qualitatively superior law-level authority requiring explicit access and its printed initiation price. |
| **Daemonic** | A mechanical tag used only when the Source Rule interacts with Corruption, daemonic energy, purification, or anti-daemonic rules. It is orthogonal to social accusations of being “demonic.” |

A character normally has one Subpath progression. Parent and Variant lineages use the executable replacement rules in the **Qi Cultivation Subpath Compendium and Shared Procedures**; they do not provide a second simultaneous Subpath progression.

---

## CL1 — Cultivated Response

Choose one Defensive Discipline.

### Reflexive Circulation

Your discipline applies to Dexterity saving throws.

### Calculated Circulation

Your discipline applies to Intelligence saving throws.

### Imperious Circulation

Your discipline applies to Charisma saving throws.

#### Response Procedure

**Reaction**  
**Trigger:** You fail the selected saving throw.  
**Cost:** 1 Qi  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Cultivated Response:

- Is not saving throw proficiency.
- Is activated after you learn that the roll failed.
- Cannot modify a death saving throw.
- Cannot modify a breakthrough check.
- Cannot modify a training check.
- Cannot modify the same saving throw more than once.

At CL15, learn a second Defensive Discipline.

At CL20, learn all three.

---

## CL1 — Qi Sensing

Qi Sensing is always active unless suppressed.

### Passive Sensing

Within 30 feet, perceive the presence of active supernatural energy from:

- Path and Subpath features.
- Sphere talents.
- Formations.
- Talismans.
- Cultivated items.
- Active spirits.
- Concentrated Cultivation Points.
- Transformations.
- Active curses.
- Active seals.
- Possession.
- Corruption.
- Strong residues created during the previous hour.

Qi Sensing is blocked by:

- 1 foot of stone.
- 1 inch of common metal.
- A thin sheet of lead.
- 3 feet of wood or packed earth.
- A sealed Formation or effect explicitly blocking Qi perception.

Passive Qi Sensing does not automatically reveal:

- The exact technique.
- Exact statistics.
- A precise occupied space for an Invisible creature.
- A dormant inheritance.
- A secret property.
- A successful concealment effect.

### Analyze Qi

**Action**  
**Range:** 30 feet

Choose one detected effect, creature, item, or residue.

Learn:

- Its broad category.
- Its active supernatural tags.
- Whether its Source CL is lower than, equal to, or higher than yours.
- Whether it is active, dormant, damaged, unstable, or suppressed.

For a concealed effect, make a Cultivation Check against its save DC.

If it has no save DC, use:

`8 + source Proficiency Bonus + source key ability modifier`

On failure:

- You know concealed power is present.
- You do not learn its exact nature or location.
- You cannot retry until the effect changes or a new scene begins.

When the check succeeds, the GM must provide the listed information and cannot withhold it for dramatic convenience.

---

## CL1 — Qi Technique Potency

Once per activation, when a Qi-powered feature deals damage, add your Qi Cultivation key ability modifier to one damage roll.

Qualifying features include:

- Qi Cultivation Path features.
- Qi Cultivation Subpath features.
- Qi-powered Sphere talents.
- Recorded Arts using Qi.
- Forged Techniques using Qi.
- Immortal Arts using Qi.
- Weapon attacks explicitly delivering a Qi-powered cultivation technique.

An ordinary weapon attack does not qualify merely because the attacker is a Qi Cultivator.

When a weapon-delivered technique deals both weapon damage and technique damage, apply Qi Technique Potency to either:

- One weapon-damage roll; or
- One technique-damage roll.

Do not apply it to both.

For a Barrage, volley, chain, multi-projectile activation, or technique applied through multiple attacks, Qi Technique Potency applies once across the entire activation.

---

## Universal Reference — Weapon-Delivered Cultivation Techniques

The **Qi Cultivation Subpath Compendium and Shared Procedures** supply the complete procedure for paid multiattack delivery, Domain Armament delivery, damage separation, and anti-recursion.

A cultivation technique can be delivered through a weapon only when a Sphere talent, Recorded Art, Forged Technique, Immortal Art, item property, Method, Subpath feature, or another Source Rule explicitly permits weapon delivery.

Unless the Source Rule explicitly states otherwise:

1. Pay the technique’s complete cost.
2. Make the authorized weapon attack.
3. On a miss, the technique fails and the cost remains spent.
4. On a hit, deal the weapon’s normal damage.
5. Apply the delivered technique from the struck creature or point.
6. Resolve any required saving throw.
7. Apply once-per-turn and once-per-activation limits.

When the user makes multiple attacks, the cultivation technique applies only to the first qualifying attack unless the Source Rule explicitly states that it applies to:

- Additional attacks.
- Multiple attacks.
- Every attack.
- A Barrage.
- A volley.
- Another defined sequence.

Weapons and shields may serve as visible cultivation focuses without automatically converting the technique into a weapon attack or adding weapon damage.

---

## CL2 — Meridian Regulation

**Action**  
**Range:** Touch  
**Cost:** 1 Qi

Choose one poison, disease, or directly caused physical impairment affecting the target.

The effect must:

- Have a printed saving throw DC.
- Not have the Curse, Tribulation, Foundation Injury, Hidden Injury, Possession, Permanent, or Soul Damage tag.

### Effect with Repeat Saves

The target immediately repeats the saving throw with Advantage.

On success, apply the effect’s normal successful-save result.

### Effect without Repeat Saves

The target makes a Constitution saving throw with Advantage against the effect’s printed DC.

On success, suppress one penalty until the end of the target’s next turn:

- Poisoned.
- Speed reduction.
- Disadvantage on attack rolls.
- Disadvantage on ability checks.
- Disadvantage on saving throws.
- Inability to take Reactions.

Meridian Regulation does not automatically:

- Remove the underlying effect.
- End its duration.
- Cure the disease or poison.
- Remove Exhaustion.
- Restore Hit Points.
- Stop ongoing damage.
- Remove a higher-authority effect.

---

## CL5 — Qi Armor

**Reaction**  
**Trigger:** You are hit by a ranged attack roll.  
**Cost:** 2 Qi

Gain +3 AC until the start of your next turn, including against the triggering attack.

Activate after learning that the attack hit and before damage is applied.

Qi Armor applies to:

- Ranged weapon attacks.
- Ranged spell attacks.
- Ranged cultivation attacks.
- Ranged Sphere attacks.
- Recorded Art attack rolls.
- Forged Technique attack rolls.
- Immortal Art attack rolls.
- Item attack rolls.
- Formation attack rolls.

Qi Armor does not apply to:

- Melee attacks.
- Reach attacks classified as melee.
- Saving throw effects.
- Automatic damage.
- Environmental damage.
- An effect without an attack roll.

At CL10, Qi Armor costs 1 Qi.

---

## CL7 — Featherfall

**Reaction**  
**Trigger:** You or a creature within 60 feet begins falling.  
**Cost:** 1 Qi per target  
**Targets:** Up to your Proficiency Bonus in creatures  
**Duration:** 1 minute

An affected target:

- Descends no more than 60 feet during each round.
- Takes no falling damage while the effect lasts.
- Lands standing when it reaches a supporting surface.
- May end the effect on itself at the start of its turn.

Featherfall does not grant flight or horizontal movement.

---

## CL9 — Domain Armament

A Domain Armament is a movable external Qi focus. It is not a Spirit Awakening Domain.

A Domain Armament may be:

- A projected cultivation construct.
- One specific real weapon bound to your Qi.
- One specific real shield bound to your Qi.

Examples include:

- Sword.
- Spear.
- Needle.
- Bow.
- Bell.
- Brush.
- Fan.
- Seal.
- Mirror.
- Orb.
- Disk.
- Chain.
- Instrument.
- Shield.
- Talisman array.
- Another noncreature weapon or cultivation implement.

### Manifest Domain Armament

**Bonus Action**  
**Initial Position:** One unoccupied point within 30 feet  
**Cost:** 1 Qi  
**Duration:** 1 hour

You may maintain one Domain Armament.

A projected Armament:

- Occupies no space.
- Provides no Cover except through Guard Mode.
- Cannot flank.
- Cannot carry objects.
- Cannot manipulate objects.
- Cannot use unrelated item properties.
- Cannot be targeted unless a rule explicitly affects projected weapons, Qi constructs, or Domain Armaments.
- Ends if you become Unconscious.

Choose Bludgeoning, Piercing, Slashing, or Force damage when it manifests.

Once during each of your turns:

- Move it up to 20 feet without using an action.
- It must remain within 30 feet.

If a projected Armament ends outside range, it moves to the nearest legal point in range.

### Binding a Real Weapon or Shield

You may bind one real weapon or shield as your Domain Armament.

**Binding Time:** 10 uninterrupted minutes while touching the item

The item must satisfy all of the following:

- You own it or have its owner’s permission.
- You are proficient with it or another rule permits its use.
- You meet its attunement and cultivation prerequisites.
- A sentient item consents.
- It is not already bound as another creature’s Domain Armament.

The bond remains until:

- You bind another item.
- You willingly end the bond.
- The item is destroyed.
- A feature explicitly severs the bond.

The actual item alternates between:

- Being wielded.
- Being carried.
- Floating as your Domain Armament.

It is never duplicated.

A Saint-class, Legendary, named, or ancestral item remains the actual item while floating.

### Call or Release Bound Item

Move the item between your hand and a floating position:

- As a Bonus Action.
- As part of manifesting Domain Armament.
- At the beginning or end of your Attack action.
- As part of activating an authorized weapon-delivered technique through it.

Calling requires a legal free hand and an unobstructed path.

Releasing requires a legal point within Domain Armament range.

This movement is not teleportation unless another feature says otherwise.

A spatial lock, sealed Formation, total physical restraint, or item-control effect can block it.

### Domain Armament Modes

A floating Domain Armament operates in Assault Mode or Guard Mode.

Choose its mode when manifested or released.

Once during each of your turns, change its mode without using an action.

#### Assault Mode — Domain Armament Attack

**Bonus Action**

Move the Armament up to 20 feet, then make a Cultivation Attack against one creature within 5 feet.

**Projected Armament Hit:**

- CL9: `1d8 + key ability modifier`
- CL13: `2d8 + key ability modifier`
- CL17: `3d8 + key ability modifier`

Use the damage type chosen when manifested.

#### Bound Weapon Attack

Use your Cultivation Attack Modifier and the weapon’s printed enhancement bonus.

On a hit, use the greater of:

- The weapon’s normal damage dice; or
- Your Domain Armament damage dice.

Then add:

- Your Qi Cultivation key ability modifier.
- The weapon’s printed damage bonus.
- Any automatic on-hit property whose trigger is legally satisfied.

The item retains:

- Damage type.
- Enhancement bonus.
- Attunement properties.
- Automatic on-hit properties.
- Material properties.
- Named traits.

A property requiring a separate action, item charge, Attack action, physical grip, stance, or unsatisfied trigger does not activate automatically.

A property saying “while wielding” treats the floating item as wielded unless it explicitly requires physical contact, a free hand, or a stance.

#### Guard Mode — Projected Shield

A projected shield or defensive form cannot make Domain Armament Attacks.

At the end of your turn, designate one creature within 5 feet as protected until the start of your next turn.

The creature gains:

`+2 AC against ranged attack rolls`

The protection ends if:

- The creature moves more than 5 feet from the Armament.
- The Armament changes mode.
- The Domain Armament ends.

The bonus:

- Applies to ranged weapon, spell, and cultivation attack rolls.
- Does not apply to melee attacks.
- Does not apply to saving throw effects.
- Does not stack with another shield bonus.
- Stacks with Qi Armor.

#### Guard Mode — Bound Shield

Use the shield’s printed shield bonus against ranged attacks for the protected creature.

Its enhancement bonus applies.

The floating shield:

- Protects one creature.
- Does not also protect you merely because it is bound.
- Retains appropriate passive properties.
- Can serve as a cultivation focus.

#### Bound Shield Assault

A bound shield may use Assault Mode.

If it has a printed attack profile, use it.

Otherwise, its Domain Armament Attack deals Bludgeoning or Force damage using normal Domain Armament damage dice.

### Bound Item Vulnerability

A bound real item:

- Uses its printed durability.
- Can be targeted by effects explicitly affecting items, weapons, shields, or cultivation implements.
- Can be suppressed, restrained, sealed, trapped, or displaced.

If forced outside Domain Armament range:

- It falls in the nearest legal space.
- Domain Armament benefits are suppressed.
- The bond remains.
- Control returns when it is in range and no blocking effect remains.

---

## CL10 — Golden Core Form

At CL10:

- Qi Armor costs 1 Qi.
- Choose one Golden Core Form.

You may replace the chosen Form after a successful CL15 breakthrough before using your CL15 Nascent Soul feature.

At CL17, your chosen Form becomes Perfected.

At CL20, choose a second Golden Core Form. Both Forms are Perfected.

### Stable Golden Core

When Initiative is rolled, if your current Qi is lower than your Proficiency Bonus, regain Qi until it equals your Proficiency Bonus.

At the start of your turn, if your current Qi is lower than your Proficiency Bonus, regain 1 Qi.

Once per round, when a hostile effect would reduce your current Qi, maximum Qi, or restored Qi, reduce that loss by your Proficiency Bonus.

This does not reduce Qi you willingly spend.

#### Perfected Stable Golden Core

- Initiative threshold becomes `2 × Proficiency Bonus`.
- Start-of-turn recovery becomes 2 Qi.
- Hostile Qi loss reduction becomes `2 × Proficiency Bonus`.

### Circulating Golden Core

Once per turn, after you spend Qi on a feature that resolves successfully, choose one:

- Move 5 feet without provoking Opportunity Attacks.
- Shift your stance around one creature within your weapon’s reach without provoking an Opportunity Attack from that creature.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Move your Domain Armament 10 feet.

This does not trigger from:

- Refunded costs.
- Invalid activations.
- A cost paid solely to activate Circulating Golden Core.

#### Perfected Circulating Golden Core

Choose two different benefits.

- Movement becomes 10 feet.
- Temporary Hit Points become `2 × Proficiency Bonus`.
- Domain Armament movement becomes 20 feet.

### Golden Core Reservoir

**Bonus Action**  
**Limit:** Once per scene

Regain Qi equal to:

`Proficiency Bonus + Qi Cultivation key ability modifier`

#### Perfected Golden Core Reservoir

Regain:

`2 × Proficiency Bonus + key ability modifier`

If you begin your turn with 0 Qi and Reservoir is unused:

- Activate it before any other recovery.
- It requires no Bonus Action.
- It remains once per scene.

---

## CL11 — Golden Core Efficiency

Once per turn, reduce the Qi cost of one Qi-powered feature with a final cost of at least 2 Qi by 1.

Cost order:

1. Base cost.
2. Optional surcharges.
3. Golden Core Efficiency.
4. Later permitted modifiers.

The final cost cannot be lower than 1 through this feature.

It does not stack with another feature reducing the same use unless explicitly permitted.

It cannot reduce:

- Post-resolution costs.
- Permanent sacrifice.
- Maximum-Qi reduction.
- Non-Qi costs.

---

## CL13 — Domain Armament Link

Your Domain Armament improves:

- Control range becomes 60 feet.
- Normal movement becomes 30 feet.
- Domain Armament Attack uses CL13 damage.

### Remote Technique Origin

When activating a non-Self Qi Path, Subpath, or Sphere technique, spend 1 additional Qi to originate it from yourself or your Domain Armament.

Measure from the selected origin:

- Range.
- Line of sight.
- Line of effect.
- Cover.
- Cones.
- Lines.
- Areas.
- Touch range when the Armament is within 5 feet.

Remote Technique Origin cannot transmit:

- A consumed physical object.
- A pill or potion that must enter the target’s body.
- A physical talisman unless the Domain Armament carries it legally.
- A weapon attack unless weapon delivery is authorized.
- Direct hand manipulation.
- A Self technique.
- An aura explicitly centered on your body.

It is blocked by:

- Total Cover.
- A sealed Formation.
- A spatial lock.
- A planar boundary.
- An effect explicitly blocking Qi transmission.

A technique uses one origin unless it explicitly permits multiple origins.

### Weapon-Delivered Remote Technique

A floating bound weapon may make the required weapon attack when a Source Rule explicitly authorizes weapon delivery.

Determine from the floating weapon:

- Attack range.
- Line of sight.
- Cover.
- Struck point.
- Technique origin.

The item must satisfy every weapon requirement.

A sword cannot deliver a technique requiring a bow. A shield cannot deliver a piercing technique unless it has a legal piercing attack.

---

## CL15 — Nascent Soul

Your Nascent Soul is a refined autonomous Qi structure. It is not Spirit Awakening spiritual authority.

### Second Defensive Discipline

Choose a second Cultivated Response discipline.

### Nascent Continuity

At the beginning of your turn, before other recovery, if you have 0 Qi:

- Regain Qi equal to your Proficiency Bonus.
- Use this once per scene.

This does not remove Exhaustion gained from reaching 0 Qi.

### Independent Concentration

**Reaction**  
**Trigger:** You fail a Constitution saving throw to maintain a Qi-powered feature.  
**Cost:** 1 Qi  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency.

### Nascent Armament Conduction

Once per turn, use Remote Technique Origin without paying its 1-Qi surcharge.

Your Domain Armament persists while you are Incapacitated, but ends if you become Unconscious.

---

## CL17 — Nine Heavens Gaze

**Action**  
**Cost:** 8 Qi  
**Duration:** 1 hour

Gain:

- Truesight 60 feet.
- Qi Sensing range 120 feet.
- Analyze Qi range 120 feet.
- Physical materials no longer block Qi Sensing within 30 feet, except lead, artifact shielding, or explicit Qi sealing.
- Perception of Formation lines, seals, projected Qi, possession links, transformations, Domain Armaments, and active cultivation routes.

### Heavenly Analysis

**Bonus Action**  
**Limit:** Once per turn  
**Range:** 120 feet

Choose one active effect.

Learn:

- Exact Source CL.
- Remaining duration.
- Whether it requires Concentration.
- Active tags.
- Its Anchor, if any.
- Its printed condition for ending or suppression.

An explicitly concealed effect whose Source CL exceeds yours requires a Cultivation Check against its save DC.

On failure:

- You know that it is concealed.
- You do not learn the details.
- You cannot retry until it changes or a new scene begins.

Nine Heavens Gaze does not reveal:

- Dormant abilities.
- Future actions.
- Memories.
- Thoughts.
- Exact Hit Points.
- Non-active secrets.

### Perfected Golden Core

Your selected Golden Core Form becomes Perfected.

### Domain Armament Damage

Domain Armament Attack uses CL17 damage.

---

## CL20 — Immortal of Qi

### Immortal Circulation

At the start of each of your turns, regain 5 Qi.

This functions in spiritually barren environments unless an effect explicitly suppresses Immortal circulation.

### Permanent Nine Heavens Gaze

Nine Heavens Gaze is always active:

- No Action required.
- No Qi cost.
- It remains suppressible.

### Twin Domain Armaments

You may maintain two Domain Armaments.

Manifest or release both through the same Bonus Action for 1 Qi.

Each may have:

- A separate projected form.
- A separate bound real item.
- A separate damage type.
- A separate mode.

Once during each of your turns, move both normally.

#### Twin Assault

When using your Bonus Action to attack:

- Make one Domain Armament Attack with each Armament in Assault Mode.
- Resolve them separately.
- Once-per-turn riders apply once across both attacks unless explicitly stated otherwise.
- A weapon-delivered technique applies to the first qualifying attack unless explicitly extended.
- Neither attack can generate another Domain Armament Attack.

#### Twin Guard

Two shield Armaments may protect two different creatures.

The same creature cannot add two shield bonuses from Twin Domain Armaments.

#### Remote Origins

Choose one Domain Armament as the origin of a technique unless it explicitly permits multiple origins.

### Complete Cultivated Response

Learn all three Defensive Disciplines.

### Second Golden Core Form

Choose a second Golden Core Form.

Both Forms are Perfected.

### Immortal Physiology

You:

- Do not age.
- Cannot die from old age.
- Do not require food, drink, air, or sleep.
- Still require rests and Cultivation Sessions to recover features whose rules require them.

---


## Realm Suppression — Qi Summary

When the universal Realm Suppression rule is active, use the suppressed CL and its Proficiency Bonus for Qi features barred or scaled by the suppressed Realm.

While suppressed, you cannot activate or benefit from:

- Qi Path or Subpath features whose minimum CL exceeds the suppressed CL.
- Higher-Realm Cultivation Insights, Sphere talents, Recorded Arts, Forged Techniques, Immortal Arts, Method powers, Foundation powers, or item powers barred by Realm Suppression.
- A higher-CL version of a scaling effect when a lower-CL version exists.

Realm Suppression does **not** reduce:

- Hit Points or Hit Dice.
- Maximum Qi.
- Path-chassis durability already embodied by the cultivator.
- A Foundation's passive physical quality unless the Foundation says otherwise.
- Existing injury, Corruption, debt, contract, karma, severance, or other consequences.

An active effect you can no longer legally maintain ends unless it has become an independent Asset, Anchor, injury, contract, or other persistent source under its printed rule. Effects that remain use the suppressed Source CL unless an independent source has its own fixed Source CL.

Realm Suppression cannot be used to refund costs, erase setup requirements, avoid a Variant conversion, or make a created consequence count as lower authority after the fact.

---

## Realm Identity

| Realm | Qi Cultivation expression |
|---|---|
| **Mortal, CL1–4** | Qi perception, technique potency, defensive circulation, meridian regulation |
| **Foundation, CL5–9** | Ranged Qi defense, safe descent, external Domain Armament |
| **Core Formation, CL10–14** | Golden Core Form, cost efficiency, advanced armament projection, remote origin |
| **Nascent Soul, CL15–19** | Autonomous circulation, reinforced Concentration, perfect perception, perfected Golden Core |
| **Immortal, CL20** | Continuous Qi, twin armaments, permanent gaze, multiple perfected Core forms |

---

## Domain Armament and Forged Technique Compatibility

A Forged Technique may combine weapon delivery or Domain Armament origin with:

- Barrage talents.
- Elemental damage.
- Elemental talent riders.
- Weapon talent riders.
- Forced movement.
- Conditions.
- Area conversion.
- Remote origins.

It must still define:

- Packet count.
- Talent count.
- Complexity.
- Qi cost.
- Weapon requirement.
- Projectile or attack count.
- Targeting.
- Attack rolls.
- Saving throws.
- Damage per projectile or attack.
- Rider frequency.
- Failure result.
- Anti-recursion rules.

Unless the Forged Technique explicitly pays for and authorizes a broader structure:

- Qi Technique Potency applies once per activation.
- A once-per-turn rider applies once across the Barrage.
- A once-per-target rider applies once to each target.
- A rider requiring damage applies only to a projectile or attack that deals damage.
- A missed attack does not carry its rider.
- A projectile cannot generate another projectile.
- An additional attack cannot generate another additional attack.

---

# 06. Spirit Awakening

Spirit Awakening cultivates the soul, identity, perception, spiritual relationships, exorcistic authority, and Domains. Wisdom governs its Path features, Resonance fuels its techniques, and spirits remain autonomous beings rather than possessions or generic summons.

## Spirit Awakening at a Glance

| Rule | Spirit Awakening |
|---|---|
| **Key Ability** | Wisdom |
| **Hit Die** | d8 |
| **Cultivation Points** | Resonance |
| **Primary Roles** | Spiritual perception, soul authority, mental and emotional pressure, exorcism, restoration, control, ritual work, spirit relations, martial conceptual practice, and Domain authority |
| **Saving Throw Proficiencies** | None |
| **Armor Training** | None |
| **Weapon Training** | Simple weapons |
| **Skills** | Choose two: Deception, Insight, Investigation, Medicine, Perception, Persuasion, Religion |

Spirit Awakening grants no saving throw proficiencies. Its spiritual defenses are active cultivation features rather than passive proficiency.

You do not gain armor or shield training from this Path. If another legal source grants armor, shield, martial weapon, or unarmed-combat training, using it does not inhibit Spirit Awakening unless an explicit Source Rule says otherwise.

### Cultivation Math

**Cultivation Save DC**  
`8 + Proficiency Bonus + Wisdom modifier`

**Cultivation Attack Modifier**  
`Proficiency Bonus + Wisdom modifier`

**Cultivation Check**  
`d20 + Proficiency Bonus + Wisdom modifier`

### Activation, Spirit Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, spirit expression, or other Source Rule, including every target, pulse, echo, rider, and repeated effect that use expressly creates.

A **Spirit Awakening technique** is a supernatural procedure authorized by a Spirit Awakening Source Rule. It is not automatically a spell, weapon attack, condition, curse, possession, Sphere talent, companion action, or ordinary ability check. The Source Rule states the resolution procedure it uses.

A Spirit Awakening technique requires Concentration only when its Source Rule says so. Use the normal Concentration limit and ending conditions unless an explicit cultivation rule changes them.

An echo, Soul Fragment, Companion, manifestation, vessel, Resonance Mark, Domain, relation, or conceptual state does not create a second activation, second turn, second Concentration slot, or additional resource pool unless its Source Rule expressly says it does.

### Effective CL and Source CL

Your normal effective CL is your Spirit Awakening CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature.

**Source CL** determines the authority of a spiritual effect. It does not replace a printed attack roll, saving throw, Cultivation Check, Anchor, cost, repeated save, recovery procedure, or reconstruction requirement.

---

## Resonance

Resonance is the cultivated force of an awakened soul: clarity, pressure, identity, memory weight, dream depth, emotional coherence, ancestral continuity, spiritual authority, and the capacity to remain oneself while touching another spirit.

### Maximum Resonance

`Spirit Awakening CL × Wisdom modifier`

Your maximum Resonance cannot be lower than:

`2 × Spirit Awakening CL`

Only a Method or another explicit Source Rule can alter this maximum.

### Recovering Resonance

| Recovery Method | Resonance Recovered | Limit |
|---|---:|---|
| **Short Rest** | Resonance equal to your Spirit Awakening CL | Once per long rest |
| **Long Rest** | Half your maximum Resonance | No additional limit |
| **Full Cultivation Session** | All missing Resonance | Once per long rest |

Round fractions down.

A Full Cultivation Session requires 2 uninterrupted hours, a reasonably safe spiritual environment, and a practice capable of restoring coherence. Examples include meditation, dream-trance, prayer, ancestor-listening, confession, emotional integration, shrine attendance, ritual music, spirit communion, soul inspection, or another practice suitable to the cultivator’s Method and Soul Anchor. It may occur during an eligible meditative long rest.

A hostile spirit, damaged Anchor, violated Taboo, Bond Crisis, active possession, or spiritual prison can prevent a particular recovery practice only when its Source Rule says how. The GM does not reduce recovery merely because the cultivator’s emotions are narratively unsettled.

### Reaching 0 Resonance

When you are reduced from more than 0 Resonance to exactly 0 Resonance, gain 1 level of Exhaustion.

Repeatedly reaching 0 Resonance can add further Exhaustion under the universal Cultivation Point rules. A feature that temporarily reduces maximum Resonance does not itself count as reaching 0 unless current Resonance is actually reduced to 0.

---

## Soul Anchors

Every Spirit Awakener has a **Soul Anchor** under the universal Soul Anchor rules. It describes what keeps the awakened self coherent: a true name, vow, ancestor, grief, dream, mask, mirror, companion spirit, shrine, debt, lost home, forbidden memory, heart demon, unfinished death, or another defining spiritual root.

At CL1, record:

- the Anchor’s name or description;
- whether it is primarily internal, relational, locational, embodied, object-linked, or vow-linked;
- one way the cultivator normally communes with it during a Full Cultivation Session;
- any separate physical vessel, relationship, or location that represents it.

These entries describe the Anchor. They do not create a destructible object, Companion, Cultivation Asset, immunity, weakness, or additional ability unless another Source Rule says so.

Path interactions:

- Your Soul Anchor is a legal focus for Spirit Awakening techniques when a Source Rule permits a spiritual focus.
- A Soul Anchor is not automatically a physical object and cannot be attacked unless a Source Rule gives it an external manifestation or Anchor profile.
- A Strained Soul Anchor does not erase your Path features, but it can prevent an expressly printed Anchor Invocation and can affect techniques that explicitly depend on it.
- Ordinary damage cannot destroy a Soul Anchor.
- Severing, rewriting, consuming, or permanently replacing a Soul Anchor requires an explicit high-authority Source Rule and an explicit recovery or reconstruction procedure.
- Realm Suppression does not remove the existence of a Soul Anchor, though it can suppress higher-CL expressions that depend on it.

A Spirit Companion, ancestor, shrine, object, relationship, or vow used as a Soul Anchor is not automatically a full Companion, Cultivation Asset, or destructible Spiritual Anchor. Those statuses require separate rules.

---

## Resonance Marks

Spirit Awakeners leave impressions upon the soul.

A **Resonance Mark** may appear as a bruise upon the spirit, a remembered name, red thread, scent of incense, pulse in a mirror, echo, dream symbol, prayer syllable, pressure point, or another Path- or Subpath-appropriate sign.

Unless a Source Rule states otherwise:

- A Resonance Mark lasts until the end of your next turn.
- A creature can bear only one Resonance Mark from you at a time.
- Reapplying your mark refreshes its duration.
- Marks from different Spirit Awakeners can coexist.
- A Resonance Mark is not a condition, curse, Charm, possession, Spirit Bond, Sphere talent, or Soul Fragment.
- The mark is invisible to ordinary sight.
- While the marked creature is within 60 feet, you know that your mark remains, but not automatically its precise space if it is hidden.
- A mark does not by itself reveal thoughts, identity, location, statistics, memories, or the text of a Source Rule.
- If the marked creature enters an effect that blocks spiritual perception or has a stronger concealment Source Rule, the mark can become hidden or suppressed.

A concealed mark can be contested with a Cultivation Check against the concealment effect’s save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

A Resonance Mark never gives permission to target through total cover or total spiritual concealment unless another Source Rule expressly says so.

---

## Spiritual Pressure

**Spiritual Pressure** is short-lived soul authority. It is not automatically fear, Charm, possession, physical restraint, or a permanent alteration.

When a feature tells you to impose ordinary Spiritual Pressure, choose one option unless the feature provides its own pressure effect:

1. **Heavy Soul:** The target’s Speed is reduced by 10 feet.
2. **Stilled Intent:** The target cannot take Reactions.
3. **Shaken Purpose:** The target has Disadvantage on the next attack roll it makes.
4. **Opened Spirit:** The target has Disadvantage on the next Intelligence, Wisdom, or Charisma saving throw it makes against one of your Spirit Awakening features.
5. **Repelled Heart:** The target cannot willingly move closer to you.
6. **Revealed Disturbance:** You learn the target’s surface emotional state and whether it is affected by ordinary possession, a spiritual curse, dream intrusion, memory interference, spiritual contamination, or one of your Resonance Marks.

Unless stated otherwise, the pressure lasts until the start of your next turn.

A creature can suffer only one ordinary Spiritual Pressure effect from you at a time. Reapplying pressure replaces or refreshes your previous choice; it does not stack multiple ordinary options. A feature that expressly creates a two-option or broader pressure package is one exceptional package and does not authorize other pressure stacking.

Immunity to Charmed or Frightened does not grant immunity to Spiritual Pressure unless the pressure expressly imposes that condition. A creature without a mind, soul, animating spirit, or equivalent spiritual identity may be immune when the Source Rule cannot logically affect it.

---

## Spirit Awakening Progression

| CL | Features |
|---:|---|
| 1 | Soul Anchor, Soulward Response, Spiritual Sense, Mind Spike |
| 2 | Soul Gaze |
| 3 | Spirit Awakening Subpath |
| 4 | Ability Score Improvement or Cultivation Insight |
| 5 | Domain Pressure |
| 6 | Subpath Feature |
| 7 | Astral Projection |
| 8 | Ability Score Improvement or Cultivation Insight |
| 9 | Soul Vessel |
| 10 | Subpath Feature |
| 11 | Soul Armor |
| 12 | Ability Score Improvement or Cultivation Insight |
| 13 | Spiritual Exorcism |
| 14 | Subpath Feature |
| 15 | Domain Manifestation |
| 16 | Ability Score Improvement or Cultivation Insight |
| 17 | Soul Splitting |
| 18 | Subpath Feature |
| 19 | Ability Score Improvement or Cultivation Insight |
| 20 | Immortal Spirit |

### Ability Score Improvement or Cultivation Insight

At CL4, CL8, CL12, CL16, and CL19, choose one:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight from the central Tianxia catalogue for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight’s **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, shrine, spirit pact, bloodline awakening, reincarnated memory, office, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise.

Background ability increases and Origin Insights are separate benefits.

If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

Use the **Central Cultivation Insights** chapter as the sole Insight catalogue authority. Only entries presented as player-ready options are available by default.

---

## Spirit Awakening Subpaths

At CL3, choose one Spirit Awakening Subpath for which you have legal access. You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Classification | Meaning |
|---|---|
| **Open Tradition** | Teachable through a recognized school, shrine, profession, community, military office, or public scripture. Open access does not imply low power or common practitioners. |
| **Restricted Lineage or Scripture** | Requires a hidden teacher, guarded manual, shrine, sect, spirit pact, haunted location, initiation, profession, or controlled institution. |
| **Rare Inheritance** | Comes from bloodline, reincarnated memory, spirit ancestry, relic fusion, mutation, possession survived and integrated, divine scar, or singular transmission. |
| **Forbidden Method or Variant** | Uses condemned, coercive, predatory, destabilizing, politically prohibited, or spiritually hazardous practices. Forbidden is not automatically Daemonic. |
| **Secret Law** | Direct law-level authority requiring explicit discovery and its printed initiation price. |
| **Daemonic** | A mechanical tag only when a Source Rule interacts with Corruption, daemonic energy, purification, or anti-daemonic rules. Social accusation does not create this tag. |

A character normally has one Subpath progression. A future parent or Variant lineage uses its printed replacement procedure rather than granting a second simultaneous progression.

A Subpath does not grant general access to a thematically similar Sphere. A Dreamweaver does not automatically learn Dreams; a Mirror Speaker does not automatically learn Illusion or Space; an Ancestral Channeler does not automatically learn Spirit Companions or Death. Only an explicit Source Rule grants a Sphere or talent.

---

## CL1 — Soulward Response

**Action Type:** Reaction  
**Trigger:** You fail an Intelligence, Wisdom, or Charisma saving throw.  
**Cost:** 1 Resonance  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Soulward Response:

- is not saving throw proficiency;
- is used after you learn that the roll failed;
- cannot modify a death saving throw;
- cannot modify a breakthrough, training, forging, or ordinary ability check;
- cannot modify the same saving throw more than once;
- cannot stack with another feature that adds Proficiency Bonus to the same saving throw;
- does not automatically end an ongoing effect unless the successful-save result says it does.

At CL11, Soul Armor improves this response.

---

## CL1 — Spiritual Sense

Spiritual Sense is always active unless suppressed.

### Range

| CL | Range |
|---:|---:|
| 1–10 | 10 feet |
| 11–16 | 30 feet |
| 17–20 | 60 feet |

Within range, you perceive active souls, spirits, possessing entities, projected souls, spiritually animated corpses, and creatures with ordinary living consciousness even when normal sight cannot perceive them.

Against an ordinary living creature, Complete Soul, or spirit within range, Spiritual Sense functions as Blindsight. It does not automatically perceive:

- soulless traps or objects;
- mundane writing, color, or visual detail;
- a construct with no mind, spirit, or animating soul;
- a corpse with no active spirit or necromantic animation;
- a creature behind total cover;
- a successfully concealed soul, Secret concealment, divine veil, artifact-level masking, sealed spirit, or stronger spiritual absence.

Spiritual Sense also tells you whether a perceived entity is broadly:

- Embodied, Manifested, Hosted, possessing, projected, Unbodied, Anchored, or Contained;
- Resonance Marked by you;
- under an obvious ordinary possession, coercive Hosting, or spirit-manifestation effect.

It does not reveal exact statistics, thoughts, memories, Soul Anchor, Spirit Nature, Subpath, full Bond terms, or hidden Source Rules.

### Read the Spirit

**Action Type:** Action  
**Range:** Your Spiritual Sense range

Choose one soul, spirit, possession link, spiritual residue, Soul Fragment, or spiritual effect you perceive. Learn:

- its broad category;
- whether its Source CL is lower than, equal to, or higher than yours;
- whether it is stable, strained, damaged, concealed, Hosted, bound, possessing, Anchored, or suppressed;
- whether it is a Complete Soul, Soul Fragment, Spiritual Imprint, or uncertain mixture.

For a concealed or protected effect, make a Cultivation Check against its save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

On failure, you know that spiritual concealment or interference is present, but not its exact nature. You cannot retry until the effect changes, you obtain a new Source Rule or evidence, or a new scene begins.

---

## CL1 — Mind Spike

**Action Type:** Action  
**Range:** 60 feet  
**Target:** One creature with a mind, soul, animating spirit, or equivalent spiritual identity

The target makes a Wisdom saving throw against your Cultivation Save DC.

**Failed Save:** The target takes Psychic damage equal to the listed dice plus your Wisdom modifier and becomes Resonance Marked by you.  
**Successful Save:** The target takes half damage and is not marked.

| CL | Psychic Damage |
|---:|---:|
| 1–4 | `1d8 + Wisdom modifier` |
| 5–10 | `2d8 + Wisdom modifier` |
| 11–16 | `3d8 + Wisdom modifier` |
| 17–20 | `4d8 + Wisdom modifier` |

Mind Spike is a Spirit Awakening technique and one activation regardless of how another feature later echoes, redirects, or originates it.

Mind Spike can affect a creature without a biological brain if it has a mind, soul, animating spirit, or equivalent identity. It normally cannot affect an ordinary object, mindless construct, spiritually empty corpse, or Spiritual Imprint that has no independent ability to suffer damage.

At CL5, when a creature already Resonance Marked by you fails against Mind Spike, you may also impose one ordinary Spiritual Pressure effect on it.

### Martial and Weapon Interface

Mind Spike is not an ordinary weapon attack, unarmed strike, spell, or Attack action. A weapon, unarmed strike, natural weapon, martial Subpath, Recorded Art, or Forged Technique can deliver or modify Mind Spike only when its Source Rule expressly says so.

A martial description does not grant Extra Attack, martial weapon proficiency, weapon delivery, physical damage, or permission to substitute an attack roll for Mind Spike’s Wisdom saving throw.

---

## CL2 — Soul Gaze

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one creature you can see. You may instead choose a creature Resonance Marked by you within range even if you cannot see it, provided it is not behind total spiritual concealment.

Learn:

- its current and maximum Hit Points;
- its broad creature nature and cultivation Path, if any;
- whether its effective CL or relevant Source CL is lower than, equal to, or higher than yours;
- its damage resistances, immunities, and vulnerabilities;
- its surface emotional state;
- whether it is affected by an ordinary curse, possession, coercive Hosting, Heart Demon, dream intrusion, memory interference, spiritual contamination, Spirit Scar, or obvious soul injury;
- the broad category of one Spirit Bond, possession link, or Spiritual Anchor currently sustaining an obvious effect upon it.

Soul Gaze does not automatically reveal:

- a protected Soul Anchor;
- a spirit’s complete Nature or Bond contract;
- Secret or divine identity;
- hidden phases or unrevealed transformations;
- exact unspent Cultivation Points;
- protected memories;
- the complete text of an unknown feature;
- a concealed effect whose Source Rule defeats ordinary spiritual diagnosis.

When protected information is contested, make a Cultivation Check against the protecting effect. On failure, identify which category of information was concealed, but not its contents. You cannot retry against the same concealment until it changes, you gain new evidence, or a new scene begins.

---

## CL5 — Domain Pressure

**Action Type:** Action  
**Area:** Cone originating from you  
**Cost:** 2 Resonance

| CL | Cone Length |
|---:|---:|
| 5–10 | 15 feet |
| 11–16 | 30 feet |
| 17–20 | 60 feet |

Release a wave of spiritual authority. Each creature of your choice in the area makes a Wisdom saving throw.

**Failed Save:** The creature is Frightened of you until the end of your next turn and becomes Resonance Marked by you.  
**Successful Save:** The creature suffers one ordinary Spiritual Pressure effect of your choice until the start of your next turn.

If a creature that fails is immune to Frightened, it is not Frightened. Instead, choose two different ordinary Spiritual Pressure effects for it. These two effects are one exceptional pressure package created by this feature and may coexist until the start of your next turn.

Domain Pressure is not a full spiritual Domain, does not establish ownership over the area, and does not create an Anchor, prison, anti-teleport effect, or companion-command zone.

---

## CL7 — Astral Projection

**Action Type:** Action  
**Cost:** 4 Resonance  
**Duration:** Up to 10 minutes  
**Concentration:** No

Project your spirit from your body.

### Body and Range

Your body becomes Unconscious and remains a living creature in its space. It can be moved, damaged, healed, restrained, protected, or killed normally. Your projected spirit can travel up to 300 feet from your body. At CL15, this range becomes 1 mile.

The projection ends if:

- you return to your body;
- you dismiss it without an action;
- the duration expires;
- your body takes damage;
- your projected spirit takes damage;
- your body dies;
- you become unable to maintain a coherent soul connection;
- body and projection are separated by a barrier that explicitly blocks or severs soul connection.

When the projection ends normally, it returns by the shortest legal spiritual route. If no legal route exists because a barrier traps it, the projection remains adjacent to that barrier and you are Incapacitated until the barrier is opened, overcome, or the connection is otherwise resolved.

### One Creature, Two Positions

Your body and projection are two positions of the same creature, not two creatures.

- You have one Hit Point total, one condition set, one turn, one action economy, and one Concentration limit.
- An activation cannot affect both positions as though they were separate targets.
- Damage to either position is damage to you and ends Astral Projection after that damage resolves.
- Healing either position heals you once.
- An effect attached to you remains attached unless its own rules require a body or a projected spirit.

### Projected Spirit

While projected:

- You retain your senses, Spiritual Sense, Read the Spirit, and Soul Gaze.
- You can communicate telepathically with a willing creature within 30 feet.
- You have a Fly Speed equal to your Speed and can hover.
- During a move, you can pass through creatures and up to 5 feet of nonmagical material, but cannot end inside a creature or object.
- Wards, Seals, Formations, consecrated boundaries, spirit prisons, Domains, and Source Rules that block astral travel can stop you.
- You are invisible to ordinary sight but visible to spiritual perception and spirit-revealing effects.
- You cannot manipulate ordinary physical objects.
- You cannot make attacks, activate hostile techniques, manifest a Domain, command a full Companion, use an item, or affect the physical world unless another Source Rule expressly permits it.

An effect that can target spirits can target your projection. Use your normal AC, Hit Points, saving throws, and defenses.

Astral Projection does not create a Soul Fragment, Companion, independent manifestation, second origin for a technique, or separately acting copy of you.

---

## CL9 — Soul Vessel

You can create a stable sympathetic vessel for one spiritual relationship.

### Create or Replace the Vessel

**Time:** 10 minutes  
**Cost:** 2 Resonance  
**Target:** One Tiny nonliving object you touch

The object becomes your **Soul Vessel**, a Spirit Cultivation Asset. It may be a doll, name tablet, folded paper figure, mirror shard, prayer strip, bead, thread knot, mask, bell, carved seal, weapon tassel, reliquary, or another object capable of carrying your spiritual imprint.

You can have only one Soul Vessel. Creating another causes the previous vessel to become an ordinary object and ends its Vessel Imprint.

When separate and legally targetable, the vessel has:

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `4 × Proficiency Bonus`.
- **Immunities:** Psychic and Poison damage; Charmed, Frightened, Poisoned, Prone, and ordinary bodily conditions.
- **Source CL:** Your effective Spirit Awakening CL.

While worn or carried, use the normal rules for targeting a worn or carried object. Reducing the vessel to 0 Hit Points destroys its cultivated structure, ends its imprint, and leaves an ordinary broken object. This does not damage your soul or the imprinted target.

### Create a Vessel Imprint

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Target:** One willing creature, or one creature Resonance Marked by you

An unwilling target makes a Charisma saving throw.

**Successful Save:** No Vessel Imprint is created. The target knows you attempted the link and suffers one ordinary Spiritual Pressure effect until the start of your next turn.  
**Failed Save or Willing Target:** The Soul Vessel records a sympathetic imprint of the target.

A Vessel Imprint is not a Soul Fragment, copied soul, possession link, ownership claim, memory copy, or Spirit Bond.

#### Duration

- A willing target’s imprint persists until you dismiss it, replace it, the target withdraws consent as an Action, the vessel is destroyed, or a Source Rule severs it.
- An unwilling target’s imprint lasts until the end of the scene. The target can also use an Action to repeat the Charisma saving throw, ending the imprint on a success.

The vessel can hold only one imprint.

#### Imprint Benefits

While the imprint persists:

- The target bears your Resonance Mark, and that mark does not expire from its ordinary duration.
- While target and vessel are on the same plane and within 1 mile, you know the direction from the vessel to the target, but not exact distance or a route through spiritual concealment.
- You can use Soul Gaze on the target from the vessel at a range of 1 mile without ordinary line of sight. Total spiritual concealment, a ward that severs sympathetic links, or a higher-authority boundary still blocks it.
- The imprint supplies identity and direction only. It does not let another feature ignore its own range, cover, target, consent, or Source CL requirements.

#### Vessel Ward

**Action Type:** Reaction  
**Trigger:** A willing imprinted target within 60 feet of the vessel fails an Intelligence, Wisdom, or Charisma saving throw against a spiritual, mental, emotional, dream, memory, possession, or identity effect.  
**Cost:** 2 Resonance  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Vessel Ward cannot modify a death saving throw, cannot add Proficiency Bonus twice, and cannot combine with Soulward Response on the same saving throw.

#### Sympathetic Rite at CL13

After you gain Spiritual Exorcism, a willing imprinted target within 1 mile can be the target of your Deep Exorcism Rite without being touched. Increase the rite’s Resonance cost by 2. A barrier that blocks the Vessel Imprint also blocks the rite.

This remote rite cannot target an unwilling Host or Intruder, cannot establish a new possession target, and cannot exceed the normal authority of Spiritual Exorcism.

---

## CL11 — Soul Armor

Your cultivated identity hardens into spiritual armor.

You gain Resistance to Psychic damage.

Soulward Response gains these benefits:

- When it turns a failed saving throw into a success, you may end one ordinary Resonance Mark or ordinary Spiritual Pressure effect on yourself.
- If that successful saving throw would normally deal half Psychic damage, you instead take no Psychic damage.
- If the effect would Charm, Frighten, possess, displace, or rewrite your soul on a failed save and do nothing on a successful save, a successful Soulward Response prevents it normally.

In addition, when an effect attempts to read, alter, erase, copy, consume, imprison, or replace your memory, identity, Soul Anchor, or soul without granting a saving throw, you may use Soulward Response and make a Wisdom saving throw against the effect’s save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

On success, prevent an ordinary effect. Against an equal- or higher-authority effect, use its printed success result. If it has none, success suppresses the attempted alteration until the end of your next turn and exposes its broad Source CL and sustaining Anchor to Spiritual Sense; it does not automatically destroy the source.

---

## CL13 — Spiritual Exorcism

You can diagnose, suppress, separate, expel, cleanse, and release invasive spiritual effects. Spiritual Exorcism uses the terms and authority hierarchy in the Spirit Awakening General Procedures.

An **Intrusion** for this feature can be:

- unwilling possession or coercive Hosting;
- dream intrusion;
- spiritual contamination;
- imposed emotional corruption;
- memory interference;
- hostile spirit presence;
- a Heart Demon expression that its Source Rule permits another creature to confront;
- a curse with a spiritual, dream, memory, emotion, identity, or soul component;
- a Charmed, Frightened, or madness effect created by a supernatural mental or spiritual source.

Spiritual Exorcism cannot treat integrated spirit ancestry, a legal Path or Subpath, a Foundation, Method, Origin Insight, ordinary memory, willing stable Bond, chosen oath, or accepted presence as an Intrusion unless its own Source Rule expressly permits separation.

### Exorcism DC

Make a Spirit Awakening Cultivation Check against the Intrusion’s save DC. If it has no printed DC, use the creator’s or sustaining spirit’s Cultivation Save DC. If neither is available, use:

| Source Realm | Authority DC |
|---|---:|
| Mortal | 12 |
| Foundation | 14 |
| Core Formation | 16 |
| Nascent Soul | 18 |
| Immortal | 20 |

### Battlefield Exorcism

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 4 Resonance  
**Target:** One perceived Intrusion attached to a creature, object, location, manifestation, vessel, or Spiritual Anchor

Make the Cultivation Check. A specific Intrusion can be targeted by your Battlefield Exorcism only once per round.

**Failed Check:** The Intrusion remains. If it permits a repeat saving throw, the affected creature immediately repeats that save with Advantage. You learn the Intrusion’s broad category, Source CL band relative to you, and whether it is sustained by a creature, Bond, vessel, location, or other Spiritual Anchor.

**Successful Check:** Compare the Intrusion’s Source CL with this feature’s Source CL.

| Intrusion Authority | Result |
|---|---|
| **6 or more Source CL lower** | End one ordinary temporary Intrusion. An ordinary possession is separated and locally expelled to its legal manifestation, vessel, or nearest legal space until the end of the scene. If it has no legal external state, it becomes a visible spiritual outline occupying the Host’s space without controlling the Host. A persistent, permanent, Secret, artifact, divine, or expressly Anchored Intrusion is instead suppressed until the end of the scene and reveals one printed release or reconstruction requirement. |
| **3–5 Source CL lower** | Suppress the Intrusion until the end of the scene without Concentration. The affected creature immediately repeats one save allowed by the Intrusion with Advantage; on a success, an ordinary temporary Intrusion ends. A possessing Intruder is exposed and cannot control the Host during suppression. |
| **Within 2 Source CL** | Suppress the Intrusion until the end of the affected creature’s next turn. It immediately repeats one save allowed by the Intrusion with Advantage. If it has no repeat save, suppression is the complete battlefield result. |
| **3 or more Source CL higher** | Do not suppress the Intrusion. The affected creature immediately repeats one save allowed by it with Advantage. Its manifestation, broad origin, and direction of its sustaining Anchor are exposed to Spiritual Sense until the end of your next turn. |

A willing Host may waive resistance made on its behalf. A willing Intruder does not resist separation. When Host and Intruder both oppose separation, use the higher relevant DC.

### Deep Exorcism Rite

**Time:** 10 minutes  
**Range:** Touch, or a willing Soul Vessel imprint as described by Soul Vessel  
**Cost:** 6 Resonance, plus 2 for a remote Soul Vessel rite  
**Target:** One perceived Intrusion or Spiritual Affliction

Make the Cultivation Check.

**Failed Check:** Do not remove or suppress the effect. Learn its broad category, exact Source CL band relative to you, sustaining Anchor category, and one printed condition required to meaningfully change it. You cannot repeat the rite against that effect until the effect changes, the revealed condition is met, or your effective Spirit Awakening CL increases.

**Successful Check:** Compare Source CL.

| Intrusion Authority | Result |
|---|---|
| **6 or more Source CL lower** | End one ordinary temporary or persistent Spiritual Affliction. Separate an ordinary possessing Intruder into its legal manifestation, vessel, or nearest legal space; it cannot re-enter the same Host until the Host completes a Full Cultivation Session. A permanent, Secret, artifact, divine, Immortal, or world-law effect is removed only when its Source Rule permits; otherwise reduce its severity by one stage and reveal its exact remaining recovery procedure. |
| **3–5 Source CL lower** | End one ordinary temporary Intrusion. Reduce one persistent Spiritual Affliction by one stage, then suppress any remainder until the target completes a Full Cultivation Session. A possession is separated for the same duration into its legal manifestation, vessel, nearest legal space, or—if none exists—a visible spiritual outline occupying the Host’s space without controlling the Host. |
| **Within 2 Source CL** | Choose one: reduce the effect by one printed severity stage; or suppress it until the target completes a Full Cultivation Session. Reveal its sustaining Anchor and exact printed recovery, release, confrontation, restitution, or reconstruction requirement. |
| **3 or more Source CL higher** | You cannot remove or reduce it. Stabilize the target so the effect cannot increase in severity until the target completes a Full Cultivation Session, and reveal its sustaining Anchor category and exact printed requirement for the next meaningful intervention. |

If an effect has no severity stages, “reduce by one stage” means remove one separately printed escalation, rider, or consequence. If none exists, use the suppression result instead.

Spiritual Exorcism cannot:

- destroy a Complete Soul without an explicit Source Rule;
- transfer ownership of a spirit;
- convert an unwilling spirit into your Companion;
- erase integrated spirit ancestry;
- remove a legal character option;
- end completed death, reincarnation, permanent soul destruction, or divine custody without explicit authority;
- invent a release condition, quest, sacrifice, price, or reconstruction procedure where the Source Rule provides none.

When complete removal is impossible, the feature must still provide the printed lesser result and diagnostic information.

The central Cultivation Insight **Exorcist’s Calling** grants a limited earlier version and improves when you gain this feature.

---

## CL15 — Domain Manifestation

**Action Type:** Bonus Action  
**Cost:** 6 Resonance  
**Area:** 30-foot aura centered on you  
**Duration:** The scene  
**Concentration:** No  
**Domain Type:** Personal Domain

Manifest the spiritual truth seeded by your Soul Anchor and refined through your Subpath. Record its sensory expression when you gain this feature. That description grants no additional effect.

The Domain moves with you and ends when you are Incapacitated, willingly end it, leave the scene, become unable to manifest Path features, or a Source Rule suppresses or breaks it.

A creature is affected while inside the aura. Entering the aura does not itself trigger a saving throw unless a Source Rule says so.

### Anchored Allies

Allies of your choice in the Domain have Advantage on Intelligence, Wisdom, and Charisma saving throws against:

- Charmed and Frightened;
- possession and coercive Hosting;
- dream intrusion;
- memory alteration;
- emotional domination;
- soul displacement.

You may revise which willing creatures count as allies at the start of your turn without an action. You cannot designate an unwilling hostile creature as an ally merely to bypass its protection or Bond terms.

### Unfading Marks

Your Resonance Marks on creatures in the Domain do not expire from duration. A mark ends normally when the creature leaves the Domain, the Domain ends, or another effect removes it.

### Domain Pressure

Once on each of your turns, when a creature in the Domain fails a saving throw against one of your Spirit Awakening Path or Subpath features, impose one ordinary Spiritual Pressure effect on it without additional cost.

This can occur only once during the turn, regardless of the number of failed saves, targets, echoes, or origins created by the activation.

### Revealed Spirits

Within the Domain, Spiritual Sense detects ordinary invisible spirits, possession links, Hosted entities, projected souls, Soul Fragments, and lower-Source-CL spiritual disguises without a check. Equal- or higher-authority concealment remains contested.

### Subpath Domain Expression

A Subpath may grant an additional Domain expression. That expression modifies this one Domain; it does not create a second Domain, second aura, second turn, or additional Concentration slot unless it explicitly says otherwise.

### Domain Collision

Compatible Domains coexist. When two Domain expressions impose contradictory laws upon the same target, space, Bond, route, or effect, compare Source CL. Equal Source CL uses a Cultivation Check contest. Losing suppresses only the contradictory expression, not the entire Domain, unless a Source Rule expressly says the whole Domain collapses.

A Domain is not automatically a Spiritual Anchor, prison, anti-teleport field, sanctuary, spirit court, Companion command zone, or law over every soul inside it.

At CL20, the Domain’s radius becomes 60 feet and its activation cost becomes 4 Resonance.

---

## CL17 — Soul Splitting

**Action Type:** Action  
**Cost:** 8 Resonance  
**Duration:** The scene  
**Concentration:** No

Split off one cultivated fragment of your Complete Soul in an unoccupied legal space within 30 feet. The fragment is a Spirit Cultivation Asset, not a duplicate character.

### Soul Fragment Profile

- **Size:** Tiny or Small, chosen when created.
- **AC:** Your Cultivation Save DC.
- **Hit Points:** `5 × Proficiency Bonus`.
- **Speed:** Fly 40 feet; hover.
- **Saving Throws:** Uses your Intelligence, Wisdom, and Charisma saving throw bonuses.
- **Resistance:** Psychic damage.
- **Immunities:** Poison damage, Disease, Poisoned, Prone, Grappled, Restrained, and ordinary bodily effects.
- **Physical Interaction:** Ordinary noncultivated attacks cannot damage it unless their Source Rule can affect spirits. Cultivated, magical, spiritual, artifact, divine, or expressly spirit-affecting attacks can.
- **Source CL:** Your effective Spirit Awakening CL.

The fragment has no independent turn, Action, Bonus Action, Reaction, Concentration, inventory, attunement, Cultivation Point pool, Path, Subpath, Sphere list, or Companion command authority.

At the end of each of your turns, it can move up to its Speed. This movement is part of Soul Splitting and is not your movement.

### Second Origin

When you activate one Spirit Awakening Path or Subpath feature, choose yourself or the fragment as its point of origin if the feature can legally originate from a spirit. You still activate the feature once, pay one cost, use one action, and obey every once-per-activation, once-per-turn, and once-per-target limit.

Measure range, area, cover, and line of effect from the chosen origin. You must still perceive the target by a method the feature permits. The fragment does not let a feature pass through total spiritual concealment or an illegal destination.

The fragment must remain within 300 feet of you. If forced beyond that range, it returns immediately to the nearest legal space within range by the shortest legal spiritual route. If no route exists, Soul Splitting ends safely unless the separating Source Rule expressly severs the fragment.

### Fragment Expression

Once on each of your turns, after you spend Resonance on a Spirit Awakening Path or Subpath feature or use Mind Spike, choose one expression. This requires no additional action and is part of the triggering turn.

- **Echo Spike:** One creature Resonance Marked by you within 60 feet of the fragment takes Psychic damage equal to your Wisdom modifier + Proficiency Bonus.
- **Maintain Pressure:** One creature Resonance Marked by you within 60 feet of the fragment suffers one ordinary Spiritual Pressure effect until the start of your next turn.
- **Guard Soul:** One ally within 30 feet of the fragment gains Temporary Hit Points equal to `2 × Proficiency Bonus` and Advantage on the next Intelligence, Wisdom, or Charisma saving throw it makes before the start of your next turn.
- **Subpath Expression:** Use one Soul Splitting expression expressly granted by your Subpath.

You can use only one Fragment Expression per turn. An expression cannot trigger itself, generate another Fragment Expression, or turn the fragment into a second attacker unless its Source Rule expressly creates an attack and pays for it.

### Ending, Severance, and Destruction

You may end Soul Splitting without an action, causing the fragment to return safely.

If the fragment is reduced to 0 Hit Points or destroyed by a legal spirit-affecting effect:

- you take `4d10` Psychic damage that ignores Resistance;
- Soul Splitting ends;
- you cannot use Soul Splitting again until you complete a Full Cultivation Session.

Destroying the fragment does not destroy your Complete Soul or Soul Anchor unless an explicit higher-authority Source Rule says so and prints the resulting injury and reconstruction procedure.

You may have only one core Soul Fragment at a time. It cannot activate Sphere talents, items, Recorded Arts, Forged Techniques, Immortal Arts, Companions, other summons, or another Soul Splitting.

A Subpath may expressly sacrifice or destroy the fragment and waive some normal backlash. Such an exception applies only to that printed sacrifice.

---

## CL20 — Immortal Spirit

Your awakened soul becomes an immortal spiritual structure rather than a mortal consciousness dependent upon one body.

### Ageless Soul

You cease aging unless you choose otherwise. Ordinary aging cannot reduce your abilities or kill you.

You do not require food, drink, air, or sleep to keep your soul alive, though your current body may still require them unless a separate feature changes its physiology. You still require rests and Cultivation Sessions to recover features whose rules require them.

### Sovereign Identity

An ordinary effect and any effect with lower Source CL cannot, against your will:

- Charm or Frighten you;
- possess or coercively Host within you;
- permanently alter or erase your memory;
- replace your identity;
- consume, destroy, imprison, redirect, or prevent the passage of your Complete Soul;
- permanently sever you from your Soul Anchor.

Equal- or higher-authority effects use their printed procedure. If no procedure is printed, make a Wisdom saving throw against the effect’s save DC; if it has none, use a Cultivation Check contest. Success prevents the attempted permanent result but does not destroy the source.

This protection does not make you immune to persuasion, grief, voluntary bargains, chosen Hosting, chosen memory alteration, lawful consequences, self-created Heart Demons, or the ordinary consequences of your own decisions.

### Continue Without the Body

If your body dies while your Complete Soul remains free, you persist as a coherent Unbodied spirit for up to 30 days.

During this state:

- You can perceive and communicate.
- You can use Spiritual Sense, Read the Spirit, and Soul Gaze.
- You cannot make hostile attacks, spend Resonance, manifest a Domain, command a full Companion, manipulate ordinary objects, or activate techniques unless a Source Rule specifically permits bodyless action.
- You can travel as Astral Projection with no distance limit on the same plane, but wards, Domains, spiritual boundaries, and routes still apply.
- You remain one Complete Soul and are not a Companion, Cultivation Asset, or Soul Fragment.

If you are imprisoned, claimed, reincarnated, destroyed, or prevented from reaching an Anchor by an equal- or higher-authority Source Rule, resolve that rule before Return to the Anchor.

### Immortal Restoration Capacity

**Limit:** Once per 28 days

Return to the Anchor and Call Back the Departed use the same capacity. Using either prevents use of the other until 28 days have passed.

### Return to the Anchor

While bodyless, spend 7 uninterrupted days at your Soul Anchor, a compatible prepared spirit vessel, or a location explicitly accepted by your Soul Anchor.

If your death and any effect blocking return have lower Source CL, you return automatically in a recreated body with:

- 1 Hit Point;
- 0 Resonance;
- 3 levels of Exhaustion;
- your Path, Subpath, known Spheres, talents, Method, Foundation, Soul Anchor, Insights, and learned techniques intact unless the effect that killed you expressly damaged one of them.

If the death effect or return barrier is within 2 Source CL and has no printed return procedure, make one Cultivation Check against its save DC at the end of the 7 days. If it has no DC, use the Authority DC for its Realm from Spiritual Exorcism.

- **Success:** You return as above.
- **Failure:** You do not expend the 28-day capacity. Learn the exact Anchor, authority, or printed condition preventing return. You cannot retry until that condition changes.

If the death effect or return barrier is 3 or more Source CL higher, you cannot return unless its printed recovery condition has already been met. The 7-day attempt reveals that condition but does not expend the 28-day capacity.

A destroyed Complete Soul, completed reincarnation, or voluntary refusal to return cannot be bypassed by this feature.

### Call Back the Departed

**Time:** 8 hours  
**Cost:** 10 Resonance, paid when the rite begins  
**Target:** One willing dead creature whose Complete Soul remains reachable

You require at least one:

- the body or meaningful remnant;
- the creature’s true or chosen name;
- its Soul Anchor or equivalent identity Anchor;
- a relic, oath, descendant, bonded spirit, or location with a profound recorded connection to it.

If the soul is free and the death effect has lower Source CL than this feature, restore the creature in a whole body with 1 Hit Point and 3 levels of Exhaustion.

If the death effect or custody is within 2 Source CL, make a Cultivation Check against its save DC. If it has no DC, use the Authority DC for its Realm.

- **Success:** Restore the creature as above.
- **Failure:** The rite does not expend the 28-day capacity or its Resonance cost. Learn the exact barrier or printed recovery condition. You cannot retry until it changes.

If the death effect or custody is 3 or more Source CL higher, the rite cannot restore the creature unless its printed recovery condition has already been met. The rite reveals that condition but does not invent a quest, payment, sacrifice, or exception.

Call Back the Departed cannot restore a creature that refuses, has completed reincarnation, whose Complete Soul has been permanently destroyed, or whose Source Rule declares the death final against this authority.

---

## Spirit Companions and Independent Spirits

Spirit Awakening and the Sphere of Spirit Companions interact closely, but they are not the same system.

### Spirits Are Independent Beings

A spirit can be natural, ancestral, embodied, object-born, cultivated, office-bearing, parasitic, or another recorded origin. A Complete Spirit has its own personhood, Nature, Source CL, appetite, sustenance, temperament, goals, cultivation, evolution, embodiment state, permissions, and relationships.

Perceiving, naming, feeding, summoning, Hosting, or being stronger than a spirit does not make it property.

Spirit ancestry is integrated personhood, not possession or a removable Intruder, unless a specific lineage rule states otherwise.

### What the Path Does Not Grant

Spirit Awakening does not automatically grant:

- the Sphere of Spirit Companions;
- a Minor Agreement or Major Spirit Bond;
- a full combat Companion;
- a spirit stat block;
- Nature Spheres known by the cultivator;
- permission to bind an unwilling spirit;
- Companion action economy;
- permission to place a spirit in a body, object, weapon, shrine, dream, shadow, dantian, or Soul Anchor.

### Spirit Nature Belongs to the Spirit

A bonded, Hosted, or manifested spirit may express legal Spheres through its Spirit Nature. Those Spheres belong to the spirit unless the cultivator separately learns them.

The cultivator may coordinate the relationship and pay Resonance when a Source Rule requires it, but does not thereby know the spirit’s Spheres or own its techniques.

### Relationship Tiers

Distinguish among:

- ordinary contact or negotiation;
- Minor Spirit Agreement;
- Major Spirit Bond;
- Hosting Bond;
- Binding Seal;
- Manifesting Spirit Source;
- full combat Companion.

A Bond is not automatically a full Companion. A full Companion requires an explicit legal upgrade and a complete record under the Bonded Companions rules.

Every significant Bond must record consent, permissions, mutual benefits, sustenance, Offerings, Taboos, Bond Strain triggers, crises, action economy, manifestation, withdrawal, destruction, reconstruction, and renegotiation.

### Core Feature Interaction

- Spiritual Sense can perceive a bonded, Hosted, possessing, or manifested spirit unless stronger concealment applies.
- Soul Gaze can identify broad Bond status, embodiment, and strain, but not hidden contract terms without permission or a successful contest.
- Soul Vessel can carry a sympathetic imprint of a spirit under its normal target and consent rules; it does not bind the spirit.
- Spiritual Exorcism cannot remove a willing stable Bond or integrated ancestry as though it were an Intrusion.
- Domain Manifestation can protect a bonded spirit inside it but grants no additional turn, expression, or command authority.
- Soul Splitting does not create, copy, or duplicate a Companion.
- A spirit used as a Soul Anchor remains a relationship and identity source unless separately given an Asset or Spiritual Anchor profile.

### Coercive Bonds

A Binding Seal is not friendship. Coercive commands that violate a spirit’s Nature, Need, consent, or Taboo use Bond Strain and the consequences printed by the Spirit Companions rules.

High Wisdom, stronger Source CL, or Spirit Awakening Path access does not erase those consequences.

---

## Realm Suppression — Spirit Awakening Summary

When a Spirit Awakener suppresses to a lower effective CL:

- use the suppressed Proficiency Bonus where the universal Realm Suppression rule requires it;
- reduce dependent Path, Subpath, Domain, possession, and spirit-effect Source CL to the suppressed effective CL;
- do not activate or benefit from Path or Subpath features whose minimum CL exceeds the suppressed CL;
- use lower-CL scaling where a lower version exists;
- Domain Manifestation ends if effective CL falls below 15;
- a core Soul Fragment returns safely if effective CL falls below 17, unless another effect violently severed it;
- Astral Projection ends if effective CL falls below 7;
- the cultivated structure of a Soul Vessel remains, but Vessel Ward and other expressions above the suppressed CL become dormant.

Realm Suppression does not reduce or erase:

- Hit Points or Hit Dice;
- maximum Resonance;
- the existence of the Soul Anchor;
- ordinary memories, personality, identity, ancestry, relationships, oaths, or consent;
- passive Foundation quality;
- an independent spirit’s statistics unless its Source Rule scales directly from the suppressed cultivator;
- a Bond, Offering, Taboo, debt, injury, Spirit Scar, possession, custody, or consequence already created.

Suppression does not itself exorcise, sever, expel, destroy, free, or transfer a spirit. An active effect you can no longer maintain ends or becomes dormant as its Source Rule states. If the rule does not state where a Hosted or possessing spirit goes when suppressed, use the Spirit Awakening General Procedures rather than inventing a destination.

Realm Suppression cannot refund Resonance, erase setup requirements, avoid a Bond crisis, or make an existing consequence count as lower authority after the fact.

---

## Realm Identity

| Realm | Spirit Awakening expression |
|---|---|
| **Mortal, CL1–4** | Soul Anchor, mental defense, spiritual perception, Resonance Marks, direct Mind Spike, diagnosis |
| **Foundation, CL5–9** | Spiritual Pressure, astral projection, stable sympathetic Soul Vessel, first Subpath mastery |
| **Core Formation, CL10–14** | Hardened soul defense, universal Spiritual Exorcism, advanced tradition authority |
| **Nascent Soul, CL15–19** | Personal Domain, cultivated Soul Fragment, remote origins, perfected spiritual perception |
| **Immortal, CL20** | Sovereign identity, body-independent continuity, self-reconstruction, restoration of reachable souls |

---

# 07. Cultivation Insights

A **Cultivation Insight** is a lasting realization, adaptation, discipline, inheritance, relationship, mutation, or cultivated truth that changes what a character can do. Insights are one central advancement system shared across Paths, Spheres, Subpaths, Foundations, Methods, bloodlines, spirit relationships, offices, scars, and other sources.

This chapter contains the complete rules for selecting and using Insights, a curated set of 72 campaign-common options, recommended Insight routes for the three orthodox Paths, and an index of the complete 451-Insight catalogue. The full rules text for every option appears in **Tianxia: Cultivation Insights Compendium**.

Cultivation Insights are one central character-option system shared across Paths, Spheres, Subpaths, inheritances, offices, pacts, scars, mutations, and cultivated realizations. A Path may provide Insight selection levels, but no Path owns a separate Insight subsystem.

## Level selection

At CL4, CL8, CL12, CL16, and CL19, when a Path progression offers an Ability Score Improvement or Cultivation Insight, choose one:

- take the normal Ability Score Improvement; or
- select one Cultivation Insight for which you meet every prerequisite.

A level-selected Insight grants its printed benefit and increases one ability score listed in **Ability Increase (Level Selection)** by 1, to the maximum permitted by the character's current Realm.

An Insight gained through a manual, tribulation, relic, shrine, spirit pact, sect instruction, bloodline awakening, reincarnated memory, office, experimentation, story reward, or another non-level source grants only its cultivation benefit unless that source expressly grants the ability increase.

## General limits

- Meet every printed prerequisite when the Insight is gained.
- Unless marked **Repeatable**, select an Insight once.
- A Path affinity, role tag, suggested Subpath, or AI recommendation is search metadata only and never grants access.
- If an Insight grants a new Sphere, gain the normal free talent granted whenever a character learns a new Sphere. The Insight does not waive Secret, Restricted, inherited, ethical, initiation, or narrative access.
- Use the effective Source CL identified by the Insight. If none is printed, use the Source CL of the Path, Sphere, Subpath, item, pact, or other Source Rule supplying the effect.
- A Path-resource or Cultivation Point cost cannot be reduced below 1 unless a rule expressly permits 0. Cost reductions do not stack on one activation unless expressly allowed.
- Copying, repeating, accelerating, or extending a technique does not waive consumed materials, sacrifices, Corruption, Impurity, item charges, maximum-resource costs, vows, Offerings, or other nonstandard prices.
- An Insight does not duplicate a weapon, Artifact, consumable, Companion, spirit, Formation Anchor, body Asset, or other cultivated Asset.
- One activation cannot deliver the same attack, poison, weapon rider, Insight rider, or Forged Technique rider multiple times unless the Source Rule expressly authorizes and prices each delivery.

## Body-linked rules

Body-linked Insights use Chapter 04 for Path features and the Body Refining player procedures and Subpath compendium for anatomy, Injury, reconstruction, transformation, natural weapons, integrated weapons, bodily Assets, mitigation, movement, restraint, external projection, Realm Suppression, Foundation interaction, and Subpath-specific states.

A Body-linked Insight does not create external projection unless it records an origin, range, legal target, action and cost, attack or save, duration, line of effect, medium, Source CL, and suppression procedure. Additional limbs or anatomy do not create extra actions or attacks unless printed. Regeneration and body-material production cannot be farmed for unlimited resources.

## Spirit-linked rules

Spirit-linked Insights use Chapter 06, the Spirit Awakening Rules Reference, the Bonded Companions rules, and the Spirit Companions Sphere where applicable.

## Central Insight execution definitions

These definitions apply whenever an Insight uses one of the following terms.

### Qualifying hostile source

A creature, hazard, Asset, Anchor, or effect is a **qualifying hostile source** when all of the following are true:

- it is not controlled by you or a willing ally;
- it was not created, invited, or damaged solely to trigger the Insight;
- it is acting against you, an ally, or a scene objective; and
- its Source CL is no more than 5 lower than yours, or it can inflict Hit Point loss, a condition, forced movement, resource loss, objective loss, or another printed consequence that matters in the current scene.

### Qualifying creature

A **qualifying creature** is an independent creature with a complete creature record that is not an illusory duplicate, disposable training construct, harmless summon, or closed-loop resource source. It qualifies if its Source CL is no more than 5 lower than yours or it is named, controls a scene objective, carries a relevant oath or relationship, or can impose a printed consequence on the scene.

### Qualifying event or meaningful scene

An event or scene qualifies when at least one of the following is true:

- a qualifying hostile source participates;
- failure can cause Hit Point loss, Cultivation Point loss, a condition, item or Asset loss, positional loss, mission failure, legal or sectarian consequence, or a change to an oath, debt, Bond, or custody record;
- the event creates, ends, or materially changes a project, relationship, Injury, transformation, or spiritual state; or
- a Source Rule expressly identifies it as qualifying.

Staged exchanges, willing damage loops, repeated harmless tests, and effects created solely to refund their own cost do not qualify.

### Recorded legal access

A choice that requires **recorded legal access** must identify the manual, teacher, lineage, office, license, relic, pact, sect permission, bloodline, or other Source Rule that grants access. A Path affinity, recommendation, or thematic similarity is not access.

### Project contribution

An Insight that contributes a principle, Mandate, presentation, technique, or tool to a project does not create the project by itself. The project record must state its objective, work time, materials, contributors, Source CL, maintenance, and vulnerability. Unless the Insight prints another benefit, one qualifying contribution grants one of the following once per project phase:

- Advantage on one project check made by a contributor;
- a reduction of 10 percent in the remaining ordinary labor time; or
- qualification as one required trained contributor or required conceptual component.

The same Insight cannot grant more than one of these benefits to the same project phase.

### Ordinary, higher-authority, and stronger effects

An **ordinary** effect is a non-Secret effect whose Source CL is no higher than yours. A **higher-authority** or **stronger** effect has a higher Source CL, is Secret or Artifact authority, or expressly overrides the relevant defense. These terms never permit the adjudicator to invent a new immunity or cost.

### Insight dormancy and restitution

When an Insight states that violating its discipline makes it dormant, its ability-score increase remains. Its cultivation benefit becomes inactive until the listed restitution is completed. Unless the Insight prints another restitution, the default is a Full Cultivation Session devoted to reflection plus one concrete corrective act toward a creature or community harmed by the violation.

### Insight cadence

- **Once per scene** resets when a new scene begins.
- **Once between Full Cultivation Sessions** resets only after completing a Full Cultivation Session.
- A **10-minute preparation or recovery procedure** requires uninterrupted work and cannot be completed during Initiative unless a rule expressly permits it.
- A prepared choice that lasts until the next Full Cultivation Session remains active through ordinary rests.

## Core PHB Catalogue

The Insights below were selected for the PHB because they are broadly useful, introduce common cultivation roles, and avoid Rare, Forbidden, Secret, bloodline-locked, organization-exclusive, or highly specialized Subpath dependencies. Their inclusion here does not make them universally available: every printed prerequisite and access requirement still applies.

### General Qi Insights

#### Expanded Dantian

**Prerequisite:** Qi Cultivation, CL4+  
**Repeatable:** Twice

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase your maximum Qi by:

`2 × your Proficiency Bonus`

Recalculate this increase whenever your Proficiency Bonus changes.

If selected twice, both increases apply.

#### Meridian Economy

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, after a Qi-powered feature resolves successfully and you actually paid at least 2 Qi for that activation, regain 1 Qi.

Meridian Economy:

- Resolves after the complete feature.
- Does not reduce the feature's cost.
- Does not trigger from refunded Qi.
- Does not trigger when the final amount actually paid was 0 or 1 Qi.
- Cannot trigger itself or create a closed refund loop.
- Functions alongside Golden Core Efficiency because it is recovery rather than a cost reduction.

#### Thunderstep

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, immediately after you spend Qi on a feature that resolves successfully, move up to 10 feet without provoking Opportunity Attacks.

At CL12, this movement may:

- Travel vertically along a wall.
- Cross an unsupported gap.
- Move across a liquid surface.

You must end on a legal supporting surface unless another feature supports you.

If Circulating Golden Core also triggers, you may use both movements or combine them into one continuous movement.

#### Fivefold Conversion

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When activating a Qi-powered feature that deals Acid, Cold, Fire, Lightning, or Thunder damage, spend 1 additional Qi to change any amount of that damage to another type from the same list.

Declare the conversion before attack rolls or saving throws are resolved.

The conversion:

- Changes damage type.
- Does not automatically change the feature's Sphere, elemental, weather, or metaphysical tags.
- Does not add a rider belonging to the new damage type.
- Applies once across a Barrage, area, or multiattack activation.
- May convert technique damage delivered through a weapon, but does not convert ordinary weapon damage unless the delivery rule explicitly permits it.

At CL16, you may instead spend 2 additional Qi to convert the chosen damage to Force.

#### Meridian Overchannel

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature deals damage or restores Hit Points, spend additional Qi up to your Proficiency Bonus.

Add `1d8` to one damage or healing roll for each additional Qi spent.

For every Qi spent beyond the first 2, take `1d8` Force strain after the feature resolves.

Force strain from this Insight:

- Cannot be reduced.
- Cannot be prevented.
- Cannot be redirected.
- Cannot be converted into another damage type.
- Cannot generate Qi, charges, Temporary Hit Points, or retaliatory effects.

Meridian Overchannel adds dice to one roll, not once per target, projectile, attack, or healing recipient.

#### Elemental Counterflow

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You take Acid, Cold, Fire, Lightning, or Thunder damage.  
**Cost:** 2 Qi

Gain Resistance to the triggering damage type against that damage packet.

After damage resolves, choose one:

- Move 10 feet without provoking Opportunity Attacks.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.
- Your next damaging Qi-powered feature before the end of your next turn may deal the triggering damage type.
- Move your Domain Armament up to 20 feet.

Elemental Counterflow cannot respond to damage you willingly dealt to yourself solely to trigger it.

#### Qi Devourer

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When an essence-bearing creature within 60 feet is reduced to 0 Hit Points after you damaged it during the current scene, you may consume a portion of its escaping cultivated essence without using an action.

Regain Qi equal to the lower of:

- Your Proficiency Bonus.
- The creature's CL, minimum 1.

You may use Qi Devourer once per round.

A creature yields essence to you once until its life-force, spirit, or cultivation has been fully restored. Repeatedly reviving the same depleted creature does not refresh it unless the restoration effect explicitly rebuilds the consumed essence.

A construct, illusion, projected clone, summoned disposable body, or creature you created solely as a refund engine does not yield essence unless it possesses an independent genuine soul, life-force, or cultivation source.

Qi Devourer can be used on captives, condemned enemies, sacrificial victims, or willing donors when they genuinely possess consumable essence. Such use may be criminal, forbidden, praised, tolerated, or condemned according to the culture involved; it does not automatically gain the Daemonic tag.

#### Heaven's Conduit

**Prerequisite:** Qi Cultivation, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Limit:** Once per scene

Regain 10 Qi and gain 1 level of Exhaustion.

The Exhaustion:

- Cannot be prevented.
- Cannot be transferred.
- Cannot be removed before the current scene ends.
- Can accumulate if you use Heaven's Conduit in later scenes before recovering.

If the regained Qi would exceed your maximum, the excess becomes unstable overflow that disappears at the end of the current turn.

#### Meridian Fortress

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws and Cultivation Checks against:

- Qi drain.
- Maximum-Qi reduction.
- Meridian sealing.
- Forced cost increases.
- Cultivation Point theft.
- Effects preventing Qi recovery.

Once per round, when a hostile effect would reduce your current Qi or maximum Qi, reduce that loss by your Proficiency Bonus.

If you possess Stable Golden Core, add this reduction to Stable Golden Core's reduction. This is an explicit stacking exception.

Meridian Fortress does not reduce Qi you willingly spend or sacrifice.

#### Refined Meridian Regulation

**Prerequisite:** Meridian Regulation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Meridian Regulation gains a range of 10 feet when used through direct Qi projection, a needle, a medical implement, or your Domain Armament.

You may also target:

- Charmed caused by a poison, drug, disease, bodily parasite, or meridian disturbance.
- Blinded or Deafened caused by smoke, ash, poison, pressure, or a directly impaired organ.
- One ordinary Bleeding effect.
- One temporary meridian blockage.

Against an effect whose Source CL is lower than yours, a successful repeated save also suppresses its ongoing damage until the end of the target's next turn.

This Insight does not allow Meridian Regulation to remove a Curse, Tribulation, Foundation Injury, Hidden Injury, permanent transformation, completed possession, Soul Damage, or conceptual severance unless another Source Rule expressly expands it.

#### Restorative Circulation

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature restores Hit Points to one or more creatures, choose one recipient.

Increase the healing it receives by your Proficiency Bonus.

If the target is already at maximum Hit Points after the healing, it instead gains Temporary Hit Points equal to your Proficiency Bonus.

At CL12, when the chosen target is at 0 Hit Points, increase the healing by `2 × your Proficiency Bonus` instead.

Restorative Circulation applies once per activation, not once per healing die, target, pulse, or repeated tick.

#### Qi-Tempered Concentration

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You fail a Constitution saving throw to maintain a Qi-powered feature.  
**Cost:** 2 Qi

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency and cannot modify the same saving throw more than once.

At CL15, this Insight improves Independent Concentration:

- Independent Concentration may protect any cultivation feature you maintain, not only a Qi feature.
- When Independent Concentration turns failure into success, choose one: move 5 feet without provoking Opportunity Attacks, move your Domain Armament 10 feet, or gain Temporary Hit Points equal to your Proficiency Bonus.

### General Body Refining Insights

#### Mountain-Forged Frame

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Gain Proficiency in Athletics. If you already have Athletics Proficiency, instead gain a +2 Insight bonus to Athletics checks. This bonus does not count as a second Proficiency and does not multiply with Expertise.

Immediately after Stamina Guard resolves, you gain Advantage on the next saving throw or ability check you make before the start of your next turn to resist being pushed, pulled, knocked Prone, Grappled, or Restrained. The benefit ends after one qualifying roll.

#### Meridian-Breath Discipline

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You have Advantage on Constitution saving throws caused by suffocation, smoke, altitude, inhaled hazards, or environmental pressure, and you can hold your breath for 1 hour.

**Breath Recovery — Once per scene.** Immediately after you use Stomping Step and its movement or Disengage benefit resolves, regain 1 Stamina, not above your maximum. An invalid or prevented Stomping Step does not trigger this recovery.

#### Iron-Blood Circulation

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

You have Advantage on saving throws against Bleeding, Poison, Disease, and Exhaustion caused by physical injury.

**Blood-Circulation Procedure.** After at least 10 uninterrupted minutes of breathing, pressure-point work, bandaging, or medicinal circulation, regain Hit Points equal to `2 × your Proficiency Bonus`. You can benefit from this procedure once between Full Cultivation Sessions. It does not remove an Injury, restore missing anatomy, or replace required treatment.

#### Living Siege Engine

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Your unarmed strikes deal triple damage, rather than double damage, to unattended ordinary objects, structures, vehicles, temporary barriers, Formation Anchors, and defined terrain sections. Against those targets, ignore the first 10 points of ordinary hardness or damage threshold.

This Insight does not bypass an Artifact, Immortal material, Secret protection, world-law barrier, explicit indestructibility, or a target whose rule prohibits structural multipliers.

#### Brutal Momentum

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Trigger — Once per turn:** You push a hostile creature at least 10 feet, knock a hostile creature Prone, reduce a hostile creature to 0 Hit Points, break an object or structure with a complete AC and Hit Point record, or one that controls a current scene objective, destroy a barrier or Formation Anchor, or escape a hostile Grapple or Restrained effect.

After the triggering event fully resolves, move up to 10 feet without provoking Opportunity Attacks. This is granted movement; it requires a legal destination and cannot pass through a barrier or occupied space unless another rule permits it. Repeatedly breaking trivial objects or cooperating with allies does not qualify.

#### Unyielding Grip

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Strength or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

A creature Grappled by you has Disadvantage on checks or saving throws it makes to escape that Grapple.

Once per turn, when a creature fails a roll to escape your Grapple, it takes Bludgeoning damage equal to your Proficiency Bonus. This damage is attributed to you but is not an attack and cannot trigger itself.

#### Tempered Reflexes

**Prerequisite:** Body Refining, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

**Reflexive Reversal — Once per scene:** When you fail a Dexterity saving throw, reroll it and use the new result. A die cannot be rerolled more than once by this Insight.

After you use Stomping Step to Disengage, you have Advantage on the next Dexterity saving throw you make before the start of your next turn. This Advantage may apply to the reroll if its timing is legal.

#### Refined Natural Weapon

**Prerequisite:** Body Refining, CL4+

**Repeatable:** Multiple; choose a different bodily weapon each time

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one recorded bodily weapon and choose Bludgeoning, Piercing, or Slashing damage. That bodily weapon is a natural weapon and may be used for Iron Fist attacks. Record its anatomical structure and whether an Injury to that structure disables it.

Once per turn when you hit with the chosen bodily weapon, choose one:

- deal additional damage of the weapon's selected type equal to your Proficiency Bonus;
- push the target 5 feet;
- prevent the target from taking Reactions until the start of its next turn; or
- gain Advantage on your next Grapple or Shove roll against that target before the end of the current turn.

Choose only one option for one hit. The additional damage is part of the hit and cannot be delivered again by copying the same attack.

#### Internal Weapon Scripture

**Prerequisite:** Body Refining, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Choose one printed weapon group or one recorded bodily-weapon tradition. You may use Constitution instead of Strength or Dexterity for attack and damage rolls with a weapon in that group or tradition.

At CL5, those attacks count as magical and cultivation-powered for overcoming ordinary Resistance. At CL17, Heavenly Fist also causes them to count as adamantine and grants its other printed benefits.

This Insight grants no weapon Proficiency, Sphere, extra attack, reach, or damage die. If the selected group is too broad to identify mechanically, record the exact weapons included when the Insight is gained.

#### Refined Golden Bell

**Prerequisite:** Golden Bell Circulation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

Whenever you activate Golden Bell Circulation, choose one refinement for that activation. It lasts until that activation ends:

- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`;
- gain Advantage on all checks and saving throws against forced movement and being knocked Prone;
- gain Resistance to Force damage; or
- reduce the first damage packet applied to you during each round by your Proficiency Bonus.

The last reduction resolves in the normal damage-ordering procedure after percentage modifiers and before other flat reductions unless a rule states otherwise. Reactivating Golden Bell Circulation replaces the selected refinement.

#### Blood-Furnace Heart

**Prerequisite:** Blood Pump, CL16+

**Ability Increase (Level Selection):** Increase your Constitution score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When Blood Pump successfully replaces a reduction to 0 Hit Points, choose one benefit after you are set to 1 Hit Point:

- move up to 10 feet without provoking Opportunity Attacks;
- end one ordinary Frightened condition affecting you;
- end one ordinary Grappled or Restrained condition affecting you;
- regain Stamina equal to your Proficiency Bonus, not above your maximum; or
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.

An equal- or higher-Source-CL effect that explicitly prevents the chosen removal is not ended. Movement requires a legal destination.

#### Heavenly Meridian Reconstruction

**Prerequisite:** Body Refining, CL16+

**Ability Increase (Level Selection):** Increase your Constitution or Wisdom score by 1, to the maximum allowed by your current Realm.

**Source CL:** Body Refining Source CL unless a named Sphere or other Source Rule supplies the effect.

When you complete a Full Cultivation Session, you may also complete one reconstruction treatment using Body Refining Shared Procedures R1.

- Automatically remove one Tier I ordinary lasting physical Injury whose Source CL is no higher than your Body Refining Source CL.
- For a Tier II Hidden Injury, you may make its treatment check as part of the session and have Advantage if it was already diagnosed.
- A Tier III crippled structure or Tier IV missing limb or organ still requires its printed Reconstruction Progress, project time, a treatment environment meeting the requirements of Body Refining Shared Procedures R1, medicine, ritual aid, and required components. Your personal work counts as a valid Body Refining treatment source.

This Insight cannot automatically reverse Tier V erasure, divine or Immortal authority, Secret effects, Artifacts, soul destruction, heavenly punishment, Foundation destruction, or an effect that expressly requires a breakthrough or story-scale cure.

### General Spirit and Spirit-Relationship Insights

#### Exorcist's Calling

**Prerequisite:** Spirit Awakening, CL4+, Spiritual Sense  
**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.  
**Source CL:** Your Spirit Awakening CL.

You have learned to diagnose and interrupt invasive spiritual influences before gaining the Path's complete exorcism feature.

## Lesser Exorcism

**Action Type:** Action  
**Range:** 30 feet  
**Cost:** 2 Resonance  
**Target:** One creature, object, location, manifested spirit, or Spiritual Anchor that you can perceive with Spiritual Sense or Soul Gaze, or one target bearing your Resonance Mark

Choose one **Intrusion** attached to the target that you can perceive:

- unwilling Possession;
- unwilling or coercive Hosting;
- dream intrusion;
- spiritual contamination;
- imposed emotional corruption;
- memory interference;
- hostile spirit presence; or
- a curse whose Source Rule has a spiritual component.

You cannot target:

- a willing stable Covenant Bond unless both bonded parties consent to separation;
- integrated spirit ancestry or a legal Species, Path, Subpath, Foundation, Method, Origin Insight, or ordinary memory;
- completed death, reincarnation, permanent soul destruction, or divine custody; or
- an artifact, Secret, Immortal, or world-law effect unless its Source Rule permits ordinary exorcism.

### Resolution

Make a Spirit Awakening Cultivation Check against the Intrusion's Cultivation Save DC. If it has no printed DC, use the possessing spirit's or creator's Cultivation Save DC. If neither exists, use the Rules Reference fallback Authority DC for the source's Realm.

On a failed check, the Intrusion remains. Learn its broad category, its Source CL band relative to you, and whether it is sustained by a creature, Bond, vessel, location, Domain, or Spiritual Anchor.

On a successful check, compare Source CL:

- **6 or More Lower:** End one ordinary temporary Intrusion. For Possession, achieve Grade 2 Separation and place the Intruder in its legal adjacent manifestation, legal vessel, or visible noncontrolling outline. A permanent, Secret, artifact, divine, or explicitly anchored Intrusion is suppressed until the scene ends and reveals one printed release requirement instead.
- **3–5 Lower:** Suppress the Intrusion for up to 1 minute while you maintain Concentration. The Host immediately repeats one saving throw the Intrusion allows with Advantage. The Intruder becomes perceptible and cannot conceal its link during suppression.
- **Within 2:** Suppress the Intrusion until the end of the target's next turn. The Host immediately repeats one allowed saving throw with Advantage. If no repeat save exists, suppression is the complete result.
- **3 or More Higher:** Do not suppress it. The Host immediately repeats one allowed saving throw with Advantage. Expose the Intrusion's manifestation and the direction of its sustaining Anchor to your Spiritual Sense until the end of your next turn.

A willing Host may waive resistance made on its behalf. A willing Intruder does not resist separation. If both Host and Intruder oppose separation, use the higher relevant Cultivation Save DC; if only one opposes, use that opponent's DC.

### Limits

- A specific Intrusion can be targeted by your Lesser Exorcism only once per round.
- Lesser Exorcism cannot destroy a Complete Soul, transfer spirit ownership, create a Companion Bond, strip integrated ancestry, or remove legal character options.
- It cannot bypass a named rite, material, location, authority, or higher Source CL requirement unless the result expressly satisfies it.

## CL13 Improvement

When you gain **Spiritual Exorcism** from Spirit Awakening:

- Lesser Exorcism costs 1 Resonance;
- its range becomes 60 feet;
- successful suppression against a lower-Source-CL Intrusion does not require Concentration; and
- when you expose an equal- or higher-authority Intrusion, the target has Advantage on its next saving throw against it before the scene ends.

This Insight does not grant the Spirit Companions Sphere and does not replace the Exorcist tradition.

#### Breath-Thread Listener

**Prerequisite:** Air sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

**Source CL:** Use your Spirit Awakening CL for Breath Reading and the normal Air Source CL for Air talents.

You hear the spiritual thread carried by breath, speech, and suppressed panic.

You have Advantage on Wisdom (Insight) checks against a creature within 30 feet that you can hear breathing or speaking.

### Breath Reading

**Action Type:** No Action  
**Trigger:** A creature within 30 feet that you can hear knowingly speaks a false statement, begins an audible command or compulsion technique, or attempts to conceal immediate fear or panic  
**Limit:** Once per scene

Learn which one of the following states best describes the triggering breath:

- **Steady:** The creature's breath does not reveal deliberate falsehood, immediate panic, or coercive command pressure.
- **Strained:** The creature is afraid, under duress, injured, or suppressing panic.
- **False:** The spoken statement deliberately conflicts with what the creature presently believes. This does not detect omission, metaphor, mistake, or technically true misdirection.
- **Absent:** The creature has no living breath, is using an artificial voice, or is speaking through a body that does not breathe normally.
- **Spiritually Masked:** A cultivation effect is concealing or falsifying the breath-thread.

If a masking effect has lower Source CL than you, you identify both the underlying state and that it was masked. Otherwise, make a Spirit Awakening Cultivation Check against the masking effect's Cultivation Save DC. On a success, identify the underlying state. On a failure, learn only **Spiritually Masked**.

Breath Reading does not read thoughts, reveal the complete truth, identify an unknown technique by name, or force the creature to speak.

#### Soul-Hearing Listener

**Prerequisite:** Soul-Echo Hearing, Spirit Awakening, CL10+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use **Soul-Echo Hearing**, choose one willing creature whose natural or spiritual voice you have heard within the last day. Establish a **Listening Link** with that creature.

The link lasts until you establish it with another creature, the creature withdraws consent while able to communicate that choice, or a Source Rule severs it.

While the linked creature is within 1 mile and on the same plane, you become aware when its state changes into or out of any of the following:

- **Possessed:** It is under unwilling Possession or coercive Hosting.
- **Silenced:** It is unable to produce its normal voice because of a condition, restraint, injury, Silence effect, or spiritual suppression.
- **Screaming:** It audibly or spiritually cries out because of immediate pain, terror, soul harm,.
- **Fallen:** It is reduced to 0 Hit Points.

You learn the state and the direction of the link, but not exact distance or location.

A ward, Domain, planar boundary, or concealment effect can block the link. If the blocking source has lower Source CL than the higher of your Sound and Spirit Awakening Source CL, you know the link is blocked and its direction immediately before the block. Otherwise, you know only that contact was lost.

The link does not transmit speech, thoughts, ordinary emotions, damage details, or continuous sensory information.

#### Courteous Medium

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

Once per spirit per scene, when you first address it respectfully after successfully reading its Spirit Nature, reduce the DC of your next social check made toward that spirit during the scene by 2.

If, before making the check, you provide one Offering that matches the spirit's recorded appetite, Minor Offering, custom, office, or acknowledged need, reduce the DC by 5 instead.

An Offering qualifies only if it is actually delivered or made available on the terms stated. The same object, promise, service, or sacrifice cannot qualify simultaneously for multiple spirits unless each spirit's record permits shared use.

This Insight improves the opening position; it does not force cooperation, waive a Taboo, erase Bond Strain, or make an insulting or impossible request acceptable.

#### Ethical Exorcist

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on the Cultivation Check for **Break the Cruel Seal**, **Exorcist's Mercy**, or **True Name Mercy** when your declared purpose is one of the following:

- free a spirit from coercive control;
- calm a maddened, frightened, wounded, or contaminated spirit;
- separate a spirit and Host without destroying either;
- release a spirit to a legal vessel, manifestation, afterlife route, reincarnation route, shrine, or other state accepted by its Source Rule.

If another Source Rule expressly says it uses one of those Spirit Companions procedures, the Advantage applies to that use as well.

The benefit does not apply when your actual purpose is enslavement, extraction of involuntary service, destruction of a Complete Soul, theft of a spirit's vessel or Name, or conversion of an unwilling spirit into your companion.

#### Spirit-Broker Reputation

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

Use the following **Spirit Negotiation Position** ladder:

`Hostile → Unwilling → Wary → Open → Favorable`

When a spirit knows your reputation for keeping spirit covenants, begin its first negotiation with you during a scene one position more favorable than its ordinary starting position, to a maximum of Favorable.

A spirit knows your reputation if one of the following is true:

- it has dealt with you before;
- a spirit, shrine, court, ancestor, broker, sect, or witness it trusts has vouched for you;
- your relevant office, seal, lineage, or public covenant record is recognized in its community.

### Broken Reputation

If you have an unresolved breach of a Covenant Bond, Offering, Taboo, spirit-court judgment, or other recorded spirit agreement, this Insight provides no benefit to spirits that know of that breach.

Restore the benefit for that breach by completing its recorded Restitution. If no Restitution was recorded, complete all three:

1. acknowledge the breach to the harmed spirit or its recognized representative;
2. provide the missed Offering, compensation, service, or release that reasonably repairs the terms; and
3. receive acceptance from the harmed spirit, its lawful successor, or a recognized neutral spirit authority.

This Insight never changes a spirit's consent, core Nature, sworn hostility, or response to an impossible request.

#### Vessel Artisan

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to prepare, repair, disguise, identify, or reinforce a spirit vessel, shrine, charm, mask, weapon, puppet, reliquary, or Spiritual Anchor.

### Craft Minor Vessel

**Action Type:** Downtime Procedure  
**Time:** 8 hours of work  
**Materials:** ordinary clay, wood, stone, cloth, metal, glass, bone, wax, inked paper, or another material listed in the spirit's Nature record; no rare cultivation material is required

Create one Tiny or Small minor vessel whose material matches at least one tag in the willing minor spirit's Nature record or one Minor Spirit Agreement.

Record:

- the vessel's object type and material;
- the spirit or Nature it is intended to receive;
- its entrance and release procedure;
- one visible or spiritual sign that it is occupied; and
- its ordinary object AC and Hit Points. If no object rule supplies them, use AC 12 and Hit Points equal to `5 + 2 × your Proficiency Bonus`.

The vessel:

- can shelter, transport, conceal, or localize its recorded spirit;
- does not grant a combat body, attack, independent turn, Nature Expression, resistance, or Companion statistics;
- cannot contain an unwilling Complete Soul without a legal Binding source; and
- expels its occupant into the nearest legal state if destroyed, unless another Source Rule governs destruction.

You may repair a minor vessel during 1 hour of work with ordinary materials, restoring all of its Hit Points if its spiritual structure has not been destroyed by a higher-authority effect.

#### Shared Breath Guardian

**Prerequisite:** Spirit Companions sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Constitution score by 1, to the maximum allowed by your current Realm.

**Action Type:** Reaction  
**Trigger:** A spirit joined to you by a Covenant Bond, Hosting Bond, Major Spirit Bond, or full Spirit Companion relationship and within 30 feet would take damage

Transfer half of the triggering damage to yourself.

Resolve the transfer in this order:

1. Determine the damage after modifiers that apply to the original damage source but before applying the spirit's Resistance, Immunity, or Vulnerability.
2. If the spirit is Hosted in you, reduce that damage by your Proficiency Bonus, minimum 0.
3. Divide the remaining damage in half. You receive the smaller half, rounded down; the spirit receives the remainder.
4. Apply your own Resistance, Immunity, and Vulnerability to your share and the spirit's to its share.

The transferred share retains its original damage type and source. It is not a new attack or activation, cannot trigger this Insight again, and cannot be redirected a second time unless a Source Rule expressly permits recursive transfer.

If either recipient is not a legal target for the original damage because of planar separation or a higher-authority ward, the transfer fails and the spirit takes the original damage normally.

#### Soul-Return Witness

**Prerequisite:** Life sphere, Spirit Awakening

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use **Read the Pulse** on a corpse that has been dead no longer than 1 day, also diagnose the soul's apparent return state. Learn one:

- **Willing:** A Complete Soul appears willing and ordinarily capable of return.
- **Unwilling:** The soul appears to refuse ordinary return.
- **Absent:** No returnable Complete Soul is present or reachable by the examined pattern.
- **Trapped:** A creature, vessel, location, Domain, Spiritual Anchor, or custody effect is restraining the soul.
- **Consumed or Destroyed:** The pattern shows loss beyond ordinary absence; this diagnosis does not itself prove permanent destruction.
- **Blocked:** An authority, reincarnation route, afterlife custody, oath, Secret, artifact, or other effect prevents ordinary return.

If the restraining or blocking source has lower Source CL than the higher of your Life and Spirit Awakening Source CL, also learn whether it is sustained by a creature, vessel, location, Domain, Bond, or Spiritual Anchor.

If the source is within 2 Source CL of you, learn its broad category and whether it is present, distant, or outside the current plane.

If the source is 3 or more Source CL higher, Secret, Immortal, divine, or world-law authority, learn only that a higher authority is involved and whether ordinary return is presently possible.

This Insight does not identify an unknown captor by name, reveal a hidden release condition, return the soul, or establish that reconstruction is possible.

#### Psychopomp’s Courtesy

**Prerequisite:** Death sphere, Spirit Awakening, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use **Soul Funeral** or **Quiet Burial** against a ghost, undead creature, possessing Intruder, or another target those talents legally affect, you may declare **Courtesy** before resolving damage.

If you do:

- the activation deals no damage;
- a target currently possessing an unwilling Host, desecrating remains, or preventing a soul from following its lawful afterlife or reincarnation route has Disadvantage on its saving throw against the activation; and
- if the target fails but remains a Complete Soul, it may communicate one final sentence and ask one brief question before it departs, is expelled, or enters the legal state produced by the talent.

The question does not compel an answer, suspend hostile action beyond the talent's normal resolution, reveal hidden information automatically, or change the target's legal destination.

#### Red Thread Sensitivity

**Prerequisite:** Thread sphere and Spirit Awakening, Karma sphere, Heartbinder, Knot Weaver, or another printed Source Rule authorizing relationship perception

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

**Action Type:** Action  
**Range:** 60 feet  
**Targets:** Two creatures you can see

Study the relationship threads between the targets. Learn whether at least one genuine, active relationship recorded through kinship, oath, debt, affection, command, mentorship, ownership, custody, hostility, worship, or a Spirit Bond from the following list connects them:

- affection or loyalty;
- debt or obligation;
- rivalry or hatred;
- fear or coercive dependence;
- oath, vow, contract, or formal duty;
- familial, ancestral, teacher-disciple, sect, office, or companion bond.

If more than one category applies, learn the category with the strongest current spiritual pressure; if tied, learn all tied categories.

You do not learn exact terms, memories, hidden names, who is morally correct, or whether either creature intends to honor the relationship.

If the relationship is concealed by a ward, Fate effect, false thread, Secret, Domain, or another cultivation source, make a Thread Cultivation Check against that source's Cultivation Save DC. On a success, read the relationship normally and learn that it was concealed. On a failure, learn only **Obscured Relationship**.

This Insight detects genuine relationships; it does not create consent or let you perceive a relationship that no longer exists merely because it existed in the past.

#### Keeper of the Funeral Wick

**Prerequisite:** Wax sphere or Spirit Awakening

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks concerning funeral etiquette, respectful corpse handling, disturbed remains, funerary wax, and preservation of final messages or identifying signs.

### Funeral Wick

**Action Type:** Reaction  
**Trigger:** A creature you can perceive dies within 30 feet  
**Limit:** Once per scene

Create one harmless funeral candle in an unoccupied space within 5 feet of the corpse or remains. The candle lasts for 1 hour and records one **Final Impression** that was perceptible at death. Choose one:

- visible name, seal, crest, or written mark;
- handprint, footprint, blood pattern, or weapon grip;
- last visible breath, gesture, expression, or direction of attention;
- one symbolic spiritual image produced by the dying creature's own soul-pattern; or
- one brief final sound of no more than six words that the creature actually uttered.

The candle is a Tiny Spirit Asset with AC 10 and 1 Hit Point. It emits dim light for 5 feet. Destroying it ends the record.

A Final Impression is evidence, not a Soul Fragment or Complete Soul. It cannot answer questions, reveal unperceived thoughts, repeat an activation, serve as a resurrection substitute, or be compelled as the dead creature.

### Common Sphere and Cultivation-Life Insights

#### Cloud-Step Novice

**Prerequisite:** Air sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you use Feather-Fall Breath on yourself, you may also move 10 feet horizontally before landing.

Once per scene, when you would fall after ending your turn in the air, you may delay the fall until the end of your next turn.

#### Alchemical Prodigy

**Prerequisite:** Alchemy, CL 4+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Once between Full Cultivation Sessions, when you successfully refine a Common or Uncommon recipe, you may create a second product of the same recipe.

You must provide ingredients for both products.

At CL 10, this Insight may affect Rare recipes.

#### Pill Master’s Eyes

**Prerequisite:** Alchemy, CL 8+.

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

You automatically identify Common and Uncommon pills, poisons, alchemical ingredients, and obvious alchemical contamination after 1 minute of study.

You have Advantage on checks to identify Rare or higher alchemical substances.

#### Courtly Presentation

**Prerequisite:** Beauty sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Gain proficiency in one of Performance, Persuasion, Insight, or Deception. If you already have proficiency in the chosen skill, gain Expertise with that skill for checks involving etiquette, presentation, reputation, sincere confession, formal challenge, or public poise.

This Insight does not make a hostile creature friendly by itself.

#### Poise-Tempered Presence

**Prerequisite:** Beauty sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Charisma, Wisdom, or Dexterity score by 1, to the maximum allowed by your current Realm.

Once per scene, when you succeed on a saving throw against being Charmed, Frightened, humiliated, magically compelled to lose face, or forced to kneel, bow, grovel, or flee, you may place one Beauty Mark on the source if the source is within 60 feet and can perceive you.

This mark lasts until the end of your next turn.

#### Named Tool Custodian

**Prerequisite:** Blacksmith sphere, Name the Purpose, CL 4+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one personal tool, hammer, anvil, file, tongs, needle, chisel, whetstone, furnace plate, or similar implement.

While using that named tool:

gain Advantage on Read the Flaw once per scene;

the tool can hold one Forge Mark;

if the tool would be destroyed, reduce the damage to it by 5 x Proficiency Bonus once between Full Cultivation Sessions.

Replacing the named tool requires a short quest, inheritance, purchase, or 8 hours of personal work.

#### Master of Repairs

**Prerequisite:** Blacksmith sphere, Close the Crack, CL 6+

**Ability Increase (Level Selection):** Increase your Intelligence, Strength, or Constitution score by 1, to the maximum allowed by your current Realm.

When you use Close the Crack outside combat, repair two compatible damaged objects in the same scene instead of one.

When you use Close the Crack in combat, add an extra 1d6 to the object HP restored.

At CL 10+, increase the extra restoration to 2d6.

#### Chain-Tool Familiarity

**Prerequisite:** Chains sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

You gain proficiency with chain weapons, manacles, prison tools, and one artisan’s tool or martial tool related to chains, locks, hooks, or restraints.

If you already have the relevant proficiency, you may add half your Proficiency Bonus to checks made to repair chains, disable shackles, evaluate prison equipment, or identify chain-based techniques.

#### Lawful Captor

**Prerequisite:** Chains sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you reduce a creature to 0 Hit Points with Chain Lash or a Chains talent, you may choose to knock it unconscious and immediately bind it with mundane chains, rope, or Manacle Method if you have a free hand, chain, or equivalent tool.

In addition, you have Advantage on Charisma checks made to justify lawful capture, prisoner transfer, bounty custody, or sect discipline when your use of Chains was witnessed and proportionate.

#### Gravekeeper

**Prerequisite:** Death, CL 4+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

You are trained in lawful funeral practice.

Gain Advantage on checks made to investigate death, identify undead, recognize possession, prepare corpses, locate hidden graves, or determine whether remains have been desecrated.

Funerary Preservation no longer costs CP for Common corpses.

#### Merciful Reaper

**Prerequisite:** Death, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature dies within 30 feet, you may use your Reaction to choose one:

prevent its corpse from being animated for 24 hours;

preserve its soul from ordinary destruction for 24 hours;

allow it to speak one final sentence;

end one ordinary possession affecting its corpse;

grant one ally who can hear the final breath Temporary HP equal to your Proficiency Bonus.

This Insight is favored by orthodox Death cultivators.

#### Breach-Reader

**Prerequisite:** Destruction sphere

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Spend 1 minute studying one visible object, wall, barrier, lock, Formation Anchor, gate, or structural defense within 30 feet.

Make an Intelligence (Investigation) check or Cultivation Check against the target's Cultivation Save DC. If it has no save DC, use `10 + its Source CL + its quality modifier`, where the quality modifier is 0 for ordinary construction, +2 for reinforced or cultivated construction, and +5 for Artifact, Secret, or masterwork construction.

On a success, choose and learn one:

- the most vulnerable visible section;
- whether it has Resistance or Immunity to one damage type you can deal;
- whether destroying it is likely to create a breach, collapse, alarm, or printed backlash; or
- one tool, Sphere, or damage category that bypasses a printed defense it possesses.

On a failure, learn only whether its Source CL is lower than, equal to, or higher than yours.

#### Calamity Control

**Prerequisite:** Destruction sphere

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use a Blast Shape that affects an area, you may choose one creature you can see in the area. That creature has Advantage on its saving throw against the blast.

At Core Formation Realm, you may choose two creatures instead.

#### Plague Physician

**Prerequisite:** Disease, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Purging Breath may be used as a Bonus Action.

Purging Breath may target a willing creature within 30 feet.

When you use Purging Breath, you may remove two Contagion Tokens instead of one.

If the target immediately repeats a saving throw against a Disease effect, it has Advantage.

You automatically identify ordinary disease when using Diagnose the Sickness.

#### Quarantine Adept

**Prerequisite:** Disease, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Raise the Quarantine Veil no longer requires Concentration when used in Containment Mode.

The veil radius increases by 5 feet.

As a Bonus Action, you may move one Quarantine Veil you created up to 10 feet.

Your Containment Mode prevents ordinary Disease effects from spreading beyond the ward unless you allow it.

#### Burden-Mark Adept

**Prerequisite:** Earth sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

Increase your Burden Mark limit by 1.

Once per round when you spend a Burden Mark, move 5 feet without provoking Opportunity Attacks from the marked creature, provided both of you are touching the same surface.

#### Tremor-Reader Adept

**Prerequisite:** Earth sphere, Tremor-Listening Palm, CL 8+

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When using Tremor-Listening Palm, you can distinguish between Small, Medium, Large, and Huge or larger creatures by weight and rhythm.

You also gain Advantage on Wisdom (Survival) and Intelligence (Investigation) checks made to read tracks, collapsed ground, battle movement, digging, marching, falling, or dragging.

#### Gambler’s Instinct

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks made to recognize cheating, manipulated wagers, altered lots, loaded dice, cursed games, or supernatural probability influence.

You cannot be Surprised by ordinary ambushes while conscious if the ambush relies on a game of chance, random patrol timing, or manipulated coincidence.

#### Auspicious Companion

**Prerequisite:** Fate, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, choose one willing creature.

Once before your next Full Cultivation Session, when that creature fails an attack roll, ability check, or saving throw, it may roll 1d8 and add the result, potentially turning failure into success.

#### Student of the Returning Current

**Prerequisite:** Flowing River sphere

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

Gain one Flowing River talent for which you meet the prerequisites.

You also gain proficiency in Dexterity (Acrobatics) or Wisdom (Insight). If already proficient in the chosen skill, gain Expertise instead.

#### Body Like Water

**Prerequisite:** Flowing River sphere

**Ability Increase (Level Selection):** Increase your Dexterity, Wisdom, or Constitution score by 1, to the maximum allowed by your current Realm.

When you are Grappled or Restrained, you may use a Bonus Action to attempt to escape.

If you escape a Grapple or Restraint this way, regain Martial Focus.

You regain Martial Focus only if it is currently absent.

#### Mountain Stance

**Prerequisite:** Gravity sphere, CL 4+.

**Ability Increase (Level Selection):** Increase your Strength, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

While touching a solid surface and Body Heavying is active:

You have Advantage against forced movement.

You have Advantage against being knocked Prone.

You count as one size larger for Grapple and Shove.

You reduce forced movement affecting you by 5 feet.

If you already have Anchor Stance, increase the total reduction by 5 feet.

#### Herb-Gatherer’s Foundation

**Prerequisite:** Harvesting and Gathering, CL 4+.

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

Choose one Sign or Cut talent you know. Once per scene, when you use that talent and roll a Gathering Check, add a d4 to the roll after seeing the d20 but before knowing the outcome.

At CL 10, the die becomes a d6.

#### Ethical Gatherer

**Prerequisite:** Harvesting and Gathering, CL8+

**Ability Increase (Level Selection):** Increase your Wisdom, Intelligence, or Constitution score by 1, to the maximum allowed by your current Realm.

When you preserve a living source that could legally have been destroyed for a greater Harvest yield, record one **Preservation Merit**. You can hold one Preservation Merit.

Spend it to gain Advantage on one Gathering Check using Root-Left-Alive Method or Source-Sparing Harvest. A source cannot grant another Preservation Merit until it has naturally recovered or completed a cultivation cycle.

Staged, owned, summoned, or repeatedly regenerated sources do not grant Preservation Merit.

#### Clean-Tongued Disciple

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you use Taste the Qi on food, drink, or medicine, you may also detect mundane spoilage, common poison, and obvious disease without rolling unless the substance is deliberately concealed.

#### Camp Kitchen Adept

**Prerequisite:** Hunger sphere

**Ability Increase (Level Selection):** Increase your Constitution, Strength, or Wisdom score by 1, to the maximum allowed by your current Realm.

During a 10-minute recovery procedure, if you prepare food for the party, choose one willing creature who eats it. That creature gains Temporary HP equal to your Proficiency Bonus.

A creature can benefit from Camp Kitchen Adept only once between Full Cultivation Sessions.

#### Patient Inscription

**Prerequisite:** Ink sphere.

**Ability Increase (Level Selection):** Increase your Intelligence, Dexterity, or Wisdom score by 1, to the maximum allowed by your current Realm.

Effect: When you spend at least 10 minutes creating an Ink Mark or Seal, choose one.

Increase its duration by one step, from 1 hour to 8 hours, or from 8 hours to 24 hours.

Give one creature Disadvantage on its first check to find or remove it.

Allow it to survive ordinary rain, dust, handling, and minor abrasion.

Hide one mundane message inside it that only a chosen creature or group can read.

#### Tempered Knuckles

**Prerequisite:** Iron Fist sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

When your Unarmed Strike deals damage to an object, temporary Barrier, or creature wearing manufactured armor, add your Proficiency Bonus to the damage once per turn.

When you take damage from striking a hard surface or armored creature, reduce that damage by your Proficiency Bonus.

#### Oathkeeper

**Prerequisite:** Karma sphere, CL 8+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

When you knowingly fulfill a difficult promise despite personal cost, gain one Grace Imprint on yourself. Maximum: one Grace Imprint between Full Cultivation Sessions.

You have Advantage on checks made to recognize magically binding promises, coerced oaths, and oath loopholes.

#### Ledger-Safe Tongue

**Prerequisite:** Karma sphere, CL 4+

**Ability Increase (Level Selection):** Increase your Wisdom, Charisma, or Intelligence score by 1, to the maximum allowed by your current Realm.

You have Advantage on Charisma checks made to word clear oaths, negotiate fair terms, identify hidden traps in bargains, and persuade creatures that a consequence is just.

When you create Minor Oath, you may include one simple exception clause without making the oath unclear.

#### Battlefield Physician

**Prerequisite:** Life sphere.

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Read the Pulse in combat, you may move up to 10 feet before or after using it without provoking opportunity attacks from the target of your treatment.

In addition, when you stabilize a creature, that creature gains Temporary HP equal to your Proficiency Bonus.

#### Clean-Handed Healer

**Prerequisite:** Life sphere

**Ability Increase (Level Selection):** Increase your Wisdom, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use Purify the Pulse to remove a disease or poison, you have Advantage for 24 hours on Cultivation Checks to identify, suppress, or prepare an ordinary treatment for that same disease or poison.

If you successfully treat at least three creatures suffering from the same disease or poison during one scene, learn its ordinary treatment requirements: required Medicine proficiency, one available mundane ingredient category, treatment time, and the check DC. This does not reveal a Secret cure or bypass a higher-Source-CL affliction.

#### Circuit Scholar

**Prerequisite:** Qiweaving sphere

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you make an Intelligence check to identify a spell, sphere technique, talisman effect, or Active Qi Pattern, add your Proficiency Bonus if you are not already proficient.

If you are proficient, add double your Proficiency Bonus.

#### Calm Hands, Clear Current

**Prerequisite:** Qiweaving sphere

**Ability Increase (Level Selection):** Increase your Intelligence, Charisma, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you fail a Concentration saving throw for a Qiweaving talent or a technique modified by a Modulation talent, you may reroll the save.

Use the new result.

Once you use this Insight, you cannot use it again until you finish a scene.

#### Proper Seniority

**Prerequisite:** Sect Stewardship, CL 4+.

**Ability Increase (Level Selection):** Increase your Charisma, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

You instinctively know how to address seniors, peers, juniors, guests, servants, deacons, elders, and strangers without causing unnecessary offense.

Gain proficiency in Insight or Persuasion. If you already have proficiency, gain a flat +2 bonus to checks with the chosen skill when navigating hierarchy, etiquette, or institutional duty.

Once between Full Cultivation Sessions, when a social scene would worsen because you used the wrong title, gesture, bow, seating order, or speaking order, you may reroll the check that caused the mistake.

#### Careful Grip Disciple

**Prerequisite:** Weapons sphere

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Constitution score by 1, to the maximum allowed by your current Realm.

You have Advantage on checks to avoid being disarmed of your Conduit Weapon or chosen profile weapon.

## Recommended Insight Routes

These tables are orientation tools, not access grants. A character must still meet every prerequisite. **Core** means the Insight is printed in this chapter; **Compendium** means its full text is in the Cultivation Insights Compendium.

### Body Refining

| Cultivation route | Suggested Insights |
|---|---|
| Durability and recovery | Mountain-Forged Frame (Core); Meridian-Breath Discipline (Core); Iron-Blood Circulation (Core); Refined Golden Bell (Core); Heavenly Meridian Reconstruction (Core) |
| Martial pressure | Brutal Momentum (Core); Tempered Reflexes (Core); Refined Natural Weapon (Core); Internal Weapon Scripture (Core); Living Siege Engine (Core) |
| Control and restraint | Unyielding Grip (Core); Mountain Stance (Core); Lawful Captor (Core); Chain-Walking Immortal (Compendium); Body Like Water (Core) |
| Weapons embodied in the cultivator | Internal Weapon Scripture (Core); Refined Natural Weapon (Core); Careful Grip Disciple (Core); Proper Weight of the Tool (Compendium); Tempered Knuckles (Core) |
| Transformation and altered anatomy | Mountain-Forged Frame (Core); Heavenly Meridian Reconstruction (Core); Internalized Sphere Insight (Compendium); Deep Internalization (Compendium); Refined Natural Weapon (Core) |

### Qi Cultivation

| Cultivation route | Suggested Insights |
|---|---|
| Resource circulation | Expanded Dantian (Core); Meridian Economy (Core); Restorative Circulation (Core); Meridian Fortress (Core); Qi-Tempered Concentration (Core) |
| Elemental technique | Fivefold Conversion (Core); Elemental Counterflow (Core); Meridian Overchannel (Core); Heaven's Conduit (Core); Calamity Control (Core) |
| Mobility and positioning | Thunderstep (Core); Cloud-Step Novice (Core); Falling Star Footwork (Compendium); Folded Reflexes (Compendium); Student of the Returning Current (Core) |
| Armament and weapon delivery | Careful Grip Disciple (Core); Conduit Safety Lesson (Compendium); Method-Bearing Grip (Compendium); Arsenal Memory (Compendium); Named Blade Listener (Compendium) |
| Strategic cultivation | Circuit Scholar (Core); Calm Hands, Clear Current (Core); Breach-Reader (Core); Tremor-Reader Adept (Core); Pill Master’s Eyes (Core) |

### Spirit Awakening

| Cultivation route | Suggested Insights |
|---|---|
| Exorcism and diagnosis | Exorcist's Calling (Core); Ethical Exorcist (Core); Soul-Hearing Listener (Core); Breath-Thread Listener (Core); Soul-Return Witness (Core) |
| Spirit relationships | Courteous Medium (Core); Spirit-Broker Reputation (Core); Vessel Artisan (Core); Shared Breath Guardian (Core); Inner Vessel Discipline (Compendium) |
| Death and ancestor practice | Psychopomp’s Courtesy (Core); Keeper of the Funeral Wick (Core); Gravekeeper (Core); Merciful Reaper (Core); Soul-Return Witness (Core) |
| Conceptual martial cultivation | Gravitic Soul (Compendium); Mirror of Frozen Breath (Compendium); Grace-Bearing Soul (Compendium); Red Thread Sensitivity (Core); Song-Soul Oathbearer (Compendium) |
| Soul protection and identity | Soul Shackles (Compendium); Heart-Devil Negotiator (Compendium); Ruin Without Hatred (Compendium); Furnace-Soul Awakening (Compendium); Keeper of the Funeral Wick (Core) |

## Complete Cultivation Insight Index

This alphabetical index covers all 451 canonical selectable Insights. **Core PHB** means the complete rules appear earlier in this chapter. **Compendium** means the complete rules appear in the separate Cultivation Insights Compendium.

| Insight | Minimum CL | Prerequisite | Ability increase options | Publication location |
|---|---:|---|---|---|
| Alchemical Constitution | 8 | Alchemy or Body Refining, CL8+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Alchemy |
| Alchemical Prodigy | 4 | Alchemy, CL 4+. | Intelligence, Wisdom, Constitution | Core PHB |
| Alloy-Sense Disciple | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Ancestral Bloodline Awakening | 4 | Discovered heritage, absorbed ancestral essence, bloodline event, or equivalent approval | Constitution, Charisma | Compendium — Qi — Bloodline Insights |
| Ancestral Treasure Bond | 8 | A bloodline feature and one genuine ancestral weapon, shield, artifact, implement, or relic; CL8+ | Constitution, Wisdom, Charisma | Compendium — Qi — Bloodline Insights |
| Anchor Between Heaven and Earth | 12 | Gravity sphere, CL 12+. | Strength, Intelligence, Wisdom | Compendium — Sphere — Gravity |
| Anchored Soul | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Compendium — Sphere — Space |
| Armament Commander | 12 | Domain Armament, CL12+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Armament Formation Node | 12 | Domain Armament and the Formations Sphere, Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another Formation-authorized Source Rule, CL12+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Armament Reversal | 12 | Domain Armament, CL12+ | Dexterity, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Armored Meridian Circulation | 4 | Qi Cultivation, proficiency with medium armor, heavy armor, or shields, CL4+ | Strength, Constitution, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Arsenal Memory | 4 | Weapons sphere, CL 4+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Arsenal-Script Custodian | 8 | Weapons sphere, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Ashura Furnace | 12 | Jigoku and Fire, Ash, or Demonic Cultivation Sphere, CL 12+ | Strength, Constitution, Charisma | Compendium — Body — Advanced Subpath Insights |
| Astral Cartographer | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Asura-Hand Tempering | 6 | Unmaking Sphere, Body Refining, CL6+ | Constitution, Strength, Wisdom | Compendium — Sphere — Unmaking |
| Auspicious Companion | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Core PHB |
| Awakener of Tools | 8 | Animate Minor Vessel or Speak to the Vessel, CL 8+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Banquet Etiquette of the Outer Court | 4 | Hunger sphere | Constitution, Strength, Wisdom | Compendium — Sphere — Hunger |
| Barrage Conduction | 12 | Qi Cultivation, CL12+, and a Barrage Sphere talent, multiattack Recorded Art, or another authorized multiattack cultivation procedure | Dexterity, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Battle Musician | 4 | Body Refining, Music Sphere, CL4+ | Constitution, Charisma, Wisdom | Compendium — Sphere — Music |
| Battlefield Physician | 4 | Life sphere. | Wisdom, Constitution, Charisma | Core PHB |
| Battlefield Scribe | 8 | Warleader sphere, Qi Cultivation or proficiency with calligrapher’s supplies, cartographer’s tools, or painter’s supplies, CL 8+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Beast-Core Butcher | 8 | Harvesting and Gathering, Simple Beast Dressing, CL 8+. | Wisdom, Intelligence, Constitution | Compendium — Sphere — Harvesting Gathering |
| Beauty-Script Custodian | 10 | Beauty sphere, Formations, Talismans, Ink, Music, or Sect Stewardship sphere, CL 10+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Beauty |
| Bell-and-Formation Custodian | 8 | Music sphere, Formations sphere, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Bell-Bone Adept | 4 | Body Refining, Sound Sphere, CL4+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Sound |
| Bell-Skin Discipline | 8 | Iron Shirt, CL 8+ | Constitution | Compendium — Body — Advanced Subpath Insights |
| Black-Lantern Commander | 12 | Death, Grave Formation, CL 12+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Death |
| Black-Vein Initiate | 4 | Unmaking sphere, CL 4+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Blackglass Executioner | 10 | Obsidian Glass Scripture or Cinderglass Shards, CL 10+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| Blade-Hesitation Adept | 8 | Beauty sphere, Turn the Blade Aside or another Beauty reaction talent, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Beauty |
| Blood-Furnace Heart | 16 | Blood Pump, CL 16+ | Constitution | Core PHB |
| Blood-Meridian Refinement | 4 | Blood Sphere, CL 4+ | Constitution, Charisma | Compendium — Body — Common Hybrid-Sphere Insights |
| Bloodline-Core Fusion | 12 | Bloodline Cultivator, Ancestral Bloodline Awakening, or another active bloodline engine; CL12+ | Constitution, Intelligence, Charisma | Compendium — Qi — Bloodline Insights |
| Body as Cauldron | 4 | Body Refining, CL4+, Constitution 15+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Alchemy |
| Body as Center | 8 | Body Refining, Gravity Sphere, CL8+ | Constitution, Strength, Intelligence | Compendium — Sphere — Gravity |
| Body Like Water | 4 | Flowing River sphere | Dexterity, Wisdom, Constitution | Core PHB |
| Body of Thorns and Spores | 4 | Body Refining, Harvesting and Gathering Sphere, CL4+ | Constitution, Wisdom, Intelligence | Compendium — Sphere — Harvesting Gathering |
| Bone General | 8 | Corpse Servant, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Death |
| Bone-Tempering Insight | 4 | Bones Sphere, CL 4+ | Constitution | Compendium — Body — Common Hybrid-Sphere Insights |
| Borrowed Golden Form | 16 | Qi Cultivation, CL16+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Borrowed Merit | 10 | Karma sphere, CL 10+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Karma |
| Branch Founder | 12 | Sect Stewardship, Courtyard Grant or Department Ledger, CL 12+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Breach-Reader | 4 | Destruction sphere | Strength, Intelligence, Charisma | Core PHB |
| Breath-Thread Listener | 8 | Air sphere, Spirit Awakening, CL8+ | Dexterity, Wisdom, Intelligence | Core PHB |
| Breathless Heart Method | 12 | Shinobi, CL 12+ | Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Broken-Rhythm Adept | 8 | Drunken Style sphere, CL 8+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Brush-Armed Guard | 8 | Brushstroke Shield, CL 8+. | Intelligence, Dexterity, Wisdom | Compendium — Sphere — Ink |
| Brutal Momentum | 8 | Body Refining, CL 8+ | Strength, Dexterity, Constitution | Core PHB |
| Brute-Body Adept | 4 | Brute Sphere, CL 4+ | Strength, Constitution | Compendium — Body — Common Might-Sphere Insights |
| Burden-Bearing Companion | 8 | Earth sphere, Companion feature or bonded companion, CL 8+ | Constitution, Strength, Wisdom | Compendium — Sphere — Earth |
| Burden-Mark Adept | 4 | Earth sphere, CL 4+ | Constitution, Strength, Wisdom | Core PHB |
| Butcher’s Mercy | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Calamity Control | 4 | Destruction sphere | Strength, Intelligence, Charisma | Core PHB |
| Calm Hands, Clear Current | 4 | Qiweaving sphere | Intelligence, Charisma, Wisdom | Core PHB |
| Camp Kitchen Adept | 4 | Hunger sphere | Constitution, Strength, Wisdom | Core PHB |
| Careful Grip Disciple | 4 | Weapons sphere | Strength, Dexterity, Constitution | Core PHB |
| Careful Inscription | 4 | Imbuement sphere, CL 4+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Cauldron Heart | 8 | Alchemy and Pill Forging Sphere or Alchemical Cultivator, CL8+ | Constitution, Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Cavalry Cut Familiarity | 4 | Sabers sphere, Cavalry Crescent Method | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Celestial Navigator | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Ceremonial Yue Bearer | 12 | Axes sphere, Mandate Axe Presence, CL12+, and Spirit Awakening, Warleader sphere, Sovereign Will, or another printed mandate doctrine | Strength, Wisdom, Charisma | Compendium — Sphere — Axes |
| Chain-Tool Familiarity | 4 | Chains sphere | Strength, Dexterity, Wisdom | Core PHB |
| Chain-Walking Immortal | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Compendium — Sphere — Chains |
| Circuit Scholar | 4 | Qiweaving sphere | Intelligence, Charisma, Wisdom | Core PHB |
| Circulating Core Refinement | 10 | Circulating Golden Core, CL10+ | Dexterity, Intelligence, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Clean Edge Discipline | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Clean Quarantine Reputation | 4 | Disease sphere | Constitution, Intelligence, Wisdom | Compendium — Sphere — Disease |
| Clean Severance Scholar | 6 | Unmaking sphere, Qi Cultivation Path, CL 6+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Clean-Handed Healer | 4 | Life sphere. | Wisdom, Constitution, Charisma | Core PHB |
| Clean-Tongued Disciple | 4 | Hunger sphere | Constitution, Strength, Wisdom | Core PHB |
| Cleansing Adept | 8 | Water sphere, Cleansing Water, CL 8+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Clinch-Gate Adept | 8 | Iron Fist sphere, Dragon-Step Clinch, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Cloud-Step Novice | 4 | Air sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Core PHB |
| Cold Star Heart | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Comet Adept | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Companion Armament | 16 | Domain Armament, CL16+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Compressed Golden Core | 12 | Qi Cultivation, CL12+ | Constitution, Intelligence, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Conceptual Edge | 16 | Heaven-Splitting Conceptual Severance or equivalent Secret authority, CL16+ | Dexterity, Intelligence, Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Conductive Preservation Artist | 8 | Lightning sphere, Spark Lattice Preservation, CL 8+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Conductor's Eye | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Conduit Hand Correction | 4 | Casting-Hand Weapon Method | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Conduit Safety Lesson | 4 | Armament Conduit Initiate | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Constellation Keeper | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Core-Sheltering Scripture | 12 | Qi Cultivation, CL12+ | Constitution, Wisdom, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Corpse-Tempered Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Intelligence | Compendium — Sphere — Death |
| Counter-Chant Specialist | 8 | Counter-Chant, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Sound |
| Counter-Script Reflex | 5 | Counterweave, CL 5+ | Intelligence, Charisma, Wisdom | Compendium — Sphere — Qiweaving |
| Counterseal Reflex | 10 | Seal Breaker, CL 10+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Talismans |
| Courteous Medium | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Core PHB |
| Courtly Presentation | 4 | Beauty sphere, CL 4+ | Charisma, Wisdom, Dexterity | Core PHB |
| Cremation-Furnace Core | 8 | Cinder Heart Cultivator or Fire/Ash cultivation access, CL8+ | Constitution, Intelligence, Charisma | Compendium — Qi — Forbidden, Condemned, and Predatory Insights |
| Crescent Projection Student | 4 | Sabers sphere, Qi Cultivation Path | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Crimson Restraint Broken | 12 | Oni Blood and Demonic Cultivation Sphere, CL 12+ | Strength, Constitution, Charisma | Compendium — Body — Advanced Subpath Insights |
| Crooked-Court Custodian | 12 | Drunken Style sphere, Court of Broken Rhythm, Formations sphere, CL 12+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Crushing Focus | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Compendium — Sphere — Gravity |
| Cultivated Weapon Channel | 4 | Qi Cultivation, proficiency with the chosen weapon group, CL4+ | Strength, Dexterity, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Cut the Snare | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Dao Guard Veteran | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Dawn Physician | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Dawn-Ward Adept | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Deacon’s Patience | 12 | Sect Stewardship, CL 12+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Debt Collector | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Karma |
| Deep Internalization | 8 | Internalized Sphere Insight; CL8+ | Constitution, Intelligence, Wisdom | Compendium — Body — Internalizing Power Spheres |
| Deepened Ancestral Memory | 8 | A bloodline feature, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Bloodline Insights |
| Demon Emperor’s Price | 15 | Demon Emperor Incarnation, CL 15+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Demon-Revealing Eyes | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Demon-Slaying Demon | 8 | Daemonic Cultivation, CL 8+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Devil-Qi Circulation | 4 | Daemonic Cultivation, CL 4+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Diamond Light Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Radiance |
| Divine Statue Meditation | 12 | Gōruden, CL 12+ | Constitution, Wisdom, Charisma | Compendium — Body — Advanced Subpath Insights |
| Double Current Method | 5 | Flowing River sphere, CL 5+ | Dexterity, Wisdom, Constitution | Compendium — Sphere — Flowing River |
| Dragon-Pearl Heart | 12 | Ryūjin, CL 12+ | Strength, Constitution, Charisma | Compendium — Body — Advanced Subpath Insights |
| Dual Mandate Adept | 8 | Layered Mandate, CL 8+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Dual-Body Synthesis | 12 | Two Internalized Sphere Insights; CL12+ | Constitution, Intelligence, Wisdom | Compendium — Body — Internalizing Power Spheres |
| Dual-Element Golden Core | 8 | Two elemental Spheres, CL8+ | Intelligence, Charisma | Compendium — Qi — Elemental Refinement Insights |
| Dune Court Architect | 12 | Sand sphere, Court of Ten Thousand Dunes, CL 12+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sand |
| Dune-Sovereign’s Mercy | 15 | Sand sphere, Sand-Sovereign Incarnation, CL 15+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sand |
| Earth-Ring Discipline | 8 | Sumo, CL 8+ | Strength, Constitution | Compendium — Body — Advanced Subpath Insights |
| Efficient Mandate | 6 | Imbuement sphere, CL 6+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Electric Fist Adept | 4 | Lightning sphere, Electric Fist Method, CL 4+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Elemental Armament | 12 | Domain Armament, one elemental Sphere or an elemental Qi Subpath, CL12+ | Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Elemental Core Mutation | 8 | Qi Cultivation, one elemental Sphere, CL8+ | Constitution, Intelligence, Charisma | Compendium — Qi — Elemental Refinement Insights |
| Elemental Counterflow | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Core PHB |
| Elemental Dominion | 16 | Elemental Mastery, CL16+ | Intelligence, Charisma | Compendium — Qi — Elemental Refinement Insights |
| Elemental Fusion Body | 12 | Elemental Mastery, CL12+ | Constitution, Intelligence, Charisma | Compendium — Qi — Elemental Refinement Insights |
| Elemental Mastery | 4 | Qi Cultivation, access to the chosen damage type, CL4+ | Intelligence, Charisma | Compendium — Qi — Elemental Refinement Insights |
| Embodied Domain | 12 | Internalized Sphere Insight and access to one Domain Talent; CL12+ | Constitution, Wisdom, Charisma | Compendium — Body — Internalizing Power Spheres |
| Emergency Commander | 8 | Warleader sphere, CL 8+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Empty Step Adept | 4 | Void sphere | Wisdom, Intelligence, Charisma | Compendium — Sphere — Void |
| Empty-Hand Twin Form | 4 | Dual Wielding sphere, an approved unarmed or natural-weapon discipline, CL 4+ | Dexterity, Strength, Constitution | Compendium — Sphere — Dual Wielding |
| Empty-Hand Weapon Master | 8 | Iron Fist sphere, Open-Hand Disarm, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Empty-Meridian Refinement | 12 | Kūkishin, CL 12+ | Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Ensemble Leader | 8 | Music sphere, Shared Measure, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Epidemic Master | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Disease |
| Erased Name | 16 | Void Sphere or Void-Touched Cultivator, CL16+, Secret approval | Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Eroding Current | 8 | Water sphere, Cutting Current or River Cuts the Gate, CL 8+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Ethical Exorcist | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Core PHB |
| Ethical Gatherer | 8 | Harvesting and Gathering, CL 8+. | Wisdom, Intelligence, Constitution | Core PHB |
| Execution Restraint | 4 | Sabers sphere, Execution Saber Method | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Exorcist's Calling | 4 | Spirit Awakening, CL4+, Spiritual Sense | Wisdom, Intelligence, Charisma | Core PHB |
| Expanded Dantian | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Charisma | Core PHB |
| Expansive Golden Core | 12 | Qi Cultivation, CL12+ | Constitution, Intelligence, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| External Foundation Breakthrough | 5 | Body Refining, Earth Sphere, CL5+ | Constitution, Strength, Wisdom | Compendium — Sphere — Earth |
| External Hammer Breakthrough | 8 | Blacksmith Sphere, Body Refining, CL8+ | Strength, Constitution, Intelligence | Compendium — Sphere — Blacksmith |
| External Thread Breakthrough | 5 | Body Refining, Puppetry Sphere, CL5+ | Constitution, Intelligence, Dexterity | Compendium — Sphere — Puppetry |
| Face Without Falsehood | 8 | Beauty sphere, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Beauty |
| Fall Seven Ways | 6 | Drunken Style sphere, Falling-Leaf Drop or Bent-Reed Recovery, CL 6+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Falling Star Footwork | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Compendium — Sphere — Gravity |
| Feed the Breakthrough Furnace | 10 | Profane Breakthrough Pressure, CL 10+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Field Refinement Doctrine | 8 | Qi Cultivation, CL8+ | Dexterity, Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Fire-Metal Furnace Understanding | 6 | Blacksmith sphere, Metal sphere or Fire sphere, CL 6+ | Intelligence, Strength, Constitution | Compendium — Sphere — Blacksmith |
| Five-Element Meridian Cycle | 12 | Five Elements Cultivator or at least three elemental Spheres, CL12+ | Constitution, Intelligence, Wisdom | Compendium — Qi — Elemental Refinement Insights |
| Fivefold Conversion | 4 | Qi Cultivation, CL4+ | Intelligence, Wisdom, Charisma | Core PHB |
| Flash-Step Duelist | 8 | Lightning sphere, Flash Step, CL 8+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Flesh-Reconstruction Insight | 4 | Flesh Sphere, CL 4+ | Constitution, Wisdom | Compendium — Body — Common Hybrid-Sphere Insights |
| Flowing Combination Adept | 6 | Iron Fist sphere, Flowing Combination, CL 6+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Flowing-River Adept | 4 | Flowing River Sphere, CL 4+ | Dexterity, Constitution, Wisdom | Compendium — Body — Common Might-Sphere Insights |
| Folded Reflexes | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Compendium — Sphere — Space |
| Fool’s Balance | 4 | Drunken Style sphere, CL 4+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Form-Script Custodian | 8 | Iron Fist sphere, Formations sphere, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Formation Apprentice | 4 | Formations Sphere, CL4+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Formation Breaker | 5 | Destruction sphere, Foundation Realm | Strength, Intelligence, Charisma | Compendium — Sphere — Destruction |
| Formation Breaker | 8 | Lightning sphere, Overload Ward, CL 8+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Formation Engineer | 8 | Formation Apprentice, CL8+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Formation Piercer | 10 | Formation Anchor Shot, CL 10+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Formation-Collapse Survivor | 4 | Survive a Formation collapse, spatial collapse, teleportation disaster, or prison Formation Tribulation | Constitution, Intelligence, Wisdom | Compendium — Qi — Tribulation Insights |
| Formation-Smasher Palm | 8 | Stone Fist, CL 8+ | Strength, Constitution | Compendium — Body — Advanced Subpath Insights |
| Formation-Wedge Cutter | 12 | Axes sphere, Axe Bites the Formation, CL 12+ | Strength, Dexterity, Constitution | Compendium — Sphere — Axes |
| Formula Archivist | 6 | Talismans sphere, CL 6+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Talismans |
| Fortune-Tempered Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Fate |
| Foundation Array Custodian | 8 | Earth sphere, Formations sphere, CL 8+ | Constitution, Strength, Wisdom | Compendium — Sphere — Earth |
| Four-Wind Adept | 8 | Air sphere, Breath Beyond the Skin, CL 8+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Air |
| Frozen Golden Core | 4 | Survive a Cold, Yin, Ice, or Stillness Tribulation | Constitution, Wisdom, Charisma | Compendium — Qi — Tribulation Insights |
| Furnace-Core Survivor | 4 | Survive a Fire, Magma, Ash, or Meridian-Flame Tribulation | Strength, Constitution, Charisma | Compendium — Qi — Tribulation Insights |
| Furnace-Heart Discipline | 4 | Magma, CL 4+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| Furnace-Soul Awakening | 4 | Spirit Awakening, CL4+ | Constitution, Wisdom, Intelligence | Compendium — Sphere — Magma |
| Furnace-Tyrant’s Stomach | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Alchemy |
| Gambler’s Instinct | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Core PHB |
| Gatekeeper’s Eye | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Compendium — Sphere — Space |
| Giant-Marrow Refinement | 8 | Flesh Crucible, CL 8+ | Strength, Constitution | Compendium — Body — Advanced Subpath Insights |
| Glass-Cutting Palm | 8 | Sand sphere, Glass Edge Scripture, CL 8+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sand |
| Gourd of the First Dune | 6 | Sand sphere, Hidden Cache of Grains or Gourd-Bound Sand Scripture, CL 6+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sand |
| Grace-Bearing Soul | 8 | Karma sphere, Spirit Awakening, CL8+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Karma |
| Gravekeeper | 4 | Death, CL 4+ | Wisdom, Intelligence, Charisma | Core PHB |
| Graveyard Sovereign | 12 | Bone Monarch and Bones or Death Sphere, CL 12+ | Constitution, Intelligence, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Gravitic Soul | 4 | Spirit Awakening, CL4+ | Strength, Intelligence, Wisdom | Compendium — Sphere — Gravity |
| Grounded Rod Body | 6 | Lightning Sphere and either Body Refining or Grounded Conductor Method, CL6+ | Constitution, Dexterity, Intelligence | Compendium — Sphere — Lightning |
| Guardian Armament | 12 | Domain Armament, CL12+ | Constitution, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Guardian-Body Adept | 4 | Guardian Sphere, CL 4+ | Constitution, Wisdom | Compendium — Body — Common Might-Sphere Insights |
| Hall Insider | 8 | Sect Stewardship, Hall Apprenticeship, CL 8+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Hard-Meridian Breathing | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Harmonic Analyst | 4 | Sound sphere, CL 4+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Sound |
| Harmonic Memory | 10 | Harmonic Package, CL 10+ | Intelligence, Charisma, Wisdom | Compendium — Sphere — Qiweaving |
| Heart-Demon Vanquisher | 4 | Survive a Heart-Demon, mental, Dream, Illusion, emotional, or identity Tribulation | Wisdom, Charisma | Compendium — Qi — Tribulation Insights |
| Heart-Devil Negotiator | 5 | Daemonic Cultivation and either Spirit Awakening or Wisdom 14+, CL5+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Heart-Stealing Resonance | 12 | Emotion Cultivator or access to Mind, Emotion, or Spirit manipulation; CL12+ | Wisdom, Charisma | Compendium — Qi — Forbidden, Condemned, and Predatory Insights |
| Heartstring Physician | 10 | Music sphere, Healing Hymn, CL 10+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Heaven's Conduit | 16 | Qi Cultivation, CL16+ | Constitution, Wisdom, Charisma | Core PHB |
| Heaven's Scar | 4 | Survive an extraordinary, unique, Secret, Immortal, or Heaven-recognized Tribulation; approval | Constitution, Wisdom, Charisma | Compendium — Qi — Tribulation Insights |
| Heavenly Meridian Reconstruction | 16 | Body Refining, CL 16+ | Constitution, Wisdom | Core PHB |
| Heaven’s Distance Student | 12 | Star-Scraper Line, CL 12+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Heaven’s Witness | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Karma |
| Heavy Armament Conduction | 8 | Qi Cultivation, proficiency with a two-handed heavy weapon or another weapon classified as a heavy armament, CL8+ | Strength, Constitution, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Heirloom Etiquette | 4 | Spirit Heirloom Method | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Herb-Gatherer’s Foundation | 4 | Harvesting and Gathering, CL 4+. | Wisdom, Intelligence, Constitution | Core PHB |
| Hidden Carrier Insight | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Disease |
| Hidden Command | 8 | Imbuement sphere, Quiet and Resound or Read the Vessel, CL 8+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Hidden Implement Discipline | 4 | Weapons sphere, CL 4+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Hidden Sleeve Adept | 6 | Hidden Sleeve Preparation, CL 6+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Talismans |
| Hidden Spool Discipline | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Hollow-Meridian Circulation | 12 | Void Sphere or Void-Touched Cultivator, CL12+ | Constitution, Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Hollow-Script Custodian | 10 | CL 10+, Void sphere | Wisdom, Intelligence, Charisma | Compendium — Sphere — Void |
| Hook Master | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Compendium — Sphere — Chains |
| Hybrid-Sphere Refinement | 4 | One Hybrid Sphere, CL4+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Cross-Sphere Insights |
| Ice-Sure Footwork | 4 | Ice sphere | Wisdom, Intelligence, Constitution | Compendium — Sphere — Ice |
| Impact Tempering | 4 | Destruction Sphere, Body Refining | Strength, Constitution, Intelligence | Compendium — Sphere — Destruction |
| Imperial Academy Graduate | 4 | Recognized academy access, CL4+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Imperial Training Insights |
| Imperial Archivist | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom | Compendium — Qi — Imperial Training Insights |
| Imperial Armory Certification | 4 | Imperial, military, sect-armory, or equivalent authorization, CL4+ | Strength, Dexterity, Intelligence | Compendium — Qi — Imperial Training Insights |
| Imperial Examination Laureate | 8 | Imperial Academy Graduate, successful examination or equivalent recognition, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Imperial Training Insights |
| Imperial Officer's Circulation | 8 | Military, guard, administrative, or command training, CL8+ | Constitution, Intelligence, Charisma | Compendium — Qi — Imperial Training Insights |
| Imperial Quartermaster Training | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Preparation and Strategic Insights |
| Impossible Recovery | 8 | Drunken Style sphere, Swaying Guard, CL 8+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Inked Body | 4 | Body Refining, CL4+ | Constitution, Intelligence, Dexterity | Compendium — Sphere — Ink |
| Inner Vessel Discipline | 4 | Spirit Companions Sphere, Body Refining | Constitution, Wisdom, Charisma | Compendium — Sphere — Spirit Companions |
| Internal Weapon Scripture | 4 | Body Refining, CL 4+ | Strength, Dexterity, Constitution | Core PHB |
| Internalized Sphere Insight | 4 | Body Refining and access to one Power sphere; CL4+ | Constitution, Intelligence, Wisdom, Charisma | Compendium — Body — Internalizing Power Spheres |
| Iron Belly Foundation | 5 | Hunger sphere, Foundation Realm | Constitution, Strength, Wisdom | Compendium — Sphere — Hunger |
| Iron Captain | 8 | Warleader sphere, Shieldbrothers or Ironclad Line, CL 8+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Iron Mercy | 4 | Life Sphere and Body Refining | Constitution, Wisdom, Charisma | Compendium — Sphere — Life |
| Iron Shirt Adept | 8 | Iron Fist sphere, Body Conditioning or Iron Shirt Practice, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Iron-Blood Circulation | 4 | Body Refining, CL 4+ | Constitution | Core PHB |
| Ironwood Staff Scripture | 8 | Bojutsu and Wood or Metal Sphere, CL 8+ | Strength, Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Item-Spirit Midwife | 10 | Blacksmith sphere, Spirit-Listening Tap, CL 10+ | Intelligence, Strength, Constitution | Compendium — Sphere — Blacksmith |
| Jade Inscription Master | 12 | Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another durable-inscription Source Rule, CL12+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Jade-Seal Preserver | 8 | Harvesting and Gathering, Spirit-Sealing Wax, CL 8+. | Wisdom, Intelligence, Constitution | Compendium — Sphere — Harvesting Gathering |
| Karmic Body | 4 | Body Refining, CL4+, secret karmic initiation | Constitution, Wisdom, Charisma | Compendium — Sphere — Karma |
| Karmic Ledger Within the Core | 12 | Karma-Thread Cultivator, Oath-Ledger Cultivator with Karma access, or genuine Karma Secret authority; CL12+ | Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Keeper of the Funeral Wick | 4 | Wax sphere or Spirit Awakening | Intelligence, Wisdom, Constitution | Core PHB |
| Lattice Scholar | 4 | Ice sphere, Qi Cultivation or Intelligence 13+ | Wisdom, Intelligence, Constitution | Compendium — Sphere — Ice |
| Lava-Walking Immortal | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| Lawful Captor | 4 | Chains sphere | Strength, Dexterity, Wisdom | Core PHB |
| Ledger-Bound Memory | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Ledger-Safe Tongue | 4 | Karma sphere, CL 4+ | Wisdom, Charisma, Intelligence | Core PHB |
| Lightning-God Disciple | 6 | Lightning sphere, Lightning-God Body, CL 6+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Lightning-Scarred Meridians | 4 | Survive a Lightning or Heaven-Thunder Tribulation | Dexterity, Constitution, Charisma | Compendium — Qi — Tribulation Insights |
| Living Anchor | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Compendium — Sphere — Chains |
| Living Bellows Body | 6 | Air Sphere, Body Refining, CL6+ | Constitution, Dexterity, Wisdom | Compendium — Sphere — Air |
| Living Illustration Adept | 8 | Painted Beast, CL 8+. | Intelligence, Dexterity, Wisdom | Compendium — Sphere — Ink |
| Living Siege Engine | 8 | Body Refining, CL 8+ | Strength, Constitution | Core PHB |
| Loaded Destiny | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Fate |
| Logging Breath Body | 6 | Axes Sphere, Body Refining, Work-Axe Eye, CL6+ | Strength, Constitution, Dexterity | Compendium — Sphere — Axes |
| Mandate Breaker | 10 | Counter-Mandate, CL 10+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Mandate-Bearing Voice | 12 | Fate, CL 12+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Fate |
| Master Calligrapher | 8 | Ink sphere, CL 8+. | Intelligence, Dexterity, Wisdom | Compendium — Sphere — Ink |
| Master of Repairs | 6 | Blacksmith sphere, Close the Crack, CL 6+ | Intelligence, Strength, Constitution | Core PHB |
| Master Seal Engraver | 4 | Wax sphere. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Wax |
| Medicine Saint | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Alchemy |
| Medicine-Field Steward | 4 | Harvesting and Gathering, CL 4+. | Wisdom, Intelligence, Constitution | Compendium — Sphere — Harvesting Gathering |
| Merciful Reaper | 8 | Death, CL 8+ | Wisdom, Intelligence, Charisma | Core PHB |
| Merciless Accountant | 10 | Karma sphere, CL 10+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Karma |
| Meridian Economy | 4 | Qi Cultivation, CL4+ | Intelligence, Charisma | Core PHB |
| Meridian Fortress | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Core PHB |
| Meridian Lightning Physician | 8 | Lightning sphere, Medicine proficiency, Life sphere or Pressure Points sphere, CL 8+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Meridian Needle Training | 4 | Thread sphere and Surgeon’s Stitch. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Meridian Overchannel | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Charisma | Core PHB |
| Meridian Student | 8 | Iron Fist sphere, Meridian-Sealing Palm, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Iron Fist |
| Meridian-Breath Discipline | 4 | Body Refining, CL 4+ | Constitution, Wisdom | Core PHB |
| Meridian-Pincer Method | 8 | Mantis Style, CL 8+ | Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Method-Bearing Grip | 8 | Weapons sphere, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Might-Sphere Discipline | 4 | Narrative access to one approved Might Sphere, CL4+ | Strength, Constitution, Intelligence, Charisma | Compendium — Qi — Cross-Sphere Insights |
| Mine-Warden's Ear | 5 | Metal sphere, Foundation Realm | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Mirror of Frozen Breath | 4 | Ice sphere and either Spirit Awakening or Wisdom 13+ | Wisdom, Intelligence, Constitution | Compendium — Sphere — Ice |
| Missing-Step Technique | 12 | Void Sphere, Void-Touched Cultivator, or Missing-Step inheritance; CL12+ | Dexterity, Intelligence, Charisma | Compendium — Qi — Secret-Law Insights |
| Mission-Born Reputation | 8 | Sect Stewardship, Notice Board Reader, CL 8+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Monkey-Body Adept | 4 | Monkey Style Sphere, CL 4+ | Dexterity, Constitution | Compendium — Body — Common Might-Sphere Insights |
| Monster-Taste Scholar | 4 | Hunger sphere | Constitution, Strength, Wisdom | Compendium — Sphere — Hunger |
| Moon-Thread Weight | 8 | Gravity sphere, CL 8+. | Strength, Intelligence, Wisdom | Compendium — Sphere — Gravity |
| Mountain Stance | 4 | Gravity sphere, CL 4+. | Strength, Intelligence, Wisdom | Core PHB |
| Mountain-Core Stability | 4 | Survive an Earth, Gravity, Mountain, pressure, or crushing Tribulation | Strength, Constitution, Wisdom | Compendium — Qi — Tribulation Insights |
| Mountain-Forged Frame | 4 | Body Refining, CL 4+ | Strength, Constitution | Core PHB |
| Name the Distant Enemy | 12 | Stars, CL 12+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Name-Sealing Demon Chain | 10 | Demon Mark, Fate or Ink sphere, CL 10+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Name-Sheltering Talisman | 8 | Fate, CL 8+ | Wisdom, Charisma, Intelligence | Compendium — Sphere — Fate |
| Named Blade Listener | 4 | Sabers sphere, Spirit Awakening, one named saber focus | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Named Tool Custodian | 4 | Blacksmith sphere, Name the Purpose, CL 4+ | Intelligence, Strength, Constitution | Core PHB |
| Named Treasure Recall | 8 | Qi Cultivation, one named weapon, shield, instrument, or cultivation implement that recognizes your bond, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Nascent Soul Externalization | 16 | Nascent Soul, CL16+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Nascent Soul Reserve | 16 | Nascent Soul, CL16+ | Constitution, Wisdom, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Nightmare Feaster | 12 | Dream Qi Cultivator or Dreams Sphere, CL12+ | Wisdom, Charisma | Compendium — Qi — Forbidden, Condemned, and Predatory Insights |
| Nine-Finger Director | 8 | Puppetry sphere, Two-Body Control, CL 8+ | Intelligence, Dexterity, Charisma | Compendium — Sphere — Puppetry |
| No Loose Ends | 10 | Thread sphere, CL 10+. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| No Road Behind Me | 10 | Space sphere, CL 10+. | Intelligence, Wisdom, Dexterity | Compendium — Sphere — Space |
| No-Rout Commander | 10 | Warleader sphere, Rallying Speech or Harangue, CL 10+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Null-Script Adept | 4 | Erode Technique | Wisdom, Intelligence, Charisma | Compendium — Sphere — Void |
| Oathkeeper | 8 | Karma sphere, CL 8+ | Wisdom, Charisma, Intelligence | Core PHB |
| Observatory Heir | 12 | Stars, CL 12+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Obsidian Sculptor | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| One Breath, One Line | 10 | Perfect Shot, CL 10+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| One-Breath Discipline | 8 | Karate, CL 8+ | Strength, Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Open the Outer Maw | 5 | Hunger Sphere, Body Refining, Foundation Realm, Constitution 16+, Stomach Furnace Scripture | Constitution, Strength, Wisdom | Compendium — Sphere — Hunger |
| Open the Outer Ore Insight | 5 | Metal Sphere, Body Refining, Foundation Realm, Iron Body Only Scripture | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Order Ledger Disciple | 6 | Warleader sphere, CL 6+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Orthodox Mask of the Black Scripture | 8 | Daemonic Cultivation, CL 8+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Outer Gate Beloved | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Compendium — Sphere — Sect Stewardship |
| Paired-Weapon Instructor | 6 | Dual Wielding sphere, CL 6+ | Dexterity, Strength, Constitution | Compendium — Sphere — Dual Wielding |
| Patient Inscription | 4 | Ink sphere. | Intelligence, Dexterity, Wisdom | Core PHB |
| Patient Trigger | 4 | Sniper sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Perfect Pitch | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Pill Master’s Eyes | 8 | Alchemy, CL 8+. | Intelligence, Wisdom, Constitution | Core PHB |
| Pill Sovereign’s Ledger | 12 | Alchemy, CL 12+. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Alchemy |
| Plague Physician | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Core PHB |
| Plague-Bearing Body Insight | 4 | Body Refining, CL4+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Disease |
| Poise-Tempered Presence | 4 | Beauty sphere, CL 4+ | Charisma, Wisdom, Dexterity | Core PHB |
| Poisoned-Meridian Scripture | 12 | Poison Cultivator or Poison Sphere, CL12+ | Constitution, Intelligence, Wisdom | Compendium — Qi — Forbidden, Condemned, and Predatory Insights |
| Poleaxe Door-Guard | 6 | Axes sphere, Poleaxe Gate, CL 6+ | Strength, Dexterity, Constitution | Compendium — Sphere — Axes |
| Portable Workshop | 8 | One preparation-based Sphere or Subpath, CL8+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Prison Warden | 8 | Chains sphere, CL 8+ | Strength, Dexterity, Wisdom | Compendium — Sphere — Chains |
| Profile Archivist | 4 | Weapons sphere, Profile Specialist | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Prop Scripture Initiate | 6 | Drunken Style sphere, Accidental Weapon, CL 6+ | Dexterity, Constitution, Charisma | Compendium — Sphere — Drunken Style |
| Proper Seniority | 4 | Sect Stewardship, CL 4+. | Charisma, Intelligence, Wisdom | Core PHB |
| Proper Weight of the Tool | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Provincial Ley-Line Familiarity | 8 | Qi Cultivation, CL8+ | Intelligence, Wisdom | Compendium — Qi — Imperial Training Insights |
| Psychopomp’s Courtesy | 8 | Death sphere, Spirit Awakening, CL8+ | Wisdom, Intelligence, Charisma | Core PHB |
| Pulse-Thread Memory | 4 | Life sphere. | Wisdom, Constitution, Charisma | Compendium — Sphere — Life |
| Puppet Artisan | 4 | Puppetry sphere, proficiency with one appropriate tool, CL 4+ | Intelligence, Dexterity, Charisma | Compendium — Sphere — Puppetry |
| Qi Devourer | 8 | Qi Cultivation, CL8+ | Constitution, Wisdom, Charisma | Core PHB |
| Qi-Tempered Concentration | 8 | Qi Cultivation, CL8+ | Constitution, Intelligence, Charisma | Core PHB |
| Quarantine Adept | 8 | Disease, CL 8+ | Constitution, Intelligence, Wisdom | Core PHB |
| Quiet After the Shot | 8 | Sniper sphere, CL 8+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Radiance’s Blessing | 4 | Radiance | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Red Execution Discipline | 8 | Axes sphere, Execution Mark, CL 8+ | Strength, Dexterity, Constitution | Compendium — Sphere — Axes |
| Red Sash Pursuer | 4 | Sabers sphere, Red Trail Pursuit | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Red Seal Authority | 10 | Ink sphere, CL 10+. | Intelligence, Dexterity, Wisdom | Compendium — Sphere — Ink |
| Red Thread Sensitivity | 4 | Thread sphere and Spirit Awakening, Karma sphere, Heartbinder, Knot Weaver, or another printed Source Rule authorizing relationship perception | Dexterity, Intelligence, Wisdom | Core PHB |
| Reeling-Immortal Adept | 4 | Reeling Immortal Sphere, CL 4+ | Dexterity, Constitution, Charisma | Compendium — Body — Common Might-Sphere Insights |
| Refined Golden Bell | 12 | Golden Bell, CL 12+ | Constitution, Wisdom | Core PHB |
| Refined Meridian Regulation | 4 | Meridian Regulation, CL4+ | Constitution, Intelligence, Wisdom | Core PHB |
| Refined Natural Weapon | 4 | Body Refining, CL 4+ | Strength, Dexterity, Constitution | Core PHB |
| Refuse the Forbidden Bowl | 4 | Hunger sphere | Constitution, Strength, Wisdom | Compendium — Sphere — Hunger |
| Remote Weapon Conduction | 12 | Domain Armament Link, CL12+ | Dexterity, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Reservoir Core Refinement | 10 | Golden Core Reservoir, CL10+ | Constitution, Intelligence, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Resonance Breaker | 10 | Music sphere, Disruptive Harmony or Silence-Breaking Note, CL 10+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Restorative Circulation | 4 | Qi Cultivation, CL4+ | Constitution, Intelligence, Wisdom | Core PHB |
| Restricted Sphere License | 8 | Imperial, sectarian, hereditary, professional, or equivalent authorization; CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Cross-Sphere Insights |
| Returning-Tide Body | 8 | Jujutsu, CL 8+ | Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Ricochet Savant | 6 | Bouncing Shot, CL 6+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| River Without Edges | 10 | Flowing River sphere, CL 10+ | Dexterity, Wisdom, Constitution | Compendium — Sphere — Flowing River |
| Road-and-Wall Adept | 6 | Earth sphere, one Settlement talent, CL 6+ | Constitution, Strength, Wisdom | Compendium — Sphere — Earth |
| Ruin Pearl Handler | 4 | Destruction sphere, Calamity Pearl | Strength, Intelligence, Charisma | Compendium — Sphere — Destruction |
| Ruin Without Hatred | 8 | Unmaking sphere, Spirit Awakening, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Ruin-Safe Grip | 4 | Unmaking sphere, CL 4+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Samsara Memory | 8 | Samsara-Wheel Cultivator, reincarnation inheritance, or genuine former-life awakening; CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Sand-Born Footwork | 4 | Sand sphere, CL 4+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sand |
| Scripture Breaker | 8 | Ink sphere, CL 8+. | Intelligence, Dexterity, Wisdom | Compendium — Sphere — Ink |
| Seal Breaker | 8 | Talismans Sphere, Cultivator of Seals, Puzzle Cultivator, Calligraphy Cultivator, or another seal-authorized Source Rule, CL8+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Sealed Demon Seed | 4 | Daemonic Cultivation, CL 1+ | Constitution, Wisdom, Charisma | Compendium — Sphere — Daemonic Cultivation |
| Secret Authority Contention | 16 | One Secret Law, CL16+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| Sect Imbuement Seal | 12 | Imbuement sphere, Talismans or Formations sphere, CL 12+ | Intelligence, Constitution, Charisma | Compendium — Sphere — Imbuement |
| Sect Infirmary Disciple | 4 | Life sphere. | Wisdom, Constitution, Charisma | Compendium — Sphere — Life |
| Sect Supply Officer | 8 | Harvesting and Gathering, Field Ledger, CL 8+. | Wisdom, Intelligence, Constitution | Compendium — Sphere — Harvesting Gathering |
| Sect Waxwright | 5 | Wax sphere, CL 5. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Wax |
| Seven-Star Battle Rhythm | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Severed Thread Recovery | 8 | Puppetry sphere, CL 8+ | Intelligence, Dexterity, Charisma | Compendium — Sphere — Puppetry |
| Shared Breath Guardian | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Core PHB |
| Shared Breath Method | 4 | Qi Bond Package | Intelligence, Charisma, Wisdom | Compendium — Sphere — Qiweaving |
| Shatter Without Waste | 5 | Ice sphere, Foundation Realm | Wisdom, Intelligence, Constitution | Compendium — Sphere — Ice |
| Shield Orbit Discipline | 8 | Domain Armament capable of Guard Mode, CL8+ | Constitution, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Shield-Breaking Eye | 4 | Sabers sphere | Strength, Dexterity, Wisdom | Compendium — Sphere — Sabers |
| Shieldhook Adept | 4 | Axes sphere, Shield-Catching Beard, CL 4+ | Strength, Dexterity, Constitution | Compendium — Sphere — Axes |
| Siege-Magma Adept | 8 | Magma, CL 8+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| Silent Foundation | 5 | Dampen Sound or Muffle Footfall, CL 5+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Sound |
| Silk-Reeling Foundation | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Solar Heart | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Song-Soul Oathbearer | 10 | Spirit Awakening, Music sphere, CL10+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Soul Shackles | 4 | Spirit Awakening, Chains sphere, CL4+ | Strength, Dexterity, Wisdom | Compendium — Sphere — Chains |
| Soul-Devouring Scripture | 12 | Qi Devourer, access to a forbidden or predatory manual, CL12+ | Constitution, Wisdom, Charisma | Compendium — Qi — Forbidden, Condemned, and Predatory Insights |
| Soul-Hearing Listener | 10 | Soul-Echo Hearing, Spirit Awakening, CL10+ | Charisma, Wisdom, Constitution | Core PHB |
| Soul-Return Witness | 4 | Life sphere, Spirit Awakening | Wisdom, Constitution, Charisma | Core PHB |
| Spatial Artisan | 8 | Space sphere, CL 8+. | Intelligence, Wisdom, Dexterity | Compendium — Sphere — Space |
| Spatial Meridian Body | 4 | Body Refining, CL4+, Constitution 15+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Space |
| Spear-Body Adept | 4 | Spear Sphere and suitable training, CL 4+ | Strength, Dexterity, Constitution | Compendium — Body — Common Might-Sphere Insights |
| Spirit Instrument | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Spirit-Adjacent Scripture | 8 | Narrative access to one approved Spirit-adjacent Sphere, CL8+ | Intelligence, Wisdom, Charisma | Compendium — Qi — Cross-Sphere Insights |
| Spirit-Broker Reputation | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Core PHB |
| Spotter’s Thread | 6 | Sniper sphere, CL 6+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Spring-Founding Adept | 12 | Water sphere, Sacred Spring, CL 12+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Stable Core Refinement | 10 | Stable Golden Core, CL10+ | Constitution, Intelligence, Charisma | Compendium — Qi — Golden Core and Nascent Soul Insights |
| Stable Wild Meridian | 4 | Turbulence Package | Intelligence, Charisma, Wisdom | Compendium — Sphere — Qiweaving |
| Stage of Ten Thousand Hands | 12 | Puppetry sphere, Puppet Theater Domain, CL 12+ | Intelligence, Dexterity, Charisma | Compendium — Sphere — Puppetry |
| Standard Bearer Adept | 4 | Warleader sphere, CL 4+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Star-Blooded Body | 4 | Body Refining, CL4+ | Constitution, Wisdom, Intelligence | Compendium — Sphere — Stars |
| Star-Sundering Preparation | 14 | Unmaking sphere, CL 14+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Star-Walking Immortal | 8 | Stars, CL 8+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Stars |
| Storm Instrumentalist | 6 | Lightning sphere, Spark-Instrument Method, Music or Sound sphere, CL 6+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Storm Partner | 8 | Lightning sphere, Weather sphere or an allied Weather cultivator, CL 8+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Storm-Eye Disciple | 12 | Air sphere, Court of the Four Winds, CL 12+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Air |
| Storm-Eye Meditation | 4 | Survive a Weather, Air, Wind, Storm, or Lightning Tribulation | Intelligence, Wisdom, Charisma | Compendium — Qi — Tribulation Insights |
| Strange Weapon Familiarity | 6 | Weapons sphere, CL 6+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Student of the Returning Current | 4 | Flowing River sphere | Dexterity, Wisdom, Constitution | Core PHB |
| Sword-Bone Insight | 4 | Sword Sphere, CL 4+ | Strength, Dexterity, Constitution | Compendium — Body — Common Hybrid-Sphere Insights |
| Sword-Line Meridian | 12 | Kensei and Sword Sphere, CL 12+ | Dexterity, Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| Sword-Tribulation Survivor | 4 | Survive a Sword, Saber, Blade, Weapon, or Killing-Intent Tribulation | Dexterity, Constitution, Wisdom | Compendium — Qi — Tribulation Insights |
| Sympathetic Effigy Worker | 5 | Wax sphere, CL 5, GM permission. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Wax |
| Talisman Body | 4 | Body Refining, Talismans Sphere, CL4+ | Constitution, Intelligence, Wisdom | Compendium — Sphere — Talismans |
| Talisman Savant | 8 | Talismans Sphere, CL8+ | Intelligence, Wisdom | Compendium — Qi — Preparation and Strategic Insights |
| Talisman Thief | 4 | Talismans sphere or Scoundrel sphere, CL 4+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Talismans |
| Tempered Knuckles | 4 | Iron Fist sphere, CL 4+ | Strength, Dexterity, Constitution | Core PHB |
| Tempered Reflexes | 8 | Body Refining, CL 8+ | Dexterity, Constitution | Core PHB |
| Ten Thousand Tools Mind | 10 | Weapons sphere, CL 10+ | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Ten-Thousand-Step Pilgrimage | 8 | Yamabushi, CL 8+ | Constitution, Wisdom | Compendium — Body — Advanced Subpath Insights |
| The Hand That Pays | 8 | Unmaking sphere, CL 8+ | Intelligence, Wisdom, Charisma | Compendium — Sphere — Unmaking |
| Thousand-Knot Memory | 4 | Thread sphere. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Thousand-Lamp Meditation | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Thousand-Mile Forager | 8 | Harvesting and Gathering, CL 8+. | Wisdom, Intelligence, Constitution | Compendium — Sphere — Harvesting Gathering |
| Threaded Weapon Adept | 4 | Thread sphere and proficiency with at least one melee or thrown weapon. | Dexterity, Intelligence, Wisdom | Compendium — Sphere — Thread |
| Thunder Archer | 6 | Lightning sphere, Crackling Arrow or Thunder Arrow, CL 6+ | Dexterity, Intelligence, Charisma | Compendium — Sphere — Lightning |
| Thunderstep | 4 | Qi Cultivation, CL4+ | Dexterity, Intelligence, Charisma | Core PHB |
| Tidal Body | 4 | Water sphere, CL 4+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Tide-Court Footwork | 12 | Water sphere, Court of the Endless Tide, CL 12+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Tomb Architect | 10 | Death, Formations or Protection, CL 10+ | Wisdom, Intelligence, Charisma | Compendium — Sphere — Death |
| Transformation-Stability Insight | 8 | Transformation Sphere, CL 8+ | Constitution, Wisdom | Compendium — Body — Common Hybrid-Sphere Insights |
| Trap-Sniper Method | 8 | Trap Technician, CL 8+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Sniper |
| Tremor-Reader Adept | 8 | Earth sphere, Tremor-Listening Palm, CL 8+ | Constitution, Strength, Wisdom | Core PHB |
| Twice-Tribulated | 4 | Survive two different Realm Tribulations | Constitution, Wisdom, Charisma | Compendium — Qi — Tribulation Insights |
| Two-Moons Focus | 8 | Dual Wielding sphere, CL 8+ | Dexterity, Strength, Constitution | Compendium — Sphere — Dual Wielding |
| Unbroken Grace | 6 | Beauty sphere, CL 6+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Beauty |
| Unhidden Path | 8 | Radiance, CL 8+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Radiance |
| Unmelting Temper | 10 | Wax sphere, CL 10. | Intelligence, Wisdom, Constitution | Compendium — Sphere — Wax |
| Unshaken Rhythm | 8 | Music sphere, CL 8+ | Charisma, Wisdom, Dexterity | Compendium — Sphere — Music |
| Unyielding Grip | 8 | Body Refining, CL 8+ | Strength, Constitution | Core PHB |
| Vessel Artisan | 4 | Spirit Companions sphere | Wisdom, Charisma, Constitution | Core PHB |
| Vessel-Body Scripture | 6 | Imbuement Sphere, Body Refining, CL6+ | Constitution, Intelligence, Charisma | Compendium — Sphere — Imbuement |
| Voice That Carries | 6 | Warleader sphere, one Shout talent, CL 6+ | Charisma, Wisdom, Intelligence | Compendium — Sphere — Warleader |
| Void Ward Adept | 4 | Void Ward | Wisdom, Intelligence, Charisma | Compendium — Sphere — Void |
| Void-Body Initiate | 4 | Body Refining, Void Sphere, and a recorded Void initiation, lineage, manual, teacher, tribulation, or other legal access source | Constitution, Wisdom, Intelligence | Compendium — Sphere — Void |
| Void-Touched Core | 4 | Void Sphere, Void-Touched Cultivator, survival of genuine Void exposure, or equivalent Secret access | Constitution, Intelligence, Charisma | Compendium — Qi — Secret-Law Insights |
| Volcanic Collateral Control | 6 | Magma, CL 6+ | Constitution, Strength, Intelligence | Compendium — Sphere — Magma |
| Water-Walking Immortal | 6 | Water sphere, CL 6+ | Wisdom, Dexterity, Constitution | Compendium — Sphere — Water |
| Wax-Tempered Body | 4 | Body Refining or a recorded Wax inheritance, manual, teacher, transformation, or other legal access source | Constitution, Dexterity, Wisdom | Compendium — Sphere — Wax |
| Weapon Exchange Drill | 4 | Weapons sphere | Strength, Dexterity, Constitution | Compendium — Sphere — Weapons |
| Weapon-and-Technique Weave | 4 | Qi Cultivation, proficiency with at least one weapon, CL4+ | Dexterity, Intelligence, Charisma | Compendium — Qi — Martial and Domain Armament Insights |
| Wheel Refuses the End | 16 | Samsara-Wheel Cultivator or reincarnation Secret authority, CL16+ | Constitution, Wisdom, Charisma | Compendium — Qi — Secret-Law Insights |
| White Tiger Restraint | 4 | Metal sphere | Constitution, Strength, Intelligence | Compendium — Sphere — Metal |
| Wind-Line Archer | 6 | Air sphere, Sniper or Barrage sphere, CL 6+ | Dexterity, Wisdom, Intelligence | Compendium — Sphere — Air |
| Wine-Gourd Immortal | 8 | Drunken Fist, CL 8+ | Constitution, Charisma | Compendium — Body — Advanced Subpath Insights |
| Winter Tempered Body | 4 | Ice Sphere and either Body Refining or Constitution 13+ | Constitution, Wisdom, Intelligence | Compendium — Sphere — Ice |
| World-Ringing Bell Keeper | 10 | Resonant Shatter, CL 10+ | Charisma, Wisdom, Constitution | Compendium — Sphere — Sound |
| Wrestling-Body Adept | 4 | Wrestling Sphere, CL 4+ | Strength, Constitution | Compendium — Body — Common Might-Sphere Insights |

## Maintaining One Canonical Insight Record

Each Insight has one canonical record in the Central Cultivation Insights reference. The PHB and Compendium reproduce player-facing text from that record. Path chapters, Subpath compendia, the Character Factory, and the GM Screen should reference the Insight by canonical ID rather than maintaining independent rewritten copies.

---

# 08. Subpaths, Traditions, and Cultivation Lineages

A **Subpath** is the specialized progression through which a Path becomes a particular school, scripture, tradition, inheritance, lineage, method, or law. Your Path establishes the cultivation chassis. Your Subpath establishes the distinctive route you follow within that Path.

Body Refining calls many of its Subpaths **Schools**, **Bodies**, **Scriptures**, or **Inheritances**. Qi Cultivation uses names such as **Schools**, **Scriptures**, **Lineages**, **Variants**, and **Secret Laws**. Spirit Awakening commonly calls them **Traditions**. These are local names for the same rules structure.

This chapter explains how to choose a Subpath, how access works, how multi-Path cultivators progress, how parent and Variant progressions replace one another, and how Source CL and Realm Suppression affect Subpath features. The complete rules for individual options appear in the separate Path compendia.

## The Subpath Progression

Each active Path provides one Subpath progression.

| Cultivation Level | Subpath event |
|---:|---|
| **3** | Choose one legal Subpath for that Path and gain its CL3 features. |
| **6** | Gain its CL6 features. |
| **10** | Gain its CL10 features. |
| **14** | Gain its CL14 features. |
| **18** | Gain its CL18 features. |

A Subpath feature is a Path feature. It uses that Path's key ability, Cultivation Save DC, Cultivation Attack Modifier, Cultivation Points, and other Path rules unless the feature expressly states otherwise.

A Subpath does not grant a Sphere, talent, Foundation, Method, item, companion, office, bloodline, or Recorded Art merely because its theme resembles one. It grants only the rules it prints.

## Choosing a Subpath at CL3

When you reach CL3, complete the following steps for each Path you possess.

1. **Choose the Path slot.** Identify the Path whose Subpath you are selecting.
2. **Choose a legal option.** Select one Subpath from that Path's compendium for which you have legal access.
3. **Record the access source.** Record the teacher, sect permission, lineage, inheritance, shrine, relic, mutation, revelation, pact, manual, office, corruption event, or other Source Rule that grants access.
4. **Record classifications and tags.** Record the Subpath's access class and any Inherited, Variant, Daemonic, bloodline, spirit, organizational, or other printed tag.
5. **Gain the CL3 features.** Add every feature, resource, state, Asset, Anchor, transformation, companion interface, or procedure granted at CL3.
6. **Add executable records.** Any activated, triggered, passive, procedural, or state-based feature must be represented on the character record in the form required by its rules.

### Delayed Selection

A character who reaches CL3 without legal access to a Subpath does not invent an access source or ignore the requirement. Leave that Path's Subpath slot unfilled.

When the character later gains legal access, select the Subpath and immediately gain all of its features through the character's current effective CL. Delaying selection does not grant a second Subpath, extra features, or compensation.

### Changing a Subpath

A Subpath is not ordinary retraining. Changing it requires an explicit Source Rule, a parent-to-Variant conversion, or a story procedure that identifies what happens to the former progression. A rest, downtime payment, or change of preference is not enough by itself.

## One Subpath per Active Path

A character has one Subpath slot for each complete Path they possess.

- A Body Refiner has one Body Refining Subpath.
- A Qi Cultivator has one Qi Cultivation Subpath.
- A Spirit Awakener has one Spirit Awakening tradition.
- A multi-Path cultivator has one Subpath progression for each active Path.

A character cannot place two Subpaths in the same Path slot unless a Source Rule expressly grants a second complete progression. Copying, mirroring, stealing, simulating, temporarily invoking, or reproducing one feature does not grant another Subpath slot.

A Foundation, Method, Insight, Sphere, talent, item, Recorded Art, or Immortal Art can interact with a Subpath without becoming a second Subpath.

## Access Classes

The first five entries below are universal access classes. **Inherited** and **Variant** are relationship tags that can appear alongside an access class.

| Access class or tag | Player-facing meaning |
|---|---|
| **Open** | Commonly teachable or institutionally available. Open does not mean weak, free, or automatically known. A teacher, manual, school, sect, or other legal route may still be required. |
| **Restricted** | Controlled by a sect, clan, shrine, profession, military office, technical discipline, hazardous practice, political authority, or other gatekeeping institution. Record who granted permission and any continuing obligation. |
| **Rare** | Requires an uncommon source such as unusual anatomy, bloodline, mutation, reincarnated memory, spirit ancestry, relic fusion, singular teacher, exceptional environment, or unique inheritance. |
| **Forbidden** | Condemned, coercive, predatory, destabilizing, illegal, corruptive, or spiritually hazardous. Access requires an explicit source and does not erase legal, social, karmic, medical, or cultivation consequences. Forbidden does not automatically mean Daemonic. |
| **Secret** | Hidden law-level, singular, or high-authority cultivation requiring explicit discovery and every printed initiation price, oath, permanent mark, sacrifice, condition, or limitation. Knowledge that a Secret exists is not access to it. |
| **Inherited** | The progression is received through ancestry, reincarnation, awakening, mutation, relic or spirit integration, an ancestor, a bloodline, an existing bodily or spiritual structure, or another nonordinary transmission. Inherited is normally paired with Open, Restricted, Rare, Forbidden, or Secret. It is not automatically removable, teachable, or transferable. |
| **Variant** | The progression is an alternate form of a named parent Subpath. It occupies the parent's slot and replaces the parent features identified by its relationship rules. Variant is not a bonus overlay. |

### Related Tags

A compendium can print additional tags such as **Daemonic**, **Bloodline**, **Spirit-Bound**, **Organizational**, or **Martial Tradition**. A tag matters only where another rule refers to it.

The **Daemonic** tag does not itself define access. It matters for Corruption, purification, anti-daemonic effects, cultivation deviations, social consequences, and other rules that expressly refer to Daemonic cultivation.

## Legal Access Sources

Every Restricted, Rare, Forbidden, Secret, or Inherited selection must name a legal access source. An Open selection should also record how the character learned it.

A legal access source must be specific enough that a player, GM, or AI can answer the following questions without invention:

| Record field | Required information |
|---|---|
| **Source** | The teacher, manual, inheritance, sect, shrine, relic, spirit, bloodline, mutation, office, event, or other rule granting access. |
| **Authority** | Why that source can grant this particular Subpath. |
| **Access class and tags** | Open, Restricted, Rare, Forbidden, Secret, Inherited, Variant, and any additional printed tags. |
| **Price or obligation** | Training, permission, oath, offering, material cost, permanent price, taboo, service, corruption, injury, or other printed requirement. Record `None` when no special price exists. |
| **Continuing condition** | Any rule that can suspend, revoke, corrupt, transform, or end access. Record `None` when access is permanent and unconditional. |
| **Source CL** | The Source CL of the access effect when the access rule requires an authority comparison. |

Money, downtime, a thematically similar Sphere, or a successful generic check does not create access unless a rule establishes that route.

### Losing Permission and Losing the Progression

Loss of social permission does not automatically erase learned cultivation. A sect can outlaw, punish, expel, or refuse support without deleting features already integrated into the character.

A progression is suppressed, transformed, damaged, or removed only when an explicit rule says so. Secret prices, pacts, vows, spirit relationships, living inheritances, offices, and artifact bonds may print continuing conditions that differ from ordinary instruction.

## Minimum CL, Realm, and Source CL

The normal minimum CL for selecting a Subpath is CL3. Its later features require CL6, CL10, CL14, and CL18 respectively.

A Subpath can print an additional minimum Realm, Source CL, anatomy, Sphere, talent, Foundation, Method, relationship, office, bloodline, or story requirement. Those requirements are cumulative. Reaching the normal feature level does not waive them.

### Feature Source CL

Unless a feature states otherwise, a Subpath feature's Source CL equals the effective CL used to activate or sustain it.

Source CL measures cultivation authority when the feature collides with suppression, reconstruction, permanent harm, an Asset, Anchor, Field, Formation, Domain, route, Gate, possession, exorcism, or another high-authority effect. It does not replace the printed attack roll, saving throw, check, damage, duration, or target procedure.

### Access Source CL

An access source has a Source CL only when its rule needs one. A teacher does not need to be permanently stronger than the student merely to teach an Open school. An inheritance, Secret Law, living relic, bloodline awakening, corruption, or contested transfer can require a particular Source CL or authority comparison when its rule says so.

The Source CL that granted access and the Source CL of a later feature are separate values. Record both where both matter.

## Multi-Path Subpath Progression

A multi-Path character has one character CL. Every complete Path the character possesses advances at that CL.

For each Path:

- choose one legal Subpath at CL3 or when the Path is gained at CL3 or higher;
- gain that Subpath's features through the character's current CL;
- use that Path's key ability, Cultivation Save DC, attack modifier, and Cultivation Point pool;
- track that Subpath's resources, states, Assets, Anchors, transformations, and procedures separately unless a rule expressly combines them.

### Adding a Path after CL3

When a character gains a new Path at CL3 or higher:

1. gain the new Path's core features through the current CL;
2. choose one legal Subpath for that Path;
3. gain the selected Subpath's features through the current CL;
4. record all legal access sources and dependencies;
5. create the required executable and display records.

Adding a Path does not grant another character-level Ability Score Improvement, Cultivation Insight choice, level talent, Background benefit, or sect-trial benefit.

### Cross-Path Interaction

A feature belongs to the Path that grants it. It does not spend another Path's Cultivation Points or use another Path's key ability unless it expressly says so.

A Body transformation, Qi Field, and Spirit Domain can coexist when their individual rules allow it. Coexistence does not merge their action economy, Concentration, Source CL, or resources.

## Parent and Variant Progressions

A **parent Subpath** is the base progression named by a Variant. A **Variant** is an alternate progression of that parent.

### The Same Slot

A Variant occupies the same Subpath slot as its parent. It is not a second Subpath, a collection of bonus features, or an overlay placed on top of the parent.

A character cannot possess both complete progressions at the same CL unless an explicit Source Rule creates a temporary composite state and states exactly which features function.

### Direct Entry

At CL3, or when first receiving the Subpath choice, a character can select a Variant instead of the parent when a legal source grants direct access. The character gains the Variant's CL3 features and later gains only the Variant features.

### Conversion Entry

A character who already possesses the parent can convert when a breakthrough, inheritance awakening, corruption event, ritual, artifact bond, spirit pact, mutation, or another Source Rule permits it.

When the Variant does not print its own conversion procedure, use this default:

1. obtain legal access to the Variant;
2. complete one Full Cultivation Session for each attained Subpath feature;
3. pay every printed material, social, spiritual, bodily, or permanent price;
4. make a Cultivation Check against `10 + PB + the number of attained parent features`.

On a failure, the sessions and any expressly consumed prices are spent, but the parent remains. On a success, all attained parent features are replaced simultaneously by the matching Variant features.

A specific Variant can replace the check with a tribulation, story condition, unavoidable transformation, permanent price, corruption event, or another printed procedure.

### One-for-One Replacement

Each Variant relationship must identify the parent feature replaced at CL3, CL6, CL10, CL14, and CL18.

A replaced feature stops functioning. Its actions, Reactions, passive benefits, resources, transformations, Assets, Anchors, Fields, Domains, companions, and capstone are not retained unless the Variant expressly repeats or transforms them.

An ongoing effect sustained only by a replaced feature ends when conversion resolves. Instantaneous results, completed injuries, real items, paid prices, debts, scars, corruption, and other completed consequences remain.

### Compatibility with Parent Requirements

A Variant counts as its parent for prerequisites that name the parent progression generally. It does not satisfy a prerequisite that names a specific replaced feature unless the Variant expressly provides an equivalent.

A Variant's own access class, prices, restrictions, Corruption, and social consequences govern actual access and use.

### Parent Resources and Persistent Structures

A parent resource converts only when the Variant relationship says how. Otherwise, it is lost when conversion succeeds, and the Variant begins with its printed starting state.

Parent Assets, Anchors, Fields, Domains, companion states, and transformations disperse, end, or become inactive unless the Variant expressly transforms them. Long-term harm and completed consequences do not disappear.

### Reversion and Further Conversion

Conversion is not free retraining. Returning to the parent or entering another Variant requires another legal source and the applicable conversion procedure. Purification, restitution, repair, or removal of a permanent price can also be required.

A character cannot alternate between parent and Variant progressions between scenes, rests, or individual encounters unless an explicit feature grants that temporary authority.

### Temporary Copies

A temporary copy grants only the named feature. It does not grant the parent or Variant progression, compatibility, access classification, future features, initiation, or permanent conversion.

## Realm Suppression

Realm Suppression changes the effective CL used by the character's Paths and Subpaths.

Use the suppressed effective CL to determine which Subpath features are available:

| Effective CL after suppression | Available Subpath tiers |
|---:|---|
| **18 or higher** | CL3, CL6, CL10, CL14, and CL18 |
| **14–17** | CL3, CL6, CL10, and CL14 |
| **10–13** | CL3, CL6, and CL10 |
| **6–9** | CL3 and CL6 |
| **3–5** | CL3 only |
| **0–2** | No Subpath features are available. |

Realm Suppression does not erase the character's selection, access source, history, prices, scars, corruption, relationships, or completed consequences.

When a feature becomes unavailable:

- the character cannot activate it or use its passive permission;
- its scaling uses only the lower effective CL where the rule has lower-level scaling;
- an effect whose continued existence requires that feature is suppressed or ends under its own procedure;
- instantaneous results and completed injuries remain resolved;
- real items remain real items, though a bond or function dependent on the suppressed feature can become inactive;
- a parent-to-Variant conversion is not reversed.

A Source Rule can suppress one Path, one Subpath, one feature, one transformation, one Asset, one Anchor, one Field, one Domain, or another narrower structure when it expressly says so. Narrow suppression affects only the named structure.

## Subpath Records for Players, GMs, and AI

A complete Subpath record contains:

- Path and Subpath name;
- canonical ID where one is available;
- access class and tags;
- legal access source;
- parent and Variant relationship, if any;
- current effective CL and feature tiers;
- Source CL basis;
- actions, Reactions, Bonus Actions, passive modifiers, procedures, resources, and states;
- Assets, Anchors, Fields, Domains, companions, transformations, and anatomy changes;
- recovery and scene-reset procedures;
- Realm Suppression behavior;
- every displayed ability required for player, GM, and AI execution.

The source paragraph remains the controlling rule. A character record must express the feature faithfully; it cannot replace a missing mechanic with improvised text.

## The Separate Path Compendia

The PHB contains the shared selection rules and each Path's CL1–20 chassis. The complete Subpath catalogues are published separately because their combined scope is much larger than the core handbook.

| Compendium | Current player catalogue |
|---|---:|
| **Tianxia: Qi Cultivation Subpath Compendium** | 80 Qi Subpaths, including Open Schools, Restricted Scriptures, Rare Inheritances, Variants, Forbidden Variants, Secret Laws, and Daemonic Subpaths |
| **Tianxia: Body Refining Subpath Compendium** | 42 Body Refining Schools, Scriptures, Bodies, Methods, and Inheritances |
| **Tianxia: Spirit Awakening Tradition Compendium** | 34 Spirit Awakening traditions |

Each compendium contains:

- complete CL3/6/10/14/18 feature text;
- access classifications and legal-source guidance;
- Path-specific shared procedures;
- parent and Variant relationships where applicable;
- Source CL, Realm Suppression, Asset, Anchor, Field, Domain, transformation, companion, and recovery interfaces;
- indexes suitable for players, GMs, the Character Factory, and AI-assisted character creation.

The compendia expand choice; they do not replace the shared rules in this chapter or the Path chassis in Chapters 04–06.

## Subpath Selection Checklist

Before play, confirm all of the following:

- [ ] The character possesses the correct Path.
- [ ] The character is CL3 or higher, or another rule legally grants early access.
- [ ] Only one complete Subpath occupies that Path's slot.
- [ ] Every prerequisite is met.
- [ ] The access source is recorded.
- [ ] The access class and all tags are recorded.
- [ ] Any initiation price, oath, taboo, corruption, injury, service, or continuing obligation is recorded.
- [ ] Parent and Variant replacements are explicit.
- [ ] Every attained feature tier is added.
- [ ] Activated and triggered features have executable records.
- [ ] Passive statistics and state modifications are applied.
- [ ] Assets, Anchors, Fields, Domains, companions, transformations, and anatomy changes have complete records.
- [ ] Source CL and Realm Suppression behavior are recorded.
- [ ] The full player text is available in the correct Path compendium.

---

# 09. Spheres and Talents Overview

Spheres are the main way Tianxia characters express cultivation techniques. A Sphere is not a Path, Background, Origin Insight, Foundation, Method, or manual. It is a rules package for a particular kind of cultivation expression.

This chapter explains how Spheres and talents work during character creation and advancement. It does not reproduce the full Sphere catalog. For complete Sphere entries, talent lists, requirements, action rules, costs, and restrictions, use the **Sphere Compendium** and the individual Sphere entries.

## What a Sphere Is

A **Sphere** is a field of cultivation expression, such as Sword, Fire, Athletics, Talismans, or Spirit Companions. Each Sphere gives you access to a family of techniques, talents, passive benefits, and special rules.

Each Sphere should tell you:

- what the Sphere represents;
- what its base ability does, if it has one;
- what talents belong to it;
- what Realm or CL requirements apply;
- what actions, costs, ranges, targets, durations, and effects its active techniques use;
- what restrictions or special rules apply.

A Sphere does not let you create any effect that sounds thematically related. Use the printed Sphere rules. If a technique, talent, manual, item, or feature gives you a specific effect, use that printed effect.

## Known Spheres

A **known Sphere** is a Sphere whose base ability your character has learned.

You might know a Sphere because of your Background, the sect trial, training, a manual, a teacher, an inheritance, a feature, or another printed rule. Once you know a Sphere, you can use its base ability and you can learn talents from that Sphere.

If two sources grant the same Sphere, you know that Sphere once. You do not gain an extra Sphere or extra talent unless a rule says you do.

Dormant and preparatory Background Spheres are not full known Spheres until a rule activates them.

## Talents

A **talent** is a specific option inside a Sphere.

A talent might grant a passive benefit, modify another technique, unlock an active technique, improve a Sphere’s base ability, or add a special rule. The talent entry controls what it does.

Unless a rule says otherwise, you can only choose talents from Spheres you know.

You cannot use a talent unless you meet its requirements. Requirements can include a Sphere, Realm, CL, Path, resource, earlier talent, manual, teacher, inheritance, or other condition named by the talent.

If a talent has a lower-Realm part and a higher-Realm part, only the part you qualify for works.

## How You Gain Spheres and Talents

Tianxia characters can gain Spheres and talents from several sources. Track where each Sphere and talent came from, because some are free and some count against your trained choices for the level.

| Source | What You Gain | Counts Against Trained Choices? |
|---|---|---:|
| Background | 1 Background Sphere and 1 Background talent at CL 1 | No |
| Sect Trial | 1 sect-trial Dao Sphere and 1 talent from that Sphere at CL 1 | No |
| Level Talent | 1 free talent each CL, chosen from a Sphere you already know | No |
| Training | Up to 3 trained Spheres or talents each CL | Yes |
| New-Sphere Bonus | 1 bonus talent when you learn a new Sphere | No |

These categories are explained below.

## Background Sphere and Talent

At 1st Cultivation Level, your Background gives you a **Background Sphere** and one talent from that Sphere, if the Background grants an active Sphere.

This represents the training, instinct, family tradition, profession, hardship, or strange experience that shaped you before formal cultivation.

Your Background Sphere and Background talent are free. They do not count against your level talent, your trained choices, or any other talent opportunity.

If your Background Sphere is dormant or preparatory, follow the Background’s rules for when it becomes active.

## Sect-Trial Dao Sphere

The sect trial is the one normal exception to the rule that new Spheres require training.

At the end of level 0 play, the sect invests in each accepted disciple by giving them a powerful initiation pill. This pill floods the disciple with cultivated energy. In that moment, the disciple expresses the Dao they showed during the trial and spontaneously awakens one legal player-facing Sphere.

This Sphere is the character’s **sect-trial Dao Sphere**.

When you gain your sect-trial Dao Sphere, you gain both of the following:

- the Sphere’s base ability;
- one talent from that Sphere.

The talent gained this way counts as your CL 1 level talent. You do not also gain a second level talent at CL 1 unless another rule says you do.

This is the only normal time a character gains a new Sphere without training. Later Spheres must be learned through training, a feature, a manual, an inheritance, or another printed rule.

## Level Talent

Each time you gain a Cultivation Level, you gain one free talent.

This is your **level talent**. Choose it from a Sphere you already know.

You do not make a check to gain your level talent. It represents the natural progress you make as your cultivation deepens.

Your level talent does not count against the number of Spheres or talents you can train during that level.

At CL 1, the talent from your sect-trial Dao Sphere counts as your level talent.

## Training Choices

At each Cultivation Level, you can train up to three additional choices.

Each trained choice can be used to do one of the following:

- learn one new Sphere;
- learn one talent from a Sphere you already know.

Training choices are not automatic. Training takes time, and you must succeed on a training check.

Training is one of the main ways ambitious cultivators pull ahead of their peers. A disciple with enough time, resources, and determination can learn far more than the minimum gained from level advancement.

## Learning a New Sphere

To learn a new Sphere through training, you need a source that can reveal or teach that Sphere. This might be a teacher, sect lesson, scripture, jade slip, manual, battlefield insight, inherited memory, monster core, ancient mural, spirit site, or other suitable source.

Learning a new Sphere uses one of your three trained choices for the level.

When you successfully learn a new Sphere, you gain both of the following:

- the Sphere’s base ability;
- one bonus talent from that Sphere.

This bonus talent represents the first complete technique you master as part of opening the Sphere. It does not count against your three trained choices for the level.

You only gain this bonus talent when you learn a Sphere you did not already know. If another source grants a duplicate Sphere, you do not gain another bonus talent unless that source says you do.

## Learning Talents from a Known Sphere

If you already know a Sphere, you can train talents from that Sphere.

You do not normally need an outside teacher, manual, or scripture to train a talent from a Sphere you already know. The Sphere is already part of your cultivation. Training a talent can represent meditation, repeated practice, combat refinement, body tempering, spiritual listening, Dao comprehension, or another form of personal cultivation.

An outside source can still help. A good manual, teacher, library, senior disciple, spirit site, or relevant experience may make training easier if the rule or GM says it does.

Some talents are exceptions. Secret techniques, inherited techniques, lineage techniques, forbidden teachings, or talents with special requirements may require a specific source before you can train them.

A talent learned this way counts as one of your three trained choices for the level.

## Training Time

Each trained choice takes time.

When you begin training a Sphere or talent, roll the training time:

**1d6 + your Proficiency Bonus − your Intelligence or Wisdom modifier, minimum 2 days.**

Choose Intelligence or Wisdom when the training begins. Use the ability that best fits the training.

- Use Intelligence for technical study, scripture analysis, formations, talismans, alchemy, exact movement theory, and precise technique work.
- Use Wisdom for meditation, instinctive refinement, body feel, spiritual perception, survival training, and Dao comprehension.

The GM may allow another ability if the training clearly calls for it.

The minimum training time is always 2 days unless a specific rule says otherwise.

## Training Checks

At the end of training, make a Cultivation Check.

### Talent Training DC

If you are training a talent from a Sphere you already know, the default DC is:

**DC 10 + the number of talents you already know from that Sphere.**

The more deeply you have developed a Sphere, the harder it becomes to add another talent from that Sphere.

### New Sphere Training DC

If you are learning a new Sphere, the default DC is:

**DC 10 + 1d4 + the number of different Spheres you know.**

Roll the 1d4 when the training check is made.

The more Spheres you already know, the harder it becomes to open another one. Each Sphere has its own shape, rhythm, and Dao-expression. Learning too broadly without enough time and stability is difficult.

## Failed Training

If you fail a training check, you do not learn the Sphere or talent.

You may try again after spending half the original training time.

A failed attempt still counts as time spent. It does not count against your three trained choices for the level unless you eventually succeed and learn the Sphere or talent.

## Training Aids

A training aid is something that makes training easier.

Common training aids include:

- a clear manual;
- a skilled teacher;
- a sect library;
- a senior disciple’s instruction;
- a compatible Method;
- a Foundation that supports the training;
- a spirit site or qi-rich environment;
- a previous Recorded Art tied to the same Sphere;
- direct experience fighting or observing the technique.

If a training aid gives a printed bonus, use that bonus.

If no printed bonus is given, the GM may decide that a strong training aid grants advantage on the training check, lowers the DC, reduces the training time, or satisfies a source requirement for a Secret, inherited, or special talent.

## Recorded Arts

A **Recorded Art** is a fixed named technique learned from a manual, jade slip, journal, inscription, inheritance, or similar source. Recorded Arts are not Sphere talents. They are recorded separately and follow the rules in Chapter 15: Manuals, Lineages, and Recorded Arts.

Learning a Recorded Art does not automatically teach you the whole Sphere unless the source says it does. However, once you have studied the source, it may count as a suitable training aid when you later train that Sphere or one of its talents.

## Manuals and Recorded Arts as Training Aids

A manual teaches one or more specific techniques. If a manual teaches a technique tied to a Sphere, that manual can help you train that Sphere or related talents.

Learning a Recorded Art does not automatically teach you the whole Sphere unless the manual says it does. However, once you have studied the manual, it may count as a suitable source when you later train that Sphere or one of its talents.

For example, if you learn a Sword technique from a manual, that manual might help you later learn the Sword Sphere or train a Sword talent.

## Active Sphere Techniques

An **active Sphere technique** is a Sphere use that spends a resource, uses a Sphere action, creates a supernatural effect, targets a creature or area, creates a duration, or otherwise relies on the Sphere’s full rules.

Every active Sphere technique needs a printed mechanical shape. At minimum, the table should be able to identify:

- action or timing;
- cost, if any;
- range or reach;
- target or area;
- duration, if any;
- effect;
- save, attack roll, check, or DC, if any;
- what happens on success or failure.

If those parts are missing, the effect is not ready for play until the relevant Sphere entry, talent, manual, item, or other printed rule supplies them.

## Path and Sphere Interaction

Path determines how the character cultivates. Sphere determines what the character can express.

A Body Refiner, Qi Cultivator, and Spirit Awakener may use the same Sphere differently when printed rules say they do. The Path can affect resource use, restrictions, action style, durability, recovery, and special permissions.

If a Path rule and a Sphere rule both apply, use the more specific printed rule. If a talent or technique is more specific than the general Sphere rule, use the talent or technique.

## Realm and Talent Requirements

Many Sphere options require a specific Realm, CL, Path, resource, talent chain, manual, teacher, inheritance, or other condition.

A character cannot use higher-Realm talents early unless a rule grants access. Flavor, training history, bloodline claims, or sect approval do not bypass requirements by themselves.

If a requirement is not met, the character cannot use that talent or technique yet.

## Manuals, Methods, and Foundations

Manuals, Methods, and Foundations can interact with Spheres, but they are separate systems.

- A Recorded Art does not grant its source Sphere unless it says it does.
- A Method does not grant extra Spheres unless it says it does.
- A Foundation does not grant extra Spheres unless it says it does.
- A Sphere does not grant a Method, Foundation, or Recorded Art unless it says it does.

Keep these systems separate unless a rule links them.

## Secret and Forbidden Spheres

Secret and Forbidden Spheres are not part of normal starting Sphere access.

A character does not gain a Secret or Forbidden Sphere from level 0, the sect trial, Background, Path, or normal Sphere progression unless a rule grants it.

Secret Spheres are restricted knowledge. Forbidden Spheres carry special danger, corruption, stigma, or other consequences defined by their own rules.

## Variant Expressions

A Sphere can have different expressions. A Sword Sphere character might use a jian, dao, saber, spiritual blade, or another legal expression if the rules allow it.

Variant expression changes description, not mechanics. It does not bypass requirements, costs, actions, damage, targeting, Realm limits, Path restrictions, or limits printed in a Sphere entry.

## Access and Opportunity

The rules allow a cultivator to learn several Spheres and talents at the same Cultivation Level, but the world does not hand them out freely.

To train, you need time, safety, resources, and access.

In a sect, this might mean earning sect tokens, completing missions, gaining library access, impressing a teacher, winning a competition, or protecting your resources from rivals. Outside a sect, it might mean finding a hidden teacher, recovering a ruined scripture, bargaining with a spirit, or surviving in a dangerous region long enough to study.

Because of this, the strongest cultivators are not only the ones with the best talent. They are the ones who turn limited opportunities into real progress.

## Example: A Hardworking 1st-Level Disciple

A new disciple completes the level 0 sect trial.

From their Background, they gain one Background Sphere and one talent from that Sphere. These are free and do not count against their trained choices.

At the end of the trial, the sect gives them an initiation pill. The pill floods their body, qi, or spirit with cultivated energy. In a flash of inspiration, they express the Dao they showed during the trial and awaken their sect-trial Dao Sphere. They gain that Sphere’s base ability and one talent from that Sphere.

That talent counts as their CL 1 level talent.

During CL 1, they may also attempt up to three trained choices. If they use one trained choice to learn a new Sphere and succeed, they gain that Sphere’s base ability and one bonus talent from that Sphere. They still have two trained choices left for CL 1.

If they have enough time, access, and success on their training checks, they could learn several new techniques before reaching CL 2. If they are short on time, fail their checks, lose access to the library, get sent on missions, or have their resources stolen by rivals, they may learn much less.

This is normal. Cultivation rewards ambition, but ambition always costs something.

## Quick Checklist

When recording Sphere and talent access, check:

- which Spheres are known;
- which Sphere came from the Background;
- which Sphere came from the sect trial;
- which talent is the CL 1 sect-trial talent;
- which talents are level talents;
- which Spheres or talents were trained this CL;
- whether the character has used all three trained choices for the CL;
- whether a new Sphere granted its one bonus talent;
- whether each talent’s requirements are met;
- whether each active technique has action, cost, target, duration, and effect text;
- whether any Secret or Forbidden Sphere requires special access;
- whether any manual, Method, or Foundation is being incorrectly counted as a Sphere.

## Glossary

**Sphere.** A rules package for a family of cultivation expressions, techniques, and talents.

**Known Sphere.** A Sphere whose base ability your character has learned.

**Background Sphere.** A Sphere granted by a Background before the sect trial. It may be active, dormant, or preparatory.

**Sect-Trial Dao Sphere.** The first full cultivation Sphere awakened at the end of the sect trial. It counts as a known Sphere at CL 1.

**Talent.** A specific option inside a Sphere.

**Level Talent.** The free talent gained at each CL. At CL 1, the sect-trial talent counts as the level talent.

**Training Choice.** One of the three additional Spheres or talents a character can train during a CL.

**New-Sphere Bonus Talent.** The free talent gained when a character successfully learns a new Sphere.

**Training Aid.** A source of help such as a teacher, manual, library, Method, Foundation, or special environment.

**Active Sphere Technique.** A Sphere use that relies on the Sphere’s full rules, such as spending a resource, using a Sphere action, targeting a creature or area, or creating a supernatural effect.

**Requirement.** Something that must be true before a talent, technique, or Sphere option can be used.

**Variant Expression.** A legal descriptive form of a Sphere that does not change mechanics unless a rule says it does.

---

# 10. Advancement and Realms Overview

Advancement is how a Tianxia character moves from one Cultivation Level to the next. Realms are the larger cultivation thresholds that divide those levels.

This chapter is a quick player-facing overview. It gives the rules needed for character creation, early advancement, Realm requirements, and the basic advancement checklist. It does not replace the full Breakthrough, Foundation, Method, Sphere, or Path progression chapters.

## Cultivation Level

**Cultivation Level**, or **CL**, is the character’s level as a cultivator.

A character begins at level 0 before the sect trial. After the sect trial, the character normally becomes **CL 1**.

CL controls:

- Proficiency Bonus;
- Path feature progression;
- Hit Dice and hit points;
- cultivation resource scaling;
- Sphere and talent access;
- Realm threshold timing;
- breakthrough requirements.

Unless a printed rule says otherwise, use the normal Tianxia advancement rules for increasing CL.

## Realms

A **Realm** is a major stage of cultivation. Realm thresholds are larger than ordinary level increases.

The current player-facing Realm bands are:

| CL Range | Realm Band | Notes |
|---:|---|---|
| Level 0 | Mortal before cultivation | No Path, Foundation, Method, or sect-trial Dao Sphere |
| CL 1–4 | Early cultivation | Path, first Dao Sphere, and basic Sphere use are active |
| CL 5–9 | Foundation stage | First major Realm threshold; Foundation rules become central |
| CL 10–14 | Core Formation stage | Higher cultivation stability, deeper techniques, and stronger Sphere access |
| CL 15–19 | Nascent stage | Advanced cultivation; many high-Realm options begin here |
| CL 20 | Peak mortal-book progression | Final mortal-book threshold before later immortal expansion rules |

Some future or advanced rules may use more specific in-world Realm names. If a later chapter gives a more exact Realm name, use that chapter’s term.

## Ordinary Advancement

Most CL increases are ordinary advancements inside the same Realm band.

For an ordinary advancement, the character must have enough **Attainment Points (AP)** for the next CL and meet any other printed advancement requirement. Then the character attempts a breakthrough check.

The same-Realm breakthrough DC is:

**DC = 10 + the new CL**

Example: advancing from CL 2 to CL 3 is DC 13.

On success, the character gains the new CL and applies the appropriate Path, Sphere, talent, hit point, resource, and progression updates.

On failure, the character does not gain the new CL. Set the character’s AP progress for the current CL to the halfway point between the current CL and the CL they were trying to reach. The character can retry after regaining the lost AP.

## Realm Breakthroughs

A **Realm breakthrough** happens at the major thresholds:

- CL 5;
- CL 10;
- CL 15;
- CL 20.

The Realm breakthrough DC is:

**DC = 10 + twice the new CL**

| New CL | Breakthrough Type | DC |
|---:|---|---:|
| 5 | Realm breakthrough | 20 |
| 10 | Realm breakthrough | 30 |
| 15 | Realm breakthrough | 40 |
| 20 | Realm breakthrough | 50 |

On success, the character enters the new Realm band and applies the normal CL update plus any Realm-specific rules granted by printed features.

On failure, use the same failure rule: the character does not gain the new CL, their AP progress for the current CL drops to the halfway point, and they can retry after regaining the lost AP. Other failure consequences, such as injuries, deviations, omens, or failure-born insights, are handled by the full Breakthrough and Failure chapters.

## Suppressing Your Realm

A cultivator can voluntarily suppress their Realm.

When you suppress your Realm, choose a lower Cultivation Level. This is your **suppressed CL**. Realm suppression is common in sect sparring, teaching matches, formal challenges, tests, and duels where a stronger cultivator agrees not to use their full cultivation against a weaker opponent.

Suppression does not make the match truly fair. A stronger cultivator is still stronger in many ways. Their body, reserves, instincts, and cultivation depth are already part of them. Suppression only limits the level of power they are willing or able to express.

### Effects of Suppression

While your Realm is suppressed:

- use the Proficiency Bonus of your suppressed CL;
- you cannot use talents, insights, Path features, Recorded Arts, Method features, Foundation features, item powers, or other abilities that require a higher CL or higher Realm than your suppressed CL;
- if an ability has a stronger effect at a higher Realm, use only the version available at your suppressed CL;
- you still know your higher-Realm techniques, but you cannot express them through your suppressed cultivation.

Realm suppression does **not** reduce your hit points, Hit Dice, maximum CP, Stamina, Resonance, ability scores, passive Foundation benefits, body quality, cultivation resources, or other traits that are already built into your character.

For example, a Core Formation cultivator who suppresses themselves to Foundation stage uses the Proficiency Bonus appropriate to the chosen Foundation CL and cannot use Core Formation talents, Core Formation insights, or any feature that requires Core Formation. They still have the body, reserves, and foundation of a Core Formation cultivator, so the challenge is not truly even. The weaker cultivator simply has a chance to fight, learn, survive, or prove something.

### Ending Suppression

You can end voluntary Realm suppression on your turn, no action required, unless a duel rule, oath, formation, item, poison, seal, or other effect says otherwise.

Ending suppression may break the terms of a spar, tournament, sect challenge, or oath. The rules allow it, but the world may judge it.

## What You Gain Each CL

When you gain a Cultivation Level, update your character before play continues.

A new CL can improve your Path, hit points, resources, talents, and access to higher-Realm options. Some benefits happen immediately. Others become available during that CL if you spend time training.

### 1. Update Your Level, Proficiency Bonus, and Hit Points

First, record your new CL.

If your Proficiency Bonus increases at the new CL, update it everywhere it applies.

Then update your Hit Dice and hit points according to your Path.

### 2. Update Your Path

Your Path is your main cultivation chassis.

When you gain a CL, check your Path table and apply anything gained at that level, such as:

- Path features;
- resource maximum increases;
- resource recovery changes;
- defensive features;
- attack or technique improvements;
- Realm-specific upgrades.

Only apply the features your Path actually grants. A new CL does not automatically grant a Foundation, Method, Recorded Art, Secret Sphere, Forbidden Sphere, or special inheritance.

### 3. Gain Your Level Talent

Each time you gain a CL, you gain one free talent.

This is your **level talent**.

Choose your level talent from a Sphere you already know. You do not make a training check for this talent, and it does not count against your trained choices for the level.

At CL 1, this works differently. The talent you gain from your sect-trial Dao Sphere counts as your CL 1 level talent. You do not gain a second CL 1 level talent unless another rule says you do.

### 4. Train During the Level

Each CL also gives you room to train.

During each CL, you can complete up to three trained choices. Each trained choice can be used to do one of the following:

- learn a new Sphere;
- learn one talent from a Sphere you already know.

Training is not automatic. You need time, practice, and a successful training check.

The detailed training rules are in Chapter 09. For quick reference:

- Training time is **1d6 + Proficiency Bonus − your Intelligence or Wisdom modifier**, minimum 2 days.
- Training a talent from a Sphere you already know is usually **DC 10 + the number of talents you already know from that Sphere**.
- Training a new Sphere is usually **DC 10 + 1d4 + the number of different Spheres you know**.

If you train a talent from a Sphere you already know, you usually do not need an outside teacher or manual. You are deepening your connection to that Sphere’s Dao-expression. A teacher, manual, special site, or other source can still help, and some Secret, inherited, lineage, or forbidden talents may require a specific source.

If you train a new Sphere, you need a suitable source of instruction or inspiration. This might be a manual, teacher, jade slip, sect lesson, battlefield demonstration, inheritance, spirit guide, spirit site, or similar source.

When you successfully learn a new Sphere, you gain that Sphere’s base ability and one bonus talent from that Sphere. This bonus talent does not count against your three trained choices.

### 5. Check Requirements and Higher-Realm Options

Some talents, Recorded Arts, Foundations, Methods, items, and special rewards require a certain CL or Realm.

When you gain a CL, check whether you now qualify for any options you were not ready to learn before.

For example, if you reach Foundation stage and then learn a new Sphere, your bonus talent from that Sphere might be a Foundation-stage talent if you meet its requirements. You might also finish training a higher-Realm talent from a manual you have been studying, as long as you spend the training time and succeed on the required check.

You cannot use an option until you meet all of its printed requirements.

### 6. Record the Breakthrough

Finally, record how you reached the new CL.

Note whether the advancement was an ordinary breakthrough or a Realm breakthrough. If any preparation, Enlightenment die, injury, deviation, burden, scar, omen, or failure-born insight affected the breakthrough, record it with the character.

These records matter because some later options may refer to previous breakthroughs, failures, injuries, insights, or cultivation events.

## Requirements and Higher-Realm Options

Many Sphere talents and techniques require a specific CL, Realm, Path, resource, earlier talent, or source of instruction.

A character cannot use an option until every printed requirement is met.

If a talent says it requires Foundation stage, Core Formation stage, Nascent stage, or another Realm, the character must be in that Realm band or have a printed exception.

If a talent has a lower-Realm passive part and a higher-Realm active part, only the part you qualify for functions.

## Breakthrough Preparation

Characters can prepare for breakthroughs through training, meditation, rare resources, tutelage, injuries, omens, or other story events.

Preparation only grants a mechanical benefit when a printed rule says it does. Possible benefits can include flat bonuses, Enlightenment dice, rerolls, or other breakthrough-specific effects.

Preparation should be recorded clearly before the breakthrough check. Do not treat vague roleplay, general ambition, or ordinary training as an automatic mechanical bonus.

## Failure Is Not Nothing

A failed breakthrough does not erase the character.

Failure can create consequences and future routes, such as:

- lost AP progress;
- delayed advancement;
- hidden injuries;
- deviations;
- scars;
- warnings;
- conditional insights;
- future breakthrough hooks.

The required baseline failure rule is the AP setback: the character drops to the halfway point of the current CL’s AP progress and must regain the lost AP before retrying. Additional consequences come from the full Breakthrough, Injury, Deviation, Foundation, or campaign rules.

Some routes to greater power are **failure-shaped**. A printed feature, talent, Foundation challenge, Method correction, Failure Enlightenment, Conditional Bonus Insight, Secret technique, or other advancement option may require a specific prior failure, scar, deviation, hidden injury, or unresolved lesson as a prerequisite. This is not a punishment; it means the character has reached a requirement that success alone would not reveal.

Do not create failure-shaped power ad hoc from this overview. The printed rule that grants it should define the required failure, the benefit, any drawback, how it is recorded, and when it becomes available.

## Realm Terms and Book Terms

Some Tianxia chapters use in-world cultivation language. Others use book-facing rules language.

When reading rules, treat these as distinct:

- **CL** is the exact character level.
- **Realm** is the larger cultivation band.
- **Path** is the character’s cultivation chassis.
- **Sphere** is a technique/talent rules package.
- **Foundation** is a separate cultivation architecture.
- **Method** is a separate cultivation practice or scripture.
- **Breakthrough** is the advancement check or transition.

Do not merge these systems unless a printed rule tells you to.

## Quick Checklist

When advancing a character, confirm:

- current CL;
- new CL;
- whether this is an ordinary advancement or Realm breakthrough;
- breakthrough DC;
- required AP or printed advancement requirement;
- any recorded breakthrough preparation;
- success or failure result;
- Path updates;
- hit point and Hit Dice updates;
- resource updates;
- level talent;
- trained choices available during the CL;
- new Sphere bonus talents, if any;
- higher-Realm options newly available;
- any failure consequences.

## Glossary

**CL.** Cultivation Level. The character’s cultivator level after the sect trial.

**Realm.** A major cultivation band that contains several CLs.

**Ordinary Advancement.** A CL increase inside the same Realm band.

**Realm Breakthrough.** A CL increase at CL 5, CL 10, CL 15, or CL 20.

**Breakthrough Check.** The check used to complete an ordinary advancement or Realm breakthrough.

**AP.** Attainment Points. Advancement progress used to determine when a character can attempt the breakthrough to the next CL.

**Realm Requirement.** A requirement that prevents a talent, technique, or feature from being used until the character reaches the required Realm.

**Failure-Shaped Option.** A printed option that can be unlocked only after a specified failure, scar, hidden injury, deviation, unresolved lesson, or similar consequence.

**Failure Enlightenment.** Insight gained because a breakthrough, trial, or cultivation attempt failed in a meaningful way.

**Conditional Bonus Insight.** A special insight or option that becomes available only after its printed condition is met, often because a failure revealed the correct route.

**Enlightenment Die.** A die granted by a printed rule and used to improve a breakthrough or related cultivation check.

---

# 11. Foundations Overview

A Foundation is the character’s cultivated base: the structure, vessel, pattern, burden, or inner architecture that lets future power become stable.

A Foundation is not a Path, Sphere, Background, Origin Insight, Method, manual, Recorded Art, item, or bloodline. It is a separate cultivation system that can shape how the character survives, advances, bears power, repairs damage, and expresses later techniques.

This chapter is a short player-facing overview. It does not replace the full Foundation rules or Foundation catalog.

## What a Foundation Is

A Foundation represents the character’s deeper cultivation architecture.

A Foundation can define:

- how the body, qi, spirit, meridians, soul, or inner world is stabilized;
- what kind of power the character can bear safely;
- what passive benefits the character gains;
- what burdens, flaws, scars, or limits the character carries;
- how the character responds to injury, deviation, pressure, or failed breakthroughs;
- what later advancement options become easier, harder, or possible.

A Foundation should be mechanically real. It should not be only a title, omen, aesthetic, or permission to improvise power.

## When Foundations Enter Play

A level 0 character has no Foundation.

A CL 1 character does not automatically gain a Foundation.

Foundation rules normally become central around the first major Realm threshold, especially the CL 5 Realm breakthrough. A character gains, awakens, repairs, or changes a Foundation only when a printed rule says so.

The full Foundation chapter controls the exact timing, requirements, and procedure.

## Foundation and Path

Path and Foundation are different systems.

- **Path** is the character’s cultivation chassis.
- **Foundation** is the character’s deeper cultivated base.

A Body Refiner, Qi Cultivator, or Spirit Awakener can have a Foundation, but the Foundation does not replace the Path. The Path still controls Hit Die, key ability, resource, recovery, and Path features.

A Foundation can modify how a Path works only when the Foundation or Path rule says it does.

## Foundation and Spheres

A Foundation does not automatically grant Spheres, talents, or active Sphere techniques.

If a Foundation improves a Sphere, opens a Sphere, modifies a talent, or changes a technique, the Foundation entry must say so. It should also say what changes mechanically.

A Foundation can make a character better at bearing certain kinds of power without granting every related Sphere.

## Foundation and Methods

A Method is a cultivation practice, scripture, discipline, or operating procedure. A Foundation is the base that the Method works on.

A Method does not grant a Foundation unless it says it does. A Foundation does not grant a Method unless it says it does.

Some Methods may repair, refine, pressure, complete, or transform a Foundation. Use the printed Method and Foundation rules for that interaction.

## Foundation Benefits

Foundation benefits can be passive, active, conditional, or advancement-facing.

A Foundation entry should state what it grants, such as:

- hit point, defense, save, resistance, or durability changes;
- resource, recovery, or expenditure changes;
- Sphere, talent, or technique modifications;
- movement, perception, cultivation, or survival benefits;
- breakthrough, injury, deviation, or recovery benefits;
- new conditions for later advancement.

If a benefit uses an action, reaction, cost, save, check, DC, range, target, duration, trigger, or limit, the Foundation entry should print those details.

## Foundation Burdens and Flaws

A Foundation can include burdens, scars, pressure points, unstable routes, taboos, or hidden injuries.

These are not only story labels. If a burden matters mechanically, the entry should say when it applies and what it does.

A burden can affect:

- recovery;
- breakthrough checks;
- resource use;
- Sphere expression;
- social recognition;
- resistance to pressure;
- vulnerability to specific injuries or deviations;
- future Foundation repair or transformation.

Burdens should create meaningful play, not vague punishment.

## Failure and Foundation Growth

Some Foundation routes are shaped by failure.

A failed breakthrough, hidden injury, deviation, scar, burden, or unresolved lesson can become a prerequisite for a later Foundation repair, transformation, insight, or stronger route. This is a failure-born option.

Failure-born Foundation power must come from a printed rule. The rule should define:

- the required failure or scar;
- how it is recorded;
- what option it unlocks;
- what benefit it grants;
- what drawback remains, if any;
- when the character can use it.

Failure does not automatically improve a Foundation. It can open a route only when a rule says it does.

## Foundation Repair and Transformation

A Foundation can be damaged, repaired, refined, sealed, redirected, awakened, or transformed only through printed rules.

Repair or transformation should specify:

- requirement;
- time;
- cost;
- check or DC, if any;
- risk;
- success result;
- failure result;
- whether the old Foundation remains, changes, or is replaced.

A Foundation change should be recorded clearly on the character sheet.

## What Foundations Do Not Automatically Grant

A Foundation does not automatically grant:

- a Path;
- a Method;
- a Recorded Art;
- a Sphere;
- a talent;
- a Secret or Forbidden sphere;
- a breakthrough success;
- immunity to injury, deviation, or failure;
- permission to ignore prerequisites.

Only printed Foundation rules grant those benefits.

## Reading a Foundation Entry

When using a Foundation, check:

- Foundation name;
- type or family, if listed;
- prerequisites;
- when it is gained;
- passive benefits;
- active features;
- burdens or flaws;
- sphere or Path interactions;
- breakthrough interactions;
- injury, deviation, or repair rules;
- advancement hooks;
- sealing, redirection, awakening, or transformation rules.

If an entry lacks the mechanical details needed to run a feature, that feature is not ready for play until repaired by a printed rule.

## Quick Checklist

Before adding a Foundation to a character, confirm:

- the character is allowed to gain it;
- the timing and requirement are met;
- the Foundation does not replace the Path;
- any Sphere or talent interaction is printed;
- all active features have action, cost, target, duration, and effect text;
- burdens and flaws have clear triggers and results;
- any failure-born route has a printed prerequisite;
- repair or transformation rules are recorded if relevant.

## Glossary

**Foundation.** The character’s deeper cultivation base or architecture.

**Foundation Benefit.** A passive, active, conditional, or advancement-facing rule granted by a Foundation.

**Foundation Burden.** A flaw, scar, instability, injury, taboo, or pressure point attached to a Foundation.

**Foundation Repair.** A printed process that restores or stabilizes a damaged or incomplete Foundation.

**Foundation Transformation.** A printed process that changes, replaces, or evolves a Foundation.

**Failure-Born Option.** An option that requires a specified prior failure, scar, hidden injury, deviation, burden, or unresolved lesson.

**Method.** A cultivation practice, scripture, or discipline that is separate from Foundation unless a rule links them.

---

# 12. Methods Overview

A Method is a cultivation practice, scripture, discipline, formula, breathing cycle, body-tempering routine, meditation, or operating procedure that teaches a character how to cultivate.

A Method is not a Path, sphere, Foundation, Background, Origin Insight, Recorded Art, item, or bloodline. It is a separate system that can guide advancement, stabilize power, unlock specific procedures, repair flaws, or change how a character cultivates.

This chapter is a short player-facing overview. It does not replace the full Method chapter or any individual Method entry.

## What a Method Is

A Method tells a character how to practice.

A Method can define:

- what kind of cultivation the character is trained to perform;
- what requirements must be met to learn it;
- what daily, downtime, or breakthrough procedures it uses;
- what risks, taboos, flaws, or burdens it creates;
- what benefits it grants;
- what spheres, Paths, or Foundations it interacts with;
- how it can be repaired, corrected, advanced, replaced, or abandoned.

A Method should provide usable rules. It should not be only a poem, doctrine, aesthetic, or permission to improvise power.

## When Methods Enter Play

A level 0 character has no Method unless a printed rule explicitly grants one.

A CL 1 character does not automatically gain a Method from the sect trial. A sect, teacher, scripture, inheritance, manual, Foundation, Path feature, or adventure reward may grant access to a Method if the printed rule says so.

Methods can enter play at different times. Some are early training practices. Some are tied to Foundation development. Some are advanced scriptures or correction procedures. The full Method rules control timing and eligibility.

## Method and Path

Path and Method are different systems.

- **Path** is the character’s cultivation chassis.
- **Method** is a learned way to cultivate.

A Method can support one Path, several Paths, or a specific build, but it does not change the character’s Path unless a printed rule says it does.

A Body Refiner Method might train marrow, breath, organs, scars, stances, or flesh routes. A Qi Cultivation Method might train circulation, elemental theory, talismanic formulas, formation logic, or projection discipline. A Spirit Awakening Method might train soul pressure, stillness, perception, spirit contact, or resonance control.

## Method and Foundation

A Method can shape, repair, pressure, refine, or complete a Foundation.

A Method does not grant a Foundation unless it says it does. A Foundation does not grant a Method unless it says it does.

If a Method changes a Foundation, it should define:

- what Foundation or Foundation type it affects;
- what requirement must be met;
- what procedure is used;
- what check or DC applies, if any;
- what happens on success;
- what happens on failure;
- whether the Foundation is repaired, refined, transformed, or replaced.

## Method and Spheres

A Method does not automatically grant Spheres, talents, or active Sphere techniques.

If a Method grants a Sphere, improves a Sphere, modifies a talent, changes a technique, or opens access to a special expression, the Method entry must say so directly.

A Method can make certain Sphere expressions safer, cheaper, stronger, or easier to learn, but only through printed mechanics.

## Method Benefits

A Method benefit can affect training, recovery, breakthrough preparation, Foundation repair, Sphere use, resource use, resistance to deviation, or advancement.

A Method entry should state what it grants, such as:

- a bonus to a specific cultivation check;
- a specific breakthrough preparation benefit;
- a resource recovery change;
- a Foundation repair or refinement procedure;
- a sphere or talent modification;
- a reduced risk, new risk, or changed failure result;
- a downtime procedure;
- a restriction, taboo, or required behavior.

If a benefit uses an action, time cost, resource cost, DC, check, trigger, duration, target, limit, or failure result, the Method entry should print those details.

## Method Flaws, Taboos, and Corrections

Some Methods are incomplete, dangerous, harsh, corrupting, unstable, or poorly matched to the character.

A Method flaw can be mechanical. It can affect:

- breakthrough checks;
- resource recovery;
- injury or deviation risk;
- Sphere expression;
- Foundation stability;
- social recognition;
- cultivation time;
- required materials or conditions;
- future correction procedures.

A taboo or flaw should have a clear trigger and result if it matters mechanically.

A Method correction is a printed procedure that repairs, stabilizes, replaces, or improves a Method. It should state the requirement, time, cost, check or DC, success result, and failure result.

## Failure-Born Methods

Some Methods can only be understood after failure.

A failed breakthrough, deviation, hidden injury, scar, burden, damaged Foundation, rejected scripture, or unresolved lesson can become a prerequisite for a Method correction, stronger route, hidden chapter, or successor scripture.

Failure-born Method power must come from a printed rule. The rule should define:

- the required failure or scar;
- how it is recorded;
- what Method option it unlocks;
- what benefit it grants;
- what flaw or cost remains;
- when the character can use it.

Failure does not automatically grant a Method or improve a Method.

## Learning, Correcting, and Changing Methods

A Method can be learned, corrected, changed, sealed, or abandoned only when a printed rule allows it.

A Method change should state:

- who or what teaches it;
- what prerequisites apply;
- how long it takes;
- what cost or risk applies;
- whether the old Method remains, is overwritten, or becomes flawed;
- what happens if the change fails.

A character should not stack Methods freely unless the full Method rules allow it. If multiple Methods apply, the printed rules should state whether they combine, conflict, replace each other, or create strain.

## What Methods Do Not Automatically Grant

A Method does not automatically grant:

- a Path;
- a Foundation;
- a Sphere;
- a talent;
- a Recorded Art;
- a Secret or Forbidden sphere;
- a breakthrough success;
- immunity to injury, deviation, corruption, or failure;
- permission to ignore prerequisites.

Only printed Method rules grant those benefits.

## Reading a Method Entry

When using a Method, check:

- Method name;
- type or tradition, if listed;
- prerequisites;
- when it can be learned;
- what it teaches;
- passive benefits;
- active procedures;
- costs;
- risks;
- taboos or flaws;
- Path, Sphere, or Foundation interactions;
- breakthrough interactions;
- correction, sealing, or transformation rules;
- failure results.

If an entry lacks the mechanical details needed to run a feature, that feature is not ready for play until repaired by a printed rule.

## Quick Checklist

Before adding a Method to a character, confirm:

- the character is allowed to learn it;
- the timing and prerequisites are met;
- the Method does not replace the Path;
- any Foundation, Sphere, or talent interaction is printed;
- benefits have clear rules;
- flaws and taboos have clear triggers and results;
- any failure-born route has a printed prerequisite;
- correction, sealing, or transformation rules are recorded if relevant;
- incompatible Methods are not being stacked without permission.

## Glossary

**Method.** A cultivation practice, scripture, discipline, formula, routine, meditation, or procedure used to cultivate.

**Method Benefit.** A rule granted by a Method, such as a training, recovery, breakthrough, Foundation, or sphere interaction.

**Method Flaw.** A mechanical weakness, mismatch, instability, taboo, risk, or burden attached to a Method.

**Method Correction.** A printed procedure that repairs, stabilizes, replaces, or improves a Method.

**Failure-Born Method.** A Method option that requires a specified prior failure, scar, hidden injury, deviation, damaged Foundation, or unresolved lesson.

**Taboo.** A Method restriction that creates a consequence if violated.

**Procedure.** A Method’s defined process for training, recovery, correction, breakthrough preparation, or other cultivation work.

---

# 13. Backgrounds

A Background represents the mortal life that shaped a character before cultivation: family, labor, exile, study, hunger, craft, service, strange inheritance, social position, or survival.

At level 0, a character does not yet have a Path, Foundation, Method, or sect-trial Dao Sphere. A Background gives the character practical identity before those systems come online.

## Background Package

Each Background grants:

- ability score increases;
- skill proficiencies;
- tool, language, or trade proficiencies;
- a Background Sphere and Background Talent package, or a listed compensating benefit;
- starting equipment;
- suggested Origin Insight options;
- a social hook.

## Ability Scores

Each Background lists three ability scores.

Choose one:

- Increase one listed ability score by 2.
- Increase two listed ability scores by 1 each.

Species grants a separate ability score increase according to its own rules.

## Trade Proficiencies

A trade proficiency is a Background-granted proficiency representing a local craft, labor role, ritual practice, coded social language, or practical profession that is narrower than a full skill and broader than a single tool.

When a trade proficiency applies, add your Proficiency Bonus to the check. If a normal tool proficiency or skill already covers the task, use the most specific applicable proficiency; do not add your Proficiency Bonus twice.

## Campaign Languages and Cants

Backgrounds may grant campaign languages, cants, signs, or liturgical languages such as Classical, Trade Pidgin, gang cant, military signs, ancestral liturgical language, or regional ritual language.

These count as languages unless the Background says they are a trade proficiency.

## Background Spheres and Talents

Some Backgrounds grant a **Background Sphere** and one **Background Talent**.

This represents mortal training, inherited practice, early exposure, practical discipline, strange literacy, family technique, weapon habit, craft method, or dormant spiritual sensitivity.

A Background Sphere is not the same as the Dao Sphere revealed by the sect trial. The trial shows how the character’s Dao begins to open when cultivation begins. A Background Sphere shows what mortal life already taught them.

### Free Background Benefits

If your Background grants a Background Sphere and Background Talent, both are free.

They do not count against:

- your CL 1 level talent;
- your three trained choices for CL 1;
- any bonus talent gained from learning a new Sphere.

At CL 1, most characters have both of the following:

- a Background Sphere and Background Talent from their Background;
- a sect-trial Dao Sphere and talent from the sect trial.

The talent from your sect-trial Dao Sphere counts as your CL 1 level talent. Your Background Talent does not.

### Active Background Spheres

When a Background grants an **active Background Sphere**, you gain that Sphere’s base ability and the listed Background Talent.

While you are level 0, the Sphere functions only at mortal scale. At CL 1, the Sphere becomes a known Sphere and follows the normal Sphere rules.

### Printed Background Choices

Every Background Sphere and Background Talent printed in this chapter is legal for that Background during normal character creation.

If a Background gives you a choice between several Spheres or talents, choose one of the listed options.

Some Backgrounds do not grant a full active Sphere and talent. If a Background grants a dormant Sphere, preparatory Sphere, weapon package, equipment package, or compensating benefit instead, use the rule printed in that Background.

## Background-Safe Talents

A Background-safe talent is a printed Mortal Realm or passive talent that can be learned at level 0 without granting CP use, Stamina use, Resonance use, full supernatural actions, companions, summons, area attacks, concentration effects, or high-Realm effects.

If a talent contains both safe and locked portions, the safe portions function at level 0 and the locked portions activate only when the character has the required Path, resource, Realm, or printed activation rule.

## Dormant and Preparatory Spheres

A **dormant Background Sphere** grants recognition, knowledge, signs, future access, and safe mortal-scale expression. It does not grant active Sphere techniques until it becomes active through a printed rule.

A **preparatory Background Sphere** grants literacy, etiquette, offering practice, vessel knowledge, relationship preparation, or training habits. It does not grant a companion, servant, hosted entity, summon, or active sphere action until the character gains the appropriate Path, resource, and legal expression.

A dormant or preparatory Background Sphere becomes active when the character reaches CL 1 and has a legal Path, resource, feature, teacher, method, or other printed rule that can support that sphere. Once active, it becomes a known Sphere and grants its normal base ability plus the listed talent, unless the Background says otherwise.

## Mortal-Scale Use

Mortal-scale use means passive knowledge, proficiency, recognition, ordinary tool use, mundane preparation, non-CP practice, or non-supernatural training.

Mortal-scale use does not include CP spending, Stamina spending, Resonance spending, sphere attacks, concentration effects, summons, companions, magical healing, area control, or supernatural travel unless a printed rule explicitly allows it.

## Variant Expressions

When a Background Sphere becomes active in cultivation, the player may choose a listed **Variant Expression** if the Background or Sphere provides one.

A Variant Expression explains how the same Sphere appears through the character’s culture, body, Path, Method, bloodline, tool, weapon, spirit, or personal Dao.

A Variant Expression does not bypass prerequisites, Realm requirements, costs, Path restrictions, or printed restrictions. It changes expression and compatibility, not the basic rules of the Sphere.

Custom Variant Expressions use the normal table rules for custom options. Listed Variant Expressions do not require additional approval.

## Origin Insight Options

Each Background suggests Origin Insight options. These are recommended matches, not exclusive lists. The Origin Insights chapter defines the mechanics for each Origin Insight.

## Background Summary

| Background | Ability Options | Skills | Background Sphere Options |
|---|---|---|---|
| Abandoned Orphan | Dexterity, Wisdom, Charisma | Deception and Sleight of Hand | Scoundrel, Equipment |
| Cursed Bloodline | Constitution, Wisdom, Charisma | Deception and Intimidation | Dark |
| Dream-Touched | Wisdom, Charisma, Intelligence | Insight and Perception | Dreams |
| Forest Hermit | Constitution, Wisdom, Dexterity | Nature and Survival | Harvesting and Gathering, Athletics |
| Imperial Scholar | Intelligence, Wisdom, Charisma | History and Investigation | Ink, Equipment |
| Jambudvipan Mystic | Wisdom, Intelligence, Constitution | Arcana and Medicine | Alchemy, Flowing River, Athletics |
| Merchant Clan Scion | Charisma, Intelligence, Wisdom | Persuasion and Investigation | Sect Stewardship, Equipment, Ink |
| Military Brat | Strength, Constitution, Charisma | Athletics and Intimidation | Equipment, Spear, Warleader |
| Northern Steppe Rider | Dexterity, Constitution, Charisma | Animal Handling and Intimidation | Beastmastery, Spear, Barrage, Warleader |
| Puppeteer’s Child | Dexterity, Intelligence, Charisma | Performance and Sleight of Hand | Puppetry, Equipment |
| Shinobi Apprentice | Dexterity, Wisdom, Intelligence | Acrobatics and Stealth | Scoundrel, Trap, Equipment, Poison |
| Temple Initiate | Wisdom, Intelligence, Charisma | Religion and Insight | Talismans, Protection, Radiance, Spirit Companions |
| Beast Hunter | Strength, Dexterity, Wisdom | Survival and Nature | Spear, Barrage, Trap, Beastmastery |
| Clan Heir | Charisma, Intelligence, Wisdom | Persuasion and History | Sect Stewardship, Equipment, Ink, Sword |
| Exiled Noble | Charisma, Dexterity, Wisdom | Deception and Insight | Sword, Scoundrel, Equipment, Sect Stewardship |
| Furnace Laborer | Strength, Constitution, Wisdom | Athletics and Survival | Brute, Blacksmith, Equipment, Athletics |
| Herb-Gatherer | Wisdom, Dexterity, Intelligence | Medicine and Nature | Harvesting and Gathering, Alchemy, Poison |
| Monastery Novice | Wisdom, Dexterity, Constitution | Religion and Acrobatics | Iron Fist, Flowing River, Spear |
| River Child | Dexterity, Wisdom, Constitution | Athletics and Perception | Flowing River, Athletics |
| Sect Servant | Wisdom, Dexterity, Charisma | Insight and Stealth | Equipment, Sect Stewardship, Ink |
| Spirit Medium | Wisdom, Charisma, Constitution | Insight and Religion | Spirit Companions |
| Talisman Apprentice | Intelligence, Dexterity, Wisdom | Arcana and Investigation | Talismans, Ink, Equipment |
| Wandering Healer | Wisdom, Intelligence, Charisma | Medicine and Insight | Alchemy, Life, Equipment |
| War Refugee | Constitution, Dexterity, Wisdom | Survival and Perception | Equipment, Scoundrel, Athletics |
| Workshop Apprentice | Dexterity, Intelligence, Constitution | Investigation and Sleight of Hand | Blacksmith, Equipment, Ink |
| Village Child | Constitution, Wisdom, Strength | Animal Handling and Survival | Harvesting and Gathering, Athletics, Equipment |
| Criminal Runner | Dexterity, Charisma, Wisdom | Stealth and Deception | Scoundrel, Equipment |
| Artisan’s Child | Dexterity, Intelligence, Wisdom | Investigation and Insight | Blacksmith, Equipment, Ink |
| Border Scout | Dexterity, Wisdom, Constitution | Perception and Survival | Athletics, Trap, Sniper |
| Ancestral Shrine Keeper | Wisdom, Charisma, Intelligence | Religion and History | Spirit Companions, Karma, Talismans |
| Traveling Performer | Charisma, Dexterity, Wisdom | Performance and Acrobatics | Music, Jester, Puppetry, Equipment |

---

## Abandoned Orphan

You grew up in alleys, ruins, kitchens, docks, roadside shrines, or abandoned courtyards. No one gave you a place. You survived by noticing danger early, hiding what mattered, and taking what you needed before someone stronger took it first.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Wisdom, Charisma.
- Increase two of the following ability scores by 1 each: Dexterity, Wisdom, Charisma.

### Skill Proficiencies

You gain proficiency in Deception and Sleight of Hand.

### Tool, Language, or Trade Proficiencies

You gain proficiency with thieves' tools and one language of your choice.

### Background Sphere and Talent

Choose one:

- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Grifter’s Hands** (`GRIFTER’S HANDS`) talent.
- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Hidden Tool Cache** (`HIDDEN TOOL CACHE`) talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.

### Starting Equipment

You begin with worn common clothes, a small knife, thieves' tools, a bedroll, a hidden pouch, three days of poor rations, and one keepsake from the life you lost or never had.

### Origin Insight Options

Suggested Origin Insights include:

- Street-Hardened
- Hunger Memory
- No One Saves You
- Quick Hands

### Social Hook

You know how people treat the powerless. Other outcasts may recognize you as one of their own, but officials, guards, and respectable families rarely assume the best of you.

---

## Cursed Bloodline

Something touched your family line before you were born. It may be a demon, spirit, broken oath, forbidden method, failed ritual, ancestor's crime, or lie everyone agreed to bury. The mark is faint, but it has never disappeared.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Constitution, Wisdom, Charisma.
- Increase two of the following ability scores by 1 each: Constitution, Wisdom, Charisma.

### Skill Proficiencies

You gain proficiency in Deception and Intimidation.

### Tool, Language, or Trade Proficiencies

You gain one language of your choice and proficiency in one ritual, clan, or occult practice from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

You gain the **Dark sphere** in a dormant form.

Choose one dormant Dark talent:

- **Blindfold**
- **Hide in Darkness**
- **Shadowed Mien**

At level 0, this Background Sphere does not allow active Dark Sphere techniques, supernatural darkness creation, or CP spending. Instead, it gives you strange knowledge of darkness, concealment, fear, hidden taint, and spiritual rejection. When you gain a Path and a legal way to express the sphere, this dormant sphere may become active.

When the Dark sphere becomes active, choose one legal Variant Expression that explains whether your darkness comes through body-bound night training, qi circulation, spirit-shadow, Chakra blockage, bloodline taint, curse inheritance, or another printed route.

### Starting Equipment

You begin with travel clothes, a hooded cloak, a family token, a charm meant to hide or suppress your mark, ink and paper, and a small weapon.

### Origin Insight Options

Suggested Origin Insights include:

- Unsettling Blood
- Hide the Stain
- Marked by Something
- Born Under Suspicion

### Social Hook

Some people fear what your blood might become. Others want to use it. Your lineage may be shameful, misunderstood, politically dangerous, or secretly valuable.

---

## Dream-Touched

Your dreams have always been too vivid. You wake with symbols on your tongue, warnings you cannot explain, or memories that do not feel fully yours. Sometimes the world seems less solid after you sleep.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Charisma, Intelligence.
- Increase two of the following ability scores by 1 each: Wisdom, Charisma, Intelligence.

### Skill Proficiencies

You gain proficiency in Insight and Perception.

### Tool, Language, or Trade Proficiencies

You gain one language of your choice or proficiency in dream interpretation, divination customs, or another symbolic practice from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

You gain the **Dreams sphere** in a dormant form.

Choose one dormant Dreams talent:

- **Dream Whisper**
- **Dream Ward**
- **Shared Dream**

At level 0, this Background Sphere does not allow active Dreams Sphere techniques, CP spending, or combat dream techniques. Instead, it gives you dream literacy, symbolic memory, strange warnings, and future access. When you gain a Path and a legal way to express the sphere, this dormant sphere may become active.

When the Dreams sphere becomes active, choose one legal Variant Expression that explains whether your dreams manifest through spirit resonance, qi-trance, body sleep discipline, Chakra wheel imagery, reincarnation fragments, or another printed route.

### Starting Equipment

You begin with soft travel clothes, a dream journal, ink, a sleeping mat, incense, a small charm against nightmares, and one strange object you do not remember obtaining.

### Origin Insight Options

Suggested Origin Insights include:

- Dream Listener
- Old Dream
- Omen Sense
- Half-Awake

### Social Hook

Some people treat your dreams as omens. Others call them illness, delusion, possession, or spiritual sensitivity. Either way, the sect trial may show whether your dreams are warning, invitation, or bait.

---

## Forest Hermit

You lived beneath old branches, among cliffs, caves, rivers, roots, and animal tracks. You may have been alone, raised by a guardian, trained by an eccentric recluse, or simply too far from civilization to belong to it.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Constitution, Wisdom, Dexterity.
- Increase two of the following ability scores by 1 each: Constitution, Wisdom, Dexterity.

### Skill Proficiencies

You gain proficiency in Nature and Survival.

### Tool, Language, or Trade Proficiencies

You gain proficiency with the herbalism kit.

### Background Sphere and Talent

Choose one:

- **Harvesting and Gathering Sphere.** You gain the Harvesting and Gathering sphere and the **Common Herbcraft** talent.
- **Harvesting and Gathering Sphere.** You gain the Harvesting and Gathering sphere and the **Camp Gatherer** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Strong Lungs** talent.

At level 0, Harvesting and Gathering represents field knowledge, clean gathering, camp survival, and resource sense. Athletics represents mortal conditioning, breath, climbing, swimming, and travel discipline.

### Starting Equipment

You begin with weathered travel clothes, a staff or simple weapon, an herbalism kit, a waterskin, a bedroll, five days of trail rations, and a pouch of useful herbs.

### Origin Insight Options

Suggested Origin Insights include:

- Beast Sign
- Bitter Root Wisdom
- Weather Ear
- Quiet Footsteps

### Social Hook

You know the wild better than court, market, or sect politics. Animals, hunters, hermits, and rural folk may trust you faster than city officials do.

---

## Imperial Scholar

You studied in academies, examination halls, archives, or a magistrate's household. You learned history, law, calligraphy, precedent, and the careful language of people who intend every sentence to survive scrutiny.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Intelligence, Wisdom, Charisma.
- Increase two of the following ability scores by 1 each: Intelligence, Wisdom, Charisma.

### Skill Proficiencies

You gain proficiency in History and Investigation.

### Tool, Language, or Trade Proficiencies

You gain proficiency with calligrapher's supplies. You know Classical and one additional language of your choice.

### Background Sphere and Talent

Choose one:

- **Ink Sphere.** You gain the Ink sphere and the **Wet Ink Warning** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Revealing Script** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Reinforced Robes** talent.

At level 0, Ink gained from this Background is usually expressed as calligraphy, document analysis, seals, marks, copied diagrams, and written pattern literacy. Combat or supernatural Ink expression may require later cultivation access.

When the Ink sphere awakens, choose an listed Variant Expression that explains whether your writing acts through scholar-qi, spirit names, bureaucratic law, talismanic script, memory ink, or another legal route.

### Starting Equipment

You begin with scholar's robes, calligrapher's supplies, a writing brush, ink, a seal or school token, a copybook of laws or histories, and travel papers.

### Origin Insight Options

Suggested Origin Insights include:

- Bureaucratic Eye
- Scripture Memory
- Paper Trail
- Courtly Caution

### Social Hook

Officials, clerks, tutors, and literate elites recognize your training. That respect can open doors, but it also marks you as someone who should know the consequences of breaking rules.

---

## Jambudvipan Mystic

You grew up among temples, jungles, ancient formations, river rites, wandering teachers, and old metaphysical arguments. You were taught that body, breath, mind, hunger, spirit, and cosmos are not easily separated.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Intelligence, Constitution.
- Increase two of the following ability scores by 1 each: Wisdom, Intelligence, Constitution.

### Skill Proficiencies

You gain proficiency in Arcana and Medicine.

### Tool, Language, or Trade Proficiencies

You gain proficiency with the herbalism kit and one sacred, scholarly, or regional language from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Alchemy Sphere.** You gain the Alchemy sphere and the **Calming Heart Pill** recipe.
- **Alchemy Sphere.** You gain the Alchemy sphere and the **Antidote Pill** recipe.
- **Flowing River Sphere.** You gain the Flowing River sphere and the **Reed in Storm** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Strong Lungs** talent.

At level 0, Alchemy from this Background represents basic medicinal and ritual preparation, not advanced pill mastery. Flowing River and Athletics represent breath, posture, discipline, and body-mind training.

When one of these spheres awakens into fuller cultivation, choose an listed Variant Expression that explains whether the practice unfolds through vital discipline, qi circulation, spirit attunement, Chakra imagery, body posture, or another legal route.

### Starting Equipment

You begin with travel robes, prayer beads or a meditation cord, an herbalism kit, incense, a small ritual text, and a satchel of medicinal roots.

### Origin Insight Options

Suggested Origin Insights include:

- Breath Before Thought
- Body Is a Shrine
- Formation Curiosity
- Patient Mind

### Social Hook

Your customs may be respected, exoticized, misunderstood, or distrusted depending on where the campaign begins. You may notice spiritual assumptions that local cultivators take for granted.


---

## Merchant Clan Scion

Your family trades in silk, grain, horses, tools, pills, favors, gossip, transport, and debt. You were taught that everything has a price, but the price is not always money.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Charisma, Intelligence, Wisdom.
- Increase two of the following ability scores by 1 each: Charisma, Intelligence, Wisdom.

### Skill Proficiencies

You gain proficiency in Persuasion and Investigation.

### Tool, Language, or Trade Proficiencies

You gain proficiency with navigator’s tools, merchant’s tools, or one artisan’s tool. You know Trade Pidgin or another trade language from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Sect Stewardship Sphere.** You gain the Sect Stewardship sphere and the **Clean Ledger Hand** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Binding Script** talent.

If Ink or Sect Stewardship later awakens into active sphere use, choose an listed Variant Expression that reflects whether your training came through contracts, clan ledgers, trade seals, auction law, caravans, or merchant intelligence.

### Starting Equipment

You begin with fine travel clothes, a ledger, writing tools, a merchant token, a purse of mixed coin, a trade sample, and one letter of introduction.

### Origin Insight Options

Suggested Origin Insights include:

- Everything Has a Price
- Read the Buyer
- Family Ledger
- Courtly Caution

### Social Hook

Your family name may open doors, create obligations, or place you under scrutiny. A merchant clan rarely gives help without remembering it.

---

## Military Brat

You grew up around barracks, marching grounds, horses, weapons, command tents, old soldiers, and shouted orders. Discipline became instinct before you understood the politics behind it.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Strength, Constitution, Charisma.
- Increase two of the following ability scores by 1 each: Strength, Constitution, Charisma.

### Skill Proficiencies

You gain proficiency in Athletics and Intimidation.

### Tool, Language, or Trade Proficiencies

You gain proficiency with land vehicles and Military Sign, a simple gestural code used for field commands.

### Background Sphere and Talent

Choose one:

- **Equipment Sphere.** You gain the Equipment sphere and the **Armor Training** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Shield Training** talent.
- **Spear Sphere.** You gain the Spear sphere and the **Rooted Spear Stance** talent.
- **Warleader Sphere.** You gain the Warleader sphere and the **Battlefield Coordination** talent.

If Warleader later awakens into active sphere use, choose an listed Variant Expression that reflects whether your command style comes from discipline, fear, battlefield rhythm, banner culture, or protective leadership.

### Starting Equipment

You begin with sturdy clothes, a simple weapon, a bedroll, a whetstone, a unit token or old insignia, and field rations.

### Origin Insight Options

Suggested Origin Insights include:

- Drill Instinct
- Hold the Line
- Pain Familiarity
- Open Sky Nerve
### Social Hook

Soldiers, guards, and veterans may treat you as familiar. Deserters, rebels, bandits, and victims of military campaigns may not.

---

## Northern Steppe Rider

You were born beneath an open sky and raised among horses, herds, banners, storms, raids, songs, and old ancestor customs. The Empire may call your people barbarians. You know better.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Constitution, Charisma.
- Increase two of the following ability scores by 1 each: Dexterity, Constitution, Charisma.

### Skill Proficiencies

You gain proficiency in Animal Handling and Intimidation.

### Tool, Language, or Trade Proficiencies

You gain proficiency with land vehicles and one northern tribal language.

### Background Sphere and Talent

Choose one:

- **Beastmastery Sphere.** You gain the Beastmastery sphere and the **Mount Training** talent.
- **Spear Sphere.** You gain the Spear sphere and the **Pursuit Spear** talent.
- **Barrage Sphere.** You gain the Barrage sphere and the **Mobile Barrage** talent.
- **Warleader Sphere.** You gain the Warleader sphere and the **Rallying Speech** talent.

At level 0, Beastmastery from this Background represents horse-handling, herd knowledge, and early bond discipline. It does not grant a full bonded companion unless another feature says so. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as horse-soul, ancestor-rider, banner-herd, or storm-steppe practice.

### Starting Equipment

You begin with riding clothes, a shortbow or simple weapon, a riding kit, a weather cloak, a clan token, dried meat, and a horsehair charm.

### Origin Insight Options

Suggested Origin Insights include:

- Born in the Saddle
- Open Sky Nerve
- Beast Sign
- Weather Ear

### Social Hook

Steppe folk may see you as kin or rival. Imperial subjects may see you through stories of raids, tribute, border wars, and freedom they do not understand.

---

## Puppeteer’s Child

Your family carved dolls, masks, toys, shrine figures, theater puppets, or ritual effigies. You learned how to make still things seem alive, and how much people reveal when they think only a doll is watching.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Intelligence, Charisma.
- Increase two of the following ability scores by 1 each: Dexterity, Intelligence, Charisma.

### Skill Proficiencies

You gain proficiency in Performance and Sleight of Hand.

### Tool, Language, or Trade Proficiencies

You gain proficiency with woodcarver’s tools.

### Background Sphere and Talent

Choose one:

- **Puppetry Sphere.** You gain the Puppetry sphere and the **Little Servant’s Errand** talent.
- **Puppetry Sphere.** You gain the Puppetry sphere and the **Hidden Thread** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.

At level 0, Puppetry from this Background represents craft, performance, puppet handling, doll repair, and familiarity with puppet forms. It does not grant a combat puppet or full animated servant unless another feature says so. If Puppetry later awakens into active sphere use, choose an listed Variant Expression such as theater puppet, ritual doll, corpse puppet, battle puppet, spirit doll, or artisan construct.

### Starting Equipment

You begin with performer’s clothes, woodcarver’s tools, carving knives, paint, string, a small puppet or doll, and a repair kit.

### Origin Insight Options

Suggested Origin Insights include:

- Painted Face
- Still Hands
- Quick Hands
- Patient Mind

### Social Hook

Puppeteers, actors, shrine keepers, and children may welcome you. Others may find your work unsettling, especially where dolls are used for curses, mourning rites, or spirit vessels.

---

## Shinobi Apprentice

You trained in silence, misdirection, climbing, coded speech, poison handling, and the discipline of not being remembered. Your name may never have been written down.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Wisdom, Intelligence.
- Increase two of the following ability scores by 1 each: Dexterity, Wisdom, Intelligence.

### Skill Proficiencies

You gain proficiency in Acrobatics and Stealth.

### Tool, Language, or Trade Proficiencies

You gain proficiency with poisoner’s kit and thieves’ tools.

### Background Sphere and Talent

Choose one:

- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Cut and Run** (`CUT AND RUN`) talent.
- **Trap Sphere.** You gain the Trap sphere and the **Warning Trigger** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.
- **Poison Sphere.** You gain the Poison sphere and the **Poison Sense** talent.

At level 0, Poison from this Background represents mundane poison handling, antidote caution, and training-safe exposure. It does not grant advanced toxic cultivation or supernatural venom unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as shinobi poison, alchemical venom, cursed toxin, needle poison, or breath poison.

### Starting Equipment

You begin with dark travel clothes, a simple weapon, a climbing cord, a poisoner’s kit, thieves’ tools, smoke pellets with no combat effect unless a printed rule allows, and coded training notes.

### Origin Insight Options

Suggested Origin Insights include:

- Vanishing Step
- Patient Shadow
- Poison Familiarity
- No One Saves You
### Social Hook

You may be useful, feared, or disposable. Samurai, magistrates, sects, and criminal houses may all have reasons to deny knowing people like you exist.

---

## Temple Initiate

You were raised or trained in a shrine, temple, monastery, ancestral hall, or roadside sanctuary. You learned prayers, offerings, ritual forms, discipline, and the names of powers older than your village.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Intelligence, Charisma.
- Increase two of the following ability scores by 1 each: Wisdom, Intelligence, Charisma.

### Skill Proficiencies

You gain proficiency in Religion and Insight.

### Tool, Language, or Trade Proficiencies

You gain proficiency with calligrapher’s supplies. You know Classical or one sacred language from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Talismans Sphere.** You gain the Talismans sphere and the **Warding Talisman** talent.
- **Protection Sphere.** You gain the Protection sphere and the **Ward** talent.
- **Radiance Sphere.** You gain the Radiance sphere and the **Consecrated Lantern** talent.
- **Spirit Companions Sphere.** You gain the Spirit Companions sphere and the **Minor Spirit Agreements** talent.

At level 0, these Background Spheres represent ritual knowledge, etiquette, shrine practice, and spiritual literacy rather than full active sphere use. If the sphere later awakens into active sphere use, choose an listed Variant Expression that reflects your temple, ancestor hall, doctrine, shrine spirit, vow, or ritual lineage.

### Starting Equipment

You begin with simple robes, prayer beads, calligrapher’s supplies, incense, a temple token, a small ritual text, and a charm against misfortune.

### Origin Insight Options

Suggested Origin Insights include:

- Shrine Child
- Sincere Offering
- Scripture Memory
- Breath Before Thought

### Social Hook

Temples and shrines may offer hospitality, but they may also expect discipline, service, humility, and respect for obligations you did not choose.


---

## Beast Hunter

You learned to track things that could kill you. You know claw marks, scat, broken branches, blood trails, territorial warnings, and the difference between an animal, a spirit beast, and something pretending to be either.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Strength, Dexterity, Wisdom.
- Increase two of the following ability scores by 1 each: Strength, Dexterity, Wisdom.

### Skill Proficiencies

You gain proficiency in Survival and Nature.

### Tool, Language, or Trade Proficiencies

You gain proficiency with leatherworker’s tools, trapper’s tools, or one hunter’s trade from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Spear Sphere.** You gain the Spear sphere and the **Rooted Spear Stance** talent.
- **Barrage Sphere.** You gain the Barrage sphere and the **Distracting Shot** talent.
- **Trap Sphere.** You gain the Trap sphere and the **Noose** talent.
- **Beastmastery Sphere.** You gain the Beastmastery sphere and the **Lookout** talent.

At level 0, Beastmastery from this Background represents tracking, calming, baiting, avoiding, and reading beasts. It does not grant a bonded companion unless another feature says so. If Beastmastery later awakens into active sphere use, choose an listed Variant Expression such as hunter’s bond, trophy-oath, pack sign, spirit-beast respect, or predator-prey discipline.

### Starting Equipment

You begin with travel clothes, a hunting knife, a simple ranged weapon or spear, trapper’s tools or leatherworker’s tools, a coil of cord, trail rations, and a trophy from a beast you survived.

### Origin Insight Options

Suggested Origin Insights include:

- Beast Sign
- Quiet Footsteps
- Pain Familiarity
- Weather Ear
### Social Hook

Villages may respect you when beasts threaten them. Sects may treat you as crude until they need someone who understands what lives beyond their walls.

---

## Clan Heir

You were born into a family that remembers its ancestors, guards its reputation, and expects its children to become useful. You may be loved, controlled, protected, traded, trained, or burdened by expectation.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Charisma, Intelligence, Wisdom.
- Increase two of the following ability scores by 1 each: Charisma, Intelligence, Wisdom.

### Skill Proficiencies

You gain proficiency in Persuasion and History.

### Tool, Language, or Trade Proficiencies

You gain one language of your choice and proficiency with calligrapher’s supplies or one artisan’s tool tied to your clan.

### Background Sphere and Talent

Choose one:

- **Sect Stewardship Sphere.** You gain the Sect Stewardship sphere and the **Sect Token Etiquette** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Reinforced Robes** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Binding Script** talent.
- **Sword Sphere.** You gain the Sword sphere and the **Sword Guard** talent.

If Ink, Sect Stewardship, or Sword later awakens into active sphere use, choose an listed Variant Expression that reflects whether your clan trained you through records, etiquette, ancestral seals, guarded forms, ritual weapons, or inherited reputation.

### Starting Equipment

You begin with quality clothes, a clan token, writing tools, a family letter, a signet or seal, and a small inherited keepsake.

### Origin Insight Options

Suggested Origin Insights include:

- Bureaucratic Eye
- Family Ledger
- Courtly Caution
- Family Name
### Social Hook

Your name opens some doors and closes others. Your actions may reflect on people who are not present but still have power over your life.

---

## Exiled Noble

You were born near power and cast away from it. Your family may have lost favor, been defeated, been betrayed, or sent you away as sacrifice, hostage, embarrassment, or hidden hope.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Charisma, Dexterity, Wisdom.
- Increase two of the following ability scores by 1 each: Charisma, Dexterity, Wisdom.

### Skill Proficiencies

You gain proficiency in Deception and Insight.

### Tool, Language, or Trade Proficiencies

You gain one language of your choice and proficiency with one gaming set, musical instrument, courtly tool, or noble practice from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Sword Sphere.** You gain the Sword sphere and the **Sword Drawing Stance** talent.
- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Distracting Trickery** (`DISTRACTING TRICKERY`) talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.
- **Sect Stewardship Sphere.** You gain the Sect Stewardship sphere and the **Quiet Apology Method** talent.

If Sword, Scoundrel, or Sect Stewardship later awakens into active sphere use, choose an listed Variant Expression that reflects whether your exile sharpened your swordwork, dueling, deception, political survival, patronage network, or hatred of courtly masks.

### Starting Equipment

You begin with worn fine clothes, a concealed family token, a small weapon, a letter you have not decided whether to destroy, and enough coin to look respectable once.

### Origin Insight Options

Suggested Origin Insights include:

- Fallen House
- Hide the Stain
- Courtly Caution
- Paper Trail
### Social Hook

Some people still know your name. Some pity it. Some hate it. Some may want to use you as a symbol, hostage, claimant, or scapegoat.

---

## Furnace Laborer

You worked in heat, smoke, stone, metal, salt, kilns, mines, docks, foundries, or construction yards. Your body learned pain before anyone called it discipline.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Strength, Constitution, Wisdom.
- Increase two of the following ability scores by 1 each: Strength, Constitution, Wisdom.

### Skill Proficiencies

You gain proficiency in Athletics and Survival.

### Tool, Language, or Trade Proficiencies

You gain proficiency with smith’s tools, mason’s tools, miner’s tools, carpenter’s tools, or another labor trade from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Brute Sphere.** You gain the Brute sphere and the **Focused Might** talent.
- **Blacksmith Sphere.** You gain the Blacksmith sphere and the **Field Repair** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Mighty Conditioning** talent.

At level 0, Blacksmith from this Background represents practical repair, forge knowledge, tool use, and material sense. It does not grant advanced artifact forging unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as forge-hand, furnace-body, weapon repair, metal scripture, construction labor, or body-as-forge practice.

### Starting Equipment

You begin with work clothes, heavy gloves, a simple tool from your trade, a waterskin, a whetstone or chalk line, and a scar from work that should have broken you.

### Origin Insight Options

Suggested Origin Insights include:


- Drill Instinct
- Hold the Line
- Pain Familiarity
- Tool Memory
### Social Hook

Workers know the truth of who eats because others bleed. Nobles and sect disciples may underestimate you until effort matters more than pedigree.

---

## Herb-Gatherer

You gathered roots, fungi, flowers, bark, insects, and spirit-touched plants for physicians, alchemists, temples, or hungry families. You learned that the difference between medicine and poison is often timing.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Dexterity, Intelligence.
- Increase two of the following ability scores by 1 each: Wisdom, Dexterity, Intelligence.

### Skill Proficiencies

You gain proficiency in Medicine and Nature.

### Tool, Language, or Trade Proficiencies

You gain proficiency with the herbalism kit.

### Background Sphere and Talent

Choose one:

- **Harvesting and Gathering Sphere.** You gain the Harvesting and Gathering sphere and the **Common Herbcraft** talent.
- **Harvesting and Gathering Sphere.** You gain the Harvesting and Gathering sphere and the **Farmer’s Eye** talent.
- **Alchemy Sphere.** You gain the Alchemy sphere and the **Antidote Pill** recipe.
- **Poison Sphere.** You gain the Poison sphere and the **Poison Sense** talent.

At level 0, Alchemy and Poison from this Background represent medicine, antidotes, safe handling, dosage, plant preparation, and practical field knowledge. They do not grant advanced pill refinement, supernatural toxins, or poison qi unless the sphere later awakens into active sphere use. When it does, choose an listed Variant Expression such as field medicine, temple apothecary, forest alchemy, venom craft, herb scripture, or healing garden practice.

### Starting Equipment

You begin with travel clothes, an herbalism kit, drying paper, small jars, a gathering knife, a field pouch, and a packet of common medicinal herbs.

### Origin Insight Options

Suggested Origin Insights include:

- Bitter Root Wisdom
- Triage Mind
- Poison Familiarity
- Steady Hands
### Social Hook

Physicians, alchemists, villagers, and hermits may value your knowledge. Spirit forests, sect gardens, and forbidden groves may punish careless gathering.

---

## Monastery Novice

You trained under bells, chants, cold floors, repeated forms, simple meals, and older disciples who corrected your posture before your philosophy. Whether you were devout or restless, discipline entered your bones.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Dexterity, Constitution.
- Increase two of the following ability scores by 1 each: Wisdom, Dexterity, Constitution.

### Skill Proficiencies

You gain proficiency in Religion and Acrobatics.

### Tool, Language, or Trade Proficiencies

You gain proficiency with calligrapher’s supplies, cook’s utensils, or one musical instrument used in temple or monastery practice.

### Background Sphere and Talent

Choose one:

- **Iron Fist Sphere.** You gain the Iron Fist sphere and the **Focusing Breath** talent.
- **Iron Fist Sphere.** You gain the Iron Fist sphere and the **Merciful Hand** talent.
- **Flowing River Sphere.** You gain the Flowing River sphere and the **Empty Step** talent.
- **Spear Sphere.** You gain the Spear sphere and the **Long-Shaft Discipline** talent.

If Iron Fist, Flowing River, or Spear later awakens into active sphere use, choose an listed Variant Expression that reflects whether your training came from temple discipline, body forms, compassion, suppression of ego, monastic staff-as-spear drills, weapon forms, breath rhythm, or ritual movement.

### Starting Equipment

You begin with simple robes, a staff, prayer beads or training beads, a begging bowl, sandals, and a copied verse.

### Origin Insight Options

Suggested Origin Insights include:

- Perfect the Stroke
- Courtly Caution
- Breath Before Thought
- Body Is a Shrine
### Social Hook

Monastic training earns respect in some places and suspicion in others. Your former teachers may expect humility, service, or obedience even after you leave.


---

## River Child

You grew up beside water: ferries, barges, fishing boats, floodplains, bridges, docks, reed marshes, or river shrines. You learned currents before roads and weather before calendars.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Wisdom, Constitution.
- Increase two of the following ability scores by 1 each: Dexterity, Wisdom, Constitution.

### Skill Proficiencies

You gain proficiency in Athletics and Perception.

### Tool, Language, or Trade Proficiencies

You gain proficiency with water vehicles, fisher’s tools, or one river trade from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Flowing River Sphere.** You gain the Flowing River sphere and the **Patient Water** talent.
- **Flowing River Sphere.** You gain the Flowing River sphere and the **Empty Step** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Strong Lungs** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Sure Grip** talent.

At level 0, Flowing River from this Background represents balance, breath, current-reading, footwork, and the habit of yielding before force. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as ferry-step, reed-water body, current-listening, river memory, soft redirection, or flood-survival practice.

### Starting Equipment

You begin with practical clothes, a fishing line or net, a river knife, waterproof wrapping, a small charm for safe crossings, and a coil of rope.

### Origin Insight Options

Suggested Origin Insights include:

- Weather Ear
- Breath Before Thought
- Patient Mind
- Quiet Footsteps

### Social Hook

Boatfolk, fishers, ferrymen, smugglers, and river shrines may know your ways. Landed officials often underestimate people whose homes move.

---

## Sect Servant

You lived near cultivation before you could touch it. You swept courtyards, carried water, cooked rice, copied schedules, cleaned training halls, tended fires, or watched disciples from the edge of the world you wanted.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Dexterity, Charisma.
- Increase two of the following ability scores by 1 each: Wisdom, Dexterity, Charisma.

### Skill Proficiencies

You gain proficiency in Insight and Stealth.

### Tool, Language, or Trade Proficiencies

You gain proficiency with cook’s utensils, calligrapher’s supplies, cleaning tools, or one servant trade from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.
- **Sect Stewardship Sphere.** You gain the Sect Stewardship sphere and the **Senior Brother’s Errand** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Wet Ink Warning** talent.

At level 0, Sect Stewardship and Ink from this Background represent exposure, memory, chores, routines, hierarchy, and overheard instruction. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as servant-network, outer-court etiquette, copied records, supply hall practice, or low-door sect intelligence.

### Starting Equipment

You begin with plain sect-issued clothes, a work knife, a cleaning or cooking kit, a copied schedule, a hidden scrap of overheard instruction, and a servant token.

### Origin Insight Options

Suggested Origin Insights include:

- Invisible in Plain Sight
- Listen While Serving
- Street-Hardened
- Patient Mind

### Social Hook

You know sect life from below. Servants, cooks, guards, and outer disciples may speak freely around you, but inner disciples may resent seeing you rise.

---

## Spirit Medium

Since childhood, you have sensed presences others missed: ancestral murmurs, shrine moods, dream visitors, grave-cold silences, hungry corners, or the pressure of something watching from behind the world.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Charisma, Constitution.
- Increase two of the following ability scores by 1 each: Wisdom, Charisma, Constitution.

### Skill Proficiencies

You gain proficiency in Insight and Religion.

### Tool, Language, or Trade Proficiencies

You gain one ritual, divination, funerary, shrine, or spirit-custom proficiency from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

You gain the **Spirit Companions sphere** in a preparatory form.

Choose one preparatory Spirit Companions talent:

- **Iron Courtesy**
- **Gentle Offering Method**
- **Ancestral Ear**
- **Vessel Mark**

At level 0, Spirit Companions from this Background does not grant a bonded spirit, combat companion, spirit servant, or hosted entity. It represents spirit literacy, shrine etiquette, vessel knowledge, offerings, taboos, and sensitivity to spiritual presence. When you gain Qi, Resonance, or another legal cultivation expression, you may choose one legal spirit relationship and one listed Variant Expression such as ancestor tablet, shrine familiar, dream visitor, household spirit, grave companion, weapon spirit, or pact-bound guide.

### Starting Equipment

You begin with ritual clothes, incense, a bell or spirit token, chalk or ash, a pouch of offerings, and a charm given by someone who believed you.

### Origin Insight Options

Suggested Origin Insights include:

- Spirit Pressure
- Grave Courtesy
- Sincere Offering
- Marked by Something

### Social Hook

Some people seek your help. Some call you cursed. Spirits may notice you before you know how to answer them.

---

## Talisman Apprentice

You copied strokes until your fingers cramped and learned that one crooked line can ruin a working. You may not yet know true talisman craft, but you understand ink, paper, seals, focus, and precision.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Intelligence, Dexterity, Wisdom.
- Increase two of the following ability scores by 1 each: Intelligence, Dexterity, Wisdom.

### Skill Proficiencies

You gain proficiency in Arcana and Investigation.

### Tool, Language, or Trade Proficiencies

You gain proficiency with calligrapher’s supplies.

### Background Sphere and Talent

Choose one:

- **Talismans Sphere.** You gain the Talismans sphere and the **Talisman Master’s Ink** talent.
- **Talismans Sphere.** You gain the Talismans sphere and the **Hidden Sleeve Preparation** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Vermilion Correction** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Reinforced Robes** talent.

At level 0, Talismans and Ink from this Background represent copying, seal literacy, safe handling, material preparation, and recognition of common talisman structures. They do not grant full talismanic battle arts unless the chosen talent explicitly functions at mortal scale. If the sphere later awakens into active sphere use, choose an listed Variant Expression such as paper seal, silk strip, bone tag, jade slip, blood-ink, scripture-stroke, or formation-script practice.

### Starting Equipment

You begin with work robes, calligrapher’s supplies, blank paper, practice talisman scraps with no supernatural effect, ink, a straightedge, and a sealed lesson you cannot yet read.

### Origin Insight Options

Suggested Origin Insights include:

- Formation Curiosity
- Scripture Memory
- Paper Trail
- Still Hands
### Social Hook

Talisman halls, clerks, scribes, and formation assistants may respect clean work. Masters may judge you harshly for small mistakes.

---

## Wandering Healer

You treated coughs, fevers, wounds, births, infections, broken bones, and grief before you ever touched cultivation. You know that saving someone often begins with staying calm.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Intelligence, Charisma.
- Increase two of the following ability scores by 1 each: Wisdom, Intelligence, Charisma.

### Skill Proficiencies

You gain proficiency in Medicine and Insight.

### Tool, Language, or Trade Proficiencies

You gain proficiency with the herbalism kit or healer’s kit.

### Background Sphere and Talent

Choose one:

- **Alchemy Sphere.** You gain the Alchemy sphere and the **Healing Pill** recipe.
- **Alchemy Sphere.** You gain the Alchemy sphere and the **Calming Heart Pill** recipe.
- **Life Sphere.** You gain the Life sphere and the **Clear Physician’s Eye** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.

At level 0, Alchemy and Life from this Background represent medicine, diagnosis, stabilizing treatment, pulse reading, and practical care. They do not grant full supernatural healing unless the chosen talent explicitly functions at mortal scale. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as physician’s qi, mercy hand, herb-pulse method, battlefield triage, shrine-healing, or life-thread diagnosis.

### Starting Equipment

You begin with plain travel clothes, a healer’s kit or herbalism kit, bandages, needle and thread, a small knife, a medicine pouch, and a list of patients you could not save.

### Origin Insight Options

Suggested Origin Insights include:

- Triage Mind
- Steady Hands
- Bitter Root Wisdom
- Body Is a Shrine

### Social Hook

Common folk may trust healers faster than warriors. Powerful people may value your skill but still treat you as a tool.

---

## War Refugee

War burned your old life down. You fled soldiers, beasts, famine, sect conflict, bandits, imperial punishment, or a battle between powers too large to care who lived below them.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Constitution, Dexterity, Wisdom.
- Increase two of the following ability scores by 1 each: Constitution, Dexterity, Wisdom.

### Skill Proficiencies

You gain proficiency in Survival and Perception.

### Tool, Language, or Trade Proficiencies

You gain one language, vehicle proficiency, or practical trade from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Equipment Sphere.** You gain the Equipment sphere and the **Sleep in Armor** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Padded Layers** talent.
- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Cut and Run** (`CUT AND RUN`) talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Swift Movement** talent.

If Scoundrel or Athletics later awakens into active sphere use, choose an listed Variant Expression that reflects whether your survival came through flight, scavenging, ruined streets, refugee caravans, battlefield escape, or refusing to collapse.

### Starting Equipment

You begin with patched clothes, a blanket, a small weapon, a family keepsake, travel rations, a waterskin, and something you carried from home when you should have dropped it.

### Origin Insight Options

Suggested Origin Insights include:

- Sleep Light
- No One Saves You
- Hunger Memory
- Hold the Line

### Social Hook

Refugees know routes, rumors, cruelty, and kindness that official histories ignore. Your loss may connect you to enemies, survivors, or unfinished revenge.

---

## Workshop Apprentice

You worked under a craftsperson: smith, carpenter, potter, weaver, mechanic, shipwright, glassworker, jeweler, printer, painter, or maker of ordinary things that survive ordinary hands.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Intelligence, Constitution.
- Increase two of the following ability scores by 1 each: Dexterity, Intelligence, Constitution.

### Skill Proficiencies

You gain proficiency in Investigation and Sleight of Hand.

### Tool, Language, or Trade Proficiencies

You gain proficiency with one artisan’s tool of your choice.

### Background Sphere and Talent

Choose one:

- **Blacksmith Sphere.** You gain the Blacksmith sphere and the **Field Repair** talent.
- **Blacksmith Sphere.** You gain the Blacksmith sphere and the **Workman’s Eye** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Revealing Script** talent.

At level 0, Blacksmith and Ink from this Background represent tool handling, repair, diagrams, material sense, and workshop discipline. If either sphere later awakens into active sphere use, choose an listed Variant Expression such as forge-hand, repair scripture, weapon maintenance, artifact apprentice, diagram craft, kiln method, or living-tool practice.

### Starting Equipment

You begin with work clothes, one artisan’s tool, chalk or measuring string, a repair kit, a half-finished project, and a debt or promise owed to your teacher.

### Origin Insight Options

Suggested Origin Insights include:

- Tool Memory
- Still Hands
- Patient Mind
- Scripture Memory

### Social Hook

Craft halls, laborers, merchants, and practical people respect useful hands. Sect disciples may overlook you until something important breaks.


---

## Village Child

You were raised in a village, farmstead, orchard, rice field, fishing hamlet, herding camp, or roadside settlement far from the great sects. Your life was ordinary by cultivator standards: work, seasons, elders, hunger, festivals, grudges, and weather. That ordinariness taught you things spoiled disciples often miss.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Constitution, Wisdom, Strength.
- Increase two of the following ability scores by 1 each: Constitution, Wisdom, Strength.

### Skill Proficiencies

You gain proficiency in Animal Handling and Survival.

### Tool, Language, or Trade Proficiencies

You gain proficiency with one artisan’s tool, farmer’s tools, or land vehicles.

### Background Sphere and Talent

Choose one:

- **Harvesting and Gathering Sphere.** You gain the Harvesting and Gathering sphere and the **Drying Shed Method** talent.
- **Athletics Sphere.** You gain the Athletics sphere and the **Mighty Conditioning** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Padded Layers** talent.

### Starting Equipment

You begin with plain work clothes, a farming tool or staff, a blanket, a waterskin, five days of simple food, a village charm, and a small gift from someone who hoped you would return.

### Origin Insight Options

Suggested Origin Insights include:

- Hunger Memory
- Weather Ear
- Patient Mind
- Tool Memory
### Social Hook

Common people recognize you as one of their own. They may feed you, warn you, or ask for help more readily than they would approach a polished sect disciple.

---

## Criminal Runner

You carried messages, goods, threats, debts, or contraband for people who preferred not to be named. You learned shortcuts, bribes, hidden doors, coded gestures, and how to look harmless while moving something dangerous.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Charisma, Wisdom.
- Increase two of the following ability scores by 1 each: Dexterity, Charisma, Wisdom.

### Skill Proficiencies

You gain proficiency in Stealth and Deception.

### Tool, Language, or Trade Proficiencies

You gain proficiency with thieves’ tools and one coded street language, gang cant, or regional trade argot from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Hidden Tool Cache** (`HIDDEN TOOL CACHE`) talent.
- **Scoundrel Sphere.** You gain the Scoundrel sphere and the **Switcheroo** (`SWITCHEROO`) talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.

### Starting Equipment

You begin with practical dark clothes, thieves’ tools, a small knife, a coded token, a concealed pouch, cheap travel papers, and one sealed message you were never supposed to read.

### Origin Insight Options

Suggested Origin Insights include:

- Street-Hardened
- Quick Hands
- Vanishing Step
- Paper Trail
### Social Hook

Criminals, smugglers, debt collectors, and corrupt guards may know your face or your routes. That can be useful, dangerous, or both.

---

## Artisan’s Child

You were raised in the rhythm of a trade: clay, thread, lacquer, bronze, jade dust, leather, paper, bells, baskets, dyes, glass, bone, or wood. You learned patience, repair, pattern, material quality, and the pride of work that survives the maker.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Intelligence, Wisdom.
- Increase two of the following ability scores by 1 each: Dexterity, Intelligence, Wisdom.

### Skill Proficiencies

You gain proficiency in Investigation and Insight.

### Tool, Language, or Trade Proficiencies

You gain proficiency with one artisan’s tool of your choice.

### Background Sphere and Talent

Choose one:

- **Blacksmith Sphere.** You gain the Blacksmith sphere and the **Field Repair** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Field Maintenance** talent.
- **Ink Sphere.** You gain the Ink sphere and the **Concealing Script** talent.

If Blacksmith or Ink later becomes a true cultivation expression, choose an listed Variant Expression appropriate to the trade: forge, repair, inscription, seal-work, craft-memory, or material resonance.

### Starting Equipment

You begin with work clothes, one artisan’s tool, a measuring cord, chalk or charcoal, repair scraps, a half-finished object, and a promise owed to or by your teacher.

### Origin Insight Options

Suggested Origin Insights include:

- Still Hands
- Perfect the Stroke
- Tool Memory
- Patient Mind
### Social Hook

Craftspeople may judge your hands before your words. Nobles and disciples may overlook you until something valuable breaks.

---

## Border Scout

You grew up near a border: empire and steppe, forest and road, sect territory and wilderness, village land and beast range, legal map and lived reality. You learned to move first, report clearly, and distrust quiet horizons.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Dexterity, Wisdom, Constitution.
- Increase two of the following ability scores by 1 each: Dexterity, Wisdom, Constitution.

### Skill Proficiencies

You gain proficiency in Perception and Survival.

### Tool, Language, or Trade Proficiencies

You gain proficiency with cartographer’s tools or land vehicles. You also know one border language, military sign, or tribal language from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Athletics Sphere.** You gain the Athletics sphere and the **Swift Movement** talent.
- **Trap Sphere.** You gain the Trap sphere and the **Warning Trigger** talent.
- **Sniper Sphere.** You gain the Sniper sphere and the **Still-Scope Posture** talent.

If Sniper later awakens as a cultivation expression, choose whether it represents bow discipline, breath-killing focus, thrown-weapon precision, firearm-equivalent campaign technology, or another listed Variant Expression.

### Starting Equipment

You begin with travel clothes, a shortbow or simple ranged weapon, a map case, chalk or trail markers, a weather cloak, five days of rations, and a warning token from a border post.

### Origin Insight Options

Suggested Origin Insights include:

- Weather Ear
- Beast Sign
- Open Sky Nerve
- Sleep Light

### Social Hook

Border folk may respect your caution. Court officials may dislike your habit of describing problems exactly as they are.

---

## Ancestral Shrine Keeper

You tended tablets, names, incense, offerings, genealogies, graves, old bells, and family rites. You learned that the dead are not gone merely because they are silent, and that a family’s history can bless, bind, or devour its children.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Wisdom, Charisma, Intelligence.
- Increase two of the following ability scores by 1 each: Wisdom, Charisma, Intelligence.

### Skill Proficiencies

You gain proficiency in Religion and History.

### Tool, Language, or Trade Proficiencies

You gain proficiency with calligrapher’s supplies and know Classical or one ancestral liturgical language from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Spirit Companions Sphere.** You gain the Spirit Companions sphere in a preparatory form and the **Iron Courtesy** talent.
- **Karma Sphere.** You gain the Karma sphere in a dormant form and the **Witness Seal** talent.
- **Talismans Sphere.** You gain the Talismans sphere and the **Warding Talisman** talent.

At level 0, Spirit Companions does not grant a companion. Karma remains dormant until the character has a printed activation rule. These choices represent ancestral literacy, rites, taboos, and future access. When the sphere becomes fully active, choose an listed Variant Expression.

### Starting Equipment

You begin with plain ritual clothes, incense, calligrapher’s supplies, a family or shrine token, a small bell, a pouch of offerings, and a copied list of names.

### Origin Insight Options

Suggested Origin Insights include:

- Shrine Child
- Sincere Offering
- Family Ledger
- Grave Courtesy
### Social Hook

Families, elders, shrine attendants, and spirits may treat you as someone who understands obligation. That respect may also pull you into old debts.

---

## Traveling Performer

You lived by voice, movement, mask, instrument, joke, dance, story, acrobatics, puppets, or staged grief. You learned how crowds breathe, how nobles pretend not to listen, and how truth can survive when dressed as entertainment.

### Ability Scores

Choose one:

- Increase one of the following ability scores by 2: Charisma, Dexterity, Wisdom.
- Increase two of the following ability scores by 1 each: Charisma, Dexterity, Wisdom.

### Skill Proficiencies

You gain proficiency in Performance and Acrobatics.

### Tool, Language, or Trade Proficiencies

You gain proficiency with one musical instrument, disguise kit, or performer’s tools from the campaign’s tool, language, or trade proficiency lists.

### Background Sphere and Talent

Choose one:

- **Music Sphere.** You gain the Music sphere and the **Captivating Melody** talent.
- **Jester Sphere.** You gain the Jester sphere and the **False Opening** talent.
- **Puppetry Sphere.** You gain the Puppetry sphere and the **Little Servant’s Errand** talent.
- **Equipment Sphere.** You gain the Equipment sphere and the **Hidden Plates** talent.

If Music, Jester, or Puppetry later awakens as cultivation, choose an listed Variant Expression: performance, mask, satire, ritual theater, spirit-song, puppet-stage, or another culturally fitting form.

### Starting Equipment

You begin with performer’s clothes, a costume piece or mask, one instrument or performer’s kit, travel papers, a small blade, a collection bowl, and a rumor learned from an audience member who thought you were not listening.

### Origin Insight Options

Suggested Origin Insights include:

- Painted Face
- Courtly Caution
- Read the Buyer
- Vanishing Step
### Social Hook

Performers can enter places soldiers cannot, hear what officials deny, and vanish before blame settles. They are welcomed, dismissed, exploited, and suspected in equal measure.

---

## Glossary

**Scene.** A scene is a single continuous stretch of play focused on one conflict, challenge, investigation, negotiation, journey segment, or other meaningful situation. A scene usually lasts until the immediate situation is resolved, the location or objective meaningfully changes, the party takes a rest, or the GM declares that a new scene has begun. Some Tianxia features last “for the scene” or can be used “once per scene”; these effects persist through the current situation but do not automatically carry into later encounters, unrelated conversations, downtime, or a new combat.

---

# 14. Origin Insights

An **Origin Insight** is the first truth a character brings into cultivation. It is chosen at level 0, before the sect trial, and represents a habit, wound, instinct, lesson, oath, talent, or way of seeing the world formed before the character becomes a cultivator.

Origin Insights are not Paths, Spheres, Foundations, cultivation Methods, manuals, or Recorded Arts. They do not make a character a cultivator. They show what kind of mortal is about to step into the trial.

## How to Use Origin Insights

Choose one Origin Insight at level 0 unless another rule says otherwise. Your Origin Insight remains part of the character after the sect trial and continues to function as you advance.

Use an Origin Insight whenever its trigger applies. If an Insight says it works once per long rest, once per scene, or during a short rest, use that limit exactly. If more than one reroll could apply to the same d20 test, use only one reroll and use the new result.

## Design Rules

Most Origin Insights grant two simple benefits:

1. a training benefit, such as proficiency, expertise, tool access, language, or trade proficiency; and
2. a defining edge, such as contextual advantage, a specific reroll, a concrete information question, passive survival logic, or clear narrative permission.

Origin Insights avoid new resource pools, combat rotations, bonus dice, Sphere access, Recorded Art access, Path features, Foundation access, or routine active supernatural effects.

If an Origin Insight grants proficiency in a skill, tool, language, or trade proficiency you already have, you may gain expertise in that proficiency instead, unless the Insight says otherwise.

## Core Vocabulary Used by Origin Insights

Origin Insights use normal 5.5e terms such as d20 test, ability check, saving throw, skill, tool, proficiency, expertise, advantage, action, Hit Dice, condition names such as Incapacitated or Frightened, short rest, and long rest. Expertise means you double your Proficiency Bonus for checks that use that proficiency.

A **trade proficiency** is a Background-style proficiency representing a local craft, labor role, ritual practice, coded social language, or practical profession that is narrower than a full skill and broader than a single tool. When a trade proficiency applies, add your Proficiency Bonus to the check. If a normal tool proficiency or skill already covers the task, use the most specific applicable proficiency; do not add your Proficiency Bonus twice.

A **campaign language** is any language, cant, sign system, court language, liturgical language, trade language, clan language, or regional language available in the campaign.

A **Secret effect** is any effect tagged or treated as Secret by a Tianxia rule. An **artifact-backed effect** is an effect created, hidden, protected, or altered by a magic item, spiritual item, talismanic item, legacy item, or other artifact. A **higher-Realm effect** is an effect produced by a creature, object, Method, Recorded Art, or technique above the character's current Realm.

A **scene** is a single continuous stretch of play focused on one conflict, challenge, investigation, negotiation, journey segment, or other meaningful situation. A scene usually lasts until the immediate situation is resolved, the location or objective meaningfully changes, the party takes a rest, or the GM declares that a new scene has begun. Effects that last “for the scene” or can be used “once per scene” persist through the current situation but do not automatically carry into later encounters, unrelated conversations, downtime, or a new combat.

## Verifiable Information Benefits

Some Origin Insights let you ask a question. When an Origin Insight lets you ask a question, the answer is based on observable evidence, memory, training, symbolic impression, or the current scene. The answer does not reveal hidden facts without evidence, override deception, expose Secret effects automatically, or replace a required check unless the Insight says so.

If no relevant clue, sign, irregularity, or answer exists, the answer can be "none," "unclear," "blocked," or "no obvious sign." That is still a valid result.

## Ordinary and Supernatural Effects

An **ordinary** effect is mundane, non-cultivation, non-artifact, non-Secret, and not protected by a stronger supernatural source.

An Origin Insight can help against ordinary danger when it says so. It does not automatically defeat cultivation techniques, spirit powers, artifacts, Secret effects, higher-Realm abilities, or deliberate magical concealment.

## Reroll Rule

Some Origin Insights allow a reroll. When you use an Origin Insight reroll, you must use the new roll. You cannot use more than one Origin Insight reroll on the same d20 test.

Unless stated otherwise, an Origin Insight reroll refreshes when you finish a long rest.

---

## 1. Street-Hardened

You learned to survive where law arrives late and hunger arrives early.

**Benefit.** You gain proficiency in Deception or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

While in a settlement, ruin, market, alley, dock, slum, or crowded public space, you have advantage on initiative rolls and Wisdom (Perception) checks made against ordinary ambushes, pickpockets, tailing, lookout signals, and sudden street violence.

You cannot be surprised by an ordinary ambush in those places if you are awake, able to move, and not deliberately ignoring danger. This protection does not apply against supernatural concealment, cultivation techniques, artifacts, or an enemy already inside your trusted group.

You also know the fastest obvious route toward an exit, crowd, guard post, hiding place, or immediate shelter in a public space you can perceive.

---

## 2. Hunger Memory

You know what the body becomes when comfort is gone.

**Benefit.** You gain proficiency in Survival or Athletics. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to endure hunger, thirst, exposure, forced marches, sleep deprivation, or ordinary deprivation.

You can always tell when food, water, warmth, or shelter is being wasted, hidden, rationed, poisoned, or controlled as leverage, unless the truth is concealed by a cultivation effect, artifact, or deliberate false trail.

---

## 3. No One Saves You

You learned that waiting for rescue is another way to die.

**Benefit.** You gain proficiency in Acrobatics, Athletics, or thieves' tools. If you already have proficiency in the chosen option, gain expertise in it.

Once per long rest, when you fail a d20 test made to escape restraints, flee pursuit, break free from a grapple, survive a trap, avoid capture, or act before immediate danger closes around you, you may reroll the d20.

You also have advantage on checks made to notice weak restraints, careless guards, unsecured doors, loose bindings, or bad prison habits.

---

## 4. Quick Hands

Your hands move before hesitation can catch them.

**Benefit.** You gain proficiency in Sleight of Hand or thieves' tools. If you already have proficiency in the chosen option, gain expertise in it.

You can conceal, palm, draw, retrieve, or pass a small object on your person without obvious fumbling. If another creature is watching for theft, concealment, contraband, or sleight of hand, make the normal contested check.

You have advantage on checks made to hide small tools, keys, charms, notes, blades, pills, coins, or similar hand-sized objects on your body.

---

## 5. Sleep Light

You never fully trusted safety.

**Benefit.** You gain proficiency in Perception or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

While resting or sleeping lightly, you have advantage on Wisdom (Perception) checks made to notice ordinary noise, movement, light, touch, nearby voices, a change in camp rhythm, or an approaching creature.

If you are sleeping lightly and not Incapacitated, you cannot be surprised by ordinary intruders who must cross open ground, open a door, disturb your belongings, touch you, or enter your immediate sleeping space. This protection does not apply against supernatural concealment, teleportation, dream attacks, or a creature already accepted into the camp.

---

## 6. Unsettling Blood

Something in your presence makes ordinary people hesitate.

**Benefit.** You gain proficiency in Intimidation. If you already have proficiency in Intimidation, gain expertise in it.

When someone senses that your bloodline, aura, curse, ancestry, or nature is strange, you have advantage on Charisma checks made to make them pause, back down, take you seriously, or admit fear.

Spirit-sensitive creatures, trained cultivators, shrine officials, and occult specialists can usually tell that something about you is unusual after interacting with you for 1 minute, unless you are actively concealing it.

---

## 7. Hide the Stain

You grew up concealing a mark, curse, bloodline, shame, or secret.

**Benefit.** You gain proficiency in Deception or disguise kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to hide visible signs of lineage, curse, injury, social origin, spiritual abnormality, fear, shame, or forbidden contact.

When someone studies you for a hidden stigma, you can identify what sign they are focusing on: body, clothing, accent, behavior, documents, aura, blood, family name, or rumor.

---

## 8. Marked by Something

Your life carries a sign others may not understand.

**Benefit.** You gain proficiency in Religion, Arcana, or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify whether a mark, scar, dream-sign, birthmark, curse, omen, strange aura, or spirit pressure is natural, inherited, ritual, spiritual, or cultivation-made.

When a creature reacts strongly to your mark, you can tell whether the reaction is fear, recognition, disgust, reverence, hunger, curiosity, or trained caution.

---

## 9. Born Under Suspicion

People accused you before they knew your name.

**Benefit.** You gain proficiency in Deception or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to detect when someone has already judged you, is looking for an excuse to blame you, or is pretending to ask questions while expecting guilt.

Once per long rest, when you fail a Charisma or Wisdom check made to avoid false blame, deflect suspicion, or prove you are not the immediate threat, you may reroll the d20.

---

## 10. Dream Listener

Your dreams are not always yours alone.

**Benefit.** You gain proficiency in Insight, Perception, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

After each long rest, choose one current danger, mystery, spirit, oath, person, or future opportunity known to your character. Ask one question:

- What emotion clung to it in my dream?
- What symbol repeated around it?
- Did the dream warn me toward it, away from it, or deeper into it?
- Did the dream feel mortal, spiritual, ancestral, demonic, or unclear?

The answer is symbolic, not a complete prediction. If the subject is shielded by stronger magic, cultivation, or secrecy, the answer may be "blocked," "distorted," or "unclear."

You have advantage on checks made to interpret dreams, recognize recurring symbols, resist dream confusion, or notice when a dream is being influenced by an outside force.

---

## 11. Old Dream

Some dreams feel older than your current life.

**Benefit.** You gain proficiency in History, Insight, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail an Intelligence or Wisdom check related to a place, person, symbol, technique, enemy, route, or danger that feels strangely familiar, you may reroll the d20.

When a place, person, symbol, or threat feels tied to a life before this one, choose one impression: danger, debt, loss, promise, betrayal, or unfinished work. You know that impression is emotionally true to your character's echo, even if it is not literal history.

---

## 12. Omen Sense

You notice the world's small warnings.

**Benefit.** You gain proficiency in Insight or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to notice symbolic warnings, unnatural animal behavior, bad-luck patterns, ritual disturbances, weather signs, strange silences, or repeated coincidences.

Once per scene, when you pause to read the situation, ask whether there is an obvious omen, warning pattern, disturbed sign, or repeated symbol present. The answer identifies the sign if one exists; it does not explain the entire danger.

---

## 13. Half-Awake

You learned to live between sleep and waking.

**Benefit.** You gain proficiency in Perception or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to recognize illusions, dreams, possession signs, memory gaps, false awakenings, or attempts to confuse whether you are asleep, awake, or entranced.

When you wake from sleep, trance, unconsciousness, or magical confusion, you can immediately recall the last clear sensory detail before the state began.

---

## 14. Beast Sign

You learned to read the body language of things with teeth.

**Benefit.** You gain proficiency in Animal Handling, Survival, or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify whether a beast is hungry, afraid, territorial, wounded, trained, corrupted, protecting young, defending a den, or preparing to flee.

When a beast tracks, watches, stalks, circles, or tests you, you can tell which behavior it is using if you can observe it for at least 1 round.

---

## 15. Weather Ear

You learned to hear the sky before it speaks.

**Benefit.** You gain proficiency in Nature or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to predict ordinary weather, identify storm signs, read river rise, notice dangerous wind shifts, track seasonal hazards, or prepare camp against exposure.

With 1 minute of observation, you can tell whether the next few hours are likely to bring worsening weather, clearing weather, dangerous travel, or no meaningful change.

---

## 16. Quiet Footsteps

You learned that sound is a kind of confession.

**Benefit.** You gain proficiency in Stealth or Acrobatics. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to move quietly across ordinary floors, stairs, roofs, alleys, underbrush, camps, halls, or sleeping areas.

When you fail a Stealth check by 5 or less while moving slowly, you may choose to stop in place before entering the exposed space, if there is a legal place to stop.

---

## 17. Bitter Root Wisdom

You learned medicine from things that taste bad and save lives.

**Benefit.** You gain proficiency in Nature, Survival, herbalism kit, or Medicine. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to identify common herbs, roots, fungi, teas, poultices, field remedies, spoiled medicine, and ordinary plant toxins.

During a short rest in a natural or stocked environment, you can prepare simple bitter remedies. One creature who spends Hit Dice during that rest may ignore disadvantage on one Constitution check or saving throw caused by ordinary sickness, nausea, bad food, or exposure before its next long rest.

---

## 18. Bureaucratic Eye

You know where power leaves paperwork.

**Benefit.** You gain proficiency in Investigation, History, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to understand permits, seals, rosters, court documents, sect records, tax lists, travel papers, ledgers, or official instructions.

After studying a document, office, queue, gate, or checkpoint for 1 minute, you can identify the person, seal, office, bribe point, missing form, or procedural step most likely to matter next.

---

## 19. Scripture Memory

You were trained to hold exact words inside your mind.

**Benefit.** You gain proficiency in History, Religion, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You can perfectly recall any ordinary, non-artifact text, law, poem, oath, formula, prayer, map, inscription, or instruction you have spent at least 10 minutes studying.

You have advantage on checks made to detect altered wording, missing lines, false quotations, forged doctrine, or corrupted scripture. Magical, Secret, artifact-backed, or mind-altering texts may require a normal check.

---

## 20. Paper Trail

You know that lies become weaker when written down.

**Benefit.** You gain proficiency in Investigation, Insight, or forgery kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to compare handwriting, identify forged seals, track transactions, find contradictions in testimony, or connect people through receipts, travel papers, ledgers, or letters.

After 10 minutes studying a set of mundane records, you can identify one inconsistency, missing document, suspicious repetition, or unusual signature if such a clue is present.

---

## 21. Courtly Caution

You learned that manners are armor.

**Benefit.** You gain proficiency in Insight, Persuasion, or one court or formal campaign language. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to avoid giving offense in formal settings, recognize status order, follow etiquette, identify who should speak first, or notice when politeness hides a threat.

When entering a formal meeting, court, hall, audience, or banquet, you know the safest obvious person to greet first and the most dangerous obvious person to ignore.

---

## 22. Breath Before Thought

You learned to take one breath before the mistake.

**Benefit.** You gain proficiency in Insight, Perception, or meditation, breath, or discipline practice as a trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

Once per long rest, when you fail a Wisdom saving throw or Wisdom ability check because of fear, anger, panic, temptation, distraction, insult, or social pressure, you may reroll the d20.

You have advantage on checks made to remain still, keep silence, wait patiently, or avoid reacting to deliberate provocation.

---

## 23. Body Is a Shrine

You were taught that flesh remembers discipline.

**Benefit.** You gain proficiency in Athletics, Medicine, or Religion. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify training injuries, strain, poor posture, breath disruption, fasting weakness, overtraining, exhaustion signs, or ordinary body-conditioning mistakes.

During a short rest, you may examine one willing creature. Until its next long rest, that creature has advantage on the next check it makes to continue training, march safely, recover posture, or avoid worsening an ordinary strain.

---

## 24. Formation Curiosity

Patterns have always bothered you until they made sense.

**Benefit.** You gain proficiency in Arcana, Investigation, or calligrapher's supplies. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to study diagrams, floor patterns, ritual layouts, ward marks, talisman grids, architectural symmetry, or repeated spatial arrangements.

After 1 minute studying a visible pattern, you can tell whether it is decorative, instructional, logistical, ritual, defensive, or deliberately misleading, unless it is concealed by a stronger effect.

---

## 25. Patient Mind

You are difficult to rush when the answer matters.

**Benefit.** You gain proficiency in Investigation, Insight, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

When you spend at least 10 minutes studying a noncombat problem, text, object, route, mechanism, person, negotiation, or social situation, ask one question:

- What detail here is easiest to overlook?
- What part of this seems out of place?
- What would haste most likely get wrong?
- What should be checked before acting?

The answer identifies a real observable clue, risk, or absence of such a clue. It does not reveal hidden information without evidence.

You have advantage on checks made to resist being hurried into a bad decision.

---

## 26. Everything Has a Price

You were taught that money is only one kind of payment.

**Benefit.** You gain proficiency in Persuasion or Investigation. If you already have proficiency in the chosen skill, gain expertise in it.

When bargaining with a creature you can understand, you can identify whether it seems to value coin, favor, safety, status, revenge, secrecy, recognition, protection, or relief more than the thing it is asking for. A creature can conceal this with a contested Deception check against your Insight.

You have advantage on checks made to negotiate trades where you can offer a non-monetary benefit.

---

## 27. Read the Buyer

You know how desire moves across a face.

**Benefit.** You gain proficiency in Insight or Persuasion. If you already have proficiency in the chosen skill, gain expertise in it.

During bargaining, bribery, gift exchange, haggling, trade negotiations, auction scenes, or a similar exchange, you may study one creature for 1 minute and ask one question:

- Does this creature truly want the item or outcome it claims to want?
- Is this creature more afraid of losing face, money, safety, time, or control?
- Is this creature pretending indifference?
- Would a better offer need coin, secrecy, status, protection, or speed?

The answer reflects observable behavior and does not reveal magically concealed thoughts.

You have advantage on Insight checks made during the same exchange.

---

## 28. Family Ledger

You learned that debts outlive the people who create them.

**Benefit.** You gain proficiency in History, Insight, or Investigation. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to remember debts, marriages, grudges, favors, inheritances, old disputes, clan obligations, and who benefited from a past arrangement.

When you learn a family, clan, sect, shop, or patron name, you can tell whether you have heard of any obvious debt, feud, alliance, or reputation tied to it. If none is known to you, you know that as well.

---

## 29. Drill Instinct

Your body remembers command before fear can argue.

**Benefit.** You gain proficiency in Athletics or Intimidation. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on saving throws and checks made to resist fear, intimidation, panic, forced retreat, or effects that would make you abandon an assigned position.

In a chaotic noncombat scene, you can issue one short, clear command to frightened commoners, recruits, servants, or untrained allies who can understand you. Creatures who are not hostile and have no stronger order will follow that command for 1 round if it does not clearly endanger them.

---

## 30. Hold the Line

You know how to stay steady when others flinch.

**Benefit.** You gain proficiency in Athletics or Survival. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail a saving throw or ability check to resist being frightened, shoved, knocked prone, intimidated, separated from an ally, or forced to abandon your position, you may reroll the d20.

You have advantage on checks made to brace doors, hold barricades, keep formation, maintain footing, or protect someone directly behind you.

---

## 31. Pain Familiarity

Pain is not new to you.

**Benefit.** You gain proficiency in Athletics or Medicine. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to continue working, moving, climbing, carrying, crawling, marching, or completing a simple physical task while injured, sick, or in physical discomfort. This does not reduce damage or ignore conditions.

You can tell whether pain is likely to be dangerous injury, ordinary strain, deliberate torture, training discomfort, poison, or sickness after observing the symptoms for 1 minute.

---

## 32. Born in the Saddle

You learned distance from the back of a mount.

**Benefit.** You gain proficiency in Animal Handling or land vehicles. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to ride, calm, guide, mount, dismount, evaluate, or care for ordinary riding animals.

When travel depends on mounts, you can identify the most tired mount, the best lead animal, and the first obvious sign of lameness, fear, thirst, or bad terrain.

---

## 33. Open Sky Nerve

You learned courage from wide places and no walls.

**Benefit.** You gain proficiency in Survival, Perception, or Animal Handling. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks and saving throws made to resist fear, hesitation, vertigo, weather panic, battlefield noise, or intimidation while outdoors, mounted, in open terrain, or under a visible sky.

When you can see the horizon or a large open route, you know the safest obvious direction to scatter, retreat, regroup, or signal allies.

---

## 34. Painted Face

You learned that a mask can tell the truth safely.

**Benefit.** You gain proficiency in Performance, Deception, or disguise kit. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to perform a role, hide emotion behind costume, use satire to criticize safely, or make an audience accept a symbolic truth as entertainment.

While performing for a crowd, you can tell whether the crowd is amused, offended, frightened, restless, or waiting for permission to react.

---

## 35. Still Hands

Your hands do not shake when precision matters.

**Benefit.** You gain proficiency in Sleight of Hand, calligrapher's supplies, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made for delicate tool use, fine repair, careful handling, needlework, brushwork, inscription copying, lock manipulation, or small-object placement when time pressure is not immediate danger.

If your hands are free and you are not restrained, ordinary fear, insult, or social pressure does not impose disadvantage on your precision tool checks.

---

## 36. Vanishing Step

You learned to leave the moment before attention arrives.

**Benefit.** You gain proficiency in Stealth or Acrobatics. If you already have proficiency in the chosen skill, gain expertise in it.

Once per long rest, when you fail a Dexterity check made to hide, slip away, break line of sight, escape pursuit, or pass through a crowded or cluttered space without being stopped, you may reroll the d20.

You have advantage on checks made to identify the nearest cover, crowd, corner, doorway, window, or obstruction you could use to leave someone's direct attention.

---

## 37. Patient Shadow

You can wait longer than suspicion.

**Benefit.** You gain proficiency in Stealth, Perception, or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to remain hidden, keep watch, tail someone slowly, observe a routine, or wait without fidgeting for at least 10 minutes.

After observing a person, guard post, shop, camp, or route for 10 minutes, you can identify one repeated habit, blind spot, timing pattern, or change from the expected pattern.

---

## 38. Poison Familiarity

You learned that poison is a tool before it is a crime.

**Benefit.** You gain proficiency in poisoner's kit, Medicine, or Nature. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to identify ordinary poisons, venom, bad antidotes, tainted food, toxic plants, dangerous powders, and symptoms of poisoning.

Once per long rest, when you fail a saving throw against an ordinary poison or poisoned food or drink, you may reroll the d20. This does not apply to Secret, artifact-backed, or higher-Realm poisons unless another rule says so.

---

## 39. Shrine Child

You grew up where incense meant listening.

**Benefit.** You gain proficiency in Religion, Insight, or Performance. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to recognize shrine etiquette, household gods, local taboos, offering customs, ancestor tablets, ritual spaces, and signs of neglect or recent worship.

When entering a shrine, graveyard, ancestor hall, or sacred place, you can identify the most obvious respectful first action: bow, silence, incense, cleansing, offering, removal of shoes, avoiding a boundary, or asking permission.

---

## 40. Sincere Offering

You understand that spirits notice form, respect, and intention.

**Benefit.** You gain proficiency in Religion, Insight, or Performance. If you already have proficiency in the chosen skill, gain expertise in it.

When you make a respectful offering, apology, prayer, or request to a minor spirit, ancestor, shrine, or sacred place using appropriate form, your approach does not count as an insult unless you have already offended it, violated its nature, or entered as an enemy.

Once per scene, after making such an offering, ask one question:

- Was the offering accepted, rejected, ignored, or blocked?
- Did the place or spirit react with welcome, warning, hunger, anger, grief, or silence?
- What part of the form mattered most here?

This does not force a spirit to answer, help, forgive, or reveal itself.

---

## 41. Triage Mind

You know what must be treated first.

**Benefit.** You gain proficiency in Medicine or Insight. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to assess who is most injured, poisoned, panicking, bleeding, exhausted, or in immediate danger.

As an action, you may examine a creature you can touch or clearly observe. You learn whether its most urgent visible problem is injury, poison, sickness, fear, exhaustion, spiritual pressure, or no obvious emergency.

---

## 42. Steady Hands

Your hands know how to help under pressure.

**Benefit.** You gain proficiency in Medicine, herbalism kit, or one artisan's tool. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to stabilize a creature, bind wounds, hold a patient still, administer medicine, remove a visible irritant, or perform careful work while others are panicking.

Once per long rest, when you fail a Medicine check or tool check made to prevent immediate harm from worsening, you may reroll the d20.

---

## 43. Tool Memory

You remember how a tool is supposed to feel.

**Benefit.** You gain proficiency in one artisan's tool, smith's tools, carpenter's tools, or tinker's tools. If you already have proficiency in the chosen tool, gain expertise in it.

You have advantage on checks made to identify damaged tools, bad repairs, poor materials, missing pieces, unsafe construction, or whether a tool has been used recently.

After 1 minute handling a mundane tool, weapon, lock, harness, hinge, wheel, or mechanism, you can identify the most obvious fault or confirm that no obvious fault is present.

---

## 44. Family Name

Your name arrives before you do.

**Benefit.** You gain proficiency in Persuasion, History, or one language tied to your family, clan, or region. If you already have proficiency in the chosen option, gain expertise in it.

In places where your family, clan, patron, sect, or lineage is recognized, you can usually secure one reasonable courtesy appropriate to your status: an audience, lodging, basic introductions, temporary shelter, formal acknowledgment, or a chance to explain yourself.

This help creates expectations, scrutiny, requests, political consequences, or obligations tied to the name you used. You know before accepting the courtesy whether the expected price is public, private, immediate, or delayed.

---

## 45. Fallen House

You learned nobility from the shape it leaves behind.

**Benefit.** You gain proficiency in History, Insight, or Persuasion. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to recognize ruined families, lost titles, old banners, confiscated estates, fallen patrons, court disgrace, or people pretending their decline has not happened.

When someone invokes old status, you can tell whether they are relying on current power, remembered respect, hidden allies, debt, fear, or empty habit.

---

## 46. Invisible in Plain Sight

You learned that servants see what masters ignore.

**Benefit.** You gain proficiency in Stealth, Insight, or one service trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

In kitchens, halls, dormitories, courtyards, storehouses, stables, and servant spaces, you have advantage on checks made to move without drawing attention while dressed and behaving appropriately for the role.

You have advantage on checks made to overhear routine information while performing a believable task. This does not hide you from a creature actively searching for you or from someone who knows you do not belong.

---

## 47. Listen While Serving

You learned that important people speak freely near the useful and ignored.

**Benefit.** You gain proficiency in Insight, Perception, or one service trade proficiency. If you already have proficiency in the chosen option, gain expertise in it.

You have advantage on checks made to overhear conversations, read household moods, notice who gives orders, identify who is actually obeyed, or learn routine information while performing a believable service task.

After serving, cleaning, carrying, waiting, cooking, grooming animals, or performing another believable task for 10 minutes, you can identify one person who seems more important than their official role suggests, if such a person is present.

---

## 48. Spirit Pressure

You know the feeling of being watched by what is not flesh.

**Benefit.** You gain proficiency in Religion, Insight, or Perception. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to notice possession signs, spiritual pressure, haunted spaces, shrine moods, hostile ancestor attention, spirit residue, or the sense that an unseen presence is observing the scene.

When you enter a place with obvious spiritual pressure, you can tell whether the pressure feels welcoming, hostile, hungry, grieving, watchful, sleeping, or disturbed.

---

## 49. Grave Courtesy

You know the dead are not furniture.

**Benefit.** You gain proficiency in Religion, History, or Medicine. If you already have proficiency in the chosen skill, gain expertise in it.

You have advantage on checks made to identify burial customs, corpse handling errors, grave taboos, ancestor rites, battlefield dead, missing remains, or signs that a body has been moved after death.

When you spend 1 minute respectfully examining a corpse, grave, memorial, or ancestor tablet, you can identify one obvious irregularity: wrong placement, missing offering, improper name, disturbed soil, old injury, recent movement, or no obvious irregularity.

---

## 50. Perfect the Stroke

You learned that one line can hold a lifetime of correction.

**Benefit.** You gain proficiency in calligrapher's supplies, painter's supplies, or one artisan's tool. If you already have proficiency in the chosen tool, gain expertise in it.

You have advantage on checks made to copy a symbol, repair a line, reproduce a diagram, match handwriting, trace a seal, or identify whether a visible mark was made by a careful, rushed, forged, damaged, or trembling hand.

After studying a mundane written mark, painted line, seal, inscription, or diagram for 1 minute, you can reproduce its visible shape accurately enough for ordinary comparison. This does not copy magical power, cultivation function, or hidden meaning.

---

# 15. Manuals, Lineages, and Recorded Arts

Manuals and Lineages explain how cultivators learn named arts from teachers, scriptures, sects, clans, ruins, spirits, jade slips, journals, and hard-won experience.

A **Sphere** is a broad field of cultivation. A **Manual** is a source of preserved teaching. A **Recorded Art** is a fixed technique learned from a manual, jade slip, journal, inscription, inheritance, or similar source. A **Lineage** explains where that teaching came from and what kind of reputation, obligation, danger, or future training surrounds it.

Manuals are a major part of cultivation. A good manual can make a low-level cultivator much stronger than their peers. A high-level jade slip found in a cave, a lost emperor's scripture, or a forgotten journal that preserves a secret forged technique can change a character's entire future.

## The Basic Rule

A manual can do two different things.

| Manual Function | What It Means |
|---|---|
| **Teach a Recorded Art** | You learn a named fixed technique preserved in the source. Record it separately from your Sphere talents. |
| **Serve as a Training Source** | The manual helps you train a new Sphere, a Sphere talent, a Method, a special technique, or another cultivation benefit. |

These functions are related, but they are not the same.

If you learn a Recorded Art, you learn only that fixed expression. You do not gain the listed Sphere, the listed talents, a general-purpose package, or permission to modify the technique unless the manual or another rule specifically says so.

If you use a manual to train a Sphere or Sphere talent, use the training rules in Chapter 09: Spheres and Talents.

## Core Distinction

| Rules Element | What It Represents | What It Usually Gives |
|---|---|---|
| **Path** | Your main cultivation route: Body Refining, Qi Cultivation, or Spirit Awakening. | Hit Die, key ability, resource type, and core cultivation identity. |
| **Sphere** | A broad field of cultivation, such as Fire, Sword, Formations, Hunger, or Spirit Companions. | Sphere rules, base abilities, and access to talent choices. |
| **Talent** | A selectable option inside a Sphere. | A printed mechanical feature that usually costs a talent choice. |
| **Method** | Your cultivation practice, scripture, circulation routine, or advancement profile. | Resource Shape, Breakthrough Shape, Foundation Shape, and cultivation procedures. |
| **Foundation** | Your deep cultivation architecture. | Long-term identity, compatibility, burdens, development hooks, and later advancement effects. |
| **Manual** | A preserved teaching, scripture, form, jade slip, journal, training method, or source text. | Recorded Arts, training sources, Method access, study benefits, or cultivation clues. |
| **Recorded Art** | A fixed named technique preserved inside a manual, jade slip, journal, inscription, inheritance, or similar source. | A usable fixed expression recorded separately from Sphere talents. |
| **Lineage** | The source and inheritance behind training. | A narrative and rules source for manuals, teachers, obligations, reputation, rivals, and future techniques. |

## What a Manual Is

A **Manual** is a specific teaching. It can be a book, jade slip, wall inscription, dream lesson, sect form, monster-bone diagram, weapon kata, ancestral chant, bloodline rite, battlefield note, cultivation journal, oral teaching, or remembered lesson.

The book uses **Recorded Art** for the fixed technique learned from such a source. Use this term whenever a rule refers to a fixed preserved technique.

Manuals are narrower than Spheres. A manual might teach **Three-Step Cloud Footwork**, **Iron Ox Shoulder Form**, **Nine Ember Spear Entry**, **Cold Moon Needle Hand**, **Broken Gate Formation Primer**, or **Dream-River Exorcist Scripture**. Each of these may express one or more Spheres, but the manual is not the whole Sphere.

Think of a manual as someone's preserved answer to cultivation. It shows how a particular school, teacher, clan, spirit, emperor, survivor, monster, or failed genius solved a problem through training.

## Manuals Are Cultivation Treasure

Manuals are not minor flavor objects. They are part of the economy of power.

A strong manual can give a character a combat technique, a route into a new Sphere, a Method, a breakthrough clue, a way to repair a hidden injury, or access to a lost lineage. This is why sect libraries, scripture halls, jade slips, inheritance caves, family archives, auction houses, and stolen scrolls matter.

At early levels, a good manual can make a disciple frighteningly strong for their Realm. At higher levels, a lost emperor's manual or ancient jade slip might teach a Nascent Soul technique that combines two powerful Sphere expressions into one fixed forged technique. If a character survives long enough to understand and train it, that single manual can reshape their whole power level.

Manuals can also be bought, sold, copied, hidden, sealed, stolen, taxed, traded, or fought over. Creating a manual can make money and build reputation, but it also risks spreading your techniques to rivals, enemies, or future generations you did not intend to teach.

## What a Manual Can Contain

A manual can contain more than combat moves.

| Manual Content | What It Can Do |
|---|---|
| **Recorded Arts** | Teach fixed named techniques for combat, movement, defense, utility, rituals, or other scenes. |
| **Sphere Training** | Serve as a source for learning a new Sphere or help train talents from a Sphere. |
| **Cultivation Methods** | Teach or unlock a Method, Method variant, breathing pattern, circulation route, or advancement practice. |
| **Cultivation Journals** | Preserve a cultivator's observations, theories, mistakes, route notes, and personal insights. |
| **Breakthrough Notes** | Help prepare for a breakthrough, identify a danger, or explain a failure route if another rule grants that benefit. |
| **Foundation Guidance** | Explain compatibility, burdens, repair routes, or development paths for certain Foundations. |
| **Forged Technique Seeds** | Preserve a fixed forged technique or provide pieces needed to develop one later. |
| **Secret or Forbidden Inheritance** | Reveal techniques, Spheres, Methods, or routes that are hidden, dangerous, illegal, or socially catastrophic. |

A single manual can contain several of these. A cultivation journal might include confused theory, half-true commentary, personal grudges, failed experiments, and one buried technique that changes the reader's future.

## Recorded Arts as Fixed Expressions

A **Recorded Art** is a fixed expression of one or more Sphere abilities, talents, Methods, or special techniques.

A Recorded Art might reproduce:

- a Sphere's base ability;
- one named talent;
- a package of several talents;
- a fixed combination of two or more Spheres;
- a Foundation-level expression;
- a forged technique preserved by a teacher, sect, ruin, or ancient cultivator.

When you learn the technique, you learn that named expression exactly as the manual teaches it.

You do **not** gain the listed Sphere or talents as flexible options. You do **not** gain a general package you can rearrange. You do **not** gain permission to add unrelated talents, metasphere effects, augments, or custom upgrades.

The technique is powerful because it is complete, refined, and preserved. It is not yet your own free expression of the Dao.

### Recorded Art Format

A Recorded Art is usually written in this form:

**Sphere of [Sphere] — [Technique Name] — [Reproduced Ability or Talent Package] — Difficulty [Number]**

For example:

**Sphere of Sword and Shadow — Second-Silhouette Blade — Sword Intent Strike, Shadow Step — Foundation Technique — Difficulty 3**

This means the technique is a fixed expression involving Sword and Shadow. Learning it does not teach you the Sword Sphere, the Shadow Sphere, Sword Intent Strike as a general talent, or Shadow Step as a general talent. You learn **Second-Silhouette Blade** as written.

The Difficulty number is used when you train the Recorded Art. It is not a fixed DC by itself. See **Learning a Recorded Art** later in this chapter.

### Fixed Does Not Mean Weak

A fixed technique can be extremely powerful.

Some manuals preserve combinations that a normal cultivator could not build alone. A manual might teach a precise defensive answer, a killing strike, a movement art, a battlefield stance, a Spirit rite, a poison delivery method, a forged technique between Secret Spheres, or a higher-Realm expression left by someone far above the reader.

The limit is control, not strength. You can use the fixed technique if you learn it and meet its requirements, but you cannot freely alter it with your own talents or abilities unless a rule says you can.

## Manuals and Modification

Recorded Arts are not modified by your own talents, Sphere options, augments, Insights, Path features, Method features, or other abilities unless the manual or another rule specifically says they can be.

For example, if you learn a Recorded Art that reproduces **Shadow Step**, you cannot automatically apply every Shadow talent or movement augment you know to that Recorded Art. You use the technique as written.

If you later learn the relevant Sphere and talents normally, you can use those Spheres and talents through their own rules. That does not automatically rewrite the Recorded Art.

Some rare manuals may include advancement text such as:

- **If you know the Sword Sphere, increase the damage die by one step.**
- **If you know Shadow Step, you may spend 1 additional CP to extend the range.**
- **If you know both listed Spheres, this technique counts as a Forged Technique for you.**

Use that text only when the manual specifically provides it.

## Manuals and Spheres

A manual may mention Spheres in three ways.

| Sphere Reference | What It Means |
|---|---|
| **Theme** | The manual's imagery, movement, or Dao resembles that Sphere. This is descriptive. |
| **Reproduced Package** | A Recorded Art uses a Sphere base ability, talent, or package as part of a fixed expression. This does not grant the Sphere or talent. |
| **Printed Prerequisite** | The technique explicitly says a Sphere is required, such as **Prerequisite: Fire Sphere** or **Requirement: Sword Sphere**. This applies only when written. |

The default is simple: a character can learn a Recorded Art without knowing the matching Sphere unless the technique says otherwise.

A Sphere becomes required only when the Recorded Art lists it as a requirement. This should be used for manuals that are deliberately written as extensions of a Sphere's rules, not for ordinary martial arts, sect drills, weapon forms, scriptures, or inherited techniques.

## Manuals and Talent Choices

Recorded Arts do not count as Sphere talents unless the manual explicitly says they do.

Your Sphere talents come from your level talent, trained choices, Background benefit, new-Sphere bonus talents, and any other rule that grants a Sphere talent. Your Recorded Arts are recorded separately.

This lets the campaign include named sect arts, weapon forms, inherited scriptures, ruin techniques, and personal training without making every manual compete with your Sphere progression.

## Manuals as Training Sources

Manuals are also training sources.

A manual can teach a fixed Recorded Art and also help you learn the Sphere, talents, Method, or style behind that technique. These are separate benefits.

| Training Goal | Do You Need a Manual or Teacher? | What Rule Do You Use? |
|---|---|---|
| **Learn a Recorded Art** | Yes. You need the manual, teacher, inheritance, or other source that teaches that technique. | Use this chapter. Recorded Arts are recorded separately from Sphere talents. |
| **Train a talent from a Sphere you already know** | Usually no. You are deepening your own connection to that Sphere's Dao-expression. | Use Chapter 09 training rules. A manual or teacher can still help. |
| **Train a new Sphere** | Yes. You need a source that can reveal or teach that Sphere. A manual can be that source. | Use Chapter 09 training rules. |
| **Train a Secret, inherited, lineage, forbidden, or special talent** | Often yes. Use the talent's printed requirement. | Use Chapter 09 training rules plus the printed source requirement. |
| **Train a Method or Method variant** | Yes, unless another rule gives access. | Use the Method's own rules. The manual may be the source. |

When you train a talent from a Sphere you already know, you do not normally need an outside source. Your character already has that Sphere open. Training can come from meditation, repeated practice, sparring, body tempering, spiritual listening, Dao comprehension, or personal refinement.

A manual, teacher, library, senior disciple, spirit site, or similar aid can still matter. A strong training aid might grant advantage, reduce the DC, reduce the training time, or satisfy a special requirement if the rule or GM says it does.

### Using a Manual to Train a Sphere or Talent

If you use a manual to train a Sphere or Sphere talent, use the normal training rules from Chapter 09.

Each trained choice takes:

**1d6 + your Proficiency Bonus - your Intelligence or Wisdom modifier, minimum 2 days.**

For a talent from a Sphere you already know, the default DC is:

**DC 10 + the number of talents you already know from that Sphere.**

For a new Sphere, the default DC is:

**DC 10 + 1d4 + the number of different Spheres you know.**

A successful new-Sphere training choice teaches the Sphere's base ability and one bonus talent from that Sphere. That bonus talent does not count against your three trained choices for the level.

A manual can provide the source needed to learn the new Sphere. It does not automatically teach the whole Sphere unless the manual says it does.

## Cultivation Journals and Theory Texts

Not every manual is a clean list of techniques.

Some are **cultivation journals**: records of a cultivator's life, tests, doubts, theories, scars, victories, failures, grudges, and Dao comprehension. A journal might describe what the writer believed about their Path, how they used their abilities, how they misunderstood a Sphere, or how they tried to combine techniques.

A cultivation journal can contain true information, false information, partial information, personal bias, outdated doctrine, or dangerous misunderstanding. It can still be priceless.

A character might find:

- a correct technique hidden inside confused commentary;
- a false theory that still points toward a real Sphere;
- a Method outline buried among personal notes;
- a warning about a breakthrough danger;
- a Secret Sphere described through metaphor;
- a forged technique between two hidden Spheres;
- a failed experiment that explains how to avoid the same mistake.

If a journal contains a usable technique, Method, Sphere clue, or training source, the rule should say what can be learned from it. If the journal is uncertain or partly wrong, the GM may call for a Recorded Art Study Check or require further sources before the character can safely use it.

## Libraries and Scripture Halls

Libraries matter because manuals matter.

A sect library is not just a place to read lore. It is a storehouse of techniques, Methods, journals, maps, beast records, pill formulas, talisman diagrams, formation notes, forbidden warnings, cultivation theory, and prior disciples' failures.

Library access can decide who advances quickly and who falls behind.

Common ways to gain access include:

- earning sect tokens;
- completing missions;
- winning competitions;
- impressing a teacher;
- receiving patronage;
- trading a manual of your own;
- joining a faction;
- paying resources;
- accepting an oath or restriction;
- stealing, copying, or smuggling the text.

A manual found in a cave, purchased at auction, inherited from a dying cultivator, or unlocked in a sect library can change a campaign. Treat important manuals as treasure.

## Creating and Selling Manuals

A character can create a manual if they know a technique well enough to teach it.

The character must be able to explain, demonstrate, encode, or preserve the teaching in a usable form. This might be a written text, jade slip, diagram, chant, weapon form, formation record, dream mark, spirit pact, or direct inheritance.

Creating a manual can have several uses:

- sell it for money or sect tokens;
- trade it for library access;
- teach allies or disciples;
- preserve a lineage;
- establish a school;
- leave an inheritance;
- bargain with a clan, teacher, or sect;
- spread a false version to mislead rivals.

Creating a manual has risks. Anyone who obtains the manual might learn your technique, copy it, sell it, alter it, counter it, or trace it back to you. A manual can make your name famous, but it can also reveal how you fight.

The exact time, cost, price, and requirements for creating or selling a manual depend on the manual's power, rarity, clarity, and social danger. A basic entry form might be easy to write. A Secret forged technique, Forbidden scripture, or higher-Realm cultivation journal may require rare materials, special encoding, oaths, sect approval, or dangerous study.

## Studying Ahead

You may study a higher-Realm section of a manual before you qualify for it. This can help you understand the theory, prepare for later training, recognize the technique in play, or know what requirement you are missing.

You cannot train or use a higher-Realm talent or Recorded Art until you meet its printed requirements. Once you qualify, the earlier study may serve as the source for training, and the GM may let it help with the training check if the study was meaningful.

## Realm Requirements

Manuals can contain teachings for different Realms. You can learn or use only the portions you qualify for.

| Requirement | Meaning |
|---|---|
| **Mortal** | Available before Foundation Realm if you meet the manual's ordinary requirements. |
| **Foundation** | Requires CL 5 or higher unless the technique says otherwise. |
| **Core Formation** | Requires CL 10 or higher unless the technique says otherwise. |
| **Nascent Soul** | Requires CL 15 or higher unless the technique says otherwise. |
| **Secret Inheritance** | Requires the printed requirement and a story source strong enough to explain the inheritance. |

You may own, read, copy, translate, or study a higher-Realm manual before you qualify for its higher techniques. You simply cannot train, learn, or use those higher techniques until you meet their requirements.

## What a Lineage Is

A **Lineage** is the source behind a character's training. It answers questions like:

- Who taught you this?
- Who preserved the art?
- What kind of person usually learns it?
- What does the training demand?
- What reputation, duty, taboo, or rivalry follows it?
- What can you learn next if you stay connected to the source?

Lineages can be orthodox, unorthodox, demonic, clan-based, sect-based, monastic, military, wandering, inherited, broken, stolen, reconstructed, spirit-taught, ruin-born, item-bound, beast-taught, dream-taught, journal-taught, or failure-born.

A lineage can include manuals, teachers, journals, oaths, taboos, rival schools, sect reputation, inheritance marks, required tests, permitted items, and future training opportunities.

## Lineage Examples

| Lineage Type | Common Source | Typical Use |
|---|---|---|
| **Sect Lineage** | Outer gate, inner court, elder teaching, scripture hall. | Clear training path, ranked manuals, sect duties. |
| **Clan Lineage** | Family archive, ancestor tablet, inherited weapon, bloodline rite. | Family reputation, ancestral manuals, inherited obligations. |
| **Wandering Lineage** | Traveling teacher, battlefield survivor, hermit, roadside manual. | Flexible access, incomplete arts, personal teacher debts. |
| **Ruin Lineage** | Jade slip, wall carving, buried hall, broken formation. | Lost techniques, missing sections, dangerous interpretation. |
| **Journal Lineage** | Cultivator diary, research notes, battlefield memoir, failed thesis. | Mixed truth and error, buried techniques, theory clues. |
| **Spirit Lineage** | Ghost teacher, hosted spirit, ancestral soul, shrine pact. | Spirit-facing manuals, offerings, taboos, possession or oath risks. |
| **Beast Lineage** | Demon beast, spirit beast, mount, companion, hunting pact. | Body methods, instinct arts, companion methods, wild Foundations. |
| **Failure-Born Lineage** | Failed breakthrough, hidden injury, deviation, scar, survival lesson. | Corrective manuals, conditional power, unusual transformation routes. |
| **Forbidden Lineage** | Demonic scripture, devouring art, corrupt inheritance, sealed teacher. | High power, social danger, strict consequences, campaign pressure. |

## Starting Manual or Lineage

A new Tianxia character should record at least one starting Manual or Lineage anchor.

This starting entry does not need to be powerful. It can be a basic sect form, family lesson, village weapon method, monastery drill, companion tradition, failed apprenticeship, first scripture fragment, or old journal with one useful page.

Examples:

- **Outer Gate Sword Drill** — a basic sect weapon form.
- **Mother's River-Breath Lesson** — a family circulation habit learned before formal cultivation.
- **Broken Spear Barracks Manual** — a military drill from a border fort.
- **Shrine Fox Listening Rite** — a spirit-facing childhood practice.
- **Iron Pot Body-Warming Method** — a kitchen or laborer body-tempering habit.
- **Unfinished Wall-Carving Art** — a ruin technique with missing higher-Realm sections.
- **Unknown Cultivator's Fire-Stained Journal** — a damaged book with one technique hidden among doubtful theory.

The starting Manual or Lineage gives your character a place in the world. It grants combat power only if its rules say it does.

## Learning a Recorded Art

Use this procedure when your character studies a Recorded Art and the technique itself does not give a more specific rule.

### Step 1: Identify the Source

Decide how your character has access to the teaching.

| Source | What It Means |
|---|---|
| **Teacher** | A living instructor, spirit teacher, senior disciple, beast companion, ancestor, or other guide can correct mistakes. |
| **Complete Text** | The manual is legible and whole enough to teach its entry portion. |
| **Fragment** | The manual is damaged, missing pages, cryptic, or incomplete. |
| **Journal** | The technique is buried in commentary, theory, memoir, failed experiments, or personal notes. |
| **Ruin or Inscription** | The teaching appears in a place, mural, formation scar, weapon mark, corpse posture, or environmental clue. |
| **Inheritance** | The teaching enters through a mark, dream, possession, bloodline stirring, item, or crisis. |
| **Reconstruction** | The character is building the art from partial notes, failures, observed techniques, or personal experimentation. |

Record the source. It explains why your character can study the technique and what future duties, problems, rivals, or discoveries might follow.

### Step 2: Name the Manual and Lineage

Give the teaching a specific name and origin.

Examples:

- **Outer Gate Sword Drill**, taught by a sect elder;
- **Nine Ember Spear Entry**, copied from a jade tablet;
- **Broken Gate Formation Primer**, found on a ruined wall;
- **Shrine Fox Listening Rite**, learned through a spirit pact;
- **Cold Moon Needle Hand**, stolen from a clan scroll;
- **Emperor's Last Eclipse Slip**, recovered from a sealed cave;
- **Nameless Heretic's Water-Fire Notes**, reconstructed from a half-burned journal.

The name should be narrower than a Sphere. A manual is a specific art, not the entire Dao.

### Step 3: Check the Printed Requirements

Check only the requirements the manual actually lists.

Common requirements include:

- Realm or CL;
- Path;
- weapon, tool, item, mount, spirit bond, or body condition;
- teacher, lineage source, sect rank, oath, taboo, scar, burden, hidden injury, deviation, or prior failure;
- special location, material, scripture fragment, or inheritance mark;
- a rare explicit Sphere prerequisite.

A matching Sphere is not required unless the Recorded Art specifically says it is required.

If you do not meet a requirement, you may still keep, copy, read, translate, or study the manual. You simply cannot learn the locked technique yet.

### Step 4: Choose the Technique

A manual may contain several techniques. Choose the technique your character is trying to learn now.

Most complete manuals contain three to seven techniques. Larger manuals may be divided into Mortal, Foundation, Core Formation, Nascent Soul, and higher chapters.

If the manual has Realm sections, start with the lowest section you qualify for unless the manual says another entry point is available.

If the manual gives a study benefit, Method, Sphere clue, or journal insight instead of a technique, record that benefit as written.

### Step 5: Practice

Use the manual's own training time if it has one. Otherwise, use the learning time the GM assigns for the technique's complexity, source quality, and campaign pacing.

The times in this step apply to Recorded Arts. If you are using the manual to train a Sphere or Sphere talent, use Chapter 09 training time instead.

| Learning Situation | Default Time |
|---|---|
| Clear entry form with a teacher | One training scene, lesson, or downtime interval. |
| Complete self-study manual | One downtime interval, or several travel/rest study scenes. |
| Specialized manual | One downtime interval plus suitable practice. |
| Damaged fragment | Study can begin, but the technique is not learned until the missing section, translation, teacher key, or second fragment is found. |
| Journal with buried technique | Study requires interpretation before the technique can be trained. A check is usually appropriate. |
| Higher-Realm section | You can study it for clues, but cannot learn it until you meet its requirements. |
| Secret or Forbidden manual | A campaign event, initiation, trial, oath, corruption test, or equivalent source may be required. |

A **downtime interval** means the amount of time your campaign normally uses for noncombat advancement. Depending on pacing, it might be a day, several days, a week, or a sect training period.

### Step 6: Calculate the Recorded Art DC

Recorded Arts use their own training DC. Do not use the normal Sphere talent DC for learning a Recorded Art.

Each Recorded Art has a **Recorded Art Difficulty**. If a whole manual gives one Difficulty number, use that number for each Recorded Art in the manual unless a specific art says otherwise.

When you train a Recorded Art, calculate the DC as follows:

**DC 10 + the Recorded Art Difficulty + 2 × the number of Recorded Arts you have already learned at your current CL.**

Count only Recorded Arts learned since you reached your current CL. When you gain a new CL, this count resets to 0.

This count does not include Sphere talents, Sphere base abilities, Background talents, the CL 1 sect-trial talent, new-Sphere bonus talents, Methods, Foundations, or Recorded Arts learned at an earlier CL.

For example, if you are studying a Recorded Art with **Difficulty 2**, the first Recorded Art you learn at your current CL is DC 12. The second is DC 14. The third is DC 16. The fourth is DC 18. When you gain a new CL, the first Difficulty 2 Recorded Art at that new CL is DC 12 again.

If you are studying a Recorded Art with **Difficulty 3**, the first Recorded Art you learn at your current CL is DC 13. The second is DC 15. The third is DC 17, and so on.

This rule lets manuals be powerful without making them unlimited. A disciple can grow very strong by learning several Recorded Arts at the same CL, but each additional technique becomes harder to master before the next breakthrough.

### Step 7: Make a Recorded Art Study Check

When you train a Recorded Art, make a **Recorded Art Study Check** against the DC you calculated in Step 6 unless the technique gives a more specific rule.

A clear teaching under safe conditions may still need a check if the character is learning a new Recorded Art. The check represents whether the character can understand, drill, stabilize, and express that fixed technique at their current level of cultivation.

Use the normal Recorded Art Study Check roll:

**d20 + your Proficiency Bonus + the most relevant ability modifier**

Choose the ability that matches how your character studies the technique.

| Study Approach | Common Ability |
|---|---|
| Physical drill, body form, weapon kata, beast imitation | Strength, Dexterity, or Constitution |
| Scripture study, formation logic, alchemy notes, technical reconstruction | Intelligence |
| Meditation, spirit contact, dream study, omen reading, inherited memory | Wisdom |
| Performance, command tradition, oath recitation, social lineage, mantra | Charisma |

A relevant Sphere, Method, Foundation, tool proficiency, language, teacher, safe training hall, or clear lineage may help with the check. Depending on the situation, it might grant advantage, reduce the DC, shorten study time, or make the result cleaner.

A damaged source, dangerous technique, bad translation, hostile teacher, rushed study, route conflict, hidden injury, deviation, burden, curse, or Forbidden practice may impose disadvantage, increase the DC, add a complication, or produce only a partial result.

### Step 8: Resolve the Attempt

When a Recorded Art Study Check is used, resolve it as follows unless the manual gives its own results.

| Result | Outcome |
|---|---|
| **Success** | You learn the chosen Recorded Art or unlock the intended study benefit. |
| **Success by 5 or more** | You learn it cleanly. The campaign may also grant a clue, reduce future study time, or reveal a useful compatibility insight. |
| **Failure by 4 or less** | Partial progress. You do not learn the technique yet, but you identify what is missing, what flaw must be corrected, or what next step is needed. |
| **Failure by 5 or more** | No usable learning yet. You may need a teacher, safer conditions, clearer translation, another source, or more practice before trying again. |
| **Natural 1 on risky study** | If the manual is forbidden, damaged, cursed, or route-incompatible, the campaign may introduce a deviation, burden, corruption mark, false interpretation, or backlash. |

Failure should move the story forward. It should show what went wrong and what your character can do next.

### Step 9: Record the Result

When learning succeeds, record the technique separately from your Sphere talents.

A learned Recorded Art should list:

- manual name;
- technique name;
- lineage source;
- Realm or CL requirement;
- associated Sphere expression;
- reproduced ability or talent package;
- whether it is active, passive, combat-facing, downtime-facing, breakthrough-facing, or training-facing;
- action type, cost, range, target, duration, trigger, saving throw, damage, recovery timing, or other rules if it has them;
- any printed Path, Method, Foundation, item, teacher, oath, scar, burden, drawback, or rare Sphere requirement.

Recorded Arts do not automatically grant Spheres and do not consume Sphere talent choices unless the manual explicitly says they do.

### Step 10: Continue the Manual

Learning the first technique is often the beginning of the manual's story.

Common next steps include:

- unlock the next Realm section;
- find a missing page;
- seek a teacher;
- repair a corrupted translation;
- test whether the writer's theory was true;
- separate a real technique from false commentary;
- change Method;
- prepare for a breakthrough;
- develop a Forged Technique;
- resolve a burden, hidden injury, deviation, or oath;
- decide whether to keep, copy, trade, hide, destroy, sell, or return the manual.

Manuals are campaign objects. They can stay important long after the first technique is learned.

## What to Record for a Manual

When your character gains a manual, record the following information.

| Field | Purpose |
|---|---|
| **Manual Name** | The specific art, book, form, scripture, journal, or teaching. |
| **Lineage Source** | Sect, clan, teacher, ruin, spirit, item, beast, journal writer, failure, or other origin. |
| **Access Type** | Taught, inherited, stolen, purchased, reconstructed, discovered, gifted, forced, copied, self-created, or traded. |
| **Associated Spheres** | Spheres used as theme, reproduced package, or printed prerequisite. These are not requirements unless written as requirements. |
| **Known Techniques** | The Recorded Arts currently learned. |
| **Locked Techniques** | Higher-Realm, missing-page, taboo, sealed, or unmastered techniques in the manual. |
| **Training Uses** | Spheres, talents, Methods, or study benefits the manual can serve as a source for. |
| **Requirements** | Printed Realm, Path, Method, item, teacher, oath, training, story requirement, or rare explicit Sphere requirement. |
| **Reliability** | Clean, uncertain, mixed, mistranslated, biased, partly false, corrupted, or deliberately deceptive. |
| **Obligations or Risks** | Oaths, taboos, rivals, side effects, social consequences, corruption, counters, or failure routes. |
| **Current Status** | Active study, mastered entry portion, incomplete, damaged, sealed, disputed, forbidden, secret, copied, sold, or archived. |

## Common Manual Requirements

A manual can require any of the following if its text says so:

- a Realm or CL;
- a Path;
- a Method;
- a Foundation theme;
- a teacher;
- a lineage source;
- an item, weapon, tool, mount, or spirit bond;
- a body condition, scar, hidden injury, deviation, or burden;
- a prior failure;
- a successful study period;
- a sect rank, oath, trial, or taboo;
- a campaign source such as a ruin, spirit, beast, jade tablet, inheritance mark, or scripture fragment;
- a rare explicit Sphere prerequisite.

Do not assume a Sphere requirement. Use one only when the manual is deliberately written as an extension of that Sphere and the technique explicitly says so.

Requirements should be specific enough to use at the table.

## Manuals, Methods, and Foundations

Manuals often interact with Methods and Foundations. Use the manual's text when it gives a rule. Otherwise, treat these connections as story and training guidance.

### Compatible Training

A manual may say it is compatible with certain Methods, Foundations, Paths, weapons, or Sphere themes. This means the training naturally fits those routes.

Example: a **White Crane Cloud Manual** might be compatible with Wind, Air, movement training, Body Refining, and poise-based Foundations.

Compatibility can help explain why the training suits a character. In difficult study, it may also justify advantage, reduced time, or a lower DC.

### Required Route

A manual may require a specific route.

Example: a **Cinder-Flesh Scripture** might require Body Refining, a furnace or ash-body Method, or a scar produced by fire. It would require the Ash Sphere only if the technique explicitly says **Prerequisite: Ash Sphere**.

### Corrective Route

A manual may exist to repair or redirect a problem.

Example: a **Clear Spring Pulse Manual** might help stabilize damaged meridians, reduce hidden-injury risk, or support a corrective breakthrough.

If the manual gives a mechanical benefit, use that benefit as written. If it only provides story support, it explains study, recovery, or route development without granting an automatic numerical bonus.

## Manuals and Breakthroughs

Studying a compatible manual can support breakthrough preparation if the breakthrough rules or the manual's own text allow it.

A manual might justify Enlightenment, a reroll source, a conditional bonus, a corrective attempt, or a new route after failure. The manual or breakthrough rule should state the exact benefit.

If the manual only provides story support, it counts as a source of training, explanation, or character direction. It does not automatically add a bonus to a breakthrough check.

## Manuals and Forged Techniques

A manual can teach a fixed forged technique or help a character develop a Forged Technique.

A fixed Recorded Art works as written, even if it reproduces a forged expression between multiple Spheres.

A Forged Technique created by the character follows the Forged Technique rules. A manual may provide one or more pieces needed to build it, such as concept, movement pattern, chant, diagram, cost model, Realm expression, or a Sphere pairing.

This distinction matters. A manual may let you use a preserved forged technique without giving you the freedom to redesign it.

## Incomplete Manuals

Many manuals found in the world are incomplete.

An incomplete manual might have:

- missing pages;
- damaged diagrams;
- sealed chapters;
- corrupted commentary;
- mistranslated terms;
- false later additions;
- a missing teacher key;
- a missing item focus;
- a higher-Realm section the character cannot yet understand.

Incomplete manuals are still useful. They can provide entry techniques now and lead to later study, repair, translation, teacher access, breakthrough clues, Method changes, or the discovery of another fragment.

## Secret and Forbidden Manuals

A **Secret Manual** is hidden, restricted, politically protected, or tied to a rare inheritance.

A **Forbidden Manual** teaches a route that the setting treats as corruptive, predatory, illegal, dangerous, or socially catastrophic.

Secret and Forbidden are not the same thing.

A Secret Manual can be orthodox but guarded. A Forbidden Manual can be widely feared but illegal to practice. A manual can be both Secret and Forbidden.

Forbidden manuals should be tempting because they offer something real. Their danger should come from consequences, incompatibility, corruption, social pressure, predatory cost, or route instability, not from being useless.

A buried journal that reveals a secret technique between two hidden Spheres can change everything for a character. It may also attract enemies, expose them to forbidden doctrine, or force them to decide whether power is worth the cost.

## Recorded Art Study During Play

A character may study a manual during downtime, travel, sect instruction, meditation, recovery, or breakthrough preparation.

Use **Learning a Recorded Art** whenever the manual does not give a more specific learning rule.

Common outcomes include:

- learning a Recorded Art;
- unlocking a higher-Realm section;
- qualifying for a Method change;
- repairing or redirecting a Foundation route;
- reducing a specific burden;
- gaining breakthrough preparation;
- creating or improving a Forged Technique;
- identifying a future teacher, place, item, or missing fragment;
- producing a copy to sell, trade, or teach.

The rule that grants the benefit should define the exact benefit. If no rule grants a numerical benefit, the manual provides story support, study progress, or a new opportunity instead.

## Player Summary

A Sphere is broad access. A Talent is a selectable Sphere option. A Method shapes how you cultivate. A Foundation is your deep cultivation architecture. A Manual preserves techniques, training sources, Methods, journals, and cultivation knowledge. A Lineage explains where that training came from and what obligations, reputation, and future lessons follow it.

Recorded Arts are recorded separately from Sphere talents. They do not require matching Sphere ownership by default, do not grant Spheres automatically, do not grant component talents as flexible options, and do not spend Sphere talent choices unless their own text says so.

Recorded Arts are fixed. You cannot modify them with your own talents or abilities unless a specific rule says you can.

Manuals are also training sources. If you already know a Sphere, you can usually train ordinary talents from that Sphere without a manual or teacher. If you are trying to learn a new Sphere, Secret talent, inherited technique, Method, or special lineage expression, a manual can be the source that makes that training possible.

Treat manuals as treasure. A jade slip, library shelf, hidden cave inheritance, cultivation journal, or self-written manual can change a character's power, status, enemies, and future.

---

# 16. Cultivation Resources, Rest, and Recovery

Cultivators do not only fight with weapons and spells. They fight with the strength of their body, the depth of their qi, the clarity of their spirit, and the reserves they have built through training.

This chapter explains the resources you spend, how you regain them, and how rest, cultivation, and downtime interact with training.

## Cultivation Resources

Each Path uses a named CP pool.

| Path | Main Resource |
|---|---|
| Body Refining | Stamina |
| Qi Cultivation | Qi |
| Spirit Awakening | Resonance |

When a rule says **CP**, use the pool of the Path powering that rule. A multi-Path character uses the Powering Path record from Chapter 03.

Many talents, Recorded Arts, Path features, Methods, Foundations, and items require CP.

## Maximum CP

Use the Path-specific formulas in Chapter 03 and the individual Path chapter.

| Path | Maximum CP |
|---|---|
| Body Refining | `CL x Constitution modifier` |
| Qi Cultivation | `CL x chosen Intelligence or Charisma modifier`, minimum `2 x CL` |
| Spirit Awakening | `CL x Wisdom modifier`, minimum `2 x CL` |

A CP pool cannot have a negative maximum. Body Refining has no additional minimum floor unless an explicit rule says otherwise.

A Method is the ordinary permanent source for modifying maximum CP. Another source changes maximum CP only when its own rule expressly says so.

## Spending CP

You spend CP when a rule tells you to do so. You cannot spend more points than the relevant pool currently contains.

If a rule permits spending "up to" a value, choose the amount as part of activation. A failed attack roll or successful saving throw does not refund the cost unless the Source Rule says otherwise.

A multi-Path character cannot split one cost between pools unless an explicit rule permits that conversion.

## Running Out of CP

If you have no remaining CP, you can still move, attack, speak, take actions, and use features that do not require CP.

When one of your CP pools is reduced from above 0 to exactly 0, gain 1 level of Exhaustion. If you later regain points in that pool and reduce it to 0 again, you can gain another level.

Different Path pools are tracked separately. Beginning a scene at 0 CP does not trigger additional Exhaustion by itself.

## Full Cultivation Sessions

A **Full Cultivation Session** is focused recovery through breathing, circulation, meditation, body refinement, spirit alignment, scripture recitation, stance practice, prayer, dream-trance, or another practice appropriate to the Path.

A Full Cultivation Session takes **2 uninterrupted hours**. You can receive full CP restoration from one Full Cultivation Session per Long Rest unless an explicit rule says otherwise.

A multi-Path cultivator can restore all active Path pools during one session if the session includes an appropriate practice for each Path.

A Full Cultivation Session can occur during an eligible meditative Long Rest if the environment is safe enough for every included practice.

## Short Rests

A Short Rest follows the normal rest rules. Apply each Path's recovery separately.

| Path | Short-Rest Recovery | Limit |
|---|---:|---|
| Body Refining | Half maximum Stamina, rounded down | Twice between Long Rests |
| Qi Cultivation | Qi equal to Qi Cultivation CL | Once per Long Rest |
| Spirit Awakening | Resonance equal to Spirit Awakening CL | Once per Long Rest |

A multi-Path character can recover every eligible pool during the same Short Rest. Each pool keeps its own limit.

## Long Rests

A Long Rest follows the normal rest rules. Apply each Path's recovery separately.

| Path | Long-Rest Recovery |
|---|---:|
| Body Refining | All missing Stamina |
| Qi Cultivation | Half maximum Qi, rounded down |
| Spirit Awakening | Half maximum Resonance, rounded down |

A Long Rest also refreshes each Path's Short-Rest recovery limit and the character's eligibility for full restoration from a Full Cultivation Session.

## Interrupted Rest or Cultivation

If your rest is interrupted, follow the normal rest rules.

If a cultivation session is interrupted before it is complete, you do not gain its benefit. You may begin again when you have another safe 2-hour window.

The GM decides whether an interruption is serious enough to break cultivation. A brief sound outside the door usually does not matter. A fight, ambush, forced movement, major injury, or broken concentration usually does.

## Safe Cultivation

Cultivation requires more than sitting still.

To complete a cultivation session, you need a place where your character can focus. The place does not need to be comfortable, but it must be stable enough for the kind of cultivation you are attempting.

A battlefield, collapsing ruin, haunted cave, storm-tossed cliff, or hostile sect prison may not allow safe cultivation unless a feature, item, Formation, or special condition makes it possible.

Unsafe cultivation does not always fail, but it may require a check or create a risk.

## Training Time

Learning Spheres, talents, and Recorded Arts takes training time.

The default training time for learning a talent, Sphere, or Recorded Art is:

**1d6 + Proficiency Bonus − your Intelligence or Wisdom modifier, minimum 2 days**

Roll once when the training begins. The result is the number of training days you must complete before making the training check.

Each training day requires **8 hours** of meaningful training.

The 8 hours do not need to be consecutive. You can split them across the day, or across multiple days if your schedule is broken. For example, a character might train for 3 hours before morning duties, 2 hours after a sect lesson, and 3 hours at night. Once those hours add up to 8, the character has completed one training day.

A trainer, teacher, special manual, Formation room, pill, spirit site, or other aid can reduce the time required if its rule says so.

## Intelligence and Wisdom in Training

Choose Intelligence or Wisdom based on the kind of training.

Use **Intelligence** for technical study, theory, formulas, written analysis, scripture comparison, formations, talismans, alchemy, life-preservation theory, blacksmithing, strategy, Qiweaving, and precise technique work.

Intelligence often applies to Spheres such as:

- Formations;
- Talismans;
- Alchemy;
- Blacksmith;
- Life when studied through medical theory;
- Warleader or strategy-based training;
- Qiweaving;
- precise Sword theory, pressure-point charts, or other technical combat study.

Use **Wisdom** for meditation, body feel, instinctive refinement, spiritual perception, Dao comprehension, survival practice, spirit contact, nature attunement, and embodied training.

Wisdom often applies to Spheres such as:

- Spirit Companions;
- Dreams;
- Flowing River;
- Athletics when trained through body feel and movement instinct;
- Verdant Growth or nature-based cultivation;
- Beastmastery, wilderness expressions, or beast-style training;
- spirit perception, omen-reading, or intuitive Dao study.

The same Sphere can sometimes use either ability depending on how you train it. A Sword disciple studying diagrams, angles, and scripture commentary might use Intelligence. A Sword disciple training through breath, stance, killing intent, and repeated cuts might use Wisdom.

The GM decides which ability fits the training method.

## Training During Downtime

Training usually happens during downtime, sect study time, travel rests, recovery periods, or quiet intervals between missions.

A training day requires 8 total hours of focused work. The hours do not need to be consecutive, but they must be serious enough to count.

Training can include:

- studying a manual;
- practicing forms;
- sparring;
- meditating;
- refining circulation;
- testing a technique;
- analyzing a jade slip;
- receiving instruction;
- reviewing a cultivation journal;
- correcting mistakes from failed practice.

If the day is consumed by combat, dangerous travel, sect duty, punishment, injury, Exhaustion, or interruption, it may not provide enough time to count as a training day.

A teacher, trainer, senior disciple, Formation room, or other special aid can shorten the required time if its rule says so.

## Training While Adventuring

You can sometimes train while adventuring.

Travel drills, nightly meditation, sparring during camp, reading a jade slip during watch, or practicing footwork on the road can all count if the situation allows it.

However, dangerous travel, Exhaustion, pursuit, severe weather, unstable qi, or repeated combat can prevent training progress.

The GM decides whether a period of activity counts as training based on what actually happened.

## Training Checks

At the end of the required training time, make the required check.

Different things use different DCs.

### Training a Talent from a Known Sphere

If you train a talent from a Sphere you already know, the default DC is:

**DC 10 + the number of talents you already know from that Sphere**

You usually do not need an outside teacher or manual to train a normal talent from a Sphere you know. You are deepening your own connection to that Sphere's Dao-expression.

A teacher, manual, spirit site, rival demonstration, or other aid can still help.

Secret, inherited, lineage, forbidden, or special talents may require a specific source.

### Learning a New Sphere

If you train to learn a new Sphere, the default DC is:

**DC 10 + 1d4 + the number of different Spheres you know**

You need a suitable source of instruction or inspiration to learn a new Sphere. This might be a manual, teacher, jade slip, sect lesson, battlefield demonstration, inheritance, spirit guide, spirit site, or similar source.

When you successfully learn a new Sphere, you gain that Sphere's base ability and one bonus talent from that Sphere.

### Learning a Recorded Art

A Recorded Art is a fixed technique learned from a manual, jade slip, scripture, journal, mural, inheritance, or similar source.

The DC to learn a Recorded Art is:

**DC 10 + the Recorded Art's difficulty + 2 × the number of Recorded Arts you have already learned at your current CL**

This count resets when you gain a new CL.

For example, if a Recorded Art has difficulty 2, the first Recorded Art you learn at that CL is DC 12. The second is DC 14. The third is DC 16. The fourth is DC 18.

If a Recorded Art has difficulty 3, the first Recorded Art you learn at that CL is DC 13. The second is DC 15. The third is DC 17.

## Failed Training

If you fail a training check, you do not learn the Sphere, talent, or Recorded Art yet.

You may try again after spending half the original training time.

## Training Aids

A **training aid** is anything that helps you study, understand, refine, or express a Sphere, talent, or Recorded Art.

Training aids can include:

- a manual;
- a jade slip;
- a teacher;
- a senior disciple;
- a cultivation journal;
- a sect lecture;
- a sparring partner;
- a spirit site;
- a spirit stone;
- a pill;
- a beast core;
- a Formation room;
- a battlefield demonstration;
- an inherited memory;
- an enemy technique you survived.

A training aid might reduce training time, grant Advantage, lower the DC, allow a reroll, provide the required source for a Secret technique, or make training possible at all.

The aid explains what it does. If it does not, the GM decides what benefit makes sense.

## Pills, Spirit Stones, and Recovery Aids

Cultivators often use pills, spirit stones, medicinal baths, qi-rich food, incense, pressure-point treatment, spirit offerings, or special environments to recover.

These aids can restore CP, speed healing, support training, or help with specific cultivation problems.

A recovery aid only does what its description says.

For example, a pill might restore Qi, remove fatigue, shorten a training period, or help with a breakthrough. A spirit stone might provide energy for cultivation. A medicinal bath might help a Body Refiner recover from strain. A spirit offering might help a Spirit Awakener stabilize Resonance.

Powerful aids can also have risks. Impure pills, unstable qi, demonic cores, corrupted sites, and forced refinement can create injuries, deviations, burdens, or other complications.

## Spirit Sites and Qi-Rich Places

Some places are especially useful for cultivation. These are usually handled as **spirit sites**, qi-rich places, sect facilities, inheritance grounds, dangerous ruins, or special training locations.

Examples include mountain peaks, spirit springs, ancient forests, dragon veins, sword cliffs, thunder valleys, shrine grounds, old battlefields, volcanic vents, moonlit lakes, and buried Formation chambers.

A spirit site might help with recovery, training, breakthroughs, Foundation refinement, Method study, or Recorded Art practice, but only if the site, adventure, item, feature, or GM gives it a concrete benefit. A place can also be dangerous, restricted, unstable, polluted, guarded, or suited only to certain kinds of cultivation.

Not every site helps every cultivator. A sword cliff might help Sword techniques. A moonlit lake might help Yin, Water, Dreams, or Spirit Companions cultivation. A volcanic vent might help Fire, Blacksmith, Body Refining, or Alchemy.

Mismatched qi does not normally turn off your abilities. It may simply be less helpful, harder to refine, or dangerous if forced. Known powers keep working unless a specific rule, hazard, formation, item, or scene says the location suppresses or blocks them.

## Studying in a Sect

A sect is one of the best places to train because it provides structure.

A sect may offer:

- libraries;
- scripture halls;
- teachers;
- sparring yards;
- Formation rooms;
- pill halls;
- mission rewards;
- senior disciple lectures;
- lineage trials;
- restricted manuals;
- public competitions;
- private instruction.

This does not mean everything is free.

Disciples may need sect tokens, rank, trust, mission credit, teacher approval, tournament placement, family support, or personal connections to access better resources.

A sect can make fast growth possible, but it also creates pressure. Missions, rival disciples, resource theft, competitions, punishments, politics, and deadlines can all reduce the time available for training.

## Resource Pressure and Training Choices

A character can theoretically learn many things during a CL.

They might gain a level talent, train up to three additional choices, learn new Spheres, gain bonus talents from those Spheres, and study Recorded Arts from manuals.

In practice, this requires time, access, successful checks, and enough safety to train.

This is intentional. Cultivation rewards ambition, preparation, and opportunity. A disciple who finds a powerful manual, earns library access, survives missions, and protects their resources can become far stronger than a disciple who only follows the minimum path.

## Recovery from Cultivation Complications

Some injuries, deviations, burdens, scars, spiritual disturbances, or other cultivation complications require special recovery.

Ordinary rest may not be enough.

A condition might require:

- a cultivation session;
- a healer;
- a pill;
- a spirit doctor;
- a Foundation repair project;
- a Method correction;
- a breakthrough;
- a spirit site;
- a confession, offering, or oath;
- a specific training exercise;
- a special quest.

The condition explains how it can be treated. If it does not, the GM sets the requirements based on the cause and severity.

## Quick Checklist

Use this checklist when your character rests or trains.

1. Track your current CP.
2. Use short rests, long rests, and cultivation sessions to recover.
3. If you are reduced to 0 CP, gain 1 level of Exhaustion.
4. Spend downtime to train Spheres, talents, and Recorded Arts.
5. Count training in 8-hour training days, which can be split across time.
6. Use the correct DC for what you are learning.
7. Track failed training and retry time.
8. Track pills, spirit stones, manuals, journals, teachers, and sites that help your cultivation.
9. Remember that time is a resource. Sect missions, rivals, tournaments, injuries, and travel can all interrupt training.

---

# 17. Breakthroughs and Attainment

Cultivation is not ordinary leveling.

A cultivator does not simply gain enough experience and become stronger. They gather pressure, insight, resources, scars, victories, failures, and understanding. Then they attempt a breakthrough.

A **breakthrough** is the moment when your cultivation reaches a new Cultivation Level. Some breakthroughs are steady steps within the same Realm. Others are Realm breakthroughs, where your body, qi, spirit, Foundation, and future path can change completely.

## Attainment Points

**Attainment Points**, or **AP**, measure your cultivation progress.

AP represents more than battle experience. It can come from training, meditation, combat, study, surviving danger, comprehending manuals, refining pills, overcoming rivals, enduring hardship, and understanding the Dao.

When you gain enough AP for your current CL, you can attempt a breakthrough to the next CL.

## Gaining AP

The GM awards AP when your character makes meaningful cultivation progress.

AP usually comes from events that challenge, sharpen, deepen, or transform your cultivation. Ordinary practice matters, but major gains often come from pressure, insight, danger, and discovery.

| Activity | Suggested AP |
|---|---:|
| Defeat a meaningful rival within 2 CL of you | `150 × rival's CL` |
| Overcome a meaningful combat encounter | `50 × average party CL` |
| Spare a meaningful rival when doing so matters | `25 × rival's CL`, once per day |
| Survive a dangerous formation, trap, spiritual trial, or cultivation hazard | `50–300 AP` |
| Complete daily cultivation meditation | GM determines, usually modest |
| Consume a cultivation pill | Based on pill rarity |
| Comprehend a rare technique, relic, natural wonder, omen, or Dao trace | `50–300 AP` |
| Survive a Heavenly Tribulation | GM determines |
| Reach the halfway point in a jade-tablet manual, art collection, or inheritance record | `5d100 AP` |
| Complete a jade-tablet manual, art collection, or inheritance record | `10d100 AP` |
| Major character achievement | GM determines |

A jade tablet, ancient manual, or inheritance record may contain many Recorded Arts, theories, Method fragments, warnings, false leads, and hidden insights. "Halfway point" means the character has made real progress through that larger body of cultivation knowledge, not merely read one line or learned one technique.

## Cultivation Pills and AP

Some pills grant AP directly.

| Pill Rarity | Suggested AP |
|---|---:|
| Common | `50 AP` |
| Uncommon | `150 AP` |
| Rare | `400 AP` |
| Very Rare | `1,000 AP` |

A pill only grants AP if its description says it does or the GM rules that it is a true cultivation pill. Ordinary medicine, food, alcohol, or battlefield stimulants do not grant AP unless their rules say so.

Impure or incompatible pills can carry risks. A pill that grants power too quickly might create strain, impurities, injuries, deviations, or later breakthrough problems.

## AP Required by Cultivation Level

Each CL requires a certain amount of AP before you can attempt the breakthrough to the next CL.

| Current CL | AP Required for Next CL |
|---:|---:|
| 1 | 300 |
| 2 | 600 |
| 3 | 1,800 |
| 4 | 3,800 |
| 5 | 7,500 |
| 6 | 9,000 |
| 7 | 11,000 |
| 8 | 14,000 |
| 9 | 16,000 |
| 10 | 18,000 |
| 11 | 20,000 |
| 12 | 20,000 |
| 13 | 25,000 |
| 14 | 30,000 |
| 15 | 35,000 |
| 16 | 35,000 |
| 17 | 40,000 |
| 18 | 45,000 |
| 19 | 50,000 |
| 20 | Maximum standard CL |

When you have enough AP, you are ready to attempt the breakthrough. You do not gain the next CL until the breakthrough succeeds.


### Multi-Path AP Multipliers

A multi-Path cultivator multiplies the AP required for the next CL. AP awards are not multiplied.

| Path Combination | Multiplier |
|---|---:|
| One orthodox Path | x1 |
| Two orthodox Paths | x3 |
| Chakra plus one orthodox Path | x4 |
| All three orthodox Paths | x5 |

Use the Path combination the character will possess after the breakthrough. A character adding a Path must declare that choice before the breakthrough and meet the resulting AP requirement.

If the breakthrough fails, calculate the halfway setback using the multiplied AP requirement.

## What a Breakthrough Is

A **breakthrough** is a cultivation attempt to reach the next CL.

During a breakthrough, your character gathers their power, circulates their Path resource, stabilizes their Foundation, applies their Method, and pushes their cultivation into a new state.

A breakthrough might look different for each Path.

A Body Refiner might temper bone, blood, organs, meridians, or flesh under extreme pressure.

A Qi Cultivator might circulate qi through scripture routes, compress a core, refine a meridian cycle, or align with a Dao pattern.

A Spirit Awakener might deepen a bond, withstand a vision, stabilize Resonance, negotiate with a spirit, face a memory, or cross a dream threshold.

The rules are the same unless a feature says otherwise.

## Cultivation Checks

A breakthrough uses a **Cultivation Check**.

Your Cultivation Check is:

**d20 + your Path key ability modifier + your Proficiency Bonus**

| Path | Key Ability |
|---|---|
| Body Refining | Constitution |
| Qi Cultivation | Intelligence or Charisma |
| Spirit Awakening | Wisdom |

If a Method, Foundation, Insight, Enlightenment die, pill, spirit site, injury, deviation, burden, or other rule modifies your breakthrough, apply that modifier to the check.

## Same-Realm Breakthroughs

Most breakthroughs are **same-Realm breakthroughs**.

A same-Realm breakthrough increases your CL while remaining inside your current Realm.

The DC for a same-Realm breakthrough is:

**DC = 10 + the new CL**

For example, advancing from CL 2 to CL 3 is a DC 13 breakthrough.

## Realm Breakthroughs

A **Realm breakthrough** occurs when you enter a new Realm.

Realm breakthroughs happen at:

| New CL | Realm Breakthrough |
|---:|---|
| 5 | Foundation |
| 10 | Core Formation |
| 15 | Nascent Soul |
| 20 | True Immortality or final standard Realm |

The DC for a Realm breakthrough is:

**DC = 10 + twice the new CL**

| New CL | Breakthrough Type | DC |
|---:|---|---:|
| 5 | Realm breakthrough | 20 |
| 10 | Realm breakthrough | 30 |
| 15 | Realm breakthrough | 40 |
| 20 | Realm breakthrough | 50 |

Realm breakthroughs are major events. They may draw omens, spiritual pressure, rivals, sect attention, natural disasters, inner demons, or Heavenly Tribulation.

At higher Realms, especially around Nascent Soul and beyond, later campaign rules may introduce **Dao Aspects** and **Immortal Arts**. These are late-game extensions of Dao mastery and are not part of ordinary early cultivation.

## Preparing for a Breakthrough

Preparation matters because it can give you real help on the breakthrough check or protect you from a worse outcome.

You do not need to write down every prayer, training montage, conversation, or night of meditation. Those things are part of the story. Only record preparation when it gives a specific mechanical benefit.

Breakthrough preparation might grant:

- a flat bonus to the breakthrough check;
- an Enlightenment die;
- a reroll;
- Advantage from a specific rule;
- removal or reduction of a penalty;
- protection from a failure consequence;
- permission to attempt a special breakthrough;
- aid during a Realm tribulation.

If a preparation source gives one of these benefits, record it.

Examples include:

- a pill that grants `+2` to a breakthrough check;
- a spirit site that grants a `1d6` Enlightenment die;
- a teacher who grants one breakthrough reroll after special instruction;
- a Formation chamber that grants Advantage during breakthrough meditation;
- a Method correction that removes a penalty from an incompatible breakthrough;
- a cultivation journal that reveals a safer breakthrough route;
- a failure-born Insight that applies to the next breakthrough.

Preparation does not give a bonus just because it sounds impressive. The source must have a rule, reward, feature, or GM-approved benefit attached to it.

You can still describe ordinary preparation freely. It helps the scene feel like cultivation, but the only preparation that must be tracked is preparation with a mechanical effect.

## Common Preparation Benefits

When preparation matters mechanically, it usually falls into one of these forms.

| Benefit | What It Does |
|---|---|
| Flat Bonus | Adds a fixed number to the breakthrough check, such as `+1`, `+2`, or `+PB`. |
| Enlightenment Die | Adds a die, such as `1d4`, `1d6`, `1d8`, or `1d10`, to the breakthrough check. |
| Reroll | Lets you reroll the breakthrough check or part of it. |
| Advantage | Lets you roll the breakthrough check with Advantage, but only if a rule specifically grants it. |
| Penalty Removal | Removes or reduces a penalty from injury, deviation, Method mismatch, bad conditions, or instability. |
| Failure Protection | Reduces the harm caused by a failed breakthrough. |
| Special Permission | Allows a special breakthrough, rare Foundation route, Method correction, or unusual Realm entry. |
| Tribulation Aid | Makes a tribulation safer, clearer, weaker, or more rewarding. |

If two preparation sources give different benefits and both apply, they can both matter. If two sources give the same kind of benefit, use the rule printed on those sources to determine whether they stack.

## Preparation and the Story

Players are encouraged to describe how their characters prepare.

A Body Refiner might train under a waterfall, drink marrow-strengthening medicine, or spar until their bones ring.

A Qi Cultivator might meditate over scripture, refine a pill, study a jade slip, or circulate qi in a Formation chamber.

A Spirit Awakener might bargain with a spirit, confront a dream, calm a ghost, or follow an omen.

These details matter to the fiction. They can also become mechanical preparation if the GM gives them a concrete benefit, such as a bonus, an Enlightenment die, a reroll, penalty removal, failure protection, special permission, or tribulation aid.

## Breakthrough Meditation

A character may prepare for a breakthrough with focused meditation, circulation, stance work, prayer, spirit alignment, scripture recitation, or another practice appropriate to their Path.

The basic breakthrough meditation period is **10 hours**.

This time must be calm enough for deep cultivation. It can occur in a sect chamber, cave, private room, spirit site, formation hall, wilderness shrine, or other suitable place.

Completing this breakthrough meditation grants Advantage on the breakthrough check unless a rule says otherwise.

This is separate from other preparation. Other preparation sources do not automatically grant Advantage unless their own rules say they do.

A dangerous or unstable location might require a check, create a risk, or prevent the meditation from counting.

Some Methods, Foundations, teachers, pills, formations, or sites can shorten, improve, or replace this preparation.

## Enlightenment Dice

Some events grant an **Enlightenment die**.

An Enlightenment die represents real insight into the Dao. It is used for breakthroughs.

| Enlightenment Rating | Die |
|---|---:|
| Minor | `1d4` |
| Notable | `1d6` |
| Major | `1d8` |
| Mythic | `1d10` |

When you make a breakthrough check, you may roll any Enlightenment dice you have earned and add them to the result, unless a specific rule says otherwise.

Enlightenment is part of the character. It does not expire and is not spent when used unless the rule that granted it specifically says it is temporary, unstable, consumed, or otherwise limited.

A character may accumulate multiple Enlightenment dice over a campaign. This is expected. Higher-Realm breakthroughs are difficult, and deep cultivation often depends on the Enlightenment a character has gathered through victories, failures, manuals, tribulations, scars, teachers, and moments of real Dao comprehension.

## Enlightenment Records

When you gain an Enlightenment die or similar breakthrough insight, record it.

An **Enlightenment Record** should include:

- the source of the insight;
- the rating, such as Minor, Notable, Major, or Mythic;
- the die, such as `1d4`, `1d6`, `1d8`, or `1d10`;
- any special limit, cost, risk, or condition printed by the source.

Example:

**Scarlet Furnace Lesson.** Major Enlightenment, `1d8`. Gained after surviving a failed breakthrough and stabilizing the meridian burn. This Enlightenment remains part of the character and can be used on future breakthrough checks unless a later rule specifically changes it.

## Multiple Enlightenment Sources

You can benefit from more than one Enlightenment die on the same breakthrough if each die comes from a separate earned Enlightenment Record and no rule says otherwise.

Repeated versions of the same lesson do not automatically create new Enlightenment dice. If a new event grants another die, record it separately.

Enlightenment dice are not restricted to the Sphere, weapon, style, or situation that created them unless their own rule says so. The Dao is connected. A lesson learned through a sword duel, failed tribulation, healing scar, dream vision, or cultivation journal can still help a later breakthrough.

## Breakthrough Rerolls

Some rules grant a reroll on a breakthrough check.

Unless the rule says otherwise, you can use only one breakthrough reroll on the same breakthrough attempt.

A reroll must be used immediately after seeing the result, before the GM describes the final outcome.

## Success

On a successful breakthrough, you gain the new CL.

When your CL increases:

1. record the new CL;
2. update your Proficiency Bonus if it changes;
3. update hit points and Hit Dice according to your Path;
4. update your maximum CP;
5. apply new Path features;
6. gain your level talent if applicable;
7. check whether any higher-Realm requirements are now met;
8. record any breakthrough events, omens, scars, insights, or boons.

If the breakthrough was a Realm breakthrough, also record the new Realm.

## Failed Breakthrough

If you fail a breakthrough, you do not gain the new CL.

You lose half your AP progress for your current CL.

Set your AP to the halfway point between your current CL and the CL you were trying to reach.

For example, if you are CL 9 and have enough AP to attempt the breakthrough to CL 10, a failed breakthrough drops you to halfway through CL 9. You do not return to the beginning of CL 9, but you must regain the lost AP before you can attempt the CL 10 breakthrough again.

If CL 9 requires 16,000 AP to attempt CL 10, a failed breakthrough leaves you with 8,000 AP toward CL 10.

Any injury, deviation, burden, scar, omen, Failure Enlightenment, or failure-born option from the failed breakthrough is recorded separately.

## Retrying a Breakthrough

You can attempt the breakthrough again after you regain the lost AP.

You do not need to begin the entire CL again. You already reached that height once. The failed attempt knocked your cultivation back, damaged your confidence, destabilized your route, or exposed a flaw that must be repaired through new attainment.

The second attempt uses the normal DC unless a rule changes it.

## Failure Is Not Nothing

A failed breakthrough is not just lost AP.

Failure can reveal weaknesses, create future opportunities, or leave marks that matter later.

A failed breakthrough might create:

- a hidden injury;
- a qi deviation;
- a burden;
- a scar;
- an omen;
- a spirit disturbance;
- Foundation strain;
- Method instability;
- a rival's opportunity;
- a Failure Enlightenment;
- a failure-born option.

The failed breakthrough does not automatically grant a benefit. A benefit appears only when a rule, feature, Insight, Method, Foundation, injury, deviation, or GM reward says it does.

The GM may use the margin of failure to decide whether the failed breakthrough is clean, strained, damaging, or catastrophic.

## Failure Enlightenment

A **Failure Enlightenment** is insight gained from failing.

It does not mean the failure was good. It means the cultivator understood something real through pain, loss, instability, humiliation, backlash, or survival.

Failure Enlightenment can appear as:

- an Enlightenment die;
- permission to choose a failure-born Insight;
- a clue toward repairing an injury or deviation;
- a bonus on a later breakthrough;
- a new training direction;
- a requirement for a harsh or corrective Method;
- a route toward an unusual Foundation transformation.

Failure Enlightenment should be specific. "I failed once" is not enough. The character should know what kind of lesson the failure left behind.

## Heavenly Tribulation

A **Heavenly Tribulation** is a major test imposed by Heaven, fate, karma, nature, the Dao, the character's own cultivation, or the consequences of the path they have walked.

Tribulations most often appear during Realm breakthroughs.

A Realm breakthrough check opens the gate to the next Realm. A tribulation tests whether that gate can be crossed, stabilized, witnessed, and survived.

At minimum, every Realm breakthrough draws pressure from Heaven. That pressure might appear as omens, unstable qi, visions, thunderheads, spirit agitation, bloodline backlash, demonic temptation, dream collapse, or sudden danger.

The GM decides whether that pressure becomes a full encounter-scale tribulation.

## Cultivation Weight and Tribulation

The chance and severity of Heavenly Tribulation depends partly on the weight of the character's cultivation.

A modest cultivator with little extra training might face only omens, pressure, a dream, or a minor backlash during a Realm breakthrough.

A heavily trained cultivator with many Spheres, many talents, powerful Recorded Arts, a rare Method, Secret or Forbidden power, a dense Foundation, or unusually broad cultivation may draw a much stronger tribulation.

This is not punishment for being strong. It is recognition. Heaven reacts to cultivators whose power is heavy, strange, ambitious, or difficult for their Realm to contain.

The detailed tribulation weight rules are handled by the GM.

## Unsettled Ascension

Some campaigns use **Unsettled Ascension** for Realm breakthroughs.

In this structure, a successful Realm breakthrough check opens the gate to the next Realm, but the new Realm is not fully settled until the tribulation or Heavenly pressure is resolved.

During Unsettled Ascension, the character may show signs of the new Realm, but their cultivation is unstable. The GM explains what benefits, risks, and limits apply.

When the tribulation is resolved, the Realm settles fully. The character then records the final breakthrough results.

If your table does not use Unsettled Ascension, a successful Realm breakthrough grants the new Realm immediately.

## Common Tribulations by Path

| Path | Common Tribulations |
|---|---|
| Body Refining | body-shattering lightning, bloodline backlash, avalanches, crushing force, bone tempering, organ strain, physical ordeals |
| Qi Cultivation | elemental overload, meridian fire, uncontrolled storms, tribulation lightning, qi collapse, core instability, scripture backlash |
| Spirit Awakening | inner demons, false memories, karmic visions, dream prisons, soul fragmentation, spirit rejection, ancestral judgment |

A tribulation can be a combat encounter, skill challenge, spiritual trial, scene of survival, social reckoning, or internal test.

A tribulation should match the character's Path, Foundation, Method, Spheres, prior choices, and unresolved problems.

## Surviving Tribulation

Surviving a tribulation can grant AP, Enlightenment, a boon, a scar, a reputation change, or a future story hook.

A tribulation can also cause injuries, deviations, burdens, lost resources, damaged equipment, broken relationships, or sect attention.

The stronger the tribulation, the more meaningful the result should be.

## Emergency Forged Techniques and Enlightenment

An **Emergency Forged Technique** is a one-time technique created under pressure by combining legal Sphere expressions, Path features, or other cultivation expressions the character can currently access.

Emergency Forged Techniques are governed by the Forged Techniques rules. They are not learned techniques when first used. If the attempt succeeds, the technique works once and creates an Emergency Technique Seed that can be studied later.

If an Emergency Forged Technique succeeds, becomes decisive in a dangerous scene, and reveals something true about the character's Path, Method, Foundation, Spheres, Dao, body, qi, spirit, vow, or future Realm, it can create an Enlightenment Record.

The GM assigns the Enlightenment rating based on the danger, originality, and impact of the moment.

| Moment | Suggested Enlightenment |
|---|---|
| Useful but narrow success | Minor, `1d4` |
| Decisive moment in a serious fight | Notable, `1d6` |
| Victory or survival turns on the technique | Major, `1d8` |
| Mythic, Realm-defining, or fate-changing technique | Mythic, `1d10` |

Emergency Forging Enlightenment does not grant Advantage on the breakthrough check. It grants an Enlightenment die, which remains part of the character unless a specific rule says otherwise.

See **Forged Techniques and Emergency Forging** for the full rules on creating, using, recording, and later studying Emergency Technique Seeds.

## Methods and Breakthroughs

A cultivation Method can change how your breakthroughs work.

A Method might modify your maximum CP, give a bonus to compatible breakthroughs, penalize incompatible breakthroughs, change how failure affects you, or help repair a flaw.

Use the Method's printed rule.

Only your Primary Method applies unless another rule says otherwise.

## Foundations and Breakthroughs

A Foundation can shape your breakthroughs.

A Foundation might make certain breakthroughs easier, make others dangerous, change the kind of preparation you need, or create special consequences from failure.

Use the Foundation's printed rule.

If a Foundation says it interacts with a breakthrough, record that interaction when you attempt the breakthrough.

## Recorded Arts, Manuals, and Breakthroughs

Studying a manual, jade slip, cultivation journal, or Recorded Art can help with a breakthrough if it gives a printed or GM-approved benefit.

A manual might provide an Enlightenment die, reveal a Method correction, explain a hidden injury, teach a route through a Realm bottleneck, or provide the source needed for a special breakthrough.

A Recorded Art does not automatically help every breakthrough. It helps when the fixed technique, Sphere expression, or theory inside it grants a concrete breakthrough benefit.

## Breakthrough Records

Always record important breakthrough events.

A useful breakthrough record includes:

- current CL;
- new CL attempted;
- AP before the attempt;
- breakthrough DC;
- roll result;
- preparation used;
- Enlightenment dice used;
- rerolls used;
- Method or Foundation modifiers;
- success or failure;
- AP after failure, if any;
- injuries, deviations, burdens, scars, omens, or boons;
- Failure Enlightenment or failure-born options.

These records matter because later rules may refer to old breakthroughs, failed breakthroughs, scars, injuries, deviations, or insights.

## Breakthrough Checklist

When you attempt a breakthrough, use this checklist.

1. Confirm you have enough AP.
2. Identify whether this is a same-Realm breakthrough or Realm breakthrough.
3. Set the DC.
4. Complete any required preparation.
5. Apply Method, Foundation, Insight, pill, site, or injury modifiers.
6. Roll a Cultivation Check.
7. Apply Enlightenment dice or rerolls.
8. On success, gain the new CL or enter Unsettled Ascension if the table uses that rule.
9. On failure, drop to halfway through your current CL's AP progress.
10. Record the result.

---

# 18. Forged Techniques and Emergency Forging

Cultivators do not only repeat what their teachers handed down.

As their understanding deepens, they begin combining principles, refining movements, and creating arts that express their own Dao. A Sword cultivator might teach a cut to carry the weight of a mountain. A Dream cultivator might step through a shadow that exists only in memory. A Body Refiner might compress force, bone, and radiance into a single palm strike.

These personal arts are called **Forged Techniques**.

A Forged Technique is not a normal Sphere talent and not a Recorded Art. It is a custom technique built from cultivation the character already knows.

## Technique Forging Access

Technique Forging normally becomes available at **Foundation Realm**, CL 5.

At Foundation Realm, a cultivator's body, meridians, qi, or spirit have become stable enough to support a personal art.

Mortal-Realm forging is possible only as an exceptional reward. A reincarnated master, bloodline heir, once-in-a-generation prodigy, or cultivator who survives an extraordinary revelation might receive GM permission to forge a Mortal-level technique.

A Mortal-level Forged Technique should usually:

- use only one Sphere or cultivation expression;
- have Complexity 1 or 2;
- represent a defining character moment;
- require an unusual teacher, rare manual, supernatural event, or major narrative opportunity.

Mortal Technique Forging is not a normal character option.

## What a Forged Technique Is

A **Forged Technique** is a custom ability created by combining elements from Spheres and talents the character already knows.

A Forged Technique personalizes existing cultivation. It does not bypass prerequisites, grant Spheres, grant talents, ignore Realm requirements, or invent unlimited effects.

A Forged Technique normally has:

- a unique name;
- a Base Form;
- a Primary Sphere Effect;
- optional Secondary Sphere Effects;
- optional Augments;
- optional Drawbacks;
- calculated Complexity;
- calculated CP cost;
- a Technique-Forging DC.

## Forged Techniques and Recorded Arts

A Forged Technique is created by the character.

A **Recorded Art** is a fixed technique learned from a manual, jade slip, scripture, mural, inheritance record, cultivation journal, or similar source.

This distinction matters.

A manual might preserve a forged art created by an ancient master. If you learn it from the manual, it is a Recorded Art for you unless the manual specifically says you learn it as your own Forged Technique.

Recorded Arts do not count against your maximum number of known Forged Techniques unless a rule says otherwise.

## Realm Complexity Limits

A technique's **Complexity** measures how much it is trying to do.

Your Realm limits how complex your Forged Techniques can be.

| Realm | CL Range | Maximum Complexity | Typical Result |
|---|---:|---:|---|
| Mortal Realm (exceptional) | 1–4 | 2 | Rare refined basic technique |
| Foundation | 5–9 | 4 | Signature move with one meaningful rider |
| Core Formation | 10–14 | 6 | Composite art combining multiple principles |
| Nascent Soul | 15–19 | 8 | Battlefield-shaping or partially conceptual technique |
| True Immortality / final standard Realm | 20 | 10 | Mythic Dao art capable of changing an encounter |

Complexity limits what can be created. CP cost determines how often the technique can be used.

A Drawback can reduce CP cost, but it never reduces Complexity.

## Base Forms

Choose a Base Form for the technique.

| Base Form | Starting CP | Complexity | Use |
|---|---:|---:|---|
| Strike | 1 | 1 | Weapon or unarmed delivery |
| Projection | 1 | 1 | Beam, bolt, slash, psychic attack, elemental blast, or similar projection |
| Movement | 1 | 1 | Leap, teleport, dash, brief flight, or repositioning |
| Burst | 2 | 2 | Area centered on yourself or a visible point |
| Cone | 2 | 2 | Cone from yourself |
| Line | 2 | 2 | Straight line |
| Ward | 2 | 2 | Defensive effect on yourself or an ally |
| Aura | 3 | 3 | Persistent self-centered effect |
| Zone | 3 | 3 | Persistent battlefield area |
| Counter | 3 | 3 | Reaction against a trigger |
| Ritual | Varies | 1 | Slow, powerful noncombat or preparation effect |

The Base Form gives the technique its basic shape. The Sphere effects and Augments determine what it actually does.

## Primary and Secondary Sphere Effects

Choose one effect from a Sphere base ability or talent the character knows. This is the **Primary Sphere Effect**.

You may add Secondary Sphere Effects if the technique combines more than one Sphere or principle.

Each additional Sphere used as a Secondary Sphere Effect adds **+1 Complexity** and may increase CP cost depending on the strength of the added effect.

Recommended maximum Spheres:

| Realm | Recommended Maximum Spheres |
|---|---:|
| Foundation | 2 |
| Core Formation | 3 |
| Nascent Soul | 4 |
| True Immortality / later immortal play | GM discretion |

The character must normally know the talent that provides each major effect.

The GM may allow a rare scripture, teacher, inheritance, supernatural revelation, or Emergency Technique Seed to substitute for a missing piece, but this is an exception.

## Augments

An **Augment** improves or expands the technique.

Basic Augments usually add **+1 Complexity** and **+1 CP**.

Common Basic Augments include:

- Increased Damage;
- Extended Range;
- Expanded Area;
- Additional Target;
- Forced Movement;
- Minor Hindrance;
- Lingering Effect;
- Mobility Rider.

Advanced Augments are stronger and often require a higher Realm.

| Augment | Minimum Realm | Complexity | Additional CP |
|---|---|---:|---:|
| Major Condition | Foundation | +2 | +2 |
| Persistent Zone | Foundation | +2 | +2 |
| Ignore Resistance | Core Formation | +2 | +2 |
| Reaction Activation | Core Formation | +2 | +2 |
| Bonus-Action Activation | Core Formation | +2 | +3 |
| Severe Hindrance | Core Formation | +2 | +2 |
| Domain Effect | Nascent Soul | +3 | +3 |
| Conceptual Effect | Nascent Soul | +3 | +4 |

Hostile conditions require saving throws against your Cultivation Save DC.

Conditions that last longer than one round normally allow repeat saves at the end of the affected creature's turns.

## Drawbacks

A **Drawback** reduces the technique's activation cost by adding a real limitation.

Drawbacks reduce CP cost, not Complexity.

A technique's CP cost cannot be reduced below 1 CP.

The maximum CP reduction from Drawbacks equals your Proficiency Bonus.

| Drawback | CP Reduction |
|---|---:|
| Concentration | −1 |
| Preparation | −1 |
| Long Invocation | −1 |
| Self-Damage | −1 |
| Restricted Environment | −1 |
| Material Focus | −1 |
| Once per Short Rest | −1 |
| Once per Long Rest | −2 |
| Exhausting | −2 |
| Backlash | −1 |

Reject Drawbacks that do not meaningfully restrict the technique.

### Backlash Drawback

**Backlash** is not automatically Exhaustion.

When you choose Backlash as a Drawback, define the trigger and consequence when the technique is created. The trigger and consequence must be concrete enough that the table can apply them without renegotiating the technique each time.

The default trigger is one of the following:

- you fail the technique's attack roll or check by 5 or more;
- a target succeeds on its saving throw by 5 or more;
- the technique is countered, interrupted, or disrupted;
- the technique is used in an unstable condition named when the technique is created.

A normal Backlash Drawback should usually cause one of the following:

- lose 1 CP after the technique resolves;
- take damage equal to the technique's Complexity + your Proficiency Bonus;
- suffer brief CP strain, such as being unable to use the same technique again until the end of your next turn;
- fall prone, lose a carried material focus, reveal your position, or suffer another concrete consequence that fits the technique.

A Backlash consequence can be harsher if the technique is especially dangerous, Forbidden, unstable, higher-Realm, or if the GM approves a stronger Drawback. **Exhaustion is usually an Exhausting Drawback, not the default Backlash Drawback.** A technique can use Exhaustion as Backlash only if the technique's text says so.

### Exhausting Drawback

**Exhausting** is a separate Drawback from Backlash.

An Exhausting technique gives you 1 level of Exhaustion after the technique resolves, unless its text gives a different timing. This is stronger than ordinary Backlash and should be used for techniques that visibly overtax the body, qi, spirit, Foundation, or Method.

## Hard Limits

Forged Techniques cannot do everything.

A Forged Technique cannot:

- create or multiply CP;
- bypass full cultivation-session limits;
- convert temporary CP into permanent CP;
- grant additional full turns;
- create permanent effects by default;
- impose hostile conditions without saves;
- replace talents the character does not know;
- ignore Realm requirements;
- ignore Path restrictions;
- ignore normal action economy unless the technique pays for that power.

Action-economy upgrades are expensive, usually require Core Formation or higher, and require GM approval.

## Technique-Forging Check

To create a Forged Technique, you need:

- the necessary Sphere base abilities, talents, or approved substitutes;
- a suitable training location;
- spiritual materials;
- inspiration or a clear technique concept;
- research time;
- a successful Technique-Forging Check.

A **Technique-Forging Check** is a Cultivation Check against the technique's Technique-Forging DC.

The Technique-Forging DC is:

**10 + final Complexity + number of Spheres used**

Research time is:

**3 days × Complexity**, minimum 3 days.

Use the normal training-day rules for this research time.

Material cost is:

**100 gp × Complexity²**

The GM may replace gp cost with sect tokens, rare materials, favors, spirit stones, beast cores, jade slips, bloodline materials, special ink, Formation access, or another campaign resource.

## Success and Failure

On a success, you learn the Forged Technique.

On a failure, you do not learn the technique yet. You lose half the material cost and must spend half the original research time before retrying.

If you fail by 5 or more, the GM may also apply appropriate Backlash. This might be CP strain, Exhaustion, injury, deviation pressure, Foundation strain, Method instability, damaged materials, or another consequence that fits the attempted technique.

## Maximum Known Forged Techniques

Your maximum number of known Forged Techniques equals your Proficiency Bonus.

A Forged Technique does not replace a Sphere talent. It is a separate personal art built from cultivation you already know.

Recorded Arts do not count against this limit unless a rule says otherwise.

## No Retraining by Default

A learned Forged Technique cannot be freely replaced, refunded, swapped, or retrained.

If you know your maximum number of Forged Techniques and want another one, you must wait until your Proficiency Bonus increases or use a specific source rule that explicitly removes, seals, transforms, or replaces one of your existing Forged Techniques.

A character can stop using a technique in the story, but the technique still counts as known unless a source rule says it is removed or transformed.

## Signature Technique

A character's first Forged Technique often becomes a **Signature Technique**.

This is narrative by default. It is not automatically stronger than other Forged Techniques.

A Signature Technique might gain reputation, attract students, become part of a manual, found a school, be refined at higher Realms, or eventually become a jade-tablet art.

## Evolving a Forged Technique

A Forged Technique can evolve at a higher Realm only when a source rule, GM-approved technique project, or printed refinement opportunity allows it. Evolution is not retraining.

An evolved Forged Technique keeps the same identity, core source expressions, and known-technique slot. It may gain a higher-Realm expression, improve its scale, add an Augment, or add a new cost, limit, or risk.

Evolution cannot be used to freely remove Drawbacks, replace the Base Form, change the Primary Sphere Effect, discard earlier costs, or rebuild the technique into an unrelated optimized technique unless a specific source rule says so. If the result is fundamentally a different technique, learn it as a new Forged Technique instead.

To evolve a technique, use the technique-forging procedure unless the source rule gives a different process. The evolved technique must still obey your Realm's Complexity limit.

## Recording and Teaching Forged Techniques

A Forged Technique can eventually be recorded in a manual, jade slip, scripture, painting, song, Formation, mural, cultivation journal, or other teaching form.

Recording requires:

**2 days × Complexity**

Materials cost:

**100 gp × Complexity**

A jade tablet or high-quality inheritance medium may cost more.

A recorded Forged Technique can become a training source. A student must still meet the requirements printed in the record.

A student who learns it as a fixed technique learns a Recorded Art. A student who learns to recreate it as their own custom art follows the Forged Technique rules.

## Jade-Tablet Martial Arts

A single Forged Technique can be preserved in a manual.

A complete jade-tablet martial art is much larger. It might contain:

- a philosophy;
- related Recorded Arts;
- several Sphere talents;
- one or more Forged Techniques;
- a training Method or Method fragment;
- higher mastery paths;
- secret techniques;
- creator impressions;
- breakthrough guidance;
- warnings, false leads, or hidden tests.

Creating a complete jade-tablet martial art normally requires several Forged Techniques, years of refinement, Core Formation or higher, coherent philosophy, major narrative accomplishment, and GM approval.

## Emergency Forged Techniques

An **Emergency Forged Technique** is a one-time breakthrough of combat instinct, Sphere interaction, and cultivation pressure.

It is not a learned technique and is not permanently added to your known Forged Techniques when used.

Emergency Forging exists for moments when a cultivator is pushed hard enough to discover a route they could not have calmly designed.

## When Emergency Forging Is Allowed

All of the following must be true:

- the scene is a meaningful combat, crisis, duel, ambush, tribulation-like pressure, desperate escape, or similarly dangerous situation;
- the attempt combines two legal Spheres, Sphere expressions, Path features, or cultivation expressions the character can currently access;
- the attempted effect follows normal Forged Technique legality, Realm, CP cost, target, range, action type, and effect scale;
- the player can explain how the sources combine in the moment;
- the GM agrees the scene has enough pressure.

Emergency Forging is not available for harmless practice, staged farming, casual sparring, or trivial encounters.

## Declaring an Emergency Forged Technique

When you attempt Emergency Forging, state:

- the two Spheres or cultivation expressions being combined;
- the intended effect;
- the action type;
- the CP cost or resource cost paid;
- the target or area;
- the risk or pressure forcing the attempt.

Then make a Technique-Forging Check using the normal Forged Technique procedure.

If there is not enough time to fully build the technique, the GM estimates the Complexity, CP cost, and DC using the same rules.

## Emergency Forging Success

On a success, the technique works once.

It obeys all normal action economy, target, range, CP cost, attack roll, saving throw, Realm, Sphere, Path, risk, and drawback limits.

A successful Emergency Forged Technique creates an **Emergency Technique Seed**.

## Emergency Forging Failure

On a failure, the GM chooses an appropriate result.

Possible results include:

- the action is spent;
- the CP or resource cost is paid;
- the effect is reduced;
- the effect is distorted;
- the character suffers CP strain, Exhaustion, or another consequence that fits the failed attempt;
- a Burden, hidden injury, deviation, or Heart Demon pressure worsens;
- the character gains a clue for later study;
- the character creates an unstable seed.

A failed Emergency Forged Technique should matter, but it should not become a safe way to farm benefits.

## Emergency Technique Seed

An **Emergency Technique Seed** is a discovered route.

It is not a learned technique yet.

Record:

- name or working name;
- scene where it appeared;
- Spheres or expressions combined;
- Path used;
- CP or resource cost paid;
- action type;
- effect produced;
- risk or flaw observed;
- whether it was decisive;
- whether it produced Enlightenment.

## Studying an Emergency Technique Seed Later

A successfully emergency-forged seed grants Advantage on study or forging checks made to formalize that exact technique.

Learning time remains normal unless another rule says otherwise.

Flawed, risky, forbidden, or unstable seeds may require correction scenes, special materials, teacher help, Foundation work, Method correction, or additional checks.

## Emergency Forging Enlightenment

If an Emergency Forged Technique succeeds, is decisive in a dangerous scene, and reveals something true about the character's Path, Method, Foundation, Spheres, Dao, body, qi, spirit, vow, or future Realm, record an Enlightenment Record.

Suggested die:

| Moment | Enlightenment |
|---|---:|
| Useful but narrow success | Minor, `1d4` |
| Decisive moment in a serious fight | Notable, `1d6` |
| Victory or survival turns on the technique | Major, `1d8` |
| Mythic, Realm-defining, or fate-changing technique | Mythic, `1d10` |

Emergency Forging Enlightenment does not grant Advantage on a breakthrough check. It grants an Enlightenment die.

Unless the source specifically says otherwise, an Enlightenment die becomes part of the character permanently and can be used on future breakthrough checks.

## Quick Forging Checklist

When creating a Forged Technique, use this checklist.

1. Confirm you have access to Technique Forging.
2. Choose the concept and name.
3. Choose a Base Form.
4. Choose the Primary Sphere Effect.
5. Add any Secondary Sphere Effects.
6. Add any Augments.
7. Add any Drawbacks.
8. Calculate Complexity.
9. Confirm the technique is within your Realm's Complexity limit.
10. Calculate CP cost.
11. Calculate the Technique-Forging DC.
12. Spend research time and materials.
13. Make the Technique-Forging Check.
14. Record the finished technique or the failure result.

## Quick Emergency Forging Checklist

When attempting Emergency Forging, use this checklist.

1. Confirm the scene has real pressure.
2. Name the two Spheres or cultivation expressions being combined.
3. State the intended effect.
4. State the action type, target or area, and cost.
5. Estimate or calculate Complexity and DC.
6. Make the Technique-Forging Check.
7. On success, use the technique once and record an Emergency Technique Seed.
8. On failure, apply the failure result.
9. If the technique was decisive and revelatory, record Emergency Forging Enlightenment.


## Beyond Forged Techniques: Dao Aspects and Immortal Arts

Forged Techniques are the normal player-facing system for creating personal cultivation arts during early and middle cultivation.

At much higher Realms, some cultivators begin working with **Dao Aspects** and **Immortal Arts**. A Dao Aspect is a late-game immortal principle, such as Destruction, Binding, Restoration, Fate, Time, Soul, or Heaven. An Immortal Art elevates a legal source effect through a Dao Aspect and other late-game construction rules.

These rules are not part of ordinary Technique Forging. They open much later in the campaign and use separate late-game rules.

---

# 19. Injuries, Deviations, Burdens, and Cultivation Scars

Cultivation is powerful, but it is not safe.

A cultivator pushes body, qi, spirit, Foundation, Method, and Dao-understanding beyond ordinary limits. Sometimes that pressure leaves a mark. This chapter explains the lasting consequences that can come from failed breakthroughs, dangerous training, unstable Methods, harsh Foundations, Forbidden power, corrupted resources, tribulations, and desperate techniques.

These consequences are not only punishments. In cultivation, a wound can become a lesson, a scar can become an identity, and a failure can reveal a hidden route. But a consequence is not a free reward. If it matters at the table, it needs a clear rule.

## Consequence Records

When your character gains a cultivation consequence, record it.

A useful consequence record includes:

- **Name.** What the consequence is called.
- **Type.** Hidden Injury, Deviation, Burden, Cultivation Scar, or Cultivation Strain.
- **Source.** What caused it.
- **Severity.** Minor, Notable, Major, or Mythic.
- **Trigger.** When the consequence matters.
- **Effect.** What the consequence does mechanically.
- **Recovery or transformation path.** How it can be purified, repaired, or integrated.
- **Visibility.** Hidden, visible, known, secret, or recognized by cultivators.
- **Unstable tag, if any.** Whether the consequence can worsen, and what causes that to happen.

A consequence should not be only a mood or warning. If the consequence affects play, the record tells you how.

## Severity

A consequence uses one of four severity ratings.

| Severity | Meaning |
|---|---|
| Minor | A small but real mark, strain, flaw, or warning. |
| Notable | A meaningful consequence that can affect scenes or training. |
| Major | A serious consequence that can shape advancement, combat, recovery, or breakthrough risk. |
| Mythic | A defining mark, curse, scar, burden, or transformation route. |

The severity tells the table how seriously to treat the consequence. The consequence's actual text still controls what it does.

## Hidden Injuries

A **Hidden Injury** is damage inside your cultivation.

It might affect flesh, bone, organs, meridians, dantian, soul, spirit, Foundation, Method route, or the way CP moves through your character.

Hidden injuries are called hidden because they may not be obvious at first. A character may still walk, fight, speak, and cultivate while something inside them has become unstable.

### Hidden Injury Effects

A Hidden Injury should have a clear effect. Examples include:

- a penalty to a specific kind of Cultivation Check;
- reduced maximum CP;
- increased CP cost for a named category of techniques;
- reduced recovery from cultivation sessions;
- damage or strain when using a related Sphere, Recorded Art, Method, or Forged Technique;
- a breakthrough penalty until treated;
- a trigger that worsens the injury.

A Hidden Injury can be unknown at first, but once it affects play, the player should receive symptoms, clues, or a record of the mechanical effect.

## Deviations

A **Deviation** is a harmful instability or distortion in your cultivation.

A Deviation does not mean your Dao is "wrong." Cultivation has many routes. Strange expression is not automatically a mistake.

A Deviation is a problem because it creates mechanical instability, danger, corruption, imbalance, loss of control, or harmful transformation.

### Deviation Effects

A Deviation might cause:

- an unwanted trigger when spending CP;
- a penalty to specific checks;
- a CP cost increase for related effects;
- aura exposure;
- backlash when using certain power;
- difficulty with a future breakthrough;
- a dangerous shortcut or temptation;
- a social, sect, or spiritual consequence if revealed.

A Deviation should always tell you what it affects.

For example, "your qi is unstable" is not enough by itself. A useful Deviation says something like:

> When you spend 3 or more CP on a Fire, Ash, Yang, or purification effect, take fire damage equal to your PB after the effect resolves. This effect can trigger once per turn.

## Burdens

A **Burden** is a lasting pressure carried by the character.

Burdens can be physical, spiritual, karmic, social, emotional, sect-related, or metaphysical. They are not always injuries. A Burden might be something the character owes, carries, suppresses, hides, or must answer for.

### Burden Effects

A Burden should define:

- what claim, pressure, oath, debt, weight, or restriction exists;
- when it matters;
- what happens if the character ignores it;
- how it can be fulfilled, stabilized, integrated, or removed.

A Burden might:

- impose a penalty when ignored;
- require a future offering, duel, apology, service, vow, or quest;
- complicate a future breakthrough;
- attract a spirit, rival, ancestor, creditor, sect elder, or enemy;
- become a requirement for a failure-born option;
- grant a benefit when honored, if its rule says so.

A Burden is not just roleplaying homework. If it matters mechanically, write down the trigger and effect.

## Cultivation Scars

A **Cultivation Scar** is a lasting mark left by cultivation pressure.

A scar can be physical, spiritual, emotional, karmic, or symbolic. Unlike a normal injury, a scar may not need to be healed. It may become part of the character.

### Three Kinds of Scars

| Scar Type | Meaning |
|---|---|
| Marked Scar | A visible or spiritual mark with no mechanical effect unless another rule refers to it. |
| Active Scar | A scar with a trigger, penalty, benefit, warning, or other mechanical effect. |
| Scar-Boon | A scar that grants a benefit, usually because of a tribulation, failure-born route, Foundation rule, or major story result. |

A scar should not grant a benefit automatically. A Scar-Boon appears only when a rule, tribulation result, Foundation, Method, Insight, or GM reward says it does.

### Scar Examples

A scar might be:

- lightning marks across the meridians;
- a ghost handprint on the soul;
- a sword-shaped scar on the dantian;
- ash in the breath;
- a permanent change in aura;
- a spirit brand;
- a cracked but reinforced Foundation line;
- a dream wound that opens during sleep;
- a tribulation mark recognized by cultivators.

Some scars are wounds. Some are proof. Some are both.

## Cultivation Strain

**Cultivation Strain** is a temporary or unstable pressure on your cultivation.

Strain is less permanent than a Hidden Injury, Deviation, Burden, or Scar. It represents a route shaking, a meridian trembling, a spirit sense distorting, a Foundation line flexing, or a Method rhythm slipping.

Strain should have a clear duration or recovery condition.

Examples include:

- until the end of the scene;
- until you complete a cultivation session;
- until you finish a long rest;
- until you complete 1 treatment day;
- until you succeed on a recovery project.

A Strain effect might impose a narrow penalty, increase a CP cost, create a one-time backlash trigger, or prevent a specific retry until stabilized.

## The Unstable Tag

Some consequences have the **Unstable** tag.

An Unstable consequence can worsen if its trigger happens. The consequence record must state the trigger and what happens.

Common Unstable triggers include:

- failing a related Cultivation Check by 5 or more;
- attempting a breakthrough before treatment;
- dropping to 0 CP;
- using a related Forbidden, Secret, or unstable technique;
- ignoring a Burden;
- using an incompatible Method;
- suffering a relevant tribulation hazard.

When an Unstable consequence worsens, it usually does one of the following:

- increases severity by one step;
- creates Cultivation Strain;
- becomes visible;
- adds a new trigger;
- blocks a specific recovery route;
- forces a treatment project before the next breakthrough.

No consequence is Unstable unless its record says so.

## Purify, Repair, and Integrate

There are three common ways to address a cultivation consequence.

| Approach | Use It For |
|---|---|
| Purify | Corruption, poison, demonic residue, polluted qi, spiritual contamination, pill impurity, or hostile influence. |
| Repair | Hidden injuries, damaged routes, meridian cracks, Foundation damage, Method route harm, body or spirit wounds. |
| Integrate | Scars, Burdens, altered routes, failure-born lessons, survivable Deviations, or consequences the character chooses to make part of their cultivation. |

The consequence tells you which approaches are available. If it does not, the GM chooses an approach that fits the cause.

## Recovery Projects

A **Recovery Project** is focused downtime spent purifying, repairing, or integrating a consequence.

A Recovery Project uses treatment days. Each treatment day requires 8 hours of work, which can be split across the day like training time.

The consequence may give its own time, DC, and requirements. If it does not, use the default table.

| Severity | Default Time | Default DC |
|---|---:|---:|
| Minor | 1 treatment day | DC 12 |
| Notable | 3 treatment days | DC 15 |
| Major | 7 treatment days | DC 18 |
| Mythic | 14+ treatment days or a quest | DC 22 or higher |

At the end of the Recovery Project, make a Cultivation Check unless the treatment source says to use a different check.

On a success, reduce the consequence by one severity step. If the consequence is Minor, it is cleared unless its rule says it becomes a scar, Burden, or other record.

On a failure, the project does not reduce the consequence. You may try again after at least 1 treatment day of rest, diagnosis, or changed approach.

If you fail by 5 or more and the consequence is Unstable, its Unstable trigger occurs.

## Integrating a Consequence

To **integrate** a consequence is to make it part of your cultivation instead of simply removing it.

Integration is not automatic. A consequence can be integrated only if:

- its rule says it can be integrated;
- a Foundation, Method, Insight, Recorded Art, spirit pact, tribulation result, or failure-born option allows it; or
- the GM creates a specific integration route.

An integration route must state what changes if it succeeds.

Possible integration results include:

- remove the penalty but keep the scar;
- turn a Hidden Injury into a Cultivation Scar;
- stabilize a Burden into an oath, vow, or Foundation feature;
- turn a Deviation into a controlled but risky route;
- unlock a printed failure-born option;
- grant an Enlightenment die;
- alter a Foundation or Method according to a printed rule.

Integration should not be used to farm benefits from random injuries. The route must be specific, costly, earned, or tied to a real cultivation event.

## Failure-Born Options

Some options only appear because a character failed, suffered, survived, or changed.

These are **failure-born options**.

Failure-born options can include:

- conditional bonus Insights;
- corrective Methods;
- altered Foundation routes;
- special Recorded Art comprehension;
- new training directions;
- unique breakthrough preparation;
- scar-based benefits;
- tribulation boons;
- routes that only open after injury, Deviation, or Burden.

A failure-born option is not an automatic reward for failing. It appears when a rule, feature, condition, or GM reward says it appears. The character must still meet any printed requirements.

## Consequences and Foundations

Your Foundation is your cultivation architecture.

Because of that, many serious consequences can affect your Foundation. A Foundation might be strained, cracked, reinforced, transformed, corrected, polluted, awakened, or redirected.

A Foundation consequence might:

- modify breakthrough checks;
- change compatible Spheres;
- alter CP recovery;
- create a special Burden;
- require a Recovery Project;
- unlock a failure-born route;
- increase tribulation weight;
- change how a Method interacts with the character;
- become part of the character's long-term identity.

Use the Foundation's printed rule if it gives one. If a consequence affects a Foundation but does not have printed mechanics, the GM should create a consequence record.

A Foundation is not just flavor. If it is damaged, strengthened, or transformed, that should matter.

## Consequences and Methods

A cultivation Method controls how your cultivation moves, stabilizes, and develops.

A Method consequence might appear when:

- the Method is incompatible with your current route;
- the Method is harsh or unstable;
- you change Methods;
- you force a Method correction too quickly;
- you use an incomplete scripture;
- you cultivate with a Method that does not suit your Foundation;
- a failed breakthrough exposes a flaw.

Use the Method's printed rule. If no printed rule exists, the GM creates a consequence record.

## Consequences and Recorded Arts

Recorded Arts are fixed techniques learned from manuals, jade slips, scriptures, murals, journals, inheritances, or similar sources.

A specific Recorded Art can carry risk if it is dangerous, incomplete, too advanced, Forbidden, misunderstood, or tied to old karma.

A Recorded Art consequence should come from that art's text, the source that teaches it, or a GM-created consequence record. Do not assume every Recorded Art is dangerous by default.

## Consequences and Forged Techniques

Forged Techniques can create consequences through failed research, unstable combinations, dangerous Drawbacks, emergency use, backlash, or overreach.

Use the Forged Technique's printed Drawbacks and failure rules. Backlash is not automatically Exhaustion. Exhaustion usually comes from the Exhausting Drawback or a rule that specifically says so.

## Consequences and Forbidden Power

Forbidden power is supposed to be tempting.

It may be stronger, faster, easier, or more efficient than the safe route. That is why cultivators risk it.

But Forbidden power often carries consequences, such as corruption, social condemnation, sect punishment, karmic debt, demonic influence, unstable aura, Hidden Injuries, Deviations, harder breakthroughs, or dangerous tribulations.

Forbidden does not mean unusable. It means the world, the body, the spirit, or Heaven may demand payment.

## Player Checklist

When your character gains a consequence, ask:

1. What is it called?
2. What type of consequence is it?
3. How severe is it?
4. What caused it?
5. What does it do mechanically?
6. When does it trigger?
7. Is it Unstable?
8. How can it be purified, repaired, or integrated?
9. Does it create a possible failure-born option or Enlightenment die?
10. Is it visible, hidden, secret, or known to others?

## Summary

Cultivation consequences are part of the path.

A Hidden Injury can reveal a weakness.  
A Deviation can become a warning.  
A Burden can become a vow.  
A Scar can become proof.  
A failed breakthrough can become Enlightenment.  
A damaged Foundation can become a transformed route.

The important rule is simple:

**If a consequence matters, write down what it does.**

---

# 20. Equipment, Items, Treasures, and Crafting

Cultivators use more than weapons and armor.

A disciple's pouch might hold spirit stones, pills, talismans, jade slips, sect tokens, beast cores, healing salves, formation keys, and a half-broken manual found in a cave. A sect's true wealth might be its scripture hall, furnace room, medicine garden, warded vault, trial grounds, transport array, and old inheritance tablets.

Items are part of cultivation. They can heal, teach, protect, transport, conceal, store, refine, test, and transform. A single jade slip, pill, divine material, or ancient treasure can change a character's future.

This chapter gives the player-facing rules for using items in Tianxia. The full item book, GM Screen, and AI tools can provide detailed item stat blocks.

## Item Rules Are Specific

An item does what its description says it does.

If an item grants a bonus, restores CP, teaches a Recorded Art, stores objects, opens a formation gate, protects against tribulation lightning, or helps with a breakthrough, its own text explains how.

Items do not grant extra benefits just because they sound impressive. A jade sword is not automatically a Sword talent. A pill is not automatically AP. A robe is not automatically armor. A manual is not automatically a full Sphere.

When in doubt, use the item's printed rule.

## Item Records

Most Tianxia items can be recorded with a simple item entry.

A full stat block may be generated by the GM Screen or AI tools, but players usually need only the usable parts.

A good item record includes:

- name;
- item type;
- physical form;
- rarity or availability;
- Realm or CL requirement, if any;
- binding requirement, if any;
- activation rule;
- range, target, and duration, if any;
- CP, charge, material, or use cost;
- mechanical effect;
- limit, drawback, or backlash;
- whether it is consumable, reusable, permanent, or story-bound.

Not every item needs every field. A simple healing pill may need only a name, use, effect, and limit. A sect artifact may need several lines.

## Major Item Categories

Tianxia uses many kinds of items.

| Item Category | Examples |
|---|---|
| Ordinary Equipment | weapons, armor, robes, tools, packs, travel gear, mounts |
| Cultivator Gear | storage rings, spirit lamps, sect uniforms, spirit compasses, formation keys |
| Consumables | pills, elixirs, medicinal baths, salves, volatile pellets, spirit meals |
| Talismans | paper talismans, jade talismans, seal strips, bone charms, talisman arrows |
| Materials | herbs, ores, beast cores, divine metals, spirit wood, monster parts |
| Learning Objects | manuals, jade slips, diagrams, cultivation journals, inheritance records |
| Formations and Infrastructure | array nodes, trial rooms, furnace halls, shield formations, transport circles |
| Artifacts | permanent treasures, named weapons, ancestral robes, soul-bound vessels |
| Story Relics | ancient inheritances, forbidden palaces, emperor treasures, cosmic vessels |

Some items are small enough to carry. Others are places, rooms, arrays, or entire structures. A sect shield formation, furnace hall, or tribulation chamber is still an item-like resource even if it cannot be put in a pouch.

## Ordinary Equipment

Most mundane equipment follows the normal rules for weapons, armor, tools, and adventuring gear.

Tianxia adds cultivation context.

A robe might be ordinary clothing, sect uniform, minor protective garment, talisman gown, spirit-bound battle dress, or ancestral treasure. A sword might be a mundane blade, a good mortal weapon, a qi-conducting weapon, a spirit heirloom, a Recorded Art vessel, or an artifact with its own will.

Do not assume every item is supernatural. Many cultivators still use ordinary tools, ropes, lamps, carts, boats, armor, locks, cooking gear, and medicine.

Ordinary items matter because cultivation often begins with ordinary things refined beyond their normal limit.

## Cultivator Gear

Cultivator gear is practical equipment made for cultivation life.

Examples include:

- storage rings;
- spirit-stone pouches;
- sect identification tokens;
- lodging keys;
- formation keys;
- communication stones;
- diagnostic lenses;
- spirit compasses;
- aura-concealing charms;
- dry boxes;
- purification containers;
- training uniforms;
- self-cleaning robes;
- spirit lamps;
- portable pavilions;
- travel platforms.

These items are often less dramatic than weapons, but they shape play. A storage ring protects supplies. A sect token grants access. A formation key opens a vault. A communication stone changes how far a sect can coordinate.

## Spirit Stones

**Spirit stones** are condensed cultivation energy used as currency, fuel, crafting material, and cultivation support.

Spirit stones may be used to:

- buy goods in cultivation markets;
- pay sect fees or auction prices;
- fuel formations;
- support crafting;
- power certain items;
- assist cultivation;
- serve as mission rewards;
- stabilize rituals or breakthroughs if an item or rule allows it.

Spirit stones do not automatically restore CP or grant AP unless a specific rule says they do.

## Consumables

A **consumable** is used up when activated.

Common consumables include:

- healing pills;
- CP-restoring pills;
- Stamina medicines;
- Resonance stabilizers;
- AP-granting cultivation pills;
- breakthrough pills;
- purification pills;
- medicinal baths;
- incense;
- salves;
- volatile pellets;
- talismans;
- emergency extraction charms.

Consumables are powerful because they let a character spend stored wealth at the right moment.

They are limited because they run out, can be expensive, may require access, and may carry impurities or side effects.

## Pills and Medicines

Pills are one of the most important item types in cultivation.

A pill might:

- restore HP;
- restore CP;
- grant AP;
- help a breakthrough;
- reduce a penalty;
- treat a hidden injury;
- purge impurities;
- stabilize a deviation;
- support a Foundation;
- protect against tribulation;
- temporarily increase power;
- create a dangerous side effect.

A pill only does what its description says.

### Cultivation and Enhancement Pills

Some pills push cultivation directly. These are stronger than ordinary medicine.

A **Cultivation pill** directly advances, accelerates, stabilizes, or forces cultivation. It might grant AP, help a breakthrough, increase CP, support a Foundation, or alter a cultivation consequence if its description says so.

An **Enhancement pill** temporarily improves the body, qi, spirit, senses, technique expression, or combat ability. It does not grant permanent cultivation progress unless its description says so.

A creature can safely consume **one Cultivation or Enhancement pill per long rest**.

Each additional Cultivation or Enhancement pill before finishing a long rest requires a Constitution save.

The DC is:

**DC 10 + 2 × the number of Cultivation or Enhancement pills already consumed since your last long rest**

On a success, the pill works and you gain 1 Pill Impurity.

On a failure, the pill fails, you gain 1 Pill Impurity, and you are Poisoned until you finish a long rest.

If you fail by 5 or more, you also gain 1 level of Exhaustion.

### Pill Impurity

**Pill Impurity** represents residue left behind by forcing cultivation through medicine.

Each Pill Impurity gives you a `-1` penalty to breakthrough checks.

Pill Impurity can be removed only by a rule that says it removes or reduces Pill Impurity. Common examples in item or adventure text might include purification pills, medicinal baths, healer treatment, cleansing techniques, tribulation rewards, Realm events, or special recovery projects.

## Talismans

A **talisman** is a stored command written into a medium.

A talisman might be written on paper, silk, wood, bone, jade, metal, armor, skin, air-script, or another suitable surface.

Most talismans are consumable. When activated, the stored effect releases and the talisman is used up.

Talismans can create many effects, such as:

- force blasts;
- barriers;
- alarms;
- cleansing water;
- fire bursts;
- seals;
- spirit wards;
- concealment;
- emergency retreat;
- anti-stealth marks;
- message constructs;
- temporary defenses;
- formation triggers.

Talismans are not default shop inventory everywhere. Their availability depends on formula access, materials, local law, sect permission, market supply, and the Talismans Sphere.

Reusable talismans, jade talismans, and permanent talisman treasures require specific rules.

## Manuals, Jade Slips, and Learning Objects

Some items teach.

Learning objects include:

- manuals;
- jade slips;
- scripture fragments;
- cultivation journals;
- diagrams;
- murals;
- ancestor recordings;
- formation maps;
- source-pattern atlases;
- weapon records;
- incomplete inheritance tablets.

A learning object might teach:

- a Recorded Art;
- a cultivation Method;
- a Sphere source;
- a talent source;
- a breakthrough route;
- Foundation theory;
- an Enlightenment die;
- AP;
- a warning;
- a false route;
- a hidden requirement.

Learning objects can be more valuable than weapons.

A single jade slip found in a cave might contain a forgotten emperor's Recorded Art, a lost Method fragment, a secret route through a Realm bottleneck, or the theory needed to understand a hidden injury.

A cultivation journal can contain truth, misunderstanding, pride, brilliance, and error. The reader must determine what can actually be used.

## Recorded Arts in Items

A Recorded Art is a fixed technique preserved in a manual, jade slip, mural, inheritance, journal, or similar source.

Learning a Recorded Art gives the fixed technique only. It does not grant the listed Sphere, talent, or permission to modify the technique unless another rule says so.

Some items contain one Recorded Art. Others contain many. A jade tablet might hold an entire art collection with Mortal, Foundation, Core Formation, and higher chapters.

Recorded Arts are covered in Chapter 15.

## Materials and Components

Cultivation crafting depends on materials.

Common materials include:

- spirit herbs;
- beast cores;
- monster bones;
- claws, horns, scales, blood, hide, venom, silk, and shell;
- rare ores;
- divine metals;
- spirit wood;
- incense wood;
- spirit soil;
- pearls, coral, jade, and crystals;
- source stones;
- ancient fragments;
- formation anchors;
- talisman ink;
- furnace fuel;
- medicinal bath ingredients.

A material's source matters.

A beast core from a fire serpent is not the same as a moonlit lake pearl. An ore mined from a battlefield grave is not the same as one mined from a clean mountain vein. Materials carry qi, history, danger, and compatibility.

## Harvest Lots

A **Harvest Lot** is a usable batch of gathered material.

A Harvest Lot might be a bundle of herbs, a beast core, a vial of venom, a horn, a scale bundle, a pouch of mineral powder, or a sealed bottle of spirit dew.

Harvest Lots should come from a real source:

- wilderness exploration;
- sect gardens;
- markets;
- monster hunts;
- ruins;
- mines;
- spirit sites;
- mission rewards;
- auctions;
- negotiated trades.

A Harvest Lot does not have a universal PHB stat block. The item book, adventure, GM Screen, or AI tool can assign its quantity, quality, tags, use, value, and crafting role.

## Formations and Infrastructure

Some "items" are fixed in place.

Examples include:

- shield formations;
- furnace halls;
- pill rooms;
- teleportation circles;
- trial gates;
- spirit pools;
- storage vaults;
- warded residences;
- cultivation chambers;
- growth chambers;
- academy shields;
- trap barriers;
- transport platforms;
- formation anchors;
- sect defense arrays.

These are infrastructure items.

A character usually cannot carry them, but they can use them, control them, damage them, repair them, key into them, or gain access through sect rank, payment, permission, or story events.

Infrastructure often matters more than personal treasure. A sect with a better pill hall, formation room, library, and tribulation chamber can raise stronger disciples.

## Artifacts and Treasures

An **artifact** is a powerful item with lasting cultivation significance.

Artifacts can be weapons, armor, vessels, robes, lamps, bells, cauldrons, seals, towers, mirrors, maps, rings, flags, scripture pages, or stranger things.

A lesser artifact might protect a disciple or store a technique.

A greater artifact might shape a sect.

An imperial or immortal treasure might carry overwhelming pressure, suppress enemies, preserve worlds, awaken like a living being, or embody a principle far beyond ordinary cultivation.

Artifacts often have:

- Realm requirements;
- binding rules;
- sect ownership;
- spirit recognition;
- command words;
- charges;
- backlash;
- hidden conditions;
- history;
- enemies;
- legal restrictions;
- inheritance pressure.

A powerful artifact should not be treated as ordinary loot.

## Binding

Some items can be used by anyone. Others must be bound.

Binding might require:

- carrying the item for a time;
- spending CP;
- meditating with it;
- feeding it spirit stones;
- offering blood;
- gaining sect permission;
- learning a command phrase;
- satisfying a lineage requirement;
- passing a trial;
- being accepted by the item spirit;
- matching a Path, Foundation, Method, Sphere, or Realm.

A bound item can have special rules. It might unlock stronger effects, recognize the bearer, resist theft, reveal hidden functions, impose a burden, or refuse another user.

There is no universal PHB binding limit in this chapter. If an item occupies a binding slot or uses another limit, the item says so.

Soul-bound, blood-bound, oath-bound, sect-bound, and spirit-bound items should always explain what the bond does and how it can be broken.

## Activation

An item's activation rule tells you how to use it.

Common activation types include:

| Activation | Meaning |
|---|---|
| Passive | The item works while worn, carried, installed, or bound. |
| Action | You use your Action to activate it. |
| Bonus Action | You use your Bonus Action to activate it. |
| Reaction | You activate it in response to a trigger. |
| Command | You speak, gesture, circulate qi, or present a token. |
| Ritual | You spend minutes, hours, or days using it. |
| Formation Use | You activate an array, node, key, or ritual site. |
| Consumption | You drink, swallow, burn, inhale, apply, or dissolve it. |

If an item has no activation rule, the GM decides the most reasonable use based on its form and effect.

## Charges, Uses, and Recharge

Many items have limited uses.

An item might have:

- one use;
- charges;
- uses per short rest;
- uses per long rest;
- uses per scene;
- a recharge roll;
- CP cost;
- spirit-stone cost;
- material cost;
- preparation requirement;
- cooldown.

A reusable item should say when it refreshes.

A consumable item is usually destroyed or emptied when used.

## Item Costs

Some items cost CP, Stamina, Resonance, spirit stones, charges, materials, HP, Exhaustion, reputation, sect tokens, or story obligations.

The cost should fit the item.

A minor cleaning talisman might cost only its paper. A teleportation platform might require a formation, spirit stones, and permission. A forbidden relic might demand blood, karma, or a vow.

Do not assume all costs are money.

## Crafting Overview

Crafting is the process of making, repairing, refining, inscribing, brewing, awakening, or stabilizing an item.

The full item book gives detailed crafting procedures. This chapter gives the core player-facing idea.

To craft an item, you usually need:

- the right recipe, formula, plan, pattern, or design;
- the right Sphere, tool proficiency, teacher, or facility;
- materials;
- time;
- a check;
- any required CL or Realm;
- any required permission, license, or story access.

Crafting should not create powerful items for free.

A permanent item should require meaningful materials, time, risk, access, or cost.

## Crafting Spheres

Different Spheres govern different kinds of item work.

| Sphere or System | Item Role |
|---|---|
| Blacksmith | weapons, armor, shields, tools, metalwork, repair, tempering |
| Talismans | stored-command items, paper charms, jade talismans, sealing strips |
| Alchemy | pills, elixirs, medicines, refinement, impurities |
| Formations | arrays, infrastructure, wards, nodes, formation halls |
| Harvesting and Gathering | finding and preserving usable materials |
| Imbuement | empowering objects, temporary roles, true vessels |
| Metal | metal appraisal, ore, alloy, weapon and armor quality |
| Sect Stewardship | permissions, tokens, storehouses, halls, archives, access |
| Weapons | weapon profiles, conduits, heirlooms, armament literacy |

A character does not need all of these to use items. These systems matter when creating, modifying, acquiring, repairing, or understanding items.

## Temporary Empowerment

Some effects empower an item temporarily.

Examples include:

- Blacksmith tempers;
- Imbuement effects;
- talisman pulses;
- formation reinforcement;
- emergency repairs;
- short-term weapon coating;
- spirit-stone charging;
- sect furnace blessings.

Temporary empowerment is not the same as permanent item creation.

A temporarily empowered item does not automatically become a permanent artifact or treasure. Its effect ends when the rule says it ends.

## Item Spirits

Some items develop memory, personality, or spiritual response.

An item spirit might begin as:

- purpose-memory;
- repeated use;
- ancestral worship;
- spirit binding;
- bloodline inheritance;
- long exposure to qi;
- a major forging project;
- a tribulation event;
- a soul-bound pact.

An item spirit seed is not automatically a full companion.

True item spirits are rare and usually require high Realm cultivation, special materials, repeated projects, a suitable site, and GM approval.

## Sect Economy and Access

Many items are not bought with coins alone.

A sect may require:

- sect tokens;
- rank;
- standing;
- mission credit;
- teacher approval;
- library permission;
- storehouse access;
- contribution records;
- tournament results;
- lineage status;
- clan support;
- oath or contract;
- legal license.

A disciple might have enough money for a pill but lack the standing to buy it. Another disciple might earn library access through missions, then find a manual worth more than silver.

In a sect, access is power.

## Three Economies

Tianxia items move through three economies.

| Economy | Examples |
|---|---|
| Mortal Economy | coins, grain, iron, salt, cloth, tools, animals, labor, ordinary goods |
| Cultivation Economy | spirit stones, pills, herbs, beast cores, manuals, talismans, rare metals, cave sites |
| Reputation Economy | face, vows, sect standing, favors, karmic debts, titles, teacher recognition, grudges |

A powerful item might require all three.

A cultivator might pay silver for a beast core, spend sect tokens for furnace access, and owe a teacher a favor for the recipe.

## Legal and Restricted Items

Not every item is legal everywhere.

A talisman, poison, blood medicine, corpse tool, spirit-binding object, demonic manual, forbidden inheritance, or formation key may be restricted by sect, city, empire, lineage, or clan law.

An item's legal status can affect:

- whether it can be bought openly;
- whether it must be registered;
- whether carrying it is suspicious;
- whether a sect will punish its use;
- whether an official can confiscate it;
- whether it creates reputation or karmic consequences.

Forbidden does not always mean impossible to obtain. It means the item carries risk.

## Item Risks

Items can create consequences.

Possible risks include:

- Pill Impurity;
- backlash;
- CP loss;
- Exhaustion;
- hidden injury;
- deviation;
- burden;
- curse;
- spirit attention;
- aura exposure;
- sect punishment;
- legal trouble;
- broken binding;
- corrupted materials;
- unstable formation reaction;
- inherited karma;
- tribulation weight.

The item's description tells you what risks apply.

## Divine, Imperial, and World-Scale Treasures

Some treasures are beyond ordinary item rules.

These include:

- emperor weapons;
- cosmic vessels;
- divine metals;
- ancient palaces;
- immortal pools;
- supreme towers;
- world cauldrons;
- forbidden altars;
- inheritance coffins;
- relic scriptures;
- treasures that awaken like living beings.

These items are campaign-shaping treasures.

A low-Realm character might encounter such an item without controlling it. They might survive its pressure, learn from it, carry a fragment, be marked by it, or build their future around it.

The GM decides how such treasures function.

## Simple Item Template

Use this template when writing down an item.

**Name.**  
**Type.**  
**Rarity / Availability.**  
**Requirement.**  
**Activation.**  
**Effect.**  
**Cost or Uses.**  
**Limit or Risk.**  
**Notes.**

Example:

**Force-Blast Talisman.**  
Type: Consumable talisman.  
Rarity / Availability: Common in some sects, restricted in others.  
Requirement: None unless the talisman says otherwise.  
Activation: Action; thrust or release the talisman toward a creature or object.  
Effect: Releases a short wave of force.  
Cost or Uses: One use; consumed after activation.  
Limit or Risk: Weak against stronger cultivators unless upgraded.  
Notes: Often used as a training, self-defense, or emergency talisman.

## Player Checklist

When you receive an item, ask:

1. What type of item is it?
2. Is it consumable, reusable, permanent, or story-bound?
3. Does it require binding, Realm, CL, Sphere, Path, Method, or sect permission?
4. How do I activate it?
5. What does it cost?
6. How often can I use it?
7. Does it have risks, impurities, backlash, or legal consequences?
8. Does it teach anything?
9. Does it interact with my Foundation, Method, Spheres, or Path?
10. Is it mine, borrowed, sect-owned, stolen, inherited, or restricted?

## Summary

Items are cultivation opportunities.

A pill can push a breakthrough.  
A talisman can save a life.  
A jade slip can teach a Recorded Art.  
A formation room can shape training.  
A storage ring can protect a future.  
A spirit stone can fuel a sect.  
A broken relic can carry an emperor's shadow.

The full item book gives deeper rules. In the PHB, remember the core rule:

**An item does what its description says it does.**

---

# 21. Combat and Cultivation Actions

Tianxia uses the normal combat structure of 5.5e unless a Tianxia rule says otherwise.

Characters still roll initiative, take turns, move, use Actions, Bonus Actions, and Reactions, make attack rolls, force saving throws, take damage, fall unconscious, and recover through rests.

Cultivation adds new resources, techniques, training sources, Realm differences, aura, and consequences. This chapter explains how those rules function during combat and other dangerous scenes.

## The Basic Rule

During combat, use the normal rules unless a Tianxia feature changes them.

A Path feature, Sphere base ability, Sphere talent, Recorded Art, Forged Technique, item, Foundation, Method, or consequence can change what you do on your turn.

If two rules conflict, use the more specific rule.

For example, the normal Attack action works normally unless a technique replaces it, modifies it, or says it uses a different action.

## Scenes and Combat

Many Tianxia rules last “for the scene.”

A scene is one continuous stretch of play focused on one meaningful conflict, challenge, investigation, negotiation, journey segment, or other situation.

A combat encounter is usually one scene. A duel is usually one scene. A chase through a ruined sect might be one scene or several scenes, depending on how the situation changes.

A scene usually ends when:

- the immediate conflict is resolved;
- the objective changes;
- the location changes meaningfully;
- the party takes a rest;
- the GM declares that a new scene has begun.

If a rule says it lasts for the scene, it ends when the scene ends.

## Combat Terms

This chapter uses the following terms.

| Term | Meaning |
|---|---|
| Technique | Any combat-relevant Path feature, Sphere base ability, Sphere talent, Recorded Art, Forged Technique, item effect, or other cultivation ability. |
| Cultivation Effect | Any supernatural, internal, spiritual, qi-based, stamina-based, resonance-based, or Dao-shaped effect created by cultivation. |
| Source Rule | The rule that gives you the technique or effect. |
| CP | Your Path resource: Stamina for Body Refining, Qi for Qi Cultivation, or Resonance for Spirit Awakening. |
| PB | Proficiency Bonus. |
| Cultivation Check | `d20 + Path key ability modifier + PB`. |
| Cultivation Save DC | `8 + PB + Path key ability modifier`, unless the source rule gives a different DC. |

Use the source rule if it gives a different DC, ability score, check, attack roll, or timing.

If a technique is missing a required combat field, such as activation, target, range, attack roll, saving throw, duration, or cost, resolve that missing field with the GM before using the technique in combat. The PHB does not grant a generic attack roll, target, or range to an incomplete technique.

## Action Economy

Tianxia uses the normal action economy.

On your turn, you normally have:

- movement;
- one Action;
- one Bonus Action, if you have something that uses it;
- one Reaction between turns;
- one free object interaction or similar minor interaction, as allowed by the table.

A technique tells you what kind of action it uses.

Common activation types include:

| Activation | Meaning |
|---|---|
| Action | Use your Action to activate the technique. |
| Bonus Action | Use your Bonus Action to activate the technique. |
| Reaction | Use your Reaction when the trigger occurs. |
| No Action | The effect happens as part of another rule. |
| Passive | The effect is always active while its conditions are met. |
| Ritual / Downtime | The effect takes longer than combat timing. |

A technique should state its activation. If it does not, resolve the missing activation before use.

Items follow the item activation rules in Chapter 20.

## Reactions

A Reaction can normally be used on another creature’s turn when its trigger occurs.

Unless a rule says otherwise, you cannot use a Reaction on your own turn.

A reaction technique must name its trigger. Examples include:

- when a creature hits you;
- when you take damage;
- when a creature enters your reach;
- when an ally within range is attacked;
- when you fail a saving throw;
- when a visible enemy begins a technique.

If the trigger does not happen, you cannot use the Reaction.

## Movement

Movement works normally unless a technique changes it.

A technique might let you:

- fly;
- leap;
- swim;
- climb;
- teleport;
- phase;
- dash as part of another effect;
- move without provoking opportunity attacks;
- move a target;
- resist forced movement;
- ignore difficult terrain.

If a technique gives special movement, it applies only as written.

A movement technique does not automatically grant immunity to hazards, opportunity attacks, grapples, restraints, falling, environmental pressure, or terrain unless it says so.

## Spending CP in Combat

Many techniques cost CP.

You pay the CP cost when you activate the technique unless the rule says otherwise.

You cannot spend CP you do not have unless a rule allows overdraw, debt, sacrifice, or another exception.

If spending CP reduces you to 0 CP, apply the 0 CP rule from Chapter 16: you gain 1 level of Exhaustion. If you are later reduced to 0 CP again, you gain another level of Exhaustion.

A technique’s CP cost is paid when the technique is activated. If the technique then misses, fails, or is resisted, the cost is still paid unless the source rule says otherwise.

## CP Types

CP means your Path resource.

| Path | CP Means |
|---|---|
| Body Refining | Stamina |
| Qi Cultivation | Qi |
| Spirit Awakening | Resonance |

A rule may say CP for simplicity. Use your Path’s resource.

If a rule specifically says Qi, Stamina, or Resonance, it applies only to that resource unless the rule says otherwise.

## Attacks, Saves, and Checks

A technique tells you whether it uses an attack roll, a saving throw, a check, or no roll.

If a technique forces a saving throw and does not give a DC, use your Cultivation Save DC.

If a technique calls for a Cultivation Check, roll:

**d20 + Path key ability modifier + PB**

Some techniques use weapon attacks, tool checks, ability checks, spell attacks, normal save DCs, or other rolls. Use the source rule.

If a technique requires an attack roll but does not define the attack roll, resolve that missing field before use. A technique should not enter combat with an undefined attack roll.

## Weapon Attacks and Techniques

Many cultivators still fight with weapons.

A technique can interact with a weapon attack in several ways.

It might:

- replace the attack;
- modify the attack;
- add damage to the attack;
- change the damage type;
- add a rider effect;
- use the weapon’s range or reach;
- require a hit before it works;
- trigger after the attack hits;
- trigger even if the attack misses.

If a technique modifies a weapon attack, the weapon attack still follows normal weapon rules unless the technique changes them.

If a technique replaces a weapon attack, use the technique’s rule instead.

## Damage Types

Tianxia uses normal damage types, but cultivation can describe them differently.

A sword technique might deal slashing damage, force damage, radiant damage, necrotic damage, fire damage, lightning damage, psychic damage, or another type depending on its source.

A Body Refining strike might still deal bludgeoning damage even if it is described as mountain-shaking force.

A qi flame might deal fire damage unless the rule says otherwise.

Use the printed damage type.

## Conditions

Tianxia uses normal 5.5e conditions unless a Tianxia rule defines a special condition.

A technique does not impose a condition unless it says so.

If a technique says the target is Prone, Restrained, Poisoned, Blinded, Frightened, Charmed, Incapacitated, or affected by another normal condition, use that condition’s normal rules.

If a technique creates a Tianxia-specific condition, the condition must define its effect.

Do not apply a condition just because the narration sounds similar.

## Concentration and Maintaining Effects

Some effects require focus to maintain.

If a technique says it requires Concentration, use the normal Concentration rules.

If a technique says it requires sustain, maintenance, or continued CP, use the rule in that technique.

If a technique does not say it requires Concentration, sustain, or maintenance, it does not require them.

A character can still be interrupted by the limits written in the technique, by normal combat rules, or by consequences such as hidden injuries, deviations, burdens, or backlash.

## Combining Effects

Many Tianxia characters have several possible effects active or available at once.

Use these rules unless a feature says otherwise:

- Bonuses from the same named feature do not stack with themselves.
- Temporary HP from the same named source does not stack with itself.
- Different features can work together if their rules do not conflict.
- You cannot use two techniques with the same required action unless a rule allows it.
- A technique cannot bypass its own limits by being combined with another technique.
- A passive benefit can apply while you use another technique if both rules allow it.

If two effects give the same named benefit, use the stronger one unless a rule says they stack.

Temporary HP follows the specific rules in the Temporary HP section below.

## Spheres in Combat

Spheres give the main combat vocabulary of cultivation.

A Sphere may provide:

- a base ability;
- talents;
- defensive options;
- attacks;
- movement;
- senses;
- control;
- healing;
- utility;
- reactions;
- rituals;
- special uses outside combat.

A character can only use Sphere abilities and talents they know, plus any fixed techniques granted by Recorded Arts, items, or other rules.

Knowing a Recorded Art does not mean you know the Sphere or talent that inspired it.

## Recorded Arts in Combat

A Recorded Art is a fixed technique learned from a manual, jade slip, mural, inheritance, journal, or similar source.

In combat, a Recorded Art works exactly as written.

It does not grant:

- the source Sphere;
- the source talent;
- the right to modify the technique;
- the right to create related techniques;
- permission to ignore prerequisites.

A Recorded Art may be stronger, narrower, stranger, or more limited than a normal talent. Its own rule controls it.

## Forged Techniques in Combat

A Forged Technique is a custom technique created from legal Sphere expressions and cultivation rules the character already has access to.

In combat, a Forged Technique uses its own written entry.

The entry should include:

- activation;
- CP cost;
- range or target;
- attack roll, saving throw, or check;
- effect;
- duration;
- limits;
- drawbacks;
- backlash, if any.

If a Forged Technique lacks one of those pieces, resolve the missing piece before using it in combat.

## Emergency Forging in Combat

Emergency Forging allows a cultivator to create a one-time technique in a dangerous scene.

Emergency Forging is not normal improvisation. It requires real pressure and GM approval.

A successful Emergency Forged Technique works once and may create an Emergency Technique Seed.

A failed Emergency Forged Technique still has consequences.

Use Chapter 18 for the full Emergency Forging rules.

## Items in Combat

Items use their activation rule.

A talisman, pill, artifact, storage item, weapon, formation key, or robe might require an Action, Bonus Action, Reaction, command, consumption, or no action.

If an item does not say how it is activated, it requires an Action by default, as described in Chapter 20.

A consumable item is used up when its rule says it is used up.

An item does not grant a Sphere, talent, Recorded Art, Forged Technique, Path feature, or Method unless it says so.

## Pills in Combat

Some pills can be used during combat.

A pill’s rule tells you its activation. Most pills require an Action to consume unless the item says otherwise.

If a pill is a Cultivation pill or Enhancement pill, use the pill rules from Chapter 20, including Pill Impurity when applicable.

A creature cannot force another unwilling creature to benefit from a pill unless a rule or the GM allows it.

## Talismans in Combat

Talismans are stored commands.

A talisman’s entry tells you how to activate it and what it does.

Most combat talismans are consumable.

A talisman might attack, defend, seal, reveal, block, move, warn, cleanse, or trigger a formation.

Using a talisman does not require knowing the Talismans Sphere unless the talisman says it does.

Creating, modifying, repairing, or upgrading talismans may require the Talismans Sphere, a formula, materials, tools, teacher, facility, or crafting rule.

## Aura

A cultivator’s aura is the visible, spiritual, emotional, or pressure-like expression of their cultivation.

Aura can show strength, intent, Path, Realm pressure, corruption, injury, emotional instability, or Dao expression.

Not every aura is obvious. Some cultivators suppress, hide, veil, disguise, or refine their aura.

Aura is not a universal truth detector. It does not reveal exact statistics, exact CL, hidden features, secret talents, or private thoughts unless a rule says so.

## Reading Aura

Any creature can notice an obvious aura if the situation makes it visible.

To read useful details from an aura in a tense scene, use a printed technique, item, sense, feature, or normal ability check the GM allows. This chapter does not create a universal aura-reading action or default aura-reading DC.

A successful reading might reveal broad information, such as:

- whether the target seems above, below, or roughly equal to your Realm;
- whether the target’s aura appears injured, unstable, burdened, demonic, forbidden, distorted, concealed, suppressed, unusually pure, bodily, qi-based, or spiritual;
- whether the target is preparing a visible cultivation effect.

The source rule or GM determines what can be learned.

## Concealing Aura

Aura concealment is handled by the feature, item, Method, Sphere, disguise, circumstance, or GM ruling that allows it.

This chapter does not grant every character a universal combat action to hide aura.

Outside combat, concealing aura can be part of disguise, travel, meditation, infiltration, social play, or a specific cultivation feature if the table allows it.

Aura concealment hides pressure and signs. It does not make the creature invisible unless a rule says so.

## Killing Intent and Pressure

Some cultivators can project killing intent, spiritual pressure, command presence, demonic hunger, divine awe, or sect authority.

These effects are not automatic.

A creature can be frightening, oppressive, or impressive without imposing a condition.

To impose Frightened, Charmed, Restrained, Incapacitated, Prone, or another condition, the rule must say so.

If a character uses pressure as a social or intimidation tactic, use normal ability checks unless a technique provides specific mechanics.

## Realm Difference in Combat

Realm matters.

A higher-Realm cultivator often has better PB, higher CP, stronger techniques, better defenses, stronger Foundations, more talents, more Recorded Arts, more Forged Techniques, and better resources.

A lower-Realm character can still win through preparation, terrain, teamwork, items, knowledge, suppression, weakness exploitation, or story circumstances.

Do not assume a higher-Realm creature is invincible unless the encounter says so.

Do not assume a lower-Realm creature can fight fairly unless the mechanics support it.

## Realm Suppression in Combat

A character can voluntarily suppress Realm/CL.

Suppression is restraint, disguise, teaching, sparring, or self-limitation. It is not true equalization.

When you suppress Realm/CL:

- choose the lower CL you are suppressing to;
- use the suppressed CL’s PB;
- do not use features, talents, insights, Recorded Arts, Forged Techniques, Method features, Foundation features, item powers, or other abilities that require a higher CL or Realm;
- if an ability has a higher-Realm expression, use only the lower version available at the suppressed CL.

Suppression does not reduce:

- HP;
- Hit Dice;
- ability scores;
- maximum CP;
- passive body quality;
- passive Foundation benefits;
- injuries, scars, burdens, or consequences;
- ordinary equipment.

Suppression gives weaker opponents a chance, but the suppressed cultivator may still be physically, spiritually, and tactically superior.

## Revealing Suppressed Power

You can end voluntary Realm suppression on your turn, no action required, unless a duel rule, oath, formation, item, poison, seal, or other effect says otherwise.

Ending suppression may break the terms of a spar, tournament, sect challenge, or oath. The rules allow it, but the world may judge it.

When suppression ends, the character resumes their true CL and PB and regains access to legal higher-Realm abilities.

Ending suppression does not restore spent CP, HP, charges, reactions, or uses.

## Defensive Techniques

Many cultivators have defensive techniques.

A defensive technique might:

- reduce damage;
- increase AC;
- impose disadvantage;
- move the user;
- shield an ally;
- block a condition;
- resist forced movement;
- negate a rider;
- create temporary HP;
- counter a technique;
- redirect an attack;
- reveal a hidden attacker.

A defensive technique must say when it can be used.

If it is a Reaction, it follows the Reaction rules.

If it reduces damage, apply it at the timing written in the technique.

If the timing is unclear, apply it after the hit is confirmed but before damage is finalized.

## Damage Reduction and Resistance

Damage reduction, resistance, immunity, temporary HP, and prevention effects are different.

Use the rule as written.

If several effects apply, use the normal game rules and the specific timing in each effect.

If a technique gives a different timing, use the technique.

## Temporary HP

Temporary HP follows normal rules unless a Tianxia rule says otherwise.

Temporary HP from the same named source does not stack with itself. If you receive temporary HP from the same named source again, use the higher amount.

Temporary HP from different named sources does not stack unless a Tianxia rule says it stacks.

Some Tianxia features, especially certain Vitality-style effects, may define special stacking behavior. Use the source rule.

## Countering Techniques

Some techniques can counter, interrupt, weaken, redirect, seal, or punish other techniques.

A counter technique must say:

- what it can counter;
- when it can be used;
- what action it costs;
- whether it requires a roll;
- what happens on success;
- what happens on failure.

You cannot counter any technique just because you understand its theme.

If no counter rule applies, use ordinary defenses such as saving throws, AC, movement, cover, resistance, or tactics.

## Cover, Terrain, and Position

Terrain matters.

Cultivation does not erase the battlefield unless a rule says so.

Walls, trees, rooftops, cliffs, rivers, streets, spirit pools, formations, fog, darkness, ruins, pressure zones, difficult terrain, and altitude can all matter.

A technique might ignore some terrain, but not all terrain by default.

Flying does not automatically ignore spiritual pressure. Teleporting does not automatically bypass wards. Burrowing does not automatically pass through formation foundations. Phasing does not automatically ignore seals.

Use the source rule.

## Environmental Cultivation Hazards

Some battlefields contain cultivation hazards.

Examples include:

- spirit pressure;
- poisoned mist;
- demonic residue;
- sword intent fields;
- unstable formations;
- tribulation lightning;
- corrupted pools;
- burning qi vents;
- dream fog;
- graveyard yin;
- beast territory;
- sect ward pressure.

A hazard should define:

- when it triggers;
- what roll it requires, if any;
- what happens on success;
- what happens on failure;
- whether it can be avoided, suppressed, cleansed, or exploited.

If a hazard matters mechanically, write it down.

## Nonlethal Defeat

A cultivator can attempt to defeat an enemy without killing them.

Use the normal nonlethal damage rules when applicable.

Some techniques can also restrain, seal, exhaust, knock out, disarm, disable, suppress, or force surrender without killing. The technique must say what it does.

Nonlethal victory can matter for AP, sect law, reputation, rivalries, karma, and future burdens if a rule, adventure, or GM reward says it does.

## Surrender, Mercy, and Face

Combat in Tianxia is often social as well as physical.

Surrender, mercy, humiliation, restraint, and public victory can matter.

A spared rival may become:

- an ally;
- an enemy;
- a witness;
- a debtor;
- a future challenge;
- a sect complication;
- a source of AP if an AP rule applies.

A defeated enemy’s reaction depends on the fiction, the faction, and the campaign.

The PHB does not require every combat to end in death.

## Consequences in Combat

Hidden injuries, deviations, burdens, scars, Pill Impurity, Exhaustion, and other consequences can affect combat.

Use the consequence record.

A consequence should tell you:

- what it affects;
- when it triggers;
- what penalty, cost, risk, or benefit applies;
- how long it lasts;
- how it can be treated, repaired, purified, or integrated.

Do not invent a penalty during combat unless the consequence, hazard, or GM ruling establishes it.

## Death, Defeat, and Survival

Tianxia uses normal death and dying rules unless a rule says otherwise.

Cultivation can create unusual survival effects, such as:

- last-stand techniques;
- refusal-to-drop features;
- emergency pills;
- spirit intervention;
- body refinement endurance;
- soul escape;
- life-saving talismans;
- artifact protection;
- sect rescue.

These effects work only if the character has the rule, item, or feature.

Do not assume every cultivator can escape death.

## Combat Outside Initiative

Not every dangerous scene needs initiative.

A duel of pressure, a formation escape, a chase, a stealth raid, a negotiation under killing intent, a ritual interruption, or a spirit trial can use checks, scenes, or ordinary roleplay.

Use initiative when turn order matters.

Use scenes when the important question is broader than individual turns.

The same cultivation rules still apply: pay CP, use the correct action scale, follow item rules, and record consequences.

## Player Combat Checklist

On your turn, ask:

1. What is my objective?
2. Am I using a normal action, a technique, an item, or movement?
3. What action does it require?
4. What CP, charge, use, item, or drawback does it cost?
5. Does it require an attack roll, saving throw, or check?
6. What happens on success?
7. What happens on failure?
8. Does it trigger a consequence, backlash, Pill Impurity, or Exhaustion?
9. Does it last until the end of my turn, next turn, a round, a minute, or the scene?
10. Do I need to record anything?

## Summary

Tianxia combat is still 5.5e combat.

Cultivation adds Path resources, Spheres, Recorded Arts, Forged Techniques, items, aura, Realm pressure, consequences, and stranger battlefields.

The most important combat rule is simple:

**Use the source rule.**

If a technique, item, scar, burden, Method, Foundation, or Sphere says how it works, follow that rule. If it does not, use the normal rules or resolve the missing field before use.

---

# 22. Exploration, Travel, Sects, and Downtime

Cultivation is not only combat.

A cultivator trains, studies, travels, bargains, gathers materials, enters ruins, accepts sect missions, visits markets, seeks teachers, investigates omens, repairs injuries, reads manuals, and prepares for breakthroughs.

This chapter explains how Tianxia handles the parts of play between battles.

Use the normal 5.5e rules for travel, exploration, social play, downtime, tools, ability checks, hazards, and rests unless a Tianxia rule says otherwise.

## The Cultivation Loop

Most Tianxia campaigns move through a repeated loop.

1. **Adventure.** The party explores, fights, negotiates, investigates, survives, or completes missions.
2. **Gain resources.** Characters gain AP, materials, items, manuals, access, favors, scars, burdens, or information.
3. **Train.** Characters learn Spheres, talents, Recorded Arts, Forged Techniques, Methods, or other options.
4. **Recover.** Characters treat hidden injuries, reduce Pill Impurity, correct deviations, resolve burdens, or stabilize consequences.
5. **Prepare.** Characters gather breakthrough support, seek teachers, cleanse impurities, refine resources, or study a route.
6. **Break through.** When ready, characters attempt a new CL or Realm breakthrough.

Not every session uses every step. Some campaigns focus on sect life, some on wandering, some on ruins, some on politics, and some on duels.

## Exploration Scenes

An exploration scene is a meaningful stretch of play focused on a place, hazard, route, ruin, wilderness, city, sect, tomb, spirit site, or other location-based challenge.

Examples include:

- crossing a demon-beast forest;
- navigating a ruined formation hall;
- searching a market for rare materials;
- exploring a cave inheritance;
- moving through hostile sect territory;
- surviving a poison swamp;
- climbing a sword-scarred mountain;
- investigating a spirit village;
- entering a restricted scripture hall;
- escaping a collapsing trial ground.

A scene usually lasts until the objective changes, the location changes meaningfully, the party rests, or the GM declares that a new scene has begun.

## Travel

Use normal travel rules unless a Tianxia feature changes them.

Tianxia travel may include:

- roads;
- rivers;
- mountain paths;
- flying mounts;
- caravans;
- sect escorts;
- spirit boats;
- cloud platforms;
- teleportation arrays;
- formation roads;
- hidden passes;
- dangerous wilderness;
- forbidden zones;
- demon-beast territories;
- spirit weather;
- unstable ruins.

A travel route can matter as much as the destination.

A safe road may require tolls, paperwork, sect tokens, or clan permission. A dangerous route may offer rare herbs, hidden caves, ancient bones, or faster travel.

## Travel Resources

Travel can use ordinary and cultivation resources.

Common travel resources include:

- food and water;
- mounts;
- tents;
- maps;
- spirit stones;
- talismans;
- medicine;
- storage items;
- sect identification tokens;
- beast repellent;
- formation keys;
- guide contracts;
- weather protection;
- local favors.

A character's cultivation can help, but it does not automatically replace preparation. A flying technique does not feed the party. A storage ring does not create supplies. A high Realm does not make local politics vanish.

## Cultivation During Travel

Characters can cultivate while traveling only when the situation allows it.

Rough travel, danger, pursuit, harsh weather, unstable qi, cramped vehicles, crowded roads, and watch duty can make deep cultivation impossible.

Light exercises, breathing practice, scripture memorization, weapon forms, meditation, note review, and minor qi circulation may still be possible.

A full cultivation session requires the rules from Chapter 16. It is not automatic during travel unless the party has time, safety, and space.

## Spirit Sites

A **spirit site** is a place where the world's power is unusually concentrated, distorted, pure, dangerous, or meaningful.

Examples include:

- spirit springs;
- lightning peaks;
- sword-intent cliffs;
- ancient battlefields;
- yin graveyards;
- sacred trees;
- demon caves;
- dragon veins;
- immortal ruins;
- cursed villages;
- blessed temples;
- hidden grottos;
- tribulation craters;
- ancestral halls;
- formation nexuses.

Spirit sites can support cultivation, create hazards, hide treasures, attract rivals, or provide clues.

A spirit site does not automatically grant AP, Enlightenment, materials, or bonuses. Its specific rule, scene, or reward determines what it offers.

## Hazards Outside Combat

Exploration hazards work like hazards in combat: they must tell you what they do if they matter mechanically.

A hazard might be:

- poisonous mist;
- corrupted qi;
- freezing yin;
- burning yang;
- sword pressure;
- spiritual noise;
- dream fog;
- beast territory;
- unstable formations;
- collapsing ruins;
- cursed water;
- false manuals;
- soul echoes;
- hunger aura;
- demon residue.

A hazard should define:

- what triggers it;
- whether a check or saving throw applies;
- what happens on success;
- what happens on failure;
- whether it can be avoided, suppressed, cleansed, endured, studied, harvested, or transformed.

If a hazard has no mechanics, treat it as description until it matters.

## Gathering Materials

Characters can gather cultivation materials during exploration.

Materials may include:

- spirit herbs;
- rare flowers;
- mushrooms;
- ores;
- spirit wood;
- beast cores;
- bones;
- venom;
- blood;
- scales;
- feathers;
- shell;
- incense wood;
- mineral powder;
- spirit dew;
- old formation fragments;
- broken talismans;
- relic shards.

Gathering may require tools, proficiency, Spheres, knowledge, safe handling, time, or a suitable container.

A material is only useful if it can be preserved, transported, identified, and matched to a recipe, buyer, or project.

## Harvest Lots

A **Harvest Lot** is a usable batch of gathered material.

A Harvest Lot might come from a monster, plant, mine, spirit site, ruin, market, or mission reward.

The item book, adventure, GM Screen, or AI tool can define Harvest Lot quantity, quality, tags, value, and use.

In the PHB, the important rule is simple:

**A Harvest Lot is useful only when a rule, recipe, buyer, project, or GM says how it can be used.**

## Sects

A **sect** is a cultivation organization.

A sect may be a school, clan, temple, academy, military order, merchant power, hidden lineage, wandering alliance, demonic hall, monastic order, formation city, imperial bureau, or other organized cultivation group.

Sects provide structure and conflict.

A sect can offer:

- teachers;
- Methods;
- manuals;
- Recorded Arts;
- scripture halls;
- training grounds;
- missions;
- pills;
- talismans;
- artifacts;
- materials;
- rivals;
- protection;
- laws;
- trials;
- ranks;
- obligations;
- punishments.

Sects are not only shops. They are social worlds.

## Sect Rank and Access

A character's sect rank can control what they can use.

Sect rank may affect access to:

- scripture halls;
- pill stores;
- medicine gardens;
- trial grounds;
- formation chambers;
- teacher instruction;
- missions;
- sect tokens;
- equipment;
- housing;
- restricted areas;
- forbidden archives;
- elder audiences;
- protected travel routes;
- sect markets;
- auction sponsorship.

A character may know that a resource exists and still not be allowed to use it.

Access can be earned through missions, rank, teacher approval, tournament results, payment, favors, oaths, family connections, or story events.

## Sect Tokens and Contribution

Many sects use contribution systems.

Contribution may be represented by tokens, tallies, marks, ledgers, favors, rank, mission credit, or elder approval.

Contribution can be spent or used to request:

- pills;
- materials;
- library time;
- teacher guidance;
- formation-room access;
- healing;
- lodging;
- travel papers;
- crafting facilities;
- trial entry;
- item repair;
- market sponsorship.

Contribution is not the same as money. It represents trust, service, standing, and usefulness to the sect.

## Missions

A sect mission is a task assigned or offered by a sect, clan, teacher, city, faction, or patron.

Missions may include:

- gathering herbs;
- escorting caravans;
- hunting beasts;
- guarding a village;
- investigating ruins;
- delivering letters;
- protecting a junior;
- scouting a rival;
- clearing a formation fault;
- collecting debt;
- winning a tournament;
- retrieving a lost manual;
- testing an inheritance;
- negotiating with spirits;
- punishing a criminal cultivator.

Missions can reward AP, materials, items, tokens, manuals, reputation, access, favors, or information.

A mission can also create burdens, rivals, hidden injuries, consequences, or future obligations.

## Scripture Halls and Libraries

A scripture hall is one of the most important places in a cultivation campaign.

A scripture hall may contain:

- manuals;
- Recorded Arts;
- Method fragments;
- Foundation theory;
- maps;
- warnings;
- formation diagrams;
- pill recipes;
- beast records;
- histories;
- sect laws;
- forbidden shelves;
- elder annotations;
- damaged jade slips;
- incomplete inheritances.

Access to a scripture hall can be more valuable than treasure.

A player should not assume they can read everything. Rank, permission, time, language, seals, comprehension, danger, and sect law may limit what can be studied.

## Teachers

A teacher can provide guidance that a book cannot.

A teacher might help with:

- training a Sphere;
- learning a talent;
- understanding a Recorded Art;
- correcting a Method;
- repairing a hidden injury;
- identifying a deviation;
- choosing a Foundation route;
- preparing for a breakthrough;
- interpreting a tribulation scar;
- finding materials;
- understanding a manual's false route.

Teacher access is a reward.

A teacher may require payment, service, loyalty, proof, rank, respect, compatibility, or a personal promise.

## Manuals and Study Time

Manuals, jade slips, murals, inheritance tablets, and cultivation journals require time to understand.

A learning object might be simple, clear, cryptic, dangerous, partial, false, too advanced, sealed, or written for another route.

The rules for Recorded Arts are in Chapter 15.

The rules for training Spheres, talents, and other options are in the relevant chapters.

A learning object does not grant a benefit just because the character owns it. The character must meet the rule for learning, training, or unlocking what it contains.

## Downtime

Downtime is time spent outside immediate danger.

During downtime, characters may:

- train;
- cultivate;
- recover;
- craft;
- gather information;
- shop;
- sell materials;
- copy manuals;
- repair items;
- treat injuries;
- reduce impurities;
- seek teachers;
- perform sect duties;
- complete rituals;
- research enemies;
- make contacts;
- prepare for travel;
- study a spirit site;
- work on a Forged Technique;
- attempt a recovery project;
- prepare for a breakthrough.

Downtime still belongs to the campaign. Rivals act, sect politics move, auctions end, seasons change, wounds worsen, and opportunities disappear.

## Training During Downtime

Training rules are covered in the chapters for Spheres, talents, Recorded Arts, and Forged Techniques.

As a reminder:

- each training day requires 8 total hours;
- training hours can be split if the table allows it;
- the normal training time for Spheres, talents, and Recorded Arts is `1d6 + PB - Intelligence or Wisdom modifier`, minimum 2 days;
- Intelligence training represents technical study, formulas, diagrams, theory, tactics, and structured analysis;
- Wisdom training represents meditation, body-feel, intuition, Dao comprehension, perception, and spiritual attunement.

A character must still meet all prerequisites.

## The Three Trained Choices

At each CL, a character can make up to 3 trained choices.

A trained choice may be used to learn a new Sphere, learn a talent, or take another option allowed by the relevant rule.

The free talent gained from leveling is separate. The bonus talent gained when learning a new Sphere is also separate.

Training requires time, effort, and a successful check when the rule calls for one.

## Cultivation Sessions and Downtime

A cultivation session is not the same as general training.

A cultivation session takes 2 uninterrupted hours and restores your full Path resource once per long rest unless a rule says otherwise.

Training is the work of learning new abilities, studying manuals, refining techniques, or changing the character.

A character may do both during downtime if the schedule allows it.

## Recovery During Downtime

Downtime is often when characters recover from cultivation consequences.

A character might use downtime to:

- treat hidden injuries;
- stabilize deviations;
- resolve burdens;
- integrate scars;
- reduce Pill Impurity;
- recover from Exhaustion;
- repair damaged items;
- correct a Method problem;
- repair Foundation strain;
- seek medical help;
- find cleansing materials.

Use the rules from Chapter 19 and any specific consequence.

A consequence is not removed just because time passes unless its rule says so.

## Breakthrough Preparation

Downtime is the usual time to prepare for breakthroughs.

Preparation might include:

- meditation;
- teacher guidance;
- pill use;
- medicinal baths;
- scripture study;
- spirit-site cultivation;
- cleansing impurities;
- repairing injuries;
- resolving burdens;
- completing a manual section;
- studying an Enlightenment Record;
- gathering materials;
- stabilizing a Method;
- strengthening a Foundation.

Only a preparation that gives a concrete rule benefit modifies a breakthrough.

A good story does not automatically grant a bonus. A real preparation benefit should say what it gives.

## Markets

Cultivation markets are places where resources move.

A market may sell:

- pills;
- talismans;
- herbs;
- ores;
- beast parts;
- manuals;
- rumors;
- maps;
- weapons;
- robes;
- spirit stones;
- information;
- crafting access;
- healing services;
- formation keys;
- illegal items.

Not every market sells everything.

Availability depends on location, season, law, sect influence, war, supply, reputation, rank, contacts, and price.

## Auctions

An auction is a high-stakes market event.

Auctions can involve rare manuals, beast cores, ancient relics, high-grade pills, spirit herbs, formation flags, divine metals, maps, or inheritance clues.

An auction can create:

- rivals;
- debts;
- bargains;
- theft attempts;
- public reputation;
- secret deals;
- sect pressure;
- legal trouble;
- story hooks.

Buying an item at auction may require more than money. A bidder may need standing, sponsorship, secrecy, intimidation, or political support.

## Reputation and Face

Reputation affects access.

A character's public actions can influence:

- teacher willingness;
- sect rank;
- market access;
- auction invitations;
- mission offers;
- rival challenges;
- clan support;
- legal attention;
- spirit responses;
- demonic suspicion;
- public fear or respect.

Reputation does not need a universal score in the PHB. Use faction records, roleplay, mission outcomes, and specific rewards or consequences.

## Favors, Debts, and Oaths

Cultivation societies run on relationships.

A character may owe or receive:

- favors;
- debts;
- vows;
- oaths;
- teacher promises;
- family obligations;
- sect duties;
- spirit bargains;
- rival agreements;
- karma;
- face debts;
- rescue debts.

A favor can be more valuable than an item.

A debt can become a burden if it has lasting pressure or consequence.

Use Chapter 19 if a debt becomes a formal Burden.

## Forbidden Access

Forbidden things are not always hidden because they are weak.

They may be hidden because they are dangerous, illegal, corruptive, politically explosive, socially condemned, or spiritually costly.

Forbidden access might involve:

- demonic manuals;
- taboo pills;
- corpse tools;
- forbidden blood arts;
- sealed relics;
- spirit-binding items;
- illegal talismans;
- corrupt formations;
- cannibal cultivation;
- curse techniques;
- dangerous inheritances.

Obtaining a forbidden item or teaching can create consequences even before it is used.

The item, manual, faction, or GM determines the actual risk.

## Information as Treasure

Information can be treasure.

Useful information includes:

- a map to a ruin;
- the weakness of a beast;
- the true name of a spirit;
- the flaw in a rival's technique;
- the location of a medicine garden;
- the hidden requirement of a manual;
- the history of a scar;
- the safe route through a formation;
- the legal status of a relic;
- the schedule of an auction;
- the identity of a teacher;
- the cause of a deviation.

Information may grant access, reduce danger, enable training, support crafting, or create breakthrough preparation if a rule says it does.

## Urban Exploration

Cities matter in Tianxia.

A city may contain:

- markets;
- mortal guilds;
- hidden cultivators;
- temples;
- formation defenses;
- clan estates;
- sect offices;
- black markets;
- spirit shrines;
- auction houses;
- physician halls;
- courier stations;
- monster arenas;
- forbidden alleys;
- official courts;
- poor districts;
- mortal politics.

Mortal cities should not disappear from the campaign. Cultivators depend on food, labor, information, trade, craftsmen, roads, families, laws, and ordinary people.

A cultivator who ignores mortal society may still be affected by it.

## Ruins and Inheritances

Ruins and inheritances are common cultivation adventures.

A ruin may contain:

- broken formations;
- sealed rooms;
- spirit echoes;
- manuals;
- pills;
- corpses;
- artifacts;
- tests;
- false paths;
- guardian beasts;
- old karma;
- damaged treasure;
- traps;
- hidden teachers;
- incomplete Methods;
- hostile remnants.

An inheritance should not be only a pile of items. It can be a test, relationship, lesson, curse, route, debt, or transformation.

A character may leave a ruin stronger, injured, marked, obligated, or changed.

## Trials

A trial is a structured challenge.

Trials may test:

- combat;
- survival;
- restraint;
- courage;
- comprehension;
- memory;
- loyalty;
- mercy;
- perception;
- formation knowledge;
- endurance;
- Dao understanding;
- teamwork;
- temptation.

A trial can be created by a sect, teacher, spirit, ruin, artifact, formation, ancestor, or world event.

Trial rewards may include AP, access, manuals, items, Enlightenment, rank, scars, or recognition.

Trial failures may create injuries, burdens, deviations, lost access, or new routes.

## Player Downtime Checklist

During downtime, ask:

1. What am I trying to accomplish?
2. How many days do I have?
3. Am I training, recovering, crafting, studying, socializing, shopping, traveling, or preparing?
4. What rule governs this activity?
5. What resource, teacher, item, manual, facility, or permission do I need?
6. What check is required, if any?
7. What happens if I succeed?
8. What happens if I fail?
9. Does this affect my next breakthrough?
10. Does this create a record, item, favor, debt, injury, burden, or clue?

## Summary

Cultivation grows between battles.

The disciple who trains carefully, studies old records, treats injuries, earns sect access, gathers materials, honors debts, reads the right manual, and chooses the right teacher may become stronger before drawing a blade.

Exploration finds opportunity.  
Travel creates pressure.  
Sects control access.  
Downtime turns resources into growth.  
Information becomes treasure.  
Consequences become routes.

The path is not only what you can do in combat. It is what you do with the time, places, people, and resources that cultivation gives you.

---

# 23. Social Play, Reputation, Karma, and Factions

Cultivation is social.

A cultivator’s strength matters, but so do teachers, rivals, clans, sects, vows, debts, face, reputation, law, taboo, mercy, betrayal, and public victory.

A character may win a duel and lose face. They may spare a rival and gain a future ally. They may steal a manual and become hunted. They may uphold an oath and earn a teacher’s trust. They may use Forbidden power and survive the battle, only to face judgment afterward.

This chapter explains how Tianxia handles social play and faction life.

Use normal 5.5e rules for social interaction, ability checks, roleplay, factions, NPC reactions, and consequences unless a Tianxia rule says otherwise.

## No Universal Reputation Score

This chapter does not create a universal reputation, face, karma, honor, infamy, or faction-point score.

Different campaigns need different levels of social detail.

A wandering campaign may track only major debts and enemies. A sect campaign may track rank, teachers, factions, forbidden acts, library access, and political alliances. A clan campaign may care about bloodline, marriage, inheritance, elders, and family reputation.

Use the records the campaign needs.

If a rule, faction, adventure, item, burden, or background gives a specific score or status, use that rule.

## Social Records

Social consequences should be written down when they matter.

A useful social record includes:

- name;
- faction, person, or group involved;
- relationship type;
- current status;
- what caused it;
- benefit, access, or restriction;
- obligation, debt, or risk;
- how it can change.

Not every conversation needs a record. Record the ones that affect future play.

## Reputation

**Reputation** is what others know, believe, suspect, or say about a character.

Reputation can be local, sect-wide, regional, secret, public, false, earned, inherited, or fabricated.

A character might be known as:

- a promising junior;
- a sect disgrace;
- a loyal disciple;
- a dangerous rogue;
- a demonic cultivator;
- a tournament victor;
- a coward;
- a reliable escort;
- a thief;
- a healer;
- a genius;
- an oathbreaker;
- a survivor of tribulation;
- a teacher’s favorite;
- a forbidden-art user.

Reputation affects access. It can influence who teaches you, who trades with you, who challenges you, who trusts you, and who watches you.

Reputation does not automatically give a bonus or penalty unless a rule says so.

## Face

**Face** is public standing, dignity, credibility, and social position.

Face matters most when others are watching.

A character can gain face by:

- winning fairly;
- showing restraint;
- honoring a teacher;
- completing a mission;
- displaying rare skill;
- protecting juniors;
- defeating a stronger foe;
- accepting responsibility;
- surviving a public trial;
- giving proper respect;
- repaying debts.

A character can lose face by:

- breaking a promise;
- cheating openly;
- humiliating the wrong person;
- failing a public duty;
- showing cowardice;
- insulting an elder;
- mishandling a sect matter;
- revealing weakness;
- using taboo power;
- losing control in public;
- violating hospitality.

Face is not the same as morality. A cruel cultivator may have high face. A kind cultivator may lose face by violating sect custom.

If face matters mechanically, the relevant faction, scene, burden, mission, or GM ruling should explain the effect.

## Factions

A **faction** is an organized social force.

Factions include:

- sects;
- clans;
- temples;
- academies;
- imperial offices;
- merchant houses;
- demonic halls;
- wandering alliances;
- city governments;
- guilds;
- mortal noble houses;
- beast tribes;
- spirit courts;
- hidden lineages;
- teacher circles;
- rebel groups;
- criminal societies;
- auction houses;
- ancient inheritances.

A faction can offer resources, protection, missions, status, enemies, restrictions, and obligations.

A faction is not only a quest board. It has memory, interests, rivals, rules, internal politics, and people who benefit from or oppose the characters.

## Faction Records

A faction record can track the party’s relationship with a faction.

A simple faction record includes:

- faction name;
- known leaders;
- known allies;
- known rivals;
- what the faction wants;
- what the faction offers;
- current relationship;
- access granted;
- restrictions or enemies;
- debts or obligations;
- major incidents involving the party.

This is a campaign record, not a universal numerical system.

A faction record can be as simple as:

> Crimson River Sect: suspicious but willing to trade. Party saved one patrol, offended one elder, and owes a favor to Disciple Lan.

## Sect Law

Sects have rules.

Sect law may govern:

- duels;
- theft;
- manual access;
- teacher respect;
- forbidden arts;
- killing juniors;
- harming mortals;
- leaving territory;
- trading sect materials;
- using sect techniques outside permission;
- accepting outside teachers;
- auction participation;
- marriage alliances;
- mission failure;
- defection;
- corpse handling;
- demonic cultivation;
- spirit contracts.

Sect law is not always fair. It protects the sect’s power, reputation, secrets, and hierarchy.

A character can violate sect law knowingly, accidentally, secretly, or publicly. The consequence depends on the sect, the rule, the witnesses, and the character’s standing.

## Clans and Families

Clans and families matter in cultivation society.

A clan may provide:

- name recognition;
- bloodline access;
- wealth;
- marriage ties;
- tutors;
- bodyguards;
- manuals;
- political pressure;
- rivals;
- expectations;
- inheritance disputes;
- forbidden obligations.

A character’s family can be a source of support, burden, conflict, or danger.

Family status does not automatically grant mechanics unless a background, feature, faction record, or story reward says so.

## Teachers and Disciples

Teacher relationships are central to cultivation.

A teacher may provide:

- instruction;
- correction;
- protection;
- criticism;
- secrets;
- tests;
- recommendations;
- manuals;
- Method access;
- Foundation advice;
- breakthrough preparation;
- faction sponsorship;
- political danger.

A teacher may require:

- respect;
- service;
- secrecy;
- obedience;
- repayment;
- proof of talent;
- moral conduct;
- sect loyalty;
- personal loyalty;
- a vow.

A teacher is not just a training bonus. A teacher is a relationship.

## Seniors and Juniors

Many cultivation societies care about seniority.

A senior may have higher rank, older entry, greater Realm, teacher lineage, clan status, official title, or battlefield achievement.

A junior may owe respect, but not blind obedience unless the sect or relationship says so.

Seniority can affect:

- forms of address;
- mission command;
- library access;
- dormitory status;
- public challenge rights;
- punishment;
- protection;
- responsibility for weaker disciples.

Characters should know when they are acting as juniors, peers, seniors, guests, outsiders, or rivals.

## Rivals

A **rival** is someone whose path repeatedly crosses the character’s path.

A rival may be hostile, friendly, respectful, petty, lethal, romantic, political, or ideological.

A rival can:

- challenge the character;
- expose flaws;
- steal resources;
- protect the character from worse enemies;
- force improvement;
- become a future ally;
- become a burden;
- become a witness;
- become a source of AP if a rule applies.

A rival is different from a random enemy. A rival matters again.

## Enemies

An enemy seeks to harm, stop, exploit, shame, hunt, or destroy the character.

Enemies can be personal, factional, political, spiritual, karmic, demonic, legal, or inherited.

An enemy might arise from:

- killing someone;
- sparing someone;
- public humiliation;
- stealing an item;
- revealing a secret;
- betraying a faction;
- refusing a marriage;
- breaking an oath;
- using Forbidden power;
- winning a tournament;
- accepting the wrong teacher;
- surviving an inheritance.

Enemy records should note who is hostile, why, what they can do, and what might change the relationship.

## Favors and Debts

A **favor** is help owed or expected.

A **debt** is an obligation created by help, rescue, teaching, protection, payment, oath, bargain, or social pressure.

A debt can be informal or formal.

An informal debt affects roleplay and future access.

A formal debt may become a Burden if it has lasting mechanical or story pressure.

Examples:

- “I saved your life; speak for me before the elder.”
- “I taught you this Method; do not pass it to outsiders.”
- “I paid your auction deposit; bring me the herb you find.”
- “I hid your Forbidden technique; you owe me silence later.”

A debt should be recorded if it can shape future play.

## Oaths and Vows

An **oath** or **vow** is a serious promise.

It may be personal, sect-bound, spirit-bound, blood-bound, Dao-bound, teacher-bound, or witnessed by Heaven.

Most oaths are roleplaying commitments unless a rule gives them mechanics.

A formal oath may create a Burden, grant access, unlock a technique, satisfy a teacher, bind an item, or affect a breakthrough if a rule says so.

Breaking an oath can create consequences.

Possible consequences include:

- lost trust;
- faction hostility;
- teacher rejection;
- loss of access;
- public shame;
- a Burden;
- a deviation;
- spirit anger;
- karmic pressure;
- item rejection;
- forbidden backlash.

Use the oath’s own rule if it has one.

## Karma

**Karma** is the weight of actions, debts, cause and effect, spiritual attention, fate, resentment, gratitude, vows, and unresolved ties.

This chapter does not create a universal karma score.

Karma matters when a rule, faction, spirit, oath, burden, item, inheritance, tribulation, or campaign event makes it matter.

Karma may appear as:

- a debt;
- a curse;
- a blessing;
- a spirit tie;
- a rival;
- a recurring omen;
- a burden;
- a tribulation mark;
- a faction consequence;
- a future opportunity;
- a hidden price.

Karma should not be used to punish every choice. It should make important choices echo.

## Mercy and Cruelty

Mercy matters in Tianxia.

Sparing an enemy can create:

- gratitude;
- humiliation;
- debt;
- rivalry;
- suspicion;
- future mercy;
- political risk;
- witness testimony;
- sect approval;
- sect disapproval.

Cruelty can create:

- fear;
- obedience;
- revenge;
- reputation;
- demonic suspicion;
- legal consequences;
- rival hatred;
- karmic pressure;
- public face;
- loss of teacher trust.

Neither mercy nor cruelty is automatically rewarded. The result depends on the scene, witnesses, culture, faction, and character involved.

## Public Duels

A duel is often social as well as martial.

A public duel can decide:

- rank;
- face;
- legal guilt;
- marriage pressure;
- teacher recognition;
- sect access;
- tournament standing;
- resource ownership;
- apology;
- revenge;
- public credibility.

Before a duel, the table should know the stakes.

Important questions include:

- Is the duel lethal?
- Is surrender allowed?
- Are items allowed?
- Are talismans allowed?
- Are poisons allowed?
- Is Realm suppression required?
- Are outside techniques restricted?
- Who judges the result?
- What happens to the loser?
- What happens if someone cheats?

A duel without clear stakes can still be dramatic, but a duel with clear stakes creates stronger consequences.

## Hospitality and Guest Rights

Hospitality can matter.

A sect, clan, city, or teacher may grant guest status.

Guest status can provide:

- lodging;
- food;
- temporary protection;
- audience rights;
- market access;
- trial access;
- library restrictions;
- escort;
- safe passage;
- ritual courtesy.

Guest status can also create limits.

A guest may be forbidden to duel, spy, enter sealed areas, trade certain items, approach juniors, inspect formations, or leave without notice.

Violating hospitality can damage reputation and create enemies.

## Secrets

Secrets are social resources.

A secret might be:

- a hidden Foundation flaw;
- a Forbidden technique;
- a demonic inheritance;
- a teacher’s true identity;
- a manual’s false route;
- a clan scandal;
- a spirit pact;
- a hidden injury;
- a stolen item;
- a disguised Realm;
- an illegal auction;
- a hidden relationship.

Secrets can protect, empower, expose, or endanger a character.

A secret becomes mechanical only if a rule, consequence, faction, item, or scene gives it an effect.

## Disguise, Lies, and Concealment

Use normal ability checks and source rules for disguise, lies, forged identities, hidden aura, concealed items, false rank, and secret travel.

A character might use:

- Charisma (Deception);
- Dexterity (Stealth);
- Intelligence checks for documents, seals, or procedure;
- Wisdom checks for reading others;
- tools;
- items;
- Sphere talents;
- Recorded Arts;
- Forged Techniques;
- Methods;
- faction access.

A lie does not succeed because it is clever. It succeeds when the table resolves it through roleplay, evidence, checks, or source rules.

## Intimidation and Pressure

A character can threaten, posture, release aura, show killing intent, display a weapon, reveal a Realm, use a title, or invoke a faction.

These are social actions unless a source rule gives them combat mechanics.

Pressure, killing intent, spiritual weight, command presence, or Realm oppression does not impose a condition or penalty by default.

To impose Frightened, Charmed, Incapacitated, movement loss, disadvantage, damage, suppression, or another mechanical effect, a source rule must say so.

## Social Techniques

Some techniques affect social scenes.

A technique might:

- reveal lies;
- conceal identity;
- project authority;
- calm emotions;
- frighten enemies;
- bind promises;
- read memories;
- contact spirits;
- disguise aura;
- carry messages;
- mark a target;
- expose corruption;
- enforce a vow.

A social technique works only as written.

A technique that influences another creature may require a saving throw, contest, check, consent, or limitation. Use the source rule.

## Forbidden Reputation

Forbidden power has social weight.

A character known to use Forbidden power may face:

- fear;
- temptation;
- secret interest;
- blackmail;
- punishment;
- exile;
- execution orders;
- demonic recruitment;
- market exclusion;
- sect investigation;
- teacher rejection;
- rival challenges;
- restricted item access.

Forbidden reputation is not always bad for every audience. Some factions may respect, desire, excuse, or exploit it.

The risk depends on who knows, what they believe, and what power they have.

## Demonic Reputation

Demonic reputation is not one thing.

A demonic-core cultivator, demonic Method user, predatory chakra refiner, native demonic-plane being, corpse-art practitioner, blood devourer, and falsely accused rival may all be treated differently depending on the culture.

The important question is not only “is this demonic?”

The important questions are:

- Who knows?
- What do they think demonic means?
- What law applies?
- What proof exists?
- Who benefits from accusation?
- Who protects the accused?
- What has the character actually done?

Use the campaign’s demon definitions and faction law.

## Mortal Society

Mortal society still matters.

Cultivators depend on mortal cities, farmers, roads, craftsmen, healers, servants, officials, merchants, families, soldiers, artists, priests, and witnesses.

A cultivator’s choices can affect mortals.

Protecting mortals may build reputation. Ignoring them may create resentment. Exploiting them may draw law, karma, rivals, or sect action.

A high-Realm cultivator may be powerful, but they still live in a world with food, labor, politics, trade, rumor, and memory.

## Social Rewards

Social play can create rewards.

Possible rewards include:

- access;
- teacher guidance;
- library permission;
- mission offers;
- faction support;
- safe lodging;
- market invitations;
- auction sponsorship;
- favors;
- information;
- legal protection;
- witnesses;
- apologies;
- marriage negotiations;
- alliances;
- debt cancellation;
- burden resolution;
- AP if a rule says so.

A social reward should be clear enough that the player knows what changed.

## Social Consequences

Social play can also create consequences.

Possible consequences include:

- lost access;
- faction suspicion;
- public shame;
- rival hostility;
- teacher disappointment;
- mission denial;
- market exclusion;
- legal judgment;
- sect punishment;
- family pressure;
- oath consequences;
- debt escalation;
- bounty;
- blackmail;
- demonic suspicion;
- a formal Burden.

A consequence should be written down if it matters after the scene.

## Player Social Checklist

When a social scene matters, ask:

1. Who is involved?
2. What do they want?
3. What do they believe about me?
4. What do I want from them?
5. What can I offer?
6. What am I risking?
7. Is this public, private, secret, or witnessed?
8. Does sect law, rank, guest status, oath, debt, or reputation matter?
9. What happens if I succeed?
10. What happens if I fail?

## Summary

Cultivation is never only personal power.

A cultivator stands inside a web of teachers, rivals, sects, clans, spirits, debts, laws, favors, witnesses, rumors, and oaths.

Strength opens doors.  
Face keeps them open.  
Reputation changes who waits behind them.  
Karma makes choices echo.  
Factions remember.  
Teachers test.  
Rivals return.  
Debts come due.

The path is not walked alone, even by those who claim to walk alone.

---

# Common Player Records and Templates

These templates help players write down the parts of Tianxia that can matter later.

A template does not create a new rule. It records a rule, item, relationship, consequence, technique, preparation, or permission that already exists in the campaign. If a source rule gives different details, use the source rule.

You do not need to fill every line. Record only what helps the table remember what the character can do, what they owe, what they carry, and what might matter in a later scene.

## Character Start Checklist

Use this checklist when creating or reviewing a character.

### Core Identity

| Field | Notes |
|---|---|
| Character Name |  |
| Path | Body Refining, Qi Cultivation, or Spirit Awakening. |
| CL and Realm |  |
| Path Key Ability |  |
| Maximum CP | Use the character's current Path resource rule and Method, if any. |
| Foundation |  |
| Method |  |
| Background |  |
| Sect, Clan, Teacher, or Lineage |  |

### Cultivation Options

| Field | Notes |
|---|---|
| Known Spheres |  |
| Known Talents |  |
| Recorded Arts |  |
| Forged Techniques |  |
| Important Items |  |
| Current Consequences | Hidden injuries, deviations, burdens, scars, strain, Pill Impurity, Exhaustion, or similar records. |
| Important Social Records | Favors, debts, enemies, allies, teachers, faction status, or oaths. |

### Opening Questions

| Question | Answer |
|---|---|
| What does this character seek? |  |
| Who taught them or shaped their path? |  |
| Who do they owe? |  |
| What would make them bow? |  |
| What would make them draw a blade? |  |
| What is their immediate cultivation goal? |  |

## Training Record

Use this record when training a Sphere, talent, Recorded Art, Forged Technique, or other learnable option.

| Field | Notes |
|---|---|
| Training Goal |  |
| Type | Sphere, talent, Recorded Art, Forged Technique, Method change, recovery project, or other rule. |
| Source | Teacher, manual, jade slip, sect hall, spirit site, personal practice, item, consequence, or other source. |
| Ability Used | Intelligence, Wisdom, or another ability if the rule says so. |
| Training Time |  |
| Check or DC |  |
| Materials or Access Needed |  |
| Result on Success |  |
| Result on Failure |  |
| Date / Session Completed |  |

## Breakthrough Preparation Record

Use this record for preparations that may affect a breakthrough.

Only record a preparation here if it gives a concrete benefit, removes a concrete penalty, satisfies a requirement, or creates a specific risk. AP itself is tracked through advancement, not this preparation record.

| Field | Notes |
|---|---|
| Breakthrough Attempt | New CL or Realm. |
| Current CL / Target CL |  |
| Path Key Ability |  |
| Cultivation Check Modifier |  |
| Breakthrough DC |  |
| Meditation Completed | Yes / No, if using the basic breakthrough meditation rule. |
| Preparation Name |  |
| Source | Teacher, pill, Method, Foundation, manual, spirit site, item, consequence, or other rule. |
| Benefit | Bonus, Enlightenment die, reroll, Advantage, penalty removal, permission, protection, or other printed benefit. |
| Limit or Cost |  |
| Risk |  |
| Notes |  |

## Enlightenment Record

Use this record for Enlightenment dice and related breakthrough insights.

Enlightenment dice do not expire or become spent by default. If a specific rule says a die is temporary, limited, consumed, or restricted, write that rule here.

| Field | Notes |
|---|---|
| Enlightenment Name |  |
| Source | Failure, teacher, manual, trial, tribulation, emergency forging, spirit site, scar, or other source. |
| Die | d4, d6, d8, d10, or other value if a rule says so. |
| What Was Learned |  |
| Limits or Conditions | Only if the granting rule gives one. |
| Cost or Risk | Only if the granting rule gives one. |
| Related Breakthrough, if any |  |

## Consequence Record

Use this record for hidden injuries, deviations, burdens, cultivation scars, cultivation strain, Pill Impurity, Exhaustion, and other lasting effects.

| Field | Notes |
|---|---|
| Consequence Name |  |
| Type | Hidden Injury, Deviation, Burden, Cultivation Scar, Cultivation Strain, Pill Impurity, Exhaustion, or other printed type. |
| Source | Breakthrough, technique, item, pill, Method, Foundation, tribulation, hazard, oath, social event, or other source. |
| Mechanical Effect | What changes in play. |
| Trigger | When the effect matters, if not constant. |
| Duration |  |
| Recovery, Purification, Repair, or Integration | Use the consequence's own rule. |
| Unstable? | Yes / No. If yes, write the escalation trigger. |
| Possible Benefit | Only if the consequence or GM reward defines one. |
| Visible, Hidden, Secret, or Known |  |
| Notes |  |

## Item Record

Use this record for important items, consumables, talismans, manuals, jade slips, artifacts, spirit-stone stores, formation keys, and story relics.

| Field | Notes |
|---|---|
| Item Name |  |
| Type | Ordinary equipment, consumable, talisman, material, manual, artifact, infrastructure key, story relic, or other type. |
| Physical Form |  |
| Rarity / Availability |  |
| Requirement | CL, Realm, Path, Sphere, sect permission, binding, command word, or other requirement if any. |
| Activation | Action, Bonus Action, Reaction, passive, ritual, command, consumption, formation use, or other source-rule timing. |
| Effect |  |
| Cost, Charge, or Use Limit |  |
| Risk or Drawback |  |
| Owner / Status | Personal, borrowed, sect-owned, stolen, inherited, restricted, or unknown. |
| Notes |  |

## Harvest Lot Record

Use this record for gathered materials that may be useful later.

Harvest Lot quantity, quality, tags, value, and use come from the item book, adventure, GM Screen, AI tool, or GM ruling. This record only preserves what the party knows.

| Field | Notes |
|---|---|
| Harvest Lot Name |  |
| Source | Beast, plant, mine, spirit site, ruin, market, mission reward, or other source. |
| Material Type | Herb, ore, beast core, venom, bone, scale, spirit dew, relic fragment, or other material. |
| Known Traits | Fire-aspected, poisonous, pure, unstable, demonic, moonlit, ancient, damaged, or other known traits. |
| Preservation Needed |  |
| Known Use | Recipe, crafting project, sale, trade, treatment, talisman, formation, or unknown. |
| Quantity / Quality / Value | Use only if defined by the campaign source. |
| Notes |  |

## Recorded Art Record

Use this record for a fixed technique learned from a manual, jade slip, mural, inheritance, journal, or similar source.

A Recorded Art grants only the fixed technique it says it grants. It does not grant the source Sphere, source talent, or permission to modify the technique unless a rule says so.

| Field | Notes |
|---|---|
| Recorded Art Name |  |
| Source Object or Teacher |  |
| Difficulty | If defined. |
| CL or Realm Requirement |  |
| Required Path, Sphere, Talent, Method, Foundation, or Item | Only if the art says so. |
| Activation |  |
| CP Cost or Other Cost |  |
| Range / Target / Area |  |
| Roll or Save |  |
| Effect |  |
| Duration |  |
| Limit, Drawback, or Backlash |  |
| Learned at CL |  |
| Notes |  |

## Forged Technique Record

Use this record for a custom technique created through the Forged Technique rules.

A Forged Technique must be built from legal Sphere expressions and cultivation rules the character can access. The record should be complete before the technique is used in combat.

| Field | Notes |
|---|---|
| Technique Name |  |
| Base Form | Strike, Projection, Movement, Burst, Cone, Line, Ward, Aura, Zone, Counter, Ritual, or other approved form. |
| Source Expressions | Sphere base abilities, talents, Path features, or approved substitutes used to build it. |
| Spheres Used |  |
| Complexity |  |
| CP Cost |  |
| Activation |  |
| Range / Target / Area |  |
| Roll or Save |  |
| Effect |  |
| Duration |  |
| Augments |  |
| Drawbacks |  |
| Backlash, if any | Define the trigger and consequence. |
| Technique-Forging DC |  |
| Research Time / Materials |  |
| Learned at CL |  |
| Notes |  |

## Emergency Technique Seed Record

Use this record only when a successful Emergency Forged Technique creates a seed for later study.

An Emergency Technique Seed is not a learned Forged Technique. It is a discovered route that can help formalize that exact technique later.

| Field | Notes |
|---|---|
| Seed Name |  |
| Scene Created |  |
| Crisis or Pressure |  |
| Expressions Combined |  |
| Path and Spheres Involved |  |
| One-Time Effect | What happened in the scene. |
| CP Cost or Risk Paid |  |
| Flaw, Instability, or Backlash |  |
| Decisive? | Yes / No. |
| Enlightenment Granted? | Only if a rule or GM reward granted one. |
| Later Study Benefit | Usually Advantage on formalizing that exact technique, if Chapter 18's rule applies. |
| Notes |  |

## Social Record

Use this record for important favors, debts, promises, teachers, rivals, enemies, guest status, public reputation, secrets, or social consequences.

| Field | Notes |
|---|---|
| Record Name |  |
| Person or Group |  |
| Relationship Type | Favor, debt, oath, rival, enemy, teacher, guest status, secret, reputation, or other relationship. |
| Current Status |  |
| Cause | What created the relationship or consequence. |
| Benefit or Access |  |
| Obligation, Risk, or Restriction |  |
| Public, Private, Secret, or Witnessed |  |
| How It Can Change |  |
| Notes |  |

## Faction Record

Use this record for sects, clans, temples, academies, merchant houses, city governments, spirit courts, demonic halls, hidden lineages, or other organized social forces.

This is not a universal faction-point system. It records the relationship as the campaign defines it.

| Field | Notes |
|---|---|
| Faction Name |  |
| Type | Sect, clan, temple, academy, government, merchant house, spirit court, hidden lineage, or other faction. |
| Known Leaders |  |
| Known Allies |  |
| Known Rivals or Enemies |  |
| What the Faction Wants |  |
| What the Faction Offers |  |
| Current Relationship |  |
| Access Granted | Library, teacher, market, mission, lodging, protection, healing, trial, or other access. |
| Restrictions or Risks |  |
| Debts or Obligations |  |
| Major Incidents |  |
| Notes |  |

## Breakthrough Result Record

Use this record after a breakthrough attempt.

| Field | Notes |
|---|---|
| Character |  |
| Attempted CL / Realm |  |
| AP Before Attempt |  |
| Breakthrough DC |  |
| Cultivation Check Result |  |
| Preparations Used |  |
| Enlightenment Dice Used |  |
| Success or Failure |  |
| New CL / Realm, if successful |  |
| AP After Failure, if failed | Use the Chapter 17 failure rule. |
| Consequences | Hidden injury, deviation, burden, scar, strain, tribulation result, or other source-rule consequence. |
| Rewards or Unlocks | Only if a rule, feature, or GM reward grants one. |
| Notes |  |

## Closing Note

These templates are tools for memory and clarity. They do not replace the source rules. If a record and a rule disagree, use the rule.

---

# Backmatter Glossary

This glossary defines the main terms used in the Tianxia Player Handbook. If a rule gives a more specific definition for a feature, item, Sphere, Method, Foundation, or consequence, use that source rule.

## A

**Active Scar.** A Cultivation Scar with a trigger, penalty, benefit, warning, or other mechanical effect. Use the scar's own record or source rule.

**Advantage.** The normal game mechanic for rolling two d20s and using the higher result.

**AP.** Attainment Points. AP measure progress toward a new Cultivation Level.

**Artifact.** A powerful item with lasting cultivation significance. Artifacts can be weapons, robes, vessels, bells, mirrors, rings, flags, cauldrons, towers, or stranger treasures.

**Attainment Points.** See **AP**.

**Aura.** The visible, spiritual, emotional, or pressure-like expression of a cultivator’s power. Aura can show broad signs such as Realm pressure, injury, corruption, intent, or Dao expression, but it is not a universal truth detector and does not reveal exact statistics unless a rule says so.

## B

**Background Sphere.** A Sphere granted by a background at CL 1. It does not count against level talents, trained choices, or the new-Sphere bonus.

**Background Talent.** A talent granted by a background at CL 1. It does not count against level talents, trained choices, or the new-Sphere bonus.

**Base Form.** The basic shape of a Forged Technique, such as a strike, projection, movement effect, ward, aura, zone, counter, or ritual. Use Chapter 18 for the current Base Form rules.

**Binding.** The process by which a character becomes able to use a specific item, artifact, formation key, or treasure. Binding exists only when an item or rule says it does. The PHB does not create a universal binding limit.

**Body Refining.** One of the three cultivation Paths. Body Refiners use Constitution, d12 Hit Dice, and Stamina as their CP resource.

**Bottleneck.** A point where cultivation progress stalls until the character gains enough AP, correction, insight, preparation, training, recovery, resource access, or story opportunity.

**Breakthrough.** The attempt to advance to a new CL or Realm.

**Burden.** A lasting physical, spiritual, karmic, social, emotional, sect-related, or metaphysical pressure carried by a character.

## C

**CL.** Cultivation Level. A character’s level in Tianxia.

**Closed-Door Cultivation.** Withdrawing from ordinary activity to focus deeply on training, study, healing, or breakthrough preparation. Closed-door cultivation is not a separate rule by itself; use the relevant training, recovery, downtime, or breakthrough rules.

**Consequence Record.** A written record of a hidden injury, deviation, burden, scar, strain, or other cultivation consequence that can affect future play.

**Core Formation.** The Realm covering CL 10–14.

**Cultivation.** The process of refining yourself beyond ordinary mortal limits through body, qi, spirit, understanding, Method, Foundation, techniques, and Dao expression.

**Cultivation Attack Modifier.** `PB + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Check.** A check using `d20 + PB + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Points (CP).** A Path's spendable cultivation resource: Stamina, Qi, Resonance, or another explicitly defined pool.

**Cultivation Economy.** The economy of cultivation resources: spirit stones, pills, manuals, jade slips, herbs, beast cores, formation materials, talismans, refined metals, spiritual inks, safe meditation sites, and rare opportunities.

**Cultivation Effect.** Any supernatural, internal, spiritual, qi-based, stamina-based, resonance-based, or Dao-shaped effect created by cultivation.

**Complexity.** A Forged Technique construction value measuring how much the technique is trying to do. Complexity limits what can be created; CP cost determines how often the technique can be used.

**Cultivation Journal.** A record of a cultivator’s observations, experiments, theories, failures, insights, and techniques. A journal may contain true doctrine, partial truth, misunderstanding, hidden Recorded Arts, Method clues, or dangerous errors.

**Cultivation Pill.** A pill that directly advances, accelerates, or forces cultivation progress. Cultivation pills use the pill safety and Pill Impurity rules from Chapter 20 when applicable.

**Cultivation Save DC.** The save DC used by Tianxia cultivation features when a source rule calls for it and does not give another DC: `8 + PB + Path key ability modifier`.

**Cultivation Scar.** A lasting mark left by cultivation pressure, failure, tribulation, or transformation. A scar can be only a record, an active consequence, or a scar-boon if a rule grants a benefit.

**Cultivation Session.** See **Full Cultivation Session**.

**Cultivation Strain.** Temporary or unstable pressure on a character’s cultivation. Strain should have a clear trigger, effect, and duration or recovery condition.

**Cultivator.** Someone who trains beyond ordinary mortal limits.

## D

**Dao.** A principle, path, truth, or way of understanding cultivation. In broader use, Dao can also suggest the deep pattern or course of reality.

**Dao Aspect.** A late-game immortal principle, such as Destruction, Binding, Restoration, Fate, Time, Soul, or Heaven, used in DM-facing and late-game rules to construct Immortal Arts. Dao Aspects are not ordinary early-cultivation player mechanics.

**Dao Heart.** A cultivator’s inner conviction and relationship to their path. Dao Heart is not a universal PHB score unless a specific rule gives it mechanics.

**Daoist Friend.** A polite address for another cultivator, usually outside one’s sect.

**Deviation.** A harmful instability, distortion, imbalance, corruption, or dangerous change in how a character’s cultivation flows. A Deviation is not proof that the character’s Dao is wrong; it is a mechanical danger or instability.

**Drawback.** A limitation added to a Forged Technique to reduce its CP cost. Drawbacks reduce CP cost, not Complexity, and must meaningfully restrict the technique.

**Disadvantage.** The normal game mechanic for rolling two d20s and using the lower result.

## E

**Elder.** A senior authority in a sect, clan, temple, academy, or lineage.

**Emergency Forged Technique.** A one-time technique created under real danger and pressure using the Emergency Forging rules.

**Emergency Forging.** The Chapter 18 procedure for creating a one-time technique in a dangerous scene. Emergency Forging is not normal improvisation and requires real pressure and GM approval.

**Emergency Technique Seed.** The recorded route, concept, flaw, and discovery left by a successful or meaningful Emergency Forged Technique. It can help later attempts to formalize that exact technique if the rules allow it.

**Enhancement Pill.** A pill that temporarily increases performance, combat power, cultivation output, or technique expression. Enhancement pills use the pill safety and Pill Impurity rules from Chapter 20 when applicable.

**Enlightenment.** A meaningful breakthrough of understanding, insight, or Dao comprehension. When a rule grants an Enlightenment die, record its source, die size, and any limits.

**Enlightenment Die.** A die, such as d4, d6, d8, or d10, recorded from an Enlightenment source and used for breakthrough-related rules. Enlightenment dice do not expire or get spent by default unless their granting rule says so.

**Enlightenment Record.** A written record of an Enlightenment source, its die size if any, and any limits, costs, risks, or conditions attached to it.

**Exhaustion.** The normal game condition for severe fatigue and strain. Tianxia adds CP exhaustion: each time you are reduced to 0 CP, you gain 1 level of Exhaustion.

## F

**Face.** Public standing, dignity, credibility, and social position. Face has no universal score in the PHB; use a specific faction, scene, burden, mission, or rule if it has a mechanical effect.

**Forbidden.** A tag or description for power, items, methods, techniques, inheritances, or practices that are taboo, illegal, corruptive, predatory, socially condemned, spiritually dangerous, or otherwise restricted. Forbidden does not mean unusable; it means the source rule, world, or faction may demand a price.

**Faction.** An organized social force such as a sect, clan, temple, academy, merchant house, demonic hall, imperial office, guild, spirit court, hidden lineage, or similar group.

**Faction Record.** A campaign record for a faction’s relationship with the party or a character. A faction record is not a universal numerical system unless a specific campaign rule makes it one.

**Failure-Born Option.** A special Insight, route, correction, Method, Foundation change, Recorded Art comprehension, scar benefit, or other option that becomes available because of a specific failure, consequence, or survival event. It appears only when a rule, feature, condition, or GM reward says it appears.

**Fellow Daoist.** A polite address for another cultivator, especially outside one’s sect.

**Forged Technique.** A custom technique created from legal Sphere expressions and cultivation rules the character already has access to.

**Forged Technique Record.** A written entry for a Forged Technique, including activation, CP cost, range or target, roll or save, effect, duration, limits, drawbacks, and backlash if any.

**Foundation.** The cultivation architecture or base that supports future growth.

**Foundation Realm.** The Realm covering CL 5–9.

## G

**GM.** Game Master.

**Guest Status.** A social position granted by a host, sect, clan, city, teacher, or faction. Guest status may grant access, protection, courtesy, or restrictions depending on the source.

## H

**Harvest Lot.** A usable batch of gathered material, such as herbs, beast parts, ore, venom, spirit dew, or relic fragments. Quantity, quality, tags, value, and use are defined by the item book, adventure, GM Screen, AI tool, or GM.

**Heart Demon.** An inner obstruction, obsession, fear, guilt, temptation, trauma, or spiritual knot that interferes with cultivation. A Heart Demon has mechanics only if a rule, consequence, burden, Method, Foundation, scene, or GM-facing procedure gives it mechanics.

**Heavenly Tribulation.** A dangerous trial, pressure, correction, recognition, or transformation that may appear during major cultivation moments.

**Hidden Injury.** Damage inside a character’s cultivation, such as harm to meridians, dantian, soul, spirit, body, Foundation, Method route, or CP circulation.

## I

**Immortal Art.** A high-Realm technique that elevates a legal source effect through a Dao Aspect and other late-game construction rules. Immortal Arts are not normally available during early cultivation.

**Inheritance.** A preserved legacy left by a cultivator, sect, spirit, ruin, ancestor, artifact, or ancient power. It may be generous, dangerous, incomplete, testing, deceptive, cursed, or tied to old karma.

**Integrate.** To make a consequence part of a character’s cultivation through a printed rule, Foundation, Method, Insight, Recorded Art, spirit pact, tribulation result, failure-born option, or GM-approved route.

**Item Record.** A written entry for an item, usually including name, type, requirement, activation, effect, uses or cost, limits or risks, and notes.

## J

**Jade Slip.** A cultivation record, usually magical or spiritual, that can store a manual, journal, Recorded Art, Method text, memory, map, theory, or other teaching.

**Junior.** Someone below another character in rank, entry order, Realm, office, generation, or social status in the current context.

**Junior Disciple.** A gender-neutral or formal same-sect address for a disciple below you in rank, entry order, or status.

## K

**Karma.** The weight of actions, debts, cause and effect, spiritual attention, fate, resentment, gratitude, vows, and unresolved ties. Karma has no universal PHB score; it matters when a rule, faction, spirit, oath, burden, item, inheritance, tribulation, or campaign event makes it matter.

## L

**Learning Object.** A manual, jade slip, diagram, mural, cultivation journal, ancestor recording, formation map, inheritance record, or similar item that can teach or reveal cultivation information.

**Level Talent.** The free talent gained at each CL. At CL 1, the sect-trial talent counts as the character's level talent unless another rule says otherwise.

**Long Rest.** The normal game rest. Body Refiners regain all missing Stamina. Qi Cultivators and Spirit Awakeners regain half their maximum Path resource. A Long Rest refreshes Path recovery limits.

## M

**Manual.** A source that preserves cultivation knowledge. A manual may teach Recorded Arts, explain a Method, preserve a lineage, record theory, describe a Foundation, or serve as a training source.

**Marked Scar.** A visible or spiritual Cultivation Scar with no mechanical effect unless another rule refers to it.

**Master.** A personal teacher or acknowledged instructor.

**Method.** The main way a character’s cultivation circulates, stabilizes, and develops.

**Multi-Path Cultivator.** A character who legally possesses more than one complete Path progression.

**Mortal Economy.** The ordinary economy of food, silver, salt, iron, cloth, animals, roads, boats, timber, labor, taxes, tools, houses, and services.

**Mortal Realm.** The Realm covering CL 1–4.

## N

**Nascent Soul.** The Realm covering CL 15–19.

**New-Sphere Bonus Talent.** The free talent gained when a character successfully learns a new Sphere.

## O

**Oath.** A serious promise. An oath may be personal, sect-bound, spirit-bound, blood-bound, Dao-bound, teacher-bound, or witnessed by Heaven. Most oaths are roleplaying commitments unless a specific rule gives them mechanics.

**Origin Insight.** An early character-defining Insight connected to origin, background, body, spirit, memory, route, or unusual inheritance. Use the rules in the Origin Insights chapter.

## P

**Path.** A character's CL 1-20 cultivation chassis. The three orthodox Paths are Body Refining, Qi Cultivation, and Spirit Awakening.

**Path Key Ability Modifier.** The ability modifier used by a character’s Path for Cultivation Checks, Cultivation Save DCs, and other Path-based rules.

**PB.** Proficiency Bonus.

**PHB.** Player Handbook.

**Pill.** A consumable cultivation aid, usually governed by Alchemy, item, or sect-resource rules. A pill only grants the benefit printed in its description.

**Pill Impurity.** Residue from forcing cultivation through pills. Each Pill Impurity gives a `-1` penalty to breakthrough checks until removed by a rule or treatment.

**Powering Path.** The recorded Path whose resource and cultivation mathematics power a feature when more than one Path could legally do so.

**Pressure.** A broad descriptive term for aura, killing intent, spiritual weight, Realm oppression, command presence, sword intent, demonic hunger, or similar force. Pressure has no automatic mechanical effect unless a source rule gives it one.

**Purify.** To remove corruption, impurity, poison, residue, demonic influence, or spiritual contamination from a consequence, item, body, route, or site.

## Q

**Qi.** The active, refinable expression of power in the world. It is also the Qi Cultivation CP resource. Context tells you whether the word means general world energy or a Qi Cultivator’s spendable resource.

**Qi Cultivation.** One of the three cultivation Paths. Qi Cultivators use Intelligence or Charisma, d8 Hit Dice, and Qi as their CP resource.

**Qi Deviation.** See **Deviation**.

## R

**Realm.** A major stage of cultivation. The standard player-facing Realms are Mortal, Foundation, Core Formation, Nascent Soul, and True Immortality / final standard Realm.

**Realm Breakthrough.** A breakthrough into a new Realm, such as CL 5, CL 10, CL 15, or CL 20.

**Realm Suppression.** Voluntarily suppressing Realm or CL for sparring, teaching, disguise, restraint, or another reason. Suppression is restraint, not true equalization.

**Recorded Art.** A fixed named technique learned from a manual, jade slip, scripture, journal, mural, inheritance, or similar source. A Recorded Art does not grant its component Spheres or talents as flexible options.

**Recorded Art Record.** A written entry for a Recorded Art, including source, requirements, activation, CP cost, effect, duration, and limits.

**Recovery Project.** Focused downtime spent purifying, repairing, or integrating a cultivation consequence.

**Repair.** To heal damage, restore structure, seal cracks, correct circulation, or stabilize what was harmed.

**Reputation.** What others know, believe, suspect, or say about a character. Reputation has no universal PHB score and does not automatically give a bonus or penalty unless a rule says so.

**Reputation Economy.** The economy of access and face: merit, contribution, sect standing, titles, vows, favors, karmic debts, grudges, teacher recognition, tournament reputation, and secret obligations.

**Resonance.** The Spirit Awakening CP resource. In broader world terms, resonance is also the way qi answers meaning, intention, spirit, memory, and pattern.

## S

**Scar-Boon.** A Cultivation Scar that grants a benefit because a rule, tribulation result, Foundation, Method, Insight, or GM reward says it does. A Scar-Boon is not automatic.

**Scene.** A single continuous stretch of play focused on one conflict, challenge, investigation, negotiation, journey segment, or other meaningful situation. A scene usually lasts until the immediate situation is resolved, the location or objective meaningfully changes, the party takes a rest, or the GM declares that a new scene has begun.

**Sect.** A cultivation organization, school, clan, temple, academy, military order, merchant power, hidden lineage, wandering alliance, demonic hall, monastic order, formation city, imperial bureau, or other organized cultivation group.

**Sect Rank.** A character’s standing or office within a sect. Sect rank may affect access, permission, duties, and social expectations.

**Sect Token.** A sect credit, reward, or accounting unit used by some sects to control access to manuals, rooms, pills, teachers, missions, and other resources.

**Sect-Trial Dao Sphere.** A Sphere granted through CL 1 sect initiation and trial structure. The associated talent counts as the CL 1 level talent unless a rule says otherwise.

**Sect-Trial Talent.** The talent gained from the sect-trial Dao Sphere. This talent counts as the character's CL 1 level talent unless another rule says otherwise.

**Secret.** A tag or description for a hidden, inherited, lineage-protected, restricted, or specially taught option. Secret is not the same as Forbidden unless the source rule says it is both.

**Senior.** Someone above another character in rank, entry order, Realm, office, generation, or social status in the current context.

**Senior Disciple.** A gender-neutral or formal same-sect address for a disciple above you in rank, entry order, or status.

**Short Rest.** The normal game rest. Body Refiners regain half maximum Stamina twice between Long Rests. Qi Cultivators and Spirit Awakeners regain CP equal to their Path CL once per Long Rest.

**Social Record.** A written record of an important social relationship, consequence, debt, status, access, or restriction. A social record should be used only when the relationship can affect future play.

**Source CL.** The authority level of a cultivation source, normally equal to the effective CL used to activate it unless a rule says otherwise.

**Source Rule.** The rule that gives a technique, item effect, feature, consequence, or other mechanical benefit. When in doubt, use the source rule.

**Sphere.** A field of cultivation expression, such as Sword, Fire, Dreams, Talismans, Spirit Companions, or another legal Sphere.

**Spirit Awakening.** One of the three cultivation Paths. Spirit Awakeners use Wisdom, d8 Hit Dice, and Resonance as their CP resource.

**Spirit Site.** A place where the world’s power is unusually concentrated, distorted, pure, dangerous, or meaningful. A spirit site does not automatically grant AP, Enlightenment, materials, or bonuses unless a rule says so.

**Spirit Stone.** A condensed cultivation resource used as payment, fuel, crafting material, training support, or recovery aid when a rule gives it an effect.

**Stamina.** The Body Refining CP resource.

**Subpath.** The universal term for a Path-specific progression gained at CL 3, with later features at CL 6, 10, 14, and 18.

**Suppression.** See **Realm Suppression**.

## T

**Talent.** A specific ability learned within a Sphere.

**Technique.** A broad table term for any combat-relevant Path feature, Sphere base ability, Sphere talent, Recorded Art, Forged Technique, item effect, or other cultivation ability. A technique does not grant its underlying Sphere, talent, or modification rights unless a rule says so.

**Technique Forging.** The Chapter 18 procedure for creating a Forged Technique. Technique Forging normally becomes available at Foundation Realm unless a rule allows an exception.

**Technique-Forging Check.** A Cultivation Check made to complete, refine, or emergency-forge a technique when the Technique Forging rules require one.

**Technique-Forging DC.** The DC for a Technique-Forging Check, calculated by the rule in Chapter 18 unless a source rule gives another value.

**Training Check.** A check made to learn a Sphere, talent, Recorded Art, or other learnable option when the relevant training rule requires one.

**Training Day.** A unit of 8 total hours of meaningful training. The hours can be split if the table allows it.

**Training Source.** A teacher, manual, site, item, memory, spirit, trial, or other source that supports learning when the relevant rule requires or rewards one.

**Trained Choice.** One of the up to 3 trained selections a character can make at each CL under the training rules.

**Treatment Day.** A unit of 8 total hours spent on a Recovery Project or other treatment. The hours can be split if the table allows it.

**Tribulation.** See **Heavenly Tribulation**.

**True Immortality / Final Standard Realm.** The Realm represented by CL 20 in the core PHB.

## U

**Unstable.** A tag for a consequence that can worsen if its listed trigger occurs.

## V

**Vow.** A serious promise similar to an oath. Use the rule of the vow, burden, item, Method, teacher, spirit, sect, or faction that created it.

---

