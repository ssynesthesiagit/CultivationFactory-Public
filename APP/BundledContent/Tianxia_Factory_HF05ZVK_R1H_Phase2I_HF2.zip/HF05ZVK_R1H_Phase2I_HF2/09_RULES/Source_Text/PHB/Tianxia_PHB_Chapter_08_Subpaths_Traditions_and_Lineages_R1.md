# 08. Subpaths, Traditions, and Cultivation Lineages

A **Subpath** is the specialized progression through which a Path becomes a particular school, scripture, tradition, inheritance, lineage, method, or law. Your Path establishes the cultivation chassis. Your Subpath establishes the distinctive route you follow within that Path.

Body Refining calls many of its Subpaths **Schools**, **Bodies**, **Scriptures**, or **Inheritances**. Qi Cultivation uses names such as **Schools**, **Scriptures**, **Lineages**, **Variants**, and **Secret Laws**. Spirit Awakening commonly calls them **Traditions**. These are local names for the same rules structure.

This chapter explains how to choose a Subpath, how access works, how multi-Path cultivators progress, how parent and Variant progressions replace one another, and how Source CL and Realm Suppression affect Subpath features. The complete rules for individual options appear in the separate Path compendia.

## The Subpath Progression

Each active Path provides one Subpath progression.

| Cultivation Level | Subpath event |
|---:|---|
| **3** | Choose one legal Subpath for that Path and gain its CL3 features. |
| **6** | Gain its CL6 features. |
| **10** | Gain its CL10 features. |
| **14** | Gain its CL14 features. |
| **18** | Gain its CL18 features. |

A Subpath feature is a Path feature. It uses that Path's key ability, Cultivation Save DC, Cultivation Attack Modifier, Cultivation Points, and other Path rules unless the feature expressly states otherwise.

A Subpath does not grant a Sphere, talent, Foundation, Method, item, companion, office, bloodline, or Recorded Art merely because its theme resembles one. It grants only the rules it prints.

## Choosing a Subpath at CL3

When you reach CL3, complete the following steps for each Path you possess.

1. **Choose the Path slot.** Identify the Path whose Subpath you are selecting.
2. **Choose a legal option.** Select one Subpath from that Path's compendium for which you have legal access.
3. **Record the access source.** Record the teacher, sect permission, lineage, inheritance, shrine, relic, mutation, revelation, pact, manual, office, corruption event, or other Source Rule that grants access.
4. **Record classifications and tags.** Record the Subpath's access class and any Inherited, Variant, Daemonic, bloodline, spirit, organizational, or other printed tag.
5. **Gain the CL3 features.** Add every feature, resource, state, Asset, Anchor, transformation, companion interface, or procedure granted at CL3.
6. **Add executable records.** Any activated, triggered, passive, procedural, or state-based feature must be represented on the character record in the form required by its rules.

### Delayed Selection

A character who reaches CL3 without legal access to a Subpath does not invent an access source or ignore the requirement. Leave that Path's Subpath slot unfilled.

When the character later gains legal access, select the Subpath and immediately gain all of its features through the character's current effective CL. Delaying selection does not grant a second Subpath, extra features, or compensation.

### Changing a Subpath

A Subpath is not ordinary retraining. Changing it requires an explicit Source Rule, a parent-to-Variant conversion, or a story procedure that identifies what happens to the former progression. A rest, downtime payment, or change of preference is not enough by itself.

## One Subpath per Active Path

A character has one Subpath slot for each complete Path they possess.

- A Body Refiner has one Body Refining Subpath.
- A Qi Cultivator has one Qi Cultivation Subpath.
- A Spirit Awakener has one Spirit Awakening tradition.
- A multi-Path cultivator has one Subpath progression for each active Path.

A character cannot place two Subpaths in the same Path slot unless a Source Rule expressly grants a second complete progression. Copying, mirroring, stealing, simulating, temporarily invoking, or reproducing one feature does not grant another Subpath slot.

A Foundation, Method, Insight, Sphere, talent, item, Recorded Art, or Immortal Art can interact with a Subpath without becoming a second Subpath.

## Access Classes

The first five entries below are universal access classes. **Inherited** and **Variant** are relationship tags that can appear alongside an access class.

| Access class or tag | Player-facing meaning |
|---|---|
| **Open** | Commonly teachable or institutionally available. Open does not mean weak, free, or automatically known. A teacher, manual, school, sect, or other legal route may still be required. |
| **Restricted** | Controlled by a sect, clan, shrine, profession, military office, technical discipline, hazardous practice, political authority, or other gatekeeping institution. Record who granted permission and any continuing obligation. |
| **Rare** | Requires an uncommon source such as unusual anatomy, bloodline, mutation, reincarnated memory, spirit ancestry, relic fusion, singular teacher, exceptional environment, or unique inheritance. |
| **Forbidden** | Condemned, coercive, predatory, destabilizing, illegal, corruptive, or spiritually hazardous. Access requires an explicit source and does not erase legal, social, karmic, medical, or cultivation consequences. Forbidden does not automatically mean Daemonic. |
| **Secret** | Hidden law-level, singular, or high-authority cultivation requiring explicit discovery and every printed initiation price, oath, permanent mark, sacrifice, condition, or limitation. Knowledge that a Secret exists is not access to it. |
| **Inherited** | The progression is received through ancestry, reincarnation, awakening, mutation, relic or spirit integration, an ancestor, a bloodline, an existing bodily or spiritual structure, or another nonordinary transmission. Inherited is normally paired with Open, Restricted, Rare, Forbidden, or Secret. It is not automatically removable, teachable, or transferable. |
| **Variant** | The progression is an alternate form of a named parent Subpath. It occupies the parent's slot and replaces the parent features identified by its relationship rules. Variant is not a bonus overlay. |

### Related Tags

A compendium can print additional tags such as **Daemonic**, **Bloodline**, **Spirit-Bound**, **Organizational**, or **Martial Tradition**. A tag matters only where another rule refers to it.

The **Daemonic** tag does not itself define access. It matters for Corruption, purification, anti-daemonic effects, cultivation deviations, social consequences, and other rules that expressly refer to Daemonic cultivation.

## Legal Access Sources

Every Restricted, Rare, Forbidden, Secret, or Inherited selection must name a legal access source. An Open selection should also record how the character learned it.

A legal access source must be specific enough that a player, GM, or AI can answer the following questions without invention:

| Record field | Required information |
|---|---|
| **Source** | The teacher, manual, inheritance, sect, shrine, relic, spirit, bloodline, mutation, office, event, or other rule granting access. |
| **Authority** | Why that source can grant this particular Subpath. |
| **Access class and tags** | Open, Restricted, Rare, Forbidden, Secret, Inherited, Variant, and any additional printed tags. |
| **Price or obligation** | Training, permission, oath, offering, material cost, permanent price, taboo, service, corruption, injury, or other printed requirement. Record `None` when no special price exists. |
| **Continuing condition** | Any rule that can suspend, revoke, corrupt, transform, or end access. Record `None` when access is permanent and unconditional. |
| **Source CL** | The Source CL of the access effect when the access rule requires an authority comparison. |

Money, downtime, a thematically similar Sphere, or a successful generic check does not create access unless a rule establishes that route.

### Losing Permission and Losing the Progression

Loss of social permission does not automatically erase learned cultivation. A sect can outlaw, punish, expel, or refuse support without deleting features already integrated into the character.

A progression is suppressed, transformed, damaged, or removed only when an explicit rule says so. Secret prices, pacts, vows, spirit relationships, living inheritances, offices, and artifact bonds may print continuing conditions that differ from ordinary instruction.

## Minimum CL, Realm, and Source CL

The normal minimum CL for selecting a Subpath is CL3. Its later features require CL6, CL10, CL14, and CL18 respectively.

A Subpath can print an additional minimum Realm, Source CL, anatomy, Sphere, talent, Foundation, Method, relationship, office, bloodline, or story requirement. Those requirements are cumulative. Reaching the normal feature level does not waive them.

### Feature Source CL

Unless a feature states otherwise, a Subpath feature's Source CL equals the effective CL used to activate or sustain it.

Source CL measures cultivation authority when the feature collides with suppression, reconstruction, permanent harm, an Asset, Anchor, Field, Formation, Domain, route, Gate, possession, exorcism, or another high-authority effect. It does not replace the printed attack roll, saving throw, check, damage, duration, or target procedure.

### Access Source CL

An access source has a Source CL only when its rule needs one. A teacher does not need to be permanently stronger than the student merely to teach an Open school. An inheritance, Secret Law, living relic, bloodline awakening, corruption, or contested transfer can require a particular Source CL or authority comparison when its rule says so.

The Source CL that granted access and the Source CL of a later feature are separate values. Record both where both matter.

## Multi-Path Subpath Progression

A multi-Path character has one character CL. Every complete Path the character possesses advances at that CL.

For each Path:

- choose one legal Subpath at CL3 or when the Path is gained at CL3 or higher;
- gain that Subpath's features through the character's current CL;
- use that Path's key ability, Cultivation Save DC, attack modifier, and Cultivation Point pool;
- track that Subpath's resources, states, Assets, Anchors, transformations, and procedures separately unless a rule expressly combines them.

### Adding a Path after CL3

When a character gains a new Path at CL3 or higher:

1. gain the new Path's core features through the current CL;
2. choose one legal Subpath for that Path;
3. gain the selected Subpath's features through the current CL;
4. record all legal access sources and dependencies;
5. create the required executable and display records.

Adding a Path does not grant another character-level Ability Score Improvement, Cultivation Insight choice, level talent, Background benefit, or sect-trial benefit.

### Cross-Path Interaction

A feature belongs to the Path that grants it. It does not spend another Path's Cultivation Points or use another Path's key ability unless it expressly says so.

A Body transformation, Qi Field, and Spirit Domain can coexist when their individual rules allow it. Coexistence does not merge their action economy, Concentration, Source CL, or resources.

## Parent and Variant Progressions

A **parent Subpath** is the base progression named by a Variant. A **Variant** is an alternate progression of that parent.

### The Same Slot

A Variant occupies the same Subpath slot as its parent. It is not a second Subpath, a collection of bonus features, or an overlay placed on top of the parent.

A character cannot possess both complete progressions at the same CL unless an explicit Source Rule creates a temporary composite state and states exactly which features function.

### Direct Entry

At CL3, or when first receiving the Subpath choice, a character can select a Variant instead of the parent when a legal source grants direct access. The character gains the Variant's CL3 features and later gains only the Variant features.

### Conversion Entry

A character who already possesses the parent can convert when a breakthrough, inheritance awakening, corruption event, ritual, artifact bond, spirit pact, mutation, or another Source Rule permits it.

When the Variant does not print its own conversion procedure, use this default:

1. obtain legal access to the Variant;
2. complete one Full Cultivation Session for each attained Subpath feature;
3. pay every printed material, social, spiritual, bodily, or permanent price;
4. make a Cultivation Check against `10 + PB + the number of attained parent features`.

On a failure, the sessions and any expressly consumed prices are spent, but the parent remains. On a success, all attained parent features are replaced simultaneously by the matching Variant features.

A specific Variant can replace the check with a tribulation, story condition, unavoidable transformation, permanent price, corruption event, or another printed procedure.

### One-for-One Replacement

Each Variant relationship must identify the parent feature replaced at CL3, CL6, CL10, CL14, and CL18.

A replaced feature stops functioning. Its actions, Reactions, passive benefits, resources, transformations, Assets, Anchors, Fields, Domains, companions, and capstone are not retained unless the Variant expressly repeats or transforms them.

An ongoing effect sustained only by a replaced feature ends when conversion resolves. Instantaneous results, completed injuries, real items, paid prices, debts, scars, corruption, and other completed consequences remain.

### Compatibility with Parent Requirements

A Variant counts as its parent for prerequisites that name the parent progression generally. It does not satisfy a prerequisite that names a specific replaced feature unless the Variant expressly provides an equivalent.

A Variant's own access class, prices, restrictions, Corruption, and social consequences govern actual access and use.

### Parent Resources and Persistent Structures

A parent resource converts only when the Variant relationship says how. Otherwise, it is lost when conversion succeeds, and the Variant begins with its printed starting state.

Parent Assets, Anchors, Fields, Domains, companion states, and transformations disperse, end, or become inactive unless the Variant expressly transforms them. Long-term harm and completed consequences do not disappear.

### Reversion and Further Conversion

Conversion is not free retraining. Returning to the parent or entering another Variant requires another legal source and the applicable conversion procedure. Purification, restitution, repair, or removal of a permanent price can also be required.

A character cannot alternate between parent and Variant progressions between scenes, rests, or individual encounters unless an explicit feature grants that temporary authority.

### Temporary Copies

A temporary copy grants only the named feature. It does not grant the parent or Variant progression, compatibility, access classification, future features, initiation, or permanent conversion.

## Realm Suppression

Realm Suppression changes the effective CL used by the character's Paths and Subpaths.

Use the suppressed effective CL to determine which Subpath features are available:

| Effective CL after suppression | Available Subpath tiers |
|---:|---|
| **18 or higher** | CL3, CL6, CL10, CL14, and CL18 |
| **14–17** | CL3, CL6, CL10, and CL14 |
| **10–13** | CL3, CL6, and CL10 |
| **6–9** | CL3 and CL6 |
| **3–5** | CL3 only |
| **0–2** | No Subpath features are available. |

Realm Suppression does not erase the character's selection, access source, history, prices, scars, corruption, relationships, or completed consequences.

When a feature becomes unavailable:

- the character cannot activate it or use its passive permission;
- its scaling uses only the lower effective CL where the rule has lower-level scaling;
- an effect whose continued existence requires that feature is suppressed or ends under its own procedure;
- instantaneous results and completed injuries remain resolved;
- real items remain real items, though a bond or function dependent on the suppressed feature can become inactive;
- a parent-to-Variant conversion is not reversed.

A Source Rule can suppress one Path, one Subpath, one feature, one transformation, one Asset, one Anchor, one Field, one Domain, or another narrower structure when it expressly says so. Narrow suppression affects only the named structure.

## Subpath Records for Players, GMs, and AI

A complete Subpath record contains:

- Path and Subpath name;
- canonical ID where one is available;
- access class and tags;
- legal access source;
- parent and Variant relationship, if any;
- current effective CL and feature tiers;
- Source CL basis;
- actions, Reactions, Bonus Actions, passive modifiers, procedures, resources, and states;
- Assets, Anchors, Fields, Domains, companions, transformations, and anatomy changes;
- recovery and scene-reset procedures;
- Realm Suppression behavior;
- every displayed ability required for player, GM, and AI execution.

The source paragraph remains the controlling rule. A character record must express the feature faithfully; it cannot replace a missing mechanic with improvised text.

## The Separate Path Compendia

The PHB contains the shared selection rules and each Path's CL1–20 chassis. The complete Subpath catalogues are published separately because their combined scope is much larger than the core handbook.

| Compendium | Current player catalogue |
|---|---:|
| **Tianxia: Qi Cultivation Subpath Compendium** | 80 Qi Subpaths, including Open Schools, Restricted Scriptures, Rare Inheritances, Variants, Forbidden Variants, Secret Laws, and Daemonic Subpaths |
| **Tianxia: Body Refining Subpath Compendium** | 42 Body Refining Schools, Scriptures, Bodies, Methods, and Inheritances |
| **Tianxia: Spirit Awakening Tradition Compendium** | 34 Spirit Awakening traditions |

Each compendium contains:

- complete CL3/6/10/14/18 feature text;
- access classifications and legal-source guidance;
- Path-specific shared procedures;
- parent and Variant relationships where applicable;
- Source CL, Realm Suppression, Asset, Anchor, Field, Domain, transformation, companion, and recovery interfaces;
- indexes suitable for players, GMs, the Character Factory, and AI-assisted character creation.

The compendia expand choice; they do not replace the shared rules in this chapter or the Path chassis in Chapters 04–06.

## Subpath Selection Checklist

Before play, confirm all of the following:

- [ ] The character possesses the correct Path.
- [ ] The character is CL3 or higher, or another rule legally grants early access.
- [ ] Only one complete Subpath occupies that Path's slot.
- [ ] Every prerequisite is met.
- [ ] The access source is recorded.
- [ ] The access class and all tags are recorded.
- [ ] Any initiation price, oath, taboo, corruption, injury, service, or continuing obligation is recorded.
- [ ] Parent and Variant replacements are explicit.
- [ ] Every attained feature tier is added.
- [ ] Activated and triggered features have executable records.
- [ ] Passive statistics and state modifications are applied.
- [ ] Assets, Anchors, Fields, Domains, companions, transformations, and anatomy changes have complete records.
- [ ] Source CL and Realm Suppression behavior are recorded.
- [ ] The full player text is available in the correct Path compendium.
