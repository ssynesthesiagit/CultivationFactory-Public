# 03. Paths and Shared Path Rules

A **Path** is the main cultivation chassis that carries a character from CL 1 through CL 20. It determines the character's Hit Die, key ability, Cultivation Points, basic training, core progression, and access to a Path-specific Subpath.

The three orthodox Paths are:

- **Body Refining**, which makes the cultivator's body the primary vessel and instrument of power;
- **Qi Cultivation**, which refines internal qi into repeatable martial, technical, elemental, and externalized arts;
- **Spirit Awakening**, which cultivates soul, perception, identity, spiritual pressure, relationships, and conceptual authority.

A Path is not a Background, Origin Insight, Sphere, talent, Foundation, Method, manual, Recorded Art, Forged Technique, item, or Dao. Those systems interact with a Path, but they do not replace it.

This chapter contains the rules shared by all three orthodox Paths. The individual Body Refining, Qi Cultivation, and Spirit Awakening chapters provide their complete CL 1-20 features and Path-specific exceptions.

## Choosing Your Starting Path

Do not choose a Path at level 0.

When you complete the sect trial and become CL 1, choose one starting Path. Record its key ability, Hit Die, Cultivation Point pool, training, skills, and CL 1 features.

Most cultivators follow one Path. A character can later add another Path through the **Multi-Path Cultivation** rules in this chapter. Beginning another Path is a major cultivation decision, not an ordinary training choice.

Qi Cultivation uses Intelligence or Charisma. Choose one of those abilities when you gain the Path. That choice remains your Qi Cultivation key ability unless an explicit Source Rule changes it.

## The Three Orthodox Paths

| Path | Key Ability | Hit Die | Cultivation Points | Armor Training | Weapon Training | Path Identity |
|---|---|---:|---|---|---|---|
| **Body Refining** | Constitution | d12 | Stamina | Light armor, medium armor, shields | Simple and martial weapons | Durability, physical force, bodily transformation, restraint, movement, and embodied martial cultivation |
| **Qi Cultivation** | Intelligence or Charisma | d8 | Qi | Light armor | Simple weapons | Qi circulation, projected techniques, weapon-and-technique cultivation, Fields, Formations, armaments, and supernatural craft |
| **Spirit Awakening** | Wisdom | d8 | Resonance | None | Simple weapons | Spiritual perception, soul authority, exorcism, spirit relations, conceptual martial practice, and Domains |

### Path Skills

When you gain your starting Path at CL 1, choose two skills from its list.

- **Body Refining:** Acrobatics, Athletics, Intimidation, Perception, Survival
- **Qi Cultivation:** Arcana, History, Insight, Investigation, Medicine, Nature, Perception, Persuasion, Religion
- **Spirit Awakening:** Deception, Insight, Investigation, Medicine, Perception, Persuasion, Religion

Adding another Path later does not grant additional skill proficiencies unless an explicit rule says otherwise.

## Shared Cultivation Mathematics

Each Path has its own key ability. Use the key ability of the Path that powers the feature.

**Cultivation Save DC**

`8 + Proficiency Bonus + Path key ability modifier`

**Cultivation Attack Modifier**

`Proficiency Bonus + Path key ability modifier`

**Cultivation Check**

`d20 + Proficiency Bonus + Path key ability modifier`

A character with more than one Path calculates these values separately for each Path.

A feature may print a different ability, attack modifier, save DC, or check. Use the feature's printed rule for that feature.

## Saving Throws

The orthodox Paths grant **no saving throw proficiencies**.

Each Path instead grants cultivated defensive features. These defenses require their printed trigger, action, cost, and limit.

A feature that adds Proficiency Bonus to a failed saving throw is not saving throw proficiency. It does not stack with proficiency or another feature that adds Proficiency Bonus to the same saving throw unless an explicit rule says that it does.

## Hit Dice and Hit Points

A single-Path character uses the Hit Die and Hit Point progression of that Path.

| Path | Hit Points at CL 1 | Hit Points at Later CLs |
|---|---|---|
| **Body Refining** | `12 + Constitution modifier` | `1d12 or 7 + Constitution modifier` per CL after CL 1 |
| **Qi Cultivation** | `8 + Constitution modifier` | `1d8 or 5 + Constitution modifier` per CL after CL 1 |
| **Spirit Awakening** | `8 + Constitution modifier` | `1d8 or 5 + Constitution modifier` per CL after CL 1 |

Minimum Hit Points gained at a CL are 1 unless an explicit rule says otherwise.

Multi-Path characters use the rules in **Multi-Path Hit Dice and Hit Points** below.

## Cultivation Points

**Cultivation Points**, abbreviated **CP**, are the spendable reserves used by cultivation features.

Each Path names its own CP pool:

- Body Refining uses **Stamina**.
- Qi Cultivation uses **Qi**.
- Spirit Awakening uses **Resonance**.

When a Path feature says to spend CP, spend from that Path's pool. A non-Path feature must identify its **Powering Path** or explicitly allow a choice of pools.

### Maximum Cultivation Points

| Path | Maximum CP |
|---|---|
| **Body Refining** | `Body Refining CL x Constitution modifier` |
| **Qi Cultivation** | `Qi Cultivation CL x chosen key ability modifier`, minimum `2 x Qi Cultivation CL` |
| **Spirit Awakening** | `Spirit Awakening CL x Wisdom modifier`, minimum `2 x Spirit Awakening CL` |

A CP pool cannot have a negative maximum. Body Refining has no additional minimum floor unless an explicit rule creates one.

A cultivation Method is the ordinary permanent way to modify maximum CP. A Foundation, Insight, item, injury, condition, or other source changes maximum CP only when its own rule expressly says so.

### Spending Cultivation Points

You spend CP when a rule tells you to do so.

Unless the Source Rule says otherwise:

- pay the cost when you activate the feature;
- you cannot activate the feature without enough CP;
- current CP cannot exceed maximum CP;
- if a feature permits spending "up to" a value, choose the amount as part of activation;
- a failed attack roll or successful saving throw does not refund the cost;
- an invalid declared target prevents the activation, and the Source Rule determines whether a cost was already committed.

### Reaching 0 Cultivation Points

When one of your CP pools is reduced from above 0 to exactly 0, gain 1 level of Exhaustion.

If you later regain points in that pool and reduce it to 0 again, you can gain another level of Exhaustion. Different CP pools are tracked separately for this purpose.

Beginning a scene at 0 CP does not trigger additional Exhaustion by itself.

### Recovery by Path

| Path | Short Rest | Long Rest | Full Cultivation Session |
|---|---|---|---|
| **Body Refining** | Recover half maximum Stamina, rounded down; usable twice between Long Rests | Recover all missing Stamina | Recover all missing Stamina; once per Long Rest |
| **Qi Cultivation** | Recover Qi equal to Qi Cultivation CL; once per Long Rest | Recover half maximum Qi, rounded down | Recover all missing Qi; once per Long Rest |
| **Spirit Awakening** | Recover Resonance equal to Spirit Awakening CL; once per Long Rest | Recover half maximum Resonance, rounded down | Recover all missing Resonance; once per Long Rest |

A **Full Cultivation Session** takes 2 uninterrupted hours and requires a reasonably safe environment and a practice appropriate to the Path, Method, and current condition.

A multi-Path cultivator can restore all active Path pools during one Full Cultivation Session if the session includes an appropriate practice for each Path. A Source Rule can prevent or modify recovery only to the extent it expressly states.

## Powering Path Records

A character with one Path normally has no ambiguity about which pool powers a feature.

A character with more than one Path must record a **Powering Path** for every Sphere ability, talent, Cultivation Insight, Recorded Art, Forged Technique, item property, or other feature that costs generic CP without naming a pool.

Use these rules:

1. A Path feature is always powered by its own Path.
2. A feature that names Stamina, Qi, or Resonance uses that pool.
3. A feature that names a required Path uses that Path's pool.
4. If more than one of your Paths can legally power the feature, choose one when you learn, create, bind, or gain the feature and record that choice.
5. You cannot split one cost between pools unless the feature expressly permits it.
6. Changing a recorded Powering Path requires retraining, reconstruction, a Method change, or another explicit rule.
7. A feature that expressly says "any CP" or "any Path resource" follows its own rule instead.

A Powering Path record does not grant access to a feature. It only resolves which legal pool pays its cost.

## Activations, Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, spirit expression, or other Source Rule. The activation includes every attack, target, pulse, echo, projectile, rider, and repeated output that the declared use expressly creates.

A **cultivation technique** is a supernatural procedure authorized by a Source Rule. It is not automatically a spell, weapon attack, condition, companion action, or ordinary ability check. The Source Rule states which resolution procedure it uses.

A cultivation effect requires Concentration only when its Source Rule says so. A creature normally has one Concentration limit, regardless of how many Paths, Soul Fragments, Companions, Assets, manifestations, or remote origins it possesses.

An independent creature may have its own Concentration only if its rules give it its own turn, actions, and Concentration capacity.

## Effective CL and Source CL

**Effective CL** determines which features you can use and how those features scale.

Your normal effective CL is your character's CL. Realm Suppression or another explicit rule can lower the effective CL used by a Path or feature.

**Source CL** measures the authority of an effect when it collides with another cultivation effect, suppression, reconstruction, permanent harm, an Anchor, a Domain, or another high-authority rule.

Unless a Source Rule states otherwise, a feature's Source CL equals the effective CL used to activate it.

Source CL does not replace:

- an attack roll;
- a saving throw;
- a Cultivation Check;
- a CP cost;
- an action or Reaction;
- an Anchor or Asset profile;
- a repeated save;
- a recovery procedure;
- a reconstruction requirement.

Use Source CL only when a rule calls for an authority comparison or when the universal authority procedures expressly require it.

## Shared Path Progression

The three orthodox Paths use the following shared progression events.

| CL | Shared Event |
|---:|---|
| **1** | Gain starting Path chassis and CL 1 Path features; gain the sect-trial Dao Sphere and its talent under Chapter 02 |
| **3** | Choose one legal Subpath for each Path you possess |
| **4** | Ability Score Improvement or Cultivation Insight |
| **6** | Subpath feature |
| **8** | Ability Score Improvement or Cultivation Insight |
| **10** | Subpath feature |
| **12** | Ability Score Improvement or Cultivation Insight |
| **14** | Subpath feature |
| **16** | Ability Score Improvement or Cultivation Insight |
| **18** | Subpath feature |
| **19** | Ability Score Improvement or Cultivation Insight |

The individual Path chapters provide all other Path features.

### Level Talents and Training

A character gains one level talent at each CL under the Spheres and Talents rules. At CL 1, the sect-trial talent counts as that level talent.

A multi-Path character does not gain extra level talents, training choices, Background benefits, or sect-trial benefits merely for possessing additional Paths.

Whenever a character legally learns a new Sphere, they also gain the normal free first talent from that Sphere. The Background Sphere and Background Talent remain separate free benefits under the Background rules.

## Ability Score Improvements and Cultivation Insights

At CL 4, CL 8, CL 12, CL 16, and CL 19, choose one of the following:

- **Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by the character's current Realm.
- **Cultivation Insight:** Choose one entry from the **Central Cultivation Insights** catalogue for which you meet every prerequisite. Gain its printed cultivation benefit and increase one ability score listed in its **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained from a manual, tribulation, relic, sect office, spirit pact, bloodline awakening, inheritance, story reward, or another non-level source does not grant the level-selection ability increase unless that source expressly says so.

These are character-level choices. A multi-Path character makes one choice at each listed CL, not one choice per Path.

## Subpaths and Access

At CL3, choose one legal Subpath for each Path you possess. You gain that Subpath's later features at CL6, CL10, CL14, and CL18. **Subpath** is the universal term; individual Paths use names such as School, Scripture, Method, Inheritance, Tradition, Lineage, or Law.

Chapter 09 provides the complete player rules for Open, Restricted, Rare, Forbidden, Secret, Inherited, and Variant access; delayed selection; legal access sources; one Subpath per active Path; parent and Variant replacement; Source CL; multi-Path progression; and Realm Suppression.

A Subpath does not grant a thematically similar Sphere unless its rule expressly says that it does.

## Paths and Other Character Systems

### Backgrounds and Origin Insights

Choosing or adding a Path does not erase the character's Background, Background equipment, Background Sphere, Background Talent, proficiencies, or Origin Insight.

A Path explains how the character cultivates. The Background explains what the character brought into cultivation.

### Spheres and Talents

A Path supplies cultivation math, resources, and permissions. A Sphere supplies a field of expression. A talent modifies or expands a Sphere.

A Path does not automatically grant a Sphere because its Subpath uses similar imagery. A sword cultivator does not automatically know the Sword Sphere; a Dreamweaver does not automatically know Dreams; a blood-based Body Refiner does not automatically know Blood.

### Foundations

A Foundation is the character's deep cultivation architecture. It is not a Path and is not chosen automatically at CL 1.

A Foundation can interact with multiple Paths when its own rule permits that interaction. Realm Suppression does not automatically remove a Foundation's passive bodily quality, identity, or existing damage.

### Methods

A Method is the character's primary circulation, refinement, stabilization, or cultivation procedure.

A multi-Path cultivator must record whether a Method applies to one Path, several Paths, or an integrated route. A Method modifies only the pools and features its own rule identifies.

### Manuals, Recorded Arts, and Forged Techniques

A manual can teach a Path feature only when its rule expressly grants or reproduces that feature. Recorded Arts remain fixed expressions and do not grant their component Spheres or talents.

A Forged Technique must identify its legal component expressions and the Path or Path resources that power it.

### Items

An item does not grant a Path, Subpath, Sphere, talent, Method, Foundation, or Recorded Art merely because its description resembles one. It grants only the authority printed in its item rule.

## Path Identity Boundaries

The Paths are not interchangeable power labels.

### Body Refining

Body Refining normally acts through the cultivator's own body, a natural bodily weapon, an integrated weapon, bodily material expressly separated by a Source Rule, or a space the body physically occupies, touches, strikes, crosses, or directly affects.

It does not automatically grant remote technique origin, free-standing Fields, independent projected creatures, detached acting body parts, or control of separated bodily material. Every external projection requires a printed exception.

### Qi Cultivation

Qi Cultivation can externalize power through printed techniques, Domain Armaments, weapons, armor, items, Fields, Formations, talismans, arrays, remote origins, and other legal sources.

Externalized imagery does not bypass the printed range, line of effect, action economy, Source CL, Anchor, or target rules.

### Spirit Awakening

Spirit Awakening cultivates soul, identity, spiritual pressure, perception, exorcism, spirit relationships, and conceptual authority.

It does not automatically grant a full Companion, ownership of a spirit, possession authority, another spirit's Spheres, extra actions, an independent resource pool, or permission to destroy or rewrite a soul. Those permissions require explicit Source Rules.

## Multi-Path Cultivation

Cultivating more than one Path is legal, powerful, and extremely demanding.

A multi-Path character has one character CL. Every Path the character possesses advances at that CL and grants its core features for that CL. The increased AP requirement represents the difficulty of advancing several complete cultivation systems together.

### Standard Multi-Path Combinations

| Path Combination | AP Requirement Multiplier |
|---|---:|
| One orthodox Path | x1 |
| Two orthodox Paths | x3 |
| Chakra plus one orthodox Path | x4 |
| All three orthodox Paths | x5 |

The multiplier applies to the AP required for the next CL in Chapter 17. It does not multiply AP awards.

Other Path combinations require an explicit Source Rule or campaign option.

### Beginning an Additional Path

To add another Path, you must have:

- a legal teacher, manual, inheritance, bloodline awakening, spirit event, bodily transformation, cultivation accident, or other access source;
- any prerequisites imposed by that source;
- enough AP for the next CL after applying the multiplier of the resulting Path combination.

Declare the additional Path before attempting the breakthrough. On a successful breakthrough:

1. your character gains the new CL;
2. the new Path immediately advances to that CL;
3. gain the new Path's core features through that CL;
4. make every mandatory Path-specific choice through that CL, such as a Qi key ability, Soul Anchor, Golden Core Form, Core Tempering Expression, Domain Armament, or similar choice;
5. if the character is CL 3 or higher, choose one legal Subpath for the new Path;
6. gain the new Path's armor and weapon training;
7. gain no additional Path skills, Background benefits, sect-trial benefits, level talents, trained choices, Ability Score Improvements, or Cultivation Insights unless an explicit rule grants them.

You cannot add a Path after reaching maximum standard CL unless an explicit post-CL-20 rule permits it.

### Multi-Path Features

A multi-Path character gains the complete core progression and one legal Subpath progression for each possessed Path.

Distinct Path features coexist. Identically named universal benefits do not stack unless an explicit rule says otherwise.

If two features could add Proficiency Bonus to the same saving throw, use only one unless a rule expressly permits stacking.

Extra Attack and other features that use the same standard nonstacking rule do not stack unless a Source Rule says that they do.

### Multi-Path Hit Dice and Hit Points

Use one Hit Die per character CL: the largest Hit Die among your active Paths.

Among the three orthodox Paths, Body Refining supplies the largest Hit Die. If a d8 character adds Body Refining, increase maximum Hit Points by:

`4 + 2 x (current CL - 1)`

This replaces the difference between the fixed d8 and d12 values for existing CLs. Do not reroll previous Hit Dice.

Adding Qi Cultivation or Spirit Awakening to a character who already uses a d8 or d12 Hit Die does not change existing Hit Points.

### Multi-Path Cultivation Points

Track each Path's CP pool separately. Calculate each maximum using the full character CL and that Path's key ability.

A cost is paid from the feature's recorded Powering Path. You cannot move points between pools unless an explicit rule permits conversion.

Each pool uses its own Short Rest and Long Rest recovery limit. One Full Cultivation Session can restore all active pools if it includes a valid practice for each Path.

Reaching 0 in one pool does not reduce another pool, but it can still cause Exhaustion under the normal 0-CP rule.

### Multi-Path Advancement Benefits

Character-level benefits are gained once, not once per Path:

- one Proficiency Bonus;
- one Hit Die per CL;
- one level talent per CL;
- up to three trained choices per CL;
- one Ability Score Improvement or Cultivation Insight at CL 4, 8, 12, 16, and 19;
- one Background package;
- one Origin Insight;
- one sect-trial Dao Sphere and sect-trial talent unless another rule grants more.

Path-level benefits are gained for every possessed Path:

- each Path's core features;
- each Path's CP pool;
- each Path's mandatory selections;
- one Subpath progression for each Path;
- armor and weapon training granted by each Path.

### Multi-Path Realm Suppression

Ordinary Realm Suppression applies one effective CL to all of the character's Paths.

A Source Rule can suppress only one Path, one pool, one Subpath, one transformation, one Soul Anchor expression, one Domain, or another narrower cultivation structure when it expressly says so.

Suppressing one Path does not transfer its CP to another Path or allow another Path to activate the suppressed feature.

## Realm Suppression

A cultivator can voluntarily suppress their Realm under the Realm Suppression rules.

While suppressed:

- use the suppressed effective CL;
- use the Proficiency Bonus for the suppressed CL where required;
- do not activate or benefit from features, higher-Realm options, talents, Insights, Recorded Arts, Method expressions, Foundation expressions, or item powers above the suppressed CL;
- use lower-CL scaling where the source provides it.

Realm Suppression does not recalculate:

- maximum Hit Points;
- Hit Dice;
- maximum CP;
- permanent anatomy;
- identity or ancestry;
- Soul Anchors or Bonds;
- Foundations or existing Foundation damage;
- injuries, scars, debts, contracts, or other persistent consequences.

An unavailable maintained effect ends or becomes dormant according to its Source Rule. Suppression does not refund costs or retroactively reduce the authority of an already resolved consequence.

## Rule Resolution Order

Resolve Path rules in this order:

1. The explicit Source Rule creating or modifying the effect.
2. A dependency expressly named by that Source Rule.
3. The relevant Path core.
4. The relevant Path player procedure or Subpath procedure addendum.
5. This shared Path chapter and other universal cultivation rules.
6. The underlying fifth-edition procedure where Tianxia has not replaced it.

Description, reputation, analogy, conventional spell comparison, and thematic similarity never grant unprinted authority.

## CL 1 Path Checklist

When the sect trial makes a character CL 1, record:

- starting Path;
- Path key ability;
- Hit Die and maximum Hit Points;
- Path CP pool and maximum;
- armor and weapon training;
- two Path skills;
- CL 1 Path features;
- sect-trial Dao Sphere and talent;
- continuing Background benefits;
- Origin Insight.

## Shared Path Glossary

**Activation.** One declared use of a Source Rule, including every attack, target, pulse, echo, projectile, rider, and repeated output expressly created by that use.

**Cultivation Attack Modifier.** `Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Check.** `d20 + Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Cultivation Points (CP).** The spendable resource used by cultivation features: Stamina, Qi, Resonance, or another explicitly defined Path resource.

**Cultivation Save DC.** `8 + Proficiency Bonus + the key ability modifier of the Path powering the feature`, unless the Source Rule gives another formula.

**Effective CL.** The CL currently used for access and scaling after Realm Suppression or another explicit modifier.

**Multi-Path Cultivator.** A character who legally possesses more than one complete Path progression.

**Path.** A character's main CL 1-20 cultivation chassis.

**Powering Path.** The recorded Path whose resource and cultivation mathematics power a feature when more than one Path could legally do so.

**Source CL.** The authority level of a cultivation source, normally equal to the effective CL used to activate it unless a rule says otherwise.


**Access Class.** The universal availability classification of a Subpath: Open, Restricted, Rare, Forbidden, or Secret.

**Inherited.** A Subpath access tag indicating transmission through ancestry, reincarnation, awakening, mutation, relic or spirit integration, or another nonordinary source.

**Parent Subpath.** The base progression named by a Variant.

**Variant.** An alternate progression that occupies its parent's Subpath slot and replaces the named parent features one for one.

**Subpath.** The universal term for a Path-specific progression gained at CL 3, with later features at CL 6, 10, 14, and 18.

---
