# Tianxia Qi Cultivation — Player Path Chapter R19

**Publication state:** Player-facing organization of the canonical R18 rules.  
**Mechanical state:** No intentional mechanical changes from R18.  
**Companion volumes:** *Qi Subpath Compendium R19* and *Qi GM Authority Appendix R19*.

## How to Use This Chapter

This volume contains the Qi Cultivation Path chassis, its CL1–20 progression, Golden Core Forms, Domain Armaments, Realm Suppression summary, and all canonical Qi Cultivation Insights. Select a Subpath from the companion compendium. Consult the GM Authority Appendix when a feature invokes Source CL contests, Cultivation Assets, Anchors, Formations, complete cultivation suppression, long-term cultivation harm, Secret-Law authority, Daemonic Corruption, or parent/Variant conversion.

## Publication Rule Hierarchy

1. A feature's **Source Rule** governs that feature.
2. The canonical Qi core governs the Path.
3. The shared Qi Subpath Rules govern recurring procedures.
4. The individual Subpath entry governs its exceptions.
5. General Tianxia and underlying 5.5e resolution rules apply where the cultivation rules do not replace them.

# Part I — Qi Cultivation Path

## Tianxia Qi Cultivation Path — Canonical Core R4

> *The breath becomes wind. The wind becomes storm. The storm becomes heaven. Heaven bows to the cultivator who mastered their first inhale.*

Qi Cultivation is the most widespread cultivation Path and the institutional foundation of the Empire. Qi Cultivators gather spiritual energy from heaven and earth, refine it through meridians and dantian, and release it through repeatable methods.

Qi Cultivation is not a ranged or spell-only Path. Martial Qi Cultivators are extremely common. Many combine armor, weapon Spheres, martial Recorded Arts, projected techniques, wards, movement methods, and elemental riders. Sword cultivators, spear cultivators, archers, armored wardens, healers, formation specialists, artificers, alchemists, and hybrid weapon-and-technique combatants are all ordinary expressions of the Path.

The default chassis remains light armor and simple weapons. Stronger armor, shields, martial weapons, and specialized weapon forms are intentionally accessible through Backgrounds, the Equipment Sphere, weapon Spheres, talents, training, Methods, items, and common martial Recorded Arts. Wearing high-quality armor or using a martial weapon does not inhibit Qi cultivation unless a specific rule says otherwise.

A Body Refiner transforms the body until the body itself becomes the technique. A Spirit Awakener imposes cultivated spiritual identity and authority upon the world. A Qi Cultivator makes a practiced system of meridians, weapons, armor, items, formulas, and external power supernatural.

**Canonical status.** This chapter is the authoritative Qi Cultivation Path chassis for the R18 working rules. When an older Qi draft conflicts with this chapter, use this chapter. The Shared Qi Subpath Rules R4 govern recurring structures; an explicit Source Rule may override a default only for the exception it prints.

---

## Canonical Rule Order

Resolve Qi Cultivation rules in this order:

1. The explicit Source Rule creating or modifying the effect.
2. This Qi Cultivation core.
3. **Tianxia Qi Cultivation — Shared Subpath Rules R4.**
4. Universal Tianxia cultivation rules, including Scene, Realm, Cultivation Points, training, Foundations, Methods, Recorded Arts, Forged Techniques, and Realm Suppression.
5. The underlying D&D 5.5e resolution procedure where Tianxia has not replaced it.

A specific rule overrides a general rule only to the extent stated. Visual description, reputation, a similar technique name, or a conventional spell analogy never grants unprinted cultivation authority.

## Qi Cultivation at a Glance

| Rule | Qi Cultivation |
|---|---|
| **Key Ability** | Intelligence or Charisma, chosen at CL1 |
| **Hit Die** | d8 |
| **Cultivation Points** | Qi |
| **Primary Roles** | Martial combatant, hybrid weapon-and-technique cultivator, ranged combatant, controller, healer, artisan, scholar, and supernatural specialist |
| **Saving Throw Proficiencies** | None |
| **Armor Training** | Light armor |
| **Weapon Training** | Simple weapons |
| **Skills** | Choose two: Arcana, History, Insight, Investigation, Medicine, Nature, Perception, Persuasion, Religion |

### Choosing Your Key Ability

At CL1, choose Intelligence or Charisma. This becomes your Qi Cultivation key ability.

Use Intelligence for formulae, arrays, scripture interpretation, medicine, alchemy, calligraphy, formation design, technical weapon methods, and methodical comprehension.

Use Charisma for instinctive circulation, willpower, bloodline expression, emotional intensity, innate affinity, command presence, and overwhelming spiritual force.

### Cultivation Math

**Cultivation Save DC**  
`8 + Proficiency Bonus + Qi Cultivation key ability modifier`

**Cultivation Attack Modifier**  
`Proficiency Bonus + Qi Cultivation key ability modifier`

**Cultivation Check**  
`d20 + Proficiency Bonus + Qi Cultivation key ability modifier`

### Activation, Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, or other Source Rule, including every attack, projectile, repeated target, and rider that the use expressly creates. Once-per-activation limits apply across that whole use.

A **cultivation technique** is a supernatural procedure authorized by a Source Rule. It is not automatically a spell, weapon attack, or ordinary ability check. The Source Rule states which D&D resolution procedure it uses.

A Qi-powered feature requires Concentration only when its Source Rule says so. Use the normal Concentration limit and ending conditions unless a cultivation rule expressly changes them. Nascent Soul's **Independent Concentration** improves a failed Concentration saving throw; it does not create a second Concentration slot.

### Effective CL and Source CL

Your normal effective CL is your Qi Cultivation CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature. Source CL determines authority and interaction; it does not replace attack rolls, saving throws, Anchors, costs, or recovery procedures printed by the Source Rule.

---

## Qi

Qi represents refined spiritual energy stored within meridians, dantian, breath, blood, Golden Core, Nascent Soul, elemental affinities, prepared techniques, items, weapons, armor, and internal formations.

### Maximum Qi

`Qi Cultivation CL × Qi Cultivation key ability modifier`

Your maximum Qi cannot be lower than:

`2 × Qi Cultivation CL`

### Recovering Qi

| Recovery Method | Qi Recovered | Limit |
|---|---:|---|
| **Short Rest** | Qi equal to your CL | Once per long rest |
| **Long Rest** | Half your maximum Qi | No additional limit |
| **Full Cultivation Session** | All missing Qi | Once per long rest |

A Full Cultivation Session requires 2 uninterrupted hours, a reasonably calm environment, and sufficient ambient spiritual energy or an appropriate substitute. It may occur during an eligible meditative long rest.

### Reaching 0 Qi

When you are reduced from more than 0 Qi to exactly 0 Qi, gain 1 level of Exhaustion.

Repeatedly reaching 0 Qi can add further Exhaustion under the universal Cultivation Point rules.

---

## Qi Cultivation Progression

| CL | Features |
|---:|---|
| 1 | Cultivated Response, Qi Sensing, Qi Technique Potency |
| 2 | Meridian Regulation |
| 3 | Qi Cultivation Subpath |
| 4 | Ability Score Improvement or Cultivation Insight |
| 5 | Qi Armor |
| 6 | Subpath Feature |
| 7 | Featherfall |
| 8 | Ability Score Improvement or Cultivation Insight |
| 9 | Domain Armament |
| 10 | Golden Core Form, Subpath Feature |
| 11 | Golden Core Efficiency |
| 12 | Ability Score Improvement or Cultivation Insight |
| 13 | Domain Armament Link |
| 14 | Subpath Feature |
| 15 | Nascent Soul |
| 16 | Ability Score Improvement or Cultivation Insight |
| 17 | Nine Heavens Gaze, Perfected Golden Core, Domain Armament damage increase |
| 18 | Subpath Feature |
| 19 | Ability Score Improvement or Cultivation Insight |
| 20 | Immortal of Qi, Second Golden Core Form |

### Ability Score Improvement or Cultivation Insight

At CL4, CL8, CL12, CL16, and CL19, choose one of the following:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight's **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, sect instruction, imperial office, bloodline awakening, experimentation, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise. Background ability-score increases and Origin Insights are separate character-creation benefits and do not activate this increase.

Use **Tianxia Qi Cultivation Insights — Modernized R2: Ability-Integrated** as the current Qi Insight catalog. If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

---


## Qi Cultivation Subpaths

At CL3, choose one Qi Cultivation Subpath for which you have legal access. You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Catalog classification | Meaning |
|---|---|
| **Open School** | Commonly teachable or institutionally available. Open access does not imply low power. |
| **Restricted Scripture** | Controlled technical, political, military, medical, inherited, or hazardous instruction. |
| **Rare Inheritance** | Uncommon structural access, bloodline, vessel, destiny, treasure, or singular transmission. A **Rare Variant** is a parent-lineage conversion inside this category. |
| **Forbidden Variant** | A parent-lineage conversion carrying a prohibited, condemned, hazardous, predatory, or politically unacceptable price. Forbidden is not automatically Daemonic. |
| **Secret Law** | Qualitatively superior law-level authority requiring explicit access and its printed initiation price. |
| **Daemonic** | A mechanical tag used only when the Source Rule interacts with Corruption, daemonic energy, purification, or anti-daemonic rules. It is orthogonal to social accusations of being “demonic.” |

A character normally has one Subpath progression. Parent and Variant lineages use the executable replacement rules in Shared Qi Subpath Rules R4; they do not provide a second simultaneous Subpath progression.

---

## CL1 — Cultivated Response

Choose one Defensive Discipline.

### Reflexive Circulation

Your discipline applies to Dexterity saving throws.

### Calculated Circulation

Your discipline applies to Intelligence saving throws.

### Imperious Circulation

Your discipline applies to Charisma saving throws.

#### Response Procedure

**Reaction**  
**Trigger:** You fail the selected saving throw.  
**Cost:** 1 Qi  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Cultivated Response:

- Is not saving throw proficiency.
- Is activated after you learn that the roll failed.
- Cannot modify a death saving throw.
- Cannot modify a breakthrough check.
- Cannot modify a training check.
- Cannot modify the same saving throw more than once.

At CL15, learn a second Defensive Discipline.

At CL20, learn all three.

---

## CL1 — Qi Sensing

Qi Sensing is always active unless suppressed.

### Passive Sensing

Within 30 feet, perceive the presence of active supernatural energy from:

- Path and Subpath features.
- Sphere talents.
- Formations.
- Talismans.
- Cultivated items.
- Active spirits.
- Concentrated Cultivation Points.
- Transformations.
- Active curses.
- Active seals.
- Possession.
- Corruption.
- Strong residues created during the previous hour.

Qi Sensing is blocked by:

- 1 foot of stone.
- 1 inch of common metal.
- A thin sheet of lead.
- 3 feet of wood or packed earth.
- A sealed Formation or effect explicitly blocking Qi perception.

Passive Qi Sensing does not automatically reveal:

- The exact technique.
- Exact statistics.
- A precise occupied space for an Invisible creature.
- A dormant inheritance.
- A secret property.
- A successful concealment effect.

### Analyze Qi

**Action**  
**Range:** 30 feet

Choose one detected effect, creature, item, or residue.

Learn:

- Its broad category.
- Its active supernatural tags.
- Whether its Source CL is lower than, equal to, or higher than yours.
- Whether it is active, dormant, damaged, unstable, or suppressed.

For a concealed effect, make a Cultivation Check against its save DC.

If it has no save DC, use:

`8 + source Proficiency Bonus + source key ability modifier`

On failure:

- You know concealed power is present.
- You do not learn its exact nature or location.
- You cannot retry until the effect changes or a new scene begins.

When the check succeeds, the AI GM must provide the listed information and cannot withhold it for dramatic convenience.

---

## CL1 — Qi Technique Potency

Once per activation, when a Qi-powered feature deals damage, add your Qi Cultivation key ability modifier to one damage roll.

Qualifying features include:

- Qi Cultivation Path features.
- Qi Cultivation Subpath features.
- Qi-powered Sphere talents.
- Recorded Arts using Qi.
- Forged Techniques using Qi.
- Immortal Arts using Qi.
- Weapon attacks explicitly delivering a Qi-powered cultivation technique.

An ordinary weapon attack does not qualify merely because the attacker is a Qi Cultivator.

When a weapon-delivered technique deals both weapon damage and technique damage, apply Qi Technique Potency to either:

- One weapon-damage roll; or
- One technique-damage roll.

Do not apply it to both.

For a Barrage, volley, chain, multi-projectile activation, or technique applied through multiple attacks, Qi Technique Potency applies once across the entire activation.

---

## Universal Reference — Weapon-Delivered Cultivation Techniques

This is the canonical player-facing summary. Shared Qi Subpath Rules R4 supplies the complete procedure for paid multiattack delivery, Domain Armament delivery, damage separation, and anti-recursion.

A cultivation technique can be delivered through a weapon only when a Sphere talent, Recorded Art, Forged Technique, Immortal Art, item property, Method, Subpath feature, or another Source Rule explicitly permits weapon delivery.

Unless the Source Rule explicitly states otherwise:

1. Pay the technique’s complete cost.
2. Make the authorized weapon attack.
3. On a miss, the technique fails and the cost remains spent.
4. On a hit, deal the weapon’s normal damage.
5. Apply the delivered technique from the struck creature or point.
6. Resolve any required saving throw.
7. Apply once-per-turn and once-per-activation limits.

When the user makes multiple attacks, the cultivation technique applies only to the first qualifying attack unless the Source Rule explicitly states that it applies to:

- Additional attacks.
- Multiple attacks.
- Every attack.
- A Barrage.
- A volley.
- Another defined sequence.

Weapons and shields may serve as visible cultivation focuses without automatically converting the technique into a weapon attack or adding weapon damage.

---

## CL2 — Meridian Regulation

**Action**  
**Range:** Touch  
**Cost:** 1 Qi

Choose one poison, disease, or directly caused physical impairment affecting the target.

The effect must:

- Have a printed saving throw DC.
- Not have the Curse, Tribulation, Foundation Injury, Hidden Injury, Possession, Permanent, or Soul Damage tag.

### Effect with Repeat Saves

The target immediately repeats the saving throw with Advantage.

On success, apply the effect’s normal successful-save result.

### Effect without Repeat Saves

The target makes a Constitution saving throw with Advantage against the effect’s printed DC.

On success, suppress one penalty until the end of the target’s next turn:

- Poisoned.
- Speed reduction.
- Disadvantage on attack rolls.
- Disadvantage on ability checks.
- Disadvantage on saving throws.
- Inability to take Reactions.

Meridian Regulation does not automatically:

- Remove the underlying effect.
- End its duration.
- Cure the disease or poison.
- Remove Exhaustion.
- Restore Hit Points.
- Stop ongoing damage.
- Remove a higher-authority effect.

---

## CL5 — Qi Armor

**Reaction**  
**Trigger:** You are hit by a ranged attack roll.  
**Cost:** 2 Qi

Gain +3 AC until the start of your next turn, including against the triggering attack.

Activate after learning that the attack hit and before damage is applied.

Qi Armor applies to:

- Ranged weapon attacks.
- Ranged spell attacks.
- Ranged cultivation attacks.
- Ranged Sphere attacks.
- Recorded Art attack rolls.
- Forged Technique attack rolls.
- Immortal Art attack rolls.
- Item attack rolls.
- Formation attack rolls.

Qi Armor does not apply to:

- Melee attacks.
- Reach attacks classified as melee.
- Saving throw effects.
- Automatic damage.
- Environmental damage.
- An effect without an attack roll.

At CL10, Qi Armor costs 1 Qi.

---

## CL7 — Featherfall

**Reaction**  
**Trigger:** You or a creature within 60 feet begins falling.  
**Cost:** 1 Qi per target  
**Targets:** Up to your Proficiency Bonus in creatures  
**Duration:** 1 minute

An affected target:

- Descends no more than 60 feet during each round.
- Takes no falling damage while the effect lasts.
- Lands standing when it reaches a supporting surface.
- May end the effect on itself at the start of its turn.

Featherfall does not grant flight or horizontal movement.

---

## CL9 — Domain Armament

A Domain Armament is a movable external Qi focus. It is not a Spirit Awakening Domain.

A Domain Armament may be:

- A projected cultivation construct.
- One specific real weapon bound to your Qi.
- One specific real shield bound to your Qi.

Examples include:

- Sword.
- Spear.
- Needle.
- Bow.
- Bell.
- Brush.
- Fan.
- Seal.
- Mirror.
- Orb.
- Disk.
- Chain.
- Instrument.
- Shield.
- Talisman array.
- Another noncreature weapon or cultivation implement.

### Manifest Domain Armament

**Bonus Action**  
**Initial Position:** One unoccupied point within 30 feet  
**Cost:** 1 Qi  
**Duration:** 1 hour

You may maintain one Domain Armament.

A projected Armament:

- Occupies no space.
- Provides no Cover except through Guard Mode.
- Cannot flank.
- Cannot carry objects.
- Cannot manipulate objects.
- Cannot use unrelated item properties.
- Cannot be targeted unless a rule explicitly affects projected weapons, Qi constructs, or Domain Armaments.
- Ends if you become Unconscious.

Choose Bludgeoning, Piercing, Slashing, or Force damage when it manifests.

Once during each of your turns:

- Move it up to 20 feet without using an action.
- It must remain within 30 feet.

If a projected Armament ends outside range, it moves to the nearest legal point in range.

### Binding a Real Weapon or Shield

You may bind one real weapon or shield as your Domain Armament.

**Binding Time:** 10 uninterrupted minutes while touching the item

The item must satisfy all of the following:

- You own it or have its owner’s permission.
- You are proficient with it or another rule permits its use.
- You meet its attunement and cultivation prerequisites.
- A sentient item consents.
- It is not already bound as another creature’s Domain Armament.

The bond remains until:

- You bind another item.
- You willingly end the bond.
- The item is destroyed.
- A feature explicitly severs the bond.

The actual item alternates between:

- Being wielded.
- Being carried.
- Floating as your Domain Armament.

It is never duplicated.

A Saint-class, Legendary, named, or ancestral item remains the actual item while floating.

### Call or Release Bound Item

Move the item between your hand and a floating position:

- As a Bonus Action.
- As part of manifesting Domain Armament.
- At the beginning or end of your Attack action.
- As part of activating an authorized weapon-delivered technique through it.

Calling requires a legal free hand and an unobstructed path.

Releasing requires a legal point within Domain Armament range.

This movement is not teleportation unless another feature says otherwise.

A spatial lock, sealed Formation, total physical restraint, or item-control effect can block it.

### Domain Armament Modes

A floating Domain Armament operates in Assault Mode or Guard Mode.

Choose its mode when manifested or released.

Once during each of your turns, change its mode without using an action.

#### Assault Mode — Domain Armament Attack

**Bonus Action**

Move the Armament up to 20 feet, then make a Cultivation Attack against one creature within 5 feet.

**Projected Armament Hit:**

- CL9: `1d8 + key ability modifier`
- CL13: `2d8 + key ability modifier`
- CL17: `3d8 + key ability modifier`

Use the damage type chosen when manifested.

#### Bound Weapon Attack

Use your Cultivation Attack Modifier and the weapon’s printed enhancement bonus.

On a hit, use the greater of:

- The weapon’s normal damage dice; or
- Your Domain Armament damage dice.

Then add:

- Your Qi Cultivation key ability modifier.
- The weapon’s printed damage bonus.
- Any automatic on-hit property whose trigger is legally satisfied.

The item retains:

- Damage type.
- Enhancement bonus.
- Attunement properties.
- Automatic on-hit properties.
- Material properties.
- Named traits.

A property requiring a separate action, item charge, Attack action, physical grip, stance, or unsatisfied trigger does not activate automatically.

A property saying “while wielding” treats the floating item as wielded unless it explicitly requires physical contact, a free hand, or a stance.

#### Guard Mode — Projected Shield

A projected shield or defensive form cannot make Domain Armament Attacks.

At the end of your turn, designate one creature within 5 feet as protected until the start of your next turn.

The creature gains:

`+2 AC against ranged attack rolls`

The protection ends if:

- The creature moves more than 5 feet from the Armament.
- The Armament changes mode.
- The Domain Armament ends.

The bonus:

- Applies to ranged weapon, spell, and cultivation attack rolls.
- Does not apply to melee attacks.
- Does not apply to saving throw effects.
- Does not stack with another shield bonus.
- Stacks with Qi Armor.

#### Guard Mode — Bound Shield

Use the shield’s printed shield bonus against ranged attacks for the protected creature.

Its enhancement bonus applies.

The floating shield:

- Protects one creature.
- Does not also protect you merely because it is bound.
- Retains appropriate passive properties.
- Can serve as a cultivation focus.

#### Bound Shield Assault

A bound shield may use Assault Mode.

If it has a printed attack profile, use it.

Otherwise, its Domain Armament Attack deals Bludgeoning or Force damage using normal Domain Armament damage dice.

### Bound Item Vulnerability

A bound real item:

- Uses its printed durability.
- Can be targeted by effects explicitly affecting items, weapons, shields, or cultivation implements.
- Can be suppressed, restrained, sealed, trapped, or displaced.

If forced outside Domain Armament range:

- It falls in the nearest legal space.
- Domain Armament benefits are suppressed.
- The bond remains.
- Control returns when it is in range and no blocking effect remains.

---

## CL10 — Golden Core Form

At CL10:

- Qi Armor costs 1 Qi.
- Choose one Golden Core Form.

You may replace the chosen Form after a successful CL15 breakthrough before using your CL15 Nascent Soul feature.

At CL17, your chosen Form becomes Perfected.

At CL20, choose a second Golden Core Form. Both Forms are Perfected.

### Stable Golden Core

When Initiative is rolled, if your current Qi is lower than your Proficiency Bonus, regain Qi until it equals your Proficiency Bonus.

At the start of your turn, if your current Qi is lower than your Proficiency Bonus, regain 1 Qi.

Once per round, when a hostile effect would reduce your current Qi, maximum Qi, or restored Qi, reduce that loss by your Proficiency Bonus.

This does not reduce Qi you willingly spend.

#### Perfected Stable Golden Core

- Initiative threshold becomes `2 × Proficiency Bonus`.
- Start-of-turn recovery becomes 2 Qi.
- Hostile Qi loss reduction becomes `2 × Proficiency Bonus`.

### Circulating Golden Core

Once per turn, after you spend Qi on a feature that resolves successfully, choose one:

- Move 5 feet without provoking Opportunity Attacks.
- Shift your stance around one creature within your weapon’s reach without provoking an Opportunity Attack from that creature.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Move your Domain Armament 10 feet.

This does not trigger from:

- Refunded costs.
- Invalid activations.
- A cost paid solely to activate Circulating Golden Core.

#### Perfected Circulating Golden Core

Choose two different benefits.

- Movement becomes 10 feet.
- Temporary Hit Points become `2 × Proficiency Bonus`.
- Domain Armament movement becomes 20 feet.

### Golden Core Reservoir

**Bonus Action**  
**Limit:** Once per scene

Regain Qi equal to:

`Proficiency Bonus + Qi Cultivation key ability modifier`

#### Perfected Golden Core Reservoir

Regain:

`2 × Proficiency Bonus + key ability modifier`

If you begin your turn with 0 Qi and Reservoir is unused:

- Activate it before any other recovery.
- It requires no Bonus Action.
- It remains once per scene.

---

## CL11 — Golden Core Efficiency

Once per turn, reduce the Qi cost of one Qi-powered feature with a final cost of at least 2 Qi by 1.

Cost order:

1. Base cost.
2. Optional surcharges.
3. Golden Core Efficiency.
4. Later permitted modifiers.

The final cost cannot be lower than 1 through this feature.

It does not stack with another feature reducing the same use unless explicitly permitted.

It cannot reduce:

- Post-resolution costs.
- Permanent sacrifice.
- Maximum-Qi reduction.
- Non-Qi costs.

---

## CL13 — Domain Armament Link

Your Domain Armament improves:

- Control range becomes 60 feet.
- Normal movement becomes 30 feet.
- Domain Armament Attack uses CL13 damage.

### Remote Technique Origin

When activating a non-Self Qi Path, Subpath, or Sphere technique, spend 1 additional Qi to originate it from yourself or your Domain Armament.

Measure from the selected origin:

- Range.
- Line of sight.
- Line of effect.
- Cover.
- Cones.
- Lines.
- Areas.
- Touch range when the Armament is within 5 feet.

Remote Technique Origin cannot transmit:

- A consumed physical object.
- A pill or potion that must enter the target’s body.
- A physical talisman unless the Domain Armament carries it legally.
- A weapon attack unless weapon delivery is authorized.
- Direct hand manipulation.
- A Self technique.
- An aura explicitly centered on your body.

It is blocked by:

- Total Cover.
- A sealed Formation.
- A spatial lock.
- A planar boundary.
- An effect explicitly blocking Qi transmission.

A technique uses one origin unless it explicitly permits multiple origins.

### Weapon-Delivered Remote Technique

A floating bound weapon may make the required weapon attack when a Source Rule explicitly authorizes weapon delivery.

Determine from the floating weapon:

- Attack range.
- Line of sight.
- Cover.
- Struck point.
- Technique origin.

The item must satisfy every weapon requirement.

A sword cannot deliver a technique requiring a bow. A shield cannot deliver a piercing technique unless it has a legal piercing attack.

---

## CL15 — Nascent Soul

Your Nascent Soul is a refined autonomous Qi structure. It is not Spirit Awakening spiritual authority.

### Second Defensive Discipline

Choose a second Cultivated Response discipline.

### Nascent Continuity

At the beginning of your turn, before other recovery, if you have 0 Qi:

- Regain Qi equal to your Proficiency Bonus.
- Use this once per scene.

This does not remove Exhaustion gained from reaching 0 Qi.

### Independent Concentration

**Reaction**  
**Trigger:** You fail a Constitution saving throw to maintain a Qi-powered feature.  
**Cost:** 1 Qi  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency.

### Nascent Armament Conduction

Once per turn, use Remote Technique Origin without paying its 1-Qi surcharge.

Your Domain Armament persists while you are Incapacitated, but ends if you become Unconscious.

---

## CL17 — Nine Heavens Gaze

**Action**  
**Cost:** 8 Qi  
**Duration:** 1 hour

Gain:

- Truesight 60 feet.
- Qi Sensing range 120 feet.
- Analyze Qi range 120 feet.
- Physical materials no longer block Qi Sensing within 30 feet, except lead, artifact shielding, or explicit Qi sealing.
- Perception of Formation lines, seals, projected Qi, possession links, transformations, Domain Armaments, and active cultivation routes.

### Heavenly Analysis

**Bonus Action**  
**Limit:** Once per turn  
**Range:** 120 feet

Choose one active effect.

Learn:

- Exact Source CL.
- Remaining duration.
- Whether it requires Concentration.
- Active tags.
- Its Anchor, if any.
- Its printed condition for ending or suppression.

An explicitly concealed effect whose Source CL exceeds yours requires a Cultivation Check against its save DC.

On failure:

- You know that it is concealed.
- You do not learn the details.
- You cannot retry until it changes or a new scene begins.

Nine Heavens Gaze does not reveal:

- Dormant abilities.
- Future actions.
- Memories.
- Thoughts.
- Exact Hit Points.
- Non-active secrets.

### Perfected Golden Core

Your selected Golden Core Form becomes Perfected.

### Domain Armament Damage

Domain Armament Attack uses CL17 damage.

---

## CL20 — Immortal of Qi

### Immortal Circulation

At the start of each of your turns, regain 5 Qi.

This functions in spiritually barren environments unless an effect explicitly suppresses Immortal circulation.

### Permanent Nine Heavens Gaze

Nine Heavens Gaze is always active:

- No Action required.
- No Qi cost.
- It remains suppressible.

### Twin Domain Armaments

You may maintain two Domain Armaments.

Manifest or release both through the same Bonus Action for 1 Qi.

Each may have:

- A separate projected form.
- A separate bound real item.
- A separate damage type.
- A separate mode.

Once during each of your turns, move both normally.

#### Twin Assault

When using your Bonus Action to attack:

- Make one Domain Armament Attack with each Armament in Assault Mode.
- Resolve them separately.
- Once-per-turn riders apply once across both attacks unless explicitly stated otherwise.
- A weapon-delivered technique applies to the first qualifying attack unless explicitly extended.
- Neither attack can generate another Domain Armament Attack.

#### Twin Guard

Two shield Armaments may protect two different creatures.

The same creature cannot add two shield bonuses from Twin Domain Armaments.

#### Remote Origins

Choose one Domain Armament as the origin of a technique unless it explicitly permits multiple origins.

### Complete Cultivated Response

Learn all three Defensive Disciplines.

### Second Golden Core Form

Choose a second Golden Core Form.

Both Forms are Perfected.

### Immortal Physiology

You:

- Do not age.
- Cannot die from old age.
- Do not require food, drink, air, or sleep.
- Still require rests and Cultivation Sessions to recover features whose rules require them.

---


## Realm Suppression — Qi Summary

When the universal Realm Suppression rule is active, use the suppressed CL and its Proficiency Bonus for Qi features barred or scaled by the suppressed Realm.

While suppressed, you cannot activate or benefit from:

- Qi Path or Subpath features whose minimum CL exceeds the suppressed CL.
- Higher-Realm Cultivation Insights, Sphere talents, Recorded Arts, Forged Techniques, Immortal Arts, Method powers, Foundation powers, or item powers barred by Realm Suppression.
- A higher-CL version of a scaling effect when a lower-CL version exists.

Realm Suppression does **not** reduce:

- Hit Points or Hit Dice.
- Maximum Qi.
- Path-chassis durability already embodied by the cultivator.
- A Foundation's passive physical quality unless the Foundation says otherwise.
- Existing injury, Corruption, debt, contract, karma, severance, or other consequences.

An active effect you can no longer legally maintain ends unless it has become an independent Asset, Anchor, injury, contract, or other persistent source under its printed rule. Effects that remain use the suppressed Source CL unless an independent source has its own fixed Source CL.

Realm Suppression cannot be used to refund costs, erase setup requirements, avoid a Variant conversion, or make a created consequence count as lower authority after the fact.

---

## Realm Identity

| Realm | Qi Cultivation expression |
|---|---|
| **Mortal, CL1–4** | Qi perception, technique potency, defensive circulation, meridian regulation |
| **Foundation, CL5–9** | Ranged Qi defense, safe descent, external Domain Armament |
| **Core Formation, CL10–14** | Golden Core Form, cost efficiency, advanced armament projection, remote origin |
| **Nascent Soul, CL15–19** | Autonomous circulation, reinforced Concentration, perfect perception, perfected Golden Core |
| **Immortal, CL20** | Continuous Qi, twin armaments, permanent gaze, multiple perfected Core forms |

---

## Domain Armament and Forged Technique Compatibility

A Forged Technique may combine weapon delivery or Domain Armament origin with:

- Barrage talents.
- Elemental damage.
- Elemental talent riders.
- Weapon talent riders.
- Forced movement.
- Conditions.
- Area conversion.
- Remote origins.

It must still define:

- Packet count.
- Talent count.
- Complexity.
- Qi cost.
- Weapon requirement.
- Projectile or attack count.
- Targeting.
- Attack rolls.
- Saving throws.
- Damage per projectile or attack.
- Rider frequency.
- Failure result.
- Anti-recursion rules.

Unless the Forged Technique explicitly pays for and authorizes a broader structure:

- Qi Technique Potency applies once per activation.
- A once-per-turn rider applies once across the Barrage.
- A once-per-target rider applies once to each target.
- A rider requiring damage applies only to a projectile or attack that deals damage.
- A missed attack does not carry its rider.
- A projectile cannot generate another projectile.
- An additional attack cannot generate another additional attack.

---

## Canonical Integration Contract

This R4 core is complete for Qi Cultivation publication preparation.

A PHB or main-book insertion must preserve:

- No saving throw proficiencies on the Path chassis.
- Defensive Disciplines as paid post-failure responses rather than proficiencies.
- Intelligence or Charisma as the chosen Qi key ability.
- The printed Qi maximum, recovery, and 0-Qi Exhaustion procedure.
- Qi Technique Potency once per activation.
- The first-qualifying-attack default for weapon delivery.
- Domain Armament support for projected forms and real bound weapons, shields, instruments, banners, cauldrons, needles, and other legally qualifying items without duplication.
- Golden Core Forms, Nascent Soul, Nine Heavens Gaze, and Immortal of Qi as printed.
- Level-selected Cultivation Insights with their printed +1 ability option; non-level awards do not automatically grant that increase.
- The Shared Qi Subpath Rules R4 procedures for Source CL, Assets, Anchors, fields, suppression, reconstruction, travel, high authority, and parent/Variant conversion.

The final PHB may shorten examples or move GM-facing adjudication to an appendix, but it must not silently change these mechanics or reintroduce obsolete features.

# Part II — Qi Cultivation Insights

## Tianxia Qi Cultivation Insights — Canonical R3: Ability-Integrated

> *A Path gives the river a bed. A Subpath teaches it a direction. An Insight changes what the river believes is possible.*

Cultivation Insights are major refinements, breakthroughs, inheritances, scars, licenses, realizations, and engineered mutations selected during Ability Score Improvement advancement at CL4, CL8, CL12, CL16, or CL19. A level-selected Insight grants its printed cultivation benefit and a +1 increase to one of its listed ability-score options. Insights may also be awarded through manuals, tribulations, relics, sect instruction, imperial office, bloodline awakening, experimentation, or story events.

An Insight is not restricted to the scale of a minor conventional character option. It may alter circulation, expand a Golden Core, bind a treasure, change elemental authority, preserve a Formation, or establish a new cultivation procedure. Its limits arise from its prerequisites, cost, preparation, Source CL, cultivation authority, and printed consequences.

### Universal Insight Rules

**Rule references.** Use Qi Cultivation Canonical Core R4 for level selection, Qi, Golden Core, Nascent Soul, and Domain Armament rules. Use Shared Qi Subpath Rules R4 for Source CL, Assets, Anchors, fields, suppression, reconstruction, weapon delivery, and high-authority interaction. An explicit Insight rule overrides those defaults only for its printed exception.

- You must meet every prerequisite when the Insight is gained.
- **Level-selected Insight:** When you choose an Insight at CL4, CL8, CL12, CL16, or CL19 instead of a normal Ability Score Improvement, gain the Insight and apply its printed **Ability Increase (Level Selection)**.
- **Other sources:** An Insight awarded through a manual, tribulation, relic, sect instruction, imperial office, bloodline awakening, experimentation, story event, or another source grants only its cultivation benefit unless that source explicitly grants an ability-score increase.
- An Insight ability increase cannot raise a score above the maximum allowed by your current Realm. If every listed option is already at that maximum, you may still select or gain the Insight, but the ability increase is lost.
- Background ability-score increases and Origin Insights are separate character-creation benefits. They do not activate a Qi Insight's level-selection ability increase.
- Unless an Insight is marked **Repeatable**, select it once.
- An Insight uses your Qi Cultivation Source CL unless it explicitly derives authority from another source.
- If an Insight grants a new Sphere, it also grants the normal free talent gained whenever a character learns a new Sphere. The Insight does not waive Secret, Restricted, inherited, or narrative access requirements.
- A cost reduction cannot lower a Qi cost below 1 unless the Insight explicitly permits a cost of 0.
- Two cost reductions do not apply to the same activation unless one of them explicitly permits stacking.
- A copied, repeated, or extended technique still pays every permanent sacrifice, material cost, item charge, Corruption cost, maximum-Qi cost, or other non-Qi cost.
- An Insight does not duplicate a real weapon, shield, artifact, consumable, companion, spirit, or Formation Anchor.
- When a cultivation effect is applied through multiple attacks, it affects only the first qualifying attack unless an Insight or Source Rule expressly authorizes and prices additional deliveries.
- **Forbidden**, **demonic**, heretical, orthodox, imperial, and sectarian are social or access classifications unless a rule explicitly applies a mechanical tag such as **Daemonic**, **Void**, **Karma**, or **Secret**.

---

## General Qi Insights

### Expanded Dantian

**Prerequisite:** Qi Cultivation, CL4+  
**Repeatable:** Twice

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase your maximum Qi by:

`2 × your Proficiency Bonus`

Recalculate this increase whenever your Proficiency Bonus changes.

If selected twice, both increases apply.

---

### Meridian Economy

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, after a Qi-powered feature resolves successfully and you actually paid at least 2 Qi for that activation, regain 1 Qi.

Meridian Economy:

- Resolves after the complete feature.
- Does not reduce the feature's cost.
- Does not trigger from refunded Qi.
- Does not trigger when the final amount actually paid was 0 or 1 Qi.
- Cannot trigger itself or create a closed refund loop.
- Functions alongside Golden Core Efficiency because it is recovery rather than a cost reduction.

---

### Thunderstep

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, immediately after you spend Qi on a feature that resolves successfully, move up to 10 feet without provoking Opportunity Attacks.

At CL12, this movement may:

- Travel vertically along a wall.
- Cross an unsupported gap.
- Move across a liquid surface.

You must end on a legal supporting surface unless another feature supports you.

If Circulating Golden Core also triggers, you may use both movements or combine them into one continuous movement.

---

### Fivefold Conversion

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When activating a Qi-powered feature that deals Acid, Cold, Fire, Lightning, or Thunder damage, spend 1 additional Qi to change any amount of that damage to another type from the same list.

Declare the conversion before attack rolls or saving throws are resolved.

The conversion:

- Changes damage type.
- Does not automatically change the feature's Sphere, elemental, weather, or metaphysical tags.
- Does not add a rider belonging to the new damage type.
- Applies once across a Barrage, area, or multiattack activation.
- May convert technique damage delivered through a weapon, but does not convert ordinary weapon damage unless the delivery rule explicitly permits it.

At CL16, you may instead spend 2 additional Qi to convert the chosen damage to Force.

---

### Meridian Overchannel

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature deals damage or restores Hit Points, spend additional Qi up to your Proficiency Bonus.

Add `1d8` to one damage or healing roll for each additional Qi spent.

For every Qi spent beyond the first 2, take `1d8` Force strain after the feature resolves.

Force strain from this Insight:

- Cannot be reduced.
- Cannot be prevented.
- Cannot be redirected.
- Cannot be converted into another damage type.
- Cannot generate Qi, charges, Temporary Hit Points, or retaliatory effects.

Meridian Overchannel adds dice to one roll, not once per target, projectile, attack, or healing recipient.

---

### Elemental Counterflow

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You take Acid, Cold, Fire, Lightning, or Thunder damage.  
**Cost:** 2 Qi

Gain Resistance to the triggering damage type against that damage packet.

After damage resolves, choose one:

- Move 10 feet without provoking Opportunity Attacks.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.
- Your next damaging Qi-powered feature before the end of your next turn may deal the triggering damage type.
- Move your Domain Armament up to 20 feet.

Elemental Counterflow cannot respond to damage you willingly dealt to yourself solely to trigger it.

---

### Qi Devourer

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When an essence-bearing creature within 60 feet is reduced to 0 Hit Points after you damaged it during the current scene, you may consume a portion of its escaping cultivated essence without using an action.

Regain Qi equal to the lower of:

- Your Proficiency Bonus.
- The creature's CL, minimum 1.

You may use Qi Devourer once per round.

A creature yields essence to you once until its life-force, spirit, or cultivation has been fully restored. Repeatedly reviving the same depleted creature does not refresh it unless the restoration effect explicitly rebuilds the consumed essence.

A construct, illusion, projected clone, summoned disposable body, or creature you created solely as a refund engine does not yield essence unless it possesses an independent genuine soul, life-force, or cultivation source.

Qi Devourer can be used on captives, condemned enemies, sacrificial victims, or willing donors when they genuinely possess consumable essence. Such use may be criminal, forbidden, praised, tolerated, or condemned according to the culture involved; it does not automatically gain the Daemonic tag.

---

### Heaven's Conduit

**Prerequisite:** Qi Cultivation, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Limit:** Once per scene

Regain 10 Qi and gain 1 level of Exhaustion.

The Exhaustion:

- Cannot be prevented.
- Cannot be transferred.
- Cannot be removed before the current scene ends.
- Can accumulate if you use Heaven's Conduit in later scenes before recovering.

If the regained Qi would exceed your maximum, the excess becomes unstable overflow that disappears at the end of the current turn.

---

### Meridian Fortress

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws and Cultivation Checks against:

- Qi drain.
- Maximum-Qi reduction.
- Meridian sealing.
- Forced cost increases.
- Cultivation Point theft.
- Effects preventing Qi recovery.

Once per round, when a hostile effect would reduce your current Qi or maximum Qi, reduce that loss by your Proficiency Bonus.

If you possess Stable Golden Core, add this reduction to Stable Golden Core's reduction. This is an explicit stacking exception.

Meridian Fortress does not reduce Qi you willingly spend or sacrifice.

---

### Refined Meridian Regulation

**Prerequisite:** Meridian Regulation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Meridian Regulation gains a range of 10 feet when used through direct Qi projection, a needle, a medical implement, or your Domain Armament.

You may also target:

- Charmed caused by a poison, drug, disease, bodily parasite, or meridian disturbance.
- Blinded or Deafened caused by smoke, ash, poison, pressure, or a directly impaired organ.
- One ordinary Bleeding effect.
- One temporary meridian blockage.

Against an effect whose Source CL is lower than yours, a successful repeated save also suppresses its ongoing damage until the end of the target's next turn.

This Insight does not allow Meridian Regulation to remove a Curse, Tribulation, Foundation Injury, Hidden Injury, permanent transformation, completed possession, Soul Damage, or conceptual severance unless another Source Rule expressly expands it.

---

### Restorative Circulation

**Prerequisite:** Qi Cultivation, CL4+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when a Qi-powered feature restores Hit Points to one or more creatures, choose one recipient.

Increase the healing it receives by your Proficiency Bonus.

If the target is already at maximum Hit Points after the healing, it instead gains Temporary Hit Points equal to your Proficiency Bonus.

At CL12, when the chosen target is at 0 Hit Points, increase the healing by `2 × your Proficiency Bonus` instead.

Restorative Circulation applies once per activation, not once per healing die, target, pulse, or repeated tick.

---

### Qi-Tempered Concentration

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You fail a Constitution saving throw to maintain a Qi-powered feature.  
**Cost:** 2 Qi

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency and cannot modify the same saving throw more than once.

At CL15, this Insight improves Independent Concentration:

- Independent Concentration may protect any cultivation feature you maintain, not only a Qi feature.
- When Independent Concentration turns failure into success, choose one: move 5 feet without provoking Opportunity Attacks, move your Domain Armament 10 feet, or gain Temporary Hit Points equal to your Proficiency Bonus.

---
## Martial and Domain Armament Insights

### Cultivated Weapon Channel

**Prerequisite:** Qi Cultivation, proficiency with the chosen weapon group, CL4+  
**Repeatable:** Choose a different weapon group each time

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one weapon group with which you are proficient.

When you make a weapon attack specifically to deliver a Qi-powered cultivation technique through a weapon from that group, you may use your Qi Cultivation key ability instead of Strength or Dexterity for:

- The delivery attack roll.
- The weapon's damage modifier on that qualifying attack.

This Insight does not change ordinary attacks made without weapon delivery.

---

### Weapon-and-Technique Weave

**Prerequisite:** Qi Cultivation, proficiency with at least one weapon, CL4+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, gain one Weave benefit:

- After you hit with a weapon attack, gain +1 to the next Cultivation Attack you make before the end of your next turn.
- After a creature fails a saving throw against your Qi-powered technique, gain +1 to the next weapon attack you make before the end of your next turn.
- After you activate a Qi-powered technique through a weapon, move 5 feet without provoking Opportunity Attacks from the target struck or affected.

Only one Weave benefit may be active at a time. Gaining another replaces the previous benefit.

---

### Armored Meridian Circulation

**Prerequisite:** Qi Cultivation, proficiency with medium armor, heavy armor, or shields, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

This Insight grants no armor or shield proficiency.

While wearing armor or using a shield with which you are proficient:

- Gain Advantage on saving throws against being knocked Prone.
- Reduce forced movement affecting you by 5 feet.
- Once per round, after you spend Qi on a feature that resolves successfully, reduce the next damage packet you take before the start of your next turn by your Proficiency Bonus.

High-quality armor, heavy armor, and shields do not interfere with your Qi techniques unless a specific item, curse, Method, or Source Rule says otherwise.

---

### Heavy Armament Conduction

**Prerequisite:** Qi Cultivation, proficiency with a two-handed heavy weapon or another weapon classified as a heavy armament, CL8+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when you hit with a heavy weapon while delivering a Qi-powered cultivation technique, spend 1 additional Qi to apply Heavy Conduction.

Add the weapon's base damage dice one additional time to that hit.

Against an unattended object, vehicle, structure, temporary barrier, Formation Anchor, or Cultivation Asset, also choose one:

- Treat Damage Threshold as 0 for the hit.
- Ignore ordinary Resistance to the weapon's damage.
- Push or displace the target section 5 feet when physically possible.
- Deal an additional `2d8` Force damage.

Heavy Conduction applies only to the first qualifying attack unless another rule expressly extends it.

---

### Barrage Conduction

**Prerequisite:** Qi Cultivation, CL12+, and a Barrage Sphere talent, multiattack Recorded Art, or another authorized multiattack cultivation procedure

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a weapon-delivered cultivation technique would normally apply only to the first qualifying attack in an authorized Barrage, volley, or multiattack sequence, you may extend it.

Before making any attacks, pay:

`1 additional Qi for each additional attack that will carry the technique`

You may extend the technique to a maximum number of attacks equal to your Proficiency Bonus.

Unless the technique explicitly states otherwise:

- A once-per-activation rider still applies once.
- Qi Technique Potency still applies once.
- A missed attack does not deliver the technique.
- Each attack must satisfy the weapon and target requirements.
- Additional attacks cannot generate more additional attacks.

---

### Armament Commander

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Domain Armament improves:

- Control range increases by 30 feet.
- Movement increases by 15 feet.
- Calling or releasing a bound item may occur at any point during your turn without using an action, once per turn.

Once per turn when your Domain Armament hits, choose one:

- Push or pull the target 5 feet.
- The target cannot take Reactions until the start of its next turn.
- Move yourself 5 feet without provoking Opportunity Attacks.
- Move the Armament 10 feet.
- Reveal the target with visible Qi until the start of your next turn; Invisible does not conceal it from you.
- Gain Advantage on your next Cultivation Attack against that target before the end of your next turn.

---

### Elemental Armament

**Prerequisite:** Domain Armament, one elemental Sphere or an elemental Qi Subpath, CL12+  
**Repeatable:** Choose a different element each time

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one damage type associated with an elemental Sphere you know.

Your projected Domain Armament may deal that damage type. A bound real item may apply the elemental damage to its Domain Armament Attack without changing its ordinary wielded damage.

Once per turn when the Armament hits with the chosen damage type, choose one:

- Deal additional damage equal to your Proficiency Bonus.
- Push or pull the target 5 feet.
- Reduce its Speed by 10 feet until the start of your next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Move the Armament 10 feet.

The rider must be thematically and mechanically compatible with the selected element as recorded when the Insight is gained.

---

### Guardian Armament

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When your Domain Armament is in Guard Mode, its protected creature may remain within 10 feet of it rather than 5 feet.

**Reaction**  
**Trigger:** The protected creature is hit by an attack roll.  
**Cost:** 1 Qi

Reduce the triggering damage by:

`2d8 + your Qi Cultivation key ability modifier`

At CL17, the reduction becomes:

`3d8 + your Qi Cultivation key ability modifier`

If the damage is reduced to 0, move the protected creature or the Armament 5 feet without provoking Opportunity Attacks.

Guardian Armament can protect against melee or ranged attack rolls, but it does not apply to saving-throw effects or automatic damage.

---

### Named Treasure Recall

**Prerequisite:** Qi Cultivation, one named weapon, shield, instrument, or cultivation implement that recognizes your bond, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You always know the direction of the named treasure while it is on the same plane.

**Bonus Action**  
**Cost:** 1 Qi

Call the treasure to a legal free hand or floating Domain Armament position from up to 1 mile away.

The call is supernatural movement and may cross ordinary intervening distance, but it is blocked by:

- A sealed Formation.
- A spatial lock.
- An artifact restraint.
- A higher-authority ownership or control effect.
- A planar boundary.

Once per scene, while holding or controlling the treasure, add your Proficiency Bonus to one failed saving throw, potentially turning it into success.

The item is never duplicated.

---

### Shield Orbit Discipline

**Prerequisite:** Domain Armament capable of Guard Mode, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

A shield or defensive Domain Armament may change its protected creature once per turn without using an action.

**Reaction**  
**Trigger:** A creature within 15 feet of the Armament is hit by an attack roll.  
**Cost:** 1 Qi

Move the Armament up to 15 feet to a legal point adjacent to that creature and increase its AC against the triggering attack by 2.

This can cause the attack to miss.

After the reaction, the creature becomes the Armament's protected creature until the start of your next turn.

The Armament must have a legal path and cannot cross a sealed Formation, spatial lock, or solid barrier.

---

### Remote Weapon Conduction

**Prerequisite:** Domain Armament Link, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a floating bound weapon delivers a cultivation technique, waive the 1-Qi Remote Technique Origin surcharge once per turn.

At CL15, this free use is separate from Nascent Armament Conduction. You may therefore waive the surcharge for:

- One weapon-delivered remote technique through this Insight.
- One other remote-origin technique through Nascent Armament Conduction.

A single technique still uses one origin unless it expressly permits multiple origins.

---

### Companion Armament

**Prerequisite:** Domain Armament, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

You may maintain two Domain Armaments before CL20.

Manifest or release both through the same Bonus Action for 2 Qi.

Before CL20:

- Move both during your turn.
- One may attack through your Domain Armament Bonus Action.
- The other may remain in Guard Mode or serve as a technique origin.
- You cannot make two Domain Armament Attacks from the same Bonus Action.
- A technique uses one origin unless expressly permitted otherwise.

At CL20, Immortal of Qi upgrades both Armaments to the full Twin Domain Armament rules. This Insight then allows you to maintain a third Armament, but only two may attack during the same turn and the third must Guard, carry an authorized field, or act as an origin.

---

### Armament Formation Node

**Prerequisite:** Domain Armament and the Formations Sphere, Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another Formation-authorized Source Rule, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Your Domain Armament may serve as one movable Formation Anchor.

When used as an Anchor:

- It uses the better of its item durability or `AC equal to your Cultivation Save DC` and `Hit Points equal to 3 × your CL`.
- It may move normally unless the Formation expressly requires a fixed Anchor.
- Moving it repositions only effects that the Formation permits to move.
- If it is suppressed, restrained, or forced out of legal range, the anchored portion is suppressed.
- A real bound item is not duplicated or made indestructible.

Once per turn after moving the Anchor, gain one of the following until the start of your next turn:

- +1 AC for one ally inside the Formation.
- Move one willing creature in the Formation 5 feet.
- Extend one Formation line by 5 feet.
- Reveal one creature touching a Formation boundary.

---

### Armament Reversal

**Prerequisite:** Domain Armament, CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** A creature within 5 feet of your Domain Armament misses you or its protected creature with an attack roll.  
**Cost:** 2 Qi

Make one Domain Armament Attack against the triggering creature.

On a hit, choose one:

- Push it 10 feet.
- It cannot take Reactions until the start of its next turn.
- Move the protected creature 5 feet without provoking Opportunity Attacks.
- Change the Armament between Assault and Guard Mode.

Armament Reversal cannot trigger another additional attack or repeat a weapon-delivered cultivation technique unless that technique expressly permits reaction delivery.
## Elemental Refinement Insights

### Elemental Mastery

**Prerequisite:** Qi Cultivation, access to the chosen damage type, CL4+  
**Repeatable:** Choose a different damage type each time

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose Acid, Cold, Fire, Lightning, Necrotic, Poison, Radiant, or Thunder.

Once per activation, when a Qi-powered feature deals the chosen damage type, add your Proficiency Bonus to one damage roll.

At CL12, the activation ignores ordinary Resistance to the chosen type.

At CL18, ordinary Immunity to the chosen type is treated as Resistance instead.

Elemental Mastery does not bypass:

- Artifact protection.
- Secret authority.
- Conceptual Immunity.
- An effect explicitly described as absolute or higher-order.

---

### Elemental Fusion Body

**Prerequisite:** Elemental Mastery, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to the damage type selected for one Elemental Mastery Insight.

Once per round, after a meaningful hostile source damages you with that type, choose one:

- Regain 1 Qi.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Move 5 feet without provoking Opportunity Attacks.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.

A harmless source, willing ally, environmental loop you arranged, or damage you dealt to yourself solely to trigger this Insight does not qualify.

If another feature already grants Resistance to the selected type, reduce the first damage packet of that type each round by your Proficiency Bonus instead.

---

### Elemental Core Mutation

**Prerequisite:** Qi Cultivation, one elemental Sphere, CL8+  
**Repeatable:** Choose a different elemental Sphere each time

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one elemental Sphere you know.

At the end of a Full Cultivation Session, choose one mutation. It remains until you complete another Full Cultivation Session and choose again.

#### Resistant Mutation

Gain Resistance to one damage type directly associated with the Sphere.

#### Violent Mutation

Once per turn, one damaging feature from the Sphere deals additional damage equal to your Proficiency Bonus.

#### Driving Mutation

Increase one forced movement caused by the Sphere by 10 feet once per turn.

#### Flowing Mutation

Once per turn after activating a feature from the Sphere, move 10 feet without provoking Opportunity Attacks.

#### Sheltering Mutation

Once per turn after activating a feature from the Sphere, you or one affected ally gains Temporary Hit Points equal to `2 × your Proficiency Bonus`.

#### Expansive Mutation

Once per turn, increase one radius or cone by 5 feet or one line by 10 feet.

A single activation benefits from one mutation granted by this Insight.

---

### Dual-Element Golden Core

**Prerequisite:** Two elemental Spheres, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

Choose two elemental Spheres you know.

When you activate a Qi-powered feature from one chosen Sphere, your next feature from the other chosen Sphere before the end of your next turn gains one Fusion benefit:

- Reduce its Qi cost by 1, minimum 1.
- Add your Proficiency Bonus to one damage or healing roll.
- Increase one forced movement by 10 feet.
- Move 10 feet without provoking Opportunity Attacks after it resolves.
- Grant one affected ally Temporary Hit Points equal to `2 × your Proficiency Bonus`.

Use one Fusion benefit per turn.

Repeatedly using the same element does not generate Fusion.

---

### Five-Element Meridian Cycle

**Prerequisite:** Five Elements Cultivator or at least three elemental Spheres, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you activate Qi-powered features carrying three different elemental alignments during the same scene, gain 1 Cycle Charge after the third resolves.

- Maximum Cycle Charges: Your Proficiency Bonus.
- Each distinct activation can count toward one sequence.
- Repeating an element before completing the sequence does not erase progress but does not advance it.
- A new sequence begins after a charge is gained.

Spend 1 Cycle Charge when activating a Qi-powered feature to choose one:

- Reduce its Qi cost by 1, minimum 1.
- Add `2d8` to one damage or healing roll.
- Increase one forced movement by 10 feet.
- Increase one radius or cone by 5 feet or one line by 10 feet.
- Grant one affected ally Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain +2 AC until the start of your next turn.

Unused Cycle Charges disappear when the scene ends.

---

### Elemental Dominion

**Prerequisite:** Elemental Mastery, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence or Charisma score by 1, to the maximum allowed by your current Realm.

**Action**  
**Range:** 90 feet  
**Area:** 20-foot-radius, 20-foot-high cylinder  
**Duration:** 1 minute  
**Concentration:** Required  
**Cost:** 6 Qi

Create a Dominion of the damage type chosen for Elemental Mastery.

For the duration:

- Your Qi-powered features of the selected type may originate from any point inside the Dominion.
- Allies you choose gain Resistance to the selected type while inside.
- The first time during each turn that a hostile creature takes the selected damage inside, it takes additional damage equal to your Proficiency Bonus.
- An ordinary environmental expression of the element obeys your printed direction inside the area.

When a hostile persistent elemental effect of an opposing or incompatible type overlaps the Dominion:

- If its Source CL is lower than yours, suppress it in the overlap.
- If its Source CL is equal to or higher than yours, make a Cultivation Check against its save DC. On success, suppress it in the overlap until the start of your next turn.

Elemental Dominion is a Qi field, not a Spirit Awakening Domain.

---
## Golden Core and Nascent Soul Insights

### Stable Core Refinement

**Prerequisite:** Stable Golden Core, CL10+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When Stable Golden Core reduces hostile Qi loss, gain Temporary Hit Points equal to your Proficiency Bonus.

**Reaction**  
**Trigger:** You fail a saving throw or Cultivation Check against meridian sealing, Golden Core damage, Qi theft, maximum-Qi reduction, or forced cost increase.  
**Cost:** 1 Qi

Add your Proficiency Bonus to the roll, potentially turning failure into success.

When Stable Golden Core becomes Perfected, this Reaction costs 0 Qi once per round.

---

### Circulating Core Refinement

**Prerequisite:** Circulating Golden Core, CL10+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Whenever Circulating Golden Core triggers, choose one additional different benefit.

Before Perfected Circulating Golden Core, choose two different benefits instead of one.

After it becomes Perfected, choose three different benefits instead of two.

You may also change one Domain Armament between Assault and Guard Mode as part of the trigger.

A single named benefit cannot be selected twice from the same trigger.

---

### Reservoir Core Refinement

**Prerequisite:** Golden Core Reservoir, CL10+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Golden Core Reservoir gains a second use during each scene.

When you use it a second time during the same scene:

- Regain the normal amount.
- Gain 1 level of Exhaustion after the Qi is restored.

This Exhaustion:

- Cannot be prevented.
- Cannot be transferred.
- Cannot be removed before the scene ends.

After Golden Core Reservoir becomes Perfected, the second use restores the Perfected amount.

---

### Compressed Golden Core

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when you activate a Qi-powered feature, compress it in one of these ways:

#### Single-Target Compression

If the feature affects exactly one target, add your Proficiency Bonus to one damage or healing roll and increase its save DC by 1.

#### Area Compression

Reduce one printed area dimension by at least 5 feet. Add your Proficiency Bonus to one damage or healing roll against one target in the reduced area and subtract 1 from the first saving throw made against it.

#### Line Compression

Reduce a line's width to 5 feet or reduce its length by at least 20 feet. The line ignores Half Cover and Three-Quarters Cover.

A feature cannot benefit from Compressed and Expansive Golden Core during the same activation.

---

### Expansive Golden Core

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, spend 1 additional Qi to increase one area dimension of a Qi-powered feature:

- Radius: +10 feet.
- Cone length: +10 feet.
- Line length: +20 feet.
- Cube side: +10 feet.
- Aura radius: +5 feet.
- Wall length: +20 feet.

Expansive Golden Core cannot increase:

- A Self-only feature into an area.
- A strategic-scale area.
- A permanent structure beyond its printed material.
- An area whose Source Rule explicitly cannot be expanded.

A feature cannot benefit from Compressed and Expansive Golden Core during the same activation.

---

### Core-Sheltering Scripture

**Prerequisite:** Qi Cultivation, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws and Cultivation Checks against:

- Golden Core damage.
- Core extraction.
- Forced Core mutation.
- Core imprisonment.
- Suppression of your Golden Core Form.
- Effects attempting to replace your Golden Core.

Once per round, when a hostile effect suppresses or damages a Golden Core function, choose one:

- Spend 2 Qi to delay the suppression until the end of your current turn.
- Reduce its duration by one round, minimum one round.
- Move 10 feet without provoking Opportunity Attacks before the suppression fully takes hold.
- Transfer the effect's Anchor mark to your Domain Armament when the effect can legally target it; the Armament becomes the affected Anchor instead.

A Secret or higher-authority effect may require a Cultivation Check against its save DC to use the final option.

---

### Nascent Soul Reserve

**Prerequisite:** Nascent Soul, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Nascent Continuity restores:

`2 × your Proficiency Bonus Qi`

instead of your Proficiency Bonus.

When Nascent Continuity activates, choose one:

- End Charmed or Frightened when its Source CL is no higher than yours.
- End Grappled or Restrained when its Source CL is no higher than yours.
- Move 15 feet without provoking Opportunity Attacks.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Gain Advantage on your next Cultivation Attack before the end of your next turn.
- Restore a suppressed Domain Armament to a legal point within 30 feet when the suppressing Source CL is lower than yours.

Against a higher-CL condition, you may immediately repeat its saving throw with Advantage instead of ending it.

---

### Borrowed Golden Form

**Prerequisite:** Qi Cultivation, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Cost:** 4 Qi  
**Limit:** Once per scene  
**Duration:** Until the scene ends

Choose one Golden Core Form you do not currently possess.

Gain its unperfected benefits for the duration.

At CL17, the borrowed Form remains unperfected unless another Source Rule explicitly perfects it.

At CL20, when you permanently possess two Perfected Forms, Borrowed Golden Form may grant the third Form in its Perfected state for the scene.

A borrowed Golden Core Reservoir begins unused, but its use disappears when the borrowed Form ends.

---

### Nascent Soul Externalization

**Prerequisite:** Nascent Soul, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

**Bonus Action**  
**Cost:** 4 Qi  
**Duration:** 1 minute

Project your Nascent Soul into an unoccupied point within 30 feet.

The projection:

- Is not a separate creature.
- Occupies no space.
- Has Fly Speed 30 feet and Hover.
- Moves up to 30 feet once during each of your turns without using an action.
- May serve as the origin of a non-Self Qi-powered technique once per turn.
- May maintain line of sight for your Domain Armament.
- Reveals your spiritual position to Qi Sensing.

If the projection is struck by an effect that explicitly targets souls, Nascent Souls, or projected cultivation structures, use your statistics and Source CL. On a failed save, take the effect normally and the projection ends.

The projection ends if it moves more than 60 feet from you, you become Unconscious, or it is successfully sealed.
## Preparation and Strategic Insights

### Formation Apprentice

**Prerequisite:** Formations Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain +2 on Cultivation Checks involving:

- Formation design.
- Formation identification.
- Formation repair.
- Formation disruption.
- Anchor placement.
- Formation maintenance.

During a short rest or 10-minute preparation procedure, create one temporary Minor Anchor from available materials.

The Anchor:

- Uses your Source CL.
- Has AC equal to your Cultivation Save DC.
- Has Hit Points equal to `2 × your CL`.
- Lasts until destroyed, dismissed, or you complete a long rest.
- Can support only a Formation effect that explicitly accepts a Minor or temporary Anchor.

You may maintain one temporary Minor Anchor from this Insight.

---

### Formation Engineer

**Prerequisite:** Formation Apprentice, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

One Formation Anchor you create or maintain gains:

- Additional Hit Points equal to your CL.
- Damage Threshold equal to your Proficiency Bonus when it lacks a higher threshold.
- Advantage on saving throws against forced movement and suppression.

Reduce ordinary material requirements and preparation time for non-Secret Formations by 25 percent.

**Reaction**  
**Trigger:** One visible Formation Anchor within 60 feet would be reduced to 0 Hit Points.  
**Cost:** 2 Qi

The Anchor remains at 1 Hit Point instead.

An Anchor can benefit from this reaction once per scene.

---

### Talisman Savant

**Prerequisite:** Talismans Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, when activating a non-ritual talisman that normally requires an Action, spend 1 additional Qi to activate it as a Bonus Action instead.

This Insight cannot accelerate:

- A permanent inscription.
- A strategic-scale talisman.
- A Secret talisman.
- A resurrection effect.
- A talisman requiring more than one Action of continuous activation.
- An item whose printed activation cannot be accelerated.

All charges, consumed materials, target limits, and other costs remain unchanged.

---

### Seal Breaker

**Prerequisite:** Talismans Sphere, Cultivator of Seals, Puzzle Cultivator, Calligraphy Cultivator, or another seal-authorized Source Rule, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on Cultivation Checks to detect, identify, weaken, solve, or remove seals.

**Reaction**  
**Trigger:** A visible seal, lock, binding script, or cultivation prison within 60 feet activates.  
**Cost:** 2 Qi

Make a Cultivation Check against its save DC.

- **Success:** Suppress the activation until the end of the current turn. If the effect requires a target decision, movement, payment, or attack, that portion fails for the turn.
- **Failure:** The effect activates normally, but you learn its Source CL, Anchor direction, and one printed escape or release condition.

Against a seal whose Source CL is 6 or more lower than yours, you may instead break one nonpermanent layer automatically.

---

### Jade Inscription Master

**Prerequisite:** Talismans Sphere, Sigil Scribe, Calligraphy Cultivator, or another durable-inscription Source Rule, CL12+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Increase the number of durable inscriptions you may maintain by 2.

Choose one durable inscription you create. It may store two charges instead of one.

When its normal recovery procedure would restore charges:

- It restores one charge.
- A Full Cultivation Session performed while touching it restores all missing charges.

A second charge does not duplicate a consumed material, permanent sacrifice, or irreplaceable item component.

---

### Cauldron Heart

**Prerequisite:** Alchemy and Pill Forging Sphere or Alchemical Cultivator, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain +2 on Cultivation Checks involving:

- Brewing.
- Pill diagnosis.
- Ingredient substitution.
- Cauldron stabilization.
- Poison identification.
- Medicine refinement.

Once during each distinct crafting procedure, after failing a crafting or stabilization check, reroll it.

You must use the new result.

If the reroll also fails, choose one consequence reduction:

- Prevent the cauldron or workshop from being destroyed.
- Preserve half of the ordinary ingredients.
- Contain the failure to a 5-foot area.
- Learn the exact failed stage and required corrective material.

This Insight cannot preserve a Secret ingredient, permanent sacrifice, or irreplaceable relic consumed by the procedure.

---

### Portable Workshop

**Prerequisite:** One preparation-based Sphere or Subpath, CL8+  
**Repeatable:** Choose a different workshop type each time

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one workshop type, such as:

- Alchemical cauldron.
- Talisman desk.
- Formation bench.
- Smithing forge.
- Medical clinic.
- Calligraphy table.
- Inscription frame.
- Culinary station.
- Kiln.

You possess or construct a portable version.

Benefits:

- Setup and breakdown time are halved.
- Routine downtime work may continue during ordinary travel when the environment permits.
- The workshop counts as proper tools for trained procedures.
- It protects ordinary materials from weather and travel damage.

It does not permit major projects while moving, waive rare facilities, or replace a required ley line, furnace, laboratory, spirit spring, or strategic Formation.

---

### Imperial Quartermaster Training

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain one skill or tool proficiency related to logistics, administration, vehicles, trade, appraisal, or supply. If already proficient, gain +2 on checks using it.

During expedition preparation, choose two Quartermaster benefits:

- Reduce ordinary supply costs by 20 percent.
- Acquire one Common consumable appropriate to the location without a separate search procedure.
- Identify the most likely logistical failure before departure.
- Establish one concealed mundane cache.
- Gain Advantage on one bureaucracy, requisition, customs, or military-supply check.
- Increase the carrying capacity of one vehicle or storage Formation by 25 percent through correct loading.

The benefit lasts for that expedition or operation and does not create rare, Restricted, or Secret goods.

---

### Field Refinement Doctrine

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

When you complete a short rest, you may perform one 10-minute Field Refinement on an existing non-Secret Cultivation Asset, Domain Armament, Formation Anchor, talisman, medical implement, or prepared vessel.

Choose one benefit lasting until the end of the next scene:

- Increase its Hit Points by `2 × your Proficiency Bonus`.
- Increase its movement by 10 feet.
- Increase one operating range by 10 feet.
- Grant it Advantage on the first saving throw it makes.
- Allow it to ignore the first ordinary suppression effect whose Source CL is lower than yours.
- Reduce the Qi cost of its first activation by 1, minimum 1.

An object or asset may hold one Field Refinement.

---
## Imperial Training Insights

### Imperial Academy Graduate

**Prerequisite:** Recognized academy access, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain proficiency in Arcana and History. If already proficient in either, gain +2 on checks using that skill instead.

Also gain one:

- Language.
- Script.
- Tool proficiency.
- Bureaucratic credential.

Once per scene, reroll one failed institutional, legal, historical, scholarly, or technical Cultivation Check.

You must use the new result.

Academy status creates obligations, records, superiors, rivals, and possible service requirements according to the institution.

---

### Imperial Examination Laureate

**Prerequisite:** Imperial Academy Graduate, successful examination or equivalent recognition, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one academy-approved Sphere to which you have legal and narrative access.

Learn that Sphere and gain its normal free first talent under the universal new-Sphere rule.

In addition:

- Training time for academy-approved talents is reduced by 25 percent.
- Gain Advantage on checks to obtain legal manuals, teachers, archives, and licenses from officials recognizing your rank.
- Once per CL, one academy-approved training attempt may be retried after half the normal failed-training delay.

Rank does not waive Secret access, inheritance requirements, sect exclusivity, or political obligations.

---

### Imperial Officer's Circulation

**Prerequisite:** Military, guard, administrative, or command training, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When Initiative is rolled, choose one ally within 30 feet.

That ally gains +2 to its Initiative result for the scene. This may change order immediately.

**Reaction**  
**Trigger:** An ally within 30 feet fails a saving throw.  
**Cost:** 2 Qi

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

This is not saving throw proficiency and cannot modify death, breakthrough, or training rolls.

If the save succeeds after this bonus, move the ally 5 feet without provoking Opportunity Attacks or allow it to stand from Prone.

---

### Provincial Ley-Line Familiarity

**Prerequisite:** Qi Cultivation, CL8+  
**Repeatable:** Choose a different province or ley-line region each time

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

Choose one province, watershed, mountain chain, city network, or comparable ley-line region you have studied.

Within that region:

- You always know the direction of the nearest major usable ambient-Qi source within 10 miles when one exists.
- A Full Cultivation Session requires 1 hour instead of 2 hours at a healthy local source.
- When Initiative is rolled while directly connected to an active local ley line, regain Qi equal to your Proficiency Bonus once per scene.
- Gain Advantage on checks to identify local Formations, spirit roads, Qi pollution, and regional cultivation traditions.

A damaged, poisoned, sealed, or hostile ley line may withhold or corrupt these benefits according to its printed state.

---

### Imperial Archivist

**Prerequisite:** Qi Cultivation, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence or Wisdom score by 1, to the maximum allowed by your current Realm.

At the end of a long rest or Full Cultivation Session, prepare one **Archive Question** concerning a named creature, place, item, technique, sect, historical event, law, lineage, Formation, or cultivation phenomenon.

Before your next long rest, when the question becomes relevant, declare it.

The AI GM must provide one truthful result available through reasonable scholarship:

- A direct clue.
- A documented precedent.
- A likely investigation avenue.
- A known weakness category.
- A historical relationship.
- A relevant legal or sectarian obligation.
- A reasonable scholarly inference clearly identified as inference.

The Insight does not fabricate lost knowledge, reveal a Secret erased from all records, or provide information that no archive could contain.

---

### Imperial Armory Certification

**Prerequisite:** Imperial, military, sect-armory, or equivalent authorization, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Dexterity, or Intelligence score by 1, to the maximum allowed by your current Realm.

Choose one weapon group, armor category, shield category, vehicle weapon, siege implement, or military cultivation implement for which you possess access.

Gain one of the following:

- Proficiency with the chosen weapon group.
- Proficiency with the chosen armor or shield category.
- Tool proficiency needed to operate the chosen siege or vehicle implement.
- A +2 bonus if already proficient.

This Insight represents formal training and certification rather than Path chassis proficiency.

When using an authorized item, gain Advantage on checks to inspect, maintain, requisition, safely store, or identify sabotage affecting it.

---
## Cross-Sphere Insights

### Might-Sphere Discipline

**Prerequisite:** Narrative access to one approved Might Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Strength, Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Learn one approved Might Sphere and gain its normal free first talent.

When a talent from that Sphere can logically operate through Qi rather than transformed flesh, use:

- Qi as its Cultivation Point resource.
- Your Qi Cultivation key ability.
- Your Qi Cultivation Save DC and Attack Modifier.

This Insight does not grant:

- Body Refining Hit Dice.
- Body Refining attack progression.
- Stamina.
- Body-only external projection.
- A Body Refining Foundation or chassis feature.

A talent whose premise requires actual transformed anatomy may still require a Method, Foundation, item, bloodline, or explicit Qi adaptation.

---

### Hybrid-Sphere Refinement

**Prerequisite:** One Hybrid Sphere, CL4+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose the Power expression of one Hybrid Sphere you know.

You may use that expression through Qi and your Qi Cultivation key ability where the Sphere permits.

Retraining between its Might and Power expressions requires:

- 7 days of training.
- A qualified master, manual, lineage, or equivalent source.
- The normal training check.
- Any campaign approval or access requirement.

The retraining does not erase talents that remain legal in both expressions.

---

### Spirit-Adjacent Scripture

**Prerequisite:** Narrative access to one approved Spirit-adjacent Sphere, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Learn one approved Spirit-adjacent Sphere and gain its normal free first talent.

Use Qi and your Qi Cultivation key ability for legal Power expressions.

This Insight does not grant:

- Resonance.
- Spirit Awakening Domains.
- Spirit Companion chassis rules.
- Authority based on cultivated identity unless the Sphere itself provides it.

Access usually requires a rare manual, specialist sect, relic, license, ritual, spirit agreement, bloodline, or major story event.

---

### Restricted Sphere License

**Prerequisite:** Imperial, sectarian, hereditary, professional, or equivalent authorization; CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one Restricted Sphere to which the license grants access.

Learn the Sphere and its normal free first talent if the authorization includes instruction. If it grants legal use only, this Insight instead grants access to training.

Once per scene, gain Advantage on one check involving the licensed Sphere's:

- Learning.
- Research.
- Identification.
- Stabilization.
- Repair.
- Countering.
- Legal deployment.

The license provides its recorded social and legal benefits but may impose reporting, service, inspection, or geographic restrictions.

---
## Bloodline Insights

### Ancestral Bloodline Awakening

**Prerequisite:** Discovered heritage, absorbed ancestral essence, bloodline event, or equivalent approval

**Ability Increase (Level Selection):** Increase your Constitution or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one narrow inherited gift approved for the lineage.

Default models include:

#### Dragon Gift

Gain Resistance to one lineage damage type. Spend 2 Qi as a Bonus Action to gain Fly Speed 30 feet until the end of your turn.

#### Phoenix Gift

When reduced to 0 Hit Points without being killed outright, spend 4 Qi to remain at 1 Hit Point and emit `2d8` Fire or Radiant damage to hostile creatures within 5 feet, Dexterity save for half. Once per scene.

#### Demon-Blood Gift

Once per turn, one damaging Qi-powered feature deals an additional `1d6` Necrotic, Psychic, or lineage damage.

#### Jade Tortoise Gift

Gain +1 AC and reduce forced movement by 5 feet.

#### Fox Gift

Gain proficiency in one social skill or +2 if already proficient. Reaction, 1 Qi, impose Disadvantage on one attack roll made by a creature you can perceive within 30 feet.

A custom lineage gift should be comparable in scope and include explicit costs, triggers, and Source CL.

The gift's social classification depends on the lineage and culture. It is not automatically Daemonic.

---

### Deepened Ancestral Memory

**Prerequisite:** A bloodline feature, CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain proficiency in one skill, tool, language, script, weapon group, or ritual practice associated with your lineage. If already proficient, gain +2 instead.

Once per scene, after failing a check directly connected to your ancestry, inherited culture, bloodline enemy, ancestral territory, or lineage technique, reroll it.

You must use the new result.

During a Full Cultivation Session, you may ask one question of ancestral memory. The answer is limited to knowledge a genuine ancestor could have possessed and may be symbolic, incomplete, or biased, but it cannot be deliberately false unless the ancestral source itself is deceptive.

---

### Bloodline-Core Fusion

**Prerequisite:** Bloodline Cultivator, Ancestral Bloodline Awakening, or another active bloodline engine; CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When you activate a bloodline Surge, transformation, release, or comparable feature, choose two different Fusion benefits:

- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Move 10 feet without provoking Opportunity Attacks.
- Regain 2 Qi.
- Gain Advantage on your next saving throw before the end of your next turn.
- End ordinary Frightened or Charmed when its Source CL is lower than yours.
- Move your Domain Armament 20 feet.
- Your next lineage-tagged attack or technique deals additional damage equal to your Proficiency Bonus.

A given bloodline activation triggers Bloodline-Core Fusion once.

---

### Ancestral Treasure Bond

**Prerequisite:** A bloodline feature and one genuine ancestral weapon, shield, artifact, implement, or relic; CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

The ancestral treasure may serve as your Domain Armament even when its form would not ordinarily qualify, provided it is a noncreature item and consents when sentient.

While bound:

- You always know its direction on the same plane.
- It gains Advantage on saving throws against suppression, theft, and severing the bond.
- You may use your Qi Cultivation key ability for Cultivation Checks involving its lineage properties.
- Once per scene, when one of its lineage properties would fail because your CL is too low by 2 or less, treat your CL as 2 higher for that property only.

This does not waive attunement, bloodline identity, permanent prices, or item charges.
## Forbidden, Condemned, and Predatory Insights

The following Insights are frequently restricted, condemned, criminalized, or called demonic. Those labels do not automatically add the **Daemonic** tag. Apply a mechanical tag only when the Insight or its source explicitly says so.

### Soul-Devouring Scripture

**Prerequisite:** Qi Devourer, access to a forbidden or predatory manual, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When Qi Devourer consumes essence from a sentient creature, you may take a deeper soul fragment.

If you do:

- Regain 4 additional Qi.
- Learn one dominant emotion, unresolved oath, major fear, or active spiritual allegiance carried by the victim.
- The victim suffers Soul Depletion.

#### Soul Depletion

Until repaired by an appropriate spiritual treatment, the victim:

- Has Disadvantage on its first saving throw in each scene against possession, dream intrusion, emotional manipulation, or soul damage.
- Cannot yield another soul fragment to you.
- Displays a visible spiritual wound to Qi Sensing.

Taking a fragment may have karmic, legal, religious, or sectarian consequences.

This Insight does not automatically trap the entire soul or prevent resurrection unless a stronger Source Rule says so.

---

### Cremation-Furnace Core

**Prerequisite:** Cinder Heart Cultivator or Fire/Ash cultivation access, CL8+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

When a meaningful creature is reduced to 0 Hit Points within 30 feet after taking Fire, Radiant, or Ash-tagged damage from you during the current turn, gain 1 Ash Charge.

- Maximum Ash Charges: Your Proficiency Bonus.
- A creature yields one Ash Charge until its body, spirit, or cultivation is genuinely restored.
- Ash Charges disappear after a Full Cultivation Session unless incorporated into another printed procedure.

Spend 1 Ash Charge when activating a Qi-powered feature to choose one:

- Add `1d8` Fire or Necrotic damage to one roll.
- Reduce its Qi cost by 1, minimum 1.
- Gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.
- Move 10 feet without provoking Opportunity Attacks.
- Prevent one damaged target from regaining Hit Points until the start of your next turn.

Using this Insight leaves visible cremation residue on your Golden Core and victims.

---

### Heart-Stealing Resonance

**Prerequisite:** Emotion Cultivator or access to Mind, Emotion, or Spirit manipulation; CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature fails a saving throw against one of your emotional cultivation effects, spend 2 additional Qi to choose one:

- Learn its current dominant emotion.
- Learn one emotional vulnerability presently influencing its decisions.
- Give it Disadvantage on its next saving throw against Charmed or Frightened before the end of your next turn.
- Prevent it from receiving emotional support, morale bonuses, or another creature's reassurance until the start of your next turn.
- Extract one surface emotion into a visible Heart Fragment lasting until the scene ends.

A Heart Fragment may be used as a focus, evidence, ritual component, or emotional key under an authorized Source Rule.

Permanent emotional theft, transplantation, removal, or rewriting requires an effect that explicitly authorizes it, such as the Heart-Stealing forbidden Subpath, a helpless or properly bound target, a ritual, sufficient authority, and printed recovery consequences.

This Insight is not automatically Daemonic.

---

### Nightmare Feaster

**Prerequisite:** Dream Qi Cultivator or Dreams Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

When a creature fails a saving throw against one of your Dream-, Nightmare-, Sleep-, Fear-, or dream-illusion effects, gain Temporary Hit Points equal to your Proficiency Bonus once per round.

#### Predatory Dream Harvest

**Ritual Time:** 10 minutes  
**Range:** Touch or shared dream connection  
**Target:** One sleeping, unconscious, restrained, willing, or otherwise accessible genuine dreamer

Drain the target's active dream substance.

The target makes a Wisdom or Charisma saving throw, its choice, unless willing.

- **Failed Save:** Regain Qi equal to your Proficiency Bonus. The target suffers one Dream Trauma.
- **Successful Save:** Regain 1 Qi. The target wakes and knows an intrusion occurred.

A Dream Trauma imposes one of the following, chosen when harvested:

- `2d8` Psychic damage that cannot be healed until the target completes a long rest.
- Maximum Hit Points reduced by your Proficiency Bonus until cultivated treatment.
- One level of Exhaustion.
- Loss of one specific recent memory until dream therapy or restoration.
- Disadvantage on the next saving throw against Dreams or Fear.

A creature may suffer a number of Dream Traumas equal to its Proficiency Bonus.

When its Dream Traumas reach that maximum:

- It becomes comatose and cannot wake naturally until at least one Trauma is removed.
- A further failed harvest deals `4d8` Psychic damage and reduces its Hit Point maximum by the same amount.
- If this maximum-Hit-Point reduction reaches its normal Hit Point maximum, the creature dies and its dreaming consciousness is consumed or scattered.

Appropriate dream therapy, spiritual medicine, memory restoration, Samsara authority, or a Source Rule that repairs Dream Trauma removes the recorded injuries.

A self-created dream construct, illusory sleeper, or closed refund loop provides no Qi unless it possesses independent genuine consciousness.

The practice may be called demonic by the Empire or other institutions, but it gains the Daemonic tag only from a separate rule.

---

### Poisoned-Meridian Scripture

**Prerequisite:** Poison Cultivator or Poison Sphere, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Once per turn when a creature fails a saving throw against your Poison Touch, cultivated poison, or Poison-tagged Qi technique, spend 2 additional Qi to infect one meridian function until the start of your next turn.

Choose one:

- Reduce Speed by an additional 10 feet.
- Prevent Hit Point recovery and Temporary Hit Points.
- Give Disadvantage on the target's next Constitution saving throw.
- Increase the Qi cost of its next feature by 1.
- Prevent Qi recovery.
- Reveal its direction to you while within 1 mile and on the same plane.

Against a target whose Source CL is 6 or more lower than yours, you may spend 4 additional Qi to extend the chosen infection until the scene ends. The target repeats the original poison saving throw at the end of each turn, ending it on a success unless the underlying poison states otherwise.

A higher-authority Venomous Poison feature may convert the temporary infection into an indefinite cultivation poison.

---
## Secret-Law Insights

Secret-Law Insights require actual contact with the relevant authority. They do not make Secret access ordinary and may impose permanent prices, erasure, karmic debt, identity damage, reincarnation consequences, or conceptual wounds.

### Void-Touched Core

**Prerequisite:** Void Sphere, Void-Touched Cultivator, survival of genuine Void exposure, or equivalent Secret access

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one permanent visible or metaphysical Void Sign, such as:

- Missing reflection.
- Silent footsteps.
- A shadow with a gap.
- Records that fade at the edges.
- A cold absence in Qi Sensing.

Gain Advantage on saving throws and Cultivation Checks against:

- Void damage.
- Banishment.
- Unwilling teleportation.
- Planar displacement.
- Spatial erasure.
- Effects removing you from reality.

Once per scene, when an effect would teleport, banish, or remove you from your current plane, remain in place instead if its Source CL is lower than yours.

Against an equal or higher Source CL, make a Cultivation Check against its save DC. On success, remain.

---

### Hollow-Meridian Circulation

**Prerequisite:** Void Sphere or Void-Touched Cultivator, CL12+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Once during each of your turns, after activating a Void-tagged feature, choose one:

- Reduce its Qi cost by 1, minimum 1.
- Move 10 feet through a visible gap without provoking Opportunity Attacks.
- Gain Advantage on your next Cultivation Check before the end of your next turn.
- Suppress ordinary sound in your space until the start of your next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Ignore one ordinary physical barrier no more than 1 foot thick when measuring the feature's line of effect.

The final option cannot bypass lead, artifacts, sealed Formations, spatial locks, or higher-authority barriers.

---

### Missing-Step Technique

**Prerequisite:** Void Sphere, Void-Touched Cultivator, or Missing-Step inheritance; CL12+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, or Charisma score by 1, to the maximum allowed by your current Realm.

**Reaction**  
**Trigger:** You are targeted by an attack roll or a line, cone, or area whose boundary you can perceive.  
**Cost:** 3 Qi

Teleport up to 15 feet to a visible legal space.

- An attack roll fails if you are no longer a legal target.
- A line, cone, or area affects you only if the destination remains inside it.
- The attacker cannot choose another target for the same attack.

Missing-Step Technique is blocked by spatial locks, sealed Formations, planar boundaries, and effects explicitly preventing Void movement.

---

### Erased Name

**Prerequisite:** Void Sphere or Void-Touched Cultivator, CL16+, Secret approval

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

Choose one permanent cost when gaining this Insight:

- Unfamiliar people struggle to remember your face.
- Mundane records of you fade unless regularly renewed.
- Your reflection is absent.
- Resurrection requires a personal anchor bearing your true identity.
- Wards and ancestral sites treat you as an unknown presence.
- One former title or identity permanently disappears from ordinary memory.

Gain Advantage against:

- Divination.
- Tracking cultivation.
- Dream intrusion.
- Memory alteration.
- Possession.
- Name-based curses.
- Oath effects that do not possess your true identity anchor.

An effect whose Source CL is lower than yours cannot learn your exact location through remote divination unless it already possesses a personal anchor.

---

### Samsara Memory

**Prerequisite:** Samsara-Wheel Cultivator, reincarnation inheritance, or genuine former-life awakening; CL8+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

At the end of a Full Cultivation Session, choose one Former-Life Memory:

- One skill proficiency.
- One tool proficiency.
- One language or script.
- One weapon group proficiency.
- One narrow historical field.
- One approved Sphere talent from a Sphere you already know.

The Memory remains until you replace it during another Full Cultivation Session.

A talent selected this way:

- Must meet its prerequisites.
- Uses your Qi and Qi Cultivation statistics when legal.
- Cannot be Secret, inherited, permanent, or identity-exclusive.

Once per scene, reroll one failed roll directly using the active Former-Life Memory.

---

### Wheel Refuses the End

**Prerequisite:** Samsara-Wheel Cultivator or reincarnation Secret authority, CL16+

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you die and your soul remains capable of entering Samsara, create a Samsara Anchor at your place of death.

For the next 1 minute:

- Your soul cannot be involuntarily consumed or redirected by an effect whose Source CL is lower than yours.
- An ally may touch the Anchor and spend an Action to preserve it.
- A resurrection, soul-return, or Samsara feature may originate from the Anchor.

When the Anchor is created, you may return through it with 1 Hit Point at the start of your next turn.

After doing so, mark this Insight **Wheel Exhausted**. It cannot create another returning Anchor until one of the following occurs:

- You complete a successful Realm breakthrough.
- You complete a 7-day reincarnation rite using the rare materials required by your Samsara source.
- You permanently reduce your maximum Qi by your Proficiency Bonus.

A permanent maximum-Qi reduction paid this way can be repaired only by a feature explicitly capable of restoring permanent cultivation sacrifice.

This does not overcome conceptual erasure, a severed Samsara connection, destruction of the soul, or an effect of superior authority without a successful Source CL contest.

---

### Karmic Ledger Within the Core

**Prerequisite:** Karma-Thread Cultivator, Oath-Ledger Cultivator with Karma access, or genuine Karma Secret authority; CL12+

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

You may hold Karmic Marks equal to your Proficiency Bonus.

Gain one Mark when a creature you can perceive during a meaningful scene:

- Directly harms you or an ally.
- Saves your life.
- Breaks an oath to you.
- Pays a genuine debt.
- Accepts a major sacrifice from you.

The event must carry actual consequence; staged exchanges and closed loops do not qualify.

Spend one Mark when interacting with that creature to choose one:

- Add `2d8` damage or healing to one result.
- Move it or an ally 10 feet through causal redirection.
- Add or subtract `1d4` from one saving throw.
- Reveal the direction of the creature on the same plane.
- Force an immediate Cultivation Check against one concealed oath, debt, or Karmic bond.

Marks persist until settled, purified, transferred, or consumed.

---

### Conceptual Edge

**Prerequisite:** Heaven-Splitting Conceptual Severance or equivalent Secret authority, CL16+

**Ability Increase (Level Selection):** Increase your Dexterity, Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When you use a feature that severs, cuts, suppresses, or separates a relationship, spend 3 additional Qi to name one eligible conceptual connection:

- Weapon from owner.
- Technique from source.
- Soul from body.
- Name from authority.
- Formation from Anchor.
- Qi from meridian.
- Memory from identity.
- Oath from beneficiary.
- Regeneration from injury.

Against a target whose Source CL is lower than yours, the connection is suppressed until the scene ends unless the feature already grants a longer result.

Against an equal or higher Source CL, make a Cultivation Check against its save DC. On success, suppress it until the end of your next turn.

This Insight cannot create a permanent severance unless the underlying Secret feature already authorizes permanence and its price is paid.

---

### Secret Authority Contention

**Prerequisite:** One Secret Law, CL16+

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

When one of your Secret effects directly contests another Secret, artifact, Immortal, or conceptual authority, add your Proficiency Bonus to the first Cultivation Check you make in that contest.

If the check still fails, choose one concession instead of total failure when logically possible:

- Reduce the opposing effect's duration by one round.
- Preserve one Anchor from destruction at 1 Hit Point.
- Prevent one permanent consequence from becoming irreversible until the scene ends.
- Learn the opposing authority's exact Source CL and one recovery condition.
- Move 10 feet without provoking Opportunity Attacks before the consequence resolves.

A concession cannot negate a price already willingly paid or recreate something conceptually erased.

---
## Tribulation Insights

A Tribulation Insight requires surviving the named Tribulation or a genuinely equivalent heavenly calamity. These are scars and adaptations, not ordinary training options.

### Lightning-Scarred Meridians

**Prerequisite:** Survive a Lightning or Heaven-Thunder Tribulation

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Lightning damage.

Once per round, after a meaningful hostile source deals Lightning damage to you, regain 1 Qi.

If another feature grants Lightning Resistance, reduce the first Lightning damage packet each round by your Proficiency Bonus instead.

Your meridians remain visibly scarred to Qi Sensing and may react to approaching tribulation weather.

---

### Furnace-Core Survivor

**Prerequisite:** Survive a Fire, Magma, Ash, or Meridian-Flame Tribulation

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Fire damage.

Once per round when you deal Fire, Magma, or Ash-tagged damage after having taken damage during the current round, gain Temporary Hit Points equal to `2 × your Proficiency Bonus`.

If another feature grants Fire Resistance, reduce the first Fire damage packet each round by your Proficiency Bonus instead.

---

### Frozen Golden Core

**Prerequisite:** Survive a Cold, Yin, Ice, or Stillness Tribulation

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Resistance to Cold damage.

Once per turn, when a creature fails a saving throw against your Cold-, Yin-, Ice-, or Stillness-tagged feature, reduce its Speed by an additional 10 feet until the start of your next turn.

If the feature already reduces Speed to 0, the creature also cannot take Reactions until the start of its next turn.

---

### Storm-Eye Meditation

**Prerequisite:** Survive a Weather, Air, Wind, Storm, or Lightning Tribulation

**Ability Increase (Level Selection):** Increase your Intelligence, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Being knocked Prone.
- Wind.
- Forced movement.
- Weather-based disorientation.

Once per turn, after spending Qi on a movement feature, move an additional 10 feet without provoking Opportunity Attacks.

This movement may cross open air but must end in a legal supported space unless another feature supports you.

---

### Mountain-Core Stability

**Prerequisite:** Survive an Earth, Gravity, Mountain, pressure, or crushing Tribulation

**Ability Increase (Level Selection):** Increase your Strength, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Forced movement.
- Being knocked Prone.
- Unwilling teleportation.
- Crushing pressure.

Reduce all forced movement affecting you by 10 feet.

Once per round, when an effect whose Source CL is lower than yours would move you, reduce that movement to 0 instead.

---

### Heart-Demon Vanquisher

**Prerequisite:** Survive a Heart-Demon, mental, Dream, Illusion, emotional, or identity Tribulation

**Ability Increase (Level Selection):** Increase your Wisdom or Charisma score by 1, to the maximum allowed by your current Realm.

Gain Advantage on saving throws against:

- Charmed.
- Frightened.
- Dreams.
- Illusions.
- Emotional manipulation.
- Forced identity alteration.

**Reaction**  
**Trigger:** You fail one of those saving throws.  
**Cost:** 2 Qi

Reroll it and use the new result.

The same saving throw cannot be rerolled more than once.

---

### Formation-Collapse Survivor

**Prerequisite:** Survive a Formation collapse, spatial collapse, teleportation disaster, or prison Formation Tribulation

**Ability Increase (Level Selection):** Increase your Constitution, Intelligence, or Wisdom score by 1, to the maximum allowed by your current Realm.

Gain Advantage on checks and saving throws to:

- Escape Formations.
- Resist unwilling teleportation.
- Locate spatial faults.
- Survive collapsing pocket spaces.

When trapped, sealed, or spatially isolated, you immediately learn the direction of the nearest vulnerable Anchor, boundary fault, exit route, or unstable spatial seam within 300 feet, if one exists.

Once per scene, spend 3 Qi to move up to 15 feet through one Formation boundary or spatial seam whose Source CL is lower than yours.

Against an equal or higher Source CL, make a Cultivation Check against its save DC.

---

### Sword-Tribulation Survivor

**Prerequisite:** Survive a Sword, Saber, Blade, Weapon, or Killing-Intent Tribulation

**Ability Increase (Level Selection):** Increase your Dexterity, Constitution, or Wisdom score by 1, to the maximum allowed by your current Realm.

While wielding or controlling a named weapon:

- Gain Advantage on saving throws against Frightened and weapon-disarming effects.
- A hostile effect whose Source CL is lower than yours cannot permanently sever your bond to that weapon.
- Once per scene, activate one known weapon field, weapon stance, or weapon Domain-style feature without paying its base Qi cost. Optional surcharges and non-Qi costs remain.

This does not grant a weapon Sphere or proficiency.

---

### Twice-Tribulated

**Prerequisite:** Survive two different Realm Tribulations

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Increase maximum Hit Points by 10.

Gain +1 on Cultivation Checks made during breakthroughs, Tribulations, and attempts to stabilize Realm damage.

When a Tribulation begins, gain Temporary Hit Points equal to `2 × your Proficiency Bonus` and regain Qi equal to your Proficiency Bonus.

These benefits occur once per Tribulation event, not once per phase.

---

### Heaven's Scar

**Prerequisite:** Survive an extraordinary, unique, Secret, Immortal, or Heaven-recognized Tribulation; approval

**Ability Increase (Level Selection):** Increase your Constitution, Wisdom, or Charisma score by 1, to the maximum allowed by your current Realm.

Gain a permanent Scar recording the Tribulation's authority.

Choose or design one narrow benefit tied directly to the survived event. Default structures include:

- Resistance to one damage type and a once-per-round rider.
- Advantage against one named category of suppression.
- A 10-foot movement technique usable after spending Qi.
- A once-per-scene refusal of one forced transformation, banishment, possession, or death effect of lower Source CL.
- The ability to perceive one specific heavenly, spatial, karmic, or elemental phenomenon.
- One additional use or stronger result for a matching Tribulation Subpath feature.

The Scar should be stronger than an ordinary background benefit but narrower than a full Subpath feature.

Record:

- Its visible sign.
- Its mechanical tag.
- Its Source authority.
- Its trigger and limits.
- Any ongoing price or heavenly attention it attracts.

# Part III — Player Glossary

### Core Character Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Path** | One of Tianxia's primary cultivation chassis, such as Qi Cultivation. | Class, casting class. |
| **Subpath** | The CL3 progression granting features at CL3, CL6, CL10, CL14, and CL18. | Subclass, archetype when rules meaning is intended. |
| **Cultivation Level (CL)** | The level used for cultivation progression and Realm. | Character level, class level, Source Level. |
| **Effective CL** | CL currently available after Realm Suppression or another explicit modifier. | Temporary level without definition. |
| **Realm** | Mortal, Foundation, Core Formation, Nascent Soul, or Immortal tier determined by CL. | Spell tier, caster tier. |
| **Proficiency Bonus (PB)** | The proficiency bonus corresponding to effective CL when Realm Suppression applies. | Unqualified level bonus. |
| **Qi Cultivation key ability** | Intelligence or Charisma chosen at CL1. | Casting ability unless a legacy spell interaction specifically requires it. |
| **Cultivation Save DC** | `8 + PB + key ability modifier`. | Spell save DC for Qi features. |
| **Cultivation Attack Modifier** | `PB + key ability modifier`. | Spell attack modifier for Qi features. |
| **Cultivation Check** | The explicit cultivation-authority check defined by a Source Rule. | Ordinary ability check unless the rule says it is one. |

### Resource and Time Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivation Points (CP)** | Generic name for a Path resource. | Mana, ki points, spell points. |
| **Qi** | Qi Cultivation's CP resource. | Mana, spell slots. |
| **Scene** | One continuous meaningful situation under the universal Tianxia definition. | Encounter when Scene is the intended rules unit. |
| **Activation** | One declared use including all attacks, projectiles, targets, and riders it creates. | Cast, spell instance, attack instance when the full use is intended. |
| **Once per activation** | Applies once across the complete use. | Once per projectile unless expressly intended. |
| **Full Cultivation Session** | The printed extended cultivation-recovery procedure. | Automatically equating it with any long rest. |

### Rule-Authority Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Source Rule** | The feature, talent, art, item, Method, Foundation, Formation, Insight, or law authorizing an effect. | Source ability, spell source, flavor authority. |
| **Source CL** | Cultivation authority of the effect or countermeasure. | Source Level, caster level. |
| **Cultivation technique** | A supernatural procedure authorized by a Source Rule. It is not automatically a spell or weapon attack. | Spell as a generic synonym. |
| **Cultivation authority** | Qualitative and quantitative authority printed by the Source Rule, including tags and Source CL. | Balance tier or spell level as the sole measure. |
| **Mechanical tag** | A printed rules tag such as Daemonic, Void, Karma, or Secret. | Inferring a tag from reputation or visual style. |
| **Realm disparity** | Asymmetric interaction produced by Source CL and Realm difference. | Automatic fairness or equal counter cadence. |

### Advancement and Character-Building Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Ability Score Improvement** | The normal +2 or two +1 level option. | ASI in player-facing final prose unless already defined. |
| **Cultivation Insight** | Major Path refinement selected at the listed levels or awarded by another source. | Feat as a generic replacement. |
| **Origin Insight** | Separate character-creation origin feature. | Treating it as a Cultivation Insight or feat. |
| **Background Sphere / Background Talent** | Free Background grants at CL1 under current character-creation rules. | Counting them against level talent or trained choices. |
| **Sphere** | Canonical sphere of practice. Learning a new Sphere grants its normal free first talent. | Skill tree, spell school. |
| **Talent** | Learned option inside a Sphere. | Spell known, invocation, maneuver unless quoting a source. |
| **Attainment Points (AP)** | Advancement currency for cultivation progress and breakthroughs. | CXP in current rules. |

### Cultivation Structure Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Foundation** | Embodied cultivation foundation with its printed passive and active qualities. | Subclass foundation, feat package. |
| **Method** | Cultivation method controlling CP maximum or other printed cultivation procedures. | Mana method, class feature. |
| **Recorded Art** | Fixed learned expression reproduced from a manual or lineage; it does not grant its source Spheres. | Martial Manual as the universal rules name; spell. |
| **Forged Technique** | Constructed multi-packet cultivation technique using the Forging rules. | Homebrew spell, combo spell. |
| **Immortal Art** | High-order named cultivation art using its own printed authority. | Ultimate spell. |
| **Cultivation Insight** | Personal breakthrough or refinement with prerequisites and printed ability options. | Feat. |

### Qi-Specific Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivated Response** | Paid post-failure Defensive Discipline; never saving throw proficiency. | Save proficiency. |
| **Qi Technique Potency** | Once-per-activation addition of the Qi key modifier to one damage roll. | Elemental Strike. |
| **Meridian Regulation** | CL2 treatment and suppression procedure. | Generic cure-all. |
| **Qi Armor** | Ranged-attack Reaction defense. | General AC spell or melee defense. |
| **Domain Armament** | Projected form or legally bound real item controlled by the Qi Path. | Flying Sword as the generic Path feature. |
| **Golden Core Form** | Stable, Circulating, or Reservoir Core choice at CL10. | Core Formation feature. Core Formation remains the Realm name. |
| **Nascent Soul** | CL15 autonomous Qi structure. It is not Spirit Awakening authority. | Spirit companion or second concentration by default. |
| **Nine Heavens Gaze** | CL17 active cultivation perception and analysis. | Generic truesight feature when referring to this Path feature. |

# Part IV — Subpath Selection Index

The full rules for each entry appear in the *Qi Subpath Compendium R19*. Classification describes access, lineage, and authority; it is not a conventional power tier and does not by itself declare a practice moral or immoral.

| Access | Subpath | Role family | Primary loop |
|---|---|---|---|
| Open School | **Five Elements Cultivator** | Elemental and weather | Elemental cycle and adaptable technique conversion |
| Open School | **Yin–Yang Cultivator** | Elemental and weather | Polarity balance, reversal, and restorative control |
| Open School | **Kiai Master** | Sound, voice, and resonance | Voice-based martial control and suppression |
| Open School | **Shugenja** | Elemental and weather | Patron-element prayer, terrain attunement, and avatar transformation |
| Open School | **Sound Cultivator** | Sound, voice, and resonance | Instrumental offense, healing, fear, and resonance |
| Open School | **Spirit Bow Cultivator** | Martial armament | Mobile projected archery and decisive fate-marked shots |
| Open School | **Cloud Walker** | Mobility and travel | Personal and group aerial mobility |
| Open School | **Iron Cloth Cultivator** | Defense and control | Flexible cloth weapon, binding, and zone control |
| Open School | **Mantra Cultivator** | Sound, voice, and resonance | Sustained spoken buffs, silence, and primal syllables |
| Open School | **Dust Cultivator** | Attrition and environmental harm | Obscurement, erosion, and sandstorm control |
| Open School | **Storm Soul Cultivator** | Elemental and weather | Mobile wind-lightning skirmishing |
| Open School | **Cinder Heart Cultivator** | Elemental and weather | Fire support, forging heat, rebirth, and ash offense |
| Open School | **Mountain Core Cultivator** | Defense and control | Personal durability, anchoring, and immovability |
| Open School | **Lantern Keeper** | Recovery, sanctuary, and support | Guidance, soul escort, rescue passage, and death prevention |
| Open School | **Tea-Sage Cultivator** | Recovery, diagnosis, and ceremony | Precision infusions, diagnosis, corrective reactions, purification, and guest ceremony |
| Open School | **Banner Cultivator** | Command and battlefield structure | Mobile command asset, rallying, and formation support |
| Open School | **Harvest Cultivator** | Recovery, sanctuary, and support | Seed assets, growth, restoration, and agriculture |
| Open School | **Kiln Cultivator** | Craft, inscription, and created assets | Prepared ceramic assets, containment, and fortification |
| Open School | **Riverway Cultivator** | Mobility and travel | Rescue transport, route finding, and river-field mobility |
| Open School | **Hearthfire Cultivator** | Recovery, sanctuary, and support | Sanctuary, morale, recovery, and portable home-field |
| Open School | **Bell-Tower Cultivator** | Sound, voice, and resonance | Detection, alarm, purification, and resonant formation |
| Open School | **Mason Cultivator** | Craft, inscription, and created assets | Rapid structures, repairs, bridges, and bastions |
| Open School | **Kite Cultivator** | Mobility and travel | Scouting, tethers, signals, and aerial transport |
| Open School | **Culinary Cultivator** | Recovery, logistics, and provisioning | Body-tempering meals, physical rations, camp kitchens, preservation, and mass provisioning |
| Open School | **Raincaller Cultivator** | Elemental and weather | Large-area weather, rain shaping, and regional rites |
| Open School | **Spear-Meridian Cultivator** | Martial armament | Spear delivery, meridian gates, linear pressure, and cultivation nailing |
| Open School | **Orbiting Shield Warden** | Defense and control | Projected or real shield constellation, interception, and shield prison |
| Open School | **Saber-Wind Cultivator** | Martial armament | Mobile sweeping saber, Gale Momentum, and cutting-wind fields |
| Open School | **Mountain-Cleaving Greatblade Cultivator** | Martial armament | Committed cleaves, terrain division, and defense severance |
| Open School | **Heaven-Anvil Maul Cultivator** | Martial armament | Impact, fractures, armor breaking, craters, and Core misalignment |
| Open School | **Iron-Rain Cavalry Saber Cultivator** | Martial armament | Armored advance, charge momentum, and line breaking |
| Open School | **Twin-Tide Paired Saber Cultivator** | Martial armament | Alternating dual-saber currents, parries, and paid multi-hit delivery |
| Restricted Scripture | **Ten-Thousand Sword Array Cultivator** | Weapon arrays and remote sword command | Cultivate a sword seed, project intent, command flying swords, and construct increasingly large sword arrays |
| Restricted Scripture | **Poison Cultivator** | Attrition and environmental harm | Direct toxin delivery, clouds, essence rot, and decay |
| Restricted Scripture | **Artifact Cultivator** | Craft, inscription, and created assets | Artifact capacity, charge restoration, storage, and item orchestration |
| Restricted Scripture | **Onmyoji** | Summoned and commanded assets | Shikigami, talismans, kami, and spirit wards |
| Restricted Scripture | **Ninpō Adept** | Information, deception, and prediction | Stealth movement, smoke, ambush, and clone-array deception |
| Restricted Scripture | **Nine-Arts Transcendent Cultivator** | Multi-discipline synthesis | Rotate among nine prepared arts, sustain split-meridian expressions, then fuse principles into a temporary Tier 3 master expression |
| Restricted Scripture | **Sigil Scribe** | Craft, inscription, and created assets | Prepared triggers, stored techniques, and reusable inscription arrays |
| Restricted Scripture | **Alchemical Cultivator** | Craft, inscription, and created assets | Pills, quick brewing, explosives, healing, and elixirs |
| Restricted Scripture | **Cultivator of Seals** | Direct binding and suppression | Name a prohibited function, apply direct seals, reinforce them through pillars, and suppress movement, techniques, meridians, or cultivation systems |
| Restricted Scripture | **Paper Cultivator** | Summoned and commanded assets | Folded familiars, paper weapons, dragons, clones, and paper fields |
| Restricted Scripture | **Mirror Cultivator** | Information, deception, and prediction | Reflection, duplication of effects, and mirrored spaces |
| Restricted Scripture | **Calligraphy Cultivator** | Craft, inscription, and created assets | Executable written characters, scroll storage, binding, and law-script |
| Restricted Scripture | **Emotion Cultivator** | Mind, emotion, and dream | Emotional sensing, contagion, healing, and heart-weather |
| Restricted Scripture | **Divination Cultivator** | Information, deception, and prediction | Stored foresight, prediction, inevitability, and fate rewriting |
| Restricted Scripture | **Painting Cultivator** | Summoned and commanded assets | Painted assets, landscape passage, prisons, and masterpiece scenes |
| Restricted Scripture | **Puzzle Cultivator** | Encoded constraints and solvable locks | Encode constraints, expose clues through interaction, punish incorrect methods, and allow prepared or emergent solutions to dismantle the lock |
| Restricted Scripture | **Dream Qi Cultivator** | Restoration, lucid shaping, and consensual shared dreams | Enter and refine dreams, restore sleepers, shape lucid dreamscapes, and create cooperative shared-dream concordances |
| Restricted Scripture | **Mercurial Cultivator** | Transformative bodies | Liquid-metal adaptation, mobility, and mutable defense |
| Restricted Scripture | **Abyssal Depths Cultivator** | Transformative bodies | Deep-water pressure, tidal control, and leviathan transformation |
| Restricted Scripture | **Dragon-Vein Geomancer** | Mobility and travel | Ley-line reading, networks, regional travel, and territorial authority |
| Restricted Scripture | **Go-Stone Cultivator** | Command and battlefield structure | Board-state positioning, capture, encirclement, and battlefield strategy |
| Restricted Scripture | **Tribulation Vessel** | Stored, stolen, and converted power | Store survived calamities and release typed tribulation power |
| Restricted Scripture | **Oath-Ledger Cultivator** | Witnessed obligations and covenant enforcement | Record accepted or lawfully imposed promises, witness fulfillment or breach, and invoke the exact clauses of the obligation |
| Restricted Scripture | **Incense Cultivator** | Craft, inscription, and created assets | Prepared fragrances, layered auras, wards, dreams, and pavilion control |
| Restricted Scripture | **Meridian Physician** | Recovery, sanctuary, and support | Diagnosis, extraction, meridian surgery, resurrection, and reconstruction |
| Restricted Scripture | **Formation-Breaking Halberd Cultivator** | Command and battlefield structure | Polearm modes, formation dismantling, and command decapitation |
| Restricted Scripture | **Star-Piercing Greatbow Cultivator** | Martial armament | Braced siege archery, anti-flight, range, and fortress penetration |
| Restricted Scripture | **Blood-Moon Execution Saber Cultivator** | Martial armament | Mark buildup, healing denial, execution thresholds, and severance |
| Restricted Scripture | **Hidden-Thunder Draw Saber Cultivator** | Martial armament | Stored draw pressure, counters, projectile cuts, and one-cut dueling |
| Rare Inheritance | **Bloodline Cultivator** | Inherited authority | Ancestral awakening, inherited arts, memory, and ancestor manifestation |
| Rare Variant | **Heaven-Thunder Storm Soul** | Inherited authority | Rare tribulation lineage and heavenly lightning authority |
| Rare Variant | **Black-Sea Leviathan Womb** | Inherited authority | Inherited inner sea, devouring maw, and world-scale abyssal body |
| Rare Variant | **Living Quicksilver Immortal Embryo** | Inherited authority | Inherited immortal mercury body, division, assimilation, and continuity |
| Forbidden Variant | **Cremation Cinder Heart** | Elemental and weather | Forbidden cremation furnace, scripture burning, and ash imprisonment |
| Forbidden Variant | **Soul-Bound Artifact Cultivator** | Specialist / mixed | Life-bound treasure body and survival through artifact continuity |
| Forbidden Variant | **Venomous Poison Cultivator** | Attrition and environmental harm | Living venom dantian, plague meridians, and poison incarnation |
| Forbidden Variant | **Heart-Stealing Emotion Cultivator** | Mind, emotion, and dream | Predatory heart theft, anchors, transplants, and emotional rewriting |
| Forbidden Variant | **Nightmare Dream Qi Cultivator** | Predatory dream infection and fear ecology | Harvest Nightmare Essence, spread contagious nightmare seeds, imprison sleepers, cultivate fear ecologies, and steal defining dreams |
| Forbidden Variant | **Calamity-Devouring Tribulation Vessel** | Stored, stolen, and converted power | Active calamity theft, decree consumption, and apocalypse storage |
| Forbidden Variant | **Soul-Collateral Contract Cultivator** | Explicit contracts, pledged collateral, and foreclosure | Negotiate terms, pledge bodily or spiritual collateral, accrue enforceable Claims on breach, and foreclose pledged assets |
| Secret Law | **Void-Touched Cultivator** | Secret Laws | Absence, erasure, suppression, and nonexistence |
| Secret Law | **Samsara-Wheel Cultivator** | Secret Laws | Former lives, rollback, reincarnation, and cyclical return |
| Secret Law | **Karma-Thread Cultivator** | Causality, deeds, and inevitable consequence | Read actual deeds as karmic imprints, return consequence without consent, mature cause into fruit, and force unresolved karma to ripen |
| Secret Law | **Heaven-Splitting Conceptual Severance** | Secret Laws | Cut relations, attributes, systems, space, and conceptual continuity |
| Daemonic | **Devil-Heart Second Furnace** | Stored, stolen, and converted power | Corruption-powered supplemental Qi engine |
| Daemonic | **Heaven-Devouring Black Cauldron** | Stored, stolen, and converted power | Consume hostile Qi effects and refine stolen damage principles |
| Daemonic | **Demon-Prison Seal Cultivator** | Sealing and imprisonment | Open demon chains and project the internal prison outward |
| Daemonic | **Calamity Banner Cultivator** | Summoned and commanded assets | Fear-fed banner command and daemonic battlefield court |

# Shared-Procedure Reference

The following procedures are intentionally centralized in the *Qi GM Authority Appendix R19* so that the player chapter does not repeat long adjudication text:

- Source Rules, Source CL, and Realm disparity
- Cultivation Assets and Anchors
- Qi fields and Formations
- Concentration, duration, and effect ending
- Suppressed features, suppressed systems, and complete cultivation suppression
- Hidden Injuries, rupture, destruction, erasure, and reconstruction
- Bound real items and projected items
- Weapon-delivered cultivation techniques and paid multiattack delivery
- Audible and Resonant techniques
- Routes, Gates, passengers, and legal destinations
- Qualifying hostility and anti-recursion
- Parent lineage and Variant conversion

A player should know the procedure governing any feature they use. The GM appendix is an authority reference, not permission to conceal player-facing consequences.
