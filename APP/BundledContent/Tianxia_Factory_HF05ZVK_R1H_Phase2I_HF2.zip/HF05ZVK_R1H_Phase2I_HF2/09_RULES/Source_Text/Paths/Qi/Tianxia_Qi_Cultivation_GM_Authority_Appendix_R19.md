# Tianxia Qi Cultivation — GM Authority Appendix R19

**Publication state:** GM-facing adjudication and authority reference for the canonical R18 Qi rules.  
**Mechanical state:** No intentional mechanical changes from R18.  
**Companion volumes:** *Player Path Chapter R19* and *Subpath Compendium R19*.

## How to Use This Appendix

Use the individual feature's Source Rule first. This appendix supplies common procedures where a Subpath invokes Source CL, Realm disparity, Assets, Anchors, fields, Formations, suppression, lasting cultivation harm, item binding, weapon delivery, routes, high authority, Corruption, or Variant conversion.

The GM should state observable stakes and printed recovery conditions. High cultivation authority can be severe, indefinite, or permanent where the rules say so; it is not reduced merely to imitate ordinary modern-D&D encounter balance.

# Part I — Canonical Terminology

## Tianxia Qi Cultivation — Canonical Terminology Map R18

This map controls terminology for the Qi Cultivation Path, its Insights, its 80-entry Subpath catalog, and PHB insertion. A Source Rule may define a narrower term, but it should not silently redefine a canonical term.

### Core Character Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Path** | One of Tianxia's primary cultivation chassis, such as Qi Cultivation. | Class, casting class. |
| **Subpath** | The CL3 progression granting features at CL3, CL6, CL10, CL14, and CL18. | Subclass, archetype when rules meaning is intended. |
| **Cultivation Level (CL)** | The level used for cultivation progression and Realm. | Character level, class level, Source Level. |
| **Effective CL** | CL currently available after Realm Suppression or another explicit modifier. | Temporary level without definition. |
| **Realm** | Mortal, Foundation, Core Formation, Nascent Soul, or Immortal tier determined by CL. | Spell tier, caster tier. |
| **Proficiency Bonus (PB)** | The proficiency bonus corresponding to effective CL when Realm Suppression applies. | Unqualified level bonus. |
| **Qi Cultivation key ability** | Intelligence or Charisma chosen at CL1. | Casting ability unless a legacy spell interaction specifically requires it. |
| **Cultivation Save DC** | `8 + PB + key ability modifier`. | Spell save DC for Qi features. |
| **Cultivation Attack Modifier** | `PB + key ability modifier`. | Spell attack modifier for Qi features. |
| **Cultivation Check** | The explicit cultivation-authority check defined by a Source Rule. | Ordinary ability check unless the rule says it is one. |

### Resource and Time Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivation Points (CP)** | Generic name for a Path resource. | Mana, ki points, spell points. |
| **Qi** | Qi Cultivation's CP resource. | Mana, spell slots. |
| **Scene** | One continuous meaningful situation under the universal Tianxia definition. | Encounter when Scene is the intended rules unit. |
| **Activation** | One declared use including all attacks, projectiles, targets, and riders it creates. | Cast, spell instance, attack instance when the full use is intended. |
| **Once per activation** | Applies once across the complete use. | Once per projectile unless expressly intended. |
| **Full Cultivation Session** | The printed extended cultivation-recovery procedure. | Automatically equating it with any long rest. |

### Rule-Authority Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Source Rule** | The feature, talent, art, item, Method, Foundation, Formation, Insight, or law authorizing an effect. | Source ability, spell source, flavor authority. |
| **Source CL** | Cultivation authority of the effect or countermeasure. | Source Level, caster level. |
| **Cultivation technique** | A supernatural procedure authorized by a Source Rule. It is not automatically a spell or weapon attack. | Spell as a generic synonym. |
| **Cultivation authority** | Qualitative and quantitative authority printed by the Source Rule, including tags and Source CL. | Balance tier or spell level as the sole measure. |
| **Mechanical tag** | A printed rules tag such as Daemonic, Void, Karma, or Secret. | Inferring a tag from reputation or visual style. |
| **Realm disparity** | Asymmetric interaction produced by Source CL and Realm difference. | Automatic fairness or equal counter cadence. |

### Advancement and Character-Building Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Ability Score Improvement** | The normal +2 or two +1 level option. | ASI in player-facing final prose unless already defined. |
| **Cultivation Insight** | Major Path refinement selected at the listed levels or awarded by another source. | Feat as a generic replacement. |
| **Origin Insight** | Separate character-creation origin feature. | Treating it as a Cultivation Insight or feat. |
| **Background Sphere / Background Talent** | Free Background grants at CL1 under current character-creation rules. | Counting them against level talent or trained choices. |
| **Sphere** | Canonical sphere of practice. Learning a new Sphere grants its normal free first talent. | Skill tree, spell school. |
| **Talent** | Learned option inside a Sphere. | Spell known, invocation, maneuver unless quoting a source. |
| **Attainment Points (AP)** | Advancement currency for cultivation progress and breakthroughs. | CXP in current rules. |

### Cultivation Structure Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Foundation** | Embodied cultivation foundation with its printed passive and active qualities. | Subclass foundation, feat package. |
| **Method** | Cultivation method controlling CP maximum or other printed cultivation procedures. | Mana method, class feature. |
| **Recorded Art** | Fixed learned expression reproduced from a manual or lineage; it does not grant its source Spheres. | Martial Manual as the universal rules name; spell. |
| **Forged Technique** | Constructed multi-packet cultivation technique using the Forging rules. | Homebrew spell, combo spell. |
| **Immortal Art** | High-order named cultivation art using its own printed authority. | Ultimate spell. |
| **Cultivation Insight** | Personal breakthrough or refinement with prerequisites and printed ability options. | Feat. |

### Qi-Specific Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivated Response** | Paid post-failure Defensive Discipline; never saving throw proficiency. | Save proficiency. |
| **Qi Technique Potency** | Once-per-activation addition of the Qi key modifier to one damage roll. | Elemental Strike. |
| **Meridian Regulation** | CL2 treatment and suppression procedure. | Generic cure-all. |
| **Qi Armor** | Ranged-attack Reaction defense. | General AC spell or melee defense. |
| **Domain Armament** | Projected form or legally bound real item controlled by the Qi Path. | Flying Sword as the generic Path feature. |
| **Golden Core Form** | Stable, Circulating, or Reservoir Core choice at CL10. | Core Formation feature. Core Formation remains the Realm name. |
| **Nascent Soul** | CL15 autonomous Qi structure. It is not Spirit Awakening authority. | Spirit companion or second concentration by default. |
| **Nine Heavens Gaze** | CL17 active cultivation perception and analysis. | Generic truesight feature when referring to this Path feature. |

### Battlefield and Persistent-Effect Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivation Asset** | Separately targetable cultivated object, construct, manifestation, servant-profile, implement, vehicle, or battlefield element. | Summon or pet when the Asset rules are intended. |
| **Anchor** | Targetable support sustaining or enabling an effect. | Focus, node, ward stone without defining its rules role. |
| **Qi Field** | Area altering local conditions without necessarily using linked geometry. | Aura or spell area as generic substitutes. |
| **Formation** | Deliberately structured linked cultivation effect, often using Anchors. | Field when geometry and linkage matter. |
| **Projected item** | Supernatural form created by a feature; it is not a second copy of a real item. | Duplicate item. |
| **Bound real item** | Existing item legally linked to a feature and moved or used without duplication. | Manifested copy. |
| **Route / Gate** | Travel path or opening using the Shared Rules definitions. | Teleport as a complete procedure when routes, passengers, and destinations matter. |

### Harm, Suppression, and Recovery Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Suppressed feature** | One named feature made unavailable. | Silenced class feature. |
| **Suppressed system** | A defined cultivation system made unavailable. | Disabled magic without scope. |
| **Complete cultivation suppression** | Full lockout under the printed high-authority procedure. | Stunned, antimagic, or ordinary dispel as substitutes. |
| **Hidden Injury** | Persistent cultivation harm requiring its printed diagnosis and treatment. | Ordinary damage or generic curse. |
| **Reconstruction** | Procedure restoring ruptured, destroyed, severed, or erased cultivation structures. | Healing when healing is insufficient. |
| **Permanent** | Persists until an explicit recovery, reconstruction, reversal, or higher authority succeeds. | Irreversible unless the rule actually says no recovery exists. |
| **Indefinite** | Has no time limit but can end through its printed procedure. | Permanent when the distinction matters. |

### Subpath Classification Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Open School** | Broadly teachable or institutionally available lineage. | Basic subclass. |
| **Restricted Scripture** | Controlled instruction due to expertise, danger, politics, medicine, military use, or institutional custody. | Automatically stronger school. |
| **Rare Inheritance** | Rare structural access or singular transmission. | Legendary subclass as a generic label. |
| **Rare Variant** | Rare parent-lineage conversion governed by replacement rules. | Second Subpath. |
| **Forbidden Variant** | Parent-lineage conversion with a prohibited or condemned price. | Automatically evil or Daemonic. |
| **Secret Law** | Law-level authority requiring explicit access and initiation price. | Merely high-level technique. |
| **Daemonic** | Mechanical tag interacting with Corruption, daemonic energy, purification, or anti-daemonic rules. | Using “demonic” reputation as a tag. |

### Canonical Collision Boundaries

- **Tea-Sage** is precision infusion, diagnosis, purification, correction, and ceremony. **Culinary** is provisions, body reinforcement, preservation, camp logistics, and mass feeding.
- **Cultivator of Seals** imposes direct named bindings. **Puzzle Cultivator** creates clue-bearing encoded constraints with solution procedures.
- **Dream Qi** is restorative and cooperative lucid cultivation. **Nightmare Dream Qi** is contagious, predatory, imprisoning, and harvest-oriented.
- **Oath-Ledger** requires obligation. **Soul-Collateral Contract** requires explicit terms and collateral. **Karma-Thread** follows actual deeds without consent or witness.
- **Void** erases or removes. **Conceptual Severance** cuts a relationship while the separated things can remain.
- **Ten-Thousand Sword Array Cultivator** is a specific flying-sword and array lineage; it is not the generic name for all sword-using Qi cultivators.
- **Nine-Arts Transcendent Cultivator** is a synthesis Scripture, not a generic label for high-level Qi cultivation.

### Deprecated Feature-Name Map

| Deprecated or ambiguous term | Canonical replacement |
|---|---|
| Elemental Strike | Qi Technique Potency, or the exact elemental Source Rule involved. |
| Flying Sword as a Path feature | Domain Armament. Lowercase descriptive flying swords remain valid inside the Ten-Thousand Sword Array lineage. |
| Core Formation feature | Golden Core Form. **Core Formation** remains the Realm name. |
| Old Nascent Soul recovery | Nascent Continuity and the current Nascent Soul feature suite. |
| Sword Cultivator as a Subpath title | Ten-Thousand Sword Array Cultivator. |
| Transcendent Cultivator | Nine-Arts Transcendent Cultivator. |
| Soul-Contract Cultivator | Soul-Collateral Contract Cultivator. |
| Subclass | Subpath. |
| Character level / class level | Cultivation Level (CL), unless ordinary noncultivation level is specifically required. |
| Source Level / caster level | Source CL. |
| Mana / ki / spell slots | Qi or Cultivation Points, as appropriate. |

# Part II — Shared Qi Subpath Rules

## Tianxia Qi Cultivation — Shared Subpath Rules R4

This chapter extracts rules that recur throughout the Qi Cultivation catalog. It is intended to be read after Qi Cultivation Canonical Core R4 and before individual Subpaths.

An individual Path feature, Subpath, Sphere talent, Recorded Art, Forged Technique, Immortal Art, item, Method, Foundation, or Secret Law may override these defaults. When it does, the specific Source Rule controls only the stated exception.

The purpose of this chapter is not to reduce cultivation authority to conventional spell adjudication. It provides one executable grammar for the recurring structures that Qi cultivators create, bind, suppress, transport, destroy, or reconstruct.

---

## 1. Rule Hierarchy and Core Terms

### Rule Hierarchy

Resolve a Qi Subpath interaction in this order:

1. The explicit Source Rule creating or modifying the effect.
2. Qi Cultivation Canonical Core R4.
3. This Shared Qi Subpath Rules chapter.
4. Universal Tianxia cultivation rules.
5. The underlying D&D 5.5e procedure where Tianxia has not replaced it.

Specific text overrides a default only for the exception it states. Similar names, visual resemblance, reputation, or analogy to a conventional spell do not create authority.

### Core Terms

- **Activation:** One declared use of a Source Rule, including every attack, projectile, target, and rider it expressly creates.
- **Cultivation technique:** A supernatural procedure authorized by a Source Rule. It uses only the attack, save, check, weapon, or other procedure printed by that rule.
- **Effective CL:** The CL currently available after Realm Suppression or another explicit modifier.
- **Path resource:** Cultivation Points used by a Path. The Qi Cultivation path resource is **Qi**.
- **Scene:** One continuous meaningful situation under the universal Tianxia Scene definition. Scene resources and durations reset only when that situation actually ends.
- **Mechanical tag:** A printed tag with rules consequences, such as **Daemonic**, **Void**, **Karma**, or **Secret**. Social accusations do not add a mechanical tag.

### No Imported Spell Assumptions

A Qi feature is not automatically a spell. Do not import spell components, counterspelling, antimagic, spell-school interactions, casting restrictions in armor, or spell-slot rules unless a Tianxia Source Rule expressly invokes them.

## 2. Source Rule and Source CL

### Source Rule

A **Source Rule** is the rule that authorizes an effect.

Examples include:

- A Path feature.
- A Subpath feature.
- A Sphere talent.
- A Recorded Art.
- A Forged Technique.
- An Immortal Art.
- A Cultivation Insight.
- A Method.
- A Foundation.
- An item property.
- A Formation.
- A Secret Law.
- An artifact or explicit setting authority.

The Source Rule determines:

- What can be targeted.
- What action is required.
- The cost.
- The Source CL.
- Whether the effect is ordinary, Rare, Forbidden, Daemonic, Secret, artifact, Immortal, conceptual, or otherwise exceptional.
- What happens on success or failure.
- Whether a repeated save, Anchor, repair procedure, or permanent price exists.

Flavor, visual form, reputation, or a similar name does not grant an authority absent from the Source Rule.

### Source CL

**Source CL** measures the cultivation authority of an effect, Asset, Anchor, item property, injury, or countermeasure.

Unless a rule states otherwise:

- A Path, Subpath, Sphere, Recorded Art, Forged Technique, or Insight uses the user’s current effective Cultivation Level.
- A Cultivation Asset or Anchor created by a feature uses the Source CL of the feature that created it.
- A cultivated item uses its printed Source CL. If none is printed, use the attuned user’s effective CL only when the item says it channels the user’s cultivation; otherwise the GM assigns a Source CL based on the item’s grade and creator.
- A Method or Foundation uses the bearer’s effective CL unless the feature has a fixed Source CL.
- Realm Suppression changes the user’s effective CL for features barred or scaled by suppression.
- A permanent injury retains the Source CL of the effect that created it until repaired, overwritten, or transformed by another procedure.

### Default Source CL Bands

When two cultivation effects directly contest and the individual rule does not provide another comparison, use these bands.

#### Opposing Source CL 6 or More Lower

The stronger effect has **decisive lower-Realm authority**.

- Resolve the initial printed save or check if the feature includes one.
- A failed resistance normally produces the full lower-authority result.
- The weaker effect does not gain automatic repeat saves, self-cleanse attempts, or passive immunity unless its Source Rule expressly provides them.
- Ordinary lower-authority dispelling, healing, teleportation, purification, or suppression cannot reverse the result merely by being activated repeatedly.

This does not defeat an explicit absolute protection, artifact clause, Secret Law, Immortal authority, or named weakness.

#### Opposing Source CL 3–5 Lower

The stronger effect has **substantial authority**.

- Resolve the printed initial resistance.
- Repeated resistance occurs at the cadence printed by the stronger feature.
- If no cadence is printed for an ongoing hostile restraint or suppression, the affected creature may attempt one repeat save at the end of every second turn.
- Outside combat, a suitable specialist may attempt one counterprocedure per Cultivation Session.

#### Opposing Source CL within 2

The effects have **contested authority**.

- Resolve all printed saves, checks, Anchors, costs, durations, and recovery procedures.
- If a direct contest requires a check and neither rule supplies a DC, use the opposing user’s Cultivation Save DC.
- If both sides are noncreature effects without a user, use `10 + opposing Source CL ÷ 2`, rounded down, plus the opposing effect’s authority modifier if one is printed.

#### Opposing Source CL 3 or More Higher

The lower effect confronts **superior authority**.

- The higher effect normally blocks, shortens, suppresses, or limits the lower effect.
- A lower effect may still succeed when it has accumulated marks, broken an Anchor, exploited a weakness, paid an additional price, or succeeded on a Cultivation Check after the target’s normal resistance.
- A successful lower-authority effect normally lasts no longer than one round unless its rule expressly states that its setup overcomes the disparity.

#### Explicit Higher Authorities

Artifact, Immortal, Secret, conceptual, heavenly, world-law, or explicit absolute authorities use their printed interactions. A numerical CL advantage does not erase a specifically named superior authority.

### Cultivation Check

A **Cultivation Check** uses the ability and proficiency specified by the Source Rule.

For a Qi Cultivation feature that does not specify another formula, use:

`d20 + PB + Qi Cultivation key ability modifier`

A Cultivation Check is not automatically an ability check for effects that modify ordinary ability checks. A feature must explicitly apply to Cultivation Checks.

---


## 3. Realm Suppression and Effective Source CL

Realm Suppression changes which cultivation rules a character may use without retroactively shrinking the character's body or erasing persistent consequences.

When a creature is Realm Suppressed:

- Its **effective CL** and Proficiency Bonus for barred or scaling cultivation features use the suppressed CL.
- It cannot activate a Path, Subpath, Sphere talent, Cultivation Insight, Recorded Art, Forged Technique, Immortal Art, Method power, Foundation power, or item power whose minimum CL or Realm exceeds the suppression.
- A scaling feature uses the version available at the suppressed CL.
- Hit Points, Hit Dice, maximum Cultivation Points, Path-chassis durability, and a Foundation's passive embodied quality are not reduced unless an explicit rule says otherwise.
- Existing Corruption, contracts, karma, injuries, severances, consumed resources, and permanent prices remain.

An effect that remains actively maintained by the suppressed user uses the suppressed Source CL. An independent item, Asset, Anchor, injury, contract, or fixed world effect retains its own Source CL when its Source Rule says it is no longer dependent on the user.

If suppression makes an effect illegal to maintain, it ends unless the Source Rule explicitly establishes an independent persistent state. Realm Suppression cannot refund costs, duplicate lower-level benefits, or evade a one-for-one parent/Variant replacement.

---

## 4. Cultivation Assets

A **Cultivation Asset** is a separately targetable cultivated object, construct, manifestation, servant-profile, implement, vehicle, or battlefield element created or empowered by a feature.

Examples include:

- Shikigami.
- Paper soldiers.
- Painted beasts.
- Banners.
- Kites.
- Floating shield constellations.
- Cauldrons.
- Formation engines.
- Projected medical arrays.
- Temporary cultivated vehicles.

A Domain Armament is not automatically a Cultivation Asset. It uses the Domain Armament rules unless a feature expressly gives it an Asset profile.

### Required Asset Profile

Every Asset should state:

- Name and type.
- Size.
- AC.
- Hit Points.
- Saving throw method.
- Damage Resistances and Immunities.
- Condition Immunities.
- Speed.
- Initiative timing.
- Command requirement.
- Legal actions and Reactions.
- Range or tether.
- Source CL.
- Duration.
- What occurs at 0 Hit Points.
- Whether repair, resummoning, replacement, or material loss is required.

### Default Asset Profile

If a feature creates a targetable Asset but omits a statistic, use these defaults only for the omitted statistic:

- **AC:** `12 + creator’s PB`.
- **Hit Points:** `4 × Source CL`.
- **Saving Throws:** `d20 + creator’s PB + creator’s relevant Path ability modifier`.
- **Condition Immunities:** Charmed, Frightened, Poisoned, Prone.
- **Damage Immunities:** Poison and Psychic.
- **Source CL:** Source CL of the creating feature.
- **Initiative:** Acts during the creator’s turn.
- **Default action:** Dodge.
- **Tether:** 60 feet from creator unless the feature states another range.

The default profile is a fallback, not a reason to omit important statistics from publication.

### Asset Command

Unless a feature states otherwise:

- The Asset acts during the creator’s turn.
- It moves only when the creator commands or moves it using the feature’s printed action.
- If no command is given, it takes the Dodge action and makes no voluntary movement.
- It cannot activate the creator’s unrelated features.
- It cannot spend the creator’s Qi unless the feature explicitly authorizes the expenditure.
- It cannot use Reactions unless its profile grants one.
- It cannot speak, reason, scout, manipulate objects, or carry passengers unless its profile permits it.

A feature may grant command without an action, require a Bonus Action, replace one attack, or use another action. Use the specific command rule.

### Asset Position and Space

A targetable Asset normally occupies its space.

- Allies can move through its space only if the profile permits it or ordinary size rules allow it.
- An Asset does not provide Cover unless its profile or physical size says so.
- An Asset cannot flank unless it is a creature or the feature explicitly permits it.
- A projected implement that “occupies no space” is not a targetable Asset unless the feature gives it an Asset profile.

### Asset Concentration

Creating an Asset does not require Concentration unless the feature states so.

If an Asset sustains a field or Formation requiring Concentration:

- Losing Concentration ends the field or Formation.
- It does not necessarily destroy the Asset unless the feature says so.
- Destroying the Asset ends any effect for which it is the sole Anchor.

### Asset at 0 Hit Points

Unless a feature states otherwise, an Asset at 0 Hit Points is **dispersed or broken**, not Unconscious.

- It stops functioning immediately.
- Effects for which it is the sole Anchor end.
- It does not make death saving throws.
- It cannot be healed by ordinary creature healing.
- It can be repaired, resummoned, redrawn, rebound, or replaced only through the creating feature or a compatible specialist procedure.

A real item used as an Asset remains a real item. Its destruction can be permanent.

### Asset Repair

If a feature gives no repair procedure, use this default:

- A projected Asset can be recreated through its normal activation after the printed lockout, or after the start of the creator’s next turn if no lockout is stated.
- A temporary physical Asset requires 10 minutes and materials worth an amount appropriate to its grade, unless the creating feature supplies them.
- A real bound item requires its normal item-repair procedure.
- An equal- or higher-Source-CL specialist can repair a nonartifact Asset during a Cultivation Session when the fiction and materials permit it.

### Asset Resource Farming

An Asset created, controlled, preserved, or repeatedly repaired by a creature cannot qualify as a hostile target for that creature’s resource-generation features unless a Source Rule expressly creates that interaction.

---

## 5. Anchors

An **Anchor** is a targetable object, mark, seal, node, vessel, or point that sustains an ongoing cultivation effect.

An Anchor may be:

- A separate Cultivation Asset.
- A real object.
- A projected seal.
- A Formation node.
- A weapon planted in terrain.
- A banner or cauldron.
- A mark attached to a creature.
- A named location.

An effect should state whether its Anchor is visible, concealed, movable, carried, or attached.

### Default Anchor Profile

When a feature creates a targetable Anchor but omits statistics, use:

- **AC:** Creator’s Cultivation Save DC.
- **Hit Points:** `4 × Source CL`.
- **Damage Immunities:** Poison and Psychic.
- **Condition Immunities:** Charmed, Frightened, Poisoned, Prone.
- **Resistance:** Bludgeoning, Piercing, and Slashing from noncultivated attacks.
- **Saving Throws:** Uses creator’s Cultivation Check modifier.
- **Source CL:** Source CL of the creating feature.

An attached mark with no physical manifestation cannot be attacked merely because the default Anchor profile exists. It requires a feature that can target marks, curses, seals, conceptual structures, or the specified Anchor type.

### Anchor Destruction

When an Anchor reaches 0 Hit Points or is lawfully removed:

- The effect it solely sustains ends unless the Source Rule states another result.
- The creator does not automatically regain spent Qi.
- Conditions already made permanent do not reverse unless their rule says the Anchor sustains them.
- Any backlash printed by the creating feature occurs.

If multiple Anchors sustain an effect, the feature must state whether:

- Every Anchor is required.
- Any one Anchor is sufficient.
- Destroying Anchors weakens the effect in stages.
- The creator can replace an Anchor.

### Anchor Suppression

An Anchor can be suppressed without being destroyed.

- While suppressed, the portion of the effect it sustains is inactive.
- Its duration continues unless the suppressing feature says otherwise.
- When suppression ends, the Anchor resumes if it still exists and the effect’s duration remains.
- Suppression does not repair Hit Points.

### Concealed Anchors

A concealed Anchor whose Source CL does not exceed the observer’s can be located through an appropriate use of Qi Sensing, Formation analysis, divination, medicine, sealing, or another relevant discipline.

An Anchor whose concealment Source CL exceeds the observer’s requires a successful Cultivation Check against its save DC or an explicit counter-authority.

### Moving Anchors

An Anchor moves only when its feature permits movement.

- Forced movement of an Anchor is possible only when the effect can target or physically move that Anchor type.
- Moving an Anchor outside the feature’s legal range may suppress or end the effect as printed.
- Teleporting an Anchor must satisfy destination legality and any sealed-boundary restrictions.

---

## 6. Qi Fields and Formations

### Qi Field

A **Qi field** is an area in which a cultivator’s power establishes recurring effects, altered terrain, pressure, protection, environmental control, or technique origins.

A Qi field is not automatically a Formation.

Typical field rules include:

- Origin and radius.
- Height.
- Whether it moves.
- Concentration.
- Entry/start timing.
- Ally designation.
- Whether the origin is an Anchor.
- Whether remote techniques can originate there.

### Formation

A **Formation** is a structured cultivated arrangement using nodes, geometry, inscriptions, terrain, participants, tools, or Anchors.

A Formation normally has one or more of:

- Setup time.
- Required nodes or participants.
- Defined boundary.
- Formation Anchors.
- Shared effects.
- A command or control point.
- A procedure for analysis, breach, inversion, or repair.

A field does not gain Formation interactions merely because it is circular or has an Anchor. The Source Rule must call it a Formation or state that it counts as one.

### Entry and Start Triggers

Unless a field states otherwise:

- A creature is affected by an “enters or starts” trigger no more than once per turn.
- Forced movement can trigger entry.
- Creating the field on a creature does not count as the creature entering unless the feature says it does; the creature resolves the start trigger at the start of its turn.
- Teleporting into the area counts as entering.
- Leaving and re-entering during the same turn does not trigger the same entry effect twice unless the feature expressly allows it.

### Moving Fields

A field moves only when its Source Rule permits it.

When a moving field passes over a creature:

- The creature does not count as entering solely because the field moved over it unless the feature says so.
- It resolves the start trigger at the start of its turn if still inside.
- A feature may expressly treat being overtaken by the field as entry.

### Overlapping Fields

Two fields can overlap unless a rule says otherwise.

- Bonuses with the same name do not stack unless stated.
- A creature resolves each distinct hostile field’s trigger.
- The same cultivator cannot stack multiple instances of the same field on one target unless the feature expressly permits it.
- When two fields directly claim incompatible control over the same phenomenon, use Source CL and a Cultivation Check if needed.

### Field Origin and Remote Techniques

A feature allowing techniques to originate from a field’s center, Asset, Anchor, or node changes only the origin.

It does not automatically change:

- The feature’s range.
- Line of effect.
- Target legality.
- Weapon requirements.
- Concentration.
- Number of targets.
- Once-per-turn limits.

A sealed boundary between creator and remote origin can block control when its Source CL equals or exceeds the controlling feature.

### Breaking a Formation

A Formation can normally be challenged through one or more of:

- Destroying Anchors.
- Displacing nodes.
- Breaking inscriptions.
- Removing participants.
- Interrupting Concentration.
- Solving its pattern.
- Overwhelming its Source CL.
- Using a feature that explicitly breaks Formations.

Generic damage does not automatically end an abstract Formation unless it reaches a legal Anchor, participant, or physical structure.

---


## 7. Concentration, Duration, and Ending Effects

### Concentration

A cultivation effect requires Concentration only when its Source Rule says so.

- A creature normally maintains one Concentration effect at a time.
- Starting another Concentration effect ends the first unless an explicit cultivation authority permits both.
- Use the standard Constitution saving throw procedure for damage-related Concentration checks.
- Cultivated Response is not Constitution saving throw proficiency and does not apply unless a feature explicitly permits it.
- Nascent Soul's Independent Concentration modifies one failed Qi-powered Concentration save as printed; it does not provide a second Concentration slot.
- Becoming Incapacitated or dying ends Concentration unless an explicit independent consciousness, Asset, Anchor, Secret Law, or item authority says otherwise.

### Duration and Range

Leaving the original activation range does not end an effect unless the Source Rule says that continued range is required. Areas, routes, projectiles, Assets, and Anchors use their own movement and persistence rules.

A duration of **for the scene** ends when the universal Scene ends, not merely when initiative stops. A duration of **until repaired**, **until released**, **until the condition is met**, or **indefinite** is not shortened by a rest unless the Source Rule says so.

### Ending an Effect

An effect ends when any of the following applies:

- Its duration expires.
- Its user dismisses it when dismissal is permitted.
- Required Concentration ends.
- Its required Anchor or Asset is destroyed or invalidated.
- Its printed ending, solution, payment, purification, reconstruction, or release condition is completed.
- A superior counterauthority succeeds under its Source Rule.

Ordinary rest, healing, dispelling, teleportation, or repeated activation does not end a cultivation effect whose printed recovery procedure requires something else.

---

## 8. Cultivation Suppression

Cultivation suppression prevents access to a cultivated function without necessarily destroying the underlying structure.

### Suppressed Feature

When one named feature is suppressed:

- It cannot be activated.
- Its active benefits cease.
- Its duration continues unless the suppressing rule says otherwise.
- Costs already paid are not refunded.
- Passive anatomy or mundane training remains unless the feature itself created it.

### Suppressed System

A **system** may be a:

- Path resource engine.
- Golden Core Form.
- Nascent Soul vessel.
- Domain Armament bond.
- Sphere.
- Method function.
- Foundation function.
- Item power set.
- Formation network.
- Bound demon prison.
- Another named cultivation structure.

When a system is suppressed:

- Features requiring that system cannot be activated.
- Independent systems remain usable unless the suppressing rule targets them too.
- A feature requiring several systems fails when any indispensable system is suppressed.

### Complete Cultivation Suppression

**Complete Cultivation Suppression** is a high-authority state. It must be expressly imposed.

While completely suppressed, a creature cannot:

- Activate Path or Subpath features.
- Activate Sphere talents.
- Activate Recorded Arts or Forged Techniques.
- Spend or regain Cultivation Points.
- Manifest, command, call, or release Domain Armaments.
- Activate cultivated item powers requiring its cultivation.
- Activate Method, Foundation, bloodline, or transformation powers.
- Use cultivation-based teleportation, flight, possession, phasing, or remote senses.

Complete Cultivation Suppression does not automatically remove:

- Hit Points or Hit Dice.
- Ability scores.
- Mundane weapon or skill proficiency.
- Ordinary movement.
- Physical equipment.
- Permanent anatomy.
- A Foundation’s purely bodily shape or passive durability when the feature does not depend on active circulation.
- Existing scars, injuries, Corruption, obligations, or prices.

An individual rule may suppress some of these when it expressly targets them.

### Complete Suppression and Concentration

When complete suppression begins:

- The creature loses Concentration on cultivation effects unless the suppressing feature states they remain sustained externally.
- Independent Assets persist only if their rules allow them to act without the creator’s cultivation.
- Effects sustained solely by the creature’s active Qi end or become inactive.

### Leaving a Suppression Field

Leaving a field does not automatically cure a condition imposed within it.

The Source Rule must state whether leaving:

- Ends the suppression immediately.
- Removes one stage.
- Grants a repeat save.
- Does nothing while an Anchor or mark remains.

If no procedure is stated for an ordinary field-based suppression, the suppression ends at the end of the affected creature’s turn after it leaves the field and remains outside.

### Suppression versus Destruction

Suppression is not destruction.

- Suppressed systems can normally return when the effect ends.
- Destroyed, severed, consumed, or erased systems require reconstruction or a higher-authority restoration.
- A feature cannot claim permanent cultivation loss merely by using the word “suppress.”

---

## 9. Long-Term Cultivation Harm and Reconstruction

Cultivation harm can outlast combat. Use the following severity grammar when a feature does not define another structure.

### Tier I — Disruption

Examples:

- Temporary cost increase.
- Blocked recovery.
- One-round suppression.
- Meridian stagger.
- Brief inability to transform.

**Typical duration:** Until the start/end of a turn, scene end, or ordinary rest.  
**Typical recovery:** Printed save, leaving the field, ordinary treatment, or time.

### Tier II — Hidden Injury

Examples:

- Persistent meridian blockage.
- Internal Qi leak.
- Damaged circulation route.
- Technique recoil scar.
- Partially sealed organ.

**Typical duration:** Until diagnosed and treated.  
**Typical recovery:** Medicine, Pressure Points, Meridian Physician, suitable pill, cultivation session, or breakthrough repair.

A Hidden Injury should state:

- Its mechanical penalty.
- Its Source CL.
- How it is detected.
- What treatment is valid.
- What happens on a failed treatment.

### Tier III — Rupture or Crippling

Examples:

- One Sphere inaccessible.
- Golden Core Form disabled.
- Domain Armament bond unusable.
- Maximum Qi reduced.
- Nascent Soul vessel cracked.
- One meridian network severed.

**Typical duration:** Indefinite until specialist reconstruction.  
**Typical recovery:** Equal- or higher-Source-CL treatment, multiple Cultivation Sessions, rare materials, a successful breakthrough, or a named restorative authority.

Ordinary rest does not repair Tier III harm.

### Tier IV — Destruction or Severance

Examples:

- Golden Core destroyed.
- Nascent Soul vessel destroyed.
- Path resource organ removed.
- Soul severed from body.
- Foundation function cut away.
- Named cultivation relationship destroyed.

**Typical duration:** Permanent until reconstructed.  
**Typical recovery:** A full reconstruction project, Secret or equivalent authority, artifact intervention, major sacrifice, dangerous tribulation, or explicit reincarnation/restoration procedure.

Reconstruction creates or restores a legal structure. It does not merely dispel the injury.

### Tier V — Erasure or Conceptual Loss

Examples:

- A structure removed from ordinary existence.
- A name erased from authority.
- A relationship cut at conceptual level.
- A defining dream or prior-life identity consumed.
- A cultivation principle rendered absent.

**Typical duration:** Permanent or indefinite under superior authority.  
**Typical recovery:** The printed weakness, equal/higher Secret authority, Samsara, Karma, Void, Name, Fate, conceptual restoration, Immortal intervention, or campaign-defining procedure.

Tier V harm cannot be reversed by generic healing, dispelling, or ordinary resurrection.

### Reconstruction Procedure

When a long-term effect says that reconstruction is possible but gives no complete procedure, use this framework:

1. **Diagnosis:** Identify the damaged system and Source CL.
2. **Authority:** Lead specialist or restorative source must normally be within 2 Source CL; lower authority requires a printed weakness or major sacrifice.
3. **Materials:** Obtain an organ, pill, treasure, manual, bloodline sample, spiritual medium, Formation, or other fictionally appropriate materials.
4. **Sessions:** Tier III normally requires at least one Cultivation Session; Tier IV requires a project measured in several sessions or downtime; Tier V requires a major story procedure.
5. **Check:** Make a Cultivation Check against the injury’s save DC or `10 + injury Source CL ÷ 2` when no DC exists.
6. **Failure:** Materials or time are consumed as stated; the injury remains and may worsen only if the procedure warned of that risk.
7. **Success:** Restore the named structure. Any permanent price, lost lifespan, consumed resource, or separate injury remains unless also repaired.

### Self-Reconstruction

A creature cannot normally perform Tier IV or V reconstruction on itself while the damaged structure is indispensable to the required technique. External aid, an independent Nascent Soul, prepared Asset, stored body, Samsara mechanism, or other printed exception is required.

### Resurrection and Cultivation Harm

Returning a creature to life does not automatically restore:

- Destroyed cultivation systems.
- Severed conceptual relationships.
- Consumed souls.
- Lost Core grade.
- Permanent prices.
- Corruption.
- Secret-Law marks.

A resurrection feature must state what it reconstructs.

---

## 10. Bound Real Items and Projected Items

### Projected Item

A **projected item** is a cultivation manifestation, not a physical duplicate.

Unless a feature states otherwise, it:

- Occupies no space.
- Has no mundane market value.
- Cannot be sold, gifted, stored, or permanently disarmed.
- Cannot carry unrelated item properties.
- Cannot manipulate objects.
- Cannot be used as material for crafting.
- Ends when its creating feature ends.

A projected item can be targeted only by a rule that affects its manifestation type, Cultivation Assets, Domain Armaments, projected constructs, or cultivation effects generally.

### Bound Real Item

A **bound real item** remains the actual object.

- It is never duplicated.
- It retains its enhancement, material, attunement, named traits, damage type, charges, and durability.
- It can be stolen, suppressed, sealed, broken, displaced, or destroyed when a legal effect reaches it.
- A property requiring physical grip, stance, free hand, separate action, charge, or another trigger must still satisfy that requirement.
- Floating control counts as wielding only when the governing feature says so.

### Calling and Releasing

Calling a bound item to hand or releasing it to float:

- Requires the action stated by the Source Rule.
- Requires a legal hand when called.
- Requires a legal destination when released.
- Is not teleportation unless the feature says so.
- Can be blocked by total restraint, item-control effects, sealed Formations, spatial locks, or equivalent authority.

### Item Charges and Qi

Qi does not replace item charges unless the item or feature explicitly permits it.

An item charge does not replace Qi unless the feature explicitly permits it.

A copied or projected image of an item does not copy:

- Charges.
- Sentience.
- Soul bond.
- Artifact authority.
- Consumable contents.
- Unique legal ownership.

### Bound Item at 0 Durability

A real item uses its printed destruction rules.

If none exist:

- A mundane or ordinary cultivated item becomes Broken and unusable.
- A named, Saint-class, Legendary, or artifact item follows its Source Rule and normally requires specialist repair rather than disappearing.
- Destruction can end a bond but does not create a replacement item.

---

## 11. Weapon-Delivered Cultivation Techniques

A cultivation technique can be delivered through a weapon only when a Source Rule expressly permits it.

Using a weapon as a visible focus is not the same as weapon delivery.

### Default Procedure

Unless the authorizing feature states otherwise:

1. Pay the technique’s complete cost.
2. Make the authorized weapon attack.
3. On a miss, the technique is not delivered and the cost remains spent.
4. On a hit, deal the weapon’s normal damage.
5. Apply the delivered technique to the struck target or point.
6. Resolve any required saving throw.
7. Apply all once-per-turn and once-per-activation limits.

### First Qualifying Attack

When the activation includes multiple attacks, the technique applies only to the **first qualifying attack** unless the Source Rule explicitly authorizes:

- An additional attack.
- Multiple attacks.
- Every attack.
- A Barrage.
- A volley.
- A named sequence.

A missed first qualifying attack does not move the technique to a later attack unless the Source Rule expressly says so.

### Paid Multiattack Delivery

A feature authorizing repeated delivery must state:

- Maximum number of deliveries.
- Additional Qi or resource cost per delivery.
- Whether the cost is paid before or after each attack.
- Whether a miss consumes that delivery.
- Whether each target can receive the technique more than once.
- How damage and riders scale.

Unless stated otherwise:

- Pay the additional delivery cost before making the additional attack.
- A miss consumes that paid delivery.
- Qi Technique Potency applies once across the activation.
- A once-per-turn rider applies once across the activation.
- A once-per-target rider applies once to each target.
- An additional attack cannot generate another additional attack.
- A delivered technique cannot recursively deliver itself.

### Weapon and Technique Damage

When weapon delivery deals both weapon damage and technique damage:

- Apply a bonus that can affect either packet to only one packet unless its rule says otherwise.
- Resistance and Immunity apply separately by damage type.
- A rider requiring “weapon damage” requires the weapon packet to deal damage.
- A rider requiring “technique damage” requires the technique packet to deal damage.

### Domain Armament Delivery

A Domain Armament can deliver a technique only when:

- The core or Subpath expressly permits it.
- The Armament is in the required mode.
- The target is in legal range of the Armament.
- The remote-origin line is not blocked.
- A real item satisfies its own prerequisites.

A projected shield does not become a weapon merely because it is a Domain Armament. A bound shield may use an authorized shield attack or its printed assault profile.

---

## 12. Audible and Resonant Techniques

### Audible Technique

An **Audible technique** requires sound that the intended target or area can physically receive.

It is blocked or impaired by:

- Magical or cultivated silence of equal or higher Source CL.
- Vacuum.
- Complete soundproofing.
- A sealed boundary that blocks sound.
- Destruction or suppression of the required instrument.

Deafness protects a target only when the effect requires hearing. A sonic shockwave can still physically affect a deaf creature.

### Resonant Technique

A **Resonant technique** propagates through vibration, Qi resonance, a medium, an instrument, a bell, a mantra structure, or cultivated sympathetic connection.

- It may affect a deaf target when it does not require comprehension or hearing.
- Silence blocks ordinary sound but not necessarily vibration through solid matter, spiritual resonance, or mental recitation.
- The Source Rule must state what medium the resonance uses.
- A Resonant technique is not automatically Audible.

### Mental Recitation

Mental recitation bypasses inability to speak only when a feature expressly permits it.

It does not automatically bypass:

- Silence that suppresses the cultivated mantra itself.
- Thought suppression.
- Possession.
- Complete cultivation suppression.
- A broken instrument required by the technique.

### Instruments

A real instrument remains a real item and can be damaged or destroyed.

A projected instrument:

- Cannot use unrelated item properties.
- Cannot hold charges.
- Exists only through the creating effect.

If an instrument is the Anchor of an ongoing technique, destroying or suppressing it ends or suspends the technique as stated.

### Competing Sound Authorities

When two Audible or Resonant effects claim incompatible control of the same area, use Source CL.

Within 2 Source CL, each user makes a Cultivation Check. The higher result controls the contested sound layer until the start of the next contesting user’s turn. Independent physical damage still resolves unless explicitly cancelled.

---

## 13. Routes, Gates, Passengers, and Destinations

### Route

A **Route** is a cultivated path connecting movement through terrain, air, water, painted space, rivers, lantern roads, dragon veins, clouds, or another defined medium.

A Route should state:

- Origin.
- Destination.
- Maximum distance.
- Required knowledge or line of sight.
- Passenger limit.
- Transit time.
- Whether it is physical movement, teleportation, planar travel, or a special route.
- What blocks it.
- What happens when interrupted.

### Gate

A **Gate** is an entry/exit point created by a Route feature.

A Gate can be:

- One-way or two-way.
- Temporary or sustained.
- Visible or concealed.
- Targetable or abstract.
- An Anchor when the feature says so.

Destroying one Gate does not necessarily destroy the Route unless it is the sole Anchor.

### Legal Destination

A destination is legal only when all required conditions are satisfied.

Unless the feature states otherwise, a destination must be:

- An unoccupied space.
- Capable of holding the traveler.
- On the same plane.
- Within range.
- Visible, precisely known, marked, or connected by the required medium.
- Not inside a sealed boundary whose Source CL equals or exceeds the Route.
- Not inside solid matter.
- Not an artifact prison or explicitly inaccessible location.

If the destination becomes illegal after activation:

- Use the feature’s failure rule.
- If none exists, place the traveler in the nearest legal unoccupied space on the origin side.
- The cost remains spent when the route was valid at activation and became invalid during resolution.

### Passengers

A passenger must be:

- Within the feature’s boarding range.
- Willing, helpless, Grappled, physically carried, or otherwise legally compelled as the feature states.
- Within the feature’s passenger limit.

An unwilling conscious passenger receives the saving throw or contest printed by the feature. If none is printed, the Route cannot transport that passenger.

Passengers travel with worn and carried equipment unless the feature imposes a load limit.

### Sealed Boundaries

A sealed boundary blocks a Route when:

- It explicitly blocks the route’s movement type.
- Its Source CL equals or exceeds the Route.
- The Route does not exploit a printed weakness, internal mark, authorized key, broken Anchor, or higher authority.

A boundary lower by 3 or more Source CL can delay or distort the transit but cannot permanently trap the traveler unless it has an explicit capture rule.

### Interrupted Transit

If a Route is interrupted after departure but before arrival:

- Use the Source Rule’s failure result.
- If none exists, return travelers to the nearest legal origin-side space and deal Force damage equal to `1d6 per 10 feet` of unrealized transit, maximum `10d6`.
- A passenger is not stranded between planes unless the feature explicitly creates interstitial travel.

### Route Destruction

Destroying a Route or Gate:

- Does not destroy its destination.
- Does not harm passengers who already completed transit.
- Does not create a permanent portal.
- Does not permit resource farming through repeated low-cost disruption.

---

## 14. Qualifying Hostility and Anti-Recursion

### Qualifying Hostile Creature

A creature used to generate Qi, Dread, Essence, charges, marks, healing, movement, or another benefit must be meaningfully hostile when the feature requires a qualifying hostile.

It cannot be:

- Created primarily for farming.
- Controlled by the beneficiary.
- Captured and repeatedly harmed for resources.
- Repeatedly revived for the same trigger.
- More than 5 CL lower unless the feature expressly permits lesser enemies.
- A harmless bystander or consenting training target.

### Once per Activation

A once-per-activation benefit applies once to the entire activation, including:

- Every attack in an Attack action granted by that activation.
- Barrages.
- Volleys.
- Chains.
- Multi-projectile effects.
- Repeated field pulses generated by the same activation when the rule says once per activation.

### No Closed Resource Loops

Unless a Source Rule explicitly creates and limits the loop:

- A resource cannot generate itself.
- An extra attack cannot generate another extra attack.
- A repeated technique cannot repeat itself again.
- A copied projectile cannot create another copied projectile.
- An Asset cannot be destroyed and recreated solely to generate net resources.
- A feature cannot refund more of its own cost than was actually paid.
- A projected item cannot be consumed to create a permanent real item.

### Real Costs

Lifespan, permanent maximum-resource loss, destroyed Anchors, consumed souls, sacrificed items, expensive materials, and accepted Hidden Injuries must actually be paid. Temporary copies or projections do not satisfy real sacrifices unless a Source Rule expressly says so.

---

## 15. High-Authority Operation Comparison

Several Qi Subpaths can affect the same cultivation structure through different fictional and mechanical operations. They remain distinct.

### Void

**Void removes or suppresses existence, presence, manifestation, or access by making the target absent.**

- The thing may cease to occupy its expected place.
- Restoration requires returning what was made absent or overcoming Void authority.
- Void is not merely a seal and does not require a logical key.

### Conceptual Severance

**Severance cuts a relationship while either side may continue to exist.**

Examples:

- Soul from body.
- Technique from source.
- Owner from weapon.
- Name from authority.
- Wound from healing.

Restoration requires reconnecting the severed relation, not creating a replacement object unless the object was also destroyed.

### Execution

**Execution destroys through accumulated weapon judgment, exposure, or condemnation.**

- It requires marks, cuts, thresholds, or a legal execution opening.
- The body or cultivation structure is destroyed by the final strike.
- Recovery is treatment or reconstruction of what the weapon destroyed.

### Seals

**Seals bind, prohibit, restrict, or suppress named functions.**

- The structure normally remains present.
- A seal uses chains, commands, marks, wards, or Anchors.
- Escape normally means breaking, removing, satisfying, or overpowering the binding.

### Puzzle Locks

**Puzzle authority locks access through an encoded constraint that remains solvable.**

- The target confronts patterns, keys, stages, rules, or cognitive exploits.
- Escape requires solving, invalidating, or bypassing the encoded logic.
- Puzzle lockout should not become an unanswerable direct seal merely because it suppresses cultivation.

### Karma

**Karma returns actual consequence from a real cause, independent of agreement.**

- It does not require a contract.
- It must identify a genuine deed, benefit, harm, cause, Karmic Burden, Merit, or transferred consequence.
- Ripening resolves the causal thread rather than enforcing a promise.

### Oath

**Oath authority enforces witnessed obligation.**

- It depends on a vow, declaration, accepted office, witnessed promise, accepted covenant, surrender term, or explicit obligation.
- It does not arise from every harmful deed.

### Soul Contract

**Soul-contract authority uses explicit terms, breach triggers, and pledged soul or cultivation collateral.**

- It is more invasive than ordinary oath enforcement.
- It must state parties, acceptance state, collateral, breach, foreclosure, and release terms.

---

## 16. Collision-Repair Identity Boundaries

These boundaries supplement the high-authority comparison above. They prevent adjacent Subpaths from collapsing into the same progression chassis.

### Tea-Sage and Culinary

**Tea-Sage authority is precise and diagnostic.**

- Tea prepares individual infusions.
- It reads pulse, steam, poison, emotion, Dream pressure, and concealed influence.
- It corrects a failed save or sudden imbalance at the moment it occurs.
- Its ceremonies establish hospitality, readable response, purification, and limited guest protection.

**Culinary authority is material and logistical.**

- Culinary arts require meals, ingredients, rations, stores, kitchens, and physical consumption.
- They reinforce bodies over hours or days.
- They preserve provisions, sustain travel, feed groups, and establish campaign logistics.
- Their mass nourishment does not diagnose hidden conditions or provide reaction-based precision correction.

A Tea feature should not become an army commissary. A Culinary feature should not become a lie-reading or meridian-diagnosis ceremony merely because both use food and hospitality.

### Direct Seals and Puzzle Locks

**A Seal names what is bound.** It is broken through force, an Anchor, a release clause, seal-breaking authority, failed Concentration, or superior Source CL. Understanding the inscription does not automatically end it.

**A Puzzle encodes a solvable operating rule.** It must publish or procedurally expose clues, Keys, methods, stages, or a valid internal solution. Even complete cultivation lockout must preserve the printed Solve procedure unless another independent effect removes the creature's ability to act.

### Ordinary Dream Qi and Nightmare Dream Qi

**Ordinary Dream Qi** governs lucid rest, dream defense, temporary intrusion, shared dreamscapes, dream travel, and bounded refinement of genuine dream residue. It may be predatory, but it does not inherently create self-propagating fear ecology or permanent identity harvest.

**Nightmare Dream Qi** exclusively claims contagious Nightmare Seeds, fear-fed propagation, sleepwalker commands, involuntary dream prisons, population-scale dream predation, and permanent defining-dream theft.

The two resources are distinct. Ordinary Dream Resonance is not Nightmare Essence.

### Oath, Soul Contract, and Karma

**Oath-Ledger authority** requires a witnessed or lawfully imposed obligation with understandable terms. Its marks record fulfillment and breach of that obligation. It does not judge unrelated deeds.

**Soul-Collateral Contract authority** requires explicit terms, pledged collateral, a breach trigger, and a foreclosure right. Consent may be voluntary, coerced, conquered, inherited, or imposed by recognized authority. The Contract does not decide moral desert.

**Karma authority** follows actual cause and consequence without requiring consent, witness, promise, or contract. It records Karmic Burden and Merit arising from real harm, aid, theft, sacrifice, restoration, substitution, or transferred consequence.

A promise can be valid without Karmic Burden. A harmful deed can create Karmic Burden without any promise. A contract can lawfully foreclose collateral while still generating Karma through the harm it causes.

### Nine-Arts Transcendence

A generalist rotation engine is not sufficient to justify the word **Transcendent**. A Transcendent progression must eventually express a higher principle unavailable to ordinary rotation. The Nine-Arts Scripture therefore includes:

- A genuine temporary Tier 3 Master Expression.
- Cross-Sphere Principle Fusion.
- High-level dual-pattern maintenance.
- Explicit limits preventing permanent theft of Spheres or recursive complete activations.

### Ten-Thousand Sword Array Scripture

The Ten-Thousand Sword Array Cultivator is a specific Restricted Scripture for Sword Seeds, remote sword control, Sword Intent, twin armaments, and array geometry. It does not define all sword cultivation.

Ordinary sword use, jian and dao schools, fencing, saber lineages, weapon Spheres, Recorded Arts, and weapon-delivered cultivation remain broadly accessible through their own Source Rules.

---

## 17. Parent Lineages, Rare Variants, and Forbidden Variants

A **Variant** is an alternate progression of an existing parent Subpath. It is not a second Subpath, a package of bonus features, or an optional overlay placed on top of the parent.

### 14.1 Subpath Slot

A Variant occupies the same Subpath choice as its parent. A character cannot possess both progressions at the same Cultivation Level unless a Source Rule expressly creates a temporary composite state and states which features function. A copied, stolen, reincarnated, mirrored, or simulated feature does not bypass this rule.

### 14.2 Entry Methods

A character may enter a Variant in either of two ways.

**Direct Entry.** At CL3, or when first receiving the Subpath choice, select the Variant instead of the parent if a legal Source grants access. The character gains the Variant's CL3 feature and later gains only the Variant's higher-level features.

**Conversion Entry.** A character who already has the parent may convert through a breakthrough, inheritance awakening, corruption event, ritual, artifact bond, or other Source Rule. Unless that Source gives a different procedure, conversion requires one Cultivation Session per attained Subpath feature, access to the Variant source, and a successful Cultivation Check against `10 + the character's PB + the number of attained parent features`. Failure expends the session and any stated material price but does not remove the parent. Success replaces all attained parent features simultaneously with the matching Variant features.

A GM may replace the check with a story condition, tribulation, permanent price, or unavoidable transformation where the fiction requires it.

### 14.3 One-for-One Replacement

Each Variant lists the parent feature replaced at CL3, CL6, CL10, CL14, and CL18. A replaced feature ceases functioning. Its actions, Reactions, resources, passive benefits, Assets, Anchors, fields, and capstone are not retained unless the Variant expressly repeats them.

If a feature was sustaining an effect when conversion occurs, that effect ends after conversion resolves. Instantaneous results and completed injuries remain. Real items remain real items, but bonds or attunements depending solely on the replaced feature end or transform as the Variant states.

### 14.4 Retained Compatibility

For prerequisites, manuals, Insights, items, and rules that name the parent Subpath, the Variant counts as the parent unless the rule requires a specific replaced feature. A requirement such as “Storm Soul Cultivator” is satisfied by Heaven-Thunder Storm Soul. A requirement such as “Gale Burst” is not satisfied unless the Variant explicitly counts one of its features as Gale Burst for that requirement.

A Variant retains the parent’s Access Category only for prerequisite recognition. Its own printed classification, prices, Corruption, social restrictions, and Source authority control actual use.

### 14.5 Resources and Persistent States

A parent resource converts only where the relationship block says so. Otherwise it is lost when conversion succeeds, and the Variant begins with its normal minimum or empty state. Parent Assets and Anchors disperse unless the Variant expressly transforms them. Long-term injuries, debts, Corruption, consumed materials, and completed consequences do not disappear merely because the progression changes.

### 14.6 Reversion and Further Conversion

Conversion is not a free respec. Returning to the parent requires another legal Source and the same conversion procedure, plus purification, repair, restitution, or removal of the Variant’s permanent price where applicable. A character cannot alternate progressions between scenes or rests.

### 14.7 Temporary Access

A feature that temporarily copies one parent or Variant feature grants only that named feature. It does not grant the full progression, the other progression’s resource engine, or compatibility with both capstones. If the copied feature refers to a missing resource, Asset, Anchor, or earlier feature, the copy fails unless its Source Rule supplies a substitute.

### Heaven-Thunder Storm Soul

- **Parent Lineage:** Storm Soul Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Wind Walker` → `Tribulation-Scarred Meridians`
- **CL6 Replacement:** `Gale Burst` → `Heaven-Punishing Reprisal`
- **CL10 Replacement:** `Lightning Reflexes` → `Tribulation Cloud Core`
- **CL14 Replacement:** `Zephyr’s Step` → `Ninefold Heavenly Sentence`
- **CL18 Replacement:** `Eye of the Storm` → `Living Heavenly Tribulation`
- **Retained Compatibility:** Storm, lightning, movement, and Domain Armament references to the parent remain compatible; ordinary wind-control clauses remain only where the variant feature preserves them.

### Black-Sea Leviathan Womb

- **Parent Lineage:** Abyssal Depths Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Tidal Resilience` → `Inner Sea Awakening`
- **CL6 Replacement:** `Flowing Evasion` → `Abyssal Maw`
- **CL10 Replacement:** `Moon’s Pull` → `Gate of the Inner Sea`
- **CL14 Replacement:** `Deep’s Embrace` → `Leviathan Swallows the Moon`
- **CL18 Replacement:** `Leviathan’s Womb` → `World Beneath the Black Sea`
- **Retained Compatibility:** Water, abyss, pressure, and deep-sea prerequisites treat the variant as Abyssal Depths; parent movement or defense text applies only when repeated by the replacement feature.

### Living Quicksilver Immortal Embryo

- **Parent Lineage:** Mercurial Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Mercurial Qi` → `Living Mercury Body`
- **CL6 Replacement:** `Liquid Form` → `Divide the Immortal Embryo`
- **CL10 Replacement:** `Mercurial Adaptation` → `Assimilate the Pattern`
- **CL14 Replacement:** `Quicksilver Step` → `Thousandfold Quicksilver Court`
- **CL18 Replacement:** `Prima Materia` → `Undying Prima Materia`
- **Retained Compatibility:** Mercury, transformation, liquid-body, and alchemical prerequisites treat the variant as Mercurial; the variant does not also receive the parent’s separate adaptation menu.

### Cremation Cinder Heart

- **Parent Lineage:** Cinder Heart Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Cinder Touch` → `Cremation-Furnace Core`
- **CL6 Replacement:** `Heart of the Forge` → `Ash Sentence`
- **CL10 Replacement:** `Promethean Gift` → `Burn the Scripture`
- **CL14 Replacement:** `Ashen Rebirth` → `Cremation Prison`
- **CL18 Replacement:** `Cinder Sovereign’s Wrath` → `Cremate Heaven and Earth`
- **Retained Compatibility:** Fire and cinder prerequisites remain compatible. Constructive forge, gift, and rebirth functions are lost unless the replacement feature expressly reproduces them.

### Soul-Bound Artifact Cultivator

- **Parent Lineage:** Artifact Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Treasure Resonance` → `Bind the Living Treasure`
- **CL6 Replacement:** `Artifact Surge` → `Artifact Flesh`
- **CL10 Replacement:** `Hidden Treasury` → `Enter the Treasure`
- **CL14 Replacement:** `Artifact Resonance Field` → `Split Soul Treasury`
- **CL18 Replacement:** `Treasury Emperor` → `Immortal Treasure Body`
- **Retained Compatibility:** Artifact and treasure prerequisites remain compatible. The bound living treasure replaces ordinary broad treasury resonance; the character cannot run both independent artifact economies.

### Venomous Poison Cultivator

- **Parent Lineage:** Poison Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Venomous Qi` → `Living Venom Dantian`
- **CL6 Replacement:** `Poison Touch` → `Poisoned Meridian Scripture`
- **CL10 Replacement:** `Toxic Cloud` → `Plague of One Hundred Meridians`
- **CL14 Replacement:** `Essence Rot` → `Venomous Incarnation`
- **CL18 Replacement:** `Lord of Decay` → `Myriad-Venom Sovereign`
- **Retained Compatibility:** Poison, venom, toxin, and anti-poison prerequisites remain compatible. Parent poison doses and variant living venom are one lineage resource unless a feature explicitly distinguishes them.

### Heart-Stealing Emotion Cultivator

- **Parent Lineage:** Emotion Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Emotional Pulse` → `Steal the Surface Heart`
- **CL6 Replacement:** `Emotional Contagion` → `Heart Anchor`
- **CL10 Replacement:** `Heartbreak and Heartmend` → `Heart Transplant`
- **CL14 Replacement:** `Weather of the Heart` → `Rewrite the Inner Heart`
- **CL18 Replacement:** `Heartweaver` → `Sovereign of Ten Thousand Hearts`
- **Retained Compatibility:** Emotion and heart prerequisites remain compatible. Cooperative emotional healing and weather are lost unless the variant replacement expressly preserves them.

### Nightmare Dream Qi Cultivator

- **Parent Lineage:** Dream Qi Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Dreamer’s Rest` → `Nightmare Feaster`
- **CL6 Replacement:** `Lucid Strike` → `Nightmare Infection`
- **CL10 Replacement:** `Dream Refinement` → `Shared Nightmare Prison`
- **CL14 Replacement:** `Shared Dream Concordance` → `Feast of Sleeping Minds`
- **CL18 Replacement:** `Dream Ascension` → `Nightmare Sovereign`
- **Retained Compatibility:** Dream, sleep, and dream-travel prerequisites remain compatible. Ordinary restorative Dream Resonance is replaced by Nightmare Essence and cannot be generated or spent as a second pool.

### Calamity-Devouring Tribulation Vessel

- **Parent Lineage:** Tribulation Vessel
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Gather Calamity` → `Devour the Blow`
- **CL6 Replacement:** `Calamity Tempering` → `Steal the Tribulation`
- **CL10 Replacement:** `Tribulation Release` → `Calamity Refining Furnace`
- **CL14 Replacement:** `Calamity Furnace` → `Eat the Heavenly Decree`
- **CL18 Replacement:** `Walking Tribulation` → `Walking Apocalypse`
- **Retained Compatibility:** Tribulation and calamity prerequisites remain compatible. Stored calamity, stolen tribulation, and devoured decree use the variant’s single printed resource and cannot be duplicated through parent features.

### Soul-Collateral Contract Cultivator

- **Parent Lineage:** Oath-Ledger Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Record the Promise` → `Sign in Living Qi`
- **CL6 Replacement:** `Invoke the Clause` → `Foreclose Minor Collateral`
- **CL10 Replacement:** `Battlefield Covenant` → `Major Soul Covenant`
- **CL14 Replacement:** `Oathkeeper’s Record` → `Soul Foreclosure`
- **CL18 Replacement:** `Heaven as Witness` → `Sovereign Soul Contract`
- **Retained Compatibility:** Oath and contract prerequisites remain compatible only where they refer to explicit accepted terms. Witnessed obligations and pledged soul collateral are not two parallel ledgers; the variant uses Claims and collateral under its own rules.


---

## 18. Publication Requirements for Qi Subpaths

Every complete Qi Subpath should state, where relevant:

- Access Category.
- Primary identity.
- Common Sphere synergies.
- Required item, weapon, implement, or Source Rule.
- Resource maximum and recovery.
- Scene-start and scene-end procedure.
- CL3, CL6, CL10, CL14, and CL18 features.
- Exact action economy.
- Cost.
- Range, target, area, duration, and Concentration.
- Attack or save.
- Failure and success outcomes.
- Repeated-save cadence.
- Source CL outcomes.
- Asset or Anchor profile.
- Domain Armament interaction.
- Weapon-delivery interaction.
- Lower-Realm dominance and higher-authority limits.
- Long-term harm and recovery.
- Anti-recursion and anti-farming rules when needed.

A shorter entry can still be complete when it does not use these systems. Brevity is not itself a defect. Missing executable procedures are.

# Part III — Daemonic Corruption and Purification

## Shared Daemonic Rules

### Daemonic Tag versus Demonic Reputation

The **Daemonic** tag is mechanical.

A feature has the Daemonic tag when it:

- Channels daemonic energy.
- Uses or generates Corruption.
- Invokes a demon-derived organ, furnace, prison, banner, court, or equivalent source.
- Explicitly says that it has the tag.

“Demonic cultivator” can also be a political, legal, religious, or cultural accusation. A corpse user, dream eater, forbidden physician, unorthodox sect member, rebel, bloodline bearer, or socially condemned cultivator may be called demonic without having any mechanically Daemonic feature.

Do not assign or remove the Daemonic tag solely because of reputation.

### Corruption

These Subpaths use the universal Corruption track from **0 to 10**.

- Corruption is persistent until removed by a valid purification procedure.
- Corruption is not a Cultivation Point resource.
- It cannot be spent unless a feature explicitly says so.
- It cannot be transferred, copied, harvested, or used to generate itself unless a Source Rule expressly permits that operation.
- A character at 10 Corruption cannot voluntarily activate a feature that requires gaining Corruption unless that feature prints a specific maximum-Corruption consequence.
- A feature that says “gain Corruption” actually increases the track. Prevention or substitution requires an effect that explicitly prevents Corruption.

#### Interim Corruption Consequences

If the campaign’s main Corruption chapter is not present, use this interim structure:

| Corruption | State |
|---:|---|
| **0–3** | The corruption is perceptible to Qi Sensing, purification, and anti-daemonic effects, but imposes no universal penalty. |
| **4–6** | You have Disadvantage on checks made to conceal your Daemonic nature from an equal- or higher-Source-CL observer. Consecrated wards treat your Source CL as 1 higher when deciding whether you may cross them. |
| **7–9** | When you fail a saving throw against a possession, frenzy, compulsion, or transformation caused by a Daemonic source, subtract 1d4 from the first repeat save you make against that effect. |
| **10** | You are Saturated. You cannot voluntarily gain more Corruption except through a printed breach consequence. Purification requires a procedure whose Source CL is at least your own or a specific weakness of the corrupting source. |

These interim consequences do not force cruelty, alignment, allegiance, or loss of character control.

### Purification and Recovery

A purification effect must state that it removes Corruption, purifies Daemonic power, repairs a daemonic organ, or performs an equivalent operation.

Unless a feature states otherwise:

- An ordinary purification whose Source CL is lower than yours can suppress one Daemonic feature for a scene but cannot remove Corruption.
- A purification whose Source CL is within 2 of yours can remove 1 Corruption after a successful Cultivation Session, ritual, or printed activation.
- A purification whose Source CL is 3 or more higher can remove up to PB Corruption through a complete ritual, provided the target survives and accepts the procedure.
- An artifact, Secret Law, Immortal authority, divine mandate, heavenly tribulation, or explicitly superior purification uses its printed result.

Removing Corruption does not automatically:

- Restore sacrificed lifespan.
- Rebuild a destroyed Core or organ.
- Return consumed souls or memories.
- Reverse a bargain.
- Refund Qi.
- Remove Exhaustion or Hidden Injuries caused by overdraw.

Those consequences require their own recovery procedures.

### Anti-Daemonic Effects

An anti-daemonic effect applies only when its trigger is satisfied.

Examples include:

- Extra damage against Daemonic creatures or Daemonic manifestations.
- Advantage on saves against Daemonic features.
- Suppression of a Daemonic Asset or Anchor.
- A ward that blocks Daemonic transit or projection.
- Purification that removes Corruption.

A creature using one of these Subpaths does not automatically become a demon creature unless another rule changes its creature type.

### Qualifying Hostile Creature

A **qualifying hostile creature** must be meaningfully hostile and cannot be used as a resource farm.

It must satisfy all of the following:

- It is actively opposing you, your allies, or your present objective.
- Its CL is no more than 5 lower than yours.
- It was not created, summoned, captured, controlled, preserved, repeatedly revived, or deliberately kept alive primarily to generate resources.
- It is not a harmless bystander, willing training partner, or unattended object.

The GM may reject an exploitative trigger even when the literal words appear satisfied.

### Daemonic Source CL

The Source CL of a feature from this chapter is your Qi Cultivation level unless a bound item, demon, artifact, or external source explicitly provides a different Source CL.

When a Daemonic feature directly contests a purification, consecrated ward, exorcism, possession defense, or another authority:

- **Opposing Source CL 6 or more lower:** your feature applies its full lower-authority result unless the opposing effect has an explicit absolute protection.
- **Opposing Source CL 3–5 lower:** resolve the printed save or check once. Repeat resistance occurs only when the feature allows it.
- **Opposing Source CL within 2:** resolve all printed saves, checks, Anchors, and recovery procedures.
- **Opposing Source CL 3 or more higher:** the higher authority normally blocks, suppresses, or limits the feature unless you exploit a printed weakness, accumulated resource, broken Anchor, or successful Cultivation Check after the target’s normal resistance.
- **Artifact, Immortal, Secret, conceptual, or explicit absolute authority:** use the printed interaction rather than numerical comparison alone.

### Daemonic Domain Armaments

A real or projected Domain Armament can carry a Daemonic appearance without becoming a separate creature.

Unless a feature states otherwise:

- The Armament does not gain Corruption.
- Damage dealt through it has the Daemonic tag only when the authorizing feature has that tag.
- A real bound item is never duplicated.
- Suppressing the Armament does not remove your Corruption.
- Purifying a real bound item can suppress its Daemonic properties without automatically severing the Domain Armament bond.
- A consecrated ward can block the Armament’s remote movement or technique origin when its Source CL equals or exceeds the controlling feature.

---

# Part IV — Secret-Law Authority Summary

## Secret-Law Catalog Summary

| No. | Secret Law | Primary authority |
|---:|---|---|
| 1 | Void-Touched Cultivator | Absence, suppression, erasure, nonexistence |
| 2 | Samsara-Wheel Cultivator | Former lives, recurrence, death, reincarnation |
| 3 | Karma-Thread Cultivator | Cause, consequence, debt, merit, restitution |
| 4 | Heaven-Splitting Conceptual Severance | Relations, attributes, identity links, conceptual division |

### Distinction of Authorities

- **Void** removes a thing or manifestation from reality.
- **Samsara** returns a thing to a prior state, life, or cycle.
- **Karma** preserves the connection between deeds and their consequences, then settles the account.
- **Conceptual Severance** leaves both sides in existence but cuts the relationship that allowed them to function together.

These authorities can interact, oppose, or repair one another, but none is a universal answer to every Secret Law.

---

---

# Part V — Parent and Variant Quick Index

The complete conversion procedure and one-for-one replacement blocks appear in **Part II, Section 17: Parent Lineages, Rare Variants, and Forbidden Variants**. This table is navigational and does not replace those rules.

| Parent lineage | Variant | Classification |
|---|---|---|
| Storm Soul Cultivator | Heaven-Thunder Storm Soul | Rare Variant |
| Abyssal Depths Cultivator | Black-Sea Leviathan Womb | Rare Variant |
| Mercurial Cultivator | Living Quicksilver Immortal Embryo | Rare Variant |
| Cinder Heart Cultivator | Cremation Cinder Heart | Forbidden Variant |
| Artifact Cultivator | Soul-Bound Artifact Cultivator | Forbidden Variant |
| Poison Cultivator | Venomous Poison Cultivator | Forbidden Variant |
| Emotion Cultivator | Heart-Stealing Emotion Cultivator | Forbidden Variant |
| Dream Qi Cultivator | Nightmare Dream Qi Cultivator | Forbidden Variant |
| Tribulation Vessel | Calamity-Devouring Tribulation Vessel | Forbidden Variant |
| Oath-Ledger Cultivator | Soul-Collateral Contract Cultivator | Forbidden Variant |

# Part VI — High-Authority Catalog Index

| Classification | Entry | Primary authority or loop |
|---|---|---|
| Rare Inheritance | **Bloodline Cultivator** | Ancestral awakening, inherited arts, memory, and ancestor manifestation |
| Rare Inheritance | **Heaven-Thunder Storm Soul** | Rare tribulation lineage and heavenly lightning authority |
| Rare Inheritance | **Black-Sea Leviathan Womb** | Inherited inner sea, devouring maw, and world-scale abyssal body |
| Rare Inheritance | **Living Quicksilver Immortal Embryo** | Inherited immortal mercury body, division, assimilation, and continuity |
| Forbidden Variant | **Cremation Cinder Heart** | Forbidden cremation furnace, scripture burning, and ash imprisonment |
| Forbidden Variant | **Soul-Bound Artifact Cultivator** | Life-bound treasure body and survival through artifact continuity |
| Forbidden Variant | **Venomous Poison Cultivator** | Living venom dantian, plague meridians, and poison incarnation |
| Forbidden Variant | **Heart-Stealing Emotion Cultivator** | Predatory heart theft, anchors, transplants, and emotional rewriting |
| Forbidden Variant | **Nightmare Dream Qi Cultivator** | Harvest Nightmare Essence, spread contagious nightmare seeds, imprison sleepers, cultivate fear ecologies, and steal defining dreams |
| Forbidden Variant | **Calamity-Devouring Tribulation Vessel** | Active calamity theft, decree consumption, and apocalypse storage |
| Forbidden Variant | **Soul-Collateral Contract Cultivator** | Negotiate terms, pledge bodily or spiritual collateral, accrue enforceable Claims on breach, and foreclose pledged assets |
| Secret Law | **Void-Touched Cultivator** | Absence, erasure, suppression, and nonexistence |
| Secret Law | **Samsara-Wheel Cultivator** | Former lives, rollback, reincarnation, and cyclical return |
| Secret Law | **Karma-Thread Cultivator** | Read actual deeds as karmic imprints, return consequence without consent, mature cause into fruit, and force unresolved karma to ripen |
| Secret Law | **Heaven-Splitting Conceptual Severance** | Cut relations, attributes, systems, space, and conceptual continuity |
| Daemonic | **Devil-Heart Second Furnace** | Corruption-powered supplemental Qi engine |
| Daemonic | **Heaven-Devouring Black Cauldron** | Consume hostile Qi effects and refine stolen damage principles |
| Daemonic | **Demon-Prison Seal Cultivator** | Open demon chains and project the internal prison outward |
| Daemonic | **Calamity Banner Cultivator** | Fear-fed banner command and daemonic battlefield court |

# Adjudication Boundary

- The **player chapter** controls the Qi Path chassis and Insight acquisition.
- The **Subpath Compendium** controls each Subpath's printed features and exceptions.
- This **GM appendix** controls recurring adjudication procedures where the feature does not state a more specific rule.
- The general Tianxia rules control Foundations, Methods, Spheres, Recorded Arts, Forged Techniques, Attainment Points, breakthroughs, and Realm Suppression outside the Qi-specific rules reproduced here.
