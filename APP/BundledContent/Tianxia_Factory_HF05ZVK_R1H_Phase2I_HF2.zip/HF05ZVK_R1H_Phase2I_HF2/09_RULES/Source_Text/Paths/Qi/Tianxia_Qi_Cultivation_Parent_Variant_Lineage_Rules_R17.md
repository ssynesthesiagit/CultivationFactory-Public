# 14. Parent Lineages, Rare Variants, and Forbidden Variants

A **Variant** is an alternate progression of an existing parent Subpath. It is not a second Subpath, a package of bonus features, or an optional overlay placed on top of the parent.

## 14.1 Subpath Slot

A Variant occupies the same Subpath choice as its parent. A character cannot possess both progressions at the same Cultivation Level unless a Source Rule expressly creates a temporary composite state and states which features function. A copied, stolen, reincarnated, mirrored, or simulated feature does not bypass this rule.

## 14.2 Entry Methods

A character may enter a Variant in either of two ways.

**Direct Entry.** At CL3, or when first receiving the Subpath choice, select the Variant instead of the parent if a legal Source grants access. The character gains the Variant's CL3 feature and later gains only the Variant's higher-level features.

**Conversion Entry.** A character who already has the parent may convert through a breakthrough, inheritance awakening, corruption event, ritual, artifact bond, or other Source Rule. Unless that Source gives a different procedure, conversion requires one Cultivation Session per attained Subpath feature, access to the Variant source, and a successful Cultivation Check against `10 + the character's PB + the number of attained parent features`. Failure expends the session and any stated material price but does not remove the parent. Success replaces all attained parent features simultaneously with the matching Variant features.

A GM may replace the check with a story condition, tribulation, permanent price, or unavoidable transformation where the fiction requires it.

## 14.3 One-for-One Replacement

Each Variant lists the parent feature replaced at CL3, CL6, CL10, CL14, and CL18. A replaced feature ceases functioning. Its actions, Reactions, resources, passive benefits, Assets, Anchors, fields, and capstone are not retained unless the Variant expressly repeats them.

If a feature was sustaining an effect when conversion occurs, that effect ends after conversion resolves. Instantaneous results and completed injuries remain. Real items remain real items, but bonds or attunements depending solely on the replaced feature end or transform as the Variant states.

## 14.4 Retained Compatibility

For prerequisites, manuals, Insights, items, and rules that name the parent Subpath, the Variant counts as the parent unless the rule requires a specific replaced feature. A requirement such as “Storm Soul Cultivator” is satisfied by Heaven-Thunder Storm Soul. A requirement such as “Gale Burst” is not satisfied unless the Variant explicitly counts one of its features as Gale Burst for that requirement.

A Variant retains the parent’s Access Category only for prerequisite recognition. Its own printed classification, prices, Corruption, social restrictions, and Source authority control actual use.

## 14.5 Resources and Persistent States

A parent resource converts only where the relationship block says so. Otherwise it is lost when conversion succeeds, and the Variant begins with its normal minimum or empty state. Parent Assets and Anchors disperse unless the Variant expressly transforms them. Long-term injuries, debts, Corruption, consumed materials, and completed consequences do not disappear merely because the progression changes.

## 14.6 Reversion and Further Conversion

Conversion is not a free respec. Returning to the parent requires another legal Source and the same conversion procedure, plus purification, repair, restitution, or removal of the Variant’s permanent price where applicable. A character cannot alternate progressions between scenes or rests.

## 14.7 Temporary Access

A feature that temporarily copies one parent or Variant feature grants only that named feature. It does not grant the full progression, the other progression’s resource engine, or compatibility with both capstones. If the copied feature refers to a missing resource, Asset, Anchor, or earlier feature, the copy fails unless its Source Rule supplies a substitute.

## Heaven-Thunder Storm Soul

- **Parent Lineage:** Storm Soul Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Wind Walker` → `Tribulation-Scarred Meridians`
- **CL6 Replacement:** `Gale Burst` → `Heaven-Punishing Reprisal`
- **CL10 Replacement:** `Lightning Reflexes` → `Tribulation Cloud Core`
- **CL14 Replacement:** `Zephyr’s Step` → `Ninefold Heavenly Sentence`
- **CL18 Replacement:** `Eye of the Storm` → `Living Heavenly Tribulation`
- **Retained Compatibility:** Storm, lightning, movement, and Domain Armament references to the parent remain compatible; ordinary wind-control clauses remain only where the variant feature preserves them.

## Black-Sea Leviathan Womb

- **Parent Lineage:** Abyssal Depths Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Tidal Resilience` → `Inner Sea Awakening`
- **CL6 Replacement:** `Flowing Evasion` → `Abyssal Maw`
- **CL10 Replacement:** `Moon’s Pull` → `Gate of the Inner Sea`
- **CL14 Replacement:** `Deep’s Embrace` → `Leviathan Swallows the Moon`
- **CL18 Replacement:** `Leviathan’s Womb` → `World Beneath the Black Sea`
- **Retained Compatibility:** Water, abyss, pressure, and deep-sea prerequisites treat the variant as Abyssal Depths; parent movement or defense text applies only when repeated by the replacement feature.

## Living Quicksilver Immortal Embryo

- **Parent Lineage:** Mercurial Cultivator
- **Variant Classification:** Rare Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Mercurial Qi` → `Living Mercury Body`
- **CL6 Replacement:** `Liquid Form` → `Divide the Immortal Embryo`
- **CL10 Replacement:** `Mercurial Adaptation` → `Assimilate the Pattern`
- **CL14 Replacement:** `Quicksilver Step` → `Thousandfold Quicksilver Court`
- **CL18 Replacement:** `Prima Materia` → `Undying Prima Materia`
- **Retained Compatibility:** Mercury, transformation, liquid-body, and alchemical prerequisites treat the variant as Mercurial; the variant does not also receive the parent’s separate adaptation menu.

## Cremation Cinder Heart

- **Parent Lineage:** Cinder Heart Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Cinder Touch` → `Cremation-Furnace Core`
- **CL6 Replacement:** `Heart of the Forge` → `Ash Sentence`
- **CL10 Replacement:** `Promethean Gift` → `Burn the Scripture`
- **CL14 Replacement:** `Ashen Rebirth` → `Cremation Prison`
- **CL18 Replacement:** `Cinder Sovereign’s Wrath` → `Cremate Heaven and Earth`
- **Retained Compatibility:** Fire and cinder prerequisites remain compatible. Constructive forge, gift, and rebirth functions are lost unless the replacement feature expressly reproduces them.

## Soul-Bound Artifact Cultivator

- **Parent Lineage:** Artifact Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Treasure Resonance` → `Bind the Living Treasure`
- **CL6 Replacement:** `Artifact Surge` → `Artifact Flesh`
- **CL10 Replacement:** `Hidden Treasury` → `Enter the Treasure`
- **CL14 Replacement:** `Artifact Resonance Field` → `Split Soul Treasury`
- **CL18 Replacement:** `Treasury Emperor` → `Immortal Treasure Body`
- **Retained Compatibility:** Artifact and treasure prerequisites remain compatible. The bound living treasure replaces ordinary broad treasury resonance; the character cannot run both independent artifact economies.

## Venomous Poison Cultivator

- **Parent Lineage:** Poison Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Venomous Qi` → `Living Venom Dantian`
- **CL6 Replacement:** `Poison Touch` → `Poisoned Meridian Scripture`
- **CL10 Replacement:** `Toxic Cloud` → `Plague of One Hundred Meridians`
- **CL14 Replacement:** `Essence Rot` → `Venomous Incarnation`
- **CL18 Replacement:** `Lord of Decay` → `Myriad-Venom Sovereign`
- **Retained Compatibility:** Poison, venom, toxin, and anti-poison prerequisites remain compatible. Parent poison doses and variant living venom are one lineage resource unless a feature explicitly distinguishes them.

## Heart-Stealing Emotion Cultivator

- **Parent Lineage:** Emotion Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Emotional Pulse` → `Steal the Surface Heart`
- **CL6 Replacement:** `Emotional Contagion` → `Heart Anchor`
- **CL10 Replacement:** `Heartbreak and Heartmend` → `Heart Transplant`
- **CL14 Replacement:** `Weather of the Heart` → `Rewrite the Inner Heart`
- **CL18 Replacement:** `Heartweaver` → `Sovereign of Ten Thousand Hearts`
- **Retained Compatibility:** Emotion and heart prerequisites remain compatible. Cooperative emotional healing and weather are lost unless the variant replacement expressly preserves them.

## Nightmare Dream Qi Cultivator

- **Parent Lineage:** Dream Qi Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Dreamer’s Rest` → `Nightmare Feaster`
- **CL6 Replacement:** `Lucid Strike` → `Nightmare Infection`
- **CL10 Replacement:** `Dream Refinement` → `Shared Nightmare Prison`
- **CL14 Replacement:** `Shared Dream Concordance` → `Feast of Sleeping Minds`
- **CL18 Replacement:** `Dream Ascension` → `Nightmare Sovereign`
- **Retained Compatibility:** Dream, sleep, and dream-travel prerequisites remain compatible. Ordinary restorative Dream Resonance is replaced by Nightmare Essence and cannot be generated or spent as a second pool.

## Calamity-Devouring Tribulation Vessel

- **Parent Lineage:** Tribulation Vessel
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Gather Calamity` → `Devour the Blow`
- **CL6 Replacement:** `Calamity Tempering` → `Steal the Tribulation`
- **CL10 Replacement:** `Tribulation Release` → `Calamity Refining Furnace`
- **CL14 Replacement:** `Calamity Furnace` → `Eat the Heavenly Decree`
- **CL18 Replacement:** `Walking Tribulation` → `Walking Apocalypse`
- **Retained Compatibility:** Tribulation and calamity prerequisites remain compatible. Stored calamity, stolen tribulation, and devoured decree use the variant’s single printed resource and cannot be duplicated through parent features.

## Soul-Collateral Contract Cultivator

- **Parent Lineage:** Oath-Ledger Cultivator
- **Variant Classification:** Forbidden Variant
- **Entry Method:** Direct Entry or Conversion Entry under this chapter.
- **Subpath Coexistence:** Prohibited. This Variant replaces the parent progression.
- **CL3 Replacement:** `Record the Promise` → `Sign in Living Qi`
- **CL6 Replacement:** `Invoke the Clause` → `Foreclose Minor Collateral`
- **CL10 Replacement:** `Battlefield Covenant` → `Major Soul Covenant`
- **CL14 Replacement:** `Oathkeeper’s Record` → `Soul Foreclosure`
- **CL18 Replacement:** `Heaven as Witness` → `Sovereign Soul Contract`
- **Retained Compatibility:** Oath and contract prerequisites remain compatible only where they refer to explicit accepted terms. Witnessed obligations and pledged soul collateral are not two parallel ledgers; the variant uses Claims and collateral under its own rules.

