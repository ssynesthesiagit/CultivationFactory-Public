# Tianxia Qi Cultivation — Canonical Terminology Map R18

This map controls terminology for the Qi Cultivation Path, its Insights, its 80-entry Subpath catalog, and PHB insertion. A Source Rule may define a narrower term, but it should not silently redefine a canonical term.

## Core Character Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Path** | One of Tianxia's primary cultivation chassis, such as Qi Cultivation. | Class, casting class. |
| **Subpath** | The CL3 progression granting features at CL3, CL6, CL10, CL14, and CL18. | Subclass, archetype when rules meaning is intended. |
| **Cultivation Level (CL)** | The level used for cultivation progression and Realm. | Character level, class level, Source Level. |
| **Effective CL** | CL currently available after Realm Suppression or another explicit modifier. | Temporary level without definition. |
| **Realm** | Mortal, Foundation, Core Formation, Nascent Soul, or Immortal tier determined by CL. | Spell tier, caster tier. |
| **Proficiency Bonus (PB)** | The proficiency bonus corresponding to effective CL when Realm Suppression applies. | Unqualified level bonus. |
| **Qi Cultivation key ability** | Intelligence or Charisma chosen at CL1. | Casting ability unless a legacy spell interaction specifically requires it. |
| **Cultivation Save DC** | `8 + PB + key ability modifier`. | Spell save DC for Qi features. |
| **Cultivation Attack Modifier** | `PB + key ability modifier`. | Spell attack modifier for Qi features. |
| **Cultivation Check** | The explicit cultivation-authority check defined by a Source Rule. | Ordinary ability check unless the rule says it is one. |

## Resource and Time Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivation Points (CP)** | Generic name for a Path resource. | Mana, ki points, spell points. |
| **Qi** | Qi Cultivation's CP resource. | Mana, spell slots. |
| **Scene** | One continuous meaningful situation under the universal Tianxia definition. | Encounter when Scene is the intended rules unit. |
| **Activation** | One declared use including all attacks, projectiles, targets, and riders it creates. | Cast, spell instance, attack instance when the full use is intended. |
| **Once per activation** | Applies once across the complete use. | Once per projectile unless expressly intended. |
| **Full Cultivation Session** | The printed extended cultivation-recovery procedure. | Automatically equating it with any long rest. |

## Rule-Authority Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Source Rule** | The feature, talent, art, item, Method, Foundation, Formation, Insight, or law authorizing an effect. | Source ability, spell source, flavor authority. |
| **Source CL** | Cultivation authority of the effect or countermeasure. | Source Level, caster level. |
| **Cultivation technique** | A supernatural procedure authorized by a Source Rule. It is not automatically a spell or weapon attack. | Spell as a generic synonym. |
| **Cultivation authority** | Qualitative and quantitative authority printed by the Source Rule, including tags and Source CL. | Balance tier or spell level as the sole measure. |
| **Mechanical tag** | A printed rules tag such as Daemonic, Void, Karma, or Secret. | Inferring a tag from reputation or visual style. |
| **Realm disparity** | Asymmetric interaction produced by Source CL and Realm difference. | Automatic fairness or equal counter cadence. |

## Advancement and Character-Building Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Ability Score Improvement** | The normal +2 or two +1 level option. | ASI in player-facing final prose unless already defined. |
| **Cultivation Insight** | Major Path refinement selected at the listed levels or awarded by another source. | Feat as a generic replacement. |
| **Origin Insight** | Separate character-creation origin feature. | Treating it as a Cultivation Insight or feat. |
| **Background Sphere / Background Talent** | Free Background grants at CL1 under current character-creation rules. | Counting them against level talent or trained choices. |
| **Sphere** | Canonical sphere of practice. Learning a new Sphere grants its normal free first talent. | Skill tree, spell school. |
| **Talent** | Learned option inside a Sphere. | Spell known, invocation, maneuver unless quoting a source. |
| **Attainment Points (AP)** | Advancement currency for cultivation progress and breakthroughs. | CXP in current rules. |

## Cultivation Structure Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Foundation** | Embodied cultivation foundation with its printed passive and active qualities. | Subclass foundation, feat package. |
| **Method** | Cultivation method controlling CP maximum or other printed cultivation procedures. | Mana method, class feature. |
| **Recorded Art** | Fixed learned expression reproduced from a manual or lineage; it does not grant its source Spheres. | Martial Manual as the universal rules name; spell. |
| **Forged Technique** | Constructed multi-packet cultivation technique using the Forging rules. | Homebrew spell, combo spell. |
| **Immortal Art** | High-order named cultivation art using its own printed authority. | Ultimate spell. |
| **Cultivation Insight** | Personal breakthrough or refinement with prerequisites and printed ability options. | Feat. |

## Qi-Specific Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivated Response** | Paid post-failure Defensive Discipline; never saving throw proficiency. | Save proficiency. |
| **Qi Technique Potency** | Once-per-activation addition of the Qi key modifier to one damage roll. | Elemental Strike. |
| **Meridian Regulation** | CL2 treatment and suppression procedure. | Generic cure-all. |
| **Qi Armor** | Ranged-attack Reaction defense. | General AC spell or melee defense. |
| **Domain Armament** | Projected form or legally bound real item controlled by the Qi Path. | Flying Sword as the generic Path feature. |
| **Golden Core Form** | Stable, Circulating, or Reservoir Core choice at CL10. | Core Formation feature. Core Formation remains the Realm name. |
| **Nascent Soul** | CL15 autonomous Qi structure. It is not Spirit Awakening authority. | Spirit companion or second concentration by default. |
| **Nine Heavens Gaze** | CL17 active cultivation perception and analysis. | Generic truesight feature when referring to this Path feature. |

## Battlefield and Persistent-Effect Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Cultivation Asset** | Separately targetable cultivated object, construct, manifestation, servant-profile, implement, vehicle, or battlefield element. | Summon or pet when the Asset rules are intended. |
| **Anchor** | Targetable support sustaining or enabling an effect. | Focus, node, ward stone without defining its rules role. |
| **Qi Field** | Area altering local conditions without necessarily using linked geometry. | Aura or spell area as generic substitutes. |
| **Formation** | Deliberately structured linked cultivation effect, often using Anchors. | Field when geometry and linkage matter. |
| **Projected item** | Supernatural form created by a feature; it is not a second copy of a real item. | Duplicate item. |
| **Bound real item** | Existing item legally linked to a feature and moved or used without duplication. | Manifested copy. |
| **Route / Gate** | Travel path or opening using the Shared Rules definitions. | Teleport as a complete procedure when routes, passengers, and destinations matter. |

## Harm, Suppression, and Recovery Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Suppressed feature** | One named feature made unavailable. | Silenced class feature. |
| **Suppressed system** | A defined cultivation system made unavailable. | Disabled magic without scope. |
| **Complete cultivation suppression** | Full lockout under the printed high-authority procedure. | Stunned, antimagic, or ordinary dispel as substitutes. |
| **Hidden Injury** | Persistent cultivation harm requiring its printed diagnosis and treatment. | Ordinary damage or generic curse. |
| **Reconstruction** | Procedure restoring ruptured, destroyed, severed, or erased cultivation structures. | Healing when healing is insufficient. |
| **Permanent** | Persists until an explicit recovery, reconstruction, reversal, or higher authority succeeds. | Irreversible unless the rule actually says no recovery exists. |
| **Indefinite** | Has no time limit but can end through its printed procedure. | Permanent when the distinction matters. |

## Subpath Classification Terms

| Canonical term | Meaning and required usage | Avoid or replace |
|---|---|---|
| **Open School** | Broadly teachable or institutionally available lineage. | Basic subclass. |
| **Restricted Scripture** | Controlled instruction due to expertise, danger, politics, medicine, military use, or institutional custody. | Automatically stronger school. |
| **Rare Inheritance** | Rare structural access or singular transmission. | Legendary subclass as a generic label. |
| **Rare Variant** | Rare parent-lineage conversion governed by replacement rules. | Second Subpath. |
| **Forbidden Variant** | Parent-lineage conversion with a prohibited or condemned price. | Automatically evil or Daemonic. |
| **Secret Law** | Law-level authority requiring explicit access and initiation price. | Merely high-level technique. |
| **Daemonic** | Mechanical tag interacting with Corruption, daemonic energy, purification, or anti-daemonic rules. | Using “demonic” reputation as a tag. |

## Canonical Collision Boundaries

- **Tea-Sage** is precision infusion, diagnosis, purification, correction, and ceremony. **Culinary** is provisions, body reinforcement, preservation, camp logistics, and mass feeding.
- **Cultivator of Seals** imposes direct named bindings. **Puzzle Cultivator** creates clue-bearing encoded constraints with solution procedures.
- **Dream Qi** is restorative and cooperative lucid cultivation. **Nightmare Dream Qi** is contagious, predatory, imprisoning, and harvest-oriented.
- **Oath-Ledger** requires obligation. **Soul-Collateral Contract** requires explicit terms and collateral. **Karma-Thread** follows actual deeds without consent or witness.
- **Void** erases or removes. **Conceptual Severance** cuts a relationship while the separated things can remain.
- **Ten-Thousand Sword Array Cultivator** is a specific flying-sword and array lineage; it is not the generic name for all sword-using Qi cultivators.
- **Nine-Arts Transcendent Cultivator** is a synthesis Scripture, not a generic label for high-level Qi cultivation.

## Deprecated Feature-Name Map

| Deprecated or ambiguous term | Canonical replacement |
|---|---|
| Elemental Strike | Qi Technique Potency, or the exact elemental Source Rule involved. |
| Flying Sword as a Path feature | Domain Armament. Lowercase descriptive flying swords remain valid inside the Ten-Thousand Sword Array lineage. |
| Core Formation feature | Golden Core Form. **Core Formation** remains the Realm name. |
| Old Nascent Soul recovery | Nascent Continuity and the current Nascent Soul feature suite. |
| Sword Cultivator as a Subpath title | Ten-Thousand Sword Array Cultivator. |
| Transcendent Cultivator | Nine-Arts Transcendent Cultivator. |
| Soul-Contract Cultivator | Soul-Collateral Contract Cultivator. |
| Subclass | Subpath. |
| Character level / class level | Cultivation Level (CL), unless ordinary noncultivation level is specifically required. |
| Source Level / caster level | Source CL. |
| Mana / ki / spell slots | Qi or Cultivation Points, as appropriate. |
