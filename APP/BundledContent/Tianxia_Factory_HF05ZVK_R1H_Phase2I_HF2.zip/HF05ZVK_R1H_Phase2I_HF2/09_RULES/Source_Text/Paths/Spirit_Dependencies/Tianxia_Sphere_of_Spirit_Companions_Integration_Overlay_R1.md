# Tianxia Sphere of Spirit Companions — Core/Companion Integration Overlay R1

**Status:** Mandatory integration overlay for use with Spirit Awakening Core R2A, Spirit Awakening Rules Reference R3, and Universal Bonded Companions Combat Chassis R2. This overlay changes shared references and procedures only. It does not yet perform the full talent-by-talent cadence and determinism modernization of the Sphere Compendium entry.

# 1. Cross-Reference Replacement

Every reference in the current Sphere entry to **Chapter 13: Bonded Companions**, **Chapter 13 companion statistics**, or **Chapter 13 bonded companion** now means the **Universal Bonded Companions Combat Chassis R2**.

Use that chassis for:

- Companion Archetype and combat statistics;
- initiative, movement, commands, attacks, Reactions, and Dodge default;
- Companion CL, Source CL, and Realm Evolutions;
- Continuity Model, 0 Hit Points, injury, recovery, and restoration;
- Realm Suppression of linked companion benefits.

Use the Sphere of Spirit Companions for:

- Spirit Nature, Nature Tags, Nature Spheres, and Nature Expressions;
- Covenant, Binding, and Hosting Bonds;
- Needs, sustenance, Offerings, Taboos, Bond Strain, and crises;
- manifestation, vessels, shrines, spirit speech, possession, true names, and spirit-specific talents.

# 2. Bond Strain Replacement

Replace the Sphere’s open-ended Bond Strain crisis paragraph with the Bond Crisis Procedure in Spirit Awakening Rules Reference R3.

Every Major Bond must record one ordinary crisis and one severe crisis before play. When Strain reaches 3, use this order:

1. a violated Taboo applies the recorded severe crisis;
2. denied Need or a coercive command causes refusal, disables one recorded Nature Expression for the scene, and applies the ordinary crisis;
3. unsafe overmanifestation ends the manifestation and prevents another manifestation until the recorded Minor Offering is completed;
4. any other listed trigger applies the recorded ordinary crisis.

After the crisis resolves, Bond Strain becomes 1 unless the Source Rule explicitly breaks the Bond, frees the spirit, preserves contested Hosting, or sets another value.

The GM does not invent a new crisis during resolution.

# 3. Offering Replacement

Replace “the GM decides whether an Offering is sufficient” with the Required Bond Record and Sustenance/Offering Values in Rules Reference R3.

Each significant spirit must record:

- routine sustenance and cadence;
- one Minor Offering;
- one Major Offering;
- the exact mechanical result of each;
- one Taboo and its exact Strain trigger.

A substitute Offering uses the printed Cultivation Check procedure. A gift with no recorded qualification has no mechanical result.

# 4. Full Companion Action-Economy Replacement

A Major Spirit Bond, Hosted spirit, Binding Seal, manifestation, vessel, or Nature Expression is not automatically a full companion.

When a spirit is explicitly upgraded to a full Bonded Companion:

- it acts under the universal companion chassis;
- a Nature Expression commanded as an Action or Bonus Action replaces its normal action unless the expression says it is a rider, Reaction, or strike replacement;
- it does not Attack and use a separate major Nature Expression on the same turn without explicit permission;
- it has no independent CP pool unless a Source Rule records one;
- destruction of its combat body uses its pre-recorded Continuity Model.

# 5. Rule Order

For Spirit Companions interactions, use:

1. explicit talent, feature, Bond, or spirit record;
2. Spirit Awakening Core R2A when it is a Path feature;
3. Spirit Awakening Rules Reference R3 for shared spiritual procedures;
4. Universal Bonded Companions Combat Chassis R2 for full companion combat-body questions;
5. the Sphere entry for Spirit Nature and relationship features;
6. universal Tianxia rules.

# 6. Publication Boundary

This overlay resolves the dependency and cross-reference blockers. It does not certify every inherited Sphere talent as publication-final. Rest cadence, open-ended GM choices, and incomplete action records in individual talents remain part of the later central Insight and Sphere modernization audit.
