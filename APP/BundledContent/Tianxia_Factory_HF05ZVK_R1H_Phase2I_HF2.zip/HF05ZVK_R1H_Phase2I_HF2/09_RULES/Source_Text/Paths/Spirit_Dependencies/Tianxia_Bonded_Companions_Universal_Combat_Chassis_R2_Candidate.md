# Tianxia Bonded Companions — Universal Combat Chassis R2 Candidate

> *A companion is not an extra action wearing an animal’s face. It is another cultivated life whose fate, body, and authority have become mechanically linked to yours.*

**Status:** Dependency-sealed candidate for Spirit Awakening modernization. This chapter supersedes the legacy PHB Bonded Companions chapter wherever the two conflict. It is suitable for Subpath normalization, Insight repair, Character Factory planning, and playtesting. It becomes final canon only after the three-Path harmonization audit and PHB publication pass.

**Scope:** This is the universal chassis for a **full combat-capable Bonded Companion**. It governs the companion’s combat body, statistics, initiative, command economy, attacks, recovery, continuity, restoration, Realm Evolutions, Realm Suppression, and record requirements.

It does **not** by itself grant a companion. A Path feature, Subpath feature, Sphere talent, Cultivation Insight, Background, inheritance, item, Recorded Art, ritual reward, or other explicit Source Rule must grant or upgrade a creature into a full Bonded Companion.

For a spirit companion, use this chapter for the combat body and use the **Sphere of Spirit Companions** and **Spirit Awakening Rules Reference** for Spirit Nature, Bonds, Hosting, Binding Seals, Offerings, Taboos, Bond Strain, manifestations, possession, exorcism, and reconstruction of the spirit itself.

---

# 1. Rule Order and Chassis Boundary

Resolve a Bonded Companion interaction in this order:

1. The explicit Source Rule granting or modifying the companion.
2. The companion’s complete recorded profile.
3. This Bonded Companion Combat Chassis.
4. For a spirit: the Spirit Awakening core, Spirit Awakening Rules Reference, and Sphere of Spirit Companions for spiritual matters within their stated scope.
5. Universal Tianxia cultivation rules.
6. Ordinary fifth-edition procedures where Tianxia has not replaced them.

A specific rule overrides only the exception it states. A creature’s appearance, legend, species name, spiritual reputation, or resemblance to a published monster does not grant an unprinted attack, immunity, movement mode, spell, Sphere, talent, or authority.

## Combat Chassis versus Relationship Chassis

A **combat chassis** answers:

- Where does the companion act in initiative?
- What are its AC, Hit Points, Speed, attacks, saves, skills, and legal actions?
- What command does it require?
- What happens at 0 Hit Points?
- How does it gain Realm Evolutions?
- How is its combat body repaired or restored?

A **relationship chassis** answers:

- Is the companion willing, bound, Hosted, inherited, constructed, or coerced?
- What does it need or consume?
- What permissions do the parties grant each other?
- What Offerings, Taboos, crises, withdrawal terms, and reconstruction terms apply?
- Does it possess independent personhood, Spirit Nature, Nature Expressions, or a separate Source CL?

A full spirit companion uses both. A beast, construct, puppet, animated item, or other companion may use only the portions relevant to its nature.

---

# 2. Access, Number, and Companion Identity

## Explicit Access Required

You gain a full Bonded Companion only when a Source Rule says that a creature becomes, counts as, or is upgraded into a full combat-capable Bonded Companion under this chapter.

The following do not automatically grant one:

- owning or training a beast;
- maintaining a Minor Spirit Agreement or Major Spirit Bond;
- Hosting a spirit;
- creating a puppet, doll, vessel, summon, manifestation, or Cultivation Asset;
- being followed by an NPC;
- placing a creature in a Soul Anchor, shrine, weapon, shadow, or dantian;
- knowing Beastmastery, Puppetry, Spirit Companions, or another thematically related Sphere without the required talent.

## One Full Bonded Companion

You may normally maintain **one** full Bonded Companion at a time.

You may also maintain ordinary pets, mounts, Minor Spirit Agreements, Major Spirit Bonds, noncombat familiars, messenger creatures, cosmetic companions, trained beasts, temporary summons, and Cultivation Assets. Those do not gain this chassis unless a Source Rule upgrades them.

A rule that grants an additional full Bonded Companion must state:

- how many additional companions it permits;
- whether each receives a complete turn;
- how commands are issued;
- whether attacks or actions are shared, reduced, or restricted;
- how Realm Evolutions are assigned;
- whether the companions share one restoration limit or have separate continuity.

“Maintain more Bonds” never means “gain more full combat turns.”

## Companion Personhood

A companion can be obedient without being mindless. Record whether it is:

- **Non-sapient:** acts through training, instinct, programming, or simple commands.
- **Awakened:** possesses self-awareness and recognizable preferences but limited social or strategic independence.
- **Sapient:** possesses personhood, long-term goals, memory continuity, and the ability to negotiate or refuse under its recorded terms.
- **Independent Cultivator:** possesses its own full cultivation progression or NPC stat block. Such a creature normally does not use this linked chassis unless its Source Rule expressly converts part of its power into a Bonded Companion profile.

A willing sapient companion is not property. A coercively bound companion obeys only under its printed binding rules and consequences.

## Refusal and Autonomy Record

For an Awakened or Sapient companion, record up to three **Refusal Triggers**. Examples include harming children, violating a shrine, attacking its own lineage, breaking an oath, entering a spiritually dead region, or consuming a prohibited substance.

A companion can refuse a command only when:

- the command triggers a recorded Refusal Trigger or Taboo;
- the command is physically or spiritually impossible;
- the companion is under a stronger hostile control effect;
- a Source Rule expressly permits refusal.

The GM does not invent new refusal conditions during combat. A Covenant, Binding Seal, construct directive, or other relationship rule states the consequence of refusal.

---

# 3. Complete Bonded Companion Record

Before a full Bonded Companion enters play, record all of the following.

## Identity and Source

- Companion name.
- Companion type and description.
- Source Rule granting full-companion status.
- Personhood category.
- Consent or binding status.
- Companion Archetype.
- Size and occupied space.
- Continuity Model.
- Linked or Independent progression model.
- Native Source CL, if any.

## Combat Profile

- Ability scores and modifiers.
- AC and maximum Hit Points.
- Speed and movement modes.
- senses and languages;
- two trained skills;
- Companion Strike form, attack ability, reach or range, and damage type;
- Realm Evolutions;
- legal equipment;
- condition, damage, or environmental exceptions granted by a Source Rule.

## Command and Relationship

- command method;
- bond range;
- incapacitated directive;
- Refusal Triggers or construct directives;
- dismissal, recall, shelter, or storage procedure;
- for a spirit: Nature, Nature Tags, Nature Expressions, Need, sustenance, Offerings, Taboo, Bond Strain, embodiment state, and reconstruction terms.

## Destruction and Recovery

- what 0 Hit Points means under the Continuity Model;
- whether death saving throws occur;
- where the surviving soul, core, pattern, or vessel remains;
- ordinary healing compatibility;
- restoration materials and remnant;
- permanent-destruction conditions.

A companion is not publication-complete if any of these entries are left as “appropriate,” “as needed,” or “GM decides during play.”

---

# 4. Companion Progression and Source CL

## Linked Companion Level

The default player-character model is **Linked Progression**.

Your companion’s **Companion CL** equals your total Cultivation Level. It gains the attack scaling and Realm Evolutions listed in this chapter at the same thresholds you do.

Companion CL is a game-facing measure of the bond’s combat expression. It does not prove that the creature knows your Paths, Spheres, talents, Methods, Foundations, Insights, or techniques.

## Independent Progression

An independent NPC, ancient spirit, inherited ancestor, intelligent weapon, beast sovereign, or other creature may possess its own native CL and statistics.

Use its independent profile instead of this chassis unless a Source Rule expressly states:

- which parts of the full profile remain;
- which parts are replaced by the linked companion profile;
- which CL determines attacks, saves, Nature Expressions, and authority;
- whether it takes an independent NPC turn or the Bonded Companion turn.

A player does not gain a higher-CL NPC’s full statistics merely by bonding with it.

## Companion Source CL

Unless a Source Rule states otherwise:

- the companion’s Companion Strike and Realm Evolutions use its current Companion CL as Source CL;
- a Nature Expression uses the Source CL specified by the Sphere talent or spirit record;
- a technique paid from the cultivator’s CP uses the activating Source Rule’s Source CL;
- an independent injury, curse, seal, Anchor, or item retains its own Source CL;
- a companion does not lend its Source CL to the cultivator’s unrelated techniques.

## Proficiency Bonus

A Linked companion uses your Proficiency Bonus. It does not add proficiency to saving throws unless a Source Rule explicitly grants a bonus to a particular save.

This preserves Tianxia’s no-saving-throw-proficiency chassis. The companion uses its ability modifier for ordinary saving throws and any specific active defense printed by its Source Rule or Realm Evolution.

---

# 5. Companion Archetypes

Choose one Companion Archetype when the creature becomes a full Bonded Companion. A Source Rule may restrict the choice.

A companion may be Small or Medium unless its Source Rule or Evolution permits another size.

## Guardian Companion

Guardian companions are durable, strong, and suited to interception, carrying, holding ground, and direct physical pressure.

| STR | DEX | CON | INT | WIS | CHA |
|---:|---:|---:|---:|---:|---:|
| 16 (+3) | 12 (+1) | 16 (+3) | 6 (−2) | 12 (+1) | 10 (+0) |

**Guardian Hide.** Increase the companion’s AC by 1.

Appropriate forms include armored beasts, shrine guardians, heavy constructs, tortoises, oxen, apes, bears, boars, statues, and defensive spirits.

## Swift Companion

Swift companions emphasize pursuit, scouting, flanking, rapid repositioning, climbing, and evasive movement.

| STR | DEX | CON | INT | WIS | CHA |
|---:|---:|---:|---:|---:|---:|
| 12 (+1) | 16 (+3) | 14 (+2) | 6 (−2) | 14 (+2) | 10 (+0) |

**Swift Step.** Its walking Speed is 40 feet.

Appropriate forms include wolves, foxes, panthers, cranes, serpents, hunting cats, light constructs, wind spirits, and shadow beasts.

## Mystic Companion

Mystic companions emphasize perception, communication, spiritual interaction, support, and Nature Expressions.

| STR | DEX | CON | INT | WIS | CHA |
|---:|---:|---:|---:|---:|---:|
| 10 (+0) | 14 (+2) | 12 (+1) | 12 (+1) | 16 (+3) | 14 (+2) |

**Spirit Sense.** It perceives visible manifestations, unhidden spirits, and incorporeal creatures within 30 feet. This does not reveal concealed Nature, thoughts, statistics, true names, possession terms, or effects protected by a stronger concealment Source Rule.

Appropriate forms include dream cats, moon rabbits, ravens, ancestral guardians, living dolls, spirit foxes, sentient weapons, and cultivated familiars.

## Changing Archetype

A companion does not change Archetype through an ordinary rest or cosmetic transformation.

Changing Archetype requires one of:

- an explicit Source Rule;
- a Realm breakthrough that physically or spiritually rebuilds the companion;
- a 30-day cultivation project with a compatible teacher, Method, laboratory, shrine, beast ecology, or reconstruction procedure.

Changing Archetype replaces the old ability array and Archetype benefit. It does not grant additional Realm Evolutions.

---

# 6. Bonded Companion Statistics

## Creature Type and Size

The companion is a beast, spirit, construct, plant, undead, elemental, object-creature, or other type established by its Source Rule. Creature type has only the consequences printed by the applicable rules.

Its default size is Small or Medium.

## Armor Class

`12 + your Proficiency Bonus`

Apply Guardian Hide or another explicit modifier. Worn armor or barding replaces this formula only when its resulting AC is higher; it does not stack unless the item says it stacks with companion natural armor.

## Hit Points

`5 + (5 × Companion CL) + (5 × Constitution modifier)`

Minimum maximum Hit Points: `5 × Companion CL`.

A Source Rule can replace this formula. Temporary changes to Constitution do not retroactively alter maximum Hit Points unless the effect says so.

## Hit Dice

The companion has one d8 Hit Die per Companion CL.

A Guardian companion may use d10 Hit Dice if the Source Rule granting it expressly states that it is a heavy or defender companion. Archetype alone does not change the die.

## Speed

Base walking Speed: 30 feet. Swift Step changes this to 40 feet.

A companion gains climbing, swimming, burrowing, flying, hovering, incorporeal, phasing, planar, or teleportation movement only from a Source Rule or Realm Evolution.

## Saving Throws

The companion makes ordinary saving throws using the relevant ability modifier. It gains no general saving throw proficiencies.

A companion can benefit from Soulward Response, Stamina Guard, Cultivated Response, a Bonded defense, or another active rule only if that rule expressly targets or can be used by the companion.

## Skills

Choose two from Acrobatics, Athletics, Insight, Investigation, Perception, Stealth, and Survival. Add your Proficiency Bonus when it makes those checks. A Source Rule can add another named skill to this list.

If a later feature grants proficiency in the same skill again, it grants no benefit unless it expressly grants Expertise.

## Senses

Passive Perception equals:

`10 + Wisdom modifier + Proficiency Bonus if trained in Perception`

Darkvision, blindsight, tremorsense, true sight, scent, spirit sense, and similar senses require an explicit Source Rule.

## Languages and Communication

The companion understands the languages you speak unless its Source Rule says otherwise. It cannot speak them unless its form, personhood, or a feature permits speech.

Within the Bond Range, you can communicate simple intent, direction, danger, emotion, and commands through the bond. This is not unrestricted telepathy or memory exchange.

## Carrying and Manipulation

Use ordinary carrying rules from the companion’s Strength and size.

A companion can manipulate tools, weapons, doors, containers, talismans, or other objects only when its anatomy or Source Rule permits it. Descriptive intelligence does not create hands.

---

# 7. Companion Strike

When the companion is created, choose its Companion Strike profile.

## Form

Choose Bite, Claw, Horn, Hoof, Slam, Tail, Talon, Construct Strike, Puppet Blade, Spiritual Lash, Weapon Body, or another form explicitly named by the Source Rule.

## Attack Ability

Choose Strength or Dexterity. Use the chosen modifier for its attack and damage rolls. The choice is fixed unless the Archetype or body is rebuilt.

## Attack Roll

`d20 + your Proficiency Bonus + chosen ability modifier`

## Reach and Range

Default reach: 5 feet.

A ranged Companion Strike requires an explicit Source Rule. Record its normal and long range. A visual projectile does not create a ranged attack without that entry.

## Damage Type

Choose Bludgeoning, Piercing, or Slashing. Another damage type requires a Source Rule or Evolution.

## Damage Scaling

| Companion CL | Companion Strike Damage |
|---:|---:|
| 1–4 | `1d8 + chosen modifier` |
| 5–10 | `2d8 + chosen modifier` |
| 11–16 | `3d8 + chosen modifier` |
| 17–20 | `4d8 + chosen modifier` |

A Companion Strike is one attack. An effect that triggers once per turn from a hit can trigger only once on the companion’s turn unless it says otherwise.

## Weapon-Shaped Companions

A weapon spirit, animated weapon, puppet blade, or armed construct may describe the Companion Strike as a weapon attack. It still uses this profile unless a Source Rule grants a separate weapon profile.

The companion does not gain the cultivator’s weapon Spheres, talents, Masteries, Recorded Arts, Forged Techniques, or item properties merely because its strike resembles a weapon.

---

# 8. Initiative, Turn, and Commands

## Initiative

The companion acts on your initiative, immediately after your turn. It has its own movement, action, and Reaction, but no Bonus Action unless a Source Rule grants one.

If several linked companions are legally present, their granting rule states their order and command economy. Otherwise they act in an order you choose when initiative begins and retain that order for the scene.

## Default Behavior

If you issue no command, the companion:

- may move to remain within 5 feet of you or remain in its current space; and
- takes the Dodge action.

It does not automatically Attack, Help, Hide, Search, activate an item, use a Nature Expression, or spend CP.

## Commanding the Companion

As a **Bonus Action**, issue one command. Choose one action:

- Attack;
- Dash;
- Disengage;
- Dodge;
- Help;
- Hide;
- Search;
- Use an Object, if physically capable;
- Grapple or Shove, if physically capable;
- use one action printed in its profile;
- use one legal Nature Expression or companion technique under its printed timing.

The companion executes the command on its turn. It may move before or after the action.

If you take the Attack action and can make more than one attack, you may replace one attack with the command instead of using your Bonus Action. This does not let the companion act before your turn ends; it still executes the command on its turn.

A command remains only for the current turn unless it is a movement route, guard location, follow instruction, or another continuing non-action directive.

## Command Range

Default Bond Range: 120 feet on the same plane or spiritual layer.

Within range, commands and simple intent pass through the bond. Outside range, the companion follows its last continuing directive and otherwise uses its Incapacitated Directive.

A Source Rule can extend range, cross planes, use a vessel, shrine, mark, or Anchor, or permit independent action.

## Incapacitated Directive

When the companion is first recorded, choose one directive:

1. **Guard:** remain near you, Dodge, and attack only a creature that damages or Grapples you.
2. **Rescue:** attempt to stabilize you, move you toward safety, or seek a named ally or refuge.
3. **Continue Objective:** continue one precisely recorded scene objective, then retreat.
4. **Withdraw:** Disengage or Dash toward a recorded safe location and avoid unnecessary combat.

If you are Incapacitated or unable to communicate, the companion follows that directive. The GM resolves hostile effects and uncertain terrain, but does not replace the directive with a new personality decision during combat.

## Independent Will

A feature that grants Independent Will changes the default behavior. It does not create a second initiative count, extra Reaction, or additional CP pool.

## Opportunity Attacks

The companion can make Opportunity Attacks with its Companion Strike unless its body or Source Rule prevents them.

---

# 9. Spirit Nature Expressions and Companion Techniques

## Full Companion and Spirit Nature

A full spirit companion can possess Nature Expressions from the Sphere of Spirit Companions. The combat body and Nature are separate records.

The companion does not gain a Nature Expression merely because its description suggests one. Every expression must be granted, purchased, unlocked, or recorded.

## Expression Action Economy

For a spirit without a full companion body, the Sphere’s manifestation rules resolve the expression directly.

For a full Bonded Companion:

- the user spends the Action, Bonus Action, Reaction, CP, Offering, or other cost printed by the Nature Expression;
- the companion uses the corresponding legal action, Reaction, or strike replacement on its turn or at the printed trigger;
- if the expression is commanded as an Action or Bonus Action and does not expressly say it is a rider, it replaces the companion’s normal action that turn;
- the companion may still move unless the expression says otherwise;
- it cannot Attack and use a separate major Nature Expression in the same turn unless a rule expressly permits both;
- an expression that replaces one Companion Strike can coexist with Twin Assault only for the replaced strike.

## CP and Other Costs

The default player-character model uses the cultivator’s Path CP pool.

A companion has no independent CP pool unless a Source Rule grants one and records:

- maximum pool;
- recovery method;
- eligible expenditures;
- whether it can also spend the cultivator’s CP.

A cost cannot be silently paid twice or shifted to a different resource. Bond Strain, Offerings, Hit Dice, Hit Points, temporary maximum reductions, and CP are distinct costs.

## Concentration

The character and companion do not share a Concentration slot merely by being bonded. Each creature can Concentrate only if a Source Rule allows it to initiate a Concentration effect.

A Nature Expression paid and activated by the cultivator normally uses the cultivator’s Concentration, even when it originates from the companion. An independently activated companion effect uses the companion’s Concentration.

The complete expression record must state which creature Concentrates.

## No Technique Duplication

A companion cannot activate the cultivator’s unrelated Path features, Subpath features, Insights, Spheres, Methods, Foundations, Recorded Arts, Forged Techniques, Immortal Arts, or item powers unless a Source Rule explicitly grants that interface.

---

# 10. Movement, Mounting, and Position

## Space and Passage

The companion occupies its space. It does not provide Cover, block line of effect, permit flanking, or allow passage through hostile spaces beyond ordinary size rules unless a Source Rule says so.

## Mounting

A companion with suitable anatomy can carry a rider if it is at least one size larger than the rider and has sufficient carrying capacity.

The companion retains its initiative immediately after yours. Mounting does not merge turns or grant additional movement on your turn.

While mounted:

- you move with the companion when it moves;
- forced movement affecting either creature uses ordinary mounted-separation rules;
- the companion still requires commands;
- if commanded to Attack, it may Attack normally;
- the rider does not gain the companion’s senses, resistances, movement permissions, or immunity unless a Source Rule grants them.

## Carrying Other Creatures

The companion can carry additional willing creatures only within its carrying capacity and anatomy. Flight, phasing, teleportation, burrowing, planar travel, or incorporeal movement does not automatically carry passengers. The movement Source Rule must permit passengers.

## Teleportation and Legal Destinations

A companion teleport must specify:

- distance;
- perception requirement;
- whether total cover matters;
- whether it can carry a rider;
- whether it crosses barriers, planes, Domains, seals, or spiritual layers;
- what occurs when no legal destination exists.

Unless stated otherwise, a teleport requires an unoccupied space the companion can see and cannot carry another creature.

---

# 11. Healing, Rests, and Cultivation Recovery

## Ordinary Healing

An Embodied living companion can receive ordinary healing normally.

A spirit manifestation, construct, puppet, undead companion, animated object, or other unusual form receives ordinary healing only when its Continuity Model says so. Otherwise use repair, Offering, Life, Medicine, Puppetry, Blacksmith, spirit reconstruction, or another explicit Source Rule that states it can restore that Continuity Model.

A healing effect never restores a destroyed Complete Soul, consumed spiritual core, erased pattern, or permanently severed Bond unless it expressly grants that authority.

## Short Rest

During a Short Rest, a companion may spend its Hit Dice normally if its Continuity Model permits rest-based recovery.

A construct, puppet, or manifestation may require repair work, materials, an Offering, or a vessel instead. Record the substitution.

## Long Rest

At the end of a Long Rest, an eligible companion regains all missing Hit Points and half its expended Hit Dice, rounded down, minimum one Hit Die if any were expended.

This is bodily recovery, not resurrection, reconstruction, Bond repair, soul restoration, or removal of Spirit Scars.

## Full Cultivation Session

During a compatible Full Cultivation Session, the cultivator and companion may perform one recorded companion maintenance procedure, such as:

- repair a construct or puppet;
- feed, cleanse, or stabilize a spirit;
- reform a dispersed manifestation;
- restore all expended Hit Dice;
- clear one Bond Shock created by a Realm Evolution;
- renegotiate one minor relationship term if both parties consent;
- restore a broken nonpermanent Nature Expression or companion technique.

The procedure does not remove permanent damage, restore a dead companion, erase Bond Strain, or rebuild a destroyed Anchor unless another rule says so.

---

# 12. Continuity Models and 0 Hit Points

Choose one Continuity Model when the companion is created. A Source Rule may provide a special model.

## Embodied Living Companion

Examples: beast, awakened animal, spirit beast with a persistent body, living plant, biological hybrid.

At 0 Hit Points:

- it falls Unconscious;
- it makes death saving throws;
- ordinary stabilization and healing can affect it;
- death leaves a corpse or bodily remnant unless another rule says otherwise.

## Manifested Spirit Companion

The combat body is a manifestation. The Complete Spirit remains in a recorded Anchor, vessel, shrine, inner world, distant body, or unbodied state.

At 0 Hit Points:

- the manifestation disperses immediately;
- it makes no death saving throws;
- the Complete Spirit is not automatically destroyed;
- all effects requiring the manifestation’s space end;
- the spirit cannot manifest through this profile again until the cultivator completes a Full Cultivation Session or performs the recorded Major Offering;
- if Bond Strain applies, increase it by 1 unless the destruction fulfilled the spirit’s Nature or a Source Rule says otherwise.

Damage that explicitly reaches the Complete Soul, Spiritual Anchor, or true body can bypass this protection.

## Constructed or Vessel-Bound Companion

Examples: living doll, puppet, animated armor, construct, sentient weapon body, corpse puppet, spirit vessel.

At 0 Hit Points:

- the body becomes broken or inert;
- it makes no death saving throws unless the Source Rule gives it a living soul-bearing body;
- ordinary healing does not repair it;
- repair requires the recorded craft, materials, time, and surviving core or pattern;
- a Hosted spirit is expelled, trapped, or remains dormant as its Hosting record states.

## Hosted Projection

The companion’s combat body is projected from or through a Host.

At 0 Hit Points:

- the projection collapses into the Host;
- the Host takes damage equal to the companion’s Companion CL, of the type printed by the Source Rule or Psychic if none is printed;
- the projection cannot reappear until a Full Cultivation Session clears the collapse;
- the Complete Spirit or intelligence remains unless the Host, Anchor, or soul was separately harmed.

## Independent Body with Linked Bond

The companion is a separate embodied creature whose body and soul are both present.

At 0 Hit Points, use Embodied Living Companion unless its creature type has a more specific death procedure.

## Changing Continuity Model

A temporary transformation does not change Continuity Model unless the feature says so.

A permanent change requires a Source Rule or reconstruction project that records the new body, healing compatibility, 0-HP result, remnant, and restoration procedure.

---

# 13. Death, Destruction, and Restoration

## Death Matters but Does Not Automatically Erase a Build

A full Bonded Companion is a major character investment. Ordinary death or body destruction should create cost, time, vulnerability, and narrative consequence without permanently invalidating the character unless a higher-authority effect expressly destroys the required continuity.

## Restoration Rite

A dead or destroyed companion can be restored when all of the following are true:

- its Complete Soul, animating intelligence, core pattern, or equivalent continuity survives;
- the Source Rule that killed or destroyed it does not prohibit this restoration;
- the required remnant or spiritual trace remains;
- the rite’s Source CL is sufficient under Realm disparity;
- the correct craft, spiritual, medical, or ritual method is used.

**Time:** 8 uninterrupted hours.

**Cost:** Materials worth `50 gp-equivalent × Companion CL`, or the campaign’s equivalent value in spirit stones, rare herbs, beast cores, incense, metals, talisman stock, ritual offerings, or reconstruction components.

**Additional requirement:** One personal token, bodily remnant, surviving core, true-name trace, Soul Anchor contact, vessel fragment, bloodline sample, memory imprint, or another continuity key recorded on the companion profile.

At the end of the rite:

- an embodied companion returns with 1 Hit Point;
- a manifestation becomes available and reforms with 1 Hit Point;
- a construct or puppet is rebuilt with 1 Hit Point;
- a Hosted projection becomes available with 1 Hit Point;
- Bond Strain and permanent injuries remain.

The rite does not repair a destroyed Spiritual Anchor, consumed core, erased pattern, completed reincarnation, unwilling soul, or Complete Soul destruction.

## Restoration Source CL

Use the Source CL of the restoring feature, ritual leader, item, shrine, Formation, or specialist procedure.

- **6+ lower than the destructive effect:** cannot restore without satisfying the destructive effect’s named weakness or recovery condition.
- **3–5 lower:** restoration requires the named weakness or one additional higher-grade material and a successful Cultivation Check against the destructive effect’s DC.
- **within 2:** use the printed rite and any required check.
- **3+ higher:** ordinary non-Secret barriers are overcome unless they state otherwise.

If no DC exists, use `10 + destructive Source CL ÷ 2`, rounded down, plus 5 for a permanent effect.

## Permanent Loss

The default rite fails when:

- the Complete Soul was destroyed;
- the animating core or pattern was consumed beyond reconstruction;
- the companion completed reincarnation and will not return;
- a Secret, artifact, divine, Immortal, or world-law effect states that this restoration cannot reach it;
- the surviving being refuses restoration;
- the required Bond, true name, vessel, or continuity key was permanently severed and no Source Rule repairs it.

Permanent loss does not automatically grant a replacement companion. The granting Source Rule states whether a new bond can be formed and what project, training, inheritance, or story procedure is required.

---

# 14. Realm Evolutions

A Linked Bonded Companion gains one Evolution at CL5, CL10, CL15, and CL20.

At each threshold:

- gain the automatic threshold benefit;
- choose one Evolution from that Realm’s list for which the companion qualifies.

An Evolution is a cultivated transformation, not a rest-selected mode. It cannot be exchanged through an ordinary rest. A new selection requires an explicit rule, Realm breakthrough reconstruction, or 30-day cultivation project.

A Source Rule may provide a unique Evolution list. If so, use that list instead of or in addition to these options as stated.

---

# 15. Foundation Evolution — CL5

## Automatic Benefit: Cultivated Attacks

The companion’s Companion Strike counts as a cultivated attack and can affect creatures and objects protected from ordinary noncultivated attacks.

This does not grant a Sphere, elemental damage, weapon Mastery, or higher authority than its Source CL.

Choose one Foundation Evolution.

## Armored Hide

Increase AC by 1.

## Coordinated Assault

Once per round, when you damage a creature and the companion can perceive it, the companion gains Advantage on its next Companion Strike against that creature before the end of its next turn.

## Enlarged Frame

The companion becomes Large if its form and environment permit it.

It gains Advantage on Strength checks and on saving throws against being forcibly moved or knocked Prone.

It does not gain reach, damage, carrying passengers, or additional space-control authority beyond ordinary size rules.

## Keen Hunter

The companion gains proficiency in Perception and Survival. If already proficient, choose one of them to gain Expertise.

It also gains Advantage on checks to follow a creature whose scent, spiritual trace, blood, tracks, or other legal trail it has perceived during the current scene.

## Nature Resistance

Choose Acid, Cold, Fire, Lightning, Necrotic, Poison, Psychic, Radiant, or Thunder. The choice must be supported by one recorded creature origin, body material, Nature Tag, Nature Sphere, or Source Rule.

The companion gains Resistance to that damage type.

## Exalted Movement

Choose one movement expression supported by the companion’s recorded anatomy, creature origin, Nature Tag, or Source Rule:

- climbing Speed equal to walking Speed;
- swimming Speed equal to walking Speed and the ability to breathe water;
- 30-foot flying Speed, without Hover;
- 15-foot burrowing Speed through loose earth, sand, snow, or another recorded medium;
- ignore noncultivated difficult terrain from one recorded terrain family.

Flight requires anatomy or supernatural transformation that can be perceived and countered normally. Burrowing does not pass through worked stone, metal, wards, or solid cultivated barriers.

## Bearer Form

The companion counts as one size larger for carrying capacity and can safely carry one rider of an eligible size without reducing Speed.

When it Dashes while carrying that rider, it ignores the first 10 feet of noncultivated difficult terrain each turn.

---

# 16. Core Evolution — CL10

Choose one Core Evolution.

## Twin Assault

When commanded to Attack, the companion makes two Companion Strikes.

An effect limited to once per turn can apply to only one strike. A Nature Expression that replaces one strike replaces only one of them.

## Interposing Bond

**Action Type:** Reaction  
**Trigger:** You or the companion takes damage while within 30 feet of the other.  
**Cost:** 2 CP from the cultivator  
**Limit:** Once per round

Reduce the damage by `2d8 + your Proficiency Bonus`.

The reacting participant must be conscious, able to perceive the other through the bond, and not behind a barrier that blocks the bond. This reduction occurs after Resistance and before damage is applied unless another rule states otherwise.

## Elemental or Spiritual Fang

Choose Acid, Cold, Fire, Force, Lightning, Necrotic, Poison, Psychic, Radiant, or Thunder. The choice must be supported by one recorded creature origin, body material, Nature Tag, Nature Sphere, or Source Rule.

Once per turn when the companion hits with a Companion Strike, it deals an additional `1d8` damage of the chosen type.

## Greater Movement

Improve one movement mode the companion possesses:

- walking, climbing, or swimming Speed increases by 20 feet;
- flying Speed increases to 60 feet;
- burrowing Speed increases to 30 feet and can pass through ordinary packed earth;
- a terrain-glide mode ignores cultivated difficult terrain of Source CL at least 3 lower than the companion.

This Evolution does not grant planar travel, phasing through solid barriers, or passenger carriage unless the base movement permits it.

## Spirit Speech

The companion can speak the languages it understands. Its Intelligence score increases to at least 10.

It can reason about immediate and long-term matters appropriate to its personhood. This does not grant hidden knowledge or skill proficiencies.

## Titanic Build

Prerequisite: Large size.

The companion counts as one size larger for carrying capacity, Grappling, Shoving, Overrun, and resisting forced movement. Its occupied space and reach do not change.

## Shared Guard

While you and the companion are within 5 feet of each other, either participant can use its Reaction when the other is targeted by an attack.

Grant the protected participant +2 AC against that attack, potentially causing it to miss.

Alternatively, when one participant takes damage, the other can use its Reaction to move up to 5 feet toward it without provoking Opportunity Attacks.

Shared Guard grants no additional Reaction and can be used only once per round between both participants.

## Nature Channel

Prerequisite: a recorded Spirit Nature Expression, Beast Nature technique, construct module, or equivalent companion technique.

Choose one eligible expression whose normal action is an Action. Once per turn when the companion takes the Attack action, it may replace one Companion Strike with that expression, paying every normal cost.

The expression must target one creature or one point and cannot create a Domain, summon another full companion, or perform a ritual unless its Source Rule specifically permits this replacement.

---

# 17. Nascent Evolution — CL15

Choose one Nascent Evolution.

## Independent Will

The companion no longer requires your Bonus Action to take the Attack action.

If you issue no command, it may move and take the Attack action instead of Dodge, following its recorded objectives and Refusal Triggers.

You may still command it to take a different action. Independent Will does not grant an additional action, turn, or CP pool.

## Regeneration

At the start of its turn, if it has at least 1 Hit Point and is not affected by a Source Rule that stops regeneration, the companion regains Hit Points equal to your Proficiency Bonus.

A damage type, injury, severance, starvation state, broken core, or spiritual condition suppresses this regeneration only if its Source Rule says so.

## Greater Elemental or Spiritual Fang

Prerequisite: Elemental or Spiritual Fang.

The additional damage becomes `2d8`, and the companion gains Resistance to the chosen damage type.

## Soul Bond

**Action Type:** Reaction  
**Trigger:** You or the companion would be reduced to 0 Hit Points while within 30 feet of the other.  
**Cost:** 5 CP from the cultivator  
**Limit:** Once per scene and only while no Bond Shock is present

The target is reduced to 1 Hit Point instead. Both participants gain **Bond Shock**.

While Bond Shock remains:

- Soul Bond cannot be used again;
- neither participant can voluntarily suppress, dismiss, or transfer the Bond to avoid the state;
- the companion’s Regeneration, if any, does not function.

Clear Bond Shock through one compatible Full Cultivation Session completed by both participants. Bond Shock is not Exhaustion, a curse, or Bond Strain, though the same event may create those separately.

## Vast Form

The companion may become Huge if its form and environment permit it.

It gains 20 maximum Hit Points and Advantage on checks and saves against Grapple, Shove, Overrun, forced movement, and being knocked Prone.

It gains no automatic reach increase beyond ordinary size rules and cannot enter a space that cannot contain it.

## Phase Step

Once per turn, the companion may spend 10 feet of movement to teleport up to 30 feet to an unoccupied space it can see.

It cannot carry another creature through Phase Step unless a Source Rule permits it. It cannot cross a planar boundary, sealed Domain, ward, or barrier that blocks teleportation.

## Deep Companion Sense

While on the same plane or spiritual layer, you and the companion know each other’s direction, approximate distance, current Hit Point band (unhurt, above half, half or lower, 0), and whether the other is Charmed, Frightened, possessed, Unconscious, or under hostile spiritual restraint.

As an Action, either participant can allow the other to perceive through one of its senses until the start of the allowing participant’s next turn. The receiving participant is Blind and Deaf to its own surroundings during that interval.

## Shared Cultivation Circuit

Once per round when either participant spends CP on a feature that directly targets, originates from, protects, moves, heals, commands, or transforms the other, reduce that CP cost by 1, minimum 1.

This cannot reduce a cost paid by an item, independent spirit pool, Formation reserve, or third creature, and cannot apply to the same activation more than once.

---

# 18. Immortal Evolution — CL20

Choose one Immortal Evolution.

## Immortal Companion

The companion ceases aging and no longer requires ordinary food, water, or air unless its recorded Nature requires a supernatural sustenance.

At the start of its turn, if it has at least 1 Hit Point, it regains 10 Hit Points. A Source Rule of equal or higher authority that stops Immortal restoration suppresses this benefit.

## Heaven-Devouring Maw

**Action Type:** Action  
**Cost:** 10 CP from the cultivator  
**Limit:** Once per scene

The companion makes one Companion Strike. On a hit, the target makes a Constitution saving throw against the cultivator’s Cultivation Save DC.

- **Failure:** The target takes `8d10` Force damage. The companion regains Hit Points equal to half the Force damage actually dealt.
- **Success:** The target takes half damage, and the companion regains no Hit Points.

This is one activation and does not combine with Twin Assault. It cannot consume a Complete Soul, Foundation, Soul Anchor, Domain, or Cultivation Asset unless another Source Rule expressly grants that authority.

## Domain Companion

**Action Type:** Bonus Action  
**Cost:** 10 CP  
**Duration:** 1 minute  
**Concentration:** The cultivator  
**Limit:** Once per scene

The companion emits a 20-foot Companion Domain that moves with it. Choose one expression when this Evolution is gained:

1. hostile creatures treat the area as difficult terrain;
2. allies gain +1 AC;
3. hostile creatures have Disadvantage on saves against Frightened effects created by the companion or cultivator;
4. allies gain Resistance to one damage type chosen when the Evolution is gained;
5. the first hostile creature each round that enters or starts there cannot take Reactions until the start of its next turn.

The Domain uses the companion’s Source CL. It collides with other Domains under the universal Domain procedure. It grants no unprinted environmental destruction, conceptual law, spirit command, or movement barrier.

## Mythic Flight

The companion gains a 90-foot flying Speed and can Hover.

If its size and carrying capacity permit, it can carry up to five willing Medium or smaller creatures. Passengers occupy its space for travel but must enter legal adjacent spaces when combat begins unless the GM has mapped a vehicle-scale space.

Mythic Flight does not cross planes, ignore sealed airspace, or pass through barriers.

## Rebirth Cycle

When the companion dies or its combat body is destroyed, it reforms after 1 minute in an unoccupied space within 30 feet of you with half its maximum Hit Points.

After it reforms, Rebirth Cycle becomes unavailable for 30 days.

The 30-day interval is a metaphysical reconstruction cycle, not a rest counter. It cannot be shortened by ordinary rests. A compatible Immortal reconstruction project may shorten it as expressly permitted.

Rebirth fails if the companion’s Complete Soul, animating core, essential pattern, or named continuity was destroyed, consumed, sealed beyond reach, or prevented from returning by equal or higher authority.

## Wisdom of the Ancient Companion

Increase the companion’s Intelligence, Wisdom, and Charisma scores to at least 16.

It becomes fully Sapient, can speak the languages it understands, and develops its own long-term goals, cultivation desires, and relationship terms.

Record one personal objective, one boundary it will not cross, and one way its relationship can be renegotiated. The player controls its combat decisions within those records; the GM portrays its independent interests outside direct tactical execution.

This Evolution does not grant a Path, Sphere, CP pool, or independent NPC turn.

## World-Bearing Form

The companion can assume a travel form one size larger than its current maximum size for up to one scene. Entering or leaving the form requires an Action and 5 CP.

While in this form:

- carrying capacity is multiplied by 10;
- it can carry up to ten willing Medium creatures if anatomy permits;
- its Speed cannot be reduced below 30 feet by ordinary encumbrance;
- it gains Advantage on checks and saves against forced movement;
- it cannot use Companion Strike or Grapple creatures smaller than Huge unless a Source Rule says otherwise.

The form is for mythic conveyance and battlefield presence, not free area damage.

---

# 19. Realm Suppression

For a Linked companion, Realm Suppression of the cultivator changes the bond-provided combat expression.

While the cultivator is suppressed:

- use the suppressed Proficiency Bonus for companion attacks, AC, trained skills, and bond-provided DCs;
- use the Companion Strike damage available at the suppressed CL;
- Evolutions whose minimum CL exceeds the suppressed CL become dormant;
- a movement mode, size, language, personhood, or permanent body change granted by a dormant Evolution remains only when it is an independent embodied quality rather than an actively sustained cultivation expression;
- any active Evolution whose minimum CL exceeds the suppressed CL ends; that Evolution remains unavailable until the suppression permits it again;
- companion maximum Hit Points, Hit Dice, existing body, personality, memory, ordinary anatomy, independent Soul, and native relationships do not shrink or vanish;
- expended CP, Bond Shock, Bond Strain, injuries, severances, destroyed vessels, and restoration obligations remain.

If the companion has an independent native CL and profile, suppressing the cultivator does not suppress the companion’s independent cultivation unless the bond Source Rule says it does. The companion still loses bond-provided benefits above the suppressed level.

Realm Suppression cannot be used to dismiss a companion into safety after an attack, erase a Refusal Trigger, cancel Bond Shock, avoid restoration cost, or create a second lower-level Evolution choice.

---

# 20. Companion Injuries, Transformation, and Equipment

## Injuries

Ordinary damage reduces Hit Points. Lingering injury, Hidden Injury, severed anatomy, damaged meridians, broken cores, destroyed vessels, Spirit Scars, and permanent cultivation harm require explicit Source Rules.

The injury record must state:

- affected body, spirit, core, vessel, or bond;
- Source CL;
- mechanical penalty;
- whether ordinary healing functions;
- repair method and minimum authority;
- whether the companion can manifest or use Evolutions while injured.

## Transformation

A temporary transformation uses the printed duration and returns the companion to its recorded profile when it ends.

A permanent transformation must update:

- size and space;
- ability scores if changed;
- movement modes;
- equipment compatibility;
- Continuity Model;
- Companion Strike form;
- personhood and communication;
- Source CL or Nature changes;
- restoration procedure.

No transformation grants an extra Evolution unless stated.

## Equipment

A companion can wear or wield equipment only when its anatomy and Source Rule permit it.

- Barding or armor replaces the normal AC formula if better; it does not stack by default.
- A wielded weapon can cosmetically define Companion Strike or use a separate printed profile.
- Attunement uses the companion’s own attunement capacity only if a Source Rule grants it. Otherwise companion items use the cultivator’s normal item limits when the item is maintained through the bond.
- Destroying equipment does not automatically injure the companion unless it is a vessel, body part, Anchor, or Hosted structure.

---

# 21. Noncombat Companions and Lesser Allies

A noncombat companion:

- does not automatically scale with CL;
- does not gain this chapter’s AC, Hit Points, attack, turn, or Realm Evolutions;
- does not normally Attack;
- may scout, carry messages, provide narrative communication, occupy a vessel, or use a specifically granted utility effect;
- may use Help only when its Source Rule permits it and it can meaningfully perform the task;
- does not count against the full Bonded Companion limit unless upgraded.

A temporary summoned creature, Beast Ally, Minor Spirit Agreement, court of lesser spirits, pack, swarm, puppet troop, or Formation servant uses its own profile. It cannot be treated as several full companions to obtain multiple turns or Evolutions.

## Upgrading a Lesser Ally

A Source Rule that upgrades a lesser ally must state:

- which individual becomes the full companion;
- what happens to prior statistics;
- the Archetype and Continuity Model;
- whether prior injuries and relationship terms remain;
- how the one-companion limit is handled.

---

# 22. Spirit Companion Overlay

A spirit upgraded into a full Bonded Companion uses the following overlay in addition to this chapter.

## Required Spirit Entries

- Spirit origin category.
- Complete Spirit or Soul Fragment status.
- Spirit Nature and Nature Tags.
- Native Source CL, if distinct.
- Embodiment state.
- Bond Mode.
- Need and sustenance cadence.
- Minor and Major Offerings.
- Taboo and Refusal Triggers.
- Bond Strain triggers and finite crisis procedure.
- Nature Expressions and their exact action economy.
- manifestation, dismissal, recall, Host, vessel, shrine, and Anchor rules.
- what destruction of the combat body means for the Complete Spirit.
- exorcism, possession, seal, release, and reconstruction interactions.

## Full Companion Is Not Ownership

Upgrading a spirit grants a combat profile. It does not:

- erase personhood;
- transfer the spirit’s Spheres to the cultivator;
- remove Offerings, Taboos, Need, or consent;
- make every command legal;
- permit soul destruction, permanent binding, Hosting, possession, or true-name control;
- make the spirit a removable Intruder when it is willing or ancestrally integrated.

## Nature Expression and Companion Strike

Companion Strike belongs to the combat chassis. Nature Expressions belong to the spirit’s Nature.

A Nature Expression does not automatically improve Companion Strike, and Companion Strike does not grant a Nature Sphere talent. A talent can explicitly connect them.

## Manifestation Continuity

A spirit whose Complete Soul remains elsewhere normally uses the Manifested Spirit Continuity Model. A spirit beast with a persistent body normally uses Embodied Living Companion. A weapon spirit or shrine spirit may use Constructed/Vessel-Bound or Hosted Projection.

The record must choose; the table does not decide after the companion reaches 0 Hit Points.

---

# 23. GM and AI Adjudication Contract

A GM or AI may adjudicate consequences within the printed records. It may not invent a missing mechanical permission.

## The GM May Decide

- whether terrain physically accommodates the companion;
- whether ordinary anatomy can manipulate an object;
- whether a narrative Offering has actually been delivered;
- the reactions and motives of independent NPCs;
- consequences explicitly delegated by a table or finite option list;
- encounter difficulty created by a higher-CL independent ally.

## The GM Must Not Invent During Resolution

- a new attack or Nature Expression;
- a second turn or CP pool;
- an unrecorded immunity, movement mode, passenger rule, refusal trigger, Taboo, or crisis;
- an “appropriate” resource cost;
- an alternate resurrection quest when the restoration rule gives a result;
- a hidden companion Archetype benefit;
- a free Sphere, talent, Evolution, item property, or spell analogue;
- automatic obedience from higher Source CL.

## AI Character Generation Requirements

A generated full Bonded Companion must include:

- complete identity and source;
- Archetype and ability scores;
- AC, Hit Points, Speed, saves, skills, senses, languages;
- Companion Strike;
- command and range;
- Continuity Model;
- 0-HP, recovery, and restoration procedures;
- every selected Realm Evolution;
- Source CL and Realm Suppression handling;
- if a spirit, the complete Spirit Companion Overlay.

If any required field is absent, the character package must flag the companion as incomplete rather than synthesize an ability from flavor.

---

# 24. Publication and Compatibility Notes

This R2 chassis intentionally retains the strongest useful structure from the legacy Bonded Companions chapter:

- one full companion by default;
- three Archetypes;
- linked CL progression;
- a single command economy;
- Companion Strike scaling;
- automatic Realm thresholds with selectable Evolutions;
- restoration that protects a major character investment.

It modernizes that structure by:

- removing general saving throw proficiencies;
- separating combat statistics from relationship and Spirit Nature rules;
- replacing ordinary per-rest Evolution buttons with CP, trigger, scene, cultivation-procedure, or metaphysical-cycle limits;
- defining Continuity Models before 0 Hit Points occur;
- defining full-companion Nature Expression action economy;
- adding Source CL, Realm Suppression, permanent harm, passenger, transformation, and AI data requirements;
- preventing Bonds, Hosting, spirits, summons, Assets, and trained creatures from silently becoming extra combat turns.
