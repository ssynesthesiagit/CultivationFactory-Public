# Tianxia Spirit Awakening — Tradition Procedure Addendum R7

**Status:** Complete integrated candidate through all 34 normalized traditions.  
**Purpose:** Shared execution rules invoked by Spirit Awakening traditions. This document grants no ability by itself.  
**Mechanical state:** Consolidation and terminology repair only; no intentional power reduction.

## 1. Rule Order

1. A specific normalized tradition feature.
2. Spirit Awakening Core R2A.
3. Spirit Awakening Rules Reference R3.
4. This Procedure Addendum R6.
5. Universal core rules.

A specific feature overrides this Addendum only where it states the exception.

## 2. Authority DC When No DC Is Printed

When a procedure requires a Cultivation Check against an effect that has Source CL but no save DC, use:

`Authority DC = 10 + opposing Source CL's Proficiency Bonus + opposing source's key ability modifier`

If the opposing source has no key ability modifier, use `10 + opposing Source CL's Proficiency Bonus + 3`. Source CL comparison never removes a printed save, check, Anchor, repeated save, cost, or recovery route.

## General Execution Closure

### Legal Destinations
Movement and teleportation require an unoccupied space the target can occupy. A destination cannot be inside total solid matter or a known immediately lethal hazard unless the feature explicitly permits that hazard. If no legal destination exists, movement fails without changing the target's position.


### Fixed Consequence Principle
When a normalized feature refers to a table, record, or ordered list, the result comes from that printed procedure. A GM or AI may describe its fiction but cannot increase its numerical severity or add an unprinted condition, cost, enemy, permanent injury, or loss.


### Source CL
Where no specific DC is printed, use the Rules Reference fallback Authority DC. Compare Source CL before a Cultivation Check. Realm Suppression removes access to features above effective CL but does not erase already-created debts, scars, relationships, or identity records unless their own rules say so.


## 3. Qualifying or Meaningful Event

A feature that requires meaningful danger, opposition, service, or cost qualifies when at least one is true:

- a nonallied creature took a hostile action or forced a save, condition, damage, movement, or resource expenditure;
- an uncontrolled hazard threatens Hit Points, Cultivation Points, a condition, an Asset, an Anchor, a relationship, or the scene objective;
- a check is opposed or has DC at least `10 + Proficiency Bonus` and failure changes access, time, resources, safety, or information;
- a participant actually pays Hit Points, a Hit Die, a Reaction, a condition, Exhaustion, Resonance, another Cultivation Point, a limited Asset, or a recorded obligation.

Harmless damage, willing attacks, staged failures, allied summons, captive targets, repeated unchanged checks, refunded costs, and self-created loops do not qualify. One activation or event grants a given buildup resource no more than once unless the feature expressly says otherwise.

## 4. Lineage Covenant Record

An Ancestral Channeler records:

- lineage name and basis of membership;
- at least three Lineage Knowledge Domains;
- one Need or Duty;
- one Taboo;
- one ordinary restitution;
- one severe restitution;
- one higher-ranked Duty, if any;
- the Ritual Proficiency selected for the Ritualist Office.

### Standard Duties
Protect descendants or adopted successors; maintain graves or archives; preserve a craft or office; answer a recognized summons; transmit a named teaching; mediate a named recurring dispute.

### Standard Taboos
Knowingly destroy a protected grave or archive; deny lawful burial to a recognized member; impersonate an ancestor for personal gain; use a willing ancestor as expendable fuel; betray a protected successor to an enemy; erase accepted lineage membership.

### Restitution
**Ordinary:** one hour of repair, burial work, archive restoration, public acknowledgment, or service to an affected member.  
**Severe:** one Full Cultivation Session at the lineage Anchor plus return or reconstruction of what was harmed, or fulfillment of a specific higher-ranked Duty.

## 5. Shrine Covenant and Kami Petition

A Miko records the shrine or kami's Spirit Nature, jurisdiction, Taboo, one Taboo Consequence, one Restitution, Descent Movement, and Offering appearance.

### Kami Petition Price
The CL14 Petition feature already pays 4 Resonance and 1 Offering. The kami may ask exactly one additional price:

1. one additional Offering consumed after the service;
2. 10 minutes of cleaning, prayer, or repair at a relevant site;
3. delivery of a Tiny object or 25-word message through an ordinary legal route;
4. observance of one recorded Taboo until the end of the next scene;
5. public apology or correction of a specific recent disrespect;
6. one hour of environmental or funerary service within the kami's jurisdiction.

The kami states the price before acceptance. Declining returns the 4 Resonance and Offering because the petition never forms. After acceptance, failure to pay is a Taboo violation only if the recorded covenant says so.

### Standard Restitution
Replace or cleanse a profaned Offering; spend one hour repairing or cleaning the relevant shrine or environment; complete one requested service from the Petition Price list; or secure forgiveness through a willing covenant renegotiation.

## 6. Guest Seat and Hosted Trait Records

A Mudang Guest Seat is a tradition expression, not automatically a separate Complete Spirit. Record its appearance, voice, Nature, Taboo, and one Guest Restitution when first used in a scene.

A real hosted spirit must also possess a Complete Spirit Record under the Rules Reference. Hosted Trait qualification is based only on printed or perceived traits. The normalized Mudang entry contains the complete template list.

## 7. Yokai Need, Taboo, and Bargain Record

A Yokai Channeler records the lineage, Tell, Need, Taboo, selected Skill, damage affinity, and current seven-day Need deadline. The normalized tradition provides exact restitution routes.

Every Yokai Bargain records:

- both parties;
- exact exchange;
- completion condition;
- duration;
- Declared or Open Claim mode;
- witnesses, if any;
- whether a controlled threshold permission is included.

A bargain cannot create a penalty outside the printed Claim menu.

## 8. Death Residue, Custody, and Grave Debt

A Soul Fragment record contains: source; source category; Consensual, Unclaimed, or Coerced custody; creation scene; expiration; known memories or impressions; legal route; and any preserving vessel.

### Custody Grades
- **Residue Custody:** one Soul Fragment only.
- **Death Custody:** departing residue held until the scene ends by the CL14 feature.
- **Final Custody:** one qualifying Complete Soul held only inside the CL18 Warden-Wraith until that activation ends.
- **Long-Term Custody:** requires a separate legal prison, vessel, underworld office, or Spiritual Anchor Source Rule.

No lower custody grade silently becomes a higher one.

### Complete Soul and Fragment
A fragment cannot answer for the Complete Soul, make decisions for it, authorize resurrection, grant its character statistics, or prove guilt. Destruction of a fragment does not destroy the Complete Soul unless a specific Source Rule explicitly identifies them as the same object.

## 9. Vow Mark Consent Record

A Heartbinder records: both participants; consent form; what relationship or promise the mark represents; any act explicitly defined as Repudiation; creation time; and any advance ending instruction.

Consent must be informed and revocable. A Vow Mark cannot be used as proof of love, legal status, innocence, ownership, or permanent loyalty. The normalized Heartbinder entry contains the ending, repudiation, scar, damage-transfer, and Soul Splitting procedures.

## 10. Assets, Origins, and Action Economy

A tradition Asset has only the statistics and expressions printed in its entry. Unless expressly designated a full companion, it has no independent turn, companion evolutions, equipment slots, Sphere access, or personal Cultivation Point pool.

Moving an Asset or using it as an origin does not create a second activation. One feature activation has one origin unless it expressly lists multiple origins. Soul Splitting can change or add an allowed origin only through the printed Subpath Expression.

## 11. Realm Suppression

Relationships, ancestry, recorded Debt, Taboos, vows, ancestor membership, and spirit personhood are not erased by Realm Suppression. A feature above effective CL cannot activate. An active transformation, Domain augmentation, or scene Asset above effective CL becomes dormant or ends as its feature states. Dormancy never counts as destruction and does not by itself harm an underlying spirit.

## 12. GM and AI Determinism Contract

The GM or AI may portray a spirit's voice, omen, appearance, cultural form, and honest knowledge. It may not during resolution invent:

- a new cost, counter, Taboo, restitution, Hosted Trait, bargain penalty, custody power, Vow restriction, or Asset action;
- a harsher consequence than the printed table;
- knowledge the spirit did not possess;
- ownership or consent merely because a mark or bond exists;
- a second turn or duplicated activation for an Asset.

If a required record was not completed before it matters, use the first compatible default in the relevant printed list and record it immediately. Do not choose a custom option that disadvantages the player.

## 13. Dream States, Threads, Scars, and Reconstruction

### Dream-Confrontation
A Dream Thread is challenged during a Short Rest or Long Rest by spending at least 10 uninterrupted minutes in sleep, meditation, guided lucid dreaming, or spiritual treatment. An ordinary Nightmare Scar is challenged during a Long Rest in a spiritually safe place or during a Full Cultivation Session that includes the same treatment. The affected creature chooses Wisdom or Charisma and makes the printed save. One attempt is permitted during the qualifying rest or session unless a separate Source Rule permits more.

### Dreamless Target
A target is dreamless only when its Source Rule says it has no sleep consciousness, symbolic inner life, or coherent dream state. Ordinary sleep immunity, Construct type, Undead type, or low Intelligence does not automatically establish dreamlessness.

### Witnessed Reconstruction
To reconstruct missing memory, hope, confidence, or identity content, gather three independent supports from different categories: a firsthand witness; a written, visual, or spiritual record; a Soul Anchor relationship; a preserved dream or Echo; a repeated lived practice; or the released original content. After at least 1 hour of work, the subject makes the required save or a specialist makes the required Cultivation Check. Repeating three copies of the same source is one support, not three.

## 14. Sovereign Authority and Restitution

A command or edict uses only the printed list or an exact ordinary-language equivalent. It cannot force a target to supply unknown information, activate a feature it cannot legally activate, or pay an unprinted cost. Court Tax and Tyranny Restitution use the exact procedures printed in the normalized Sovereign Will entry.

## 15. Spiritual Truesight

Spiritual Truesight is a line-of-effect spiritual sense, not universal visual Truesight. It reveals broad spiritual truth, manifestations, possession links, soul displacement, transformations, and illusions within range. It does not see through total cover, reveal mundane secrets without spiritual expression, or defeat equal-or-higher concealment without a contest.

## 16. Qualifying Radiance and Vacant Halo

Qualifying radiance must be a supernatural invested protection, blessing, ward, benediction, sanctified enhancement, oath-backed defense, shrine protection, divine favor, or artifact safeguard. Ordinary healing and mundane defense do not qualify unless their Source Rule spiritualizes them. Vacant-Halo Tax uses only the eligible printed resources listed in the normalized Halo Eater entry.

## 17. Witness, Contradiction, and Evidence

A Witness Note records one finite subject, notation, and event. It does not make a claim true by fiat. Contradiction requires knowing incompatibility from the subject's current perspective. Witness evidence preserves the fact and source of an extraordinary witnessed event, not every precise detail. Protected information remains protected unless a Source Rule explicitly defeats it.

## 18. Mercy Scars and Burden Custody

Mercy Scars, Flayed Burden Anchors, White Mercy Scars, and White Room Anchors are custody structures. They do not erase the original Source Rule or transform a Complete Soul, permanent injury, destroyed system, Secret effect, divine judgment, or artifact consequence into an ordinary removable condition. Treatment, escape, and restoration use the finite procedures printed in the normalized Mercy Flayer entry.

## 19. Additional GM and AI Determinism Contract

For the traditions added in R2, the GM or AI may not invent:

- an extra dream recovery requirement, protected-memory exception, or undefined quest;
- a Court Tax resource, sovereign restitution, Retainer memory, or office power outside the record;
- a new meaning for Spiritual Truesight;
- a qualifying radiance category, Halo cost, or blessing expression not supported by the Source Rule;
- a witnessed contradiction, preserved fact, confession detail, or Eye action beyond the printed procedure;
- a Mercy Scar consequence, escaped burden, Lasting Mercy, or White-Mercy restoration outside the finite lists.

When a required record was omitted, use the first compatible default and record it immediately. Do not select a custom default that disadvantages the player.

## Batch 3 Shared Modules

### Identity and Transformation Records
A transformation record states anatomy, movement, occupied spaces, equipment treatment, additional attacks if any, Source CL, duration, and recovery. Cosmetic anatomy supplies no unprinted action, equipment slot, or natural weapon.

### Fate Liabilities
Counter-Omens, Named Echoes, and Severed Thread Consequences use fixed menus. They must be recorded at creation. They cannot be retroactively intensified.

### Death Delay
A delayed death or execution consequence records its source and original resolution. Only an intervention that invalidates that source changes the result. Delay is not resurrection, soul reconstruction, or universal immunity.

### Threshold Routes
Each route records origin, destination, legal occupancy, passengers, Anchors, and Source CL. Unwilling movement preserves its save or contest.

### Relationship Hierarchy
Ties are classified as Duty, Pursuit, Possession or Control, Oath or Contract, Kinship or Lineage, Attachment, Summoning or Creation, or Custody. A relation must have a current permission, obligation, benefit, cost, or behavioral expression.

### Compelled Action
A compelled attack uses the target's normal statistics and cannot spend CP, limited charges, ammunition it lacks, or an unprinted action. Harmless choreography cannot create damage, known hazards, forced disclosure, or limited-resource expenditure.

### Emotional Harm
Emotion categories are fear, grief, rage, guilt, love, emptiness, despair, relief, shame, longing, and numbness. Emotional treatment does not automatically restore physical injury, Complete Soul destruction, a Method, Foundation, or unrelated curse.

## Tradition-Specific Modules

The complete procedures for Molt Integration, Permanent Seraphic Signs, Counter-Omens, Named Echoes, Severed Thread Consequences, Sustaining Categories, Borrowed Final Breath, Threshold qualification, relationship change, harmless choreography, Burden Scars, and Soul Splitting expressions are printed in their respective normalized tradition files. Those procedures are incorporated here by reference and remain printed in the Tradition Compendium R7.

## Batch 4 Shared Modules

### Reflection Correspondence
A reflection must record surface, subject, clarity, and continuity. It supplies only the correspondence expressly used by the feature and never creates unrestricted remote access or duplication.

### Organic and Dream Networks
Mycelial Nodes, Rootline routes, dream participants, residue questions, and Memory Mushrooms use explicit records. A corpse medium is not animated and a spirit or soul is not captured by implication.

### Recorded Evidence
Echo Entries record exact facts or impressions, source, time, location, authority, and confidence. Records are evidence rather than automatic legal, true-name, or metaphysical truth. Current events become settled through the printed event-settlement procedure.

### Grave and Burial Authority
Gravebeats require a current objective-changing death interaction. Forced marches use the Safest Available Path. Battlefield finishing follows the explicit ordinary-creature and lethal-scene criteria; it never silently claims soul custody.

### Temporal Records
Time Debt, Temporal Arrears, Deferred Consequences, Hourglass Marks, and Round Images use exact state records. Temporal authority delays or restores only printed data and does not invent a stronger consequence.

### Soulwake Routes
A Soulwake is an ordered sequence of spaces actually crossed. Passage, exchanges, pursuit, extraction, and Domain current use legal-destination and route-collision rules.

### Witness Attribution
Notice denial changes attribution rather than visibility or history. Each affected observer uses a Witness record. False sources must be plausible existing or feature-created points and cannot frame an unrelated creature.

## Batch 4 Soul Splitting Expressions

- Mirror Speaker — **Reverse Witness**
- Mushroom Dreamwalker — **Hyphal Dreamlet**
- Echo Scribe — **Footnote Witness**
- Thrum of the Grave — **Afterbeat Shade**
- Well of Hours — retains **Yesterday's Witness** and **Hold This Breath**
- Black Current Walker — retains **Tributary**
- Unwritten Footprint — retains **False Author**

The complete procedures remain printed in the respective integrated tradition entries.

## Batch 5 Shared Modules

### Conceptual Martial Strike
A **Martial Strike** is one of the following when a feature permits it:

- one unarmed strike;
- one attack with a weapon the practitioner is proficient with;
- Mind Spike, only when the feature expressly permits it.

A granted Martial Strike is one attack or one use of Mind Spike, not the Attack action. It cannot grant Extra Attack, Weapon Mastery, a Sphere, a talent, another Path, a second Reaction, or another activation. Choose the delivery before rolling. A weapon or unarmed attack applies its added effect on a hit. Mind Spike applies the added effect on a failed save; successful-save handling is the exact handling printed by the feature.

### Martial Anti-Recursion
An attack, Mind Spike, movement, or counter granted by one normalized martial tradition cannot activate another feature that grants an attack or independent activation unless the later feature expressly permits that combination. Once-per-turn riders remain once per turn across the practitioner, Soul Fragment, echoes, reactions, and Domain expressions.

### Legal Martial Movement
Spiritual steps, conceptual translations, and relation movement require legal unoccupied destinations. They cannot cross total solid matter, an unknown sealed destination, a prohibited planar boundary, or a Source Rule that wins the authority contest. Forced movement cannot place a creature in an obviously immediately lethal hazard unless the feature expressly permits it and the target receives every printed save.

### Echo Positions and Pursuit
Echo Positions are recorded attack origins, not bodies, objects, duplicates, routes, or flank providers. Pursuit Marks are special Resonance Marks with finite removal procedures. Multi-origin techniques declare sequence and targets before resolution.

### Near and Far Relations
Near and Far are recorded relations, not physical tethers or unrestricted line of effect. Far-Sided movement, delayed activations, Constellation designations, and Secret prices use the exact procedures in Law of Near and Far.

### Poles and Bearings
A Pole and each declared Bearing use start-of-turn reference records. A stored token represents completed voluntary movement and cannot be generated through staged, forced, or harmless loops. “Substantially larger” for normalized martial movement means at least two size categories larger.

### Measures and Debts
Measures record one fully resolved qualifying hostile activation. Debts record the first qualifying activation by an aggressor each round in Court of Equal Heaven. Any Hand May Answer resolves globally once per turn across the Domain.

### Declarations and Credence
Open Declarations use exact subject and completion records. Break’s meaningful-damage threshold is Proficiency Bonus Hit Points after mitigation, a forced Concentration or maintenance check, a printed break threshold, or reduction to 0 Hit Points. The Witness Stone is a stationary external Domain Anchor with the complete profile in Plain-Truth Fist.

### Handspan and Contact
A Handspan designation grants only the spiritual-contact permissions printed by Last-Inch Palm. It does not create physical adjacency or general remote bodily force. Contact Cannot Be Stolen is tracked once per hostile source per round. Sanctuary defers only a recorded contact-dependent portion.

## Batch 5 Soul Splitting Expressions

- Echo-Step Disciple — **Second Stance**
- Law of Near and Far — **Near Twin**
- Compass-Breaking Hand — **Counter-Needle**
- Equal Measure Scripture — **Second Pan**
- Plain-Truth Fist — **Witness to the Word**
- Last-Inch Palm — **Second Palm**

The complete procedures remain printed in the respective integrated tradition entries.

## Complete Soul Splitting Expression Index

| # | Tradition | Expression |
|---:|---|---|
| 1 | Dreamweaver | Dream Double |
| 2 | Sovereign Will | Twin Heralds |
| 3 | Exorcist | Seal Warden |
| 4 | Ancestral Channeler | Fourth Voice |
| 5 | Miko | Procession of Two Worlds |
| 6 | Mudang | Second Drum |
| 7 | Inner Soul-Gate Ascetic | Gate Mirror |
| 8 | Yokai Channeler | Masked Twin |
| 9 | Dream Eater | Mouth Behind Sleep |
| 10 | Soul Warden / Necromancer | Twin Custody |
| 11 | Halo Eater | Hungry Reflection |
| 12 | Choir of the Unopened Eye | Second Witness |
| 13 | Mercy Flayer | Burden-Bearing Double |
| 14 | Seraphic Molter | Shed-Wing Witness |
| 15 | Fate Reader | Forked Omen |
| 16 | Candlemaker | Funeral Ember |
| 17 | Boundary Walker | Threshold Shade |
| 18 | Knot Weaver | Loose-End Double |
| 19 | Soulstring Dancer | Second Dancer |
| 20 | Grief Eater | Mourning Attendant |
| 21 | Mirror Speaker | Reverse Witness |
| 22 | Mushroom Dreamwalker | Hyphal Dreamlet |
| 23 | Echo Scribe | Footnote Witness |
| 24 | Heartbinder | Second Heartbeat |
| 25 | Thrum of the Grave | Afterbeat Shade |
| 26 | Well of Hours | Yesterday’s Witness; Hold This Breath |
| 27 | Black Current Walker | Tributary |
| 28 | Unwritten Footprint | False Author |
| 29 | Echo-Step Disciple | Second Stance |
| 30 | Law of Near and Far | Near Twin |
| 31 | Compass-Breaking Hand | Counter-Needle |
| 32 | Equal Measure Scripture | Second Pan |
| 33 | Plain-Truth Fist | Witness to the Word |
| 34 | Last-Inch Palm | Second Palm |
