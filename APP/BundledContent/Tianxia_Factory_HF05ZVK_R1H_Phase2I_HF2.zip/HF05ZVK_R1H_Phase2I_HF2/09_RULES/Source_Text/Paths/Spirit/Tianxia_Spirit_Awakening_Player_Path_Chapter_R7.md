# Tianxia Spirit Awakening — Player Path Chapter R7

**Publication state:** Player-facing organization of Spirit Awakening Core R2A.  
**Mechanical state:** No intentional mechanical changes from Core R2A.  
**PHB state:** Source-ready only. This volume has not yet been inserted into the Player's Handbook.  
**Companion volumes:** *Spirit Awakening Player General Procedures R7*, *Spirit Awakening Tradition Compendium R7*, the central Cultivation Insight catalogue, and the universal Bonded Companions chassis when a legal feature grants a full companion.

## How to Use This Chapter

This volume contains the Spirit Awakening CL1–20 chassis, Resonance, Soul Anchors, Resonance Marks, Spiritual Pressure, Soul Vessel, Spiritual Exorcism, Domain Manifestation, Soul Splitting, Immortal Spirit, and the Path's relationship to independent spirits.

At CL3, select one Spirit Awakening tradition from the companion compendium. At CL4, CL8, CL12, CL16, and CL19, choose an Ability Score Improvement or a legal Cultivation Insight from the **central** Insight catalogue. Spirit Awakening does not maintain a separate Insight authority.

Use *Player General Procedures R7* when a feature involves souls, spirits, Hosting, possession, exorcism, banishment, spiritual harm, memory, identity, dreams, Bonds, manifestations, vessels, Anchors, spiritual Domains, or reconstruction. Exceptional authority collisions and GM-only adjudication belong to the *Spirit Awakening GM Authority Appendix R7*.

## Publication Rule Hierarchy

1. The explicit Source Rule creating or modifying the effect.
2. This Spirit Awakening core.
3. Spirit Awakening Player General Procedures R7 for ordinary player-facing procedures.
4. The individual tradition entry and Tradition Procedure Addendum R7.
5. The Universal Bonded Companions Combat Chassis R2 and Sphere of Spirit Companions when expressly invoked.
6. Universal Tianxia cultivation rules.
7. Ordinary fifth-edition resolution rules where Tianxia has not replaced them.

A thematic resemblance never grants an unprinted ability, companion, possession permission, soul authority, or additional action.

## Publication Boundary

This chapter is organized now so that Spirit Awakening can be audited independently. Final PHB insertion waits until Body Refining reaches publication parity and Qi Cultivation, Body Refining, and Spirit Awakening complete the three-Path harmonization audit.

---

> *The body can be broken. Qi can be emptied. The awakened soul remembers the hand that reached for it—and reaches back.*

Spirit Awakening is the rarest, most personal, and least institutionally trusted of Tianxia’s three orthodox Paths. A Spirit Awakener refines identity, memory, emotion, dream, spiritual perception, relationships, and the authority of the soul until inner truth can impress itself upon the world.

A Body Refiner makes the body itself into supernatural law. A Qi Cultivator builds repeatable systems of meridians, treasures, weapons, formations, and external power. A Spirit Awakener cultivates the self that persists beneath flesh and technique: the name that remembers, the grief that will not fade, the vow that holds, the dream that opens, the ancestor who answers, and the Domain in which the cultivator’s spiritual truth becomes locally real.

Spirit Awakening is not inherently benevolent, pacifistic, incorporeal, companion-focused, or nonmartial. Spirit Awakeners may be exorcists, mediums, shrine guardians, spirit companions, dream hunters, sovereigns, oath keepers, soul physicians, ancestor channelers, martial conceptualists, mirror walkers, grief eaters, necromancers, or practitioners of Secret Laws. What unifies them is the ability to perceive, preserve, negotiate with, and impose spiritual identity.

**Status.** This is the controlled R2A dependency-sealed core candidate. It supersedes Spirit Awakening Core R1 and Core R2 wherever they conflict. The Spirit Awakening Rules Reference R3 and Universal Bonded Companions Combat Chassis R2 dependencies are now sealed for Subpath repair and playtesting. Final PHB canon still depends on Subpath normalization, central Insight modernization, publication organization, and the three-Path harmonization audit.

---

# Canonical Rule Order

Resolve Spirit Awakening rules in this order:

1. The explicit Source Rule creating or modifying the effect.
2. This Spirit Awakening core.
3. **Tianxia Spirit Awakening Rules Reference R3** for recurring spiritual definitions and procedures.
4. The **Universal Bonded Companions Combat Chassis R2** when a Source Rule grants a full combat-capable companion.
5. The **Sphere of Spirit Companions** for Spirit Nature, Bonds, Hosting, Binding Seals, Offerings, Taboos, Bond Strain, and Nature Expressions.
6. Universal Tianxia cultivation rules, including Scene, Realm, Cultivation Points, Soul Anchors, Cultivation Assets, Anchors, Methods, Foundations, Recorded Arts, Forged Techniques, Hidden Injuries, permanent cultivation harm, reconstruction, and Realm Suppression.
7. The underlying fifth-edition resolution procedure where Tianxia has not replaced it.

A specific Source Rule overrides a general rule only to the extent it expressly states. Similar imagery, a conventional spell comparison, a spirit’s reputation, a martial description, or a technique’s name never grants unprinted authority.

This core grants no permission to possess, bind, create, destroy, reconstruct, command, or transform a spirit unless a feature expressly grants that permission.

---

# Spirit Awakening at a Glance

| Rule | Spirit Awakening |
|---|---|
| **Key Ability** | Wisdom |
| **Hit Die** | d8 |
| **Cultivation Points** | Resonance |
| **Primary Roles** | Spiritual perception, soul authority, mental and emotional pressure, exorcism, restoration, control, ritual work, spirit relations, martial conceptual practice, and Domain authority |
| **Saving Throw Proficiencies** | None |
| **Armor Training** | None |
| **Weapon Training** | Simple weapons |
| **Skills** | Choose two: Deception, Insight, Investigation, Medicine, Perception, Persuasion, Religion |

Spirit Awakening grants no saving throw proficiencies. Its spiritual defenses are active cultivation features rather than passive proficiency.

You do not gain armor or shield training from this Path. If another legal source grants armor, shield, martial weapon, or unarmed-combat training, using it does not inhibit Spirit Awakening unless an explicit Source Rule says otherwise.

## Cultivation Math

**Cultivation Save DC**  
`8 + Proficiency Bonus + Wisdom modifier`

**Cultivation Attack Modifier**  
`Proficiency Bonus + Wisdom modifier`

**Cultivation Check**  
`d20 + Proficiency Bonus + Wisdom modifier`

## Activation, Spirit Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, spirit expression, or other Source Rule, including every target, pulse, echo, rider, and repeated effect that use expressly creates.

A **Spirit Awakening technique** is a supernatural procedure authorized by a Spirit Awakening Source Rule. It is not automatically a spell, weapon attack, condition, curse, possession, Sphere talent, companion action, or ordinary ability check. The Source Rule states the resolution procedure it uses.

A Spirit Awakening technique requires Concentration only when its Source Rule says so. Use the normal Concentration limit and ending conditions unless an explicit cultivation rule changes them.

An echo, Soul Fragment, Companion, manifestation, vessel, Resonance Mark, Domain, relation, or conceptual state does not create a second activation, second turn, second Concentration slot, or additional resource pool unless its Source Rule expressly says it does.

## Effective CL and Source CL

Your normal effective CL is your Spirit Awakening CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature.

**Source CL** determines the authority of a spiritual effect. It does not replace a printed attack roll, saving throw, Cultivation Check, Anchor, cost, repeated save, recovery procedure, or reconstruction requirement.

---

# Resonance

Resonance is the cultivated force of an awakened soul: clarity, pressure, identity, memory weight, dream depth, emotional coherence, ancestral continuity, spiritual authority, and the capacity to remain oneself while touching another spirit.

## Maximum Resonance

`Spirit Awakening CL × Wisdom modifier`

Your maximum Resonance cannot be lower than:

`2 × Spirit Awakening CL`

Only a Method or another explicit Source Rule can alter this maximum.

## Recovering Resonance

| Recovery Method | Resonance Recovered | Limit |
|---|---:|---|
| **Short Rest** | Resonance equal to your Spirit Awakening CL | Once per long rest |
| **Long Rest** | Half your maximum Resonance | No additional limit |
| **Full Cultivation Session** | All missing Resonance | Once per long rest |

Round fractions down.

A Full Cultivation Session requires 2 uninterrupted hours, a reasonably safe spiritual environment, and a practice capable of restoring coherence. Examples include meditation, dream-trance, prayer, ancestor-listening, confession, emotional integration, shrine attendance, ritual music, spirit communion, soul inspection, or another practice suitable to the cultivator’s Method and Soul Anchor. It may occur during an eligible meditative long rest.

A hostile spirit, damaged Anchor, violated Taboo, Bond Crisis, active possession, or spiritual prison can prevent a particular recovery practice only when its Source Rule says how. The GM does not reduce recovery merely because the cultivator’s emotions are narratively unsettled.

## Reaching 0 Resonance

When you are reduced from more than 0 Resonance to exactly 0 Resonance, gain 1 level of Exhaustion.

Repeatedly reaching 0 Resonance can add further Exhaustion under the universal Cultivation Point rules. A feature that temporarily reduces maximum Resonance does not itself count as reaching 0 unless current Resonance is actually reduced to 0.

---

# Soul Anchors

Every Spirit Awakener has a **Soul Anchor** under the universal Soul Anchor rules. It describes what keeps the awakened self coherent: a true name, vow, ancestor, grief, dream, mask, mirror, companion spirit, shrine, debt, lost home, forbidden memory, heart demon, unfinished death, or another defining spiritual root.

At CL1, record:

- the Anchor’s name or description;
- whether it is primarily internal, relational, locational, embodied, object-linked, or vow-linked;
- one way the cultivator normally communes with it during a Full Cultivation Session;
- any separate physical vessel, relationship, or location that represents it.

These entries describe the Anchor. They do not create a destructible object, Companion, Cultivation Asset, immunity, weakness, or additional ability unless another Source Rule says so.

Path interactions:

- Your Soul Anchor is a legal focus for Spirit Awakening techniques when a Source Rule permits a spiritual focus.
- A Soul Anchor is not automatically a physical object and cannot be attacked unless a Source Rule gives it an external manifestation or Anchor profile.
- A Strained Soul Anchor does not erase your Path features, but it can prevent an expressly printed Anchor Invocation and can affect techniques that explicitly depend on it.
- Ordinary damage cannot destroy a Soul Anchor.
- Severing, rewriting, consuming, or permanently replacing a Soul Anchor requires an explicit high-authority Source Rule and an explicit recovery or reconstruction procedure.
- Realm Suppression does not remove the existence of a Soul Anchor, though it can suppress higher-CL expressions that depend on it.

A Spirit Companion, ancestor, shrine, object, relationship, or vow used as a Soul Anchor is not automatically a full Companion, Cultivation Asset, or destructible Spiritual Anchor. Those statuses require separate rules.

---

# Resonance Marks

Spirit Awakeners leave impressions upon the soul.

A **Resonance Mark** may appear as a bruise upon the spirit, a remembered name, red thread, scent of incense, pulse in a mirror, echo, dream symbol, prayer syllable, pressure point, or another Path- or Subpath-appropriate sign.

Unless a Source Rule states otherwise:

- A Resonance Mark lasts until the end of your next turn.
- A creature can bear only one Resonance Mark from you at a time.
- Reapplying your mark refreshes its duration.
- Marks from different Spirit Awakeners can coexist.
- A Resonance Mark is not a condition, curse, Charm, possession, Spirit Bond, Sphere talent, or Soul Fragment.
- The mark is invisible to ordinary sight.
- While the marked creature is within 60 feet, you know that your mark remains, but not automatically its precise space if it is hidden.
- A mark does not by itself reveal thoughts, identity, location, statistics, memories, or the text of a Source Rule.
- If the marked creature enters an effect that blocks spiritual perception or has a stronger concealment Source Rule, the mark can become hidden or suppressed.

A concealed mark can be contested with a Cultivation Check against the concealment effect’s save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

A Resonance Mark never gives permission to target through total cover or total spiritual concealment unless another Source Rule expressly says so.

---

# Spiritual Pressure

**Spiritual Pressure** is short-lived soul authority. It is not automatically fear, Charm, possession, physical restraint, or a permanent alteration.

When a feature tells you to impose ordinary Spiritual Pressure, choose one option unless the feature provides its own pressure effect:

1. **Heavy Soul:** The target’s Speed is reduced by 10 feet.
2. **Stilled Intent:** The target cannot take Reactions.
3. **Shaken Purpose:** The target has Disadvantage on the next attack roll it makes.
4. **Opened Spirit:** The target has Disadvantage on the next Intelligence, Wisdom, or Charisma saving throw it makes against one of your Spirit Awakening features.
5. **Repelled Heart:** The target cannot willingly move closer to you.
6. **Revealed Disturbance:** You learn the target’s surface emotional state and whether it is affected by ordinary possession, a spiritual curse, dream intrusion, memory interference, spiritual contamination, or one of your Resonance Marks.

Unless stated otherwise, the pressure lasts until the start of your next turn.

A creature can suffer only one ordinary Spiritual Pressure effect from you at a time. Reapplying pressure replaces or refreshes your previous choice; it does not stack multiple ordinary options. A feature that expressly creates a two-option or broader pressure package is one exceptional package and does not authorize other pressure stacking.

Immunity to Charmed or Frightened does not grant immunity to Spiritual Pressure unless the pressure expressly imposes that condition. A creature without a mind, soul, animating spirit, or equivalent spiritual identity may be immune when the Source Rule cannot logically affect it.

---

# Spirit Awakening Progression

| CL | Features |
|---:|---|
| 1 | Soul Anchor, Soulward Response, Spiritual Sense, Mind Spike |
| 2 | Soul Gaze |
| 3 | Spirit Awakening Subpath |
| 4 | Ability Score Improvement or Cultivation Insight |
| 5 | Domain Pressure |
| 6 | Subpath Feature |
| 7 | Astral Projection |
| 8 | Ability Score Improvement or Cultivation Insight |
| 9 | Soul Vessel |
| 10 | Subpath Feature |
| 11 | Soul Armor |
| 12 | Ability Score Improvement or Cultivation Insight |
| 13 | Spiritual Exorcism |
| 14 | Subpath Feature |
| 15 | Domain Manifestation |
| 16 | Ability Score Improvement or Cultivation Insight |
| 17 | Soul Splitting |
| 18 | Subpath Feature |
| 19 | Ability Score Improvement or Cultivation Insight |
| 20 | Immortal Spirit |

## Ability Score Improvement or Cultivation Insight

At CL4, CL8, CL12, CL16, and CL19, choose one:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight from the central Tianxia catalogue for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight’s **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, shrine, spirit pact, bloodline awakening, reincarnated memory, office, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise.

Background ability increases and Origin Insights are separate benefits.

If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

Use the **Central Cultivation Insights** player catalogue and AI reference. An inherited entry flagged for cadence, determinism, or authority repair is not automatically publication-final merely because it appears in the central ledger.

---

# Spirit Awakening Subpaths

At CL3, choose one Spirit Awakening Subpath for which you have legal access. You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Classification | Meaning |
|---|---|
| **Open Tradition** | Teachable through a recognized school, shrine, profession, community, military office, or public scripture. Open access does not imply low power or common practitioners. |
| **Restricted Lineage or Scripture** | Requires a hidden teacher, guarded manual, shrine, sect, spirit pact, haunted location, initiation, profession, or controlled institution. |
| **Rare Inheritance** | Comes from bloodline, reincarnated memory, spirit ancestry, relic fusion, mutation, possession survived and integrated, divine scar, or singular transmission. |
| **Forbidden Method or Variant** | Uses condemned, coercive, predatory, destabilizing, politically prohibited, or spiritually hazardous practices. Forbidden is not automatically Daemonic. |
| **Secret Law** | Direct law-level authority requiring explicit discovery and its printed initiation price. |
| **Daemonic** | A mechanical tag only when a Source Rule interacts with Corruption, daemonic energy, purification, or anti-daemonic rules. Social accusation does not create this tag. |

A character normally has one Subpath progression. A future parent or Variant lineage uses its printed replacement procedure rather than granting a second simultaneous progression.

A Subpath does not grant general access to a thematically similar Sphere. A Dreamweaver does not automatically learn Dreams; a Mirror Speaker does not automatically learn Illusion or Space; an Ancestral Channeler does not automatically learn Spirit Companions or Death. Only an explicit Source Rule grants a Sphere or talent.

---

# CL1 — Soulward Response

**Action Type:** Reaction  
**Trigger:** You fail an Intelligence, Wisdom, or Charisma saving throw.  
**Cost:** 1 Resonance  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Soulward Response:

- is not saving throw proficiency;
- is used after you learn that the roll failed;
- cannot modify a death saving throw;
- cannot modify a breakthrough, training, forging, or ordinary ability check;
- cannot modify the same saving throw more than once;
- cannot stack with another feature that adds Proficiency Bonus to the same saving throw;
- does not automatically end an ongoing effect unless the successful-save result says it does.

At CL11, Soul Armor improves this response.

---

# CL1 — Spiritual Sense

Spiritual Sense is always active unless suppressed.

## Range

| CL | Range |
|---:|---:|
| 1–10 | 10 feet |
| 11–16 | 30 feet |
| 17–20 | 60 feet |

Within range, you perceive active souls, spirits, possessing entities, projected souls, spiritually animated corpses, and creatures with ordinary living consciousness even when normal sight cannot perceive them.

Against an ordinary living creature, Complete Soul, or spirit within range, Spiritual Sense functions as Blindsight. It does not automatically perceive:

- soulless traps or objects;
- mundane writing, color, or visual detail;
- a construct with no mind, spirit, or animating soul;
- a corpse with no active spirit or necromantic animation;
- a creature behind total cover;
- a successfully concealed soul, Secret concealment, divine veil, artifact-level masking, sealed spirit, or stronger spiritual absence.

Spiritual Sense also tells you whether a perceived entity is broadly:

- Embodied, Manifested, Hosted, possessing, projected, Unbodied, Anchored, or Contained;
- Resonance Marked by you;
- under an obvious ordinary possession, coercive Hosting, or spirit-manifestation effect.

It does not reveal exact statistics, thoughts, memories, Soul Anchor, Spirit Nature, Subpath, full Bond terms, or hidden Source Rules.

## Read the Spirit

**Action Type:** Action  
**Range:** Your Spiritual Sense range

Choose one soul, spirit, possession link, spiritual residue, Soul Fragment, or spiritual effect you perceive. Learn:

- its broad category;
- whether its Source CL is lower than, equal to, or higher than yours;
- whether it is stable, strained, damaged, concealed, Hosted, bound, possessing, Anchored, or suppressed;
- whether it is a Complete Soul, Soul Fragment, Spiritual Imprint, or uncertain mixture.

For a concealed or protected effect, make a Cultivation Check against its save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

On failure, you know that spiritual concealment or interference is present, but not its exact nature. You cannot retry until the effect changes, you obtain a new Source Rule or evidence, or a new scene begins.

---

# CL1 — Mind Spike

**Action Type:** Action  
**Range:** 60 feet  
**Target:** One creature with a mind, soul, animating spirit, or equivalent spiritual identity

The target makes a Wisdom saving throw against your Cultivation Save DC.

**Failed Save:** The target takes Psychic damage equal to the listed dice plus your Wisdom modifier and becomes Resonance Marked by you.  
**Successful Save:** The target takes half damage and is not marked.

| CL | Psychic Damage |
|---:|---:|
| 1–4 | `1d8 + Wisdom modifier` |
| 5–10 | `2d8 + Wisdom modifier` |
| 11–16 | `3d8 + Wisdom modifier` |
| 17–20 | `4d8 + Wisdom modifier` |

Mind Spike is a Spirit Awakening technique and one activation regardless of how another feature later echoes, redirects, or originates it.

Mind Spike can affect a creature without a biological brain if it has a mind, soul, animating spirit, or equivalent identity. It normally cannot affect an ordinary object, mindless construct, spiritually empty corpse, or Spiritual Imprint that has no independent ability to suffer damage.

At CL5, when a creature already Resonance Marked by you fails against Mind Spike, you may also impose one ordinary Spiritual Pressure effect on it.

## Martial and Weapon Interface

Mind Spike is not an ordinary weapon attack, unarmed strike, spell, or Attack action. A weapon, unarmed strike, natural weapon, martial Subpath, Recorded Art, or Forged Technique can deliver or modify Mind Spike only when its Source Rule expressly says so.

A martial description does not grant Extra Attack, martial weapon proficiency, weapon delivery, physical damage, or permission to substitute an attack roll for Mind Spike’s Wisdom saving throw.

---

# CL2 — Soul Gaze

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one creature you can see. You may instead choose a creature Resonance Marked by you within range even if you cannot see it, provided it is not behind total spiritual concealment.

Learn:

- its current and maximum Hit Points;
- its broad creature nature and cultivation Path, if any;
- whether its effective CL or relevant Source CL is lower than, equal to, or higher than yours;
- its damage resistances, immunities, and vulnerabilities;
- its surface emotional state;
- whether it is affected by an ordinary curse, possession, coercive Hosting, Heart Demon, dream intrusion, memory interference, spiritual contamination, Spirit Scar, or obvious soul injury;
- the broad category of one Spirit Bond, possession link, or Spiritual Anchor currently sustaining an obvious effect upon it.

Soul Gaze does not automatically reveal:

- a protected Soul Anchor;
- a spirit’s complete Nature or Bond contract;
- Secret or divine identity;
- hidden phases or unrevealed transformations;
- exact unspent Cultivation Points;
- protected memories;
- the complete text of an unknown feature;
- a concealed effect whose Source Rule defeats ordinary spiritual diagnosis.

When protected information is contested, make a Cultivation Check against the protecting effect. On failure, identify which category of information was concealed, but not its contents. You cannot retry against the same concealment until it changes, you gain new evidence, or a new scene begins.

---

# CL5 — Domain Pressure

**Action Type:** Action  
**Area:** Cone originating from you  
**Cost:** 2 Resonance

| CL | Cone Length |
|---:|---:|
| 5–10 | 15 feet |
| 11–16 | 30 feet |
| 17–20 | 60 feet |

Release a wave of spiritual authority. Each creature of your choice in the area makes a Wisdom saving throw.

**Failed Save:** The creature is Frightened of you until the end of your next turn and becomes Resonance Marked by you.  
**Successful Save:** The creature suffers one ordinary Spiritual Pressure effect of your choice until the start of your next turn.

If a creature that fails is immune to Frightened, it is not Frightened. Instead, choose two different ordinary Spiritual Pressure effects for it. These two effects are one exceptional pressure package created by this feature and may coexist until the start of your next turn.

Domain Pressure is not a full spiritual Domain, does not establish ownership over the area, and does not create an Anchor, prison, anti-teleport effect, or companion-command zone.

---

# CL7 — Astral Projection

**Action Type:** Action  
**Cost:** 4 Resonance  
**Duration:** Up to 10 minutes  
**Concentration:** No

Project your spirit from your body.

## Body and Range

Your body becomes Unconscious and remains a living creature in its space. It can be moved, damaged, healed, restrained, protected, or killed normally. Your projected spirit can travel up to 300 feet from your body. At CL15, this range becomes 1 mile.

The projection ends if:

- you return to your body;
- you dismiss it without an action;
- the duration expires;
- your body takes damage;
- your projected spirit takes damage;
- your body dies;
- you become unable to maintain a coherent soul connection;
- body and projection are separated by a barrier that explicitly blocks or severs soul connection.

When the projection ends normally, it returns by the shortest legal spiritual route. If no legal route exists because a barrier traps it, the projection remains adjacent to that barrier and you are Incapacitated until the barrier is opened, overcome, or the connection is otherwise resolved.

## One Creature, Two Positions

Your body and projection are two positions of the same creature, not two creatures.

- You have one Hit Point total, one condition set, one turn, one action economy, and one Concentration limit.
- An activation cannot affect both positions as though they were separate targets.
- Damage to either position is damage to you and ends Astral Projection after that damage resolves.
- Healing either position heals you once.
- An effect attached to you remains attached unless its own rules require a body or a projected spirit.

## Projected Spirit

While projected:

- You retain your senses, Spiritual Sense, Read the Spirit, and Soul Gaze.
- You can communicate telepathically with a willing creature within 30 feet.
- You have a Fly Speed equal to your Speed and can hover.
- During a move, you can pass through creatures and up to 5 feet of nonmagical material, but cannot end inside a creature or object.
- Wards, Seals, Formations, consecrated boundaries, spirit prisons, Domains, and Source Rules that block astral travel can stop you.
- You are invisible to ordinary sight but visible to spiritual perception and spirit-revealing effects.
- You cannot manipulate ordinary physical objects.
- You cannot make attacks, activate hostile techniques, manifest a Domain, command a full Companion, use an item, or affect the physical world unless another Source Rule expressly permits it.

An effect that can target spirits can target your projection. Use your normal AC, Hit Points, saving throws, and defenses.

Astral Projection does not create a Soul Fragment, Companion, independent manifestation, second origin for a technique, or separately acting copy of you.

---

# CL9 — Soul Vessel

You can create a stable sympathetic vessel for one spiritual relationship.

## Create or Replace the Vessel

**Time:** 10 minutes  
**Cost:** 2 Resonance  
**Target:** One Tiny nonliving object you touch

The object becomes your **Soul Vessel**, a Spirit Cultivation Asset. It may be a doll, name tablet, folded paper figure, mirror shard, prayer strip, bead, thread knot, mask, bell, carved seal, weapon tassel, reliquary, or another object capable of carrying your spiritual imprint.

You can have only one Soul Vessel. Creating another causes the previous vessel to become an ordinary object and ends its Vessel Imprint.

When separate and legally targetable, the vessel has:

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `4 × Proficiency Bonus`.
- **Immunities:** Psychic and Poison damage; Charmed, Frightened, Poisoned, Prone, and ordinary bodily conditions.
- **Source CL:** Your effective Spirit Awakening CL.

While worn or carried, use the normal rules for targeting a worn or carried object. Reducing the vessel to 0 Hit Points destroys its cultivated structure, ends its imprint, and leaves an ordinary broken object. This does not damage your soul or the imprinted target.

## Create a Vessel Imprint

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Target:** One willing creature, or one creature Resonance Marked by you

An unwilling target makes a Charisma saving throw.

**Successful Save:** No Vessel Imprint is created. The target knows you attempted the link and suffers one ordinary Spiritual Pressure effect until the start of your next turn.  
**Failed Save or Willing Target:** The Soul Vessel records a sympathetic imprint of the target.

A Vessel Imprint is not a Soul Fragment, copied soul, possession link, ownership claim, memory copy, or Spirit Bond.

### Duration

- A willing target’s imprint persists until you dismiss it, replace it, the target withdraws consent as an Action, the vessel is destroyed, or a Source Rule severs it.
- An unwilling target’s imprint lasts until the end of the scene. The target can also use an Action to repeat the Charisma saving throw, ending the imprint on a success.

The vessel can hold only one imprint.

### Imprint Benefits

While the imprint persists:

- The target bears your Resonance Mark, and that mark does not expire from its ordinary duration.
- While target and vessel are on the same plane and within 1 mile, you know the direction from the vessel to the target, but not exact distance or a route through spiritual concealment.
- You can use Soul Gaze on the target from the vessel at a range of 1 mile without ordinary line of sight. Total spiritual concealment, a ward that severs sympathetic links, or a higher-authority boundary still blocks it.
- The imprint supplies identity and direction only. It does not let another feature ignore its own range, cover, target, consent, or Source CL requirements.

### Vessel Ward

**Action Type:** Reaction  
**Trigger:** A willing imprinted target within 60 feet of the vessel fails an Intelligence, Wisdom, or Charisma saving throw against a spiritual, mental, emotional, dream, memory, possession, or identity effect.  
**Cost:** 2 Resonance  
**Limit:** Once per round

Add your Proficiency Bonus to the saving throw, potentially turning failure into success.

Vessel Ward cannot modify a death saving throw, cannot add Proficiency Bonus twice, and cannot combine with Soulward Response on the same saving throw.

### Sympathetic Rite at CL13

After you gain Spiritual Exorcism, a willing imprinted target within 1 mile can be the target of your Deep Exorcism Rite without being touched. Increase the rite’s Resonance cost by 2. A barrier that blocks the Vessel Imprint also blocks the rite.

This remote rite cannot target an unwilling Host or Intruder, cannot establish a new possession target, and cannot exceed the normal authority of Spiritual Exorcism.

---

# CL11 — Soul Armor

Your cultivated identity hardens into spiritual armor.

You gain Resistance to Psychic damage.

Soulward Response gains these benefits:

- When it turns a failed saving throw into a success, you may end one ordinary Resonance Mark or ordinary Spiritual Pressure effect on yourself.
- If that successful saving throw would normally deal half Psychic damage, you instead take no Psychic damage.
- If the effect would Charm, Frighten, possess, displace, or rewrite your soul on a failed save and do nothing on a successful save, a successful Soulward Response prevents it normally.

In addition, when an effect attempts to read, alter, erase, copy, consume, imprison, or replace your memory, identity, Soul Anchor, or soul without granting a saving throw, you may use Soulward Response and make a Wisdom saving throw against the effect’s save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

On success, prevent an ordinary effect. Against an equal- or higher-authority effect, use its printed success result. If it has none, success suppresses the attempted alteration until the end of your next turn and exposes its broad Source CL and sustaining Anchor to Spiritual Sense; it does not automatically destroy the source.

---

# CL13 — Spiritual Exorcism

You can diagnose, suppress, separate, expel, cleanse, and release invasive spiritual effects. Spiritual Exorcism uses the terms and authority hierarchy in the Spirit Awakening Rules Reference.

An **Intrusion** for this feature can be:

- unwilling possession or coercive Hosting;
- dream intrusion;
- spiritual contamination;
- imposed emotional corruption;
- memory interference;
- hostile spirit presence;
- a Heart Demon expression that its Source Rule permits another creature to confront;
- a curse with a spiritual, dream, memory, emotion, identity, or soul component;
- a Charmed, Frightened, or madness effect created by a supernatural mental or spiritual source.

Spiritual Exorcism cannot treat integrated spirit ancestry, a legal Path or Subpath, a Foundation, Method, Origin Insight, ordinary memory, willing stable Bond, chosen oath, or accepted presence as an Intrusion unless its own Source Rule expressly permits separation.

## Exorcism DC

Make a Spirit Awakening Cultivation Check against the Intrusion’s save DC. If it has no printed DC, use the creator’s or sustaining spirit’s Cultivation Save DC. If neither is available, use:

| Source Realm | Authority DC |
|---|---:|
| Mortal | 12 |
| Foundation | 14 |
| Core Formation | 16 |
| Nascent Soul | 18 |
| Immortal | 20 |

## Battlefield Exorcism

**Action Type:** Action  
**Range:** 60 feet  
**Cost:** 4 Resonance  
**Target:** One perceived Intrusion attached to a creature, object, location, manifestation, vessel, or Spiritual Anchor

Make the Cultivation Check. A specific Intrusion can be targeted by your Battlefield Exorcism only once per round.

**Failed Check:** The Intrusion remains. If it permits a repeat saving throw, the affected creature immediately repeats that save with Advantage. You learn the Intrusion’s broad category, Source CL band relative to you, and whether it is sustained by a creature, Bond, vessel, location, or other Spiritual Anchor.

**Successful Check:** Compare the Intrusion’s Source CL with this feature’s Source CL.

| Intrusion Authority | Result |
|---|---|
| **6 or more Source CL lower** | End one ordinary temporary Intrusion. An ordinary possession is separated and locally expelled to its legal manifestation, vessel, or nearest legal space until the end of the scene. If it has no legal external state, it becomes a visible spiritual outline occupying the Host’s space without controlling the Host. A persistent, permanent, Secret, artifact, divine, or expressly Anchored Intrusion is instead suppressed until the end of the scene and reveals one printed release or reconstruction requirement. |
| **3–5 Source CL lower** | Suppress the Intrusion until the end of the scene without Concentration. The affected creature immediately repeats one save allowed by the Intrusion with Advantage; on a success, an ordinary temporary Intrusion ends. A possessing Intruder is exposed and cannot control the Host during suppression. |
| **Within 2 Source CL** | Suppress the Intrusion until the end of the affected creature’s next turn. It immediately repeats one save allowed by the Intrusion with Advantage. If it has no repeat save, suppression is the complete battlefield result. |
| **3 or more Source CL higher** | Do not suppress the Intrusion. The affected creature immediately repeats one save allowed by it with Advantage. Its manifestation, broad origin, and direction of its sustaining Anchor are exposed to Spiritual Sense until the end of your next turn. |

A willing Host may waive resistance made on its behalf. A willing Intruder does not resist separation. When Host and Intruder both oppose separation, use the higher relevant DC.

## Deep Exorcism Rite

**Time:** 10 minutes  
**Range:** Touch, or a willing Soul Vessel imprint as described by Soul Vessel  
**Cost:** 6 Resonance, plus 2 for a remote Soul Vessel rite  
**Target:** One perceived Intrusion or Spiritual Affliction

Make the Cultivation Check.

**Failed Check:** Do not remove or suppress the effect. Learn its broad category, exact Source CL band relative to you, sustaining Anchor category, and one printed condition required to meaningfully change it. You cannot repeat the rite against that effect until the effect changes, the revealed condition is met, or your effective Spirit Awakening CL increases.

**Successful Check:** Compare Source CL.

| Intrusion Authority | Result |
|---|---|
| **6 or more Source CL lower** | End one ordinary temporary or persistent Spiritual Affliction. Separate an ordinary possessing Intruder into its legal manifestation, vessel, or nearest legal space; it cannot re-enter the same Host until the Host completes a Full Cultivation Session. A permanent, Secret, artifact, divine, Immortal, or world-law effect is removed only when its Source Rule permits; otherwise reduce its severity by one stage and reveal its exact remaining recovery procedure. |
| **3–5 Source CL lower** | End one ordinary temporary Intrusion. Reduce one persistent Spiritual Affliction by one stage, then suppress any remainder until the target completes a Full Cultivation Session. A possession is separated for the same duration into its legal manifestation, vessel, nearest legal space, or—if none exists—a visible spiritual outline occupying the Host’s space without controlling the Host. |
| **Within 2 Source CL** | Choose one: reduce the effect by one printed severity stage; or suppress it until the target completes a Full Cultivation Session. Reveal its sustaining Anchor and exact printed recovery, release, confrontation, restitution, or reconstruction requirement. |
| **3 or more Source CL higher** | You cannot remove or reduce it. Stabilize the target so the effect cannot increase in severity until the target completes a Full Cultivation Session, and reveal its sustaining Anchor category and exact printed requirement for the next meaningful intervention. |

If an effect has no severity stages, “reduce by one stage” means remove one separately printed escalation, rider, or consequence. If none exists, use the suppression result instead.

Spiritual Exorcism cannot:

- destroy a Complete Soul without an explicit Source Rule;
- transfer ownership of a spirit;
- convert an unwilling spirit into your Companion;
- erase integrated spirit ancestry;
- remove a legal character option;
- end completed death, reincarnation, permanent soul destruction, or divine custody without explicit authority;
- invent a release condition, quest, sacrifice, price, or reconstruction procedure where the Source Rule provides none.

When complete removal is impossible, the feature must still provide the printed lesser result and diagnostic information.

The central Cultivation Insight **Exorcist’s Calling** grants a limited earlier version and improves when you gain this feature.

---

# CL15 — Domain Manifestation

**Action Type:** Bonus Action  
**Cost:** 6 Resonance  
**Area:** 30-foot aura centered on you  
**Duration:** The scene  
**Concentration:** No  
**Domain Type:** Personal Domain

Manifest the spiritual truth seeded by your Soul Anchor and refined through your Subpath. Record its sensory expression when you gain this feature. That description grants no additional effect.

The Domain moves with you and ends when you are Incapacitated, willingly end it, leave the scene, become unable to manifest Path features, or a Source Rule suppresses or breaks it.

A creature is affected while inside the aura. Entering the aura does not itself trigger a saving throw unless a Source Rule says so.

## Anchored Allies

Allies of your choice in the Domain have Advantage on Intelligence, Wisdom, and Charisma saving throws against:

- Charmed and Frightened;
- possession and coercive Hosting;
- dream intrusion;
- memory alteration;
- emotional domination;
- soul displacement.

You may revise which willing creatures count as allies at the start of your turn without an action. You cannot designate an unwilling hostile creature as an ally merely to bypass its protection or Bond terms.

## Unfading Marks

Your Resonance Marks on creatures in the Domain do not expire from duration. A mark ends normally when the creature leaves the Domain, the Domain ends, or another effect removes it.

## Domain Pressure

Once on each of your turns, when a creature in the Domain fails a saving throw against one of your Spirit Awakening Path or Subpath features, impose one ordinary Spiritual Pressure effect on it without additional cost.

This can occur only once during the turn, regardless of the number of failed saves, targets, echoes, or origins created by the activation.

## Revealed Spirits

Within the Domain, Spiritual Sense detects ordinary invisible spirits, possession links, Hosted entities, projected souls, Soul Fragments, and lower-Source-CL spiritual disguises without a check. Equal- or higher-authority concealment remains contested.

## Subpath Domain Expression

A Subpath may grant an additional Domain expression. That expression modifies this one Domain; it does not create a second Domain, second aura, second turn, or additional Concentration slot unless it explicitly says otherwise.

## Domain Collision

Compatible Domains coexist. When two Domain expressions impose contradictory laws upon the same target, space, Bond, route, or effect, compare Source CL. Equal Source CL uses a Cultivation Check contest. Losing suppresses only the contradictory expression, not the entire Domain, unless a Source Rule expressly says the whole Domain collapses.

A Domain is not automatically a Spiritual Anchor, prison, anti-teleport field, sanctuary, spirit court, Companion command zone, or law over every soul inside it.

At CL20, the Domain’s radius becomes 60 feet and its activation cost becomes 4 Resonance.

---

# CL17 — Soul Splitting

**Action Type:** Action  
**Cost:** 8 Resonance  
**Duration:** The scene  
**Concentration:** No

Split off one cultivated fragment of your Complete Soul in an unoccupied legal space within 30 feet. The fragment is a Spirit Cultivation Asset, not a duplicate character.

## Soul Fragment Profile

- **Size:** Tiny or Small, chosen when created.
- **AC:** Your Cultivation Save DC.
- **Hit Points:** `5 × Proficiency Bonus`.
- **Speed:** Fly 40 feet; hover.
- **Saving Throws:** Uses your Intelligence, Wisdom, and Charisma saving throw bonuses.
- **Resistance:** Psychic damage.
- **Immunities:** Poison damage, Disease, Poisoned, Prone, Grappled, Restrained, and ordinary bodily effects.
- **Physical Interaction:** Ordinary noncultivated attacks cannot damage it unless their Source Rule can affect spirits. Cultivated, magical, spiritual, artifact, divine, or expressly spirit-affecting attacks can.
- **Source CL:** Your effective Spirit Awakening CL.

The fragment has no independent turn, Action, Bonus Action, Reaction, Concentration, inventory, attunement, Cultivation Point pool, Path, Subpath, Sphere list, or Companion command authority.

At the end of each of your turns, it can move up to its Speed. This movement is part of Soul Splitting and is not your movement.

## Second Origin

When you activate one Spirit Awakening Path or Subpath feature, choose yourself or the fragment as its point of origin if the feature can legally originate from a spirit. You still activate the feature once, pay one cost, use one action, and obey every once-per-activation, once-per-turn, and once-per-target limit.

Measure range, area, cover, and line of effect from the chosen origin. You must still perceive the target by a method the feature permits. The fragment does not let a feature pass through total spiritual concealment or an illegal destination.

The fragment must remain within 300 feet of you. If forced beyond that range, it returns immediately to the nearest legal space within range by the shortest legal spiritual route. If no route exists, Soul Splitting ends safely unless the separating Source Rule expressly severs the fragment.

## Fragment Expression

Once on each of your turns, after you spend Resonance on a Spirit Awakening Path or Subpath feature or use Mind Spike, choose one expression. This requires no additional action and is part of the triggering turn.

- **Echo Spike:** One creature Resonance Marked by you within 60 feet of the fragment takes Psychic damage equal to your Wisdom modifier + Proficiency Bonus.
- **Maintain Pressure:** One creature Resonance Marked by you within 60 feet of the fragment suffers one ordinary Spiritual Pressure effect until the start of your next turn.
- **Guard Soul:** One ally within 30 feet of the fragment gains Temporary Hit Points equal to `2 × Proficiency Bonus` and Advantage on the next Intelligence, Wisdom, or Charisma saving throw it makes before the start of your next turn.
- **Subpath Expression:** Use one Soul Splitting expression expressly granted by your Subpath.

You can use only one Fragment Expression per turn. An expression cannot trigger itself, generate another Fragment Expression, or turn the fragment into a second attacker unless its Source Rule expressly creates an attack and pays for it.

## Ending, Severance, and Destruction

You may end Soul Splitting without an action, causing the fragment to return safely.

If the fragment is reduced to 0 Hit Points or destroyed by a legal spirit-affecting effect:

- you take `4d10` Psychic damage that ignores Resistance;
- Soul Splitting ends;
- you cannot use Soul Splitting again until you complete a Full Cultivation Session.

Destroying the fragment does not destroy your Complete Soul or Soul Anchor unless an explicit higher-authority Source Rule says so and prints the resulting injury and reconstruction procedure.

You may have only one core Soul Fragment at a time. It cannot activate Sphere talents, items, Recorded Arts, Forged Techniques, Immortal Arts, Companions, other summons, or another Soul Splitting.

A Subpath may expressly sacrifice or destroy the fragment and waive some normal backlash. Such an exception applies only to that printed sacrifice.

---

# CL20 — Immortal Spirit

Your awakened soul becomes an immortal spiritual structure rather than a mortal consciousness dependent upon one body.

## Ageless Soul

You cease aging unless you choose otherwise. Ordinary aging cannot reduce your abilities or kill you.

You do not require food, drink, air, or sleep to keep your soul alive, though your current body may still require them unless a separate feature changes its physiology. You still require rests and Cultivation Sessions to recover features whose rules require them.

## Sovereign Identity

An ordinary effect and any effect with lower Source CL cannot, against your will:

- Charm or Frighten you;
- possess or coercively Host within you;
- permanently alter or erase your memory;
- replace your identity;
- consume, destroy, imprison, redirect, or prevent the passage of your Complete Soul;
- permanently sever you from your Soul Anchor.

Equal- or higher-authority effects use their printed procedure. If no procedure is printed, make a Wisdom saving throw against the effect’s save DC; if it has none, use a Cultivation Check contest. Success prevents the attempted permanent result but does not destroy the source.

This protection does not make you immune to persuasion, grief, voluntary bargains, chosen Hosting, chosen memory alteration, lawful consequences, self-created Heart Demons, or the ordinary consequences of your own decisions.

## Continue Without the Body

If your body dies while your Complete Soul remains free, you persist as a coherent Unbodied spirit for up to 30 days.

During this state:

- You can perceive and communicate.
- You can use Spiritual Sense, Read the Spirit, and Soul Gaze.
- You cannot make hostile attacks, spend Resonance, manifest a Domain, command a full Companion, manipulate ordinary objects, or activate techniques unless a Source Rule specifically permits bodyless action.
- You can travel as Astral Projection with no distance limit on the same plane, but wards, Domains, spiritual boundaries, and routes still apply.
- You remain one Complete Soul and are not a Companion, Cultivation Asset, or Soul Fragment.

If you are imprisoned, claimed, reincarnated, destroyed, or prevented from reaching an Anchor by an equal- or higher-authority Source Rule, resolve that rule before Return to the Anchor.

## Immortal Restoration Capacity

**Limit:** Once per 28 days

Return to the Anchor and Call Back the Departed use the same capacity. Using either prevents use of the other until 28 days have passed.

## Return to the Anchor

While bodyless, spend 7 uninterrupted days at your Soul Anchor, a compatible prepared spirit vessel, or a location explicitly accepted by your Soul Anchor.

If your death and any effect blocking return have lower Source CL, you return automatically in a recreated body with:

- 1 Hit Point;
- 0 Resonance;
- 3 levels of Exhaustion;
- your Path, Subpath, known Spheres, talents, Method, Foundation, Soul Anchor, Insights, and learned techniques intact unless the effect that killed you expressly damaged one of them.

If the death effect or return barrier is within 2 Source CL and has no printed return procedure, make one Cultivation Check against its save DC at the end of the 7 days. If it has no DC, use the Authority DC for its Realm from Spiritual Exorcism.

- **Success:** You return as above.
- **Failure:** You do not expend the 28-day capacity. Learn the exact Anchor, authority, or printed condition preventing return. You cannot retry until that condition changes.

If the death effect or return barrier is 3 or more Source CL higher, you cannot return unless its printed recovery condition has already been met. The 7-day attempt reveals that condition but does not expend the 28-day capacity.

A destroyed Complete Soul, completed reincarnation, or voluntary refusal to return cannot be bypassed by this feature.

## Call Back the Departed

**Time:** 8 hours  
**Cost:** 10 Resonance, paid when the rite begins  
**Target:** One willing dead creature whose Complete Soul remains reachable

You require at least one:

- the body or meaningful remnant;
- the creature’s true or chosen name;
- its Soul Anchor or equivalent identity Anchor;
- a relic, oath, descendant, bonded spirit, or location with a profound recorded connection to it.

If the soul is free and the death effect has lower Source CL than this feature, restore the creature in a whole body with 1 Hit Point and 3 levels of Exhaustion.

If the death effect or custody is within 2 Source CL, make a Cultivation Check against its save DC. If it has no DC, use the Authority DC for its Realm.

- **Success:** Restore the creature as above.
- **Failure:** The rite does not expend the 28-day capacity or its Resonance cost. Learn the exact barrier or printed recovery condition. You cannot retry until it changes.

If the death effect or custody is 3 or more Source CL higher, the rite cannot restore the creature unless its printed recovery condition has already been met. The rite reveals that condition but does not invent a quest, payment, sacrifice, or exception.

Call Back the Departed cannot restore a creature that refuses, has completed reincarnation, whose Complete Soul has been permanently destroyed, or whose Source Rule declares the death final against this authority.

---

# Spirit Companions and Independent Spirits

Spirit Awakening and the Sphere of Spirit Companions interact closely, but they are not the same system.

## Spirits Are Independent Beings

A spirit can be natural, ancestral, embodied, object-born, cultivated, office-bearing, parasitic, or another recorded origin. A Complete Spirit has its own personhood, Nature, Source CL, appetite, sustenance, temperament, goals, cultivation, evolution, embodiment state, permissions, and relationships.

Perceiving, naming, feeding, summoning, Hosting, or being stronger than a spirit does not make it property.

Spirit ancestry is integrated personhood, not possession or a removable Intruder, unless a specific lineage rule states otherwise.

## What the Path Does Not Grant

Spirit Awakening does not automatically grant:

- the Sphere of Spirit Companions;
- a Minor Agreement or Major Spirit Bond;
- a full combat Companion;
- a spirit stat block;
- Nature Spheres known by the cultivator;
- permission to bind an unwilling spirit;
- Companion action economy;
- permission to place a spirit in a body, object, weapon, shrine, dream, shadow, dantian, or Soul Anchor.

## Spirit Nature Belongs to the Spirit

A bonded, Hosted, or manifested spirit may express legal Spheres through its Spirit Nature. Those Spheres belong to the spirit unless the cultivator separately learns them.

The cultivator may coordinate the relationship and pay Resonance when a Source Rule requires it, but does not thereby know the spirit’s Spheres or own its techniques.

## Relationship Tiers

Distinguish among:

- ordinary contact or negotiation;
- Minor Spirit Agreement;
- Major Spirit Bond;
- Hosting Bond;
- Binding Seal;
- Manifesting Spirit Source;
- full combat Companion.

A Bond is not automatically a full Companion. A full Companion requires an explicit legal upgrade and a complete record under the Universal Bonded Companions Combat Chassis R2.

Every significant Bond must record consent, permissions, mutual benefits, sustenance, Offerings, Taboos, Bond Strain triggers, crises, action economy, manifestation, withdrawal, destruction, reconstruction, and renegotiation.

## Core Feature Interaction

- Spiritual Sense can perceive a bonded, Hosted, possessing, or manifested spirit unless stronger concealment applies.
- Soul Gaze can identify broad Bond status, embodiment, and strain, but not hidden contract terms without permission or a successful contest.
- Soul Vessel can carry a sympathetic imprint of a spirit under its normal target and consent rules; it does not bind the spirit.
- Spiritual Exorcism cannot remove a willing stable Bond or integrated ancestry as though it were an Intrusion.
- Domain Manifestation can protect a bonded spirit inside it but grants no additional turn, expression, or command authority.
- Soul Splitting does not create, copy, or duplicate a Companion.
- A spirit used as a Soul Anchor remains a relationship and identity source unless separately given an Asset or Spiritual Anchor profile.

## Coercive Bonds

A Binding Seal is not friendship. Coercive commands that violate a spirit’s Nature, Need, consent, or Taboo use Bond Strain and the consequences printed by the Spirit Companions rules.

High Wisdom, stronger Source CL, or Spirit Awakening Path access does not erase those consequences.

---

# Realm Suppression — Spirit Awakening Summary

When a Spirit Awakener suppresses to a lower effective CL:

- use the suppressed Proficiency Bonus where the universal Realm Suppression rule requires it;
- reduce dependent Path, Subpath, Domain, possession, and spirit-effect Source CL to the suppressed effective CL;
- do not activate or benefit from Path or Subpath features whose minimum CL exceeds the suppressed CL;
- use lower-CL scaling where a lower version exists;
- Domain Manifestation ends if effective CL falls below 15;
- a core Soul Fragment returns safely if effective CL falls below 17, unless another effect violently severed it;
- Astral Projection ends if effective CL falls below 7;
- the cultivated structure of a Soul Vessel remains, but Vessel Ward and other expressions above the suppressed CL become dormant.

Realm Suppression does not reduce or erase:

- Hit Points or Hit Dice;
- maximum Resonance;
- the existence of the Soul Anchor;
- ordinary memories, personality, identity, ancestry, relationships, oaths, or consent;
- passive Foundation quality;
- an independent spirit’s statistics unless its Source Rule scales directly from the suppressed cultivator;
- a Bond, Offering, Taboo, debt, injury, Spirit Scar, possession, custody, or consequence already created.

Suppression does not itself exorcise, sever, expel, destroy, free, or transfer a spirit. An active effect you can no longer maintain ends or becomes dormant as its Source Rule states. If the rule does not state where a Hosted or possessing spirit goes when suppressed, use the Spirit Awakening Rules Reference rather than inventing a destination.

Realm Suppression cannot refund Resonance, erase setup requirements, avoid a Bond crisis, or make an existing consequence count as lower authority after the fact.

---

# Realm Identity

| Realm | Spirit Awakening expression |
|---|---|
| **Mortal, CL1–4** | Soul Anchor, mental defense, spiritual perception, Resonance Marks, direct Mind Spike, diagnosis |
| **Foundation, CL5–9** | Spiritual Pressure, astral projection, stable sympathetic Soul Vessel, first Subpath mastery |
| **Core Formation, CL10–14** | Hardened soul defense, universal Spiritual Exorcism, advanced tradition authority |
| **Nascent Soul, CL15–19** | Personal Domain, cultivated Soul Fragment, remote origins, perfected spiritual perception |
| **Immortal, CL20** | Sovereign identity, body-independent continuity, self-reconstruction, restoration of reachable souls |

---

# Dependency Seal Note

Core R2A makes no numerical or progression changes from Core R2. Its changes are limited to:

- correcting the canonical rule order;
- replacing provisional Rules Reference R2 citations with Rules Reference R3;
- recognizing the completed Universal Bonded Companions Combat Chassis R2;
- removing the prior unresolved companion dependency from the release status;
- clarifying that full companion status requires the universal combat record in addition to a Spirit relationship record.

# Canonical Integration Contract

A PHB, compendium, GM Guide, Character Factory, or GM Screen insertion based on this core must preserve:

- Wisdom as the Spirit Awakening key ability.
- No saving throw proficiencies on the Path chassis.
- The printed Resonance maximum, recovery, and 0-Resonance Exhaustion procedure.
- Soulward Response as a paid post-failure response rather than proficiency.
- Spiritual Sense and Soul Gaze as perception and diagnosis, not permission to read unprinted secrets.
- Mind Spike as a save-based Spirit technique unless a Source Rule expressly creates martial or weapon delivery.
- Resonance Mark and Spiritual Pressure limits.
- Soul Vessel as a sympathetic and protective Asset, not universal puppet control.
- Spiritual Exorcism’s exact DC, Source CL bands, lesser results, consent limits, and prohibition against treating ancestry or legal character options as removable Intrusions.
- Astral Projection’s one-creature rule and body vulnerability.
- Domain Manifestation as one Personal Domain with explicit collision procedures.
- Soul Splitting as one Cultivation Asset with no independent turn or duplicate resource economy.
- Spirits as autonomous cultivated beings rather than generic summons or property.
- Spirit Companions as a separate legal system requiring explicit access, complete relationship records, and the Universal Bonded Companions Combat Chassis R2 only when a full combat companion is expressly granted.
- Level-selected Cultivation Insights from the central catalogue, with their printed +1 ability option; non-level awards do not automatically grant that increase.
- Realm Suppression preserving Soul Anchor existence, personhood, relationships, ancestry, and independent spirits while suppressing higher-CL expressions.
- Immortal restoration using exact Source CL and recovery procedures rather than an undefined “appropriate quest.”

The final PHB may shorten examples and move GM-only authority detail into the Universal Cultivation Authority Appendix, but it must not silently change these mechanics or restore superseded feature text.
