# Tianxia Spirit Awakening — Tradition Compendium R7

**Publication state:** Player-facing organization of all 34 normalized Spirit Awakening traditions.  
**Integration state:** Consolidated after controlled non-nerfing normalization.  
**Mechanical state:** No intentional changes to inherited feature levels, costs, dice, ranges, durations, targets, Asset profiles, or conceptual authority.  
**Required rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7; Universal Bonded Companions Combat Chassis R2 when expressly invoked.

## Using This Compendium

Each tradition retains its complete CL3, CL6, CL10, CL14, and CL18 progression. The integrated procedure footer at the end of each entry is a cross-reference and grants no additional ability. A tradition does not grant a Sphere, weapon proficiency, armor proficiency, companion, independent Asset turn, or external projection permission unless its feature expressly says so.

## Canonical Rule Order

1. Explicit tradition feature text.
2. Spirit Awakening Core R2A.
3. Spirit Awakening Rules Reference R3.
4. Spirit Tradition Procedure Addendum R7.
5. Universal cultivation procedures and general Tianxia rules.

## Catalog Summary

| Access category | Count |
|---|---:|
| Forbidden Tradition | 6 |
| Rare Inheritance | 2 |
| Restricted Infiltration Tradition | 1 |
| Restricted Inheritance | 1 |
| Restricted Martial Tradition | 6 |
| Restricted Tradition | 16 |
| Secret Law | 2 |
| **Total** | **34** |

## Contents

| # | Tradition | Category | Primary role | Progression |
|---:|---|---|---|---|
| 1 | Dreamweaver | Restricted Tradition | Reaction control, dream setup, save revision, survival through a dream Anchor, and single-target spiritual isolation. | CL3 Dream Stitch; CL6 Unreality Bites Back; CL10 Waking Dream Revision; CL14 Eternal Dream Refuge; CL18 World of One |
| 2 | Sovereign Will | Restricted Tradition | Low-cost commands, earned authority, area edicts, spiritual retainers, and a controlling Domain. | CL3 Commanding Voice; CL6 Break Their Will; CL10 Edict of Heaven; CL14 Retainer of the Empty Throne; CL18 Hegemon’s Domain |
| 3 | Exorcist | Restricted Tradition | Anti-possession specialist, spirit controller, curse surgeon, area purification, and high-authority expulsion. | CL3 Ghost Sight and Name the Intruder; CL6 Banishment Strike; CL10 Purification Bell; CL14 Seal of Binding; CL18 Grand Exorcism |
| 4 | Ancestral Channeler | Restricted Tradition | Flexible expertise, defensive possession, office-based support, ancestor manifestations, and full ancestral embodiment. | CL3 Council of the Remembered; CL6 Possession by the Past; CL10 Legacy Made Present; CL14 Ancestral Legion; CL18 Ancestral Ascension |
| 5 | Miko | Restricted Tradition | Preventive protection, ritual purification, area support, communication, and temporary divine embodiment. | CL3 Purification Dance; CL6 Minor Kami Favor; CL10 Sacred Ground; CL14 Kami’s Messenger; CL18 Kami Descent |
| 6 | Mudang | Restricted Tradition | Mobile support, spirit revelation, negotiated hosting, condition relief, and temporary manifestation. | CL3 Spirit Dance; CL6 Possession Trance; CL10 Gut of Revealed Guests; CL14 Greater Spirit Possession; CL18 Grand Mudang Procession |
| 7 | Inner Soul-Gate Ascetic | Restricted Tradition | Self-defense, anti-possession, save correction, emotional stabilization, and high-level spiritual clarity. | CL3 Root Soul Gate; CL6 Sacral Soul Gate; CL10 Solar Soul Gate; CL14 Heart Soul Gate; CL18 Crown Soul Gate |
| 8 | Yokai Channeler | Rare Inheritance | Adaptive transformation, movement, natural weapons, trickster bargains, lineage-specific control, and local spirit-beast authority. | CL3 Yokai Mask; CL6 Unmasking; CL10 Yokai’s Bargain; CL14 True Yokai Form; CL18 Yokai Lord |
| 9 | Dream Eater | Forbidden Tradition | Predatory setup, psychological information, sleep control, persistent dream injury, and high-level memory consumption. | CL3 Dream Walker; CL6 Nightmare Touch; CL10 Stolen Dreams; CL14 Sleeping Curse; CL18 Dream Eater Ascension |
| 10 | Soul Warden / Necromancer | Forbidden Tradition | Death investigation, earned soul-residue, temporary specter Assets, spirit damage, containment, and battlefield manifestation. | CL3 Speak with the Dead; CL6 Soul Harvest; CL10 Raise Specter; CL14 Soul Drain and Death Custody; CL18 Lord of the Dead |
| 11 | Halo Eater | Forbidden Tradition | Anti-buff pressure, blessing diagnosis, hostile sustain theft, radiant defense, and high-authority spiritual predation. | CL3 Taste the Radiance; CL6 Bite the Halo; CL10 Stolen Benediction; CL14 Crown of Borrowed Light; CL18 Empty Heaven Maw |
| 12 | Choir of the Unopened Eye | Forbidden Tradition | Revelation, anti-concealment, reaction denial, truth pressure, coordinated control, and witness-based imprisonment. | CL3 Witness Note; CL6 Hymn of Stillness; CL10 Forced Confession; CL14 All Eyes Open; CL18 Edict of Perfect Witness |
| 13 | Mercy Flayer | Forbidden Tradition | Emergency healing, affliction extraction, damage interception, burden transfer, and deferred catastrophic harm. | CL3 Gentle Knife; CL6 Peel the Wound; CL10 Give the Pain a Name; CL14 Painless Martyr; CL18 White Room Mercy |
| 14 | Seraphic Molter | Forbidden Tradition | Transformation, mobility, self-cleansing, perception, anti-concealment, and identity-scale survival. | CL3 First Molt; CL6 Wingless Ascent; CL10 Burn Away the Lesser Self; CL14 Eyes in the Wings; CL18 Molt the Mortal Name |
| 15 | Fate Reader | Secret Law | Prediction, roll intervention, danger diagnosis, delayed failure, and high-authority outcome revision. | CL3 Omen Glimpse; CL6 Read the Thread; CL10 Nudge Consequence; CL14 Borrowed Ending; CL18 Sever One Thread |
| 16 | Candlemaker | Restricted Tradition | Setup controller, anti-possession support, spiritual diagnosis, emergency preservation, and prepared finisher. | CL3 Wick of the Self; CL6 Candle Against the Dark; CL10 Funeral Light; CL14 Last Flame; CL18 Thousand-Year Lantern |
| 17 | Boundary Walker | Restricted Tradition | Tactical movement, anti-teleport control, route surveillance, threshold defense, and temporary border-realm exile. | CL3 Threshold Step; CL6 Mark the Door; CL10 Deny Passage; CL14 Walk the Border; CL18 Gate of No Return |
| 18 | Knot Weaver | Restricted Tradition | Relationship diagnosis, roll and movement interference, linked damage, bond cleansing, and relationship-based control. | CL3 Red Thread Sense; CL6 Tie the Moment; CL10 Binding Knot; CL14 Sever the False Thread; CL18 Knot of Inevitability |
| 19 | Soulstring Dancer | Restricted Tradition | Forced movement, reaction denial, attack redirection, single-target control, and mobile area control. | CL3 Threaded Step; CL6 Stolen Rhythm; CL10 Marionette Defense; CL14 Dance of Borrowed Limbs; CL18 Theater of Strings |
| 20 | Grief Eater | Restricted Tradition | Emotional cleansing, ally protection, burden sharing, guilt pressure, and communal defensive field. | CL3 Taste of Sorrow; CL6 Eat the Bitter Memory; CL10 Shared Burden; CL14 Weight of Mourning; CL18 Vessel of Ten Thousand Sorrows |
| 21 | Mirror Speaker | Restricted Tradition | Reactive defense, spiritual detection, positional misdirection, identity exposure, and temporary reflection imprisonment. | CL3 Reflection Listener; CL6 Inverted Glance; CL10 Borrowed Reflection; CL14 Mirror Confession; CL18 World Behind the Glass |
| 22 | Mushroom Dreamwalker | Rare Inheritance | Network support, area control, dream communication, environmental investigation, attrition, and regenerative field play. | CL3 Mycelial Dream; CL6 Spore Murmur; CL10 Under-Root Memory; CL14 Hallucinogenic Bloom; CL18 Fruiting Body of the Dream |
| 23 | Echo Scribe | Restricted Tradition | Investigation, anti-deception, reactive disruption, event recording, spiritual tagging, and bounded consequence revision. | CL3 Ink Remembers; CL6 Written Rebuke; CL10 Name on the Page; CL14 Marginal Correction; CL18 Chronicle of the Living Soul |
| 24 | Heartbinder | Restricted Tradition | Bonded support, retaliation, emotional protection, damage sharing, emergency preservation, and relationship-centered field play. | CL3 Vow Mark; CL6 Heart’s Rebuke; CL10 Borrowed Courage; CL14 Chain of Devotion; CL18 Unbroken Vow |
| 25 | Thrum of the Grave | Restricted Tradition | Mobile damage stance, forced movement, anti-healing, death-zone control, unquiet echo Assets, and major earthbound finishing pressure. | CL3 Gravebeat; CL6 Dead March; CL10 Burial Drum; CL14 Call the Unquiet; CL18 The Earth Beats Once |
| 26 | Well of Hours | Restricted Inheritance | Initiative control, action compression, delayed consequences, temporal debuffing, emergency restoration, and bounded local time authority. | CL3 Ripple of Before; CL6 Borrowed Second; CL10 Hourglass Mark; CL14 Refuse the Moment; CL18 The Well Has No Bottom |
| 27 | Black Current Walker | Restricted Martial Tradition | Mobile skirmisher, defensive redirection, marked-target pursuit, ally extraction, and flowing battlefield control. | CL3 Enter the Black Current; CL6 Turn the Pursuer; CL10 River-Cut Passage; CL14 No Bank Holds the River; CL18 Procession of the Black River |
| 28 | Unwritten Footprint | Restricted Infiltration Tradition | Stealth skirmisher, anti-surveillance infiltrator, ambush control, escape, and selective witness suppression. | CL3 Step No Record Keeps; CL6 Knife Between Thoughts; CL10 Steal the Witness; CL14 No Trace Returns; CL18 Concept of the Missing Footstep |
| 29 | Echo-Step Disciple | Restricted Martial Tradition | Single-target skirmisher, pursuit, reaction defense, line-breaking burst, and high-speed dueling. | CL3 Afterimage Edge; CL6 Echo Counter; CL10 Three-Step Soul Execution; CL14 Pursuit Without Distance; CL18 Hundred Echoes Kill One Moment |
| 30 | Law of Near and Far | Secret Law | Conceptual mobility, ally rescue, attack denial, pursuit, battlefield separation, and high-authority spatial control. | CL3 Name What Is Near; CL6 Make the Blow Far; CL10 Collapse the Interval; CL14 Cast Them to the Far Side; CL18 World Without Between |
| 31 | Compass-Breaking Hand | Restricted Martial Tradition | Mobile skirmisher, interceptor, positional defender, pursuit breaker, and battlefield reorientation. | CL3 Three-Bearing Footwork; CL6 Turn the Compass; CL10 Break the Four Directions; CL14 No Fixed Compass; CL18 Heaven Has No Fixed North |
| 32 | Equal Measure Scripture | Restricted Martial Tradition | Reactive defender, martial counterattacker, ally protection, forced-movement resistance, and punishment of repeated aggression. | CL3 Receive and Return; CL6 Exact Counterweight; CL10 Threefold Recompense; CL14 The Scales Do Not Tremble; CL18 Court of Equal Heaven |
| 33 | Plain-Truth Fist | Restricted Martial Tradition | Duelist, pursuer, guardian, anti-deception combatant, and controller of predictable hostile intent. | CL3 Word and Hand; CL6 Unspoken Intention Made Visible; CL10 Deed Follows Word; CL14 Heaven Rejects the Feint; CL18 Hall of Spoken Deeds |
| 34 | Last-Inch Palm | Restricted Martial Tradition | Close controller, anti-Grapple defender, touch-technique interceptor, spiritual striker, and local reach manipulator. | CL3 The Last Inch; CL6 Nothing Crosses Unanswered; CL10 Palm Across Emptiness; CL14 Inside Every Guard; CL18 World of One Handspan |

---

## 01. Dreamweaver

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted dream lineage, oneiric scripture, dream-court initiation, inherited lucid memory, or tutelage by a qualified dream spirit.  
**Identity:** Dream-shaped unreality, emotional symbolism, false certainty, and personal dream imprisonment.  
**Primary role:** Reaction control, dream setup, save revision, survival through a dream Anchor, and single-target spiritual isolation.  
**Sphere Lean:** Dreams, Illusion, Mind. This tradition does not grant those Spheres.  
**Cultivation boundary:** Dreamweaver alters what a soul accepts as presently real. It does not rewrite actual history, steal Fate’s authority, permanently replace memory without an explicit higher-authority technique, or automatically affect mindless or dreamless entities.

> *Do not wake them. The dream is kinder than the blade.*

Dreamweavers stitch waking perception to dream logic. Their attacks become omens, missed blows become openings in the attacker’s self-image, and marks become recurrent symbols that let the cultivator return to the same vulnerable dream. A Dreamweaver does not need the Dreams Sphere to use this tradition, but the Sphere broadens the art beyond these five expressions.

### Dream Threads

Several Dreamweaver features create **Dream Threads**.

- You can maintain a number of Dream Threads equal to your Proficiency Bonus.
- Each Thread is attached to one creature, dream zone, illusion, or dream object created by you.
- A creature can bear only one of your Dream Threads at a time.
- A Thread lasts for the scene, until you dismiss it, or until its attached Source is destroyed or leaves the plane.
- A Thread is a spiritual state, not a condition, curse, Resonance Mark, or physical object.
- You know which of your Threads remain, but a Thread does not reveal a hidden creature’s exact location.
- A creature can attempt to remove its Thread through the **Dream-Confrontation procedure** in the Procedure Addendum. The procedure is performed as part of a Short Rest or Long Rest and requires at least 10 uninterrupted minutes of sleep, meditation, lucid-dream treatment, or spiritual care. It uses a Wisdom or Charisma saving throw against your Cultivation Save DC, chosen by the affected creature, and permits one attempt during that rest unless a separate Source Rule grants another attempt. Ordinary sleep alone does not remove a Thread.

When you would create a Thread beyond your maximum, choose one of your existing Threads to end.

### CL3 — Dream Stitch

**Reaction**  
**Trigger:** A creature you can perceive within 60 feet makes an attack roll.  
**Cost:** 1 Resonance

Stitch a moment of dream hesitation into the attacker’s intent. Impose Disadvantage on the triggering attack roll.

If the attack misses, choose one:

- The attacker becomes Resonance Marked by you.
- Create a Dream Thread on the attacker.

If the attack already had Disadvantage, Dream Stitch does not add a third die. Instead, subtract your Proficiency Bonus from the attack roll after the roll is made but before the result is announced.

Dream Stitch cannot alter an attack you cannot spiritually perceive, an environmental collapse with no attacking creature, or an effect that expressly cannot be altered by Reactions. It can affect a blind, invisible, or incorporeal attacker if Spiritual Sense or another legal sense perceives that attacker.

#### Threaded Reverie

When you use Soul Gaze on a creature bearing your Dream Thread, you may learn one additional item:

- The strongest emotion presently shaping its next intended action.
- Whether it is asleep, dreaming, affected by a dream intrusion, or maintaining an illusion.
- The symbolic image through which its current fear or desire would appear in a dream.

This is diagnostic information. It does not reveal private memories, hidden mechanics, or an exact future action.

### CL6 — Unreality Bites Back

Your dream-work resists being dismissed as “only an illusion.”

**Reaction**  
**Trigger:** A creature within 60 feet succeeds on a check or saving throw made specifically to disbelieve, pierce, escape, suppress, or end one of your dream, illusion, emotional unreality, or Dreamweaver effects.  
**Cost:** 2 Resonance

The creature makes a Wisdom saving throw.

**Failed Save:** It takes `3d10` Psychic damage, becomes Resonance Marked by you, and suffers one ordinary Spiritual Pressure effect. You may also create or refresh a Dream Thread on it.

**Successful Save:** It takes half damage and you may create a Dream Thread on it, but it still succeeds against the original effect.

Unreality Bites Back never reverses the triggering success by itself. It punishes spiritual certainty and creates later access.

#### Dream-Thread Passage

As a Bonus Action, spend 1 Resonance and choose one creature bearing your Dream Thread within 60 feet. Until the end of your turn, you may perceive that creature through ordinary darkness, invisibility, and non-total visual concealment. This does not cross total cover or defeat equal- or higher-Source-CL spiritual concealment without a Cultivation Check.

### CL10 — Waking Dream Revision

You can revise a moment by forcing the soul to rehearse a different dream-version of it. This is not Fate alteration; the revision must pass through one of your Dream Threads.

**Reaction**  
**Trigger:** You, an ally you can perceive, or a creature bearing your Dream Thread within 60 feet completes a d20 Test.  
**Cost:** 3 Resonance  
**Limit:** Once per round

Choose one of the following:

- **Rehearse Success:** If the Test was made by you or an ally, reroll it. The new roll must be used.
- **Rehearse Failure:** If the Test was made by a hostile creature bearing your Dream Thread, force it to reroll. The new roll must be used.
- **Change the Symbol:** Do not reroll. Instead, move your Dream Thread from the creature involved in the Test to another creature you can perceive within 30 feet of it. The new creature makes a Wisdom saving throw, receiving the Thread on a failure.

You must use Waking Dream Revision before the Test’s consequences produce a new independent roll, damage packet, movement, or another completed activation. It cannot reroll a natural 20 where an explicit rule makes that result unalterable, and it cannot modify breakthrough, training, forging, or tribulation resolution unless a Source Rule explicitly permits dream intervention.

#### Lucid Resistance

You have Advantage on saving throws against sleep, dream intrusion, nightmare effects, and memory alterations that occur through dreams. When you succeed on such a save, you may spend 1 Resonance to identify the effect’s direction, dream-symbol, or spiritual signature if its Source CL does not exceed yours. Equal or higher authority can require a Cultivation Check.

### CL14 — Eternal Dream Refuge

You cultivate a hidden dream-body that catches you when the waking body collapses.

**Trigger:** You would be reduced to 0 Hit Points while conscious and your soul is not sealed, possessed, or prevented from dreaming.  
**Cost:** 6 Resonance  
**Limit:** Once per scene

You fall Unconscious at 0 Hit Points but do not immediately begin making death saving throws. Create a **Dream Refuge** in a 20-foot Emanation centered on your body. The Refuge lasts for up to 3 rounds. It is a **Dream Field** anchored to your body, not a separate targetable Asset. Your body is its sole Anchor and retains its normal AC, Hit Points, size, and conditions. An effect that can directly suppress dreams, Fields, souls, or spiritual Anchors may contest the Refuge under the Source CL rules without first destroying a separate object.

While the Refuge exists:

- You are stable.
- Your body has Resistance to all damage except Psychic, Force, and damage from an effect that can strike dreams or souls.
- Enemies that first enter the Refuge on a turn or start their turn there make a Wisdom saving throw.
- On a failed save, a creature falls into **Dream Sleep** until the end of its next turn, until it takes damage, or until another creature uses an action to wake it.
- On a successful save, its Speed is reduced by 10 feet and it cannot take Reactions until the start of its next turn.
- An ally in the Refuge can use an Action to complete one **Refuge Recall**: speak your name and at least one specific shared event in a sentence of no more than 25 words; invoke one recorded Soul Anchor relationship or principle; spend and resolve a legal healing feature on you; or succeed on a Wisdom (Medicine), Wisdom (Insight), or Charisma (Performance or Persuasion) check against your Cultivation Save DC while physically touching your body. A successful Recall restores you to consciousness with Hit Points equal to `2 × Proficiency Bonus`, and the Refuge ends. A creature can attempt only one Recall during the same Refuge unless it uses a different listed method.

At the end of the third round, if no ally wakes you and you remain alive, you awaken with 1 Hit Point, gain 1 level of Exhaustion, and the Refuge ends.

If the Dream Refuge is broken by an equal- or higher-Source-CL anti-dream effect, you become stable but lose its other protections and begin death saving throws normally at the start of your next turn if still at 0 Hit Points.

#### Soul Splitting Expression — Dream Double

While Soul Splitting is active, you may use **Dream Double** as your Subpath Expression. Move your Soul Fragment up to 20 feet without provoking reactions from spirit-affecting creatures. One creature bearing your Dream Thread within 30 feet of the fragment has Disadvantage on the next attack roll it makes before the start of your next turn.

### CL18 — World of One

You isolate one soul inside a personal dream-world whose symbols obey your cultivated authority.

**Action**  
**Range:** 60 feet  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Concentration:** Yes

Choose one creature you can perceive. A creature bearing your Dream Thread makes the initial saving throw with Disadvantage. The target makes a Wisdom saving throw.

#### Failed Save

The target’s consciousness is drawn into a **World of One**. Its body becomes Incapacitated, falls Prone if able, and cannot perceive or affect the ordinary battlefield. The body remains present and can be moved or damaged.

At the end of each of its turns, the target takes `6d10` Psychic damage and may attempt to escape by choosing one procedure:

- Repeat the Wisdom saving throw.
- Make an Intelligence (Investigation), Wisdom (Insight), or Charisma (Performance or Persuasion) check against your Cultivation Save DC to identify, accept, reinterpret, or break the governing dream-symbol.
- Destroy a dream Anchor that you manifest inside the World. The Anchor has AC equal to your Cultivation Save DC, Hit Points equal to `5 × your Proficiency Bonus`, and can be damaged only by the target’s spiritual, cultivated, magical, or symbolic actions.

A successful procedure ends the effect. The target chooses one procedure each turn; it does not attempt all three.

#### Successful Initial Save

The target takes half of `6d10` Psychic damage, suffers one ordinary Spiritual Pressure effect, and you may create a Dream Thread on it.

#### Authority and Realm

- A creature whose Source CL is at least 5 lower than yours and that fails the initial save cannot use an ordinary legendary resistance or mundane immunity to ignore the dream unless that protection explicitly applies to dream entry, soul isolation, or conceptual imprisonment.
- An equal- or higher-Source-CL target retains every printed escape procedure and may contest a contradictory dream law with a Cultivation Check.
- A mindless entity, a being that truly cannot dream, or a creature with no coherent soul is immune unless another Source Rule gives you an appropriate dream-symbol or consciousness route.
- Damage dealt to the target’s body grants it Advantage on its next escape attempt but does not automatically end World of One.
- If your Concentration ends, the target returns immediately and knows it was attacked through a dream.

#### Domain Integration

While Domain Manifestation is active, you may originate World of One from yourself or your Soul Fragment. A target inside your Domain that bears both your Resonance Mark and Dream Thread cannot benefit from ordinary sleep immunity on the initial save; equal- or higher-authority immunity remains valid.

### Normalized Execution Notes

#### Dream Thread Record
For each Thread, record the bearer or attached dream source, creation time, visible dream-symbol, Source CL, and whether it is ordinary, concealed, or protected by another authority. A Thread never supplies the target's precise location, private memory, complete intent, or a legal route through total cover.

#### Dream-Confrontation Procedure
The affected creature uses at least 10 minutes of a Short Rest or Long Rest to name or confront the Thread's recorded symbol, receive treatment, or lucidly reject the symbol. It then makes the printed Wisdom or Charisma save. On success, the Thread ends. On failure, the creature learns whether the Thread is lower, equal, or higher Source CL and cannot repeat the procedure during the same rest. A distinct legal removal Source Rule can still act normally. A willing Dreamweaver can dismiss the Thread without an action.

#### Dreamless and Mindless Targets
A target is truly dreamless only when its creature rules, Spirit Nature, construction, or Source Rule says it has no dreams, sleep consciousness, or symbolic inner experience. Immunity to ordinary sleep alone does not make a creature dreamless. A mindless target is one whose Source Rule says it lacks coherent thought or soul; low Intelligence by itself is insufficient.

#### Dream Refuge Resolution
The Refuge has no independent turn, movement, Hit Points, or duplicate occupancy. It ends when you awaken, after 3 rounds, when your body ceases to be a legal Anchor, or when a successful equal-or-higher-authority counterprocedure ends the Field. Destroying or moving the body uses ordinary creature rules and does not create a second Refuge object.

#### World of One Anchor
The dream Anchor inside World of One is local to that target's personal dream and cannot be attacked by outside creatures. The target can use one legal Action, Bonus Action, attack, technique, or symbolic act available on its turn to damage it. One activation or Multiattack sequence damages the Anchor only through the attacks or packets that actually hit it. The Anchor is immune to Poison and ordinary bodily conditions and cannot leave the World.

#### Realm Suppression
Existing Dream Threads persist with the Source CL they had when created if their Source Rule has become an independent spiritual state; however, you cannot create or exploit a feature above your effective CL. Dream Refuge and World of One end immediately if your effective CL falls below their required feature level. Dream Double becomes unavailable while your effective CL is below 14.

### Integrated Procedure Closure — Dreamweaver

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Dream Double. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 02. Sovereign Will

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted imperial soul scripture, throne lineage, divine-mandate inheritance, command sect, state cult, or initiation by a sovereign spirit.  
**Identity:** Direct hierarchy, command, submission, spiritual jurisdiction, and the embodied expectation of obedience.  
**Primary role:** Low-cost commands, earned authority, area edicts, spiritual retainers, and a controlling Domain.  
**Sphere Lean:** Mind, Spirit, War, Oaths. This tradition grants none of those Spheres.  
**Cultivation boundary:** Sovereign Will creates direct spiritual hierarchy. It does not fabricate an oath, create Karma, reveal unknown information, make a target capable of impossible acts, or automatically override equal or higher cosmic authority.

> *Kneel because your soul remembers the shape of a throne.*

A Sovereign Will cultivator is not merely persuasive. Their soul carries the architecture of court and command. The tradition is dangerous because obedience can feel momentarily more natural than resistance.

### Mandate

You can hold a number of **Mandate** points equal to your Proficiency Bonus.

You gain 1 Mandate, up to this maximum, when one of the following occurs:

- A meaningful hostile creature fails a saving throw against your Sovereign Will feature.
- A meaningful hostile creature voluntarily surrenders, accepts your command, or acknowledges your authority during a scene.
- A meaningful hostile creature Resonance Marked by you is reduced to 0 Hit Points, banished, or forced to flee by you or an ally.

You can gain Mandate from a given creature only once per scene. Mandate lasts for the scene. It is not Resonance and cannot be transferred, stored between encounters, or generated by harmless summoned creatures, willing allies, captives repeatedly commanded, or collusive farming.

### CL3 — Commanding Voice

**Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance

Speak one brief command to one creature that can hear you or spiritually perceive your authority. The target makes a Wisdom saving throw.

On a failed save, the target follows the command on its next turn to the best of its ability. Choose or phrase a command equivalent to one of these:

- **Approach:** Move toward a legal space you indicate by the safest reasonably direct route.
- **Drop:** Drop one held object that is not fused to the body or protected by a stronger Source Rule.
- **Flee:** Spend its movement moving away from you by a reasonably safe route.
- **Halt:** Its Speed becomes 0 and it takes no voluntary movement.
- **Kneel:** Fall Prone and do not stand until the end of the turn.
- **Silence:** Do not speak or use an audible technique until the end of the turn.
- **Yield:** Take the Dodge action and do not make hostile attacks until the end of the turn.

The creature may still take actions not contradicted by the command. The command cannot force direct self-harm, compel use of a limited Secret or artifact resource, reveal information the target does not know, violate an absolute Source Rule, or require an impossible action.

On a failed save, the target also becomes Resonance Marked by you and you gain 1 Mandate if it is meaningful and hostile.

On a successful save, choose one ordinary Spiritual Pressure effect.

#### Voice of Office

You may use Wisdom instead of Charisma for Persuasion or Intimidation checks made to issue formal commands, adjudicate a dispute, demand surrender, or speak from a recognized office. This does not force compliance and applies only when the authority claim is intelligible in the scene.

### CL6 — Break Their Will

When your authority gains momentum, resistance becomes spiritually expensive.

#### Submission Shock

**Reaction**  
**Trigger:** A meaningful hostile creature within 60 feet is reduced to 0 Hit Points, surrenders, becomes Incapacitated through one of your Spirit Awakening effects, or fails a saving throw against Commanding Voice.  
**Cost:** 1 Mandate

Choose another hostile creature within 30 feet of the triggering creature that can perceive you, the creature, or the spiritual collapse. It makes a Wisdom saving throw.

**Failed Save:** It is **Dazed by Submission** until the end of its next turn. While Dazed this way, it cannot take Reactions, can take either an Action or a Bonus Action on its turn but not both, and its Speed is halved.

**Successful Save:** It suffers one ordinary Spiritual Pressure effect.

A creature can be targeted by Submission Shock only once per round.

#### Command the Marked

When you use Commanding Voice against a creature Resonance Marked by you, you may spend 1 Mandate instead of 1 Resonance. The creature still receives its saving throw.

### CL10 — Edict of Heaven

You impose one local law upon the conduct of lesser wills.

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance or 3 Resonance plus 2 Mandate  
**Duration:** Until the start of your next turn

Declare one clear edict and choose any number of creatures within range that can hear you or spiritually perceive you. Each target makes a Charisma saving throw.

Choose one printed edict:

- **No Advance:** The target cannot willingly move closer to a point or creature you designate.
- **No Escape:** The target cannot willingly move farther from a point or creature you designate.
- **No Reaction:** The target cannot take Reactions.
- **No Violence:** The target cannot make attacks or activate a technique whose immediate purpose is to deal damage.
- **No Speech:** The target cannot speak, issue audible commands, or activate an expressly Audible technique.
- **No Passage:** The target cannot teleport or cross a threshold you designate within range.
- **No [Named Expression]:** Name one technique, item activation, companion command, or repeated expression you have personally perceived the target use during the scene. The target cannot use that named expression.

On a failed save, the target must obey the edict for the duration. If it attempts a prohibited act, the act is wasted before costs are paid unless a stronger Source Rule says costs are committed on declaration.

On a successful save, the target resists the edict but suffers one ordinary Spiritual Pressure effect.

An edict cannot prohibit all actions, erase a Path, prevent passive defenses, force self-harm, suppress an unknown category, or forbid an entire Sphere or cultivation system without higher authority. Equal- or higher-Source-CL targets may use a Cultivation Check in place of the Charisma save if they are contesting the edict with a coherent Domain, throne, true name, oath, or comparable authority.

#### Mandate of Clarity

When a creature fails against Edict of Heaven, you know whether it understood the edict and whether a stronger Source Rule prevented full obedience. You do not learn the hidden Source Rule’s exact text.

### CL14 — Retainer of the Empty Throne

You can preserve a loyal, surrendered, or lawfully accepted soul-impression as a spiritual retainer. This Restricted expression is not automatic soul imprisonment.

#### Creating the Retainer

Conduct a 1-hour rite and spend 6 Resonance. You require one of the following:

- The willing agreement of a living or dead creature.
- The final acknowledged surrender of a meaningful foe whose soul is free to refuse.
- A lawful ancestral, institutional, or spiritual office whose previous holder accepts succession.
- A relic containing a consenting residual personality or office-imprint.

An unwilling full soul cannot be made into this Retainer without a separate Forbidden or Secret Source Rule. A fading combat impression can provide mannerisms and one simple combat expression, but is not the dead creature’s continuing consciousness.

You may maintain one Retainer at a time. It is a Spirit Cultivation Asset attached to your Soul Anchor.

#### Retainer Profile

**Bonus Action**  
**Cost:** 2 Resonance  
**Duration:** The scene

Manifest the Retainer in an unoccupied space within 30 feet.

- **Size:** Medium or smaller.
- **AC:** Your Cultivation Save DC.
- **Hit Points:** `6 × Proficiency Bonus`.
- **Speed:** Fly 30 feet; hover.
- **Source CL:** Your effective Spirit Awakening CL.
- **Resistances:** Psychic and Necrotic.
- **Immunities:** Poison, Disease, Poisoned, Prone, and ordinary bodily restraint.

The Retainer has no independent turn. At the end of your turn, it can move up to its Speed. Once on each of your turns, when you use Commanding Voice, Mind Spike, Domain Pressure, or Edict of Heaven, choose one Retainer expression:

- **Spectral Strike:** Make a melee or ranged Cultivation Attack from the Retainer against one target within 30 feet. On a hit, deal `2d8 + Wisdom modifier` Psychic, Necrotic, or Radiant damage, chosen when the Retainer is created.
- **Interpose:** One ally within 5 feet of the Retainer gains Temporary Hit Points equal to `2 × Proficiency Bonus`.
- **Herald:** Extend the audible or spiritually perceptible origin of Commanding Voice or Edict of Heaven from the Retainer.
- **Counsel:** Gain Advantage on one Insight, Persuasion, Religion, History, or Intimidation check whose subject falls within the Retainer’s established office or memory.

If destroyed, the Retainer becomes dormant until you complete a Full Cultivation Session. Its underlying soul or office is not destroyed unless a higher-authority effect explicitly attacks it.

#### Soul Splitting Expression — Twin Heralds

While both your Retainer and Soul Fragment exist, use **Twin Heralds** as your Subpath Expression: move the Retainer up to 15 feet, and one creature Resonance Marked by you within 30 feet of either Asset cannot take Reactions until the start of your next turn.

### CL18 — Hegemon’s Domain

Your Domain becomes a court in which your authority is locally real.

When you activate Domain Manifestation, you may spend 4 additional Resonance to transform it into **Hegemon’s Domain** for the scene. This is part of the same activation and does not require Concentration.

While active:

#### Court of Submission

At the start of each hostile creature’s turn in the Domain, if it can perceive you or one of your spiritual Assets, it makes a Charisma saving throw.

- **Failed Save:** Its Speed is halved, it cannot take Reactions, and the first time during the turn it attempts to act directly against you, resolve the **Court Tax** before the action's effects. If the action or technique has a printed expendable cost, increase one such cost by 1 unit of the same resource; the acting creature chooses among multiple eligible printed resources. If it cannot or will not pay, or if the action has no printed expendable cost, it instead takes Psychic damage equal to `2d10 + Wisdom modifier` before resolving the action. The damage does not cancel the action unless it incapacitates the creature or another rule does so.
- **Successful Save:** Choose either Speed reduced by 10 feet or no Reactions until the start of its next turn.

A creature makes this save only once per turn, regardless of how many Assets express your authority.

#### Lesser-Realm Command

When a hostile creature with Source CL at least 5 lower than yours fails a saving throw against Commanding Voice or Edict of Heaven inside the Domain, it does not repeat or negate that command through an ordinary legendary resistance, ordinary condition immunity, or mundane morale rule unless that protection expressly defeats spiritual command. It still cannot be ordered to perform impossible or directly self-destructive acts.

#### Equal Thrones

An equal- or higher-Source-CL creature may contest Court of Submission with a Cultivation Check instead of the Charisma save if it expresses a coherent sovereign identity, Domain, true name, oath, divine mandate, or equivalent authority. On a successful contest, it ignores Court of Submission until the start of its next turn, but does not suppress your Domain for other creatures.

#### Absolute Edict

Once during each activation of Hegemon’s Domain, use Edict of Heaven without spending Resonance. You may affect creatures anywhere in the Domain, and a failed target obeys until the end of its next turn rather than until the start of yours.

#### Price of Tyranny

If you knowingly use Hegemon’s Domain to command a willing ally into direct self-destruction, violate a freely accepted Soul Anchor oath, or enslave an unwilling Complete Soul, your Soul Anchor becomes Strained after the scene. Record the harmed creature, violated relationship, command, and result as a **Tyranny Breach**. The Strain ends only through the **Tyranny Restitution procedure** in the Procedure Addendum. This consequence does not classify every Sovereign Will cultivator as Forbidden; it classifies the abusive act.

### Normalized Sovereign Procedures

#### Mandate Qualification
Use the meaningful-event rules in the Procedure Addendum. A surrender or acknowledgment qualifies only if it changes the scene: the creature stops meaningful resistance, yields an objective or Asset, accepts custody, provides passage, or creates another material consequence. Repeating words under an already-resolved command does not generate Mandate.

#### Command Timing
A failed Commanding Voice takes effect on the target's next turn. It spends only the movement or action required by the selected command and can use remaining legal actions normally. **Yield** requires Dodge and forbids hostile attacks until the end of that turn but does not prohibit nonhostile aid, escape, or communication. A command that becomes impossible before the turn is spent attempting the nearest legal equivalent and then ends.

#### Court Tax
A printed expendable cost includes Resonance, Qi, Stamina, another Cultivation Point, a charge, a limited use, a Hit Die, a consumed Offering, a named buildup point, or a material that the action itself consumes. It does not include an Action, Bonus Action, Reaction, movement, Hit Points lost as an effect, Concentration, ammunition with no meaningful scarcity, or a resource paid by another creature. The Court Tax cannot increase a cost above the resource holder's available amount; inability to pay invokes the printed damage instead.

#### Retainer Record
When created, record whether the Retainer is a consenting Complete Soul, office-imprint, residual personality, or fading combat impression; its three knowledge domains; damage type; appearance; voice; consent or office basis; and lawful dissolution procedure. A fading impression has no private knowledge beyond what the creating scene revealed. A consenting Complete Soul retains personhood and may withdraw according to the recorded agreement unless a separate lawful office or Bond states otherwise.

#### Retainer Asset Closure
The Retainer is a Medium-or-smaller Spirit Cultivation Asset, occupies its space, flies with hover, and is immune to Charmed, Frightened, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained, Poison damage, and ordinary disease. It acts only through the printed end-of-turn movement and one expression attached to your listed activation. At 0 Hit Points it becomes dormant as printed; it does not make death saves and cannot be healed by ordinary creature healing.

#### Tyranny Restitution
To clear a Tyranny Breach, complete all applicable steps:

1. End the coercive command, custody, or enslavement if it still exists.
2. Restore the victim's legal freedom, Soul Anchor, body, Asset, or material position as far as your available authority permits.
3. Provide one concrete restitution chosen by the harmed creature or its lawful representative: return a seized Asset or office; accept one scene of equivalent service without command authority; publicly revoke the abusive edict before relevant witnesses; pay a material or spiritual Offering worth at least the original activation's total Resonance cost; or undertake one dangerous service directly repairing the harm.
4. Complete a Full Cultivation Session confronting the Breach. If the victim cannot be restored because of higher authority or death, the Breach remains recorded but the Soul Anchor Strain ends after steps 1, 3, and 4; future resurrection or reconstruction does not recreate the Strain automatically.

The victim cannot demand self-destruction, permanent enslavement, surrender of a character option, or a price exceeding the original harm as restitution under this procedure.

#### Realm Suppression
Mandate already earned remains until the scene ends but cannot power a feature above effective CL. A manifested Retainer becomes dormant if effective CL falls below 14 and resumes if suppression ends during the scene. Hegemon's Domain ends if effective CL falls below 18. Tyranny Breaches and Soul Anchor Strain remain.

### Integrated Procedure Closure — Sovereign Will

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Twin Heralds. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 03. Exorcist

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted exorcist lineage, temple office, spirit-court warrant, funerary scripture, demon-hunting sect, inherited true-name register, or apprenticeship under a qualified exorcist.  
**Identity:** Detection, diagnosis, separation, banishment, binding, purification, and destruction of unlawful spiritual intrusion.  
**Primary role:** Anti-possession specialist, spirit controller, curse surgeon, area purification, and high-authority expulsion.  
**Sphere Lean:** Spirit, Death, Radiance, Seals. This tradition grants none of those Spheres.  
**Cultivation boundary:** Exorcism removes an entity or influence that lacks a lawful or accepted right to remain. It does not automatically sever willing Spirit Companions, consensual hosted spirits, Soul Anchors, inherited ancestors, divine offices, or a creature’s own integrated spiritual nature.

> *What wears your face has no right to keep it.*

Exorcists cultivate the old laws of name, host, boundary, burial, invitation, and departure. They are most effective when they can identify the intruder, expose its route of entry, and establish why it has no right to remain.

### Exorcist Designations

When you use Soul Gaze on a willing creature, a Resonance Marked creature, a visible spirit, or a creature detected as possessed, you may assign one **Exorcist Designation** that lasts for the scene:

- **Intruder:** A possessing, parasitic, controlling, or unlawfully hosted entity.
- **Host:** The body, object, site, corpse, or soul being occupied.
- **Curse Source:** The entity, Anchor, object, vow, wound, or route sustaining a curse or contamination.
- **Restless Dead:** A ghost, undead soul, corpse-spirit, or funerary disturbance that should have passed on or reached lawful rest.
- **Lawful Guest:** A willing, accepted, ancestral, bonded, or otherwise legitimate spirit presence.

A Designation records your diagnosis; it does not make the diagnosis true by fiat. Use the Accepted Presence, Intruder, Host, Spiritual Affliction, and concealment procedures in the Spirit Awakening Rules Reference. If the target’s Source CL exceeds yours or the relevant presence, route, or Anchor is concealed, make a Cultivation Check against the opposing effect’s save DC. If no DC is printed, use the Authority DC in the Procedure Addendum. On failure, the Designation is recorded as **Contested**: you learn which category is uncertain, but Exorcist features that require a confirmed Intruder, Curse Source, or Restless Dead cannot use that Designation until you perceive new evidence or succeed on a later check.

Your Exorcist features never target a Lawful Guest as an Intruder unless the relationship has become coercive, corrupted, or revoked under its own Source Rule.

### CL3 — Ghost Sight and Name the Intruder

#### Ghost Sight

Your Spiritual Sense extends to 60 feet for the limited purpose of perceiving:

- Invisible spirits, ghosts, incorporeal undead, projected souls, possessing entities, and spirit parasites.
- The broad outline of a possession link between a Host and Intruder.
- Ordinary curses, spiritual contamination, corpse animation, and funerary disturbance.

Ghost Sight does not function as general Blindsight at that extended range. It does not reveal mundane hidden creatures, physical writing, concealed objects, or a spirit behind total cover. Equal- or higher-Source-CL concealment remains contested.

#### Name the Intruder

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one spirit, possessed creature, cursed creature, haunted object, or Resonance Marked creature you perceive. Use Soul Gaze’s normal diagnostic limits without requiring its Action. You may assign one Exorcist Designation.

If the target is an Intruder, Curse Source, or Restless Dead, it becomes Resonance Marked by you. If it succeeds on a Charisma saving throw, the mark is concealed until the start of your next turn but the Designation remains.

#### Ward of Invitation

You have Advantage on Cultivation Checks made to determine whether a possession, hosting, spirit bond, or haunting is willing, inherited, lawfully invited, coerced, or parasitic.

### CL6 — Banishment Strike

You turn a successful soul wound into a door of departure.

**Trigger:** An Intruder, Restless Dead, fiend, demon, hostile spirit, or possessed creature fails its saving throw against your Mind Spike.  
**Cost:** 2 Resonance

Choose the spirit being struck. If the target is a possessed creature, choose either the Host or the designated Intruder; ordinary Mind Spike damage still applies to the original target. The chosen spiritual target makes a Charisma saving throw.

#### Failed Save

Apply the result appropriate to the target:

- **Possessing Intruder:** It is forced out of the Host into the nearest legal unoccupied space within 10 feet. It is visible to Spiritual Sense and cannot repossess that Host until the end of the scene. If it has no legal independent manifestation, it is sealed in a temporary spiritual outline adjacent to the Host until the end of your next turn and is Incapacitated during that time.
- **Extraplanar Spirit, Fiend, or Demon:** It is banished from the current battlefield until the end of its next turn, then returns to the nearest legal space to where it departed. If its Source CL is at least 5 lower than yours and it is not anchored to the plane, it is instead expelled to its home plane for the scene.
- **Native Ghost, Undead Soul, or Restless Dead:** It is Frightened of you and cannot willingly move closer to its Host, corpse, grave, or sustaining Anchor for 1 minute. It repeats the save at the end of each turn.
- **Cursed or Contaminated Host:** Suppress one ordinary possession, curse, or spiritual contamination affecting it until the end of your next turn. The Host may immediately repeat one save the effect normally permits, with Advantage.

#### Successful Save

The chosen target suffers one ordinary Spiritual Pressure effect and cannot become hidden from your Ghost Sight until the start of your next turn.

#### Banishment Limits

Banishment Strike does not permanently destroy a soul, erase a Spirit Companion bond, override divine custody, dismiss a willingly hosted ancestor, or send an equal- or higher-Source-CL entity across planar boundaries without its printed Anchor or escape procedure.

### CL10 — Purification Bell

You manifest the spiritual law of a bell, chime, clap, drum, sutra, sword-ring, hand seal, or other tradition-appropriate purification sound.

**Action**  
**Area:** 30-foot Emanation  
**Cost:** 5 Resonance

Choose any number of creatures, spiritual Assets, haunted objects, and curse Anchors in the area. A hostile Intruder, Restless Dead, fiend, demon, undead spirit, or possessing entity makes a Wisdom saving throw.

**Failed Save:** It takes `6d8` Radiant or Psychic damage, chosen for each activation, becomes Resonance Marked by you, and is Frightened of you until the end of your next turn.

**Successful Save:** It takes half damage and cannot take Reactions until the start of its next turn.

A willing Host or ally in the area may instead receive one purification benefit:

- End one ordinary Frightened or Charmed condition caused by a spirit, curse, possession, or Heart Demon.
- Repeat one saving throw against possession, dream intrusion, memory alteration, or spiritual contamination with Advantage.
- Suppress one ordinary curse or spiritual contamination until the start of your next turn.
- Remove one Resonance Mark, ordinary Spiritual Pressure effect, or hostile spirit-tracking mark with Source CL lower than yours.

#### Resonant Exposure

Any invisible or incorporeal hostile spirit damaged by Purification Bell becomes visible as a spiritual outline until the end of your next turn. This does not make it corporeal.

#### Bell Against the Anchor

Instead of damaging a creature, you may target one spiritual Anchor or curse Anchor you can perceive in the area. Make a Cultivation Attack against its AC or a Cultivation Check against its save DC. On success, deal `6d8` Force or Radiant damage to the Anchor, or reduce the sustaining effect’s Source CL by 2 until the end of your next turn if it has no Hit Point profile. This cannot reduce Source CL below 1 and does not permanently alter the originating cultivator. Multiple uses of Bell Against the Anchor against the same sustaining effect do not stack their Source CL reductions; a later successful use refreshes the duration of the existing reduction.

### CL14 — Seal of Binding

You create an exorcist seal that restrains a designated spiritual threat and exposes its removal procedure.

**Action**  
**Range:** 30 feet  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Concentration:** No

Choose one Intruder, Restless Dead, fiend, demon, incorporeal undead, curse Source, hostile spirit Asset, or possessed creature you perceive. The target makes a Charisma saving throw.

#### Failed Save

Create a **Binding Seal Anchor** in an unoccupied space within 5 feet of the target or attach it visibly to the Host, object, corpse, threshold, or ground.

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `5 × Proficiency Bonus`.
- **Saving Throws:** Uses your Wisdom saving throw bonus.
- **Source CL:** Your effective Spirit Awakening CL.
- **Immunities:** Poison, Disease, Psychic damage, and ordinary bodily conditions.

While the Anchor remains:

- The target is Restrained.
- It cannot become invisible, incorporeal, or enter a Host unless the new state is an inherent passive quality that cannot be suppressed.
- It cannot teleport, cross planar boundaries, or move more than 30 feet from the Anchor.
- A possessing Intruder is forced out of its Host and remains adjacent to the Host or Anchor if it lacks a legal body.
- The target repeats the Charisma saving throw at the end of each of its turns. Three total successful repeat saves destroy the Anchor and end the effect. These successes need not be consecutive.

#### Successful Initial Save

The target is Restrained until the start of your next turn, becomes Resonance Marked by you, and you learn one of the following if it has one:

- Its immediate escape condition.
- Its sustaining Anchor category.
- Its invitation or possession route.
- The true name, title, taboo, burial need, payment, or unfinished obligation most relevant to peaceful resolution.

#### Breaking or Resolving the Seal

A creature can attack the Anchor if it can perceive and affect spiritual objects. Destroying it ends the binding but does not harm the target.

You, the Host, or an ally can also end the binding by completing one exposed lawful resolution. The resolution must be one of the following: **Revoke Invitation** by the willing Host or the authority that granted it; **Break or Suppress the Sustaining Anchor** through its printed profile; **Return Remains or Complete Burial** when that need was diagnosed; **Pay the Recorded Restitution or Offering**; **Speak the Recorded True Name or Release Formula** when a Source Rule grants it that function; **Accept Surrender and Provide a Legal Departure Route**; or **complete Spiritual Exorcism or another printed removal procedure**. A resolution cannot be invented after the seal is applied merely to deny the feature.

#### Soul Splitting Expression — Seal Warden

While Soul Splitting is active and a Binding Seal Anchor exists, use **Seal Warden** as your Subpath Expression. Move the Soul Fragment to a legal space adjacent to the Anchor. Until the start of your next turn, the Anchor has Resistance to all damage and the sealed target has Disadvantage on its next repeat saving throw.

### CL18 — Grand Exorcism

You invoke the full authority of departure, rightful hosting, burial, and spiritual boundary.

**Action**  
**Area:** 60-foot Emanation  
**Cost:** 10 Resonance

Choose any number of allies, Hosts, Intruders, Restless Dead, fiends, demons, undead spirits, possessions, curse Anchors, and hostile spirit Assets in the area. Each hostile chosen creature makes a Charisma saving throw.

#### Failed Save

The target takes `10d10` Radiant or Psychic damage and suffers the result appropriate to its nature:

- **Possessing Intruder:** It is forced out of every Host in the area, cannot repossess those Hosts for the scene, and is either manifested in a legal space or sealed in a visible spiritual outline. If its Source CL is at least 5 lower than yours and it has no independent legal existence on the plane, it is expelled for the scene.
- **Extraplanar Spirit, Fiend, or Demon:** If unanchored and of lower Source CL, it is expelled to its home plane. If anchored, its sustaining Anchor becomes revealed and it is Incapacitated until the end of its next turn.
- **Restless Dead or Native Ghost:** Choose to destroy a purely hostile residual imprint, send a willing soul onward, or reduce a coherent unwilling soul to 0 Hit Points without destroying it. A coherent soul with unfinished obligations may instead reveal the required funerary or narrative resolution.
- **Undead Body or Corpse-Spirit:** It is destroyed if reduced to 50 Hit Points or fewer by this activation. A unique equal- or higher-authority undead uses its own destruction and recovery rules.
- **Curse or Spiritual Contamination:** End one ordinary effect on each willing Host. Against equal or higher authority, suppress it for the scene and reveal its Source, Anchor, or recovery condition.
- **Hostile Spirit Asset or Anchor:** It takes double damage from the activation. If destroyed, the underlying full soul is not automatically destroyed unless the Asset’s Source Rule expressly makes them the same.

#### Successful Save

The target takes half damage, becomes Resonance Marked by you, and suffers one ordinary Spiritual Pressure effect.

#### Allied Purification

Each willing ally or Host chosen in the Emanation may immediately:

- End one ordinary Charmed or Frightened condition.
- Repeat one save against possession, curse, dream intrusion, memory alteration, or Spiritual Affliction or Heart Demon influence with Advantage.
- Return a displaced soul to its body if both are in the Emanation and no equal- or higher-authority seal prevents return.
- Suppress one equal- or higher-authority spiritual affliction until the end of the scene, provided you succeed on a Cultivation Check against its save DC.

#### High-Authority Limits

Grand Exorcism does not automatically destroy a deity, erase a Secret Law, annul a willing Soul Anchor, break a lawful Spirit Companion bond, reverse reincarnation, or release a soul held by higher Source CL without a contest and the relevant recovery procedure. It must still expose useful information or create a temporary opening when it cannot produce complete removal.

#### Domain Integration

When used inside your Domain Manifestation, Grand Exorcism treats every ordinary possession link, invisible hostile spirit, and lower-Source-CL curse Anchor in the Domain as perceived. You may originate the Emanation from yourself or your Soul Fragment.

### Normalized Execution Notes

- **Confirmed Designation:** a Designation is confirmed when the target is willing, the presence is openly manifested, the relevant Source Rule identifies the category, or you succeed on the required Cultivation Check.
- **One spiritual target:** when Banishment Strike follows Mind Spike against a possessed Host, the Mind Spike keeps its original target and damage. Banishment Strike separately chooses either the Host's qualifying Affliction or one perceived Intruder; it never damages both unless another Source Rule says so.
- **Nearest legal space:** use the legal-destination procedure in the Rules Reference. If no legal manifestation space exists, the temporary outline printed by the feature is used.
- **Grand Exorcism and Complete Souls:** “destroy a purely hostile residual imprint” applies only to a Spiritual Imprint or incomplete residue. A Complete Soul receives the coherent-soul result and retains the reconstruction, custody, and higher-authority protections of the Rules Reference.
- **Realm Suppression:** a Binding Seal Anchor already created at CL14 becomes dormant rather than destroyed if your effective CL falls below 14. Its target is no longer Restrained, but the Anchor resumes if your effective CL returns to 14 before the scene ends and the Anchor was not destroyed. Grand Exorcism ends immediately if your effective CL falls below 18.

### Integrated Procedure Closure — Exorcist

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Seal Warden. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 04. Ancestral Channeler

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted clan lineage, ancestor hall initiation, funerary inheritance, reincarnated family memory, bloodline scripture, adopted lineage rite, or acceptance by a council of the dead.  
**Identity:** Lineage memory, inherited offices, ancestral obligation, and controlled overshadowing by the remembered dead.  
**Primary role:** Flexible expertise, defensive possession, office-based support, ancestor manifestations, and full ancestral embodiment.  
**Sphere Lean:** Spirit, Mind, History, Medicine, War. This tradition grants none of those Spheres.  
**Cultivation boundary:** Ancestors provide memory, office, and spiritual force. They are not automatically full companions, cannot grant their complete old character sheets, and do not make bloodline morally superior to adoption, discipleship, marriage, oath-kinship, or accepted spiritual succession.

> *I stand alone only to those who cannot see the dead behind me.*

Ancestral Channelers cultivate a living relationship with a lineage of remembered dead. That lineage may be biological, adopted, institutional, sectarian, regional, or chosen. What matters is continuity and acceptance.

### Ancestor Offices

At CL3, choose two **Ancestor Offices** from the list below. An Office is a cultivated lineage role, not one specific full soul. At CL10, choose a third Office.

#### Archivist

Associated skills: History and Investigation.  
Associated expression: records, precedent, forgotten routes, names, and past events.

#### Healer

Associated skills: Medicine and Insight.  
Associated expression: diagnosis, pulse memory, funerary care, herbs, and bodily or spiritual stabilization.

#### Magistrate

Associated skills: Insight and Persuasion.  
Associated expression: testimony, mediation, authority, contracts, etiquette, and social procedure.

#### Warrior

Associated skills: Athletics and Intimidation.  
Associated expression: battlefield instinct, guard, pursuit, weapon memory, and courage.

#### Wayfarer

Associated skills: Perception and Survival.  
Associated expression: roads, weather, hidden paths, camps, omens, and regional memory.

#### Ritualist

Associated skills: Religion and one **Ritual Proficiency** chosen when you gain the Office: calligrapher’s supplies, carpenter’s tools, herbalism kit, mason’s tools, weaver’s tools, woodcarver’s tools, or one musical instrument used in funerary or shrine rites. The choice is recorded and changes only when the Office is retrained by a legal Source Rule.  
Associated expression: burial, shrines, wards, offerings, spirit etiquette, and ceremonial procedure.

An Office never grants weapon, armor, shield, Sphere, spell, or item proficiency unless a feature expressly says so.

### Ancestral Favor

You can hold Ancestral Favor equal to your Proficiency Bonus. When you gain this tradition, complete the **Lineage Covenant Record** in the Procedure Addendum: recognized membership, one active Need or Duty, one Taboo, one ordinary restitution, and one severe restitution. You begin each scene with 1 Favor if your Soul Anchor is not Strained and you have not knowingly violated the recorded Taboo since your last Full Cultivation Session.

Gain 1 Favor, up to your maximum, when you:

- Succeed on a meaningful check using an Ancestor Office’s associated skill.
- Protect a descendant, student, clan member, sworn kin, ancestral site, grave, archive, or duty recognized by your lineage.
- Fulfill a meaningful request, taboo, burial need, or obligation communicated by your ancestors.
- Accept a significant complication because you honored lineage duty instead of personal convenience.

A given act grants Favor only once. Favor lasts until the end of the scene. It cannot be farmed through trivial checks, invented ancestors, harmless repetitions, or collusive obligations.

### CL3 — Council of the Remembered

#### Ancestral Advice

When you make an ability check using a skill associated with one of your Ancestor Offices, you may spend 1 Favor to gain Advantage. If you have no Favor, you may spend 1 Resonance instead.

You may declare this after rolling but before the result is announced. If you already have Advantage, add your Proficiency Bonus to the check instead.

#### Ask the Lineage

**Ritual:** 10 minutes  
**Cost:** 1 Resonance

Ask your ancestors one question concerning lineage history, a person or place known to the lineage, an established duty, a burial matter, a repeated danger, or an Office’s field of knowledge.

The answer arrives as memory, dream, scent, gesture, borrowed handwriting, a voice, a remembered route, or a symbolic warning. The answer is truthful according to what the ancestors know, but may be incomplete, biased, outdated, divided among several ancestors, or framed by lineage values.

Ask the Lineage does not reveal facts no ancestor could know, bypass Secret concealment, or guarantee a strategically optimal answer.

#### Lineage Recognition

You can perceive willing ancestor spirits associated with your lineage within your Spiritual Sense. You know whether a manifested ancestor is accepted, disputed, forgotten, hostile, coerced, or falsely claiming membership, subject to a Cultivation Check against equal or higher concealment.

### CL6 — Possession by the Past

An ancestor can briefly move your spirit into a posture that survived this danger before.

**Reaction**  
**Trigger:** You fail a saving throw, fail an ability check associated with one of your Offices, or are hit by an attack while you can act.  
**Cost:** 1 Favor or 2 Resonance

Choose an Ancestor Office and resolve one effect:

- **Remembered Resistance:** Reroll the failed saving throw and use the new result.
- **Inherited Method:** Reroll the failed associated ability check and use the new result.
- **Old Guard:** Add your Wisdom modifier to your AC against the triggering attack, potentially turning it into a miss.

After resolving the effect, the ancestor’s posture lingers until the start of your next turn. During that time, you cannot use Possession by the Past again and cannot take Reactions other than opportunity attacks expressly permitted by the chosen Office’s Source Rule. This is ancestral adjustment, not the Dazed condition.

#### Disputed Possession

If your Soul Anchor is Strained, you violated a lineage taboo during the scene, or two ancestor factions openly disagree, using Possession by the Past costs 1 additional Resonance. The first time this occurs in a scene, you learn the subject of the dispute.

### CL10 — Legacy Made Present

Choose a third Ancestor Office.

#### Office Mastery

Choose one associated skill from each of your three Offices. Gain proficiency in it. If you already have proficiency, gain Expertise. If you already have Expertise, gain a permanent +1 bonus to checks with that skill instead.

This feature cannot grant more than a +1 permanent bonus to the same skill.

#### Borrow the Office

**Bonus Action**  
**Cost:** 2 Resonance  
**Duration:** 10 minutes

Choose one of your Ancestor Offices. Until the effect ends:

- You may use Wisdom for its associated skill checks.
- You understand relevant ordinary professional signs, etiquette, jargon, and procedures.
- Once on each of your turns, when you use a Spirit Awakening feature, apply the Office’s expression:
  - **Archivist:** Learn whether one visible spiritual effect or Asset has lower, equal, or higher Source CL than you.
  - **Healer:** One ally affected by your feature gains Temporary Hit Points equal to your Proficiency Bonus.
  - **Magistrate:** One creature Resonance Marked by you cannot knowingly speak a direct lie until the start of your next turn; it can remain silent or evade.
  - **Warrior:** One creature damaged by your feature cannot take opportunity attacks until the start of your next turn.
  - **Wayfarer:** Move yourself or one willing ally affected by your feature 5 feet without provoking opportunity attacks.
  - **Ritualist:** One ordinary curse, possession, or spiritual contamination revealed by your feature cannot become concealed until the start of your next turn.

You can maintain only one borrowed Office at a time.

### CL14 — Ancestral Legion

You manifest three lineage shades as one coordinated Spirit Cultivation Asset rather than three independent creatures.

**Action**  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Concentration:** No

Manifest the **Ancestral Legion** in three unoccupied spaces within 30 feet. Each shade represents one of your Ancestor Offices.

#### Shared Legion Profile

The Legion uses one shared profile:

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `10 × Proficiency Bonus` shared among all shades.
- **Speed:** Each shade flies 30 feet and hovers.
- **Source CL:** Your effective Spirit Awakening CL.
- **Resistances:** Psychic and Necrotic.
- **Immunities:** Poison, Disease, Poisoned, Prone, and ordinary bodily restraint.

The shades have no independent turns. At the end of your turn, move each shade up to its Speed. An area effect damages the shared Hit Point pool only once per activation even if it overlaps multiple shades, unless its Source Rule expressly damages each spiritual body separately.

Once on each of your turns, use a Bonus Action or spend 1 Favor to command one shade to perform one expression:

- **Advise:** One ally within 5 feet of the shade gains Advantage on its next ability check before the start of your next turn.
- **Interpose:** One ally within 5 feet gains Temporary Hit Points equal to `2 × Proficiency Bonus` and half cover against one attack originating on the opposite side of the shade.
- **Ancestral Strike:** Make a Cultivation Attack against one Resonance Marked creature within 30 feet of the shade. On a hit, deal `2d8 + Wisdom modifier` Psychic, Necrotic, Radiant, or Force damage, chosen according to the Office.
- **Carry the Message:** The shade travels up to 1 mile during the scene to deliver up to 25 words to a creature, grave, shrine, household, or institution recognized by the lineage. Wards and boundaries still apply.
- **Office Expression:** Apply the active Borrow the Office expression from the shade’s space without using your once-per-turn application.

If the Legion is reduced to 0 Hit Points, it becomes dormant until you complete a Full Cultivation Session. No ancestor is destroyed by ordinary Asset damage.

#### Soul Splitting Expression — Fourth Voice

While Soul Splitting and Ancestral Legion are active, use **Fourth Voice** as your Subpath Expression. Choose one Legion shade. It immediately performs Advise, Interpose, or moves up to its Speed without requiring your Bonus Action or Favor.

### CL18 — Ancestral Ascension

A great ancestor, composite lineage spirit, or perfected Office overshadows you without erasing your identity.

**Bonus Action**  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Concentration:** No

Choose one Ancestor Office as the Ascendant Office. You gain the following benefits:

- +2 AC.
- Advantage on Intelligence, Wisdom, and Charisma saving throws.
- You cannot be unwillingly possessed by an ordinary or lower-Source-CL effect.
- Borrow the Office for the Ascendant Office activates without cost and does not prevent you from maintaining one different borrowed Office.
- Once per turn when you activate a Spirit Awakening Path or Subpath feature, impose one ordinary Spiritual Pressure effect on one creature Resonance Marked by you within 60 feet.
- You may originate Spirit Awakening features from yourself, your Soul Fragment, or one Ancestral Legion shade, but each activation still has only one origin unless a Source Rule says otherwise.

#### Ascendant Office Authority

Once during the activation, invoke the Office’s greater expression:

- **Archivist — Precedent of the Dead:** Ask one precise question about a creature, site, technique, lineage, or spiritual event perceived during the scene. If any ancestor genuinely knew the answer, receive it. Otherwise learn the closest relevant precedent and one missing source needed for certainty.
- **Healer — Hands That Remember Life:** Touch one creature or affect one ally within your Domain. Restore `8d8 + Wisdom modifier` Hit Points and end one ordinary poison, disease, possession, curse, madness, or spiritual contamination.
- **Magistrate — Judgment of the Lineage Court:** One creature within 60 feet makes a Charisma saving throw. On failure, it must either cease one named hostile act for the scene or publicly state the genuine reason it refuses. A creature cannot be forced to reveal magically concealed information it does not consciously know.
- **Warrior — Thousand Battles in One Body:** Make one weapon attack, unarmed strike, or Cultivation Attack. On a hit, deal an additional `8d8` Force or Psychic damage and the target cannot take Reactions or regain Hit Points until the start of your next turn.
- **Wayfarer — Road Remembered Before Birth:** Move yourself and up to `Proficiency Bonus` willing creatures you can perceive to one legal place on the same plane that your lineage has physically reached and that you can name or identify through an accepted ancestral memory. Sealed boundaries and stronger route prohibitions still apply.
- **Ritualist — Ceremony Without Error:** Complete one ritual you know with a normal completion time of 8 hours or less as an Action, paying every printed Resonance, Cultivation Point, Offering, Hit Die, material, Anchor, and participant cost. The ritual must primarily perform one of these functions: spiritual diagnosis; ordinary exorcism or cleansing; burial or funerary passage; willing spirit communication; creation, repair, or consecration of a nonpermanent ward, vessel, shrine, or Spiritual Anchor; a recorded Offering, restitution, Bond renegotiation, or hospitality rite; or opening a legal same-plane route whose Source Rule already permits acceleration. The ritual’s Source CL cannot exceed yours. This expression cannot accelerate a breakthrough, training, Forged Technique creation, item creation, permanent companion creation, Complete-Soul reconstruction, resurrection, reincarnation, permanent transformation, Secret-Law initiation, tribulation, or any ritual that forbids acceleration.

#### Identity and Price

You remain the acting character. The ancestor cannot seize the character sheet, spend resources without your decision, or override player agency.

When Ancestral Ascension ends, make a Wisdom saving throw against your own Cultivation Save DC.

- **Success:** The ancestor withdraws cleanly.
- **Failure:** Gain 1 level of Exhaustion and your Soul Anchor becomes Strained until you complete a 1-hour reconciliation rite with the lineage.

If you acted directly against the recorded Lineage Taboo during the activation, the save automatically fails. This automatic failure is waived only when the prohibited act was the sole available way to prevent one of these recorded greater violations: the destruction of a Complete Soul; the permanent severance of the lineage’s recognized Soul Anchor; the death of a protected descendant, adopted successor, sworn kin, or student; or violation of a higher-ranked Duty written into the Lineage Covenant before the scene began.

### Normalized Lineage Procedures

#### Qualifying Favor Event
An Office check grants Favor only when at least one of the following is true: the check is opposed by a meaningful creature; the DC is at least `10 + Proficiency Bonus`; failure would consume a resource or close a route; or success directly protects or advances a recorded lineage Duty. One check can grant no more than 1 Favor, and the same unchanged obstacle cannot grant Favor twice.

#### Ancestor Knowledge Record
Ask the Lineage and Precedent of the Dead use actual ancestor knowledge. Before play, record at least three **Lineage Knowledge Domains** such as a region, institution, family era, profession, war, migration, scripture, burial network, or spirit court. A question inside a recorded domain can receive a direct answer if an ancestor knew it. Outside those domains, the feature returns the nearest precedent and identifies the missing witness, record, era, or location required for certainty.

#### Office and Possession Boundary
Possession by the Past and Ancestral Ascension are Accepted Presences. They use your action economy, Hit Points, Concentration, resources, and decisions. They do not create a second turn, grant an ancestor’s complete statistics, or let an ancestor override player agency. If a hostile effect contests the presence, use the Hosting rules in the Rules Reference with you treated as a willing Host.

#### Ancestral Legion
Each shade's Office is chosen when manifested and cannot change during that activation. The shared pool takes damage only once from one activation, even if several shade spaces overlap it. A shade cannot carry a creature, manipulate an item, flank as an independent creature, or satisfy a requirement for an additional ally unless an expression expressly says so.

### Integrated Procedure Closure — Ancestral Channeler

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Fourth Voice. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 05. Miko

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted shrine initiation, hereditary or adopted shrine office, covenant with a kami, purification lineage, sacred-dance scripture, or acceptance by a recognized local spirit court.  
**Identity:** Shrine service, reciprocal sacred ground, purification, offerings, omen-bearing messengers, divine whispers, and controlled kami descent.  
**Primary role:** Preventive protection, ritual purification, area support, communication, and temporary divine embodiment.  
**Sphere Lean:** Spirit, Life, Dreams, Radiance, Nature. This tradition grants none of those Spheres.  
**Cultivation boundary:** A Miko petitions, hosts, serves, and negotiates with kami. She does not automatically command every local spirit, create a full companion, copy a deity’s stat block, or treat divine favor as unconditional ownership.

> *A shrine is not a building. It is the place where the unseen agrees to listen.*

Miko traditions cultivate reciprocity. Their authority is strongest where service, offerings, boundaries, cleanliness, memory, and local relationship have created a place in which mortal and spirit agree to recognize one another.

### Offerings

You can prepare a number of **Offerings** equal to your Proficiency Bonus. An Offering may be an ofuda, folded paper, candle, prayer strip, bell cord, salt packet, cup of water or sake, flower, food portion, thread, mirror chip, carved token, or another culturally appropriate object.

Preparing all missing Offerings requires 10 minutes of shrine work, prayer, dance, cleaning, calligraphy, or arrangement and ordinary inexpensive materials. An Offering lasts until used, profaned, or you prepare a replacement beyond your maximum. An Offering becomes **Profaned** only if it is deliberately destroyed, knowingly used to violate the recorded Shrine Covenant, contaminated by an equal- or-higher-Source-CL profanation effect, or left inside a Sacred Ground whose Shrine Anchor is profaned.

Offerings are simple ritual implements, not magic items. Another creature cannot activate your Offering unless a feature says otherwise. You cannot sell prepared Offerings as permanent magic assets.

Several Miko features allow Resonance to replace an Offering or an Offering to reduce Resonance cost. Unless stated otherwise, one activation can consume only one Offering.

### CL3 — Purification Dance

You learn two forms of Purification Dance.

#### Brief Purification

**Action**  
**Range:** Touch  
**Cost:** 1 Offering or 2 Resonance

Touch one willing creature, object, corpse, threshold, or 5-foot space. Choose one result:

- End the Poisoned condition if caused by an ordinary poison.
- Grant Advantage on the target’s next save against an ordinary disease, curse, possession, Frightened effect, dream intrusion, or spiritual contamination before the end of the scene.
- Remove one ordinary Resonance Mark, tracking mark, minor curse-sign, spiritual scent, or contamination with Source CL lower than yours.
- Suppress one ordinary possession, curse, or spiritual contamination until the start of your next turn.
- Make one invisible ordinary spirit, curse residue, or possession trace visible to Spiritual Sense until the end of your next turn.

Brief Purification cannot end severe disease, a permanent curse, a Heart Demon, willing possession, divine punishment, Secret-Law effect, or equal/higher-Source-CL contamination without a check and its proper recovery condition.

#### Full Purification Dance

**Ritual:** 1 minute  
**Range:** Touch  
**Cost:** 1 Offering and 1 Resonance

End one ordinary poison, disease, curse, minor possession, nightmare residue, or spiritual contamination affecting the target. Against an equal- or higher-Source-CL effect, make a Cultivation Check against its save DC. On success, choose one:

- End it if its Source Rule permits ordinary removal.
- Suppress it until the target completes its next Full Cultivation Session.
- Reveal its Source, Anchor, taboo, offering, restitution, or recovery condition.
- Prevent it from worsening until the end of the next scene.

#### Shrine Etiquette

You may use Wisdom instead of Intelligence for Religion checks concerning kami, shrines, local spirits, offerings, purification, funerary boundaries, and sacred customs.

### CL6 — Minor Kami Favor

Choose two **Minor Kami Favors**. You may change one chosen Favor when you complete a breakthrough or receive initiation at a suitable shrine.

#### Favor of Clear Water

**Action; Range 30 feet; Cost 1 Resonance.** One willing creature regains Hit Points equal to `1d8 + Wisdom modifier`. A creature can benefit from this Favor only once per scene.

#### Favor of the Guiding Wind

**Bonus Action; Range 30 feet; Cost 1 Resonance.** Move one willing creature 10 feet to a legal unoccupied space it can reach without crossing total cover, a sealed boundary, or unsupported space. This movement does not provoke opportunity attacks.

#### Favor of the Hearth

**Reaction; Cost 1 Resonance.** When you or an ally within 30 feet makes a saving throw against Frightened, Charmed, possession, cold, starvation, exhaustion caused by travel, or hostile emotional influence, add your Proficiency Bonus after the roll but before the result is announced.

#### Favor of the Harvest

**Ritual: 10 minutes; Cost 1 Offering.** Purify enough ordinary food and water for `10 × Proficiency Bonus` creatures, reveal ordinary poison or spoilage in it, and cause it to remain wholesome for 24 hours.

#### Favor of the Lantern

**Action; Range 60 feet; Cost 1 Resonance.** Reveal ordinary invisible spirits, ghosts, possession traces, and spiritual concealment in a 10-foot-radius sphere centered on a point you can perceive until the start of your next turn. Equal or higher concealment requires a Cultivation Check.

#### Favor of the Shrine Hound

**Bonus Action; Cost 1 Offering; Duration the scene.** Create a Tiny paper, smoke, light, fox, dog, bird, or lion-dog messenger. It has AC 12, 1 Hit Point, fly or walking Speed 40 feet, and can carry one Tiny object or 25-word message. It cannot attack, use Help in combat, activate items, or pass sealed boundaries.

#### Shrine Recovery

After 10 minutes of prayer, cleaning, dance, offerings, or shrine service, recover additional Resonance equal to your Proficiency Bonus. You can receive this additional recovery once between Full Cultivation Sessions, and only if you have spent Resonance since the previous use. This is an out-of-combat cultivation procedure and does not create a combat activation.

### CL10 — Sacred Ground

You establish a reciprocal sanctuary rather than merely projecting a hostile aura.

**Action**  
**Area:** 20-foot-radius sphere centered on a point within 30 feet  
**Cost:** 5 Resonance and 1 Offering  
**Duration:** 1 hour  
**Concentration:** No

Place or suspend the consumed Offering as a visible **Shrine Anchor** at the center.

#### Shrine Anchor Profile

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `5 × Proficiency Bonus`.
- **Source CL:** Your effective Spirit Awakening CL.
- **Immunities:** Poison, Disease, and Psychic damage.
- It can be perceived by Spiritual Sense and by creatures able to perceive sacred or spiritual objects.

Sacred Ground ends if the Anchor is destroyed, willingly dismissed, or moved more than 5 feet. When you create it, choose one **Profanation Condition** from the Procedure Addendum and record it on the Anchor. The Ground is profaned only when that exact condition occurs inside the Ground and the responsible creature knowingly performs the act.

Choose one **Ground Aspect** when you create it:

#### Purifying Ground

Allies in the Ground have Advantage on saves against possession, curses, disease, poison, Frightened, and spiritual contamination. A willing ally that starts its turn there can repeat one save against an ongoing qualifying effect once per scene.

Hostile undead, fiends, demons, and Intruders have Disadvantage on the first attack roll they make each turn in the Ground.

#### Welcoming Ground

Willing spirits, ancestors, kami, projected souls, and Spirit Companions in the Ground can communicate intelligibly with creatures they could normally reach through language, emotion, image, or spiritual impression. This does not grant universal knowledge or remove a spirit’s Taboo.

A hostile spirit that enters for the first time on a turn makes a Charisma saving throw. On failure, it cannot take hostile actions until the start of its next turn unless attacked.

#### Restorative Ground

A willing creature that spends at least 10 minutes resting in the Ground regains additional Hit Points equal to `2 × your Spirit Awakening CL` when it spends one or more Hit Dice and gains Advantage on its next save against Exhaustion, Heart Demon escalation, dream intrusion, or spiritual contamination before the target completes its next Full Cultivation Session.

A creature can receive this restorative benefit only once between its Full Cultivation Sessions.

#### Sacred-Ground Collision

An equal- or higher-Source-CL Domain, desecration, curse field, or hostile shrine can contest one Ground law with a Cultivation Check. Losing the contest suppresses only the contradictory law until the start of the winner’s next turn unless a Source Rule says otherwise.

### CL14 — Kami’s Messenger

Your messengers can cross the border between ordinary distance and recognized spiritual relationship.

#### Omen Message

**Action**  
**Cost:** 3 Resonance and 1 Offering

Send a message of up to 25 words to one creature you have met, one recognized shrine, one willing ancestor, one bonded spirit, or one community that knows your shrine name. The target must be on the same plane.

The message arrives within 1 hour through one chosen omen form: dream, foxfire, reflected text, moving paper charm, bird call, shrine sign, sudden scent, or writing produced by an unattended brush. The form is cosmetic and grants no concealment, control, damage, item activation, or additional information. The recipient knows the message is spiritually sent and can send a response of up to 25 words if willing.

Omen Message cannot cross a sealed planar boundary, reach a creature whose soul is completely hidden by equal or higher Source CL without a Cultivation Check, or force a target to read or answer.

#### Petition the Local Kami

**Ritual:** 10 minutes  
**Cost:** 4 Resonance and 1 Offering

Petition the most relevant willing local kami, shrine spirit, land memory, river presence, household spirit, grave guardian, or equivalent minor authority. Ask for one service:

- Reveal one recent spiritual disturbance within 1 mile.
- Identify the direction of a known spirit, curse, shrine, grave, possession, or sacred boundary within 1 mile.
- Carry a message or Tiny object within 10 miles through a legal route.
- Grant safe passage through one ordinary environmental or spiritual inconvenience under the kami’s authority.
- Provide one omen concerning a proposed action within the next day.
- Consecrate one additional Sacred Ground Aspect on an existing Shrine Anchor for 1 hour.

The petition uses the **Kami Petition Price** procedure in the Procedure Addendum. The kami either accepts the printed cost or names exactly one additional recorded price from that procedure. You learn the exact price before accepting and may decline without losing the Resonance or Offering. A local kami cannot grant power outside its recorded Nature, jurisdiction, or Source CL.

#### Manifest Messenger Asset

As an Action, spend 4 Resonance to manifest one previously contacted willing messenger kami for the scene. It is a Small Spirit Cultivation Asset:

- **AC:** Your Cultivation Save DC.
- **Hit Points:** `4 × Proficiency Bonus`.
- **Speed:** 40 feet; choose fly, climb, swim, or walking when contacted.
- **Source CL:** Your effective Spirit Awakening CL.
- **Resistances:** Psychic.

It has no independent turn. At the end of your turn, it moves up to its Speed. Once on each of your turns after you use a Miko or Spirit Awakening support feature, it can deliver that feature’s touch or 30-foot-range effect from its space if the feature is not hostile and does not create another Asset.

If destroyed, it returns to its shrine or local spirit state and cannot be manifested again until you complete a Full Cultivation Session or make restitution required by its Taboo.

#### Soul Splitting Expression — Procession of Two Worlds

While Soul Splitting is active, use **Procession of Two Worlds** as your Subpath Expression. Move your Soul Fragment or Manifest Messenger up to 20 feet. One willing creature adjacent to the moved Asset gains Advantage on its next save against possession, curse, Frightened, or spiritual contamination before the start of your next turn.

### CL18 — Kami Descent

A willing greater kami or perfected shrine office descends into your cultivated spirit. This is negotiated hosting, not uncontrolled possession.

**Bonus Action**  
**Cost:** 10 Resonance and 1 Offering  
**Duration:** The scene  
**Concentration:** No

Choose one **Descent Aspect** appropriate to your shrine or covenant. You gain the universal benefits and the chosen Aspect.

#### Universal Benefits

- +2 AC.
- Choose one Descent Movement when the covenant is recorded: **Heavenly Flight** (Fly 60 feet and hover), **Sacred Ascent** (Climb 60 feet, including ceilings), **River Passage** (Swim 60 feet and breathe air and water), or **Processional Step** (walking Speed becomes 60 feet and you ignore nonmagical difficult terrain and liquid surfaces). Kami Descent grants the recorded movement.
- Advantage on saving throws against possession, curses, Frightened, Charmed, and spiritual contamination.
- Ordinary and lower-Source-CL spirits recognize the manifest kami authority and cannot disguise their broad Nature from your Spiritual Sense.
- Your Brief Purification and Minor Kami Favors can originate from you, your Soul Fragment, your Shrine Anchor, or your Manifest Messenger, but each activation still uses only one origin.

#### Descent of Purity

Once per turn when you spend Resonance on a Miko or Spirit Awakening feature, one willing creature affected by that feature regains Hit Points equal to your Wisdom modifier or repeats one save against possession, curse, poison, disease, Frightened, or spiritual contamination.

Once during the Descent, use **Kami Purification** as an Action without additional Resonance or Offering cost. Choose up to your Proficiency Bonus willing creatures within 60 feet. Each chosen creature selects one benefit: end one ordinary Charmed or Frightened condition; repeat one saving throw against possession, curse, dream intrusion, memory alteration, Spiritual Affliction, or Heart Demon influence with Advantage; return its displaced soul to its body if both are within 60 feet and no equal-or-higher-authority seal prevents return; or suppress one equal-or-higher-Source-CL Spiritual Affliction until the end of the scene if you succeed on a Cultivation Check against its save DC. Kami Purification grants no hostile damage, soul destruction, planar expulsion, or Anchor damage.

#### Descent of Protection

You and allies within 20 feet gain Resistance to Psychic and Necrotic damage. Once per round when an ally in that aura takes damage, use your Reaction and spend 1 Resonance to reduce the damage by `2d10 + Wisdom modifier`.

Once during the Descent, create Sacred Ground without an Offering or Resonance cost. It lasts only until the Descent ends and uses no destructible Anchor; it is centered on you and moves with you.

#### Descent of Revelation

Your Spiritual Sense becomes 120 feet and can perceive through ordinary walls up to 5 feet thick for the limited purpose of detecting spirits, souls, possession, curses, dream intrusion, spiritual Assets, and sacred or profane Anchors. Total cover still prevents ordinary targeting.

Once during the Descent, ask the descending kami three questions concerning the current site, spiritual conflict, local history, or an entity the kami can perceive. The kami answers truthfully according to its knowledge and Nature.

#### Descent of Renewal

At the start of each of your turns, one willing creature you can perceive within 30 feet regains Hit Points equal to your Wisdom modifier if it has at least 1 Hit Point.

Once during the Descent, touch one creature and restore `8d8 + Wisdom modifier` Hit Points, end one ordinary poison or disease, and suppress one curse, possession, Heart Demon, or spiritual contamination for the scene. Equal or higher authority requires a Cultivation Check.

#### Reciprocity and Taboo

When Kami Descent ends, the kami withdraws. If you upheld its Nature and Taboo, no automatic Exhaustion is gained.

If you knowingly violate the recorded Taboo during the Descent, apply the recorded **Taboo Consequence** immediately: one of the four consequences below must have been selected when the Shrine Covenant was created.

- Gain 1 level of Exhaustion.
- Your Soul Anchor becomes Strained until you complete the recorded Restitution.
- Lose access to one recorded Minor Kami Favor until you complete the recorded Restitution.
- Your Shrine Anchor and Manifest Messenger become unavailable until you complete the recorded Restitution.

The covenant also records one Restitution from the Procedure Addendum. The consequence cannot be changed after the breach and the GM or AI does not invent a harsher replacement during resolution.

A kami cannot use Descent to seize control of the character without a separate hostile possession procedure and saving throw. You remain the acting character.

#### Domain Integration

If Domain Manifestation is active when you use Kami Descent, your Domain becomes recognized sacred territory for the duration. Sacred Ground effects you create inside it use the Domain’s boundary if smaller, and willing spirits inside can communicate through spiritual impression even without a shared language.

### Normalized Shrine and Kami Procedures

#### Shrine Covenant Record
When you gain this tradition, record: shrine or kami name; Spirit Nature; jurisdiction; one Taboo; one Taboo Consequence; one Restitution; Descent Movement; and the visual form of your Offerings. A new recognized shrine or willing kami can replace the record only through a 1-hour covenant rite and mutual consent.

#### Profanation Conditions
Choose one for each Sacred Ground: **Blood Desecration** (a creature willingly kills a helpless creature in the Ground); **Broken Hospitality** (you or a designated ally attacks a willing spirit that entered under declared hospitality before giving it a legal chance to depart); **Pollution** (a creature deliberately introduces poison, corpse filth, or spiritually contaminated matter to corrupt the Ground); or **Covenant Violation** (the recorded Shrine Taboo is knowingly violated in the Ground). Ordinary combat, accidental blood, a hostile spirit attacking first, or environmental dirt does not profane the Ground.

#### Sacred-Ground Collision
A contest suppresses one contradictory Ground law only; it never destroys the Shrine Anchor or ends the other Ground Aspects unless the hostile Source Rule expressly says so. A single hostile field makes at most one collision check when it enters or is created, and again only if its Source CL or governing law materially changes.

#### Manifest Messenger
The messenger's movement mode is chosen when first contacted and recorded. Its delivery-origin permission does not extend a feature beyond the feature's printed range measured from the messenger, does not bypass total cover when the delivered feature cannot do so, and cannot deliver Kami Purification, Sacred Ground, Kami Descent, or another Asset-creating feature.

### Integrated Procedure Closure — Miko

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Procession of Two Worlds. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 06. Mudang

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted spirit-service lineage, village gut tradition, hereditary mediumship, masked ritual house, drum lineage, or initiation by a qualified officiant and consenting spirit court.  
**Identity:** Ecstatic dance, drumming, public spirit negotiation, embodied trance, healing, and controlled spirit-riding.  
**Primary role:** Mobile support, spirit revelation, negotiated hosting, condition relief, and temporary manifestation.  
**Sphere Lean:** Spirit, Death, Dreams, Music. This tradition grants none of those Spheres.  
**Cultivation boundary:** A Mudang invites, negotiates, hosts, or contains spirits through embodied ritual. The tradition does not automatically command every nearby spirit, copy a spirit’s full statistics, erase a spirit’s Nature or Taboo, or convert a visiting spirit into a permanent companion.

> *The drum opens the door. Courtesy determines what crosses it.*

Mudang practice is deliberately visible. Rhythm announces the negotiation, dance makes the body a lawful threshold, and the gathered community witnesses who entered, what was promised, and whether the guest departed cleanly. Where a Miko stabilizes sacred ground through shrine reciprocity, a Mudang carries the rite in breath, blood, drum, and motion.

### Trance Rhythm

Several Mudang features use **Trance Rhythm**.

- Your Trance Rhythm begins at 0 at the start of each scene.
- Its maximum equals your Proficiency Bonus.
- Once on each of your turns, you gain 1 Trance Rhythm when at least one of the following occurs:
  - You move at least 10 feet while consciously maintaining a dance, chant, drumbeat, bell pattern, or other audible or embodied ritual.
  - A meaningful hostile creature fails a saving throw against one of your Spirit Awakening features.
  - You spend Resonance to protect, diagnose, stabilize, exorcise, or heal another creature.
  - A willing spirit accepts an invitation, offering, or negotiated limitation from you.
- You cannot gain Trance Rhythm from harmless summons, allied creatures deliberately failing saves, repeated staged possessions, captive spirits used for practice, or a ritual with no meaningful uncertainty.
- Trance Rhythm lasts for the scene and is not Resonance.
- Silence does not automatically end your dance if you can continue through movement, breath, or percussion transmitted through a surface, but a Source Rule that suppresses both your bodily rhythm and spiritual expression can prevent gaining new Rhythm.

### CL3 — Spirit Dance

**Bonus Action**  
**Cost:** 1 Resonance  
**Duration:** The scene

Begin a Spirit Dance. Choose one **Dance Step** when you activate the feature and again at the start of each of your turns. You may choose the same step repeatedly.

#### Warding Step

Until the start of your next turn, you and one ally within 10 feet gain a bonus equal to half your Proficiency Bonus, rounded up, to the first Intelligence, Wisdom, or Charisma saving throw each makes.

#### Guiding Step

Choose one creature within 30 feet that can perceive your rhythm. It may move 10 feet without provoking opportunity attacks from spirits, incorporeal undead, or creatures Resonance Marked by you. This movement does not use the creature’s Reaction.

#### Settling Step

Choose one willing creature within 10 feet. It may suppress one ordinary Frightened effect, one ordinary Spiritual Pressure effect, or one minor possession symptom until the start of your next turn. Suppression does not remove the underlying effect and does not grant a new saving throw.

#### Divining Step

Spend 1 Trance Rhythm and choose a present concern, nearby spirit disturbance, proposed course of action, or omen-bearing object. Determine one symbolic impression from the following procedure: **Favorable** if the proposed next step has a known material advantage and no known immediate severe danger; **Dangerous** if it leads into a known hostile threat, trap, severe hazard, or Spiritual Affliction; **Divided** if both a material advantage and a severe danger are present; **Concealed** if equal-or-higher authority blocks the answer or the required evidence is absent; **Spiritually Contaminated** if a spirit, curse, possession, corpse influence, dream intrusion, or profane Anchor is materially shaping the result. If more than one category applies, reveal all applicable categories. The impression concerns the immediate scene or the next declared step, not a distant guaranteed future.

A protected mystery, Secret Law, divine concealment, or equal- or higher-Source-CL deception can require a Cultivation Check. On failure, you learn that the omen is obscured or contested rather than receiving false certainty.

#### Spirit-Service Training

Gain proficiency in Performance or Religion. If already proficient in both, gain proficiency in Medicine or Insight instead.

### CL6 — Possession Trance

You can invite a minor spirit expression to ride your body without creating a second creature or granting the spirit an independent turn.

**Bonus Action**  
**Cost:** 2 Resonance and 1 Trance Rhythm  
**Duration:** The scene

Choose one **Guest Seat** from the four printed seats. A Guest Seat is a cultivated office-expression and is always mechanically available; an actual local spirit is not required. Its appearance and personality may reflect your lineage, current location, or an established spirit relationship, but this cosmetic choice cannot add or remove abilities.

#### Road Guest

Your Speed increases by 10 feet, you ignore nonmagical difficult terrain, and once on each of your turns after moving at least 20 feet, you may move one willing adjacent creature 5 feet with you.

#### Watchful Guest

You gain a 10-foot increase to Spiritual Sense, Advantage on Perception checks involving spirits or possession, and cannot be surprised by a spiritually perceptible creature while conscious.

#### Guardian Guest

Gain `2 × Proficiency Bonus` Temporary Hit Points when the guest enters. Once per round when you or an ally within 10 feet takes Psychic, Necrotic, or Radiant damage, reduce that damage by your Wisdom modifier.

#### Healing Guest

Once on each of your turns when you use Settling Step, Spiritual Exorcism, Medicine, or another legal healing procedure on a creature, it regains Hit Points equal to your Proficiency Bonus or gains that many Temporary Hit Points. A creature can receive this benefit only once per round.

You may change Guest Seats as a Bonus Action by spending 1 Trance Rhythm. You cannot host more than one Guest Seat through this feature at a time.

#### Guest Conduct

A Guest Seat is a negotiated expression, not a captured full spirit. It cannot speak private information it does not know, activate Sphere talents, use limited spirit powers, violate its Nature or Taboo, or remain after the feature ends. If you knowingly order or force a guest to violate its recorded Taboo, the guest departs immediately and you cannot use Possession Trance again until you either complete a Full Cultivation Session or complete one recorded Guest Restitution: offer a valued item or sustenance; perform 1 hour of service within the spirit’s Nature; repair the immediate harm caused by the violation; or publicly acknowledge the violation before the witnesses of the rite. Choose the guest's Taboo and Restitution before it first enters during a scene.

### CL10 — Gut of Revealed Guests

You can establish a public ritual court in which spirits must either appear, declare concealment, or contest your authority.

**Ritual:** 10 minutes  
**Cost:** 4 Resonance  
**Required focus:** Drum, bells, cloth streamers, offering table, marked floor, ancestor board, or another recognizable gut instrument  
**Duration:** The scene

At the ritual’s completion, create a **Gut Circle** with a radius of 50 feet centered on the focus. The focus is a Spirit Anchor with:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `5 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Immunities:** Poison, Psychic, and ordinary bodily conditions
- **Ending:** The Circle ends if the Anchor is destroyed, you dismiss it, or the scene ends

Within the Circle:

- Ordinary spirits, ghosts, hosted entities, possessing creatures, projected souls, and incorporeal undead become visible to creatures you designate.
- A concealed spiritual creature with lower Source CL is revealed automatically. Equal or higher authority can contest revelation with a Cultivation Check.
- A spirit that speaks within the Circle cannot disguise whether it is willing, coerced, starving, bound, possessing, or acting under another spirit’s command, though it need not reveal every term or secret.
- You have Advantage on Insight, Medicine, Persuasion, and Religion checks made to diagnose or negotiate a spiritual disturbance.

#### Pacification Petition

**Action**  
**Range:** Any spirit in the Gut Circle  
**Cost:** 1 Trance Rhythm

Choose one spirit, ghost, hosted entity, or incorporeal undead. If it is willing, it ceases hostile action while negotiations continue. If it is hostile, it makes a Charisma saving throw.

**Failed Save:** It cannot willingly attack, possess, or spiritually contaminate a creature until the start of your next turn. It may defend itself, move, speak, bargain, or attempt escape. At the end of its turn, it repeats the save if the effect would continue.

**Successful Save:** It suffers one ordinary Spiritual Pressure effect and learns the broad terms you are offering.

Pacification is not domination. Attacking the spirit, breaking declared hospitality, or making an impossible demand ends the restraint immediately.

#### Public Diagnosis

Once during the ritual, use Soul Gaze on every willing creature in the Circle without additional Resonance. For each, learn only whether it is possessed, contaminated, cursed, spiritually wounded, or carrying a concealed guest. Protected details remain contested normally.

### CL14 — Greater Spirit Possession

You can host a willing greater spirit, accept a dangerous spirit under negotiated restraint, or temporarily contain an unwilling intruder inside your cultivated body.

**Action**  
**Range:** 30 feet  
**Cost:** 6 Resonance and 2 Trance Rhythm  
**Duration:** Concentration, up to 1 minute

Choose one spirit, ghost, incorporeal undead, projected soul, or possessing entity you can perceive.

#### Willing Guest

The spirit enters by agreement. Choose one **Hosted Trait Template** from the Procedure Addendum for which the spirit qualifies: Movement, Resistance, Sense and Speech, Spiritual Strike, Carrier, Phase Passage, Water Breathing, Light or Temperature, or Spirit Revelation. Record the chosen template when the spirit agrees to enter.

A Hosted Trait cannot be Legendary, Secret, divine, artifact-level, plot-defining, a full Sphere talent, a complete creature feature package, or a second turn.

#### Unwilling Intruder

The target makes a Charisma saving throw.

**Failed Save:** It is drawn into your body and **Contained**. While Contained, it cannot act, perceive beyond your body, possess another creature, or use external features. Choose one Hosted Trait Template from the Procedure Addendum for which the spirit demonstrably qualifies. At the end of each of its turns, it repeats the save, ending containment on a success and appearing in the nearest legal space.

**Successful Save:** It remains free, becomes Resonance Marked by you, and suffers one ordinary Spiritual Pressure effect.

If the target’s Source CL is at least 5 lower than yours and it is already Resonance Marked or restrained by your Gut Circle, it has Disadvantage on the initial save. Equal- or higher-Source-CL spirits retain every repeat save and can contest a proposed Hosted Trait that would exceed the feature’s authority.

#### Possession Strain

When the feature ends, make a Constitution saving throw against your own Cultivation Save DC if you hosted an unwilling spirit or a spirit with higher Source CL.

- **Success:** The guest departs cleanly.
- **Failure:** Take `4d10` Psychic damage and suffer the Possession Strain effect linked to the Hosted Trait: Movement, Carrier, or Phase Passage causes **Heavy Soul**; Resistance, Water Breathing, Light or Temperature causes **Stilled Intent**; Sense and Speech or Spirit Revelation causes **Opened Spirit**; Spiritual Strike causes **Shaken Purpose**. The effect lasts until the end of your next turn.

If you are reduced to 0 Hit Points during Greater Spirit Possession, the guest is expelled into the nearest legal space. It does not gain control of your body unless another Source Rule expressly allows that result.

#### Soul Splitting Expression — Second Drum

While Soul Splitting is active, your Soul Fragment may serve as the visible or audible ritual origin for Spirit Dance, Pacification Petition, or one Hosted Trait. This does not create a second guest, second use, or additional action.

### CL18 — Grand Mudang Procession

You call a greater manifestation into a moving court of drum, breath, ancestor, and local spirit authority.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Concentration:** No

Create a **Grand Spirit Procession**, a Huge Spirit Cultivation Asset occupying a 15-foot-square space within 30 feet. It may appear as a masked giant, ancestral palanquin, spectral animal, procession of banners, storm of paper spirits, or another lineage-appropriate manifestation.

#### Procession Profile

- **AC:** Your Cultivation Save DC
- **Hit Points:** `10 × Proficiency Bonus`
- **Speed:** 40 feet; it can hover
- **Saving Throws:** Uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic, Necrotic, Radiant
- **Immunities:** Poison, Disease, Poisoned, Prone, Grappled, Restrained, and ordinary bodily effects
- **Source CL:** Your effective Spirit Awakening CL
- **Action economy:** No independent turn. At the end of each of your turns, it moves up to its Speed. You direct one Procession Expression as a Bonus Action.

#### Procession Expressions

Choose one:

- **Spirit Strike:** Make a Cultivation Attack against a creature within 15 feet of the Procession. On a hit, deal `4d10 + Wisdom modifier` Psychic, Necrotic, Radiant, Thunder, or Force damage, chosen to fit the invited court.
- **Carry the Living:** Move one willing Large or smaller creature adjacent to the Procession with it. That creature has Half Cover until it leaves the Procession’s space.
- **Reveal the Hidden Court:** Until the start of your next turn, ordinary invisible spirits, projections, possessing entities, and lower-Source-CL spiritual disguises within 30 feet of the Procession are revealed.
- **Beat Back the Intruder:** One spirit, possessed creature, or incorporeal undead within 30 feet makes a Charisma saving throw. On a failure, move it up to 20 feet, end one ordinary possession it maintains, and impose one Spiritual Pressure effect. On a success, move it 5 feet or impose one Spiritual Pressure effect.
- **Communal Mending:** One creature within 15 feet regains `3d8 + Wisdom modifier` Hit Points and may repeat one saving throw against Charmed, Frightened, ordinary possession, or ordinary spiritual contamination.

A creature can benefit from Communal Mending only once per activation of Grand Mudang Procession.

#### Grand Hospitality

Spirits with lower Source CL cannot enter the Procession’s space, possess a creature inside it, or conceal their broad category from you without succeeding on a Charisma saving throw. A willing spirit may instead enter under hospitality and speak through the Procession without gaining control of it.

#### Destruction and Departure

If the Procession is reduced to 0 Hit Points, it disperses and you take `4d10` Psychic damage that ignores Resistance. You cannot use Grand Mudang Procession again until you complete a Full Cultivation Session.

The Procession ends cleanly if dismissed. Invited spirits depart with memory of how they were treated. A spirit is not permanently bound, duplicated, or converted into a companion by this feature.

### Normalized Hosting Procedures

#### Hosted Trait Templates
- **Movement:** gain one movement mode the spirit possesses, maximum Speed 60 feet. Choose fly with hover, climb including ceilings, swim with water breathing, or walking that ignores nonmagical difficult terrain. Burrowing, planar movement, and teleportation require a separate Source Rule.
- **Resistance:** gain Resistance to one damage type the spirit naturally possesses other than Bludgeoning, Piercing, or Slashing. If it has only physical Resistance, choose one of those three when the spirit enters.
- **Sense and Speech:** gain one language the spirit knows and one of Darkvision 60 feet, Tremorsense 30 feet, Blindsight 10 feet, or a 30-foot increase to Spiritual Sense. A sense cannot perceive through total cover unless its own rule says so.
- **Spiritual Strike:** gain one melee or ranged spiritual strike. It uses your Cultivation Attack Modifier, has 5-foot reach or 60-foot range selected when gained, and deals `2d10 + Wisdom modifier` damage of one type the spirit actually deals.
- **Carrier:** your carrying capacity doubles and you can carry one willing Medium-or-smaller creature without reducing Speed. You cannot carry it through a space it could not legally enter.
- **Phase Passage:** once on each of your turns, move through up to 5 feet of ordinary nonmagical material. You cannot end inside matter; sealed, warded, equal-or-higher-Source-CL, and lead-lined boundaries remain solid.
- **Water Breathing:** breathe air and water and ignore penalties from ordinary deep water and pressure appropriate to the spirit's habitat.
- **Light or Temperature:** shed or suppress bright and dim light within 30 feet, or warm or chill unattended ordinary material within 10 feet. This deals no damage and cannot create environmental immunity.
- **Spirit Revelation:** ordinary invisible spirits, possession links, and spiritual disguises within 30 feet are visible to your Spiritual Sense. Equal-or-higher concealment remains contested.

#### Qualification
A willing guest qualifies through its Complete Spirit Record. An unwilling Intruder qualifies only through a trait you have directly perceived, identified with Soul Gaze, or that its Source Rule prints. No one invents a trait because it would be convenient.

#### Consent, Containment, and Bond Strain
A willing guest records consent and can withdraw at the end of any of your turns; withdrawal ends the feature and places it in the nearest legal space. Containing an unwilling Intruder is exorcistic custody, not a Bond. If the target is also your bonded spirit, coercive containment adds 1 Bond Strain unless it was the only immediate procedure preventing possession, soul destruction, or comparable catastrophe.

#### Grand Procession
The Procession is one Spirit Cultivation Asset. A Procession Expression cannot be originated from the Procession and your Soul Fragment simultaneously, and Communal Mending cannot trigger Healing Guest a second time unless Healing Guest’s once-per-round limit has not already been used.

### Integrated Procedure Closure — Mudang

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Drum. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 07. Inner Soul-Gate Ascetic

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Legacy name:** Chakra Ascetic  
**Access:** Restricted inner-soul scripture, monastery discipline, breath-and-identity lineage, trauma-transmutation school, or direct instruction by a qualified ascetic.  
**Identity:** Opening internal soul gates, stabilizing identity, surviving spiritual pressure, and turning inward discipline into restoration.  
**Primary role:** Self-defense, anti-possession, save correction, emotional stabilization, and high-level spiritual clarity.  
**Sphere Lean:** Spirit, Mind, Medicine, Body internalization. This tradition grants none of those Spheres.  
**Cultivation boundary:** The Inner Soul-Gate discipline refines the practitioner’s own spiritual architecture. It does not grant Chakra Path features, external energy projection, universal immunity to mental effects, or authority to rewrite another creature’s identity without a printed procedure.

> *The door is inside the wound. Breathe until it opens without breaking you.*

The old name survives in foreign manuals, but Tianxia monasteries more often call this the **Inner Soul-Gate Ascetic** tradition. Its gates are not the Chakra Path’s organs or elemental reservoirs. They are spiritual thresholds through which fear, pain, memory, desire, and identity are admitted, examined, and integrated.

### Soul-Gate Discipline

You unlock one gate at each Subpath level. An unlocked gate provides its passive benefit at all times unless suppressed. Several gates also have an **Opening**, an active release of that gate’s authority.

- You can benefit from every passive gate you have unlocked at the same time.
- You can have only one Gate Opening active at a time unless Crown Soul Gate says otherwise.
- Activating a new Gate Opening ends the previous one.
- A Gate Opening is a Spirit Awakening effect and uses your Source CL.
- Suppressing a Gate Opening does not erase the gate’s existence, training, or passive identity.

### CL3 — Root Soul Gate

Your soul learns the shape of its own body and refuses ordinary displacement from it.

#### Rooted Identity

Gain proficiency in Athletics or Acrobatics. If already proficient in both, gain proficiency in Medicine or Insight instead.

You have Advantage on saving throws and Cultivation Checks against:

- Forced possession.
- Soul displacement.
- An effect that would exchange, eject, or misidentify your soul and body.
- Forced movement caused by a spirit, psychic effect, or incorporeal creature.

#### Root Reclamation

**Reaction**  
**Trigger:** You are knocked Prone, moved against your will, Grappled or Restrained by a spirit-affecting effect, or an effect attempts to separate your soul from your body.  
**Cost:** 1 Resonance

Choose one:

- Stand from Prone without spending movement.
- Reduce forced movement by `10 feet + 5 × floor(Proficiency Bonus ÷ 2)`; this is 15 feet at PB 2–3, 20 feet at PB 4–5, and 25 feet at PB 6.
- Gain Advantage on the triggering saving throw or Cultivation Check if it has not yet resolved.
- If the effect grants no roll, make a Wisdom saving throw against its save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`. On success, prevent an ordinary or lower-Source-CL separation effect. Equal or higher authority follows its printed result or becomes a recoverable soul strain rather than automatic prevention.

Root Reclamation cannot prevent physical movement caused solely by terrain collapse, a mundane vehicle, or an effect too large to be spiritually resisted unless another Source Rule makes identity relevant.

#### Root Opening

**Bonus Action**  
**Cost:** 1 Resonance  
**Duration:** The scene

While open, your Speed cannot be reduced below 10 feet by ordinary Spiritual Pressure, and standing from Prone costs only 5 feet of movement. When you end your turn in the same space in which you began it, gain Temporary Hit Points equal to your Wisdom modifier + half your Proficiency Bonus.

### CL6 — Sacral Soul Gate

You admit emotional turbulence without allowing it to seize the whole self.

#### Fluid Affect

You have Advantage on checks made to recognize whether an emotion is your own, externally imposed, inherited from a spirit, or echoing from a memory or location.

When Soul Gaze reveals a creature’s surface emotional state, you may also learn whether that emotion is stable, suppressed, externally amplified, magically imposed, or divided against another emotion.

#### Sacral Reorientation

**Reaction**  
**Trigger:** You fail a Dexterity, Wisdom, or Charisma saving throw.  
**Cost:** 2 Resonance  
**Limit:** Once per round

Add your Wisdom modifier to the saving throw, potentially turning failure into success. This can be used after Soulward Response only if the saving throw is still failed, but the same modifier cannot be added twice.

If Sacral Reorientation turns failure into success:

- You become Resonance Marked by yourself until the end of your next turn.
- You may immediately use Soul Gaze on yourself without spending Resonance, learning only the source category, current severity, and likely recovery route of the triggering spiritual disturbance.
- If the triggering effect was Charmed, Frightened, emotional domination, dream intrusion, or ordinary possession, impose one ordinary Spiritual Pressure effect on its source if that source is within 60 feet and perceptible to you.

#### Sacral Opening

**Bonus Action**  
**Cost:** 2 Resonance  
**Duration:** The scene

While open, you can move through the space of a creature affected by one of your Resonance Marks as if it were difficult terrain, and you have Advantage on saving throws against effects that would force you to act from an imposed emotion. Once per turn after you succeed on such a save, move up to 10 feet without provoking opportunity attacks.

### CL10 — Solar Soul Gate

The gate of selfhood burns away borrowed fear and turns conviction into spiritual heat.

#### Solar Core

You gain Resistance to Psychic damage. If Soul Armor later grants the same Resistance, you instead reduce Psychic damage you take by your Proficiency Bonus after Resistance is applied.

You have Advantage on saving throws against Charmed, Frightened, coercive emotional manipulation, and effects that would force you to renounce your identity or Soul Anchor.

#### Solar Opening

**Bonus Action**  
**Cost:** 4 Resonance  
**Duration:** The scene

While open:

- You are immune to ordinary Frightened effects with lower Source CL.
- When you succeed on a saving throw against Charmed, Frightened, possession, or emotional domination, the effect’s source takes Psychic or Radiant damage equal to `2d8 + Wisdom modifier` if within 60 feet.
- Once on each of your turns when you deal Psychic or Radiant damage through a Spirit Awakening feature, you may impose **Repelled Heart** or **Stilled Intent** as an ordinary Spiritual Pressure effect.
- You shed spiritual light in a 10-foot radius that reveals lower-Source-CL possession residue, emotional contamination, and dream parasites without revealing private memories.

If an equal- or higher-authority effect expressly weaponizes your own chosen emotion, Solar Opening grants Advantage rather than immunity and cannot simply declare the emotion false.

### CL14 — Heart Soul Gate

You can share stability without replacing another creature’s feelings or choices.

#### Heart Attunement

When a willing creature within 30 feet fails a saving throw against Charmed, Frightened, possession, emotional corruption, madness, or dream intrusion, you may use your Reaction and spend 2 Resonance. The creature adds your Wisdom modifier to the saving throw. If the result becomes a success, you take Psychic damage equal to `2 × Proficiency Bonus` as you absorb the spiritual recoil.

You cannot use Heart Attunement on the same saving throw as another feature that adds your Wisdom modifier.

#### Heart Restoration

**Action**  
**Range:** Touch  
**Cost:** 5 Resonance

Touch one willing creature and choose one effect:

- Charmed.
- Frightened.
- Ordinary madness.
- Ordinary emotional corruption.
- Ordinary possession.
- A suppressed identity fracture.
- A lower-Source-CL dream intrusion.

If the effect’s Source CL is lower than yours, end it. If its Source CL is equal or higher, the target immediately repeats its saving throw with Advantage. If it has no repeat save, make a Cultivation Check against its save DC.

On a successful repeat save or Cultivation Check, choose one:

- End the effect if its Source Rule permits ordinary removal.
- Suppress it until the end of the scene.
- Reduce its severity by one stage.
- Stabilize the target so the effect cannot worsen until the next Full Cultivation Session.
- Reveal the effect’s Anchor, true name, contradiction, restitution, confession, or reconstruction requirement.

On failure, suppress one symptom until the start of your next turn and learn whether the effect is lower, equal, or higher authority.

Heart Restoration cannot erase a chosen oath, consensual bond, Soul Anchor, true Heart Demon, tribulation scar, divine judgment, Secret-Law wound, or identity change the target genuinely accepts. It must still provide a useful recovery route when full removal is impossible.

#### Heart Opening

**Bonus Action**  
**Cost:** 4 Resonance  
**Duration:** The scene

While open, allies of your choice within 10 feet have Advantage on saving throws against Charmed and Frightened. Once per round when such an ally succeeds on an Intelligence, Wisdom, or Charisma saving throw, it gains Temporary Hit Points equal to your Wisdom modifier + Proficiency Bonus.

### CL18 — Crown Soul Gate

The crown gate opens above the ordinary self and aligns every lower gate into one coherent spiritual axis.

#### Crown Opening

**Bonus Action**  
**Cost:** 9 Resonance  
**Duration:** The scene  
**Concentration:** No

While Crown Opening is active:

- Root, Sacral, Solar, and Heart Openings are all considered active simultaneously. This expressly overrides the one-opening limit.
- You gain **Spiritual Truesight 30 feet** as defined in the Procedure Addendum. It perceives spiritual presences, transformations, illusions, possession links, soul displacement, and hidden souls within line of effect; it does not see through total cover, read mundane writing through walls, reveal every Secret, or defeat equal-or-higher-authority concealment without a Cultivation Check.
- Ordinary possession and soul displacement with lower Source CL automatically fail against you.
- You have Advantage on all Intelligence, Wisdom, and Charisma saving throws.
- Once per round when you fail an Intelligence, Wisdom, or Charisma saving throw, you may spend 2 Resonance to succeed instead. This cannot override a natural result that an explicit Source Rule makes unalterable, and it cannot replace a breakthrough, tribulation, training, or forging resolution.
- When a creature within 30 feet attempts to possess, erase, rewrite, consume, or forcibly relocate a soul, you may use your Reaction to force a Source CL contest. On your success, an ordinary or lower-authority attempt fails. Equal or higher authority is delayed until the end of the current turn or converted into its lesser successful-save result if one exists.

#### Silent Axis

You cannot be spiritually silenced merely by losing speech. Your Spirit Awakening features can use breath, posture, gaze, heartbeat, or Soul Anchor invocation unless a Source Rule suppresses spiritual expression itself.

#### Soul Splitting Expression — Gate Mirror

While Soul Splitting is active and Crown Opening is not active, you may treat your Soul Fragment as holding a second Gate Opening. You gain the passive benefits of both openings, but each active area, movement, or retaliation originates only from the body or fragment holding that gate. This does not duplicate a Reaction or once-per-round trigger.

#### Crown Collapse

If Crown Opening is forcibly broken by an equal- or higher-Source-CL effect, you take `4d10` Psychic damage and cannot activate another Gate Opening until the end of your next turn. Cleanly dismissing it causes no collapse.

### Normalized Gate Procedures

#### Spiritual Truesight
Spiritual Truesight reveals the true spiritual position and broad category of a perceptible creature, manifestation, projection, illusion, transformation, possession link, Soul Fragment, spiritual Asset, or Anchor within range and line of effect. It automatically defeats ordinary mundane disguise, ordinary invisibility, and lower-Source-CL spiritual concealment. Equal or higher authority requires a Cultivation Check. It does not reveal private memories, complete statistics, passwords, a hidden Source Rule's exact text, an object behind total cover, or a fact with no spiritual expression.

#### Gate Opening Origins
An Opening belongs to the body unless Gate Mirror assigns it to the Soul Fragment. An area, movement trigger, retaliation, or light produced by an Opening originates only from its holder. Passive personal defenses that do not require position still protect the cultivator once. Gate Mirror never grants a second turn, Reaction, once-per-round trigger, damage instance, or saving-throw correction.

#### Heart Restoration Information
When Heart Restoration reveals a recovery route, choose the first applicable category in this order: end the sustaining Anchor; expel or negotiate with an Intruder; complete a printed restitution or confession; reconstruct memory or identity through witnesses and records; receive treatment from a named Sphere or Path procedure; defeat a Source CL contest; or wait for the printed duration. The feature reveals the category and one perceivable prerequisite, not an unknown Secret procedure in full.

#### Root Reclamation Without a Printed DC
Use the Source Rule's save DC. If none exists, use the Authority DC in the Procedure Addendum rather than reconstructing a source creature's statistics ad hoc.

#### Crown Opening Contest
A successful Crown Opening contest prevents the single triggering attempt. It does not destroy the source, provide immunity to later activations, or suppress unrelated effects. If the effect has a lesser successful-save result, conversion to that result occurs only once for the triggering activation.

#### Realm Suppression
Unlocked gates remain part of the character's training, but passives and Openings above effective CL become unavailable. If Crown Opening is active when effective CL falls below 18, it ends cleanly unless the suppressing effect expressly breaks it; clean ending does not trigger Crown Collapse.

### Integrated Procedure Closure — Inner Soul-Gate Ascetic

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Gate Mirror. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 08. Yokai Channeler

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Rare Inheritance arising from spirit-beast ancestry, reincarnated yokai memory, inherited mask, relic fusion, divine scar, curse transmuted into lineage, or singular adoption by a yokai court.  
**Identity:** A human-presenting soul with an inherited yokai nature, appetite, cleverness, body, and spiritual jurisdiction.  
**Primary role:** Adaptive transformation, movement, natural weapons, trickster bargains, lineage-specific control, and local spirit-beast authority.  
**Sphere Lean:** Transformation, Illusion, Beast Taming, Spirit. This inheritance grants none of those Spheres.  
**Cultivation boundary:** The inheritance expresses one chosen yokai lineage. It does not grant every yokai power, a separate yokai stat block, universal command over beasts or spirits, immunity to the lineage’s traditional weaknesses, or permission to ignore its Need and Taboo.

> *A mask is only a lie until the old blood answers from beneath it.*

A Yokai Channeler is not a cultivator who learned to imitate a monster. Their soul has always had another grammar. The inheritance may be loved, feared, concealed, commodified, or treated as proof of impurity, but it is a genuine lineage rather than a temporary possession.

### Choose a Yokai Lineage

At CL3, choose **Kitsune, Tengu, Kappa,** or **Jorogumo**. The choice cannot normally be changed. A reincarnation, bloodline reconstruction, Secret-Law severance, or comparable story event can alter it.

Each lineage has a **Tell, Need,** and **Taboo**.

- A **Tell** is a visible or spiritually perceptible sign of the inheritance. You can suppress it while calm, but it appears while Unmasking, in True Form, or when a Source Rule exposes your spiritual identity.
- A **Need** is an appetite or practice that keeps the lineage coherent. Satisfying it during a Full Cultivation Session is sufficient. Neglecting it for seven consecutive days Strains your Soul Anchor until you satisfy the Need and complete a Full Cultivation Session.
- A **Taboo** is a lineage contradiction. Knowingly violating it does not remove your features, but you take `2d10` Psychic damage and cannot gain Temporary Hit Points from this inheritance until you make restitution or complete a suitable Heart Demon confrontation.

Needs and Taboos use their ordinary-language meaning and the recorded restitution procedures below. A violation requires a knowing choice; accident, magical compulsion that removes agency, mistaken identity, or a fact the character could not perceive does not count. Technical wording cannot manufacture a violation.

### Lineage Table

#### Kitsune

- **Tell:** Fox eyes, spectral tails, foxfire scent, reflected ears, or a smile that appears first in mirrors.
- **Need:** A secret, story, clever exchange, or act of hospitality freely given.
- **Taboo:** Betraying a guest under your declared protection without prior warning or necessity.
- **Skill:** Deception or Persuasion.
- **Damage affinity:** Psychic or Fire.

#### Tengu

- **Tell:** Black feathers, long-nosed mask, wind moving against the room, raptor shadow, or impossible balance.
- **Need:** High places, disciplined challenge, martial display, or an honest contest.
- **Taboo:** Claiming mastery after refusing a fair challenge that you were free to accept or decline openly.
- **Skill:** Acrobatics or Athletics.
- **Damage affinity:** Thunder or Force.

#### Kappa

- **Tell:** Wet footprints, shell pattern, river smell, webbed fingers, or water held in an impossible hollow.
- **Need:** Clean water, cucumber or river offering, bathing rite, or maintenance of a waterway.
- **Taboo:** Polluting water placed under your protection or denying agreed hospitality at a safe crossing.
- **Skill:** Athletics or Medicine.
- **Damage affinity:** Cold or Bludgeoning.

#### Jorogumo

- **Tell:** Multiple reflected eyes, silk at the fingertips, spider shadow, patterned skin, or footsteps that cling to walls.
- **Need:** Weaving, patient hunting, a preserved story, or maintaining a web of relationships.
- **Taboo:** Destroying a dependent bond for amusement after deliberately creating that dependence.
- **Skill:** Perception or Insight.
- **Damage affinity:** Poison or Psychic.

Gain proficiency in the chosen Skill. If already proficient, gain proficiency in the other listed Skill.

### CL3 — Yokai Mask

Your inheritance can be hidden, displayed, or used as a social and spiritual instrument.

#### Suppress or Reveal the Tell

You may suppress or reveal your Tell as a Bonus Action. Suppression defeats ordinary visual inspection but not Spiritual Sense, Soul Gaze, a lineage-specific detector, or equal- or higher-Source-CL identity revelation.

When a creature attempts to determine whether you are lying about your species, ancestry, or spiritual nature, you may use Wisdom instead of Charisma for the relevant Deception check.

#### Lineage Gift

Gain the gift of your chosen lineage:

- **Kitsune — Foxfire Misdirection:** When a creature within 30 feet makes an Insight check against you or an attack roll against an illusion, reflection, or duplicate created by you, use your Reaction and spend 1 Resonance to impose Disadvantage. If the roll fails, the creature becomes Resonance Marked by you.
- **Tengu — Wind-Perched Step:** Your jump distance doubles. When you fall, reduce the effective fall by `10 feet × Proficiency Bonus`. As a Reaction when pushed or knocked Prone, spend 1 Resonance to move 10 feet to a legal space and remain standing.
- **Kappa — River Body:** Gain a swim Speed equal to your Speed and can hold your breath for 1 hour. As a Reaction when you or an adjacent ally would be moved, spend 1 Resonance to reduce that movement by 10 feet and shift the creature 5 feet to another legal adjacent space.
- **Jorogumo — Wall-Clinging Thread:** Gain a climb Speed equal to your Speed and can move across ceilings while leaving both hands free. Once on each of your turns when you Resonance Mark a creature, you may reduce its Speed by 5 feet until the mark ends.

### CL6 — Unmasking

**Bonus Action**  
**Cost:** 2 Resonance  
**Duration:** The scene

Reveal a combat-capable portion of your yokai nature. Your Tell becomes obvious and cannot be suppressed while the feature remains active.

#### Yokai Natural Weapon

Choose an appropriate bite, claw, horn, wing-blade, tail, web-strike, water-heavy blow, or foxfire lash when you activate Unmasking. It is a simple cultivated natural weapon with which you are proficient. It uses Wisdom for attack and damage rolls, has a reach of 5 feet, and deals `1d8 + Wisdom modifier` damage of your lineage affinity or an appropriate physical type.

Once on each of your turns when you hit with the natural weapon or a creature fails its save against Mind Spike, deal additional damage equal to your Proficiency Bonus of your lineage affinity.

This is a weapon expression of your own body and soul. It is not a Sphere talent and does not count as a detached Cultivation Asset.

#### Unmasked Lineage Gift

- **Kitsune:** After you deal the additional damage, create one foxfire double in an adjacent space until the start of your next turn. The first attack against you before then has Disadvantage; on a miss, you may move 5 feet.
- **Tengu:** After you move at least 15 feet in a straight line, your next natural-weapon hit that turn deals an extra `1d8` Thunder damage and can push the target 10 feet.
- **Kappa:** You have Advantage on checks and saves against Grappled and Restrained. Once per turn on a natural-weapon hit, you may Grapple the target using your Cultivation Attack Modifier in place of Athletics.
- **Jorogumo:** Once per turn on a natural-weapon hit, place a **Silk Thread** on the target until the end of your next turn. While threaded, it cannot benefit from invisibility against you and has Disadvantage on the first check or save it makes to escape one of your movement or restraint effects.

### CL10 — Yokai’s Bargain

Yokai bargains are voluntary exchanges enforced by hospitality, appetite, clever wording, and spiritual face. They are not Oath-Ledger debts, Soul-Collateral Contracts, or Karma judgments.

**Action or 10-minute negotiation**  
**Range:** 30 feet during action use; conversational range during negotiation  
**Cost:** 3 Resonance  
**Duration:** Up to 24 hours

Offer a bargain to one creature that can understand the terms. State:

- What each party will give, do, refrain from doing, reveal, or protect.
- The duration or completion condition.
- Whether the bargain uses a **Declared Claim** or an **Open Claim**. A Declared Claim selects one Claim use from the printed Breach list when the bargain forms. An Open Claim permits the nonbreaching party to choose any one printed Claim use after breach. No consequence outside that list is created by this feature.

The bargain forms only if both parties knowingly accept. Magical coercion that removes meaningful choice prevents formation unless the bargain’s Source Rule expressly allows coerced contracts.

Each party gains a visible-to-spiritual-senses **Bargain Mark**. A party can bear only one Bargain Mark from you at a time.

#### Permitted Benefits

The bargain may grant each party one of the following while it remains honored:

- Advantage on one defined category of skill check directly related to fulfilling the bargain.
- A 10-foot increase to one movement mode while traveling toward the bargain’s objective.
- Temporary Hit Points equal to `2 × Proficiency Bonus` at the start of the first scene in which the bargain is actively pursued.
- The ability to communicate telepathically within 1 mile for purposes related to the bargain.
- Permission to cross one ward, threshold, territory, or hospitality boundary controlled by the other party, if that party has authority to grant permission.

#### Breach

When a party knowingly breaches, the nonbreaching party immediately knows the broad category of breach and gains one **Yokai Claim** against the violator. The Bargain Mark remains until the claim is used or the parties reconcile.

The claimant may spend the Claim in one of these ways:

- Impose Disadvantage on one d20 Test the violator makes within 60 feet.
- Gain Advantage on one saving throw against the violator.
- Learn the violator’s direction while on the same plane for 1 hour, unless blocked by equal or higher spiritual concealment.
- Deal `4d10` Psychic damage to the violator as a Reaction when it directly benefits from the breach. The violator makes a Charisma saving throw, taking half damage on a success.

A Yokai Claim cannot force future obedience, seize a soul, create unlimited pursuit, or punish an ambiguous technical breach. If the bargain’s meaning is genuinely disputed, resolve it through the stated terms, witnesses, and a Cultivation Check rather than automatic punishment.

### CL14 — True Yokai Form

**Action**  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Concentration:** No

Assume your inherited true form. You retain your game statistics, equipment, actions, and identity unless a feature says otherwise. Equipment can merge cosmetically into the form or remain worn if physically compatible; it is not destroyed or duplicated.

You gain the benefits of Unmasking without paying its cost, your natural weapon die becomes `1d10`, and gain the lineage package below.

#### Kitsune True Form

- Fly Speed 40 feet; hover through foxfire steps rather than wings.
- Resistance to Psychic or Fire damage, chosen when you transform.
- **Ninefold Feint:** Once per round when an attack misses you, move up to 15 feet and create a Dream Thread–like foxfire sign on the attacker. The sign lasts until the end of your next turn and lets you target it with Soul Gaze through ordinary invisibility within 60 feet.

#### Tengu True Form

- Fly Speed 50 feet.
- Resistance to Thunder or Force damage, chosen when you transform.
- **Mountain Wind Cut:** Once on each of your turns after moving at least 20 feet, one creature you hit with your natural weapon takes an extra `2d8` damage and must succeed on a Strength saving throw or fall Prone or be pushed 15 feet, your choice.

#### Kappa True Form

- Swim Speed 60 feet and can breathe air and water.
- Resistance to Cold or Bludgeoning damage, chosen when you transform.
- **River Lock:** A creature Grappled by you cannot teleport or use incorporeal movement unless its Source CL exceeds yours or it succeeds on a Charisma saving throw when it attempts to do so.

#### Jorogumo True Form

- Climb Speed 50 feet, including ceilings, and web-walking.
- Resistance to Poison or Psychic damage, chosen when you transform.
- **Grand Silk:** As an Action, create a 20-foot-square web zone within 60 feet until the end of the scene. The zone is difficult terrain for enemies. A creature that enters for the first time on a turn or starts there makes a Dexterity saving throw, becoming Restrained until the end of its next turn on a failure. A creature can use its Action to repeat the save, ending the restraint on success. You can have one Grand Silk zone at a time.

#### True-Form Exposure

While in True Form, ordinary observers recognize that you are not wholly human, though they may not know the exact lineage. Identity concealment with equal or higher authority can alter this result; mundane disguise cannot.

### CL18 — Yokai Lord

You become a local sovereign expression of your inherited lineage rather than merely revealing an ancestral body.

**Bonus Action**  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Concentration:** No

Assume True Yokai Form and manifest a **Yokai Court** in a 30-foot aura centered on you.

#### Court Authority

- Beasts, yokai, spirit-beasts, transformed creatures, and spiritually compromised creatures with lower Source CL know your lineage and broad emotional intent while in the aura.
- Such a hostile creature that first enters the aura on a turn or starts its turn there makes a Charisma saving throw.
- **Failed Save:** It is **Overawed** until the start of its next turn. While Overawed, it cannot take Reactions, cannot willingly move closer to attack you, and has Disadvantage on attacks against creatures other than you.
- **Successful Save:** It suffers one ordinary Spiritual Pressure effect.
- A creature repeats no save merely for remaining in the aura; it saves again only after leaving and reentering or when you use Lordly Challenge.

#### Lordly Challenge

**Bonus Action, once per round**

Choose one beast, yokai, spirit-beast, transformed creature, or spiritually compromised creature within 60 feet. It makes a Charisma saving throw.

- **Failed Save:** It follows one simple, non-suicidal command on its next turn: approach, withdraw, release, reveal, kneel, cease pursuit, or attack a creature already hostile to it. If it takes damage from you or your allies before complying, the command ends.
- **Successful Save:** It suffers one ordinary Spiritual Pressure effect.

This is temporary lineage authority, not permanent taming, friendship, enslavement, or a companion bond. A substantially lower-Source-CL ordinary creature can be compelled for up to 1 minute if you maintain Concentration after the first failed save; it repeats the save at the end of each turn and whenever damaged.

#### Lineage Apotheosis

Gain one greater expression:

- **Kitsune — Palace of Foxfire:** Once during the activation, create up to `Proficiency Bonus` illusory doubles in spaces within 60 feet. Until destroyed by a successful Investigation check against your Cultivation Save DC or struck by an attack, each double can serve as the origin of one non-hostile Spirit Awakening feature. You still activate each feature only once and pay all costs.
- **Tengu — Heaven-Scouring Descent:** Once during the activation, move up to your fly Speed without provoking reactions and make one Cultivation Attack against every hostile creature whose space you pass within 5 feet of, maximum Proficiency Bonus targets. On a hit, deal `4d10 + Wisdom modifier` Thunder or Force damage.
- **Kappa — Court Beneath the River:** Once during the activation, create a 30-foot-radius water court centered on a point within 60 feet. It lasts for the scene, is difficult terrain for enemies, and permits you and willing allies to breathe, swim, and stand in it as though on solid ground. Hostile teleportation and forced passage across its boundary require a Charisma saving throw.
- **Jorogumo — Web of a Hundred Names:** Once during the activation, choose up to Proficiency Bonus creatures you can perceive within 60 feet. Each makes a Dexterity saving throw. On a failure, spectral silk links it to a point you choose in the Court. Its Speed becomes 0 until it uses an Action to repeat the save or an ally destroys the thread Anchor, which has AC equal to your Cultivation Save DC and Hit Points equal to `3 × Proficiency Bonus`.

#### Soul Splitting Expression — Masked Twin

While Soul Splitting is active, your Soul Fragment may display your Tell and use your Spiritual Sense. During Unmasking or True Yokai Form, the fragment may originate one natural-weapon attack you make, but this does not grant an additional attack or separate turn.

### Normalized Inheritance and Bargain Procedures

#### Need Satisfaction
A Need is satisfied when you complete a Full Cultivation Session that includes one listed Need expression for at least 10 minutes. One qualifying act satisfies the Need for seven days. Additional acts are permitted but do not bank future weeks.

#### Taboo Restitution
After a knowing Taboo violation, the inheritance's printed damage occurs once for that event. Complete one lineage restitution and then a Full Cultivation Session to end the Temporary-Hit-Point restriction and repair a Strained Soul Anchor caused by neglected Need.

- **Kitsune:** give truthful warning to a guest or dependent you could exploit; provide shelter or safe passage to a willing guest; or reveal a secret of comparable personal value to someone harmed by the betrayal.
- **Tengu:** openly acknowledge the refused challenge; complete one hour of disciplined practice under a credible witness; or accept and complete a fair challenge you remain free to refuse.
- **Kappa:** remove pollution from a waterway for one hour; restore a damaged crossing or hospitality site; or deliver a clean-water offering to the harmed community or spirit.
- **Jorogumo:** release a dependent you manipulated; repair material or social harm caused by the broken bond; or spend one hour weaving, building, or arranging aid for the affected dependent.

A restitution must address the same violation or the harmed relationship. Repeating an unrelated trivial rite does not qualify.

#### Bargain Formation and Breach
The parties write or state the exact exchange, completion condition, duration, and Claim mode. A term is valid only if both parties can understand what performance would satisfy it. If a disputed event is not clearly covered by the terms, no breach occurs until the parties clarify the bargain. A Cultivation Check can reveal deception or concealed interference, but cannot rewrite an ambiguous term after acceptance.

A Yokai Claim is spent only through the four printed Claim uses. Spending it ends the Bargain Mark unless both parties voluntarily reconcile first, in which case the Claim ends without effect. Damage from a Claim is a spiritual consequence from the breaching party's own accepted Mark; it is not an attack and does not trigger on harmless or indirect benefit.

#### Inherited Body and Equipment
Yokai identity is integrated personhood, not Hosting or possession. Exorcism cannot remove the lineage. Unmasking and True Yokai Form do not duplicate equipment. Worn equipment either remains fitted, merges and becomes unusable until the form ends, or is safely carried by the form; choose for each item when transforming. An item cannot grant its worn benefit while merged unless its own rule permits it.

#### Natural Weapon Damage Types
Choose from the lineage affinity or one physical type fitting the printed anatomy: bite or horn uses Piercing; claw, wing-blade, or tail-blade uses Slashing; tail, shell, water-heavy blow, or body-check uses Bludgeoning. Foxfire lash may use Fire or Psychic. Silk or web-strike uses Bludgeoning or Psychic. The choice is made when Unmasking begins and remains until it ends.

### Integrated Procedure Closure — Yokai Channeler

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Masked Twin. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 09. Dream Eater

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden predatory dream method, nightmare lineage, stolen oneiric scripture, initiation by a dream predator, or survival after consuming a parasitic dream.  
**Identity:** Entering vulnerable dreams, inflicting persistent Nightmare Scars, consuming fear and memory, and turning stolen sleep into spiritual power.  
**Primary role:** Predatory setup, psychological information, sleep control, persistent dream injury, and high-level memory consumption.  
**Sphere Lean:** Dreams, Mind, Spirit. This method grants none of those Spheres.  
**Cultivation boundary:** Dream Eater consumes dream-content and the spiritual vulnerability surrounding sleep. It does not gain Dreamweaver’s reality revision, Fate authority, unrestricted memory access, automatic control of sleeping creatures, or permission to harvest harmless victims without consequence.

> *Sleep is a door. Hunger is the hand already resting on the latch.*

Dream Eaters are feared because their art turns rest into exposure. Some prey only upon enemies, curses, invasive nightmares, or monsters whose dreams poison communities. Others cultivate through helpless sleepers and become exactly what the method’s reputation promises. The method is predatory by structure but not mechanically Daemonic unless another Source Rule adds that tag.

### Nightmare Scars

Several Dream Eater features create a **Nightmare Scar**.

- A creature can bear only one Nightmare Scar from you at a time.
- A Scar lasts until the creature completes the **Nightmare-Scar Recovery procedure**, succeeds on another printed recovery procedure, or an effect removes it.
- While scarred, the creature has Disadvantage on the first saving throw it makes against Frightened, sleep, dream intrusion, or one of your Dream Eater features after each Long Rest.
- Once that Disadvantage is applied, the Scar remains but grants no further Disadvantage until the creature completes another Long Rest.
- Soul Gaze can identify that a Nightmare Scar exists and whether it was created by fear, memory predation, sleep deprivation, or dream imprisonment.
- Spiritual Exorcism, a suitable Dreams or Spirit technique, or the Nightmare-Scar Recovery procedure removes an ordinary Scar according to its Source CL result.
- A lower-Source-CL creature cannot remove a Scar merely by being rendered unconscious again.

### Dream Morsels

You can hold a number of **Dream Morsels** equal to your Proficiency Bonus.

You gain 1 Dream Morsel, up to this maximum, when a meaningful hostile creature first in a scene:

- Fails a save against one of your Dream Eater features while asleep, helpless, Frightened, or bearing your Nightmare Scar.
- Reveals a genuine fear, dream, or emotionally important memory through your Dream Eater feature.
- Has one of your Nightmare Scars removed by resisting you through a meaningful recovery procedure.

You can gain only one Morsel from a given creature per scene. Dream Morsels last until the end of the scene. They cannot be gained from harmless animals, allied summons, willing allies staging resistance, captive victims repeatedly sedated, creatures created for harvesting, or a memory you already consumed from the same creature.

Dream Morsels are not Resonance and cannot normally restore Resonance. They represent usable dream-content, not abstract energy.

### CL3 — Dream Walker

You can approach the edge of another creature’s dream without immediately harming it.

**Ritual or Action**  
**Range:** 1 mile during the ritual; 60 feet during action use  
**Cost:** 1 Resonance  
**Duration:** Up to 10 minutes during the ritual; until the end of your next turn during action use

Choose one sleeping creature whose broad location you know, or one sleeping or Resonance Marked creature you can perceive.

A willing creature admits you automatically. An unwilling creature makes a Wisdom saving throw.

#### Failed Save

You enter the dream’s outer threshold. Your body remains where it is, and this is not Astral Projection. You may:

- Speak to the dreamer in symbolic or ordinary language.
- Present one image, sensation, warning, or memory you willingly disclose.
- Learn the dream’s dominant emotional tone.
- Determine whether another dream intruder, nightmare parasite, memory seal, or obvious dream curse is present.
- Create a Resonance Mark on the dreamer that lasts until it wakes or until the normal mark duration expires after waking, whichever is later.

You cannot deal damage, compel behavior, steal information, rewrite memory, or move beyond the outer dream through Dream Walker alone.

#### Successful Save

You perceive that the dream is closed, warded, lucidly defended, absent, or beyond your current authority. You do not learn its content.

#### Defended Dreams

A ward, Spirit technique, Dreams technique, trained lucid dreamer, Soul Anchor, spirit companion, equal- or higher-Source-CL soul, or creature that does not truly dream can block entry or require a Cultivation Check. On failure, you cannot attempt Dream Walker against that creature again until its dream changes or the next scene begins.

#### Wakeful Taste

When a creature Resonance Marked by you within 60 feet becomes Frightened or fails a save against Mind Spike, choose one of these categories and learn its result:

- A symbolic image associated with its present fear.
- Whether it slept normally during its last long rest.
- Whether a nightmare, dream parasite, or dream-derived memory currently influences it.

This does not reveal a hidden fact merely because the target fears discovery.

### CL6 — Nightmare Touch

You can bite into the spiritual residue of sleep, helplessness, or a marked fear.

**Action**  
**Range:** Touch, or 30 feet against a sleeping creature or a creature bearing your Resonance Mark  
**Cost:** 3 Resonance

The target makes a Wisdom saving throw.

**Failed Save:** It takes `4d8 + Wisdom modifier` Psychic damage, gains a Nightmare Scar, and cannot regain Hit Points from sleep or rest until the start of your next turn. If it is asleep, it wakes after the damage unless you spend 1 Dream Morsel to keep it asleep until the end of its next turn or until it takes damage from another source.

**Successful Save:** It takes half damage and does not gain a Scar.

If the target was sleeping, helpless, Frightened, or already scarred and is meaningful and hostile, gain 1 Dream Morsel subject to the normal limit.

#### Feed on Resistance

When a meaningful hostile creature succeeds on its saving throw against Nightmare Touch while already scarred, you may spend 1 Dream Morsel to impose one ordinary Spiritual Pressure effect and prevent the Scar’s first-save Disadvantage from being expended by that successful save.

#### Predatory Trace

A creature damaged by Nightmare Touch can identify that its sleep or fear was spiritually attacked, even if it cannot identify you. Soul Gaze, Read the Spirit, and appropriate dream diagnosis can identify your spiritual signature unless you defeat the diagnosis with a Cultivation Check.

### CL10 — Stolen Dreams

You can take usable fragments of fear, longing, and recent dream-memory.

**Trigger:** A creature bearing your Nightmare Scar fails its save against Mind Spike, Nightmare Touch, Domain Pressure, or another Dream Eater feature.  
**Cost:** 2 Resonance or 1 Dream Morsel  
**Limit:** Once per turn

Choose one **Dream Fragment** to steal:

- A recent dream image.
- A surface fear relevant to the current scene.
- A person, place, or object presently associated with safety or danger.
- One ordinary emotional vulnerability.
- One language fragment, face, route, or sensory memory encountered during the last 24 hours.

Protected memories, sealed secrets, Soul Anchor material, training secrets, plot-critical knowledge, and memories hidden by equal or higher authority require a Cultivation Check. On failure, you learn the category of protection rather than the memory.

You can retain a number of Stolen Dreams equal to your Wisdom modifier, minimum 1. A Stolen Dream lasts until your next Full Cultivation Session unless preserved through a legal item, Sphere, ritual, or Insight. When you exceed the limit, release one existing fragment.

#### Spend a Stolen Dream

As a Bonus Action, release one retained fragment for one benefit:

- Gain Advantage on one Insight, Investigation, Perception, Persuasion, Deception, or Survival check directly related to the fragment.
- Give the original creature Disadvantage on one attack roll or saving throw it makes against you before the end of your next turn by confronting it with the fragment.
- Reproduce one harmless sensory image, voice, scent, or dream-symbol for up to 1 minute.
- Find the direction of a person, place, or object shown in the fragment if it is within 1 mile and not hidden by stronger authority.

Releasing the fragment removes it from you but does not erase it from the original creature.

#### Memory Theft Boundary

Stolen Dreams reads or copies a fragment; it does not remove a proficiency, delete an entire relationship, replace identity, or grant the full knowledge required to use another creature’s feature, Sphere, manual, password system, or Secret.

### CL14 — Sleeping Curse

You can drag an exhausted or spiritually opened soul into predatory sleep even during battle.

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance  
**Duration:** Concentration, up to 1 minute

Choose one creature that is Bloodied, Frightened, Resonance Marked by you, or bearing your Nightmare Scar. It makes a Wisdom saving throw.

#### Failed Save

The creature falls into **Cursed Sleep**. It is Unconscious, falls Prone if able, and cannot be awakened by ordinary noise or an ally’s simple action.

At the end of each of its turns, it repeats the saving throw, ending the effect on a success. It also immediately repeats the save with Advantage when it takes damage.

While it sleeps, you may use one of these options once on each of your turns:

- **Feed:** Spend 1 Dream Morsel. The sleeper takes `3d10` Psychic damage and you gain Temporary Hit Points equal to half the damage dealt. This damage grants the normal immediate repeat save with Advantage.
- **Question:** Ask one question about a fear, dream, or recent emotionally important event. The sleeper’s dream answers symbolically. Protected information can require a Cultivation Check.
- **Deepen the Scar:** The target’s Nightmare Scar cannot be removed by an ordinary long-rest save until after the next scene.
- **Maintain Stillness:** The target does not repeat the save at the end of this turn, but you cannot choose this option on consecutive turns.

#### Successful Initial Save

The target becomes Drowsy until the end of its next turn: its Speed is halved, it cannot take Reactions, and it suffers one ordinary Spiritual Pressure effect.

#### Intervention

An ally adjacent to the sleeper may use an Action to perform one intervention:

- Inflict damage, granting the repeat save with Advantage.
- Invoke the sleeper’s Soul Anchor, true name, or meaningful bond, granting an immediate repeat save.
- Use Spiritual Exorcism, a Dreams or Spirit technique, or a suitable stimulant or ritual.
- Contest your Source CL with a Cultivation Check to break the curse’s dream connection.

#### Lower-Realm Dominance

A substantially lower-Source-CL ordinary creature that fails the initial save cannot wake through ordinary immunity to magical sleep unless the immunity explicitly protects the soul or dreams. It retains the printed repeat saves and intervention procedures.

### CL18 — Dream Eater Ascension

You enter the vulnerable inner dream and consume something the target uses to remain psychologically whole.

**Action**  
**Range:** 60 feet  
**Cost:** 10 Resonance and up to 3 Dream Morsels  
**Target requirement:** Sleeping, helpless, in Cursed Sleep, or bearing both your Resonance Mark and Nightmare Scar  
**Duration:** Instantaneous injury; stolen effects persist as described

The target makes a Wisdom saving throw. It has Disadvantage if you spent at least 2 Dream Morsels and it is asleep or helpless.

#### Failed Save

The target takes `10d10` Psychic damage. Choose one **Consumption**:

- **Recent Memory:** Remove one significant memory formed within the last 30 days. The target knows a gap exists but cannot access the content.
- **Restful Dream:** The target cannot receive recovery benefits from a Long Rest until it completes one successful **Devoured-Dream Recovery**. It can still sleep, avoid ordinary sleep-deprivation consequences, and complete a Full Cultivation Session if another rule permits; only the Long Rest benefits are withheld.
- **Practiced Confidence:** Suppress one skill proficiency, tool proficiency, or language linked to a memory you have identified. This cannot suppress a Path, Sphere, talent, Method, Foundation, Insight, or entire ability score.
- **Defining Hope:** Suppress one stated aspiration, source of courage, or positive bond. While suppressed, the target has Disadvantage on saves against Frightened and cannot use that hope as a Soul Anchor invocation. This does not sever or replace the Soul Anchor itself.
- **Prepared Dream:** Suppress one dream-based, memory-based, or emotional technique the target has used or revealed during the scene. The suppression lasts until recovery and cannot affect a feature of higher minimum CL than your Source CL.

You retain the consumed content as a **Devoured Dream**. You can hold only one Devoured Dream at a time. While holding it:

- Gain Temporary Hit Points equal to half the Psychic damage dealt.
- Gain one relevant language, skill proficiency, or narrow emotional insight if the consumed content supports it.
- You can reproduce the consumed memory or dream as an illusion or symbolic vision.

Holding a Devoured Dream does not give you the victim’s Path, Sphere, technique, statistics, true identity, or Soul Anchor.

#### Successful Save

The target takes half damage, suffers one ordinary Spiritual Pressure effect, and you may steal one ordinary Dream Fragment under Stolen Dreams without additional cost.

#### Recovery

The target can recover the consumed content through one of these routes:

- Spiritual Exorcism followed by a Full Cultivation Session and a successful Wisdom or Charisma saving throw against your Cultivation Save DC.
- A Dreams, Spirit, Medicine, Memory, Samsara, Karma, or appropriate Secret-Law procedure that explicitly restores lost memory or identity content.
- Destroying or forcing you to release the Devoured Dream, followed by a Long Rest or Full Cultivation Session.
- Completing the **Witnessed Reconstruction procedure** in the Procedure Addendum using witnesses, journals, Soul Anchor relationships, dream records, or lived repetition.

An equal- or-higher-Source-CL Consumption requires the printed Source CL contest or a restoration Source Rule of equal or higher authority. Secret, divine, artifact, tribulation, or conceptual protection uses its own explicit counterprocedure; this feature does not create an undefined quest requirement. A Devoured Dream cannot be permanently destroyed merely because you die; it is released as recoverable spiritual residue unless another explicit effect consumes it.

#### Hunger’s Reflection

While holding a Devoured Dream, Soul Gaze and spiritual diagnosis can perceive that you contain another creature’s dream-content. If you retain it through a Full Cultivation Session, make a Wisdom saving throw against your own Cultivation Save DC. On failure, roll or choose one **Dream Intrusion** from the Procedure Addendum. It persists until you release the dream or complete Spiritual Exorcism on yourself. This is a spiritual consequence, not the mechanical Daemonic tag.

#### Soul Splitting Expression — Mouth Behind Sleep

While Soul Splitting is active, your Soul Fragment may enter the outer threshold of a dream through Dream Walker and may serve as the origin for Nightmare Touch or Sleeping Curse. You still activate the feature once, pay one cost, and cannot affect a target through total cover unless the dream connection already exists.

### Normalized Dream-Predation Procedures

#### Nightmare-Scar Recovery
During a Long Rest in a spiritually safe place, the affected creature spends at least 10 minutes in lucid-dream treatment, meditation, guided sleep, or spiritual care, then chooses Wisdom or Charisma and makes a saving throw against your Cultivation Save DC. A Full Cultivation Session that includes the same treatment also permits one attempt. A willing specialist using a suitable Dreams, Spirit, Medicine, or exorcism Source Rule may instead use its printed check and timing. On success, an ordinary Scar ends. On failure, the creature learns the Scar's Source CL band and cannot repeat the same recovery method during that Long Rest or Cultivation Session. Equal-or-higher Source CL Scars require a successful contest or a printed removal feature.

#### Spiritually Safe Place
A place is spiritually safe for dream treatment when the sleeper has ordinary physical safety, no hostile creature has immediate access, and no active hostile dream Field, Intruder, Nightmare Scar Anchor, or equal-or-higher-authority dream effect controls the space. A bed, shrine, camp, or ward is not safe by name alone.

#### Defended Dream DC
When a defended dream grants no printed DC, use the defending Source Rule's save DC. For a trained lucid dreamer without another Source Rule, use `10 + target PB + target Wisdom modifier`. Failure blocks only that current dream state; a new scene, a new dream, consent, or removal of the defense permits another attempt.

#### Dream Fragment Record
Record the fragment category, source creature, scene relevance, exact image or narrow information, protection category, acquisition time, and expiration. A fragment cannot expand through inference into a full map, language, identity, manual, or tactical plan.

#### Devoured-Dream Recovery
One successful route restores the consumed content:

1. **Release and Reintegrate:** the Devoured Dream is released, and the target completes a Long Rest or Full Cultivation Session that includes sleep, meditation, journaling, or guided recollection.
2. **Witnessed Reconstruction:** three independent evidence points recreate the content—such as one witness, one record, and one Soul Anchor relationship—followed by a Wisdom or Charisma save against your Cultivation Save DC.
3. **Spiritual Exorcism:** Spiritual Exorcism identifies and restores the missing category, followed by a Full Cultivation Session.
4. **Equal Authority Restoration:** a Dreams, Spirit, Medicine, Memory, Samsara, Karma, divine, artifact, or Secret Source Rule explicitly restores the content and succeeds against the Consumption's Source CL.

A failed attempt does not worsen the injury and cannot be repeated by the same route until the next scene.

#### Dream Intrusion Table
Choose or roll `1d6`: (1) speak one harmless phrase in the victim's cadence when first waking; (2) see the victim's recurring symbol in reflective surfaces; (3) momentarily misidentify one familiar scent or sound as belonging to the victim; (4) dream of one disclosed fear during the next sleep; (5) display one harmless emotional mannerism when the Devoured Dream is invoked; (6) briefly use the victim's preferred metaphor when describing danger. These are roleplaying intrusions, not control, compelled disclosure, Disadvantage, or identity replacement.

#### Sleeping Curse and Intervention
Each listed intervention grants exactly one immediate repeat save unless its own Source Rule ends the effect. Several allies can attempt different interventions, but the target cannot receive more than one intervention save between the ends of its turns. **Maintain Stillness** removes only the ordinary end-of-turn repeat save for that turn; damage and interventions still grant their printed attempts.

#### Realm Suppression
Existing Nightmare Scars and Devoured Dreams remain as recorded injuries or content. Features above effective CL cannot be activated. Sleeping Curse ends if effective CL falls below 14. A Devoured Dream already held is released as recoverable residue if effective CL falls below 18 and the character no longer has legal authority to contain it.

### Integrated Procedure Closure — Dream Eater

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Mouth Behind Sleep. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 10. Soul Warden / Necromancer

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden funerary scripture, battlefield death lineage, prison-of-souls office, grave sect, condemned corpse manual, underworld bureaucracy, or tutelage by a lawful or predatory dead spirit.  
**Identity:** Corpse memory, fading soul-residue, spiritual custody, commanded specters, and the dangerous boundary between guarding the dead and exploiting them.  
**Primary role:** Death investigation, earned soul-residue, temporary specter Assets, spirit damage, containment, and battlefield manifestation.  
**Sphere Lean:** Death, Spirit, Necromancy, Medicine. This method grants none of those Spheres.  
**Cultivation boundary:** This method manipulates corpse memory and soul-fragments. It does not casually seize a complete immortal soul, create a permanent undead army, grant a full companion, restore the dead to true life, or make every corpse truthful and omniscient.

> *The dead are not silent. They are tired of being questioned by people who never learned the law of custody.*

Some practitioners call themselves Soul Wardens and treat every fragment as evidence, prisoner, patient, or pilgrim. Others accept the name Necromancer and cultivate through coercion. The same procedures can protect a community or desecrate it; the distinction is recorded through custody, consent, and consequence rather than a cosmetic title.

### Soul Fragments

Several features create or spend **Soul Fragments**.

A Soul Fragment is a fading residue of memory, emotion, animating will, death shock, or spiritual identity. It is **not automatically the creature’s complete soul**.

- You can hold a number of Soul Fragments equal to your Proficiency Bonus.
- A fragment lasts until your next Full Cultivation Session unless preserved by a legal vessel, ritual, item, Spirit technique, Death technique, or higher feature.
- Each fragment records its source creature and whether it was received willingly, collected from an already-fading residue, or taken coercively.
- A creature can provide only one fragment to you from the same death or spiritual collapse.
- You cannot gain fragments from harmless animals, allied summons, manufactured creatures made for harvesting, repeatedly revived captives, trivial sacrifices, or the same corpse after its meaningful residue has already been exhausted.
- A fragment cannot activate the source creature’s features, reveal all of its memories, serve as a complete resurrection soul, or satisfy a Soul Anchor requirement unless a Source Rule expressly says otherwise.

#### Custody Status

Every Soul Fragment has one status:

- **Consensual:** Freely given by a willing spirit, ancestor, dying creature, or lawful funerary office.
- **Unclaimed:** Gathered from residue that would otherwise dissipate and whose complete soul has departed or cannot be reached.
- **Coerced:** Taken from an unwilling spirit, trapped soul, or creature whose departure you deliberately obstructed.

Using a Coerced fragment can create **Grave Debt**.

### Grave Debt

Grave Debt records spiritual custody abused beyond necessity.

Gain 1 Grave Debt when you:

- Create a Coerced Soul Fragment from a nonhostile or helpless creature.
- Prevent a willing soul from departing after its legal custody or declared purpose ends.
- Command a manifestation to violate a known funerary oath, Soul Anchor, or protected descendant without necessity.
- Destroy a complete soul or use one as fuel when the Source Rule offered a release or containment route.

Grave Debt is not Daemonic Corruption, Karma, or a universal alignment meter. It is a spiritual complication specific to this method.

At the end of a Full Cultivation Session, if you have Grave Debt greater than your Wisdom modifier, make a Wisdom saving throw against your own Cultivation Save DC.

- **Success:** The debt remains but causes no immediate intrusion.
- **Failure:** Roll `1d6` on the Grave Debt Complication table in the Procedure Addendum, or choose the result before rolling. Apply the printed result; no additional penalty is invented.

Reduce Grave Debt only through the Grave Debt Restitution procedure in the Procedure Addendum. Ordinary gold payment, destroying evidence, releasing a different harmless fragment, or repeating the same completed restitution is insufficient.

### CL3 — Speak with the Dead

You can awaken corpse memory or lingering residue without importing a spell’s fixed assumptions.

**Ritual:** 1 minute  
**Range:** Touch  
**Cost:** 1 Resonance

Choose a corpse with an intact head, chest, or other body part that retains a memory-bearing organ or a funerary object linked to the deceased, funerary object, grave marker, severed body part containing meaningful residue, or location where a creature died within the last year.

Ask up to `1 + half your Proficiency Bonus`, rounded down, questions. The response comes through voice, gesture, corpse movement, remembered sensation, nearby shadows, written condensation, or another appropriate medium.

#### What the Dead Know

The residue can answer only from information the creature knew, perceived, believed, or experienced before death. It may be confused, biased, incomplete, or emotionally distorted. It does not know what occurred after death unless the lingering spirit remained present.

#### Resistance and Protection

The corpse or residue can resist if:

- The creature was hostile to you.
- Its funeral rites prohibit questioning.
- Its soul or memory is sealed.
- Another authority claims custody.
- It died under Secret, divine, artifact, or higher-Source-CL concealment.

Make a Cultivation Check against the protecting effect or the creature’s Charisma save bonus converted into a DC of `8 + Proficiency Bonus + Charisma modifier`. On failure, you learn whether the resistance is unwillingness, ignorance, damage, concealment, or higher custody.

#### Repeat Questioning

Once you use Speak with the Dead on a given residue, you cannot question the same residue again until you learn materially new information, repair it, obtain consent, or a new scene begins. Repetition cannot force a different answer through dice fishing.

#### Funerary Reading

Gain proficiency in Medicine or Religion. If already proficient in both, gain proficiency in Investigation or Insight instead.

### CL6 — Soul Harvest

You can catch a fragment at the moment a meaningful soul sheds residue.

**Reaction**  
**Trigger:** A meaningful creature dies within 30 feet, an undead or spirit is destroyed within 30 feet, or a willing spirit within 30 feet deliberately gives you a fragment  
**Cost:** 1 Resonance

Create one Soul Fragment from the triggering source, subject to your maximum.

The fragment is Consensual if freely given, Unclaimed if the complete soul has already departed and no lawful custody contests it, or Coerced if the source resists or you obstruct departure.

#### Unwilling Source

If a spirit or soul remains present and unwilling, it makes a Charisma saving throw.

- **Failed Save:** You capture one fragment, not the complete soul. If the source is meaningful and nonhostile or helpless, gain 1 Grave Debt.
- **Successful Save:** You gain no fragment, but learn whether the soul is departing, claimed, reincarnating, concealed, or bound by another effect.

A creature at least 5 Source CL lower than you that dies after being damaged by you cannot prevent collection of ordinary residue, but this still does not grant custody of its complete soul.

#### Fragment Uses

As a Bonus Action, spend one Soul Fragment for one benefit:

- Recover Resonance equal to half your Proficiency Bonus, rounded up. You can do this only once per scene.
- Gain Advantage on one Soul Gaze, Speak with the Dead, or Cultivation Check involving death, undead, or the fragment’s source.
- Cause one specter Asset you control to regain Hit Points equal to `5 × Proficiency Bonus`.
- Prevent one spirit or soul within 30 feet from becoming spiritually concealed until the start of your next turn; an equal- or higher-Source-CL creature may resist with a Charisma saving throw.

Spending a fragment releases or consumes the residue according to the declared use. Consuming a Coerced fragment for personal recovery without necessity gains 1 Grave Debt.

### CL10 — Raise Specter

You construct a temporary manifestation from corpse memory or a Soul Fragment. It is a Spirit Cultivation Asset, not the creature restored and not a full companion.

**Action**  
**Cost:** 5 Resonance and 1 Soul Fragment  
**Duration:** The scene, or 1 hour outside conflict  
**Range:** Create the specter in an unoccupied space within 30 feet

Choose **Warden Specter** or **Predatory Specter** when created.

#### Specter Profile

- **Size:** Medium
- **AC:** Your Cultivation Save DC
- **Hit Points:** `6 × Proficiency Bonus`
- **Speed:** Fly 40 feet; hover
- **Saving Throws:** Uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic and Necrotic
- **Immunities:** Poison, Disease, Poisoned, Prone, Grappled, Restrained, and ordinary bodily effects
- **Source CL:** Your effective Spirit Awakening CL
- **Action economy:** No independent turn. At the end of each of your turns, it moves up to its Speed. As a Bonus Action, direct one Specter Expression.

#### Warden Specter Expressions

- **Guard the Threshold:** One ally within 10 feet of the specter gains Half Cover and Advantage on its next saving throw against possession or soul displacement before the start of your next turn.
- **Seize Intruder:** One spirit, incorporeal undead, possessed creature, or Resonance Marked creature within 10 feet makes a Charisma saving throw. On a failure, its Speed becomes 0 and it cannot possess another creature until the start of your next turn.
- **Testify:** The specter reproduces one memory, route, image, or statement contained in the spent fragment. Protected information remains limited to what the fragment held.

#### Predatory Specter Expressions

- **Spectral Strike:** Make a Cultivation Attack against a creature within 5 feet. On a hit, deal `2d10 + Wisdom modifier` Necrotic or Psychic damage.
- **Harrier of the Living:** One creature within 10 feet cannot take Reactions and has Disadvantage on the next death saving throw it makes before the start of your next turn. This cannot target an ally unless the ally willingly accepts the risk.
- **Drink Fear:** One Frightened or Resonance Marked creature within 10 feet makes a Wisdom saving throw. On a failure, it takes `2d8` Psychic damage and you gain Temporary Hit Points equal to your Proficiency Bonus.

#### Destruction

If the specter is reduced to 0 Hit Points, it disperses. If created from a Coerced fragment, you take Psychic damage equal to `2 × Proficiency Bonus` as the custody breaks.

The source’s complete soul is not harmed merely because the specter is destroyed. A manifestation cannot use the source creature’s attacks, spell list, Legendary actions, equipment, full statistics, or identity-defining features.

#### Soul Splitting Expression — Twin Custody

While Soul Splitting is active, the Soul Fragment may serve as the origin of a Specter Expression. The specter still receives only one expression per Bonus Action and gains no independent action.

### CL14 — Soul Drain and Death Custody

You can draw spiritual vitality from a living soul or collapse the animating residue of an undead creature.

**Action**  
**Range:** 30 feet  
**Cost:** 6 Resonance

Choose one creature. It makes a Constitution saving throw. A spirit, incorporeal undead, possessed creature, or creature bearing your Resonance Mark may use Charisma instead if that bonus is higher.

**Failed Save:** The target takes `6d8 + Wisdom modifier` Necrotic or Psychic damage, your choice. Until the end of its next turn, it cannot regain Hit Points or restore Cultivation Points. If it is a spirit or undead, it also cannot become incorporeal, possess another creature, or return to a prepared vessel during that time.

**Successful Save:** It takes half damage and cannot become spiritually concealed until the start of your next turn.

#### Capture at the Brink

If Soul Drain reduces a qualifying hostile creature to 0 Hit Points, choose one:

- Create one Soul Fragment without using your Reaction.
- Stabilize the creature and place its departing residue under **Death Custody** until the end of the scene.

A creature under Death Custody does not die, depart, reincarnate, become undead, or have its soul seized by an ordinary lower-Source-CL effect while custody remains. It is stable at 0 Hit Points. You must choose one outcome before the scene ends:

- Release it to die or depart normally.
- Permit legal healing.
- Transfer custody to a willing healer, funerary authority, or prepared vessel.
- Attempt a lawful interrogation through Speak with the Dead if death occurs.
- Convert the residue into a Coerced Soul Fragment, gaining 1 Grave Debt unless necessary to prevent a greater spiritual catastrophe.

Equal- or higher-authority death claims, divine custody, Secret Laws, Samsara, or artifacts can contest Death Custody with Source CL and their printed procedures.

#### Warden’s Reversal

As a Reaction when an ally within 30 feet would have its soul displaced, consumed, trapped, or converted into an undead manifestation, spend one Soul Fragment. The ally gains Advantage on the relevant save. If no save exists, it makes a Charisma saving throw against the effect’s save DC. On success, delay the effect until the end of the ally’s next turn, allowing escape, healing, Exorcism, or another intervention.

### CL18 — Lord of the Dead

You establish temporary jurisdiction over the dead in the scene and manifest a warden-wraith built from your cultivated office.

**Action**  
**Cost:** 10 Resonance and 1 Soul Fragment  
**Duration:** The scene  
**Concentration:** No

Create a **Warden-Wraith**, a Large Spirit Cultivation Asset in an unoccupied space within 30 feet.

#### Warden-Wraith Profile

- **AC:** Your Cultivation Save DC
- **Hit Points:** `12 × Proficiency Bonus`
- **Speed:** Fly 50 feet; hover
- **Saving Throws:** Uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic, Necrotic, Radiant
- **Immunities:** Poison, Disease, Poisoned, Prone, Grappled, Restrained, and ordinary bodily effects
- **Source CL:** Your effective Spirit Awakening CL
- **Action economy:** No independent turn. At the end of each of your turns, it moves up to its Speed. As a Bonus Action, direct one Wraith Expression.

#### Wraith Expressions

- **Warden’s Scythe:** Make a Cultivation Attack against one creature within 10 feet. On a hit, deal `4d10 + Wisdom modifier` Necrotic, Psychic, or Radiant damage. A spirit or undead hit cannot take Reactions until the start of your next turn.
- **Chain the Departing:** One spirit, incorporeal undead, projected soul, or creature attempting teleportation, reincarnation, soul escape, or possession within 30 feet makes a Charisma saving throw. On a failure, the attempted movement or transition fails and the creature is Restrained by spiritual chains until the end of its next turn. On success, its Speed is halved or it suffers one ordinary Spiritual Pressure effect.
- **Open the Proper Gate:** Release one willing spirit, end one ordinary lower-Source-CL coercive binding, or permit one soul under Death Custody to depart through the correct afterlife, reincarnation, ancestor court, or Soul Anchor route. Equal or higher custody requires a Cultivation Check.
- **Procession of Witnesses:** Up to Proficiency Bonus corpses, grave residues, or willing local dead within 60 feet produce brief testimony, reveal their direction of death, or indicate the presence of a murderer, possessor, necromantic Anchor, or concealed spirit they genuinely perceived.
- **Burial Silence:** Create a 20-foot-radius zone centered on the wraith until the start of your next turn. Hostile spirits and undead in the zone cannot regain Hit Points, restore Cultivation Points, become invisible, or create new possessed hosts.

#### Jurisdiction of the Dead

While the Warden-Wraith exists:

- Ordinary lower-Source-CL undead and unbound specters within 60 feet cannot attack you unless they succeed on a Charisma saving throw at the start of their turn.
- You know when a creature dies within 60 feet and whether its soul departs, remains, is seized, reincarnates, or becomes concealed.
- You may maintain a number of Soul Fragments equal to twice your Proficiency Bonus for the activation’s duration.
- Coerced fragments cannot be hidden from you by ordinary means.

#### Complete Soul Boundary

Once during the activation, when a hostile spirit at least 5 Source CL lower than you, undead ruler, or soul predator is reduced to 0 Hit Points within 60 feet, you may attempt **Final Custody**.

The target makes a Charisma saving throw.

- **Failed Save:** Its complete soul or governing death-fragment is sealed inside the Warden-Wraith until the feature ends. While sealed, it cannot reform, possess, reincarnate, return to a phylactery-like Anchor, or activate a death-triggered escape. Before the feature ends, you must release it, transfer it to a legal prison or afterlife route, or create a specific long-term Anchor under a separate Source Rule.
- **Successful Save:** Its attempted escape is delayed until the end of its next turn and it suffers one ordinary Spiritual Pressure effect.

Final Custody is not permanent soul destruction. Equal- or higher-Source-CL targets use their printed escape procedures and may force a Cultivation Check contest.

#### Wraith Destruction

If the Warden-Wraith is destroyed, you take `6d10` Psychic damage that ignores Resistance, every Soul Fragment beyond your normal maximum is released, and any complete soul held by Final Custody escapes to the nearest legal route. You cannot use Lord of the Dead again until you complete a Full Cultivation Session.

#### Forbidden Consequences

Using Lord of the Dead to release, protect, or lawfully imprison spirits creates no Grave Debt. Each of the following creates 2 Grave Debt when completed: consume an unwilling Complete Soul; create permanent slavery of a Complete Soul; obstruct a recorded rightful afterlife route for personal gain; or weaponize a protected ancestor against its recorded will. One act can create Grave Debt only once under this list, even if several descriptions apply. Higher spiritual authorities may perceive or contest the act according to their Source Rules.

### Normalized Death-Custody Procedures

#### Qualifying Hostile Creature
For Capture at the Brink, a creature qualifies when all of these are true: it was hostile during the current scene; it was not created, summoned, dominated, restrained, or offered by you or an ally for harvesting; it took at least one hostile Action, Bonus Action, Reaction, or scene-changing cultivation action; and its defeat materially advances or protects the scene objective. A helpless captive, harmless animal, staged combatant, or repeatedly restored target never qualifies.

#### Grave Debt Complication Table
| d6 | Complication | Exact effect | Ending procedure |
|---:|---|---|---|
| 1 | Corpse Voices | You have Disadvantage on the first Wisdom or Charisma ability check you make in the next scene. | The check occurs, or you complete a 10-minute funerary-settling rite before the scene. |
| 2 | Unstable Fragment | One Coerced fragment of your choice cannot be spent and audibly manifests distress to Spiritual Sense. If you have none, the next Coerced fragment you create gains this state. | Release it, change it to Consensual through actual consent, or complete a 1-hour containment rite. |
| 3 | Strained Soul Anchor | Your Soul Anchor becomes Strained. | Complete a 1-hour funerary reconciliation rite and release or lawfully house one Coerced fragment. |
| 4 | Underworld Notice | You bear a visible-to-Spiritual-Sense custody writ. Lawful dead and funerary officers begin one social step less friendly toward you. | Accept one lawful hearing, complete one recorded restitution, or succeed on a Cultivation Check proving the Debt was incurred to prevent a greater catastrophe. |
| 5 | Descendant's Omen | One living descendant, sworn successor, or recognized custodian of a Coerced fragment receives an omen identifying your broad direction and the custody category. | Release or lawfully transfer that fragment, or obtain consent from the notified custodian. |
| 6 | Hostile Reception | The next nonallied spirit you intentionally question, petition, or bargain with begins Hostile rather than Indifferent. | Resolve that interaction, withdraw without coercion, or first present a Consensual fragment as witness and release it afterward. |

#### Grave Debt Restitution
One completed restitution reduces Grave Debt by 1: release one Coerced fragment to its lawful route; return remains or a funerary object to the proper custodian; complete a known unfinished duty for the same dead; accept and fulfill a lawful judgment; repair a violated grave, shrine, or Anchor; or convert one Coerced fragment into Consensual custody through informed consent. A single soul, grave, or duty reduces Debt only once unless a later distinct violation affects it again. A breakthrough-scale judgment or underworld rite may reduce more only when its Source Rule prints the amount.

#### Death Custody
Death Custody is a temporary Contained state over departing residue, not ownership of a Complete Soul. At the scene's end, if you have not chosen a printed outcome, custody automatically ends and the creature dies or departs through the route it would have taken without the feature. A prepared vessel must already possess a valid Spiritual Anchor profile and willing custodian. Transfer does not make the recipient owner and cannot bypass equal-or-higher custody.

#### Lawful Routes
A lawful route is one already available to that soul: return to its living body or Soul Anchor; departure to a recognized afterlife or ancestor court; reincarnation or Samsara; release into a willing prepared vessel; custody by a recognized funerary authority; or a prison expressly authorized by a Source Rule. The practitioner cannot declare a new route merely to retain custody.

#### Final Custody
Final Custody requires the target to be at least 5 Source CL lower, hostile, at 0 Hit Points, and attempting or possessing a printed death-triggered transition. It seals the Complete Soul only for the remaining activation. If no legal prison or long-term Anchor is established before the Warden-Wraith ends, the soul automatically takes its nearest lawful route. The Warden-Wraith cannot consume, interrogate, copy, or spend the Complete Soul unless another feature expressly allows that action.

#### Specter and Wraith Asset Boundary
Specters and the Warden-Wraith are single Spirit Cultivation Assets with no independent turn. They cannot wear equipment, provide companion evolutions, use the source creature's Spheres, count as the source creature for resurrection, or be duplicated by Soul Splitting. Twin Custody changes an origin only; it never creates a second Specter Expression.

### Integrated Procedure Closure — Soul Warden / Necromancer

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Twin Custody. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 11. Halo Eater

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden angelic method, stolen shrine scripture, fallen guardian pact, radiant-predator initiation, or the surviving organ of a devoured blessing.  
**Identity:** Devouring spiritual radiance, benedictions, visible virtue, protective authority, and the power invested in sacred signs.  
**Primary role:** Anti-buff pressure, blessing diagnosis, hostile sustain theft, radiant defense, and high-authority spiritual predation.  
**Sphere Lean:** Light, Spirit, Healing, Corruption. This tradition grants none of those Spheres.  
**Cultivation boundary:** A Halo Eater consumes the spiritual investment carried by a blessing or sacred protection. It does not automatically negate every healing effect, erase a deity, invalidate an oath, steal a creature’s moral character, or copy a complete feature sheet.

> *Your blessing is beautiful. Hold still while I taste it.*

Halo Eaters embody a disturbing angelic philosophy: holiness is not purity but concentrated nourishment. They taste the structure of a benediction, bite through the ward that carries it, and wear the stolen brilliance as a false crown. Temples often condemn them more fiercely than ordinary corrupters because a Halo Eater proves that visible sanctity can be hunted.

### Stolen Radiance

Several Halo Eater features create or spend **Stolen Radiance**.

- Your Stolen Radiance begins at 0 at the start of each scene.
- Its maximum equals your Proficiency Bonus.
- You gain 1 Stolen Radiance when a meaningful hostile creature within 60 feet does one of the following and you consciously perceive the spiritual event:
  - receives healing from a supernatural Source Rule;
  - gains Temporary Hit Points from a blessing, ward, oath, shrine, spirit, cultivation technique, or artifact;
  - activates or renews a holy, radiant, protective, oath-bearing, or visibly sanctified effect;
  - succeeds on a saving throw because of a supernatural blessing or protection;
  - loses or has suppressed a qualifying blessing because of one of your Halo Eater features.
- You can gain no more than 1 Stolen Radiance from a single triggering effect and no more than 1 per turn.
- You cannot gain Stolen Radiance from your own effects, willing allies staging repeated blessings, harmless summons, ceremonial healing with no meaningful danger, repeatedly restored captives, or an effect created principally to feed this resource.
- Stolen Radiance lasts for the scene. It is not Resonance and cannot be converted directly into Resonance.

#### Qualifying Radiance

A **qualifying radiance** is a supernatural blessing, ward, benediction, protective aura, holy or radiant enhancement, oath-backed defense, shrine protection, divine favor, artifact safeguard, or similar invested spiritual benefit. Ordinary Hit Point recovery, mundane armor, natural regeneration, and purely physical cover are not qualifying radiance unless a Source Rule expressly spiritualizes them.

When uncertainty exists, Soul Gaze can identify whether an effect carries qualifying radiance and its broad authority category.

### CL3 — Taste the Radiance

**Reaction**  
**Trigger:** A creature within 60 feet gains or activates qualifying radiance, receives supernatural healing, or becomes Resonance Marked by you while carrying qualifying radiance  
**Cost:** 1 Resonance

Taste the spiritual structure of the triggering effect.

You learn:

- its broad purpose;
- whether it is healing, warding, cleansing, empowering, oath-bearing, shrine-backed, divine, artifact-based, or another recognizable category;
- whether its Source CL is lower than, equal to, or higher than yours;
- whether it is ordinary, Restricted, Rare, Forbidden, Secret, divine, artifact-level, tribulation-scale, or otherwise exceptional.

A concealed or deliberately masked source can require a Cultivation Check against the protecting effect. On failure, you still learn that meaningful radiance is present and that its details are concealed.

If the triggering creature is a meaningful hostile creature, gain 1 Stolen Radiance and Temporary Hit Points equal to your Proficiency Bonus. These Temporary Hit Points do not stack with themselves.

#### Aftertaste

Until the end of your next turn, the creature is **savored** by you. Your Halo Eater features can target a savored creature as though it were Resonance Marked by you, but savoring is not itself a Resonance Mark and grants no benefit to unrelated features.

### CL6 — Bite the Halo

**Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Requirement:** The target is savored by you, Resonance Marked by you, or visibly carries qualifying radiance

Choose one creature. It makes a Charisma saving throw.

**Failed Save:** The target takes `4d8 + Wisdom modifier` Psychic or Radiant damage, your choice. Choose one qualifying effect on it that you identified or can visibly perceive.

- If the effect is ordinary and has lower Source CL, it ends.
- If it is Restricted or has equal Source CL, it is suppressed until the end of your next turn. At the end of each of the target’s turns, it repeats the save, ending the suppression on a success.
- A higher-Source-CL, Rare, Forbidden, Secret, divine, artifact, tribulation, or identity-defining protection is strained rather than automatically ended. Suppress one printed benefit of that protection until the start of your next turn, subject to a Cultivation Check if its authority is equal or higher.

**Successful Save:** The target takes half damage. One qualifying effect you can perceive flickers: you learn its remaining duration and one condition that could legally end, discharge, bypass, or restore it.

If you end or suppress a qualifying effect, gain 1 Stolen Radiance.

#### Devoured Effect Recovery

Bite the Halo does not permanently delete the source that created a blessing unless the source itself is destroyed by another procedure.

- A creature can receive the blessing again from its lawful source.
- A discharged item can be recharged according to its own rules.
- A shrine or Anchor can restore its protection when repaired or reconsecrated.
- A complete oath, divine office, Foundation, Method, or artifact authority cannot be consumed through this feature merely because one expression was ended.

### CL10 — Stolen Benediction

You can convert predation into a controlled counterfeit blessing.

**Reaction**  
**Trigger:** A meaningful hostile creature within 60 feet receives supernatural healing, gains Temporary Hit Points, or succeeds on a save against Charmed, Frightened, possession, curse, spiritual contamination, identity damage, or memory damage because of qualifying radiance  
**Cost:** 3 Resonance and 1 Stolen Radiance

Choose one **Benediction Shape**:

#### Restoring Shape

You or one ally within 30 feet regains Hit Points equal to `2d8 + Wisdom modifier`.

#### Warding Shape

You or one ally within 30 feet gains Temporary Hit Points equal to `2 × Proficiency Bonus + Wisdom modifier` and Advantage on the next Intelligence, Wisdom, or Charisma saving throw made before the end of its next turn.

#### Cleansing Shape

End Charmed or Frightened on yourself, or suppress one ordinary curse, ordinary possession, Nightmare Scar, spiritual contamination, or Spiritual Pressure effect on yourself until the end of your next turn.

#### Reflecting Shape

The triggering creature becomes Resonance Marked by you. If it already bears your mark, impose one ordinary Spiritual Pressure effect on it.

Stolen Benediction does not reduce the triggering creature’s benefit unless another Halo Eater feature says so. It copies only a general benediction shape, not the triggering feature’s name, tags, charges, scaling, limited uses, or unique authority.

#### Predatory Mercy

Once per scene, when you use Stolen Benediction because a hostile creature succeeded against possession, curse, or spiritual contamination, you may use Cleansing Shape on one willing ally within 30 feet instead of yourself.

### CL14 — Crown of Borrowed Light

**Bonus Action**  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Initial fuel:** Spend up to 3 Stolen Radiance

Manifest a stolen halo. It sheds bright spiritual light in a 20-foot radius and dim spiritual light for another 20 feet. This is a Spirit Awakening field with your Source CL. You may suppress its visible light without ending its spiritual presence.

While the Crown lasts:

- You have Resistance to Radiant and Psychic damage.
- You can perceive qualifying radiance within the field even when its physical light is concealed.
- A hostile creature in the field cannot gain more than one benefit from the same named healing or Temporary Hit Point feature during the same turn unless its Source Rule expressly allows repeated applications.
- Once on each of your turns when you damage a savored or Resonance Marked creature with a Spirit Awakening feature, choose one ally in the field. That ally gains Temporary Hit Points equal to `Wisdom modifier + Proficiency Bonus`.
- If the damaged creature is protected by a shrine, oath, divine office, holy artifact, or qualifying radiance, impose one ordinary Spiritual Pressure effect on it.

For each Stolen Radiance spent when the Crown manifests, choose one **Crown Facet**:

#### Facet of Sanctuary

Allies in the field gain a +1 bonus to Intelligence, Wisdom, and Charisma saving throws.

#### Facet of Hunger

The first time each round a hostile creature in the field gains qualifying radiance, it takes Psychic damage equal to your Proficiency Bonus and becomes savored by you until the end of your next turn.

#### Facet of False Grace

When an ally in the field would be reduced to 0 Hit Points, you may use your Reaction and spend 2 Resonance. It drops to 1 Hit Point instead, and the Crown loses this Facet for the rest of the scene.

A creature can benefit from False Grace only once per activation.

#### Crown Collapse

If a higher-authority effect tears away the Crown, make a Wisdom saving throw against that effect’s save DC. On failure, take `4d8` Psychic damage and lose all remaining Stolen Radiance. On success, take half damage and retain 1 Stolen Radiance.

### CL18 — Empty Heaven Maw

You can open a spiritual absence shaped specifically to consume invested sanctity.

**Action**  
**Range:** 90 feet  
**Cost:** 10 Resonance and all remaining Stolen Radiance, minimum 1  
**Requirement:** The target is Resonance Marked or savored by you and carries qualifying radiance

Choose one creature, shrine, sacred Formation, blessing Anchor, divine projection, or protective spiritual Asset. A creature makes a Charisma saving throw. An unattended Asset or Anchor is resolved against its Source CL and printed defenses.

**Failed Save or Successful Authority Contest:**

- The target takes `10d10 + Wisdom modifier` Psychic or Radiant damage, your choice.
- Choose one qualifying radiance expression for each Stolen Radiance spent, maximum three.
- An ordinary or Restricted expression with lower Source CL ends.
- An equal-Source-CL expression is suppressed for the scene. At the end of each of the target’s turns, it may repeat the save; three successes restore one suppressed expression.
- A higher-Source-CL, Rare, Forbidden, Secret, divine, artifact, tribulation, or office-defining expression is not erased automatically. Choose one printed benefit to suppress until the end of your next turn. A successful Cultivation Check extends that suppression until the end of the target’s next turn instead.
- You regain Hit Points equal to half the damage actually dealt, to a maximum of half your Hit Point maximum.

**Successful Save or Failed Authority Contest:** The target takes half damage. Suppress one ordinary qualifying expression until the start of your next turn, or cause a higher-authority expression to visibly reveal its Anchor, source direction, or restoration condition.

#### Vacant Halo

If Empty Heaven Maw ends at least one qualifying effect, leave a **Vacant Halo** on the target for the scene.

- The Vacant Halo is visible to Spiritual Sense.
- The first time each round the target would receive qualifying radiance, resolve the **Vacant-Halo Tax**. If the incoming Source Rule has a printed expendable activation cost, its user must pay 1 additional unit of one such resource; that user chooses among multiple eligible resources. If the additional unit is not paid, the new radiance remains suppressed until the start of the target's next turn.
- If the incoming Source Rule has no printed expendable activation cost, or its user has no eligible unit remaining, its user makes a Cultivation Check against your Cultivation Save DC. On success, the new radiance functions normally; on failure, it is suppressed until the start of the target's next turn.
- A meaningful purification, reconsecration, source-specific restoration, or an equal- or higher-Source-CL cleansing effect removes the Vacant Halo.

Empty Heaven Maw cannot consume a deity, moral worth, an entire oath relationship, a complete Foundation, a complete Method, or an artifact’s existence without a dedicated Source Rule or campaign-scale rite.

#### Soul Splitting Expression — Hungry Reflection

While Soul Splitting is active, use **Hungry Reflection** as your Subpath Expression. Move your Soul Fragment up to 20 feet. Until the start of your next turn, it may serve as the origin of Taste the Radiance or Bite the Halo. You still activate the chosen feature once, pay one cost, and select one target. The first qualifying radiance you perceive within 15 feet of the fragment before then is visibly outlined to Spiritual Sense, revealing its source direction and broad category; this does not grant additional Stolen Radiance beyond the normal once-per-turn limit.

### Normalized Radiance Procedures

#### Qualifying-Radiance Record
When Taste the Radiance identifies an effect, record its Source Rule, Source CL band, category, target, remaining duration if perceptible, sustaining Asset or Anchor if any, and whether it has an expendable activation cost. This record prevents later effects from selecting an unobserved or unrelated protection.

#### Bite the Halo Selection
Choose one discrete printed benefit, named effect, aura, ward, bonus, resistance, temporary protection, or recurring expression. A complete Path, Foundation, Method, office, oath relationship, item, deity, or creature is never a single selectable expression unless its Source Rule expressly says the whole structure is one effect. Ending or suppression does not refund its original cost.

#### Vacant-Halo Tax
Eligible expendable costs are Resonance, Qi, Stamina, another Cultivation Point, a charge, a limited use, a Hit Die, a consumed Offering, a named buildup point, or a consumed material printed as part of the activation. Actions, movement, Concentration, damage suffered, passive prerequisites, and resources paid by another creature are not eligible. The tax is paid by the creature or Asset activating the incoming Source Rule, not necessarily the Halo's bearer.

#### Crown Facets
Each Facet can be selected only once during the same Crown activation. Spending fewer than 3 Stolen Radiance grants that many distinct Facets. A lost False Grace Facet cannot be selected again without a new Crown activation.

#### Empty Heaven Maw and Assets
An unattended Asset or Anchor uses its printed save, defense, or Source CL contest. If none exists, make a Cultivation Check against `10 + its Source CL PB + 3`. Damage applies to an Asset's Hit Points only if the target has a Hit Point profile; otherwise resolve only the suppression and revelation results.

#### Realm Suppression
Stolen Radiance already gained remains until the scene ends but cannot fuel a feature above effective CL. Crown of Borrowed Light ends if effective CL falls below 14. Vacant Halo is an independent scene state and retains its creation Source CL. Empty Heaven Maw cannot be activated below effective CL18.

### Integrated Procedure Closure — Halo Eater

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Hungry Reflection. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 12. Choir of the Unopened Eye

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden angelic choir, sealed hymnbook, eye-covered idol, witness-cult initiation, or pact with a many-voiced watcher.  
**Identity:** Harmony, surveillance, confession, synchronized judgment, and the terror of being perfectly witnessed.  
**Primary role:** Revelation, anti-concealment, reaction denial, truth pressure, coordinated control, and witness-based imprisonment.  
**Sphere Lean:** Sound, Light, Mind, Spirit. This tradition grants none of those Spheres.  
**Cultivation boundary:** The Choir creates coercive spiritual witness. It does not provide universal omniscience, automatically reveal every secret, compel protected passwords, or replace Sovereign Will’s hierarchy and command authority.

> *There is no prison like being completely understood.*

The Choir does not hide violence behind darkness. It watches, harmonizes, reveals, and forces the observed self to remain consistent under attention. Its practitioners are feared not because they always know the truth, but because once enough voices agree on what they witnessed, escape becomes spiritually expensive.

### Witness Notes

Several Choir features place **Witness Notes**.

- A Witness Note is a spiritual notation attached to a creature, object, location, statement, disguise, or active effect.
- You can maintain a number of Witness Notes equal to your Proficiency Bonus.
- Placing a Note beyond that maximum ends the oldest Note of your choice.
- A Note normally lasts for the scene.
- A Note is visible to Spiritual Sense as an eye, chord, written syllable, afterimage, halo-fragment, or another appropriate sign.
- A lower-Source-CL ordinary concealment cannot hide a Note from you. Equal or higher authority can contest perception with a Cultivation Check.
- A Witness Note is not a curse, charm, Resonance Mark, or Spirit Companion bond.
- Notes on willing allies, harmless objects, or staged statements cannot be used to generate hostile-control benefits.

### CL3 — Witness Note

When you use Spiritual Sense, Soul Gaze, or another legal diagnostic procedure on a creature or effect, you may spend 1 Resonance to place a Witness Note on one observed subject.

Choose one **Notation**:

#### Face Notation

Ordinary invisibility, mundane disguise, and ordinary illusion cannot prevent you from identifying the subject as the same spiritual presence while it remains within 60 feet. This does not reveal a new body behind total cover or defeat higher-authority transformation automatically.

#### Voice Notation

While the subject is within 60 feet and you can hear it, you know when it knowingly contradicts a statement it made while bearing the Note. You do not automatically learn which statement was false or the complete truth.

#### Wound Notation

You know when the subject gains or loses Hit Points, Temporary Hit Points, a possession effect, a spiritual contamination, or a Resonance Mark while within 60 feet.

#### Threshold Notation

Place the Note on a doorway, boundary, object, corpse, shrine, or 5-foot space. You know when a spiritually perceptible creature crosses, possesses, activates, removes, or meaningfully alters the subject while you are within 300 feet on the same plane.

#### Chorus Recognition

Once per turn when a hostile creature bearing your Witness Note becomes Resonance Marked by you, you may impose Revealed Disturbance as its ordinary Spiritual Pressure effect without additional cost.

### CL6 — Hymn of Stillness

**Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Target:** One creature that can hear you or bears your Witness Note

The target makes a Wisdom saving throw.

**Failed Save:** It takes `3d8 + Wisdom modifier` Psychic damage and is caught in synchronized observation until the start of your next turn. During that time:

- it cannot take Reactions;
- its Speed is reduced by 10 feet;
- it cannot willingly benefit from ordinary invisibility or an ordinary disguise against you;
- if Resonance Marked by you, choose one additional ordinary Spiritual Pressure effect for it.

**Successful Save:** It takes half damage. Choose either to reduce its Speed by 10 feet or prevent Reactions until the start of your next turn.

#### Sustained Refrain

At the start of your next turn, you may spend 1 Resonance to force a target that failed to repeat the save.

- On a failure, the Stillness continues until the start of your following turn.
- On a success, it ends.
- You can sustain only one Hymn of Stillness at a time.
- Damage from the Hymn is dealt only on the initial use.

A creature with lower Source CL that fails by 5 or more cannot speak a deliberate lie while the Hymn persists, though it can remain silent.

### CL10 — Forced Confession

You can force an observed contradiction to surface as an emotionally true statement.

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance  
**Requirement:** The target can hear you and bears your Witness Note or Resonance Mark

Choose one question from the following list and speak it aloud:

- What do you fear will happen next?
- What are you trying to protect?
- Whom or what do you presently serve?
- What guilt or shame is influencing this decision?
- What immediate action do you intend?
- What desire are you refusing to name?

The target makes a Charisma saving throw.

**Failed Save:** It must speak one emotionally true sentence that directly concerns the chosen question. It may use metaphor if literal speech is impossible, but it cannot knowingly answer with a falsehood.

**Successful Save:** You learn which broad motive currently dominates it: fear, duty, hunger, love, pride, grief, hatred, survival, obedience, or concealment.

#### Protected Information

Forced Confession does not automatically reveal:

- protected names;
- passwords or exact tactical plans;
- a Secret Law’s hidden procedure;
- a sealed memory;
- divine or artifact-confined knowledge;
- facts the target genuinely does not know;
- an identity whose exposure would itself require higher authority.

If the answer would cross such protection, the target instead speaks a true sentence describing the pressure surrounding the secret. A Cultivation Check against the protecting effect can reveal one additional useful category, but not necessarily the exact secret.

#### Confession Echo

If the target fails, you may place a new Witness Note on the spoken statement without counting against the once-per-turn limits of another feature. For the scene, you know when the target knowingly acts in direct contradiction to that statement while within 300 feet on the same plane.

### CL14 — All Eyes Open

**Bonus Action**  
**Cost:** 6 Resonance  
**Duration:** The scene

Manifest a **Choir of Unopened Eyes**, a Spirit Awakening field extending 30 feet from you. Invisible spiritual eyes, reflected faces, harmonized whispers, or rings of unreadable script fill the field.

While the field lasts:

- You cannot be surprised by a spiritually perceptible creature in the field unless protected by higher authority.
- Ordinary invisibility, ordinary illusion, mundane disguise, and ordinary voice mimicry cannot grant Advantage against you.
- Hostile creatures of your choice have Disadvantage on Deception checks made in the field and on saves made to maintain ordinary disguises or illusions against your observation.
- A creature bearing your Witness Note cannot teleport, cross a planar boundary, or spiritually project out of the field without leaving a visible departure chord that identifies the direction and broad method used.
- Once per round when a hostile creature in the field becomes Resonance Marked or contradicts a witnessed statement, impose one ordinary Spiritual Pressure effect on it.

#### Chorus Assets

When the field manifests, create three **Unopened Eyes**. They are stationary Cultivation Assets placed in unoccupied spaces you can see in the field.

Each Eye has:

- **Type and Size:** Tiny stationary Spirit Cultivation Asset
- **AC:** Your Cultivation Save DC
- **Hit Points:** `3 × Proficiency Bonus`
- **Speed:** 0 feet
- **Source CL:** Your effective Spirit Awakening CL
- **Damage Immunities:** Poison and Psychic
- **Condition Immunities:** Charmed, Frightened, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained
- **Perception:** Shares your Spiritual Sense within 15 feet of itself
- **At 0 Hit Points:** It is destroyed, deals the printed Psychic damage to you, and leaves no creature or corpse.

An Eye does not take a turn. Once on each of your turns, choose one surviving Eye as the origin of Spiritual Sense, Soul Gaze, Hymn of Stillness, Forced Confession, or a technique that expressly permits a spiritual Asset as its origin.

Destroying all three Eyes ends the field. If an Eye is destroyed, you take Psychic damage equal to your Proficiency Bonus. Soul Splitting cannot duplicate these Eyes or grant them independent actions.

#### Closed Testimony

As a Bonus Action, spend 2 Resonance and choose two surviving Eyes. Until the start of your next turn, the straight line between them becomes a witness barrier. A lower-Source-CL creature bearing your Witness Note cannot cross that line unless it succeeds on a Charisma saving throw. On a failure, its movement stops before the line and it suffers one ordinary Spiritual Pressure effect.

### CL18 — Edict of Perfect Witness

You can make the Choir’s shared observation temporarily more authoritative than the target’s preferred self-presentation.

**Action**  
**Range:** 90 feet  
**Cost:** 10 Resonance  
**Requirement:** The target bears both your Witness Note and Resonance Mark, or is inside All Eyes Open and has failed against one of your features this scene

Choose one creature that can hear you. It makes a Charisma saving throw.

**Failed Save:** For up to 1 minute, subject to repeated saves, the target is under **Perfect Witness**.

While under Perfect Witness, it cannot willingly:

- speak a deliberate lie;
- benefit from ordinary invisibility, disguise, or illusion against creatures you designate;
- teleport, plane shift, project its soul, or cross a sealed threshold without first using its Action to declare the broad method and intended destination;
- target a creature other than you with an attack or hostile technique while you are a legal target, unless it first uses its Action to state one emotionally true reason it refuses your witness;
- conceal whether it is possessed, oath-bound, coerced, disguised, carrying a hidden spiritual Asset, or acting under a direct command, though exact details may remain protected.

At the end of each of its turns, it repeats the save. Each success removes one bullet of its choice. Three successes end Perfect Witness. A failed repeat save imposes one ordinary Spiritual Pressure effect.

**Successful Initial Save:** Until the end of its next turn, it cannot willingly lie, cannot benefit from ordinary invisibility against you, and suffers two different ordinary Spiritual Pressure effects as one exceptional pressure package.

#### Equal and Higher Authority

A Secret Law, divine silence, artifact mask, identity-defining transformation, or equal- or higher-Source-CL concealment can contest individual expressions of the Edict. A successful contest suppresses only the disputed bullet, not the entire feature.

Perfect Witness does not compel revelation of facts the target does not know, force self-incrimination in exact legal terms, or grant you control of the target’s full turn. It is terrifying because it narrows evasion, not because it creates omniscience.

#### Witness Aftermath

When Perfect Witness ends, every creature that directly observed the Edict retains a clear memory that extraordinary spiritual coercion occurred. Ordinary memory alteration cannot erase that fact from a lower-Source-CL witness, though it may blur details. This social and spiritual evidence is one reason the method remains Forbidden.

#### Soul Splitting Expression — Second Witness

While Soul Splitting is active, use **Second Witness** as your Subpath Expression. Move your Soul Fragment up to 20 feet and choose one subject within 30 feet of it that bears your Witness Note. Until the start of your next turn, the fragment counts as a second witness position for determining whether that subject is within range of Face, Voice, Wound, or Confession Echo notation. This does not place a new Note, duplicate an activation, or permit a statement or event hidden from both positions to be witnessed.

### Normalized Witness Procedures

#### Witness Note Record
Every Note records its subject, Notation, creation time, Source CL, last known plane, and the exact statement or threshold when relevant. A Note on a statement stores no more than 25 spoken words or one concise proposition. A Note does not create truth; it records contradiction against the subject's own knowingly held understanding at the time of the later act.

#### Knowing Contradiction
A contradiction occurs only when the subject understands both propositions and knowingly treats them as incompatible. Changed beliefs, new information, metaphor, mistaken recollection, coerced speech, ambiguity, and predictions that later fail do not count automatically. When disputed, the subject makes a Charisma save against your Cultivation Save DC; on success, no contradiction trigger occurs, though the Note remains.

#### Threshold Notation
A threshold Note defines one doorway, boundary surface, discrete object, corpse, shrine, or 5-foot cube when placed. It reports the crossing, possession, activation, removal, or meaningful alteration and the broad category of the actor if spiritually perceptible. It does not provide exact identity through stronger concealment or a continuous map after the event.

#### Closed Testimony Geometry
The barrier is the vertical plane rising 20 feet above the straight line between the centers of the two Eyes and extending down to the supporting surface. It has no thickness, provides no Cover, and blocks only the printed crossing. A creature already intersecting the plane when it forms chooses the nearest legal side without spending movement. Forced movement receives the same save; on failure it stops at the plane.

#### Initiative and Surprise
“All Eyes Open” prevents the Surprised state or equivalent loss of first-turn actions only against a spiritually perceptible creature already in the Field when initiative is determined. It does not reveal total-cover positions or prevent environmental hazards, mundane creatures outside Spiritual Sense, or higher-authority concealment from using their printed initiative benefits.

#### Perfect Witness Action Taxes
The declaration required before teleportation, projection, threshold crossing, or hostile targeting is an Action separate from the prohibited activity. It states only the broad method, broad destination, or emotionally true reason. The target can complete the activity on the same turn only if it has another legal Action or a feature that performs the activity without using an Action. The declaration itself is not a confession of protected exact details.

#### Witness Evidence
Witness Aftermath records one fact: extraordinary coercive spiritual witness occurred, the apparent source, and the scene in which it happened. It does not make every statement legally true or preserve exact dialogue. Lower-Source-CL ordinary memory alteration cannot erase that core event; it can blur faces, wording, chronology, or interpretation. Equal or higher authority uses a Source CL contest.

#### Eye Action Economy
An Eye has no turn, movement, actions, Reactions, speech, manipulation, or independent senses beyond the printed shared Spiritual Sense. Originating a feature from an Eye uses the same activation, range, cost, target count, and Concentration as originating it from you.

#### Realm Suppression
Witness Notes remain scene states but cannot provide a feature above effective CL. All Eyes Open and its Eyes end if effective CL falls below 14. Perfect Witness ends if effective CL falls below 18. Evidence already witnessed remains ordinary memory and is not retroactively erased.

### Integrated Procedure Closure — Choir of the Unopened Eye

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Witness. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 13. Mercy Flayer

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden healer scripture, failed bodhisattva vow, martyr-spirit pact, battlefield revelation, or apprenticeship under a surgeon of soul-scars.  
**Identity:** Removing pain, sin, conditions, wounds, and spiritual contamination by peeling them out of one soul and carrying or placing them elsewhere.  
**Primary role:** Emergency healing, affliction extraction, damage interception, burden transfer, and deferred catastrophic harm.  
**Sphere Lean:** Healing, Spirit, Blood, Mind. This tradition grants none of those Spheres.  
**Cultivation boundary:** A Mercy Flayer transfers and contains suffering. It does not create consequence-free healing, erase permanent cultivation damage without reconstruction, or justify placing suffering into an unwilling target without a printed save.

> *Be grateful. I left you only the scar.*

Mercy Flayers are healers in the most uncomfortable sense. They treat pain as a substance, fear as a membrane, curse-pressure as infected skin, and spiritual injury as something that can be cut loose. Their greatest miracles do not prove suffering vanished. They prove someone agreed—or was forced—to carry it.

### Mercy Scars

Several features give you **Mercy Scars**.

- Your maximum Mercy Scars equals your Proficiency Bonus.
- A Mercy Scar is a contained burden: pain, fear, curse-pressure, spiritual contamination, a deferred wound, or another injury you removed from someone else.
- Mercy Scars remain until discharged, transferred, treated, or resolved. They do not automatically vanish when a scene ends.
- While you bear at least one Mercy Scar, Soul Gaze identifies you as carrying transferred suffering.
- When you fail an Intelligence, Wisdom, or Charisma saving throw, you may allow one Mercy Scar to rupture. The Scar fades, and you take Psychic damage equal to `2 × Proficiency Bonus`; this damage cannot be reduced. You then add your Proficiency Bonus to the failed save, potentially turning it into a success.
- If you would gain a Mercy Scar beyond your maximum, choose one existing Scar to rupture immediately, or the attempted extraction fails before affecting its source.

#### Treating Mercy Scars

A Mercy Scar can be removed by one of the following:

- the **Mercy-Scar Treatment procedure** in the Procedure Addendum;
- transferring it through a feature that permits transfer;
- resolving the burden’s named condition through a printed source-specific rite;
- accepting one recorded **Lasting Mercy** from the finite list in the Procedure Addendum during downtime.

A lower-authority generic rest or ordinary Hit Point healing does not remove Mercy Scars.

### CL3 — Gentle Knife

**Action**  
**Range:** Touch  
**Cost:** 1 Resonance  
**Target:** One willing creature

Choose one result:

#### Ease Pain

Suppress one ordinary pain, fear symptom, despair symptom, or minor spiritual disturbance until the end of the scene. The underlying source remains and resumes afterward unless treated.

#### Take the Edge

The target gains Temporary Hit Points equal to `Proficiency Bonus + Wisdom modifier` and Advantage on its next saving throw against Frightened or Spiritual Pressure before the end of your next turn.

#### Lift the Tremor

End one ordinary Spiritual Pressure effect, or allow the target to repeat one saving throw against an ordinary Charmed or Frightened effect.

After resolving the chosen result, take Psychic damage equal to your Proficiency Bonus. This damage cannot be reduced.

If Gentle Knife suppresses or ends an effect created by a meaningful hostile creature, you may gain 1 Mercy Scar instead of taking this damage.

#### Diagnostic Incision

When you touch the target, you also learn whether its pain or disturbance is ordinary, Restricted, Forbidden, Secret, divine, artifact-level, cultivation-based, bodily, emotional, memory-based, identity-based, or possession-based. Protected causes can require a Cultivation Check.

### CL6 — Peel the Wound

**Action**  
**Range:** Touch  
**Cost:** 3 Resonance  
**Target:** One willing creature, or one restrained/unconscious creature whose current custodian lawfully permits emergency treatment

Choose one poison, disease, Charmed effect, Frightened effect, ordinary curse, ordinary possession, Nightmare Scar, Devoured Dream, spiritual contamination, or Spiritual Pressure package affecting the target. Make a Cultivation Check against the effect’s save DC. If it has no save DC, use `8 + source Proficiency Bonus + source key ability modifier`.

**Success:** Choose one result.

- **Suppress:** Suppress the effect for the scene.
- **Extract:** If the effect is ordinary and has lower Source CL, end it and gain 1 Mercy Scar.
- **Expose:** Reveal the effect’s Anchor, current host, transmission route, restoration condition, or one legal way to remove it.

**Failure:** The target gains Advantage on its next saving throw or Cultivation Check against the effect. You take Psychic damage equal to `2 × Proficiency Bonus`.

#### Flayed Burden

When you Extract an effect, you may place the Mercy Scar into a prepared strip of cloth, paper skin, wax figure, surgical thread, spirit parchment, or other suitable vessel instead of carrying it personally. The vessel becomes a **Flayed Burden Anchor**:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `4 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Immunities:** Poison, Psychic, and ordinary bodily conditions
- **Duration:** Until treated, destroyed, deliberately opened, or the burden is transferred

A Flayed Burden Anchor can hold one Mercy Scar. You can maintain a number of such Anchors equal to your Wisdom modifier, minimum one.

If an Anchor is destroyed without purification, resolve **Escaped Burden Priority** from the Procedure Addendum. Apply the first legal result; no additional penalty is invented. An equal-or-higher-authority effect also retains its own printed recovery and persistence rules.

### CL10 — Give the Pain a Name

You can transfer a burden after defining what it is.

**Action**  
**Range:** 60 feet  
**Cost:** 4 Resonance  
**Requirement:** The receiving target is Resonance Marked by you, bears your Mercy Scar through a prior link, or is touching a Flayed Burden Anchor

Choose one Mercy Scar carried by you, a willing ally within 30 feet, or a Flayed Burden Anchor. Name its broad burden aloud: fear, pain, despair, contamination, possession-pressure, nightmare, curse-pressure, or another accurate category.

A willing receiving target accepts the transfer. An unwilling receiving target makes a Wisdom saving throw.

**Failed Save:** Transfer the Mercy Scar to the target until the end of its next turn. Choose one expression appropriate to the burden:

- impose one ordinary Spiritual Pressure effect;
- impose Frightened until the end of its next turn if the Scar came from fear;
- reduce Speed by 10 feet and prevent Reactions if the Scar came from pain;
- impose Disadvantage on the next Intelligence, Wisdom, or Charisma save if the Scar came from spiritual contamination;
- suppress one source of healing or Temporary Hit Points until the end of its next turn if the Scar came from a curse or bodily wound.

At the end of the target’s next turn, the Scar returns to its prior bearer or Anchor unless another procedure receives it.

**Successful Save:** The transfer fails. The target suffers one ordinary Spiritual Pressure effect, and the Scar remains where it was.

#### Permanent and Protected Burdens

This feature cannot transfer a permanent injury, destroyed organ, complete curse, complete possession, memory deletion, identity severance, Foundation damage, Method damage, or Secret-Law harm unless a separate Source Rule expressly permits it. It may transfer one symptom or pressure expression from such harm for the printed duration.

#### Named Relief

When a willing creature accepts a Mercy Scar from another willing creature, both gain Temporary Hit Points equal to your Proficiency Bonus. This can occur only once per scene for each creature.

### CL14 — Painless Martyr

**Reaction**  
**Trigger:** An ally within 30 feet takes damage, fails an Intelligence, Wisdom, or Charisma saving throw, or would gain a Mercy Scar, Nightmare Scar, spiritual contamination, possession effect, memory wound, or identity wound  
**Cost:** 5 Resonance

Choose one result.

#### Divide the Blow

You take half the triggering damage, rounded down, and the ally takes the remainder. Damage type and bypass properties are preserved. Damage transferred to you this way cannot be reduced below your Proficiency Bonus unless the triggering damage was already lower.

#### Carry the Failure

The ally rerolls the triggering saving throw and must use the new result. You gain 1 Mercy Scar. If the reroll succeeds, the hostile source becomes Resonance Marked by you.

#### Catch the Wound

Delay one ordinary possession, contamination, memory wound, identity wound, or permanent-injury consequence until the end of your next turn. You immediately gain 1 Mercy Scar. During the delay, the ally or another creature can heal, escape, exorcise, surrender, sever an Anchor, or perform another meaningful intervention.

If the source is equal or higher authority, make a Cultivation Check. On failure, you may still delay one symptom until the start of the ally’s next turn, but not the complete consequence.

#### Martyr’s Limit

You cannot use Painless Martyr if doing so would force you above your Mercy Scar maximum unless you rupture a Scar first. If the feature would reduce you to 0 Hit Points, it still resolves; you fall unconscious afterward.

### CL18 — White Room Mercy

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene

Create a silent 30-foot aura of white spiritual pressure centered on you. The aura is a Spirit Awakening field with your Source CL. Sound can exist within it, but cries of pain, panic, and involuntary confession do not travel beyond its boundary unless you permit them.

While the White Room lasts:

- Allies of your choice have Advantage on death saving throws and saves against Charmed, Frightened, possession, despair, pain, ordinary spiritual contamination, and ordinary memory or identity pressure.
- Once on each of your turns, choose one ally in the aura. It regains `3d8 + Wisdom modifier` Hit Points or repeats one save against an effect listed above.
- A willing creature in the aura can transfer one ordinary pain, fear, Spiritual Pressure effect, Nightmare Scar, Mercy Scar, or minor contamination to an empty Flayed Burden Anchor as an Action.
- Hostile creatures cannot force a willing ally to reveal information through pain, fear, or ordinary spiritual coercion while that ally remains in the aura.

#### Once During the White Room — Impossible Triage

When a creature in the aura would die, suffer a permanent wound, lose a memory, have its identity altered, become possessed, have its soul displaced, or suffer permanent cultivation-system harm, you may use your Reaction and choose one result:

##### Defer

Delay the complete consequence until the end of the scene. The target remains alive and functional enough to act, though it may be at 1 Hit Point and visibly unstable. If the consequence is not properly repaired, escaped, exorcised, or otherwise changed before the scene ends, it returns in full.

##### Take the Burden

If the consequence is ordinary or lower Source CL, transfer it to yourself as a **White Mercy Scar**. The target avoids it. A White Mercy Scar counts as two Mercy Scars, cannot rupture for a save bonus, and cannot be removed by an ordinary Full Cultivation Session. It requires the **White-Mercy Restoration procedure** in the Procedure Addendum or treatment by an explicit equal-or-higher-authority restoration Source Rule.

##### House the Burden

Place the consequence into a specially prepared **White Room Anchor** occupying one space in the aura. The Anchor has:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `10 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Immunities:** Poison, Psychic, Necrotic, Radiant, and ordinary bodily conditions

The Anchor persists after the aura ends until the burden is reconstructed, transferred, purified, or released. If destroyed without completing a transfer, purification, or reconstruction, resolve Escaped Burden Priority from the Procedure Addendum using the housed consequence as the burden.

#### Authority Limits

Secret-Law erasure, divine judgment, artifact execution, tribulation injury, complete soul destruction, voluntary refusal to return, and equal- or higher-Source-CL permanent harm can resist Impossible Triage. On a successful Cultivation Check, you may still stabilize the victim and prevent escalation until a proper restoration procedure is attempted.

White Room Mercy is powerful because it creates time and custody. It does not make catastrophic harm cease to exist without someone or something carrying it.

#### Soul Splitting Expression — Burden-Bearing Double

While Soul Splitting is active, use **Burden-Bearing Double** as your Subpath Expression. Move your Soul Fragment up to 20 feet, then transfer one Mercy Scar you carry to the fragment or return one Scar it carries to you. The Scar still counts against your maximum. While carried by the fragment, it cannot be ruptured for a saving-throw bonus, but Give the Pain a Name and White Room Mercy may treat the fragment as its bearer and origin. If the fragment is destroyed or Soul Splitting ends, the Scar immediately returns to you; if that exceeds your maximum, resolve overflow normally.

### Normalized Mercy Procedures

#### Mercy-Scar Treatment
During a Full Cultivation Session, select one Scar and complete one applicable route:

1. **Medicine or Healing:** a creature succeeds on Wisdom (Medicine) or a compatible Healing/Spirit Cultivation Check against `10 + Scar Source CL PB + 3`, or against the source save DC if known.
2. **Confession or Acceptance:** the bearer accurately names the burden, its source, and one consequence it caused, then accepts responsibility or rejects imposed guilt as appropriate; make a Wisdom or Charisma save against the source save DC.
3. **Purification:** a legal exorcism, cleansing, or restoration Source Rule succeeds against the Scar's Source CL.
4. **Source Rite:** complete the burden's printed restitution, cure, funeral, Offering, reconstruction, or severance procedure.

Success removes one ordinary Mercy Scar. Failure does not worsen it and the same route cannot be repeated for that Scar until the next Full Cultivation Session.

#### Lasting Mercy
Instead of removing one ordinary Scar through the above check, the bearer may accept one lasting result: a visible nonimpairing scar; a named memorial duty performed once per month; a minor vow not to repeat the specific harmful act that created the burden; a one-time Offering worth at least 5 times Source CL in setting currency or equivalent materials; or preservation of the burden's name in a shrine, journal, grave, or clinic. The result grants no numerical penalty or benefit unless another Source Rule says so. Breaking a vow does not recreate the Scar automatically; it creates only consequences printed by the vow's own Source Rule.

#### Escaped Burden Priority
When a Flayed Burden or White Room Anchor is improperly destroyed, apply the first legal result:

1. If the original victim remains within 300 feet on the same plane and the burden's Source Rule preserves a link, the burden returns to that victim.
2. Otherwise, if the destroyer is a legal target and knowingly destroyed the Anchor, the burden attaches to the destroyer as the original effect or nearest printed symptom until the end of the scene.
3. Otherwise, the 5-foot space becomes a contaminated Spirit Field for the scene; the first creature entering or starting there makes the original save or suffers the nearest printed successful-save symptom.
4. If none of the above can legally carry the burden, it becomes a visible dormant residue in that space for 24 hours and can be diagnosed, contained, or purified. It creates no new creature or power by itself.

Complete Souls, permanent injuries, destroyed cultivation systems, Secret effects, divine judgments, and artifact consequences use their own persistence rules and cannot be reduced to a minor manifestation by this table.

#### White-Mercy Restoration
Remove one White Mercy Scar only after all three steps:

1. Stabilize or reconstruct the original consequence, or establish lawful continuing custody for it.
2. Complete one Full Cultivation Session with a successful Medicine, Healing, Spirit, exorcism, memory, identity, or reconstruction check against the original Source Rule's save DC or Authority DC.
3. Accept one Lasting Mercy or complete the original source's restitution.

If the original consequence remains active and uncontained, the Scar cannot be removed. Equal-or-higher-authority restoration can replace step 2 but not the factual requirement that the burden have a legal destination.

#### White Room Functional State
Under **Defer**, a creature that would die remains at 1 Hit Point, is not Unconscious solely from that consequence, and can act normally unless another existing condition prevents it. A deferred permanent wound, memory loss, identity alteration, possession, displacement, or cultivation-system harm has no mechanical effect until the scene ends, but its visible instability can be diagnosed. Damage and unrelated effects can still reduce the creature to 0 Hit Points afterward.

#### Flayed Burden Anchor Closure
A Flayed Burden Anchor is Tiny, occupies its space, has Speed 0, and is immune to Charmed, Frightened, Grappled, Paralyzed, Petrified, Poisoned, Prone, Restrained, Poison damage, and Psychic damage. A White Room Anchor is Medium, occupies one 5-foot space, has Speed 0, and has the same condition immunities in addition to its printed damage immunities. Neither acts, moves, speaks, or provides Cover unless physically appropriate.

#### Realm Suppression
Mercy Scars and contained burdens remain. A feature above effective CL cannot activate. Existing Flayed Burden Anchors retain their creation Source CL. White Room Mercy ends if effective CL falls below 18, but a White Room Anchor already created persists as an independent Anchor until resolved.

### Integrated Procedure Closure — Mercy Flayer

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Burden-Bearing Double. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 14. Seraphic Molter

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Forbidden angelic body-soul scripture, cocoon shrine, radiant parasite, hereditary seraphic contamination, or inheritance from a winged thing that was never human.  
**Identity:** Shedding weakness, growing impossible spiritual anatomy, and burning away portions of the self that cannot ascend.  
**Primary role:** Transformation, mobility, self-cleansing, perception, anti-concealment, and identity-scale survival.  
**Sphere Lean:** Transformation, Light, Spirit, Body. This tradition grants none of those Spheres.  
**Cultivation boundary:** Seraphic anatomy is primarily spiritual unless a feature says it becomes physical. It does not grant Body Refining features, natural armor, universal flight, divine status, or immunity to consequences merely because the transformation resembles an angel.

> *The mortal self is a chrysalis. Do not mistake it for mercy.*

Seraphic Molters pursue ascension through shedding. Their bodies and souls sprout signs of an inhuman heaven: eyes, wings, halos, radiant scars, recursive shadows, and the terrible conviction that weakness is only material waiting to be peeled away.

### Seraphic Signs and Molt Debt

You acquire **Seraphic Signs** through this tradition. A Sign can be visible, concealable only with effort, or spiritually visible even when physically hidden.

Several features also create **Molt Debt**.

- Molt Debt represents portions of identity, empathy, memory, pain, or mortality shed faster than they can be integrated.
- Your maximum Molt Debt equals your Proficiency Bonus.
- Molt Debt remains until resolved through a Full Cultivation Session that includes identity integration, confession, human contact, shrine purification, dream reconstruction, or one Molt Integration listed in the Normalized Execution Notes.
- A Full Cultivation Session removes 1 Molt Debt by default. One Greater Integration listed in the Normalized Execution Notes can remove one additional Debt during that session.
- At maximum Molt Debt, you cannot voluntarily use a feature that would add more unless you accept a **Permanent Seraphic Sign** chosen from the Permanent Seraphic Sign table. A Permanent Sign can be altered or purified only through the printed reconstruction procedure.

### CL3 — First Molt

Choose one **Minor Seraphic Sign** when you gain this feature. You may change the chosen functional expression during a Full Cultivation Session, but some visible trace of prior Signs may remain.

#### Glass-Eye Sign

Your Spiritual Sense range increases by 5 feet. You have Advantage on Insight checks made to recognize possession, false serenity, concealed terror, or spiritual coercion.

#### Feather-Scar Sign

You have Advantage on saving throws against Frightened. When you succeed on such a save, you may move 5 feet without provoking opportunity attacks.

#### Halo-Bruise Sign

Gain Resistance to Psychic damage caused by dreams, fear, possession, or Spiritual Pressure.

#### Second-Voice Sign

Gain proficiency in Insight or Religion. If already proficient in both, add half your Proficiency Bonus, rounded up, to checks with one of them in which your spiritual second voice can assist.

#### Many-Shadow Sign

Ordinary spiritual concealment cannot hide whether a creature within your Spiritual Sense is singular, possessed, carrying a projected soul, or accompanied by a hidden spiritual Asset, though exact identity can remain concealed.

#### Molt Recognition

When Soul Gaze examines you, it identifies the presence and broad nature of your Seraphic Sign. A lower-Source-CL disguise cannot make the Sign appear entirely absent to trained spiritual perception.

### CL6 — Wingless Ascent

**Bonus Action**  
**Cost:** 3 Resonance  
**Duration:** The scene

Unfold incomplete spiritual wings. At the start of each of your turns, choose one mode.

#### Ascending Beat

Gain a fly Speed equal to your walking Speed until the end of the turn. If you end the turn without another way to remain aloft, descend safely up to 60 feet.

#### Folding Glide

Until the start of your next turn, you can move across liquids, fragile surfaces, open air gaps of up to 20 feet, and vertical surfaces without falling during the movement. You must end on a surface or descend safely.

#### Shielding Pinions

Choose yourself or one ally within 10 feet. Until the start of your next turn, reduce the first instance of Psychic, Radiant, or Necrotic damage to that creature by `Wisdom modifier + Proficiency Bonus`.

You may use one mode each turn without additional Resonance. After using Ascending Beat on three turns during the same scene, each later Ascending Beat costs 1 Resonance.

#### Torn Wings

If an equal- or higher-Source-CL effect suppresses the wings while you are airborne, you descend safely 30 feet before falling normally. A feature that explicitly destroys spiritual anatomy can instead inflict a Hidden Injury or Molt Debt according to its printed procedure.

### CL10 — Burn Away the Lesser Self

You can shed an affliction into a temporary spiritual cast-off.

**Bonus Action**  
**Cost:** 5 Resonance  
**Optional cost:** Gain 1 Molt Debt to strengthen the result

Choose one effect on yourself:

- Charmed;
- Frightened;
- Poisoned;
- one ordinary Spiritual Pressure effect;
- one ordinary dream influence;
- one ordinary emotional corruption;
- one ordinary or lower-Source-CL possession symptom;
- one minor curse or spiritual contamination.

If the effect is ordinary and lower Source CL, end it. If equal or higher authority, suppress it until the end of your next turn and make a Cultivation Check. On success, suppress it for the scene instead.

The removed or suppressed burden becomes a **Cast-Off Self** in an adjacent space:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `5 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Speed:** 0 feet
- **Immunities:** Poison, Psychic, and ordinary bodily conditions
- **Duration:** Until the scene ends, it is destroyed, or you reintegrate it

The Cast-Off is not a creature and takes no turn. It visibly expresses the shed weakness.

#### Cast-Off Consequences

While the Cast-Off exists:

- You cannot gain the exact same ordinary effect from the same source again.
- If the hostile source was within 60 feet when you shed it, that source becomes Resonance Marked by you.
- A creature can target the Cast-Off as though it were an Anchor for the removed effect.

If the Cast-Off is destroyed by hostile action, the burden does not return, but you gain 1 Molt Debt. If you voluntarily reintegrate it as an Action, regain Resonance equal to half your Proficiency Bonus, rounded down, and the original effect returns only if its duration and source still legally persist.

If you gained Molt Debt on activation, the Cast-Off’s Hit Points double and the effect is treated as one Source CL higher for resisting restoration by its original source.

### CL14 — Eyes in the Wings

**Bonus Action**  
**Cost:** 6 Resonance  
**Duration:** The scene

Open impossible eyes across your spiritual wings, shadows, halo scars, and reflected surfaces.

While this feature lasts:

- Your Spiritual Sense range increases by 30 feet.
- You can use Spiritual Sense from any point occupied by your Wingless Ascent movement during the current turn, allowing you to inspect around a corner or across a gap without remaining there.
- Creatures detected by Spiritual Sense cannot gain Advantage against you from ordinary invisibility, ordinary darkness, ordinary cover, mundane disguise, or ordinary illusion.
- You know when a detected creature is looking directly at you, attempting to target you through spiritual perception, or carrying a gaze-based technique.
- Once per round when a detected hostile creature misses you with an attack or fails a technique against you, impose one ordinary Spiritual Pressure effect on it.

#### Pinion Witness

As a Reaction when a creature within your Spiritual Sense teleports, projects its soul, becomes invisible, changes shape, or crosses a spiritual boundary, spend 2 Resonance. Place a Resonance Mark on it and record a **Pinion Trace** until the end of the scene.

While the Trace lasts, Soul Gaze can determine:

- the broad direction of its movement;
- whether it remains on the same plane;
- whether its current form is the same spiritual identity;
- whether a stronger Source Rule severed or concealed the trace.

A lower-Source-CL ordinary concealment cannot erase the Trace. Equal or higher authority can contest it with a Cultivation Check.

#### Sensory Overgrowth

If you begin your turn perceiving more meaningful hostile creatures through Eyes in the Wings than your Wisdom modifier, minimum one, choose one:

- take Psychic damage equal to your Proficiency Bonus;
- close the additional eyes until the start of your next turn, reducing Spiritual Sense to its normal range;
- gain 1 Molt Debt and maintain full perception.

### CL18 — Molt the Mortal Name

You shed the layer of identity by which ordinary death, weakness, and mortal limitation recognize you.

**Action**  
**Cost:** 10 Resonance and 1 Molt Debt  
**Duration:** The scene

Manifest a complete **Seraphic Ascension Form**. Choose two **Ascension Anatomies** when the form begins and a third when you reach half your Hit Point maximum or lower.

#### Throne Wings

Gain a fly Speed of 60 feet and hover. Your movement does not provoke opportunity attacks from creatures with lower Source CL unless they possess a specific anti-flight or anti-spirit Source Rule.

#### Thousand Eyes

Your Spiritual Sense extends 60 feet farther. You cannot be surprised by spiritually perceptible creatures, and ordinary concealment cannot make a creature you already detected count as unseen against you.

#### Burning Name

Gain Resistance to Psychic and Radiant damage. When a creature damages you with one of those types, it becomes Resonance Marked by you.

#### Crown of Unselfing

You have Advantage on Intelligence, Wisdom, and Charisma saving throws. When you succeed on one, impose one ordinary Spiritual Pressure effect on the source if it is within 60 feet.

#### Mercyless Purity

At the start of each of your turns, end one ordinary Charmed, Frightened, Poisoned, possession, curse, disease, spiritual contamination, or emotional corruption effect on yourself. Equal or higher authority requires a Cultivation Check and is suppressed until the start of your next turn on success.

#### Swordless Judgment

Once on each of your turns when you deal Psychic, Radiant, or Necrotic damage with a Spirit Awakening feature, deal an additional `2d8` damage of one of those types and impose one ordinary Spiritual Pressure effect.

#### Death and the Shed Name

The first time during the form that you would be reduced to 0 Hit Points, displaced from your body, or have your soul imprisoned by an ordinary or lower-Source-CL effect, you may shed the consequence into a **Mortal Name Husk** and remain at 1 Hit Point.

The Husk appears in an adjacent space with:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `10 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Immunities:** Poison, Psychic, Radiant, Necrotic, and ordinary bodily conditions

If the Husk survives until the form ends, reintegrate it and gain 1 additional Molt Debt. If it is destroyed, the prevented consequence remains prevented, but you gain a Permanent Seraphic Sign and cannot use Molt the Mortal Name again until you complete the Mortal Name Husk identity-reconstruction procedure.

#### End of the Form

When the form ends, choose one cost:

- gain 1 additional Molt Debt;
- lose one Hit Die until treated during a Full Cultivation Session;
- accept Disadvantage on your next meaningful Charisma check involving ordinary mortal empathy;
- become spiritually obvious to trained observers for 24 hours;
- manifest a new visible Seraphic Sign until purified.

Secret-Law erasure, divine custody, artifact imprisonment, tribulation destruction, voluntary surrender of identity, and equal- or higher-authority soul destruction can contest the Husk and Ascension Form through their printed procedures. Molting is not universal immortality.

### Normalized Execution Notes

#### Molt Debt Recovery
A **Molt Integration** is a defined Full Cultivation Session procedure. Choose one method and record the completed act:

- **Identity Integration:** describe one rejected or altered trait and one way it remains part of you;
- **Confession:** truthfully disclose one consequence of the Molt to an affected willing creature;
- **Human Contact:** spend the session in ordinary noncoercive activity with at least one willing creature who knows your current state;
- **Shrine Purification:** expend offerings worth the normal campaign cost for a cultivation treatment of your Realm at a lawful shrine;
- **Dream Reconstruction:** complete a legal dream-entry or memory-reconstruction procedure;
- **Equal-Authority Treatment:** receive a printed feature that repairs identity, spiritual anatomy, or transformation harm.

Completing one method removes 1 Molt Debt. A single session can remove one additional Debt only if you also complete one of these recorded **Greater Integrations**: fulfill a vow created before the session, reconcile with a creature materially harmed by the Molt, permanently surrender a benefit obtained through the Molt, or accept a lasting visible Sign. The same event cannot remove more than 2 Debt.

#### Permanent Seraphic Signs
When a feature requires a Permanent Sign, choose one from this finite list. A Sign is visible to Soul Gaze and does not grant an additional numerical benefit unless another feature says so.

1. **Unclosing Eyes:** one or more eyes remain visible on your wings, shadow, palms, or halo.
2. **Feathered Scars:** feathers, quills, or radiant scar-lines remain across part of your body.
3. **Second Voice:** your speech carries a distinct harmonic or delayed voice.
4. **Unnatural Shadow:** your shadow shows wings, a halo, extra limbs, or a different posture.
5. **Halo Fracture:** a cracked, dim, or burning halo remains spiritually visible.
6. **Name Echo:** your spoken name produces an audible or spiritual echo.
7. **Mortal Distance:** ordinary observers can recognize that your emotional responses are altered, though this does not compel hostility.
8. **Seraphic Anatomy:** retain one cosmetic element of an Ascension Anatomy.

A Permanent Sign can be altered or removed only by completing three Molt Integrations across three separate Full Cultivation Sessions and then succeeding on a Cultivation Check against DC `12 + your Proficiency Bonus`, or by a printed equal-or-higher-Source-CL identity-reconstruction feature. Failure does not erase progress; repeat the check after another Full Cultivation Session.

#### Transformation and Equipment
Seraphic wings, eyes, halos, and shadows are spiritual anatomy. They do not provide additional hands, weapon attacks, object interactions, armor slots, or equipment capacity unless the feature explicitly says so. Worn and carried equipment remains equipped unless the new form lacks a legal location for it; such equipment merges harmlessly and becomes unusable until the form ends. Artifact, living, cursed, or independently resisting equipment follows its own Source Rule.

#### Mortal Name Husk
The Husk is a Spirit Cultivation Asset and identity Anchor, not a creature. It takes no turn, cannot move, cannot be healed by ordinary healing, and cannot be targeted as though it were you except by a Source Rule that targets identity Anchors. Destroying it does not repeat the prevented consequence. Identity reconstruction after its destruction requires one successful Permanent Sign removal procedure; completing that procedure also restores use of Molt the Mortal Name.

#### Soul Splitting Expression — Shed-Wing Witness
Your Soul Fragment may manifest one spectral wing and eye. Once per round when a creature within 30 feet of the fragment teleports, changes shape, projects, becomes invisible, or crosses a spiritual boundary, the fragment may record a Pinion Trace on that creature. The fragment cannot impose Spiritual Pressure, activate Wingless Ascent, create a Cast-Off Self, or trigger Mortal Name Husk.

#### Realm Suppression
A suppressed Sign remains part of your identity and appearance. Numerical or active benefits from a feature above your effective CL become unavailable. Existing Molt Debt and Permanent Signs are not erased by Realm Suppression.

### Integrated Procedure Closure — Seraphic Molter

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Shed-Wing Witness. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 15. Fate Reader

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Secret Law or Karma-adjacent inheritance, Fate or Karma Sphere access, karmic revelation, hidden scripture, inherited omen-organ, tribulation scar, or recorded Secret event.  
**Identity:** Reading possible outcomes, weighting probability, delaying consequences, and severing one future thread before it hardens into history.  
**Primary role:** Prediction, roll intervention, danger diagnosis, delayed failure, and high-authority outcome revision.  
**Sphere Lean:** Fate, Karma, Divination, Spirit. This tradition grants none of those Spheres.  
**Classification:** Secret Law / Karma-adjacent method. Fate Reader is not a default open choice and requires explicit access.  
**Cultivation boundary:** Fate Reader interferes with probability and possible endings. It does not judge moral conduct, record debts from actual deeds, create contracts, or replace Karma-Thread authority. It does not make the future fixed or grant complete omniscience.

> *The future is not written. It is tangled.*

Fate Readers touch consequence before it hardens into history. Their power appears subtle—a wrong footstep, a delayed blade, an omen spoken before rain—but each intervention teaches the world that its first answer can be refused. The world eventually answers back.

### Fate Tension

Several Fate Reader features create **Fate Tension**.

- Your Fate Tension begins at 0.
- Its maximum equals your Proficiency Bonus.
- Fate Tension does not automatically clear when a scene ends.
- A Full Cultivation Session that includes divination, karmic offering, confession, omen interpretation, or acceptance of a meaningful consequence removes 1 Fate Tension.
- One additional Fate Tension is removed when you complete one recorded Karmic Restitution, voluntarily allow one predicted danger to resolve without using a Fate Reader feature, or pay one recorded debt created by your intervention.
- When Fate Tension reaches its maximum, you become **Fate-Tangled** until it falls below maximum.

While Fate-Tangled:

- You cannot gain or prepare a new Omen die.
- The first time in each scene you use a Fate Reader feature that changes a roll or delays a consequence, create one **Counter-Omen token** under the Normalized Execution Notes.
- Resolve the Counter-Omen through the fixed Counter-Omen Procedure in the Normalized Execution Notes.
- A Counter-Omen cannot invent impossible facts, erase a legal feature, or override a Secret Law without authority.

### CL3 — Omen Glimpse

You can read one outcome before it becomes attached to an action.

#### Prepare an Omen

After at least 1 minute observing meaningful signs—cards, bones, stars, smoke, dreams, spirit behavior, battlefield movement, blood patterns, falling leaves, or another legal omen medium defined in the Normalized Execution Notes—spend 1 Resonance and roll one d20. Record the result as your **Omen die**.

- You can hold only one Omen die.
- Preparing a new one replaces the old one.
- An Omen die lasts until used, until the current scene ends, or until circumstances change so completely that the divination’s subject no longer exists.
- If a scene begins without preparation because you were genuinely surprised, you may prepare an Omen as a Bonus Action by spending 2 Resonance and gaining 1 Fate Tension.

#### Invoke the Omen

**Reaction**  
**Trigger:** A creature you can see within 60 feet makes an attack roll, ability check, saving throw, death saving throw, or Cultivation Check  
**Cost:** 1 Resonance

Before the final outcome is declared, replace the d20 with your Omen die. The Omen die is then expended.

If the target is unwilling and the replacement would make its result worse, it may make a Charisma saving throw.

- **Failed Save:** The replacement applies.
- **Successful Save:** The original roll stands, but the creature becomes Resonance Marked by you and you retain the Omen die until the end of your next turn.

#### Omen Limits

An Omen cannot replace a roll that has no d20, retroactively change a fully resolved event, or automatically override a higher-authority fixed result. A Secret Law, divine decree, artifact prophecy, tribulation law, or equal- or higher-Source-CL certainty can require a Cultivation Check.

### CL6 — Read the Thread

**Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Target:** One creature, object, location, active plan, or imminent event you can meaningfully observe

Choose one Thread Question from the Normalized Execution Notes:

- What is this subject most likely to do next?
- What is it trying hardest to protect?
- What immediate danger is connected to it?
- What choice would most alter its next likely outcome?
- Is fate around it ordinary, Restricted, Forbidden, Secret, divine, artifact-level, tribulation-bound, or otherwise distorted?
- What visible sign will precede the next major consequence tied to it?

The answer is symbolic but operationally useful. It must identify a real pressure, likely action, danger, leverage point, omen, or distortion rather than empty atmosphere.

#### Thread Clarity

- Against ordinary and lower-Source-CL concealment, the answer is direct enough to guide immediate action.
- Equal or higher authority can require a Cultivation Check.
- On a failed check, you learn which category is obscured and one visible sign of the concealment rather than receiving false information.
- Protected fate can reveal a branch rather than a certainty: “If no one intervenes,” “if the oath remains intact,” or “if the artifact is used.”

#### Mark the Branch

After receiving the answer, choose one creature involved in the predicted branch. If it knowingly takes the predicted action before the end of your next turn, it becomes Resonance Marked by you and you may move 10 feet or allow one ally within 30 feet to move 10 feet without provoking opportunity attacks from that creature.

### CL10 — Nudge Consequence

You can apply force to a probability already in motion.

**Reaction**  
**Trigger:** A creature you can see within 60 feet makes an attack roll, ability check, saving throw, death saving throw, or Cultivation Check  
**Cost:** 4 Resonance

Before the final outcome is declared, add or subtract `1d8` from the triggering roll. If the target is unwilling and you worsen its result, it makes a Charisma saving throw.

- **Failed Save:** Apply the full modifier.
- **Successful Save:** Apply only `1d4`, and the target suffers one ordinary Spiritual Pressure effect.

After the result resolves, gain 1 Fate Tension if the modifier changed success to failure or failure to success.

#### Consequence Echo

When Nudge Consequence changes an outcome involving a major enemy, a death saving throw, a Secret Law, divine agent, artifact, tribulation, fate-protected creature, breakthrough, permanent injury, or identity-scale effect, choose one:

- gain 1 additional Fate Tension;
- accept one **Named Echo** from the fixed Named Echo table and state it immediately.

A Named Echo is a coherent future complication connected to the intervention, such as:

- the spared enemy recognizes your fate signature;
- a broken weapon fails at a later dramatic moment;
- the healing that succeeded creates a visible omen;
- a diverted curse seeks a new route;
- an authority notices the altered probability;
- the beneficiary owes a spiritual favor.

A Named Echo cannot negate the changed outcome retroactively. Resolving or willingly accepting it removes 1 Fate Tension.

#### Refuse Certainty

Once per scene, when a creature within 60 feet would automatically succeed or fail because of an ordinary lower-Source-CL feature, spend 2 additional Resonance. Require that creature to roll normally instead. Equal or higher authority uses a Cultivation Check contest.

### CL14 — Borrowed Ending

You can detach a consequence from the moment it was supposed to occur.

**Reaction**  
**Trigger:** You or an ally within 30 feet would be reduced to 0 Hit Points, fail a death saving throw, become Charmed or Frightened, become possessed, suffer a curse, lose a memory, have identity altered, suffer a permanent wound, or fail a Cultivation Check with an immediate consequence  
**Cost:** 6 Resonance and 1 Fate Tension

Create a **Borrowed Ending** and delay the triggering consequence until the end of the target’s next turn.

During the delay:

- The target remains at a minimum of 1 Hit Point if the trigger was reduction to 0 Hit Points.
- A failed death saving throw is not recorded yet.
- A condition, possession, curse, memory wound, identity wound, or permanent injury has not yet taken hold, though signs of it are visible.
- The target has one meaningful opportunity to alter the branch through healing, escape, exorcism, surrender, counter-technique, bargain, destroying an Anchor, accepting another cost, or another action capable of changing the cause.

At the end of the target’s next turn:

- If the cause was legally removed or the situation genuinely changed, the Borrowed Ending dissolves.
- If nothing changed, the original consequence occurs.
- If the source is equal or higher authority, a successful Cultivation Check is required for complete dissolution. On failure, reduce the consequence’s severity by one step where logically possible or delay it until the end of the scene.

#### Ending Token

The Borrowed Ending appears as a visible spiritual token attached to the target: a black thread, unfinished sentence, inverted hourglass, unfallen drop of blood, severed shadow, or another omen.

It is a Cultivation Asset with:

- **AC:** Your Cultivation Save DC
- **Hit Points:** `6 × Proficiency Bonus`
- **Source CL:** Your effective Spirit Awakening CL
- **Immunities:** Poison, Psychic, and ordinary bodily conditions

Destroying the token by hostile action causes the original consequence to occur immediately unless the destructive effect expressly consumes or rewrites fate. A willing equal- or higher-authority healer, exorcist, fate cultivator, or source-specific countermeasure may instead target the token to dissolve it.

#### No Repeated Borrowing

A creature cannot carry more than one Borrowed Ending from you at a time. You cannot use Borrowed Ending on the same underlying consequence twice unless a distinct Source Rule recreated it after genuine resolution.

### CL18 — Sever One Thread

You can cut one resolved possibility away from the world and force another nearby possibility to occupy its place.

**Reaction**  
**Trigger:** A creature within 90 feet succeeds or fails on an attack roll, ability check, saving throw, death saving throw, or Cultivation Check, or an immediately resolved event creates a single discrete outcome  
**Cost:** 10 Resonance  
**Requirement:** You are not Fate-Tangled, and the event has not yet produced further dependent rolls or completed a later action

Name the thread you are severing in a brief statement: “the blade lands,” “the seal holds,” “the soul escapes,” “the gate opens,” or another precise outcome.

Choose one procedure.

#### Reroute the Roll

Force the creature to reroll the d20 and choose which result applies. If the creature is unwilling, it makes a Charisma saving throw first.

- **Failed Save:** You choose which result applies.
- **Successful Save:** The reroll occurs, but the target chooses which result applies and suffers two different ordinary Spiritual Pressure effects as one exceptional package.

#### Restore the Omen

If you used an Omen die on the triggering roll or on a directly connected roll this scene, replace the final d20 with the expended Omen result instead. An unwilling target makes the same Charisma saving throw described above.

#### Cut the Immediate Event

For a discrete non-roll event—an ordinary teleport completing, an ordinary possession taking hold, an ordinary gate opening, an ordinary execution trigger firing, or an ordinary Anchor collapsing—make a Cultivation Check against the effect’s Source Rule.

- **Success:** The named event does not occur. Costs already paid remain paid unless the source says otherwise.
- **Failure:** Delay the event until the end of the current turn and reveal one legal condition that could stop or alter it.

#### Severed-Thread Consequence

After Sever One Thread resolves:

- Set your Fate Tension to its maximum.
- You become Fate-Tangled.
- Choose and record one **Severed Thread Consequence** from the fixed list before play continues. It must arise from the altered event.
- You cannot use Sever One Thread again until that consequence is resolved through its recorded completion condition. Restoring Resonance or completing an ordinary rest does not restore access.

Examples include:

- an authority notices the impossible divergence;
- the spared death returns as a future tribulation;
- a sealed enemy gains a prophetic connection to you;
- the abandoned possibility becomes a hostile omen-spirit;
- a different branch claims the cost that was refused;
- your name disappears from one relationship, record, or prophecy until repaired.

#### Secret-Law Authority

An equal- or higher-Source-CL Secret Law, divine decree, artifact destiny, tribulation law, fixed reincarnation event, voluntary self-sacrifice, or campaign-defining outcome can resist Sever One Thread. Resolve the contest by Source CL and then Cultivation Check. Even on failure, you learn whether the outcome was fixed, protected, willingly accepted, or anchored elsewhere.

Fate Reader changes possibility. It does not erase Karma already earned, invalidate a lawful Soul Contract, or remove the moral and spiritual consequences of the action that created the roll.

### Normalized Execution Notes

#### Omen Media
A legal omen medium must contain naturally occurring or previously established variation that you did not create solely to force a desired result. Cards, bones, stars, smoke, dreams, spirit behavior, battlefield movement, blood patterns, weather, falling leaves, written lots, and comparable recorded media qualify. Repeating the same prepared arrangement without a meaningful change does not produce a new omen.

#### Counter-Omen Procedure
The first time in a scene you change a roll or delay a consequence through this tradition, create one **Counter-Omen token**. A maximum of one Counter-Omen can exist at a time. Before the scene ends, the GM or the opposition controller must spend it at the first legal opportunity from this ordered list:

1. after you declare but before you roll a Cultivation Check, impose Disadvantage on that check;
2. after you declare but before you roll a saving throw, impose Disadvantage on that save;
3. when an ordinary favorable coincidence created only by narrative positioning would remove a current obstacle without a check, the coincidence fails;
4. if none of the above occurs before the scene ends, you gain 1 Fate Tension.

The Counter-Omen cannot create damage, a condition, lost equipment, a new enemy, or a permanent consequence by itself.

#### Thread Questions
Read the Thread uses one of these exact questions:

- What is the most likely immediate danger if the observed plan proceeds unchanged?
- Which observed creature, object, location, or Anchor is most causally important to the next stage?
- What visible action would most directly improve the observed plan's chance of success?
- What visible action would most directly cause the observed plan to fail?
- Is the imminent event primarily protected by lower, equal, or higher Source CL?
- Is the observed branch being concealed, redirected, willingly accepted, or fixed by another authority?

The answer must identify one currently knowable fact, category, or visible course. It does not reveal secret statistics, private memories, or future events beyond the feature's horizon.

#### Named Echo Table
When Nudge Consequence requires a Named Echo, roll or choose one and record its subject and expiration. An Echo ends when its printed condition occurs or at the end of the next scene, whichever comes first.

1. **Reversal:** the next time you alter a d20 roll, roll twice and use the result farther from 10.
2. **Witness:** the creature most affected by the changed result knows that fate was altered and your broad direction.
3. **Delayed Cost:** lose Resonance equal to your Proficiency Bonus at the end of the current scene; if insufficient, gain 1 Fate Tension.
4. **Narrowed Branch:** you cannot use Nudge Consequence on the same creature again this scene.
5. **Borrowed Misfortune:** the next ordinary saving throw you make before the end of your next turn cannot gain Advantage.
6. **Marked Cause:** one object, creature, or Anchor directly involved becomes spiritually legible to equal-or-higher-Source-CL fate perception until the scene ends.

#### Severed Thread Consequences
When Sever One Thread requires a consequence, choose one before play continues:

- **Karmic Restitution:** perform a specific service for the creature or community materially affected by the alteration;
- **Accepted Loss:** voluntarily allow one later ordinary consequence of the same causal chain to resolve without using Fate Reader features;
- **Offering:** expend materials worth the normal campaign cost of a cultivation treatment at your Realm during a Full Cultivation Session;
- **Public Omen:** reveal the altered event and your role to one materially affected creature;
- **Bound Branch:** designate one creature or event involved; you cannot use Sever One Thread concerning it again until the current consequence is resolved;
- **Fate Scar:** accept one visible spiritual scar detectable by Soul Gaze until three Full Cultivation Sessions have passed.

Once the chosen condition is completed, Sever One Thread becomes available again. The GM confirms only whether the recorded condition occurred; the GM does not invent a different price after activation.

#### Soul Splitting Expression — Forked Omen
When you create your Soul Fragment, assign it one unused Omen die you have prepared. Once before the fragment ends, when a creature within 30 feet of it makes a d20 Test, the fragment may invoke that Omen under the normal Omen rules. The fragment cannot prepare Omens, create Counter-Omens, use Nudge Consequence, Borrowed Ending, or Sever One Thread.

#### Secret Access
“Secret event” means an event expressly designated Secret by the campaign's access rules, not discretionary permission without a recorded source. Record the scripture, inheritance, revelation, scar, teacher, or event that granted access.

### Integrated Procedure Closure — Fate Reader

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Forked Omen. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 16. Candlemaker

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted vigil tradition, deathbed apprenticeship, shrine inheritance, imperial witness office, or pact with a lamp-spirit.  
**Identity:** Soul-flame diagnosis, warding, funeral custody, final promises, and prepared spiritual execution.  
**Primary role:** Setup controller, anti-possession support, spiritual diagnosis, emergency preservation, and prepared finisher.  
**Sphere Lean:** Fire, Light, Spirit, Death. This tradition grants none of those Spheres.  
**Cultivation boundary:** Candlemakers cultivate the flame by which a soul remains itself. They can tend, mark, shelter, suppress, and extinguish spiritual expressions. They do not automatically erase a complete soul, oath, Method, Foundation, bloodline, divine office, or artifact merely because it can be described as a flame.

> *Every flame is a promise. Every promise burns. Every burning thing eventually tells the truth.*

Candlemakers are remembered as hospice keepers, shrine lamplighters, battlefield witnesses, and executioners who wait for the exact instant a target’s sustaining flame becomes vulnerable. Their art is not ordinary fire. A Soul Candle burns memory, identity, courage, vow, and remaining possibility.

### Soul Candle

At the end of a 1-minute vigil using a candle, lamp, wick, ember, funeral tablet, or similar focus, create one **Soul Candle**. You may perform this vigil during travel, preparation, a rest, or another quiet interval. Creating a Soul Candle costs 1 Resonance if you do not have appropriate physical materials.

You can maintain only one Soul Candle at a time. It lasts until destroyed, willingly extinguished, or replaced.

The Soul Candle is a Tiny Cultivation Asset:

- **AC:** `12 + Proficiency Bonus`
- **Hit Points:** `5 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Immunities:** Poisoned, Disease, ordinary suffocation
- **Resistances:** Psychic and Fire damage
- **Movement:** None unless a feature moves it
- **Source CL:** your effective Spirit Awakening CL

The candle can be held, worn, mounted in a lantern, or placed in an adjacent space. As a Bonus Action, spend 1 Resonance to move it up to 30 feet to an unoccupied space you can see. It hovers there until you move it again. The candle cannot take actions, reactions, or an independent turn.

If destroyed, you take Psychic damage equal to `2 × Proficiency Bonus`, and all your Soul-Wick Marks end. You can rekindle it through another 1-minute vigil.

### Soul-Wick Marks

Several Candlemaker features place **Soul-Wick Marks**.

- A Soul-Wick Mark is a special Resonance Mark and counts as your Resonance Mark for features that require one.
- A creature can bear up to three Soul-Wick Marks from you.
- A Soul-Wick Mark lasts for the scene unless removed, consumed, or the Soul Candle is destroyed.
- When you would place an ordinary Resonance Mark on a creature already bearing your mark, you may instead add one Soul-Wick Mark, subject to the maximum.
- You can normally add no more than one Soul-Wick Mark to the same creature per turn.
- Soul-Wick Marks are visible to Spiritual Sense as flames, wick-knots, soot-script, funeral characters, or an equivalent sign.
- An equal- or higher-Source-CL concealment can hide a Soul-Wick Mark through a Cultivation Check contest but does not automatically remove it.

A Soul-Wick Mark records the target’s current sustaining state. It does not by itself reveal hidden facts, make the target guilty, or allow arbitrary instant death.

### CL3 — Wick of the Self

While your Soul Candle is within 60 feet, you gain **Wicksight**:

- You know when a creature you can spiritually perceive within 60 feet is possessed, dream-haunted, Resonance Marked, Frightened, Charmed, at 0 Hit Points, or sustaining a Concentration effect.
- You know whether a visible creature’s soul-flame is stable, faltering, divided, borrowed, concealed, or externally sustained.
- You do not automatically learn the source’s identity, exact feature text, secret weakness, remaining resources, or protected information.

#### Candle Marking Rite

**Bonus Action**  
**Range:** 60 feet from you or your Soul Candle  
**Cost:** 1 Resonance

Choose one creature you can spiritually perceive. It makes a Wisdom saving throw. A willing creature may fail automatically.

**Failed Save:** Place one Soul-Wick Mark on the target. You learn one current sustaining category: bodily vitality, active defense, courage, Concentration, possession, oath, external blessing, spiritual companion bond, or the next applicable Sustaining Category in the Normalized Execution Notes.

**Successful Save:** The target is not marked, but you learn whether its Source CL is lower than, equal to, or higher than yours and whether a stronger effect is concealing its soul-flame.

If the target is Bloodied, has failed an Intelligence, Wisdom, or Charisma saving throw since the end of your last turn, has lost Concentration, or has had a supernatural defense suppressed during the scene, it makes this save with Disadvantage.

### CL6 — Candle Against the Dark

Your Soul Candle can catch a spiritual failure before it becomes final.

**Reaction**  
**Trigger:** You or an ally within 30 feet of you or your Soul Candle fails an Intelligence, Wisdom, or Charisma saving throw  
**Cost:** 2 Resonance

The target rerolls the saving throw and must use the new result.

If the effect involves possession, fear, dreams, memory, illusion, identity, a spirit, or a Soul-Wick Mark, the target also gains Temporary Hit Points equal to `Wisdom modifier + Proficiency Bonus` after the reroll resolves.

After this reaction resolves, choose one:

- **Burn Bright:** The Soul Candle takes damage equal to `2 × Proficiency Bonus`, ignoring Resistance. The protected creature gains Advantage on the next saving throw it makes against the same named source before the end of its next turn.
- **Take the Soot:** You become Resonance Marked by the hostile source until the end of your next turn and suffer one ordinary Spiritual Pressure effect resolved through Take the Soot in the Normalized Execution Notes. The Soul Candle takes no damage.

A creature can benefit from Candle Against the Dark only once against the same triggering roll. It cannot be recursively triggered by another reroll of that roll.

#### Black-Wax Seal

When Candle Against the Dark turns a failure into a success, you may spend 1 additional Resonance to place a Black-Wax Seal on the protected creature until the end of its next turn. During that time, ordinary possession, forced soul movement, and removal of the creature’s soul from its body automatically fail. Equal- or higher-authority effects require a Cultivation Check rather than being automatically negated.

### CL10 — Funeral Light

You can make the Soul Candle reveal what remains and what is trying to remain unlawfully.

**Action**  
**Range:** 30 feet from you or your Soul Candle  
**Cost:** 4 Resonance

Choose one creature, corpse, haunt, possession, curse, spiritual contamination, or Soul-Wick-marked target.

#### Vigil of the Departed

Choose a corpse or free spirit. If the spirit remains available and has not been destroyed, trapped, fully reincarnated, or protected by higher authority, it may answer up to three brief questions during the next minute.

- A willing spirit answers honestly according to what it knew in life.
- An unwilling spirit makes a Charisma saving throw. On failure, it must answer one question honestly before it may depart or fall silent.
- The rite does not create knowledge the dead never possessed, defeat Secret concealment automatically, or call back a soul that has passed beyond the rite’s authority.

#### Funeral Suppression

Choose one haunt, possession, curse, ordinary spiritual contamination, or one active spiritual expression on a Soul-Wick-marked creature. Make a Cultivation Check against the effect’s save DC or Source CL.

**Success:** An ordinary lower-Source-CL effect ends. A Restricted or equal-Source-CL effect is suppressed for 10 minutes. A higher, Rare, Forbidden, Secret, divine, artifact, or tribulation effect has one printed expression suppressed until the end of your next turn.

**Failure:** The candle gutters. You learn the effect’s broad authority category, one lawful recovery route, and whether it is anchored in the creature, an external object, a place, an oath, a spirit, or another source.

#### Funeral Candle

Choose one hostile creature bearing at least one Soul-Wick Mark. It makes a Wisdom saving throw.

**Failed Save:** It takes `5d8 + Wisdom modifier` Psychic, Fire, or Necrotic damage, your choice, and cannot regain Hit Points until the start of your next turn. Consume one Soul-Wick Mark.

**Successful Save:** It takes half damage, and you do not consume the mark.

If the target is sustained by possession, an external blessing, Concentration, an oath-backed defense, or a spiritual Anchor you have identified, it has Disadvantage on the next saving throw or Cultivation Check it makes to maintain that specific expression before the end of its next turn.

### CL14 — Last Flame

Your Soul Candle can preserve a soul at the instant its ordinary future would end.

**Reaction**  
**Trigger:** A creature within 30 feet of you or your Soul Candle is reduced to 0 Hit Points, fails a death saving throw, would die from an ordinary instant-death effect, or would have its soul removed from its body  
**Cost:** 6 Resonance  
**Requirement:** Your Soul Candle is present and has at least 1 Hit Point

The Soul Candle is extinguished and reduced to 0 Hit Points. The triggering creature instead gains the following benefits:

- If reduced to 0 Hit Points, it drops to 1 Hit Point.
- If it failed a death saving throw, that failure is ignored.
- If an ordinary instant-death or soul-removal effect triggered, that consequence is delayed until the end of the creature’s next turn.
- Until the end of its next turn, it cannot be possessed, have its soul removed, or be killed by an ordinary instant-death effect.
- It is wrapped in visible soul-flame and cannot benefit from being Hidden or Invisible.

During the delay, healing, exorcism, escape, surrender, restoration, severing an Anchor, or another meaningful intervention can change the outcome. If nothing changes and the original effect remains valid, the delayed consequence occurs.

A creature can benefit from your Last Flame only once per scene. Secret Laws, divine judgment, artifact execution, tribulation authority, complete conceptual severance, and campaign-scale soul destruction require a Cultivation Check or a specific counterprocedure; Last Flame does not automatically overrule them.

#### Borrowed Final Breath

If the protected creature survives the delayed consequence, it gains a **Borrowed Final Breath** until it completes one printed Borrowed Final Breath recovery procedure. While it bears this mark, the next time it is reduced to 0 Hit Points, it immediately gains one failed death saving throw. An equal- or higher-Source-CL healing rite, Spiritual Exorcism with suitable materials, or a proper funeral-cleansing vigil removes the mark.

### CL18 — Thousand-Year Lantern

You manifest a lantern containing the remembered flame-patterns of every soul you have lawfully tended.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Requirement:** A functioning Soul Candle

The Soul Candle becomes a **Thousand-Year Lantern**, a 30-foot-radius Spirit Awakening field centered on the candle. Its Asset Hit Points double for the duration.

While the Lantern persists:

- Allies of your choice in the field have Advantage on death saving throws and Intelligence, Wisdom, and Charisma saving throws.
- Allies in the field cannot be possessed or have their souls displaced by ordinary lower-Source-CL effects.
- When an ally in the field succeeds on one of those saving throws, choose one hostile creature in the field. It gains one Soul-Wick Mark or suffers one ordinary Spiritual Pressure effect.
- You may use Spiritual Exorcism once during the activation without spending Resonance, provided the target is in the field.
- A creature restored by Last Flame within the field does not gain Borrowed Final Breath until the field ends.

#### Last Wick Extinguishes

Once during the activation, you may use the following Action:

**Range:** 60 feet from the Lantern  
**Cost:** 6 Resonance  
**Requirement:** A hostile creature bearing three Soul-Wick Marks that is Bloodied, has failed an Intelligence, Wisdom, or Charisma save during the scene, has lost Concentration, or has had a supernatural defense suppressed

The target makes a Wisdom saving throw.

**Failed Save:** It takes `10d10 + Wisdom modifier` Psychic, Fire, or Necrotic damage. Consume all its Soul-Wick Marks. Choose one sustaining expression you previously identified.

- An ordinary lower-Source-CL expression ends.
- A Restricted or equal-Source-CL expression is suppressed for the scene; the target repeats the save at the end of each turn, restoring it after two successes.
- A higher, Rare, Forbidden, Secret, divine, artifact, tribulation, Foundation, Method, or identity-defining expression is not erased automatically. One printed benefit is suppressed until the end of the target’s next turn, subject to a Cultivation Check.
- An ordinary creature whose Source CL is at least 5 lower than yours reduced to 0 Hit Points by this damage can be killed outright if the campaign’s stakes permit it.

**Successful Save:** It takes half damage, loses one Soul-Wick Mark, and its identified sustaining expression flickers until the start of its next turn.

Last Wick Extinguishes is prepared execution authority, not universal soul erasure. Complete soul destruction, lineage extinction, permanent Method loss, and similar results require a dedicated higher-authority Source Rule or campaign-scale rite.

### Normalized Execution Notes

#### Soul Candle Materials
Appropriate physical materials are a wick or absorbent cord, a stable flame or ember, and a vessel or surface that can safely hold it for the vigil. A funeral tablet, lamp, candle, spirit ember, or equivalent item can satisfy all three. If any component is absent, pay the printed 1 Resonance substitution cost.

#### Sustaining Categories
Candle Marking Rite reveals the first applicable category from this ordered list unless you already know it, in which case reveal the next applicable category:

1. bodily vitality or regeneration;
2. active defense or damage mitigation;
3. courage or emotional resistance;
4. Concentration or maintained technique;
5. possession or Hosting;
6. oath, contract, or relationship;
7. external blessing or curse;
8. full companion Bond or manifestation;
9. Anchor, vessel, shrine, or other external sustaining structure.

If none applies, learn that the target has no currently evident external sustaining category.

#### Take the Soot
When Take the Soot applies an ordinary Spiritual Pressure effect, use this ordered selection: the hostile Source Rule chooses one if it already prints an applicable Pressure effect; otherwise choose **Disquieted**. Disquieted gives Disadvantage on the next Concentration check or Wisdom (Perception) check made before the end of your next turn. It is an ordinary Spiritual Pressure effect.

#### Delayed Death and Borrowed Final Breath
Last Flame delays only the discrete consequence that triggered it. Record the source, damage or effect, and original resolution. During the delay, a legal intervention changes the outcome only if it would have prevented, removed, or invalidated that recorded source under its normal rules. If the creature survives, Borrowed Final Breath ends after a Full Cultivation Session, a 1-hour funeral-cleansing vigil costing 2 Resonance, or one successful equal-or-higher-Source-CL healing or exorcism procedure. Use Spiritual Exorcism for this intervention.

A “substantially lower-Realm” creature is a creature whose Source CL is at least 5 lower than yours. Last Wick Extinguishes can kill such an ordinary creature at 0 Hit Points only when the campaign normally permits lethal resolution; it does not bypass an explicit death, reincarnation, phylactery, Anchor, or survival rule.

#### Soul Splitting Expression — Funeral Ember
Your Soul Fragment carries a pale ember. Once per round when a creature within 30 feet of the fragment gains or loses one of your Soul-Wick Marks, the fragment may illuminate it until the start of your next turn. The illuminated creature cannot benefit from ordinary spiritual concealment against your Spiritual Sense. Once before the fragment ends, it may take the reaction for Candle Against the Dark as though it were the Soul Candle's position; you still pay all costs. It cannot create a Soul Candle, use Last Flame, or trigger Last Wick Extinguishes.

#### Asset and Field Rules
A Soul Candle and Thousand-Year Lantern use the printed Asset profile. The Lantern field ends if the Candle is destroyed, suppressed, moved to another plane, or ceases to be a legal Anchor. The Candle takes no independent actions.

### Integrated Procedure Closure — Candlemaker

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Funeral Ember. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 17. Boundary Walker

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted liminal tradition learned at graves, thresholds, mountain gates, river crossings, city wards, shrine borders, or the edge of a Spirit Domain.  
**Identity:** Edges, invitation, refusal, passage, exile, and the third side of a boundary.  
**Primary role:** Tactical movement, anti-teleport control, route surveillance, threshold defense, and temporary border-realm exile.  
**Sphere Lean:** Space, Spirit, Shadow, Death. This tradition grants none of those Spheres.  
**Cultivation boundary:** Boundary Walkers command meaningful crossings. They do not treat arbitrary chalk lines, weapon edges, creature silhouettes, or convenient geometric divisions as thresholds unless ritually prepared or made meaningful by play.

> *Every door has two sides. I learned the third.*

### Meaningful Thresholds

A **meaningful threshold** is a place where passage changes legal, spiritual, social, environmental, or metaphysical state. Examples include a door, gate, bridge, grave-mouth, shrine entrance, city wall breach, river crossing, ritual circle, ward boundary, shadowed arch, cave mouth, border stone, Domain edge, or planar aperture.

A line drawn principally to create a feature target is not meaningful unless prepared through a 1-minute rite and 1 Resonance. A prepared line lasts for the scene and occupies no more than a 10-foot segment.

### Threshold Marks

You can maintain a number of **Threshold Marks** equal to your Proficiency Bonus.

- A Threshold Mark is a visible or concealed spiritual inscription on one meaningful threshold.
- It lasts until you dismiss it, replace it, the threshold is destroyed, or you move more than 1 mile from it for 24 hours.
- It has your Source CL.
- A lower-Source-CL ordinary effect cannot cross, erase, or counterfeit the Mark without your awareness.
- Equal or higher authority can contest it through a Cultivation Check.
- A Threshold Mark is an Anchor only when a feature says it becomes one.

### CL3 — Threshold Step

Once per turn when you move through or begin adjacent to a meaningful threshold, you may spend 1 Resonance to teleport to an unoccupied space you can see within 15 feet of that threshold.

- This movement does not provoke Opportunity Attacks.
- You must cross from one side of the threshold to another, even if the arrival space is only spiritually distinct.
- Total cover, a sealed wall without an opening, or a threshold whose destination is unknown blocks the step.
- You cannot use the same threshold more than once during the same turn.

#### Threshold Sense

While within 60 feet of a meaningful threshold, you know:

- whether it has been crossed by a spirit, possessed creature, undead creature, Resonance Marked creature, or teleporting creature during the current scene;
- whether it is warded, invited, forbidden, broken, one-way, or attached to another destination;
- whether its controlling Source CL is lower than, equal to, or higher than yours.

Protected destination details can require a Cultivation Check.

### CL6 — Mark the Door

**Action**  
**Range:** Touch  
**Cost:** 2 Resonance

Place a Threshold Mark. Choose one mode:

#### Witnessing Mark

You know whenever a spiritually perceptible creature crosses the threshold while you are within 1 mile on the same plane. If it is Resonance Marked, possessed, undead, a spirit, or known to you, you also know its direction of travel and whether it entered willingly.

#### Invited Mark

Name up to your Wisdom modifier in creatures, lineages, offices, spiritual signatures, or broad categories. Those subjects can cross without triggering hostile Boundary Walker effects from you. This is permission, not compulsion.

#### Refusing Mark

Choose one spiritually coherent category such as possessing spirits, undead, creatures bearing a named curse, one known individual, or creatures carrying a specific Resonance Mark. The first qualifying creature each round that attempts to cross must make a Charisma saving throw.

**Failed Save:** Its movement ends immediately before crossing.  
**Successful Save:** It crosses but becomes Resonance Marked by you until the end of your next turn.

A Refusing Mark does not stop substantially higher-authority creatures automatically. It alerts you and forces a Source CL contest instead.

#### Threshold Mark Profile

A marked threshold can be attacked or cleansed as an Anchor when hostile effects depend on it:

- **AC:** `12 + Proficiency Bonus`
- **Hit Points:** `5 × Proficiency Bonus`
- **Resistance:** Psychic and Force
- **Immunity:** Poison and Disease

Destroying the physical threshold normally destroys its Mark. Destroying only the Mark does not destroy the physical object.

### CL10 — Deny Passage

**Reaction**  
**Trigger:** A creature you can perceive enters, leaves, teleports across, becomes incorporeal through, or spiritually passes through a Threshold Mark or a meaningful threshold within 30 feet  
**Cost:** 4 Resonance

The creature makes a Charisma saving throw.

**Failed Save:** Choose one:

- its movement or teleportation fails, and the spent movement is lost;
- it is returned to the space it occupied immediately before crossing;
- if it is a possessing or occupying spirit, it is forced into the nearest open space adjacent to its host or vessel.

It also suffers one Spiritual Pressure effect.

**Successful Save:** The crossing succeeds, but its Speed is reduced by 10 feet and it cannot teleport or become incorporeal again until the end of the turn.

#### Passage Authority

- Ordinary lower-Source-CL movement and teleportation are subject to the save normally.
- Equal-Source-CL route, Gate, artifact, Formation, or Domain effects can require a Cultivation Check after the save.
- Higher, Secret, divine, tribulation, or world-route authority cannot be permanently closed by this Reaction, but you still learn the route’s source direction, broad destination class, and whether an Anchor exists.

Deny Passage resolves before the creature receives any benefit from completing the crossing.

### CL14 — Walk the Border

**Bonus Action**  
**Cost:** 6 Resonance  
**Duration:** The scene

Become half-present on the border between locations.

While active:

- You can move through creatures and openings at least 1 inch wide.
- Opportunity Attacks against you have Disadvantage.
- You can stand on a wall, threshold, bridge edge, shadow boundary, or similar border as though it were stable ground.
- Once per turn, Threshold Step can teleport you up to 30 feet rather than 15 feet.
- You can perceive and interact with incorporeal spirits and border-realm manifestations as though they were fully present.
- You have Resistance to Force and Psychic damage caused by teleportation, planar displacement, possession separation, or spiritual collision.

You cannot pass through a solid wall that has no meaningful opening or threshold, and you cannot end your turn in an invalid space. If forced to do so, you are shunted to the nearest legal space and take `4d10` Force damage.

#### Border Strike

Once on each of your turns when a creature fails a save against your Spirit Awakening feature, you may move it 5 feet toward or away from a meaningful threshold it can perceive. This forced movement cannot place it directly into an obviously lethal hazard unless another Source Rule allows it.

### CL18 — Gate of No Return

You create a temporary border-prison by giving one marked threshold authority over a target’s return.

**Action**  
**Range:** 60 feet  
**Cost:** 10 Resonance  
**Requirement:** The target is Resonance Marked by you or currently crossing a meaningful threshold

Choose one creature. It makes a Charisma saving throw.

**Failed Save:** The target is exiled into a nearby border-realm. Remove it from the battlefield and create a **Gate of No Return Anchor** in an unoccupied space within 30 feet of where it vanished.

The Anchor has:

- **AC:** your Cultivation Save DC
- **Hit Points:** `10 × Proficiency Bonus`
- **Saving Throws:** your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistance:** all damage from sources other than the exiled creature and creatures spiritually tied to it
- **Source CL:** yours

At the end of each of its turns, the exiled creature repeats the save.

- An equal- or higher-Source-CL creature returns after two successes.
- A lower-Source-CL creature returns after three successes.
- Destroying the Anchor immediately returns the creature.
- If you become Incapacitated, the creature gains Advantage on its next save.

While exiled, the creature can perceive a symbolic border-prison and can attack the Anchor spiritually using its normal attack or Cultivation Attack Modifier. It cannot target other battlefield creatures, receive ordinary healing from them, or use the border-realm as a legal destination for unrelated teleportation.

When the creature returns, place it in the nearest unoccupied space of your choice within 30 feet of the Anchor. It suffers two different Spiritual Pressure effects until the start of its next turn.

**Successful Save:** It remains, but until the end of its next turn it cannot teleport, become incorporeal, enter a creature or object, or cross planar or spiritual boundaries. It also suffers one Spiritual Pressure effect.

#### Permanent Exile Boundary

Gate of No Return does not permanently exile a major enemy, destroy a route, erase a homeland connection, or close a world-scale Gate. Such outcomes require a dedicated ritual, lawful destination, suitable Anchors, Source CL superiority, and a separate ritual Source Rule.

### Normalized Execution Notes

#### Threshold Qualification
A threshold qualifies when crossing it changes at least one recorded state: inside/outside a structure, one side of a ward or Domain, land/water, one jurisdiction or territory to another, life-space/grave-space, one plane or bounded spiritual region to another, or permitted/forbidden passage. A prepared line records the two sides when created. Merely drawing a line under a creature or naming an arbitrary weapon edge does not qualify.

#### Route and Destination Record
Any feature that teleports, redirects, or exiles records:

- origin threshold;
- destination space or bounded side;
- whether the route is visible, known, Anchored, or previously crossed;
- lawful occupancy and size;
- passengers, unwilling creatures, and carried Assets;
- Source CL of the route and any opposing boundary.

A destination is legal only if the creature can occupy it, it is not inside total solid matter, and the feature can perceive, identify, or Anchor it as required. If a route becomes illegal before resolution, place the creature in the nearest legal space on the origin side; no cost is refunded unless the feature says so.

#### Invited and Refused Passage
A willing creature may accept passage without a save. An unwilling creature always receives the printed save or Source CL contest. A creature that cannot consent is unwilling unless its controller is legally permitted to consent for it. A Bond, oath, ownership claim, or command does not remove the save unless its Source Rule explicitly authorizes passage.

#### Boundary Collision
When two boundary effects directly conflict, compare Source CL. Lower authority yields. At equal Source CL, each controller makes a Cultivation Check; the higher result governs that crossing only. On a tie, the crossing fails and all creatures remain on their origin sides.

#### Gate of No Return
Its temporary destination must be one of: the opposite side of the marked threshold, a bounded holding space expressly created by the feature, a previously recorded legal threshold within range, or a legal adjacent space on the far side of the current boundary. Permanent exile, route destruction, world-Gate closure, or erasure of a homeland connection requires a separate ritual Source Rule and is not produced by this combat feature.

#### Soul Splitting Expression — Threshold Shade
Your Soul Fragment can occupy a marked or meaningful threshold within 60 feet of you. Once per round when a creature crosses that threshold, the fragment may either place one Resonance Mark on it or move 5 feet through the threshold to a legal space. It cannot teleport another creature, create a Threshold Mark, use Refuse Passage, or activate Gate of No Return.

#### Realm Suppression
Threshold Marks above your effective feature level become dormant but remain physically or spiritually present until their normal duration ends. A dormant mark cannot detect, trigger, or serve as a destination.

### Integrated Procedure Closure — Boundary Walker

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Threshold Shade. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 18. Knot Weaver

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted thread scripture, marriage-curse lineage, karmic shrine, sympathetic-spirit apprenticeship, or initiation by a keeper of relationships.  
**Identity:** Actual relationships, sympathetic ties, mutual consequence, attachment, distance, and severance.  
**Primary role:** Relationship diagnosis, roll and movement interference, linked damage, bond cleansing, and relationship-based control.  
**Sphere Lean:** Fate, Spirit, Mind, Thread. This tradition grants none of those Spheres.  
**Cultivation boundary:** Knot Weavers manipulate existing relationships. They do not create moral debt like Karma, impose accepted obligations like Oath-Ledger, seize collateral like Soul Contracts, or freely rewrite probability like Fate Reader.

> *No one moves alone. Even betrayal leaves a thread.*

### Observed Ties

An **Observed Tie** is an actual relationship you have spiritually witnessed or diagnosed. Examples include protector and ward, commander and subordinate, hunter and quarry, owner and object, mourner and dead, summoner and Asset, possessor and host, oathbound parties, healer and patient, lineage and relic, or creature and home.

You can maintain a number of Observed Ties equal to your Proficiency Bonus.

- An Observed Tie normally lasts for the scene.
- Recording a new Tie beyond your maximum ends one of your choice.
- A Tie records relationship shape, not every secret, motive, name, or legal term.
- False evidence can mislead ordinary diagnosis. Equal or higher concealment can require a Cultivation Check.
- A tie that genuinely ends also ends your record unless a scar, debt, ownership claim, grief, or other continuing relationship remains.

### Knot Tension

Some features create **Knot Tension** on a creature or relationship.

- Knot Tension begins at 0 each scene.
- Your maximum Knot Tension equals your Proficiency Bonus.
- You gain 1 Knot Tension when a meaningful hostile creature within 60 feet acts through an Observed Tie: protects its ward, obeys a commander, attacks its quarry, activates a bound Asset, exploits an oath, uses a possession link, or meaningfully invokes another recorded relationship.
- You can gain no more than 1 Knot Tension per turn.
- You cannot gain Tension from staged ally behavior, harmless summons, captive loops, or repeatedly invoking a tie without meaningful stakes.
- Knot Tension lasts for the scene and is not Resonance.

### CL3 — Red Thread Sense

**Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one creature, object, Asset, Anchor, location, or active spiritual effect you can perceive. Learn one visible relationship involving it and record that relationship as an Observed Tie.

You learn:

- the broad role of each side;
- whether the tie is willing, coerced, inherited, possessive, protective, contractual, grief-born, hostile, or concealed;
- whether the tie’s Source CL is lower than, equal to, or higher than yours;
- whether the tie is active, dormant, damaged, false, severed-but-scarred, or externally anchored.

You do not automatically learn names, exact contract terms, hidden motives, complete memories, or protected secrets.

#### Tug the Visible Thread

Once per turn when you place or refresh a Resonance Mark on a creature involved in an Observed Tie, you may choose one:

- move it 5 feet toward or away from the other side of the Tie;
- learn whether it is currently acting to protect, obey, pursue, possess, restore, or abandon the other side;
- prevent it from becoming Hidden from the other side until the start of your next turn.

Forced movement cannot place a creature in an obviously lethal hazard without another Source Rule.

### CL6 — Tie the Moment

**Reaction**  
**Trigger:** A Resonance Marked creature within 60 feet involved in an Observed Tie makes an attack roll, saving throw, or ability check, or willingly moves 10 feet or more  
**Cost:** 3 Resonance or 1 Knot Tension

Declare the tug before the outcome is finalized. Choose one:

- subtract `1d6` from the triggering attack roll or saving throw;
- reduce the triggering movement by 10 feet;
- deny Advantage granted by the other side of the Observed Tie on the triggering roll;
- if the triggering creature moved away from the other side, pull it 5 feet back after its movement resolves;
- if it targeted the other side with a hostile effect, impose one ordinary Spiritual Pressure effect after the effect resolves.

Tie the Moment cannot reverse an already resolved event, create an attack target that was illegal at declaration, or force a creature to spend an additional limited resource.

#### Counter-Tug

An equal- or higher-Source-CL target may spend its Reaction to make a Charisma saving throw. On success, reduce the numerical adjustment by half or ignore the forced movement. This does not refund your cost.

### CL10 — Binding Knot

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance  
**Duration:** The scene

Choose two creatures, or one creature and one object, Asset, Anchor, or location, that are part of the same Observed Tie. Each unwilling creature makes a Charisma saving throw. A willing creature may fail automatically.

If both fail or consent, create a **Binding Knot**. Choose one form:

#### Burden Knot

Once per round when one linked creature takes Psychic, Force, or Necrotic damage, the other linked creature takes Psychic damage equal to `Wisdom modifier + Proficiency Bonus`.

#### Distance Knot

When one linked creature willingly ends its turn more than 60 feet from the other, it makes a Charisma saving throw. On failure, its Speed becomes 0 until the start of its next turn and it is pulled up to 10 feet toward the other side if a legal path exists.

#### Guardian Knot

Once per round when one side takes damage, the other side may use its Reaction to take up to half that damage instead. If unwilling, the other side must first fail a Charisma saving throw.

#### Possession Knot

Use only on a possessor and host or controller and controlled Asset. The controller has Disadvantage on the first save or Cultivation Check each round made to maintain control, and damage to the controller can force an immediate maintenance save.

At the end of each unwilling creature’s turn, it repeats the save, breaking its side on a success. Destroying or ending the actual relationship can end the Knot if no continuing scar or claim remains.

A Binding Knot does not independently create consent, loyalty, ownership, love, guilt, or legal obligation.

### CL14 — Sever the False Thread

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance

Choose one charm, fear, possession, compulsion, false memory bond, coercive oath expression, hostile sympathetic link, controller-Asset link, or emotional manipulation affecting a creature you can perceive.

Make a Cultivation Check against the effect’s save DC or Source CL.

**Success:**

- An ordinary lower-Source-CL false or coercive tie ends.
- A Restricted or equal-Source-CL tie is suppressed for the scene. Its source may attempt restoration through its printed procedure or a Cultivation Check after one Meaningful Intervention defined in the Normalized Execution Notes.
- A higher, Rare, Forbidden, Secret, divine, artifact, tribulation, Foundation, Method, or identity-defining tie has one coercive expression suppressed until the end of your next turn.

**Failure:** The target gains Advantage on its next saving throw or Cultivation Check against that tie, and you learn one Anchor, maintenance condition, lawful release, or reconstruction route.

#### Honest Bonds Remain

Sever the False Thread does not automatically end a willing relationship, valid Spirit Companion bond, complete oath, lawful contract, genuine love, lineage, parentage, memory of the dead, Foundation, or Method. It can remove coercion, counterfeit attachment, possession, or an unlawful expression without erasing the underlying people or history.

#### Severance Scar

When you fully end a coercive tie, the target may retain a Severance Scar visible to Soul Gaze until it completes one Severance Scar recovery procedure. The scar provides evidence that a tie existed but grants no control and does not count as an Observed Tie for hostile benefits.

### CL18 — Knot of Inevitability

You bind a consequence to an actual relationship rather than to abstract fate.

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 10 Resonance and all remaining Knot Tension, minimum 1  
**Duration:** The scene  
**Requirement:** The target is Resonance Marked and involved in an Observed Tie

Choose one target and one actual side of its Observed Tie. Create a **Great Knot Anchor** in an unoccupied space within 30 feet of either side.

The Anchor has:

- **AC:** your Cultivation Save DC
- **Hit Points:** `8 × Proficiency Bonus`
- **Resistance:** Psychic, Force, and damage from creatures not involved in the Tie
- **Source CL:** yours

Name one relationship-bound consequence:

- **Remain:** The target cannot willingly move more than 30 feet from the other side.
- **Face:** The target cannot willingly target creatures other than the other side with hostile effects while that side remains a legal target.
- **Release:** The target must drop, dismiss, or cease controlling one object, Asset, possession, or effect that forms the Tie.
- **Protect:** The target cannot willingly harm the other side and must use its Reaction, if available, to reduce one instance of damage to that side by `2 × Proficiency Bonus`.
- **Answer:** The target must answer one direct question about the Observed Tie with a statement it believes to be true.
- **Return:** An object, Asset, stolen identity-fragment, or controlled spirit forming the Tie must move or be moved toward its lawful or former side by the safest available route.

The target makes a Charisma saving throw when the Knot is created and at the end of each of its turns.

**Failed Save:** The consequence binds until the next save. A lower-Source-CL target that fails three saves during the scene remains bound until the Great Knot Anchor is destroyed or the relationship genuinely changes.

**Successful Save:** The target resists until the start of its next turn but suffers two different Spiritual Pressure effects.

Destroying the Anchor ends the Great Knot. Equal- or higher-Source-CL relationship, oath, contract, karma, fate, Secret, divine, or artifact authority can contest the Knot through a Cultivation Check.

Knot of Inevitability cannot command unrelated behavior, invent guilt, establish ownership, rewrite history, or force direct self-destruction. Its authority exists because the target already participates in the relationship being tightened.

### Normalized Execution Notes

#### Relationship Categories
Every Observed Tie uses one primary category:

- **Duty:** protector/ward, commander/subordinate, healer/patient;
- **Pursuit:** hunter/quarry, investigator/subject;
- **Possession or Control:** possessor/host, controller/Asset, owner/object when legally or metaphysically active;
- **Oath or Contract:** sworn parties, patron/client, covenant members;
- **Kinship or Lineage:** ancestor/descendant, lineage/relic;
- **Attachment:** mourner/dead, beloved/beloved, creature/home;
- **Summoning or Creation:** summoner/manifestation, maker/construct;
- **Custody:** jailer/prisoner, keeper/contained spirit.

A relationship must currently exist and have at least one observable permission, obligation, benefit, cost, or behavior. Mere proximity, acquaintance, or declared hostility is not a Tie.

#### Meaningful Intervention and Genuine Change
A suppressed Tie can be restored only by its printed maintenance procedure or by an action that changes one of its recorded terms: renewed consent, fulfilled obligation, repaired Anchor, replacement controller, completed restitution, lawful release, or a successful equal-authority rite. Ordinary movement or repeating the same declaration is not sufficient.

A relationship genuinely changes when one side dies or is permanently removed, consent is lawfully withdrawn, the governing object or Anchor is destroyed, an oath is fulfilled or broken under its rules, control legally transfers, or the parties complete a printed renegotiation procedure.

#### Safest Available Return Route
For Return, choose the shortest legal route that does not enter an obvious lethal hazard, total solid matter, or an effect known to be immediately destructive. If multiple routes are equal, the returning object's controller chooses. If no route exists, it moves as close as possible and the Great Knot remains active.

#### Relationship Authority
When Oath, Contract, Karma, Fate, Bond, Secret, divine, or artifact authority conflicts with a Knot, compare Source CL first. Equal Source CL requires opposed Cultivation Checks. A successful Knot changes only the feature's printed relationship expression; it does not erase an unrelated legal identity, ownership history, ancestry, or Complete Soul.

#### Severance Scar Recovery
A Severance Scar ends after one Full Cultivation Session that includes consent restoration, grief or identity treatment, lawful release, relationship renegotiation, or an equal-authority exorcism procedure. It has no numerical penalty and cannot be harvested for Knot Tension.

#### Soul Splitting Expression — Loose-End Double
Your Soul Fragment may hold one Observed Tie you have recorded. Once per round when either side of that Tie moves within 30 feet of the fragment, the fragment may move the other willing side 5 feet along a legal path or reveal whether the Tie is currently active, suppressed, or severed. It cannot create Ties, gain Knot Tension, use Binding Knot, or activate Knot of Inevitability.

### Integrated Procedure Closure — Knot Weaver

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Loose-End Double. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 19. Soulstring Dancer

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted scripture, cursed dance school, theater-spirit pact, execution-stage lineage, or inheritance from a soulstring adept.  
**Identity:** Motion, rhythm, reflex, balance, soul-threads, and forced choreography.  
**Primary role:** Forced movement, reaction denial, attack redirection, single-target control, and mobile area control.  
**Sphere Lean:** Mind, Body, Illusion, Spirit. This tradition grants none of those Spheres.  
**Cultivation boundary:** Soulstring Dancers pluck the interval between intention and motion. They do not create autonomous puppets, copy complete bodies, grant Body Refining features, or replace a specialized sustained direct-control technique.

> *Your body knows the next step. I only ask it to answer me instead.*

### Choreography Strings

Several features place **Choreography Strings** on creatures.

- A creature can bear up to three Choreography Strings from you.
- A String lasts for the scene unless removed or consumed.
- A String is visible to Spiritual Sense but is not a physical cord, grapple, Restraint, Spirit Companion bond, or possession.
- A creature gains one String when it fails a saving throw against one of your Spirit Awakening features and you choose to place one.
- You can place no more than one String on the same creature per turn.
- A creature can use an Action to attempt a Wisdom saving throw, removing one String on a success.
- An equal- or higher-Source-CL cleansing, identity stabilization, or movement-freedom effect can remove one or more Strings through a Cultivation Check.

Strings record interrupted rhythm. They do not independently allow arbitrary speech, memory, resource spending, self-harm, or feature activation.

### CL3 — Threaded Step

When you hit a creature with Mind Spike or it fails a saving throw against one of your Spirit Awakening features, you may place one Choreography String and move it 5 feet in a direction of your choice if it is Large or smaller and physically able to move.

- This is forced movement and does not provoke Opportunity Attacks.
- It cannot move the creature into an obviously lethal hazard unless another Source Rule permits it.
- A creature with equal or higher Source CL can make a Strength or Wisdom saving throw to ignore the movement while still receiving the String.

#### Dancer’s Counterstep

Once per round when a creature bearing one of your Strings moves willingly within 30 feet of you, you may move 5 feet without provoking Opportunity Attacks. This does not use your Reaction, but you cannot use it while Incapacitated or Restrained.

### CL6 — Stolen Rhythm

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance  
**Requirement:** The target bears at least one Choreography String

The target makes a Wisdom saving throw.

**Failed Save:** Consume one String and choose two effects until the start of your next turn:

- Speed reduced by 10 feet;
- cannot take Reactions;
- Disadvantage on the next weapon attack;
- cannot benefit from Advantage created by an ally’s Help;
- must spend 5 additional feet of movement to stand from Prone or change elevation;
- cannot take the same movement mode twice during the turn, such as teleporting twice or flying after walking.

**Successful Save:** Do not consume the String. Choose one effect from the list.

#### Catch the Beat

If the target fails while bearing three Strings, you may instead consume all three to make its Speed 0 until the start of your next turn. It can still teleport or be moved by another source unless that source also fails a Source CL contest against you.

### CL10 — Marionette Defense

**Reaction**  
**Trigger:** You are hit by an attack while a creature bearing one of your Choreography Strings is within 30 feet  
**Cost:** 4 Resonance

Choose one String-bearing creature that is within the triggering attack’s reach, line, area, or legal target geometry. It makes a Wisdom saving throw.

**Failed Save:** Consume one String. You move up to 10 feet without provoking Opportunity Attacks. If the chosen creature remains a legal target for the triggering attack after that movement, the attack targets it instead and retains the original attack roll.

**Successful Save:** You gain `+2 AC` against the triggering attack and may move 5 feet after it resolves.

Marionette Defense cannot redirect an effect to an illegal target, force an attacker to spend another resource, change a self-only effect, or redirect a precise effect whose Source Rule states it cannot change targets.

#### Dance Partner

A willing ally bearing one of your Strings may choose to fail the save. If it does, it gains Resistance to the triggering attack’s damage and the String is consumed after damage resolves. This permits deliberate bodyguard choreography without creating infinite redirection loops.

### CL14 — Dance of Borrowed Limbs

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance  
**Concentration:** Required, up to 1 minute  
**Requirement:** The target bears at least two Choreography Strings

The target makes a Wisdom saving throw.

**Failed Save:** Consume one String. At the start of each of the target’s turns, choose one command:

- lose 10 feet of Speed;
- drop one held object that is not soul-bound or inseparably attached;
- move up to 10 feet along a legal path;
- fall Prone;
- make one weapon attack at Disadvantage against a legal target you choose within reach;
- spend its Reaction making a harmless involuntary gesture, step, or guard motion;
- speak or remain silent for one brief phrase, provided this does not compel protected information or a lie the creature cannot formulate.

The target repeats the save at the end of each turn, ending the feature on a success. Each successful save removes one remaining Choreography String.

**Successful Initial Save:** The feature does not take hold. The target suffers one ordinary Spiritual Pressure effect, and you do not consume a String.

#### Control Boundary

Dance of Borrowed Limbs cannot force direct self-destruction, activate Legendary, Secret, divine, artifact, tribulation, or limited-use powers, spend the target’s cultivation resources, alter its memories, or compel it to reveal unknown or protected information.

A substantially lower-Source-CL ordinary creature can be forced to repeat harmless choreography without further saves after three failed saves during the same activation, but hostile attacks, self-endangerment, and major actions always preserve the saving throw procedure.

### CL18 — Theater of Strings

You transform the battlefield into a stage whose rhythm is spiritually legible to you.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene

Create a 30-foot-radius **Theater of Strings** field centered on you. It moves with you and has your Source CL.

While active:

- When a hostile creature starts its turn in the field, you may place one Choreography String on it if it is Resonance Marked by you, failed a Spirit Awakening save since the end of its last turn, or moved unwillingly during the round.
- A creature can receive no more than one String from the field per round.
- Once per round when a creature in the field moves, attacks, stands, falls, teleports, or changes elevation, you may move another String-bearing creature 5 feet along a legal path.
- You and willing allies in the field ignore the first 10 feet of difficult terrain each turn and can stand from Prone using 5 feet of movement.
- Hostile String-bearing creatures cannot take Opportunity Attacks against you.

#### Final Choreography

Once during the activation, choose one creature in the field bearing three Strings. It makes a Wisdom saving throw.

**Failed Save:** Consume all three Strings. Choose one sequence:

- **Empty Turn:** It loses its Action on its next turn performing harmless involuntary movement.
- **Crossed Blades:** It uses its Reaction immediately to make one weapon attack at Disadvantage against a legal target you choose.
- **Broken Formation:** Move it up to half its Speed along a legal route, and it cannot take Reactions until the end of its next turn.
- **Kneeling Beat:** It falls Prone, its Speed becomes 0 until the end of its next turn, and it suffers one Spiritual Pressure effect.

**Successful Save:** It removes one String and suffers two different Spiritual Pressure effects until the start of its next turn.

Equal- and higher-Source-CL targets can contest forced movement or target redirection through a Cultivation Check after the save. Theater of Strings controls motion; it does not erase agency, create an additional sustained puppet-control system, or create a permanent puppet.

#### Soul Splitting Option — Second Dancer

Your Soul Fragment gains the following **Subpath Fragment** option:

- **Echo the Step:** Move one creature bearing your Choreography String within 30 feet of the fragment by 5 feet along a legal path. A creature can be moved by this fragment option only once per round.

The fragment does not place Strings, consume Strings, or use Final Choreography.

### Normalized Execution Notes

#### Harmless Choreography
Harmless choreography is movement, posture, facing, dropping prone, standing, drawing or stowing a nonhazardous object, or making a purely demonstrative weapon flourish that deals no damage and triggers no technique. It cannot force a creature to enter a known hazard, leave safe support while airborne, surrender irreplaceable property, break Concentration, spend a limited resource, reveal protected information, or provoke an attack from another creature known to be waiting.

#### Compelled Attacks and Actions
A command that makes an attack uses the target's ordinary attack bonus, reach, weapon, damage, and legal target rules. It cannot make the target spend CP, ammunition it does not possess, charges, limited-use features, or a Reaction unless the command explicitly uses that Reaction. It cannot force self-targeting unless the original feature expressly permits it.

#### Forced Movement
All Choreography movement follows legal-destination rules. It does not provoke opportunity attacks unless the feature says so. A creature cannot be moved more than once by the same fragment option in a round, and movement from separate Soulstring features does not recursively trigger additional Strings.

#### String Record
For each creature, record current Strings, their source, and whether the creature is willing. Strings are spiritual states, not physical cords, unless a manifestation says otherwise. Realm Suppression can make Strings dormant; dormant Strings cannot be spent or counted but resume if the suppressing effect ends before their duration.

#### Soul Splitting Expression
The existing **Second Dancer** expression is retained. Echo the Step follows the legal-destination and anti-recursion rules above.

### Integrated Procedure Closure — Soulstring Dancer

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Dancer. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 20. Grief Eater

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted funeral lineage, cursed compassion, battlefield-survivor awakening, mourner-spirit pact, or initiation by a community that entrusts its dead to one vessel.  
**Identity:** Consuming sorrow, carrying communal grief, shielding the living, and making harm answer to mourning.  
**Primary role:** Emotional cleansing, ally protection, burden sharing, guilt pressure, and communal defensive field.  
**Sphere Lean:** Spirit, Death, Mind, Healing. This tradition grants none of those Spheres.  
**Cultivation boundary:** Grief Eaters metabolize grief, fear, despair, and the emotional shadow of loss. They do not remove arbitrary physical injuries, curses, poisons, complete memories, Methods, Foundations, or soul damage merely by calling them sorrow. Mercy Flayer houses suffering and afflictions; Grief Eater transforms emotional mourning into protection and judgment.

> *Give me the sorrow. I know where to put it.*

### Sorrow Burdens

Several Grief Eater features create or spend **Sorrow Burdens**.

- Your Sorrow Burdens begin at 0 each scene.
- Your maximum equals your Proficiency Bonus.
- Gain 1 Sorrow Burden when a meaningful creature within 60 feet becomes Bloodied, Frightened, Charmed, possessed, reduced to 0 Hit Points, dies, suffers major memory or identity harm, or openly experiences story-significant grief—and you consciously witness or spiritually perceive the event.
- You can gain no more than 1 Sorrow Burden per turn and no more than 1 from the same event.
- You cannot gain Burdens from staged harm, harmless summons, repeated captive loops, allies intentionally frightening one another, or repeatedly reopening a resolved minor sadness.
- Sorrow Burdens last for the scene. They are not Resonance and cannot be converted directly into Resonance.

Carrying Burdens leaves visible traces to Spiritual Sense: dark flowers, funeral smoke, wet ash, stones in the chest, remembered voices, or another suitable sign.

### CL3 — Taste of Sorrow

**Reaction**  
**Trigger:** A meaningful creature within 60 feet becomes Bloodied, Frightened, Charmed, possessed, reduced to 0 Hit Points, dies, or experiences a major emotional break

Gain 1 Sorrow Burden and choose the triggering creature. If it is willing or fails a Wisdom saving throw, it becomes Resonance Marked by you until the end of your next turn.

You learn the dominant emotional category around it: fear, grief, rage, guilt, love, emptiness, despair, relief, using the fixed Emotion Categories in the Normalized Execution Notes.

This does not reveal the cause, hidden facts, exact memories, guilt’s truth, or whether the emotion is morally justified.

#### Carry the First Tear

Once per round when an ally within 30 feet would suffer an ordinary Spiritual Pressure effect, you may spend 1 Sorrow Burden to take that effect instead. You may choose a different ordinary Spiritual Pressure effect that meaningfully represents the burden. This does not use your Reaction.

### CL6 — Eat the Bitter Memory

**Action**  
**Range:** Touch  
**Cost:** 3 Resonance

Touch a willing creature suffering Frightened, Charmed, a Nightmare Scar, ordinary despair, grief paralysis, emotional corruption, or an ordinary memory-emotion wound.

Choose one:

#### Consume

End one ordinary effect. Gain 1 Sorrow Burden if you are below your maximum. You take `1d8` Psychic damage per authority tier, normally one die for ordinary, two for Restricted, three for Rare or Forbidden, and four for Secret or comparable effects. This damage cannot be reduced, redirected, transferred, converted into healing, or used to generate another Sorrow Burden.

#### Suppress

Suppress a stronger effect until the end of your next turn. You take `2d8` Psychic damage that cannot be reduced. The target gains Advantage on the next save or Cultivation Check it makes against that effect during the suppression.

#### Diagnose

Do not remove the effect. Learn its Source CL relationship to yours, whether it is self-generated or externally imposed, one trigger that strengthens it, one condition that weakens it, and one lawful recovery route.

Equal- or higher-Source-CL effects can require a Cultivation Check. Failure never worsens the target’s condition; instead, you become Resonance Marked by the hostile source until the end of your next turn.

### CL10 — Shared Burden

**Reaction**  
**Trigger:** An ally within 30 feet takes Psychic, Necrotic, or Force damage, fails an Intelligence, Wisdom, or Charisma saving throw, or would receive an ordinary emotional, possession, nightmare, grief, or identity effect  
**Cost:** 4 Resonance or 2 Sorrow Burdens

Choose one mode:

#### Divide the Pain

You take half the triggering damage, rounded up, and the ally takes the remainder. Your share cannot be reduced, redirected, or converted into healing.

#### Carry the Echo

The ally rerolls the triggering saving throw and must use the new result. Whether it succeeds or fails, you suffer one lesser emotional echo until the end of your next turn: Frightened, unable to take Reactions, Speed reduced by 10 feet, Disadvantage on your next attack, or another ordinary Spiritual Pressure effect.

#### Hold the Door

Delay an ordinary possession, nightmare, charm, despair, memory-emotion wound, or identity-pressure consequence until the end of the ally’s next turn. During the delay, meaningful exorcism, healing, escape, surrender, anchor destruction, or emotional intervention can change the result. If nothing changes, the consequence occurs.

Transferring a permanent soul wound, complete memory loss, high-authority possession, curse, Secret effect, divine judgment, artifact authority, or tribulation scar requires a Cultivation Check and normally creates a persistent Burden Scar rather than simply removing the effect.

#### Burden Scar

A Burden Scar is a Hidden Injury of the spirit. It remains until treated through Spiritual Exorcism, a funeral rite, a proper emotional resolution, equal-authority healing, or one Burden Scar treatment procedure in the Normalized Execution Notes. It cannot be farmed for Sorrow Burdens.

### CL14 — Weight of Mourning

You make a target carry the grief created by its own meaningful actions.

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance and 1 Sorrow Burden  
**Requirement:** The target damaged an ally, killed or destroyed a meaningful creature or Asset, inflicted major emotional or spiritual harm, or bears a visible grief-related spiritual stain during the scene

The target makes a Charisma saving throw.

**Failed Save:** It gains **Mourning Weight** until it completes two successful saves at the end of its turns.

While weighted:

- its Speed is halved;
- it cannot take Reactions;
- it has Disadvantage on attacks against creatures directly harmed by the qualifying act;
- the first time each turn it uses a hostile feature, it takes Psychic damage equal to `2 × Proficiency Bonus`;
- it cannot become Hidden from you or from a creature directly harmed by the qualifying act.

**Successful Save:** Its Speed is reduced by 10 feet and it suffers one Spiritual Pressure effect until the end of its next turn.

Mourning Weight does not determine moral guilt or punish a creature for secret crimes you have not witnessed, diagnosed, or connected through lawful evidence. It gives spiritual mass to grief already present in the scene.

#### Innocence and False Grief

A target protected by false memories, framed evidence, coerced action, or concealed causality can reveal that contradiction through a successful Cultivation Check or relevant investigation. If the qualifying basis proves false, Mourning Weight ends and you recover neither Resonance nor Sorrow Burdens.

### CL18 — Vessel of Ten Thousand Sorrows

You open your soul as a communal vessel without allowing the stored grief to erase your identity.

**Bonus Action**  
**Cost:** 10 Resonance and any number of Sorrow Burdens  
**Duration:** The scene

Create a 30-foot-radius **Mourning Field** centered on you. It moves with you and has your Source CL.

While active:

- Allies of your choice in the field have Resistance to Psychic damage.
- They have Advantage on saves against Charmed, Frightened, possession, nightmare, despair, grief, ordinary emotional corruption, and forced memory-emotion effects.
- When an ally in the field fails one of those saves, you may take one ordinary Spiritual Pressure effect to let it reroll. You can do this once per round without spending your Reaction.
- When you use Eat the Bitter Memory, Shared Burden, Spiritual Exorcism, or another legal feature to remove, suppress, absorb, or delay a meaningful hostile effect in the field, choose one ally in the field. It gains Temporary Hit Points equal to `Wisdom modifier + Proficiency Bonus`.
- A creature cannot generate Sorrow Burdens from consequences you already absorbed during this activation.

For each Sorrow Burden spent when the field manifests, choose one **Mourning Office**:

#### Office of the Wake

Allies reduced to 0 Hit Points in the field remain conscious until the end of their current turn, though they are still at 0 Hit Points and make death saving throws normally afterward.

#### Office of the Empty Chair

Hostile creatures in the field cannot benefit from ordinary invisibility or emotional concealment against creatures they meaningfully harmed during the scene.

#### Office of the Funeral Bell

The first time each round a hostile creature in the field inflicts Psychic, Necrotic, possession, nightmare, grief, or identity damage, it becomes Resonance Marked by you and takes Psychic damage equal to your Proficiency Bonus.

#### Office of Returning Names

When an ally in the field would lose an ordinary memory, name, relationship recognition, or emotional bond, delay that loss until the field ends. The ally has until then to receive restoration or complete a meaningful anchoring act.

#### Mourner’s Embrace

Once during the activation, choose one hostile creature in the field bearing Mourning Weight or at least one of your Resonance Marks. It makes a Charisma saving throw.

**Failed Save:** It is Restrained by manifested grief until the end of its next turn and must choose one:

- cease hostile action for that turn;
- move toward a creature, corpse, place, or object connected to the grief;
- speak one statement it believes about the harm;
- accept `8d10 + Wisdom modifier` Psychic damage and two different Spiritual Pressure effects.

An ordinary creature whose Source CL is at least 5 lower than yours that chooses to cease hostility cannot resume hostility until it leaves the field or succeeds on a Charisma save at the end of a later turn.

**Successful Save:** It is not Restrained but takes half the listed damage and suffers one Spiritual Pressure effect.

Mourner’s Embrace does not compel true remorse, invent guilt, reveal unknown facts, or permanently reform a target. It forces contact with grief that already has a lawful spiritual basis.

#### Vessel Consequence

When the Mourning Field ends, make a Wisdom saving throw against your own Cultivation Save DC.

**Success:** Retain your identity and release the gathered grief through a visible but harmless funeral sign.  
**Failure:** Gain a Burden Scar and one level of Exhaustion. The Burden Scar cannot be removed by a short rest or ordinary healing; it requires one Burden Scar treatment procedure.

### Normalized Execution Notes

#### Emotion Categories
Use one of these categories: fear, grief, rage, guilt, love, emptiness, despair, relief, shame, longing, or numbness. If several apply, the affected creature chooses when willing; otherwise use the first category demonstrated by its most recent qualifying action or condition. No additional category is invented during resolution.

#### Meaningful Creature and Event
A creature qualifies when it is a nontrivial participant in the current scene, a named or persistent relationship, a significant Asset or Companion, or a creature whose loss or suffering changes an objective. Staged ally damage, harmless summons, captive loops, repeated condition application without new stakes, and created creatures whose only purpose is producing Burdens do not qualify.

#### Burden Scar Treatment
A Burden Scar is a spiritual Hidden Injury with no automatic numerical penalty beyond the feature that created it. Remove one Scar through one of these procedures:

- complete a Full Cultivation Session with a funeral, mourning, confession, reconciliation, or emotional-integration practice;
- receive successful Spiritual Exorcism or equal-authority emotional restoration;
- fulfill a recorded final request or duty connected to the grief;
- spend a Full Cultivation Session at a lawful ancestral, community, or funeral shrine with appropriate offerings.

A single event removes one Scar unless a Source Rule says otherwise. A Scar cannot generate Sorrow Burdens.

#### Changing a Delayed Consequence
During Hold the Door or Office of Returning Names, an intervention changes the delayed result only if it removes its source, succeeds at its printed save or contest, destroys or suppresses its sustaining Anchor, moves the target beyond the source's legal reach, or causes the source to willingly withdraw. An unrelated emotional speech is insufficient unless a feature expressly makes it a legal treatment.

#### Ceasing Hostility
A creature ceases hostility when it uses its turn to take no hostile action, ends any voluntary hostile Concentration it controls, and either moves away from its current target or clearly surrenders. A creature locked by Mourner's Embrace may defend itself and move to safety. It resumes hostility only after leaving the Field or succeeding on the printed Charisma save at the end of a later turn.

#### Burden Translation
When Carry the First Tear lets you choose a different Spiritual Pressure effect, choose from the ordinary effects already defined by the Spirit Awakening core. The replacement must have equal or lower ordinary severity and cannot create damage, control, or a higher-authority state.

#### Soul Splitting Expression — Mourning Attendant
Your Soul Fragment can carry one Sorrow Burden. Once per round when an ally within 30 feet of the fragment would suffer an ordinary Spiritual Pressure effect, the fragment may spend its carried Burden to take that effect, causing the fragment to become dormant until the start of your next turn. It cannot gain new Burdens, use Eat the Bitter Memory, create Mourning Weight, or manifest Vessel of Ten Thousand Sorrows.

#### Terminology Update
This tradition uses **Spiritual Exorcism** under Core R2A.

### Integrated Procedure Closure — Grief Eater

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Mourning Attendant. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 21. Mirror Speaker

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted mirror shrine, haunted reflection, moon-water rite, polished-weapon lineage, or inheritance from a reflection spirit.  
**Identity:** Reflected identity, inverted truth, false selves, confessions, and spaces behind glass.  
**Primary role:** Reactive defense, spiritual detection, positional misdirection, identity exposure, and temporary reflection imprisonment.  
**Sphere Lean:** Mirrors, Illusion, Spirit. This tradition grants none of those Spheres.  
**Cultivation boundary:** A Mirror Speaker works through a reflection that meaningfully corresponds to a creature, object, place, or event. A random glint, painted image, ordinary portrait, or imagined reflection does not automatically provide spiritual access. Reflection reveals correspondence and contradiction; it does not grant unrestricted omniscience, true-name authority, or arbitrary duplication.

> *The mirror never lies. It waits for you to become honest enough to understand what it is saying.*

Mirror Speakers cultivate the difference between what stands before the glass and what answers from within it. Their arts are elegant and deeply unsettling: a hostile intent appears half a breath early, a lie leaves a second mouth in the mirror, and a person who has fled every ordinary prison discovers that their own reflection has been waiting with the door locked.

### Valid Reflections

A **valid reflection** is a visible reflected image in a mirror, polished metal, polished stone, still water, ice, glass, lacquer, a reflective treasure, or another surface whose current image can be perceived clearly enough to correspond to its subject.

Unless a feature says otherwise:

- A valid reflection must be within 60 feet of you or within range of a Reflection Double you control.
- A reflection blocked by total cover is not a valid origin merely because the reflective surface exists.
- Darkness, turbulence, damage, smoke, mud, or deliberate distortion can make a reflection invalid.
- A warded, divine, Secret, artifact, or higher-Source-CL reflection can block, counterfeit, or distort your access.
- A creature whose image is absent from ordinary reflections is not automatically immune. You may attempt a Cultivation Check against the effect concealing or removing its image. On success, you perceive the absence itself as its reflected sign.

### Reflection Traces

Several features place a **Reflection Trace**.

- A Reflection Trace is a special Resonance Mark and counts as your Resonance Mark.
- It appears to spiritual perception as a second outline, reversed shadow, reflected eye, silver crack, water-image, or equivalent sign.
- It lasts for the scene unless removed or consumed.
- A creature can bear only one Reflection Trace from you.
- You can normally place no more than one Reflection Trace on the same creature per turn.
- While a traced creature has a valid reflection within 60 feet of you, ordinary invisibility and mundane disguise do not conceal the fact that the traced creature is present, though they can still conceal its exact space.
- A Reflection Trace does not reveal thoughts, statistics, true names, or hidden memories.

A creature can attempt to erase its trace by spending an Action to break, obscure, or ritually repudiate every valid reflection of itself it can perceive within 30 feet, then succeeding on a Charisma saving throw. On a success, the trace ends. An equal- or higher-Source-CL cleansing effect can remove it normally.

### CL3 — Reflection Listener

You can listen to the self that surfaces preserve.

#### Speak Through Reflection

**Action**  
**Range:** One valid reflection within 60 feet  
**Cost:** 1 Resonance  
**Duration:** Until the end of your next turn

You see and hear from the chosen reflection as though occupying its surface. During the activation:

- You can speak through the reflection in your own voice or in a reversed whisper recognizable as yours.
- You can use Spiritual Sense and Soul Gaze from the reflection’s space.
- You do not gain line of effect for attacks, ordinary object interaction, or unrelated features.
- If the surface is moved, covered, shattered, or made invalid, the activation ends.
- A creature observing the surface can identify it as spiritually active with a successful Wisdom (Perception), Intelligence (Investigation), or Cultivation Check against your Cultivation Save DC.

#### Reflection Diagnosis

When you perceive a creature both directly and in a valid reflection, you may compare its presented self with its reflected self. As part of Soul Gaze or as a Bonus Action costing 1 Resonance, choose that creature.

The target makes a Charisma saving throw. A willing creature may fail automatically.

**Failed Save:** Place a Reflection Trace on it and learn one category in which its current spiritual presentation contradicts its reflected state:

- concealed fear, grief, guilt, loyalty, desire, or hostility;
- possession, divided identity, borrowed appearance, counterfeit spiritual signature, or active transformation;
- an illusion or disguise affecting identity;
- an external effect suppressing, replacing, or speaking through the target;
- no meaningful contradiction.

**Successful Save:** You learn only whether a stronger spiritual effect is protecting or altering the target’s reflection and whether its Source CL is lower than, equal to, or higher than yours.

This procedure does not force confession or reveal the protected fact itself.

### CL6 — Inverted Glance

You catch hostile intention in the attacker’s reflected motion and turn that discrepancy against it.

**Reaction**  
**Trigger:** A creature you can perceive targets you or an ally within 30 feet with an attack, or forces you or that ally to make an Intelligence, Wisdom, or Charisma saving throw  
**Cost:** 2 Resonance  
**Requirement:** The triggering creature or protected creature has a valid reflection you can perceive

Choose the triggering creature. It makes a Wisdom saving throw.

**Failed Save:** Choose one result:

- The triggering attack is made with Disadvantage.
- The protected creature makes the triggering saving throw with Advantage.
- If the triggering effect would charm, frighten, possess, deceive, alter memory, or change identity, the protected creature also gains Temporary Hit Points equal to `Wisdom modifier + Proficiency Bonus` after the roll resolves.

The triggering creature then takes `2d8 + Wisdom modifier` Psychic damage if it bears your Reflection Trace.

**Successful Save:** The protected creature gains `+2` to AC against the triggering attack or `+2` to the triggering saving throw. Apply this bonus after seeing the roll but before the outcome is finalized.

#### Reflected Consequence

If Inverted Glance causes the triggering attack to miss or the saving throw to succeed, you may spend 1 additional Resonance to place a Reflection Trace on the triggering creature. If it already bears your trace, choose one ordinary Spiritual Pressure effect for it until the start of its next turn.

Inverted Glance can affect one triggering attack or saving throw only once. A reflected reroll, reaction, or correction cannot recursively trigger another Inverted Glance from you on the same roll.

### CL10 — Borrowed Reflection

You can draw a temporary second self out of a reflective surface.

**Bonus Action**  
**Range:** 30 feet  
**Cost:** 4 Resonance  
**Duration:** 1 minute  
**Requirement:** A valid reflection within range

Create one **Reflection Double** in an unoccupied space adjacent to the chosen surface. You can maintain only one Reflection Double at a time.

The Reflection Double is a Medium Cultivation Asset:

- **AC:** your Cultivation Save DC
- **Hit Points:** `4 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Immunities:** Poisoned, Disease, ordinary suffocation
- **Resistances:** Psychic damage
- **Speed:** 30 feet; it cannot move more than 60 feet from you or a valid reflection
- **Source CL:** your effective Spirit Awakening CL

It has no independent turn, cannot flank, hold items, make weapon attacks, provide Help, maintain Concentration, or use your Subpath features independently.

On your turn, it can move up to its Speed when you move or as part of a Bonus Action you use to direct it.

While it exists:

- You may originate Mind Spike, Soul Gaze, a Resonance Mark, or another single-target Spirit Awakening technique from your space or the Double’s space.
- Range and line of effect are measured from the chosen origin.
- You still pay all costs and use your own action economy.
- A technique cannot originate from both spaces unless it expressly creates multiple origins.
- The Double has a valid reflection of every creature it can perceive.

#### Exchange With the Image

Once on each of your turns, when you use a Spirit Awakening technique from the Double’s space, you may spend 1 Resonance to exchange spaces with it immediately before or after the technique resolves. This movement is teleportation and fails across an effect that blocks teleportation or reflected passage.

#### Break the Double

When the Double is reduced to 0 Hit Points, every creature within 5 feet of it makes a Wisdom saving throw.

**Failed Save:** The creature takes `2d8` Psychic damage and cannot take Reactions until the start of its next turn.

**Successful Save:** It takes half damage.

You may dismiss the Double without this burst.

### CL14 — Mirror Confession

You force the reflected self to answer when the presented self refuses.

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance  
**Requirement:** The target bears your Reflection Trace or can perceive a valid reflection of itself

The target makes a Charisma saving throw.

**Failed Save:** Choose one confession procedure:

#### Emotional Confession

Ask one short question concerning fear, guilt, desire, loyalty, grief, hatred, or the target’s current intention. The target must answer with emotional honesty in one or two sentences. It need not reveal complete factual detail, protected names, sealed memories, or information it does not know.

You also learn whether the answer is being distorted by possession, compulsion, memory alteration, divided identity, or a stronger Source Rule.

#### Reflected Exposure

Choose one disguise, illusion, possession expression, counterfeit identity, emotional concealment, or transformation currently altering how the target presents itself.

- An ordinary lower-Source-CL expression ends.
- A Restricted or equal-Source-CL expression is suppressed until the end of the target’s next turn. The target repeats the save at the end of each turn, ending suppression on a success.
- A higher, Rare, Forbidden, Secret, divine, artifact, bloodline-defining, Foundation, Method, or identity-defining expression is not erased. On a successful Cultivation Check, one printed benefit is suppressed until the end of your next turn.

#### Confession Crack

The target gains a **Confession Crack** until it succeeds on two Charisma saving throws at the end of its turns, completes one of the Confession Crack recovery procedures in the Normalized Execution Notes.

While cracked:

- it cannot benefit from ordinary spiritual disguise against you;
- it has Disadvantage on the first Charisma saving throw it makes against you each round;
- the first time each round it knowingly speaks a direct lie while you can hear it, it takes Psychic damage equal to `2 × Proficiency Bonus`.

**Successful Save:** You learn whether the target is hiding fear, guilt, desire, loyalty, grief, hatred, or a current hostile intention. It does not gain a Confession Crack.

A creature can suffer only one active Confession Crack from you. Mirror Confession does not compel obedience, establish guilt, or create a legal oath.

### CL18 — World Behind the Glass

You unfold the spiritual territory that every reflection implies.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene  
**Requirement:** At least one valid reflection within 60 feet

Create a 30-foot-radius **Mirror Domain** centered on you, your Reflection Double, or a reflective surface within 60 feet. The center remains fixed unless it is your Double; if centered on the Double, the field moves with it.

The Domain is visibly transformed by silver water, reversed shadows, glass pathways, doubled voices, and reflections that move before their subjects.

While it persists:

- Every creature and object in the Domain has a valid reflection for your features.
- You may originate Spirit Awakening techniques from any unbroken reflective surface in the Domain.
- Once per round when a traced hostile creature attacks you or an ally in the Domain, you may impose Disadvantage without spending your Reaction. Resolve this before the roll.
- A traced enemy cannot become Hidden from you through ordinary darkness, invisibility, smoke, disguise, or mundane cover that leaves any reflection exposed.
- When a traced creature fails an Intelligence, Wisdom, or Charisma saving throw against you, you may move it up to 10 feet to an unoccupied reflected space it could physically occupy. This is forced spiritual displacement, not teleportation.

The Domain requires Concentration. If every reflective surface in it is destroyed, completely obscured, or suppressed, the Domain ends.

#### Reflection Cell

Once during the activation, when a traced creature in the Domain fails a Wisdom or Charisma saving throw against one of your Spirit Awakening features, you may spend 6 Resonance to draw it into a **Reflection Cell**.

The target disappears into a mirrored copy of the Domain until the end of its next turn. While inside:

- it is Incapacitated and has total cover from creatures outside the Cell;
- it can perceive distorted reflections of the real Domain;
- at the end of its turn, it repeats the Charisma saving throw;
- on a success, it returns to its former space or the nearest unoccupied space;
- on a failure, it remains until the end of its following turn, then returns automatically unless a stronger Source Rule extends the imprisonment.

An ordinary creature whose Source CL is at least 5 lower than yours can remain imprisoned for the scene after two failed saves if the Mirror Domain’s center becomes a destructible **Mirror Gate Anchor**:

- **AC:** your Cultivation Save DC
- **Hit Points:** `8 × Proficiency Bonus`
- **Resistances:** Psychic damage
- **Source CL:** your effective Spirit Awakening CL

Destroying or suppressing the Anchor immediately releases every imprisoned creature.

Equal- or higher-Source-CL targets, major enemies, Secret Law practitioners, divine beings, artifact-bound creatures, and creatures protected by explicit anti-banishment authority cannot be imprisoned for the scene through this feature alone. They use the repeated-save procedure.

World Behind the Glass does not create a permanent plane, duplicate souls, or replace true mirror, space, imprisonment, or conceptual authority from another Source Rule.

---

### Normalized Execution Notes

#### Reflection Correspondence Record
A reflection used by this tradition must record four facts at the moment it is selected:

1. **surface:** the mirror, water, metal, ice, glass, lacquer, treasure, or other reflective medium;
2. **subject:** the creature, object, place, or event currently represented;
3. **clarity:** whether the image shows enough of the subject to distinguish it from another subject of the same broad kind;
4. **continuity:** whether the surface is currently unbroken, unobscured, and within the feature's permitted line of perception.

A reflection remains valid while those facts remain true. A thumb-sized surface can support a reflection only if it actually shows the relevant subject clearly enough for the feature being used. A painted image, portrait, memory, illusionary image, copied recording, or image of an absent subject is not a valid reflection unless a Source Rule expressly gives it present spiritual correspondence.

When a concealment effect removes or counterfeits a reflection, compare Source CL. Lower authority yields. At equal Source CL, make a Cultivation Check against the concealment effect. On a failure, you identify that the correspondence is blocked or false, but do not gain the protected information.

#### Reflection Trace Removal
A creature removing a Reflection Trace uses an Action and chooses one legal procedure:

- **Obscure:** cover, muddy, shatter, darken, or otherwise invalidate every reflection of itself that it can perceive within 30 feet, then succeed on the printed Charisma save;
- **Repudiate:** directly face a valid reflection, state one current truth about its identity or intention, and succeed on the printed Charisma save;
- **Cleanse:** use Spiritual Exorcism, a Mirrors, Illusion, Spirit, identity, or curse-cleansing Source Rule, or an equal-or-higher-Source-CL effect that expressly removes spiritual marks.

Failure leaves the Trace in place. Breaking one surface does not remove the Trace while another valid reflection of the creature remains within the procedure's area.

#### Confession Crack Recovery
A Confession Crack ends through the two printed end-of-turn saves or one of these exact procedures:

- complete a Full Cultivation Session devoted to identity stabilization, confession, reconciliation, or memory repair;
- truthfully disclose the specific emotional category exposed by Mirror Confession to one willing creature materially involved in that category;
- complete a legal Spiritual Exorcism or equal-authority identity-cleansing procedure;
- destroy or lawfully end the external possession, disguise, counterfeit identity, or memory effect that created the contradiction.

The procedure removes the Crack, not an unrelated curse, possession, crime, oath, or social consequence. A GM or AI cannot require an additional unprinted confession after one listed procedure succeeds.

#### Reflection Double Record
When Borrowed Reflection creates a Double, record its originating surface, current space, maximum tether, Hit Points, Source CL, and whether it is externalized or suppressed. It is a **Manifested Spirit Cultivation Asset**.

- It uses your relevant Intelligence, Wisdom, and Charisma saving throw modifiers; it gains no general saving throw proficiency.
- It can receive repair or healing only from a feature that affects Cultivation Assets, manifestations, or spirits.
- It cannot become a Host, full Companion, second Concentration bearer, or second turn.
- If its originating surface is destroyed, the Double remains only if another valid reflection is within 60 feet; otherwise it ends at the conclusion of the current resolution.
- Exchange With the Image checks the destination immediately before movement. If either destination is illegal, the exchange fails and the 1 Resonance is not spent.

#### Mirror Confession Records
An Emotional Confession records the exact question and one of the printed emotional categories. The answer must be emotionally honest according to the target's current belief; it does not compel factual accuracy where the target is mistaken.

Reflected Exposure records the exact expression being targeted and one printed benefit being suppressed. It cannot suppress an entire Path, Foundation, Method, bloodline, identity, or Complete Soul by naming a broad category.

#### Reflection Cell
Reflection Cell is temporary spiritual imprisonment. The Cell contains only the target, the distorted visual copy needed by the feature, and no harvestable objects or duplicate Assets. The target cannot target outside the Cell, and outside creatures cannot target it unless a Source Rule expressly crosses reflected imprisonment.

If the target's former space is illegal when it returns, place it in the nearest legal unoccupied space in the Domain, chosen by the target on a tie. A Mirror Gate Anchor is an Anchor and Cultivation Asset; it takes no turn and cannot be healed except by Asset-compatible repair.

#### Soul Splitting Expression — Reverse Witness
Your Soul Fragment carries a narrow reflected plane. Once per round, when a creature within 30 feet of the fragment becomes Resonance Marked by you or fails a save against one of your Spirit Awakening features, the fragment may show that creature's current valid reflection until the start of your next turn. During that interval, the fragment can satisfy the reflection requirement for one Reflection Diagnosis, Inverted Glance, or Mirror Confession that you activate and pay for normally. It does not provide line of effect through total cover, create a Reflection Double, impose a Trace independently, or activate Reflection Cell.

#### Realm Suppression
Reflection Traces, Confession Cracks, and existing Cell records are not erased by Realm Suppression. Features above your effective CL become unavailable. A Reflection Double or Mirror Domain ends if suppression removes the feature that sustains it. A temporarily imprisoned creature returns immediately if the Domain or required Anchor ends.

### Integrated Procedure Closure — Mirror Speaker

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Reverse Witness. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 22. Mushroom Dreamwalker

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Rare dream contact, mycelial spirit pact, forbidden grove, underworld spore inheritance, sleeping-forest initiation, or apprenticeship beneath a fungal ancestor.  
**Identity:** Shared dreams, spores, decay, hallucination, fungal memory, and the quiet intelligence beneath roots.  
**Primary role:** Network support, area control, dream communication, environmental investigation, attrition, and regenerative field play.  
**Sphere Lean:** Dreams, Plant, Poison, Earth, Spirit. This tradition grants none of those Spheres.  
**Cultivation boundary:** Mushroom Dreamwalkers cultivate spiritual mycelium, not ordinary infectious disease. Their dream-spores can affect minds, spirits, corpses, soil, and supernatural ecologies as printed. They do not automatically poison creatures immune to poison, read every memory in the earth, command all fungi, or create unrestricted telepathy.

> *Rot is memory learning how to speak softly.*

Mushroom Dreamwalkers know that a forest’s most important conversations occur beneath the visible world. Their traditions link sleeping minds, decomposing bodies, buried grief, old roots, and fungal spirits into networks through which sensation, memory, and dream pass like rain through soil.

### Dream-Spore Marks

Several features place **Dream-Spore Marks**.

- A Dream-Spore Mark is a special Resonance Mark and counts as your Resonance Mark.
- It appears to spiritual perception as pale gills, drifting motes, luminous hyphae, root-veins, or dream-colored mold.
- It lasts for the scene unless consumed or cleansed.
- A creature can bear up to three Dream-Spore Marks from you.
- You can place no more than one Dream-Spore Mark on the same creature per turn unless a feature expressly says otherwise.
- A creature immune to poison can still bear a Dream-Spore Mark unless it is mindless and spiritually inert.
- Fire, purification, Medicine, a suitable Sphere effect, or an equal- or higher-Source-CL cleansing procedure can remove one mark with an Action and a successful check against your Cultivation Save DC.

A marked creature is not automatically poisoned, diseased, asleep, charmed, or controlled.

### Mycelial Nodes

At the end of a 1-minute rite, you may plant one **Mycelial Node** in soil, old wood, fungus, a corpse, compost, a dream-soaked object, or another organic medium meeting the Node Medium rules in the Normalized Execution Notes. Creating a Node without suitable material costs 1 Resonance.

You can maintain a number of Nodes equal to your Proficiency Bonus. A Node lasts until destroyed, replaced, or you remain more than 1 mile from it for 24 hours.

A Mycelial Node is a Tiny Cultivation Asset:

- **AC:** `12 + Proficiency Bonus`
- **Hit Points:** `4 × Proficiency Bonus`
- **Immunities:** Poisoned, Disease
- **Vulnerability:** Fire damage
- **Source CL:** your effective Spirit Awakening CL

Nodes do not act, attack, move, flank, or provide independent senses. They are legal origins only for features that expressly name them.

### CL3 — Mycelial Dream

You can join minds through a hidden root-dream.

#### Shared Root-Dream

During a rest, 10-minute meditation, or prepared sleep rite, choose willing sleeping, meditating, or trance-capable creatures within 30 feet of you or one of your Mycelial Nodes. You may include a number of creatures equal to twice your Proficiency Bonus.

For the duration of the rest or rite:

- participants communicate through images, sensations, remembered places, and spoken dream-language;
- each participant may share one memory, omen, route, emotional impression, or symbolic question;
- each participant gains Advantage on one check made before the next long rest to remember, interpret, navigate by, or emotionally understand something genuinely shared in the Root-Dream;
- a participant may refuse any memory or image and may leave the dream at any time by waking or ending meditation.

You may attempt to touch one sleeping unwilling creature within 30 feet of you or a Node by spending 1 Resonance. It makes a Wisdom saving throw.

**Failed Save:** It enters the edge of the shared dream until it wakes or the rite ends. You can communicate and place one Dream-Spore Mark on it, but cannot force it to reveal memories.

**Successful Save:** It wakes, knows that a dream presence touched it, and cannot be targeted by your Shared Root-Dream again during the same rest.

#### Spore Touch

**Bonus Action**  
**Range:** 30 feet from you or a Mycelial Node  
**Cost:** 1 Resonance

Choose one creature you can perceive. It makes a Constitution saving throw. A willing creature may fail automatically.

**Failed Save:** Place one Dream-Spore Mark on it and learn whether it is sleeping, poisoned, frightened, charmed, dream-haunted, grief-strained, possessed, or spiritually contaminated.

**Successful Save:** It is not marked, but you learn whether it is immune or resistant to Poison or Psychic damage and whether it is protected by higher spiritual authority.

### CL6 — Spore Murmur

Your spores speak directly to the target’s nerves, dreams, and soul.

**Action**  
**Range:** 60 feet from you or a Mycelial Node  
**Cost:** 3 Resonance

Choose one creature. It makes a Constitution saving throw.

**Failed Save:** It takes `4d8 + Wisdom modifier` Poison or Psychic damage, your choice, gains one Dream-Spore Mark, and suffers one of the following Murmurs until the start of your next turn:

- **Heavy Cap:** Its Speed is reduced by 15 feet.
- **Whispering Gills:** It cannot take Reactions.
- **False Forest:** It has Disadvantage on the next attack roll it makes.
- **Drowsing Root:** It has Disadvantage on the next Wisdom saving throw it makes against one of your Spirit Awakening features.

**Successful Save:** It takes half damage and gains no mark or Murmur.

A mindless creature can take Poison damage but is immune to False Forest and Drowsing Root. A creature immune to poison can be affected normally by the Psychic option if it has a mind or spirit.

#### Hyphal Spread

If the target already bears two or more Dream-Spore Marks when it fails, choose one creature within 10 feet of it. That creature makes a Constitution saving throw.

**Failed Save:** It gains one Dream-Spore Mark and takes Psychic damage equal to `2 × Proficiency Bonus`.

**Successful Save:** It is unaffected.

Hyphal Spread cannot bounce, chain, or trigger itself.

### CL10 — Under-Root Memory

You can consult the network of decay, roots, corpse-soil, and dream residue beneath a place.

**Ritual Action:** 10 minutes  
**Cost:** 4 Resonance  
**Requirement:** Touch fungus, roots, corpse-soil, old wood, compost, grave earth, or a Mycelial Node connected to the area

Ask up to three questions concerning creatures, deaths, strong emotions, dreams, poisons, burials, spiritual disturbances, or significant passages through the area during the previous seven days.

The answers arrive as sensory and symbolic impressions:

- taste, smell, pressure, temperature, direction, rhythm, color, emotion, dream image, or decay pattern;
- the broad number and nature of significant creatures;
- whether death, violence, fear, grief, poison, possession, dream influence, or spiritual contamination occurred;
- a remembered direction or route through connected organic terrain.

Under-Root Memory does not provide exact dialogue, hidden statistics, secure names, complete chronology, or knowledge that left no meaningful organic, spiritual, or dream residue.

Sterile metal, purified stone, burned earth, divine wards, Secret concealment, spatial severance, or a stronger anti-divination Source Rule can block or distort the network. On a failed Cultivation Check against such concealment, you learn that the memory was deliberately interrupted and one broad category of interruption.

#### Rootline Passage

After completing Under-Root Memory, choose two of your Mycelial Nodes within 1 mile that are connected through continuous soil, root, fungal growth, grave earth, or dream-soaked organic terrain. Until the end of the scene, you may use a Bonus Action and spend 2 Resonance to dissolve into spores at one Node and emerge adjacent to the other.

- You may carry worn and held equipment.
- You cannot carry another creature unless it is willing, your size or smaller, and you spend 1 additional Resonance.
- An effect blocking teleportation, route travel, dream passage, or the intervening spiritual ecology can prevent the passage.
- Destroying either Node ends that route.

### CL14 — Hallucinogenic Bloom

You cause the hidden dream-network to fruit across the battlefield.

**Action**  
**Range:** 60 feet from you or a Mycelial Node  
**Cost:** 6 Resonance  
**Duration:** 1 minute  
**Area:** 20-foot-radius sphere  
**Concentration:** Required

The area fills with luminous spores, impossible mushrooms, false roots, remembered voices, and damp dream-light. It is lightly obscured to hostile creatures and difficult terrain for them.

When a hostile creature enters the Bloom for the first time on a turn or starts its turn there, it makes a Wisdom saving throw.

**Failed Save:** Choose one Bloom effect until the start of its next turn:

- **Lost Trail:** It cannot take Reactions and cannot willingly move closer to a creature you designate.
- **Borrowed Forest:** The first attack it makes targets a reflected or fungal afterimage. The attack is made with Disadvantage; on a miss, it cannot redirect that attack.
- **Sleep Beneath the Roots:** Its Speed becomes 0. If it is Bloodied, already bears three Dream-Spore Marks, or its Source CL is at least 5 lower than yours, it is also Incapacitated until the start of its next turn. Damage ends the Incapacitated state.
- **Spore Communion:** It becomes spiritually audible to you and cannot conceal its surface emotional state, current hostile intention, or direction within the Bloom.

**Successful Save:** It ignores the Bloom’s saving throw effects until the start of its next turn but still treats the area as difficult terrain.

A creature bearing three Dream-Spore Marks makes its first save against the Bloom with Disadvantage. When such a creature fails, you may consume one mark to place one Dream-Spore Mark on another creature within 10 feet of it.

#### Blooming Node

When you create the Bloom, you may transform one Mycelial Node in the area into a **Blooming Node Anchor** for the duration:

- **AC:** your Cultivation Save DC
- **Hit Points:** `6 × Proficiency Bonus`
- **Vulnerability:** Fire damage
- **Source CL:** your effective Spirit Awakening CL

While the Anchor remains, the Bloom does not require Concentration. Destroying or suppressing the Anchor ends the Bloom.

### CL18 — Fruiting Body of the Dream

Your soul blooms as the visible fruiting body of a vast hidden dream-network.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene

Choose yourself or one Mycelial Node within 60 feet as the **Fruiting Heart**. A 30-foot-radius Spirit Awakening field surrounds it and moves with it if centered on you.

While the field persists:

- You have Blindsight 60 feet against sleeping, poisoned, frightened, charmed, hallucinating, possessed, spiritually contaminated, Resonance Marked, or Dream-Spore-marked creatures.
- You may use Spore Touch once on each of your turns without spending Resonance.
- Once per turn when a hostile creature in the field fails a saving throw against one of your Spirit Awakening features, choose one ally in the field. It regains Hit Points equal to `Proficiency Bonus + Wisdom modifier`, or ends one ordinary Frightened, Charmed, Poisoned, dream-haunted, or grief-based effect.
- A creature cannot trigger this restoration if it is harmless, allied, willing, summoned principally for resource generation, or repeatedly subjected to a self-created loop.
- Allies who begin a rest in the field may enter a Shared Root-Dream even while awake, meditating, or keeping watch.

#### Fruiting Body Asset

If centered on a Mycelial Node, the Node becomes a Large **Fruiting Body** Cultivation Asset:

- **AC:** your Cultivation Save DC
- **Hit Points:** `10 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic, Poison, and Necrotic damage
- **Vulnerability:** Fire damage
- **Source CL:** your effective Spirit Awakening CL

It cannot move, attack, act, or maintain Concentration. You may originate Spirit Awakening techniques from it.

#### Dream-Corpse Fruiting

Once during the activation, when a hostile creature bearing three Dream-Spore Marks is reduced to 0 Hit Points in the field or fails a death saving throw there, you may spend 6 Resonance to create one of the following results:

- **Merciful Fruiting:** Consume its marks. The creature becomes stable, falls into supernatural sleep for 1 hour, and cannot be possessed or have its soul removed by ordinary lower-Source-CL effects during that sleep.
- **Memory Fruiting:** Consume its marks. Create a Tiny **Memory Mushroom** containing one sensory memory, route impression, emotional truth, or answer the creature actually possessed. A willing creature may reveal the memory. An unwilling creature makes a Charisma saving throw; on a failure, the mushroom contains one broad memory category you specify. Protected memories require a Cultivation Check and may remain incomplete.
- **Grave Fruiting:** If the creature is dead and its soul is no longer present or cannot be lawfully contacted, the body becomes a Mycelial Node without additional cost. This does not animate, imprison, duplicate, or consume the soul.

Secret, divine, artifact, reincarnation, true-name, or identity-sealed memories cannot be harvested automatically. Fruiting Body of the Dream creates a spiritual ecology, not unrestricted mind reading, resurrection, or soul consumption.

---

### Normalized Execution Notes

#### Dream-Spore Cleansing
Removing one Dream-Spore Mark requires an Action and one of these procedures:

- deal Fire damage to the marked creature or object and succeed on a Medicine or Cultivation Check against your Cultivation Save DC; the acting creature chooses whether the cleansing fire deals its normal damage;
- use a printed purification, poison-cleansing, dream-cleansing, Medicine, Plant, Fire, Spirit, or exorcism feature and succeed on its normal check or the fallback check against your Cultivation Save DC;
- complete 10 minutes of washing, controlled heat, antifungal medicine, incense, or meditation outside the current scene and succeed on a Constitution (Medicine), Wisdom (Medicine), or Cultivation Check against your Cultivation Save DC.

One successful procedure removes one Mark unless its Source Rule says otherwise. Poison immunity does not remove a Mark automatically because the Mark is spiritual mycelium rather than ordinary poison.

#### Node Medium
A legal Node medium must be one continuous object, corpse, soil patch, root network, fungal growth, compost bed, dream-soaked organic object, or other organic mass large enough to contain a Tiny Asset. Record its medium, space, Source CL, and whether it is living, dead, corpse-derived, or dream-derived.

A corpse used as medium is not animated, possessed, or deprived of its soul. Destroying the physical medium destroys the Node unless another feature has transformed it into a separate Anchor. A Node cannot be planted inside an unwilling living creature through this rite.

#### Root-Dream Participation
Each participant's shared contribution is voluntary and limited to one memory, omen, route, emotional impression, or symbolic question. Record the category, not private details withheld by that participant. The Advantage applies to one check genuinely using that contribution and expires at the next long rest; it cannot be transferred to an unrelated check by vague symbolic similarity.

An unwilling sleeper entering the edge of the dream can hear and respond but cannot be made to disclose memories, accept a Bond, receive a permanent mark, or surrender consent beyond the single Dream-Spore Mark expressly printed.

#### Under-Root Residue Record
For each Under-Root Memory question, record:

- the seven-day time window;
- the connected organic medium being consulted;
- the requested category;
- the strongest qualifying residue;
- whether the answer is direct, symbolic, blocked, or distorted;
- any opposing Source CL.

A **significant creature** for this feature is a creature that materially altered the area, left blood or bodily residue, died, slept, cultivated, carried a strong spirit effect, or remained for at least 10 minutes. A fleeting ordinary passerby that left no residue is not significant.

When concealment blocks the network, the broad interruption category is one of: burned or sterilized, physically severed, spiritually purified, spatially removed, dream-silenced, memory-altered, or protected by higher authority. The GM or AI selects the category actually created by the opposing Source Rule; it does not invent a false event.

#### Rootline Route Record
A Rootline Passage records both Nodes, the connected medium, maximum distance, passengers, and the Source CL of any route seal. Continuous connection means a physically or spiritually connected route of soil, roots, fungal growth, grave earth, or dream-soaked organic matter between the Nodes. A gap wider than 10 feet breaks ordinary continuity unless a printed effect bridges it.

The destination space must be legal. If the destination becomes illegal or either Node is destroyed before resolution, the passage fails and no passenger moves; Resonance spent on that attempted passage remains spent only if the movement had begun.

#### Memory Mushroom
A Memory Mushroom is a Tiny Spirit Cultivation Asset:

- **AC:** `12 + Proficiency Bonus`;
- **Hit Points:** `2 × Proficiency Bonus`;
- **Immunities:** Poisoned, Disease, ordinary suffocation;
- **Vulnerability:** Fire damage;
- **Source CL:** your effective Spirit Awakening CL;
- **Duration:** until read, destroyed, or the end of the next Full Cultivation Session.

It stores exactly one printed sensory memory, route impression, emotional truth, or answer. Reading it takes 1 minute of touch or dream contact. It cannot store complete identity, a true name, a full technique, an unspent resource, or a memory the source did not possess. When read, the reader receives the stored impression and the Mushroom becomes ordinary inert fungus.

#### Soul Splitting Expression — Hyphal Dreamlet
Your Soul Fragment counts as a temporary Mycelial Node only for determining the origin of Spore Touch or Spore Murmur. Once per round when you place a Dream-Spore Mark on a creature within 30 feet of the fragment, the fragment may reveal whether that creature is connected to one of your Nodes, Dream-Spore-marked allies, or active dream Fields. It cannot plant Nodes, create Rootline Passage, maintain Hallucinogenic Bloom, trigger Dream-Corpse Fruiting, or supply an additional turn.

#### Fruiting Body and Death
Dream-Corpse Fruiting resolves only after the creature is legally at 0 Hit Points or dead under the campaign's death procedure. Merciful Fruiting stabilizes but does not heal. Grave Fruiting requires the soul to be absent, departed, inaccessible, or lawfully beyond contact; it cannot be used to declare an uncertain soul absent without diagnosis.

#### Realm Suppression
Existing Marks and Nodes remain but become dormant if their creating feature is above your effective CL. Dormant Nodes cannot serve as origins or routes. A Bloom or Fruiting Body ends if its sustaining feature becomes unavailable.

### Integrated Procedure Closure — Mushroom Dreamwalker

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Hyphal Dreamlet. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 23. Echo Scribe

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted archive tradition, haunted library, memory-ink inheritance, imperial record office, or pact with a record-spirit.  
**Identity:** Recorded echoes, written souls, names, testimony, and corrections made in the margins of lived events.  
**Primary role:** Investigation, anti-deception, reactive disruption, event recording, spiritual tagging, and bounded consequence revision.  
**Sphere Lean:** Sound, Knowledge, Spirit, Fate. This tradition grants none of those Spheres.  
**Cultivation boundary:** Echo Scribes record what meaningfully occurred and edit only what their Source Rules authorize. A record does not become true because it is written, a nickname is not automatically a true name, and a marginal correction cannot retroactively invent actions, knowledge, resources, or consent.

> *If it mattered, it left handwriting on the world.*

Echo Scribes cultivate memory as evidence. They can hear the residue in a broken sword, write the shape of a lie, annotate a possession, and preserve the exact instant a soul began to fail. Their power is feared because the written soul can become more difficult to deny than the living speaker.

### Echo Entries

You maintain a spiritual record called an **Echo Ledger**. It can be a book, tablet, scroll, tattoo, memory palace, floating script, ancestral archive, or another suitable focus.

You can maintain a number of **Echo Entries** equal to twice your Proficiency Bonus. Each Entry records one of the following:

- a sensory echo recovered by Ink Remembers;
- a creature’s name, title, or descriptive epithet recorded by Name on the Page;
- a significant roll or event explicitly recorded by another Echo Scribe feature;
- a witnessed lie, command phrase, possession sign, oath statement, death, spiritual wound, or meaningful emotional declaration.

An Entry lasts until you erase it, replace it, its source is reconstructed beyond recognition, or a stronger Source Rule destroys or rewrites it.

An Entry is evidence, not omniscience. It contains only the fact, impression, or event actually recorded.

If your physical ledger is destroyed, your Entries remain in your awakened memory, but you cannot create new written Anchors or use Chronicle of the Living Soul until you spend 10 minutes and 2 Resonance reconstructing a ledger focus.

### CL3 — Ink Remembers

You can recover the strongest recent echo left on a meaningful object or mark.

**Action**  
**Range:** Touch  
**Cost:** 1 Resonance

Touch a written document, carved inscription, blood mark, footprint, broken weapon, garment, corpse, shrine object, damaged treasure, or another object meaningfully involved in an event.

You receive one sensory echo connected to its strongest recent use or emotion. Choose one category:

- sight or visual arrangement;
- sound or spoken emotional tone;
- touch, force, injury, or direction of movement;
- fear, grief, loyalty, anger, desire, or intent;
- spiritual pressure, possession, curse, dream influence, death, or another supernatural disturbance.

The echo usually concerns the most significant event within the previous seven days. Older echoes may remain on treasured, blood-soaked, haunted, consecrated, artifact, or story-significant objects.

You may record the echo as an Echo Entry.

Ink Remembers does not provide complete history, exact statistics, secret mechanics, secure identity, or facts the object did not meaningfully witness. Cleansing, forgery, counter-inscription, stronger concealment, or destruction can distort the echo. A successful Cultivation Check against that Source Rule reveals one true fragment and the fact that the record was altered.

#### Record the Disturbance

When you place a Resonance Mark on a creature, you may also record one immediately observable spiritual category as an Echo Entry: Charmed, Frightened, possessed, dream-haunted, grief-strained, oath-bound, transformed, disguised, dying, or spiritually contaminated.

This does not reveal the source unless you identify it through another procedure.

### CL6 — Written Rebuke

You write against a hostile word before its echo settles into reality.

**Reaction**  
**Trigger:** A Resonance Marked creature within 60 feet knowingly speaks a direct lie, uses a verbal or spiritual command, activates an audible or named technique, or targets you or an ally with a mental, emotional, memory, dream, or possession effect  
**Cost:** 3 Resonance

The triggering creature makes a Charisma saving throw.

**Failed Save:** It takes `4d8 + Wisdom modifier` Psychic damage. Choose one Rebuke:

- **Strike the Phrase:** The triggering attack roll is made with Disadvantage or the triggering effect’s first target makes its saving throw with Advantage.
- **Break the Command:** If the effect requires the target to hear, understand, obey, recognize a name, or receive a spiritual command, its effect is suppressed until the start of the triggering creature’s next turn.
- **Record the Lie:** Create an Echo Entry containing the exact direct lie or false command. Until the end of the scene, the creature has Disadvantage on the first Charisma saving throw it makes against you when that Entry is relevant.

**Successful Save:** It takes half damage. You may still create an Echo Entry recording the triggering phrase or effect category.

Written Rebuke does not automatically counter silent techniques, purely physical attacks, accidental falsehoods, mistaken beliefs, or speech protected by superior true-name, divine, Secret, or artifact authority. Against such effects, a Cultivation Check may be required to apply Strike the Phrase or Break the Command.

### CL10 — Name on the Page

You write a creature into your ledger strongly enough that ordinary concealment can no longer make it spiritually anonymous to you.

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance  
**Duration:** The scene

Write, trace, sign, or speak one of the following concerning a creature you can perceive:

- its chosen name;
- a title it meaningfully bears;
- a kinship or office it recognizes;
- a descriptive epithet that is currently and demonstrably true, such as “the wounded gatekeeper,” “the spirit within the magistrate,” or “the killer holding the red spear.”

The target makes a Charisma saving throw.

**Failed Save:** It becomes Resonance Marked for the scene, and you create a **Name Entry**. While the Entry remains:

- ordinary invisibility, disguise, mimicry, voice alteration, illusion, and crowd concealment cannot hide the fact that the recorded subject is present within 120 feet;
- you know when the recorded subject knowingly acts in direct contradiction to the recorded name, title, office, or epithet;
- the first time each round it contradicts that recorded identity while within 60 feet, it takes Psychic damage equal to `2 × Proficiency Bonus` or suffers one ordinary Spiritual Pressure effect, your choice.

**Successful Save:** It is Resonance Marked until the end of your next turn, and the Name Entry records only the subject’s current appearance and spiritual pressure category.

#### Correcting the Name

A creature can spend an Action to challenge an inaccurate or obsolete Name Entry. If the title, office, epithet, or relationship is no longer true, the Entry ends automatically. If contested, the creature makes a Charisma saving throw against your Cultivation Save DC. On a success, the Entry is reduced to an ordinary Echo Entry and loses its mechanical effects.

A chosen name or title is not a true name unless another Source Rule expressly says so. Name on the Page cannot seize ownership, compel obedience, or permanently rewrite identity.

### CL14 — Marginal Correction

You revise a spiritual event while its ink is still wet.

**Reaction**  
**Trigger:** You or an ally within 60 feet fails an ability check or saving throw involving memory, knowledge, illusion, charm, fear, possession, dreams, identity, emotional deception, spiritual concealment, or an event represented by one of your relevant Echo Entries  
**Cost:** 6 Resonance

Choose one Correction:

#### Reroute the Line

The target rerolls the check or saving throw with Advantage and must use the new result.

If the reroll succeeds, you learn the triggering effect’s broad authority category: ordinary, Open, Restricted, Rare, Forbidden, Secret, divine, artifact, tribulation, Foundation, Method, bloodline, or universal cultivation authority.

#### Restore the Missing Word

If the failure resulted from ordinary memory loss, silence, confusion, illusion, emotional distortion, or a hidden but previously recorded fact, consume one relevant Echo Entry. The target instead treats the roll as a success, but only for the discrete question, perception, or immediate effect represented by that Entry.

This cannot restore an erased lifetime, return a destroyed soul fragment, create knowledge never recorded, or overrule higher authority without a Cultivation Check.

#### Annotate the Wound

If the failure would inflict possession, identity alteration, major memory loss, a Heart Demon escalation, or a lasting spiritual wound, create an **Annotation** on the target. The immediate failure still occurs, but one named expression is suppressed until the end of the target’s next turn, creating time for exorcism, escape, healing, or another intervention.

A creature can benefit from only one Marginal Correction on the same roll. Corrections cannot recursively correct one another.

### CL18 — Chronicle of the Living Soul

You open a living record in which the next moments become editable before they harden into history.

**Action**  
**Cost:** 10 Resonance  
**Duration:** The scene

Manifest a **Living Chronicle** containing pages, floating script, carved tablets, or remembered verses. Choose up to your Proficiency Bonus creatures you can perceive. Each becomes a **Recorded Soul** for the duration.

When a Recorded Soul experiences one of the following events, you may record it as a **Living Entry** without using an action:

- succeeds or fails an Intelligence, Wisdom, or Charisma saving throw;
- fails a death saving throw;
- is reduced to 0 Hit Points;
- becomes Charmed, Frightened, possessed, spiritually transformed, or identity-wounded;
- loses Concentration;
- has a Soul Anchor, Cultivation Asset, spiritual bond, or companion bond suppressed;
- willingly makes a defining vow, confession, sacrifice, or betrayal.

You can maintain a number of Living Entries equal to your Proficiency Bonus. Recording beyond the maximum erases the oldest Living Entry.

#### Rewrite the Margin

Once on each of your turns, you may spend 4 Resonance and consume one relevant Living Entry to rewrite the recorded event into one lesser result:

- erase one failed death saving throw;
- reduce damage that reduced the creature to 0 Hit Points by `2 × Spirit Awakening CL`, potentially leaving it above 0;
- suppress one Charmed, Frightened, possession, ordinary transformation, or identity-wound expression until the end of the creature’s next turn;
- restore Concentration if the creature has not begun another Concentration effect and the original effect’s duration has not expired;
- allow the creature to reroll the recorded Intelligence, Wisdom, or Charisma saving throw with Advantage;
- convert a recorded betrayal, confession, or vow into undeniable spiritual evidence without changing whether it occurred.

Against an ordinary lower-Source-CL effect, the rewrite applies as printed. Against equal or higher, Rare, Forbidden, Secret, divine, artifact, tribulation, Foundation, Method, bloodline, true-name, reincarnation, or campaign-scale authority, make a Cultivation Check. On failure, the Entry is not consumed, but the rewrite does not occur and you learn one required recovery or counterprocedure.

#### Chronicle Asset

You may externalize the Chronicle as a Medium Cultivation Asset in an adjacent space:

- **AC:** your Cultivation Save DC
- **Hit Points:** `8 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic damage
- **Source CL:** your effective Spirit Awakening CL

While externalized, you may originate Echo Scribe features from it. If destroyed, every unused Living Entry is lost and the activation ends. If kept internal, it cannot be targeted separately but every use of Rewrite the Margin costs 1 additional Resonance.

Chronicle of the Living Soul edits recent spiritual consequence, not settled history. It cannot undo an event after the scene meaningfully changes, resurrect someone whose death is no longer current, restore resources spent before the recorded event, duplicate consumed items, reverse a breakthrough, erase consent, or rewrite the campaign’s past.

---

### Normalized Execution Notes

#### Echo Ledger Record
Each Echo Entry records:

- entry ID and category;
- subject or originating object;
- exact witnessed fact, phrase, sensation, state, or event;
- time and location of recording;
- Source CL of the event and of any detected alteration;
- whether the Entry is direct, symbolic, partial, contested, or corrected;
- expiration or destruction condition, if any.

An Echo Entry is evidence of what the feature actually perceived. It does not establish legal guilt, metaphysical truth, or true-name authority by itself. Two contradictory Entries remain contradictory until investigated; the later Entry does not automatically overwrite the earlier one.

#### Strongest Recent Echo
When more than one event qualifies for Ink Remembers, use this order:

1. event that created permanent or lasting spiritual alteration;
2. death, severe injury, possession, oath, or major emotional rupture;
3. event involving the object's destruction, creation, consecration, or primary use;
4. most recent event leaving blood, force, spiritual pressure, or deliberate inscription;
5. most recent ordinary significant handling.

The practitioner chooses the requested sensory category; the ordered list determines which event answers. A Cultivation Check can pierce a deliberate forgery or concealment, but cannot recover an event that left no meaningful echo.

#### Direct Lie and Contradiction
A **direct lie** is a declarative statement the speaker believes false and intends the listener to accept as true. Mistakes, metaphor, predictions, jokes identified as jokes, incomplete answers, silence, refusal, and changed beliefs are not direct lies.

A Name Entry is contradicted only when the creature knowingly performs an action incompatible with a recorded current office, oath, state, or demonstrably true epithet. Mere complexity, private doubt, or conduct outside the Entry's stated scope is not contradiction.

#### Authority Categories
The complete authority categories reported by this tradition are: ordinary, Open, Restricted, Rare, Forbidden, Secret, divine, artifact, tribulation, Foundation, Method, bloodline, true-name, reincarnation, universal cultivation authority, and unknown concealed authority. “Unknown concealed authority” is used only when the Source Rule defeats category identification; it does not permit the GM or AI to invent a new mechanical class.

#### Annotation Record
Annotate the Wound records one exact expression: the named possession impulse, memory deletion, identity replacement, Heart Demon escalation, spiritual wound effect, or transformation benefit that would apply. Suppression ends at the end of the target's next turn. It does not remove the underlying source, reverse already-applied damage, or suppress an entire creature, Path, Foundation, Method, or bloodline.

#### Event Settlement
For Chronicle of the Living Soul, an event is no longer current when any one of these occurs:

- the scene ends or its objective materially changes;
- a later dependent roll or action has resolved using that event as an established fact;
- the affected creature completes a rest or Full Cultivation Session;
- the consequence becomes permanent under its own Source Rule;
- more than 1 minute passes outside structured rounds.

After settlement, Chronicle cannot rewrite it. This does not shorten any printed Living Entry duration during the same active scene.

#### Required Counterprocedure
When a failed Cultivation Check reveals one required recovery or counterprocedure, report one procedure expressly named by the opposing Source Rule. If none is named, report one governing authority category and one of these universal approaches: destroy or suppress its Anchor, exceed its Source CL, complete its printed duration, obtain willing release, use Spiritual Exorcism, repair the affected soul or identity, or perform a relevant breakthrough-scale reconstruction. The response cannot invent a unique quest, price, or sacrifice.

#### Chronicle Externalization
Choose internal or external Chronicle when CL18 is activated. That choice remains fixed for the activation. The externalized Chronicle takes no independent turn and can be repaired only by Asset-compatible effects. If internal, it is not a separate target and the additional 1 Resonance cost applies to every Rewrite the Margin.

#### Soul Splitting Expression — Footnote Witness
Assign your Soul Fragment one existing Echo Entry when the fragment is created. The fragment can display and preserve that Entry even if your physical ledger is destroyed. Once per round when the recorded subject acts within 30 feet of the fragment, the fragment may reveal whether the action directly matches, contradicts, or is unrelated to the Entry. It may serve as the origin for Record the Disturbance when you legally place a Resonance Mark. It cannot create new Entries independently, use Written Rebuke, alter a Name Entry, activate Marginal Correction, or rewrite an event.

#### Realm Suppression
Entries and written evidence remain, but mechanical effects from features above effective CL become dormant. A Living Chronicle ends if CL18 becomes unavailable. Dormant Name Entries do not deal damage or impose Pressure but remain readable records.

### Integrated Procedure Closure — Echo Scribe

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Footnote Witness. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 24. Heartbinder

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted vow scripture, lover’s curse lineage, kinship-spirit pact, battlefield brotherhood, devotional cultivation inheritance, or apprenticeship beneath a guardian of chosen bonds.  
**Identity:** Chosen ties, loyalty, intimacy, courage, sacrifice, obsession, and the soul’s willingness to remain connected.  
**Primary role:** Bonded support, retaliation, emotional protection, damage sharing, emergency preservation, and relationship-centered field play.  
**Sphere Lean:** Mind, Spirit, Fate, Healing. This tradition grants none of those Spheres.  
**Cultivation boundary:** Heartbinders cultivate willing or authentically existing emotional bonds. They do not create contractual debt, legal obligation, karmic guilt, compelled love, permanent obedience, or ownership merely by placing a mark. A bond can become unhealthy, coercive, or obsessive in the story, but the tradition does not treat abuse as consent.

> *The heart is not soft. It is the strongest chain most people ever forge willingly.*

Heartbinders are protectors, lovers, comrades, kin-keepers, tragic guardians, and sometimes terrifying zealots. Their strength comes from chosen connection: the moment one soul says, “You will not face this alone,” and the world discovers that the statement has acquired weight.

### Vow Marks

You can maintain a number of **Vow Marks** equal to your Proficiency Bonus.

A Vow Mark requires a willing creature and a 1-minute rite involving one recorded consent form: spoken promise, exchanged token, shared breath, blood touch, handclasp, embrace, meal, prayer, or battle oath. Both participants must understand that the rite creates a Vow Mark and may refuse without penalty.

- The rite costs no Resonance outside immediate danger. During combat or a similarly pressured scene, it requires an Action and 2 Resonance.
- A Vow Mark lasts until either participant completes the Ending a Vow Mark procedure below, the relationship is Repudiated under the printed definition below, or a stronger Source Rule severs it.
- A creature can bear Vow Marks from more than one Heartbinder if it willingly accepts them.
- A Vow Mark is not a charm, contract, possession, command, true-name bond, or Soul Anchor unless another Source Rule says so.
- A coerced or counterfeit mark fails immediately when either participant discovers the coercion or counterfeit consent.

While a marked creature is within 1 mile, you know whether it is Bloodied, Charmed, Frightened, possessed, at 0 Hit Points, or suffering a major emotional or identity wound. You know the category, not the source, exact location, remaining Hit Points, thoughts, or statistics.

### Devotion

You can hold a number of **Devotion** points equal to your Proficiency Bonus. You begin each scene with 0 Devotion.

You gain 1 Devotion when one of the following occurs, no more than once per turn and only from meaningful danger:

- a Vow-Marked creature willingly takes damage, accepts a condition, or spends a resource to protect another marked creature;
- you use a Reaction or spend Resonance to protect a marked creature from a hostile source;
- a marked creature succeeds on a saving throw against fear, charm, possession, despair, or identity alteration while another marked creature is visibly endangered;
- a marked creature fulfills a meaningful promise despite immediate cost.

You gain no Devotion from harmless damage, willing attacks, allied summons, staged loops, repeated trivial promises, or effects created principally to generate resources.

Unused Devotion ends when the scene ends.

### CL3 — Vow Mark

You gain the Vow Mark and Devotion rules above.

#### Heart-Sense

As a Bonus Action, choose one Vow-Marked creature within 1 mile and spend 1 Resonance. Until the end of your next turn:

- you know its direction and whether it is conscious;
- you know whether its current strongest surface emotion is fear, grief, anger, loyalty, despair, hope, love, hatred, or confusion;
- if it is willing, you may exchange one brief emotional image or sentence regardless of language;
- if it is affected by possession, charm, fear, grief, despair, or emotional corruption, you learn that category.

Heart-Sense does not reveal thoughts, exact location, hidden facts, or memories.

#### Stand Together

When you or a Vow-Marked ally within 30 feet places a Resonance Mark on a hostile creature, you may spend 1 Devotion to grant one marked ally within 30 feet Temporary Hit Points equal to `Wisdom modifier + Proficiency Bonus`.

A creature can receive these Temporary Hit Points only once per round.

### CL6 — Heart’s Rebuke

A hostile act against one of your chosen bonds returns as spiritual pain.

**Reaction**  
**Trigger:** A creature within 60 feet damages, charms, frightens, possesses, spiritually manipulates, forcibly moves, or inflicts a Spirit Scar, Soul Wound, defining-memory injury, identity injury, grief effect, despair effect, or another effect expressly labeled a major emotional wound on a Vow-Marked creature  
**Cost:** 3 Resonance

The triggering creature makes a Wisdom saving throw.

**Failed Save:** It takes `4d8 + Wisdom modifier` Psychic damage and suffers one Rebuke until the start of its next turn:

- **Do Not Approach:** It cannot willingly move closer to the protected creature.
- **Feel What You Caused:** It has Disadvantage on the next attack roll it makes.
- **The Bond Remembers:** It becomes Resonance Marked for the scene.
- **Shared Alarm:** The protected creature can immediately move up to half its Speed without provoking Opportunity Attacks from the triggering creature.

**Successful Save:** It takes half damage. The protected creature gains Temporary Hit Points equal to your Proficiency Bonus.

If you spend 1 Devotion when using Heart’s Rebuke, the protected creature also gains Advantage on the next Intelligence, Wisdom, or Charisma saving throw it makes against the triggering creature before the end of its next turn.

Heart’s Rebuke punishes the witnessed hostile act. It does not establish legal guilt, karmic debt, an oath breach, or permanent hostility.

### CL10 — Borrowed Courage

Your bonds allow one soul to lend another the strength to remain itself.

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 4 Resonance  
**Target:** One willing Vow-Marked creature

Choose one procedure:

#### Courage Shared

End the Frightened condition on the target. It gains Temporary Hit Points equal to `2 × Proficiency Bonus + Wisdom modifier` and can immediately stand from Prone without spending movement.

#### Hold the Heart

Suppress one ordinary charm, possession, grief, despair, emotional corruption, obsession, or identity-confusion expression until the end of your next turn. Against a Restricted or equal-Source-CL effect, make a Cultivation Check. Against higher authority, one printed expression can be suppressed on a successful check, but the source is not erased.

The target repeats any normal saving throw at the end of its turn. A success ends the effect rather than merely suppressing it if the original Source Rule allows recovery that way.

#### Bear It With Me

Transfer one ordinary Frightened, Charmed, grief, despair, or emotional-wound expression from the target to yourself for 1 minute. You are affected as though you were the original target, using the original source’s DC and Source CL. At the end of each of your turns, you may repeat any save normally allowed.

If you are immune, the effect is not erased; it remains suppressed on the original creature until the end of your next turn, then returns unless lawfully removed.

#### Devotion Release

Spend up to 3 Devotion. For each point spent, choose one additional benefit:

- the target regains Hit Points equal to your Wisdom modifier;
- the target may move 10 feet without provoking Opportunity Attacks;
- the target gains `+1` to Intelligence, Wisdom, and Charisma saving throws until the start of your next turn;
- you learn one lawful recovery route for the effect you suppressed or transferred.

### CL14 — Chain of Devotion

You manifest the living relationship between chosen souls as a battlefield network.

**Action**  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Targets:** Up to your Proficiency Bonus willing creatures bearing your Vow Mark, including yourself  
**Concentration:** Required

While at least two linked creatures remain within 60 feet of one another, they form a **Devotion Chain**.

Each linked creature gains:

- `+1` to Intelligence, Wisdom, and Charisma saving throws;
- knowledge of the direction and broad distress state of every other linked creature within 1 mile;
- the ability to communicate one brief emotional impression to the chain once per turn without an action.

Once per round when a linked creature within 60 feet takes damage, another willing linked creature may use its Reaction to take any portion of that damage, up to half, after Resistance and before Temporary Hit Points. The transferred damage retains its type and source and cannot be reduced again by the receiving creature’s Resistance unless a Source Rule expressly allows it.

Once per round when a linked creature fails an Intelligence, Wisdom, or Charisma saving throw, another linked creature within 60 feet may spend 1 Devotion and use its Reaction to grant a reroll. The target must use the new result.

#### Chain Anchor

You may externalize the Devotion Chain as a visible **Heart-Knot Anchor** in an unoccupied space within 30 feet:

- **AC:** your Cultivation Save DC
- **Hit Points:** `8 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Psychic damage
- **Source CL:** your effective Spirit Awakening CL

While the Anchor exists, the Chain does not require Concentration. Destroying or suppressing it ends the Chain, but does not end the underlying Vow Marks.

A linked creature can leave the Chain at any time without an action. Unwilling creatures cannot be added.

### CL18 — Unbroken Vow

A chosen bond can hold a soul in the world after ordinary fate says it should be gone.

**Reaction**  
**Trigger:** A Vow-Marked creature within 60 feet would die, have its soul severed or removed, be permanently transformed, lose a defining memory, suffer a major identity wound, or have its complete cultivation suppressed  
**Cost:** 10 Resonance

Choose yourself or another willing Vow-Marked creature within 60 feet as the **Vow Bearer**. The triggering consequence is delayed until the end of the target’s next turn.

During the delay:

- the target remains alive and conscious at 1 Hit Point if physically possible;
- it cannot be possessed or have its soul displaced by ordinary lower-Source-CL effects;
- the Vow Bearer knows the broad category and source direction of the delayed consequence;
- the Vow Bearer may willingly take one level of Exhaustion and spend up to 3 Devotion to extend the delay by one additional round;
- healing, Spiritual Exorcism, reconstruction, reaching a legal escape destination, accepting a surrender that ends the hostile Source Rule, severing the sustaining Anchor, fulfilling a recovery condition already printed by the source, or another explicitly printed intervention can change or remove the consequence.

At the end of the delay, if the original consequence remains valid, it occurs unless you succeed on the following procedure.

#### The Bond Refuses

Make a Cultivation Check against the effect’s save DC or Source CL.

**Success against ordinary lower-Source-CL authority:** Convert death into unconsciousness at 0 Hit Points, soul removal into a Strained Soul Anchor, permanent transformation into a suppressible transformation scar, major memory loss into an inaccessible memory wound, or complete cultivation suppression into suppression of one printed system for the scene.

**Success against Restricted or equal authority:** Choose one of those conversions, and the target gains a persistent **Vow Scar**. The Scar imposes no additional numerical penalty by itself, but it is a Spiritual Affliction visible to Soul Gaze and relevant Source Rules. Remove it through the Vow Scar Recovery procedure below.

**Higher, Rare, Forbidden, Secret, divine, artifact, tribulation, true-name, conceptual, reincarnation, or campaign-scale authority:** On success, suppress one printed expression until the end of the scene and learn the proper reconstruction route. The complete consequence is not erased automatically.

**Failure:** The delay ends and the original consequence occurs. The Vow Mark remains unless the relationship or soul is destroyed.

#### Unbroken Bond Field

If you use Unbroken Vow while your Devotion Chain is active, every willing linked creature may contribute one of the following without an action:

- spend 1 Hit Die;
- take Psychic damage equal to `2 × Proficiency Bonus`, ignoring Resistance;
- spend 1 Cultivation Point from a Path it possesses;
- accept one level of Exhaustion.

For each distinct contributor, gain `+1` to The Bond Refuses Cultivation Check, to a maximum of `+3`.

A contribution is valid only when the contributor is willing, can perceive the preservation attempt, and immediately pays the listed cost. A creature cannot be forced, dominated, contractually compelled, or have the same paid cost refunded before the Cultivation Check. Each creature contributes at most once to one use.

Unbroken Vow preserves through chosen connection. It does not compel affection, prevent a willing departure, create resurrection without a remaining soul, or supersede dedicated Secret Laws of death, karma, fate, time, or conceptual severance.

### Normalized Vow Procedures

#### Ending a Vow Mark
Either participant can end its Vow Mark without the Heartbinder's permission.

- **Outside immediate danger:** complete a 1-minute act of reflection, communication, or deliberate release. The mark ends at the rite's completion.
- **During a scene:** use an Action while able to make decisions. The mark ends at the end of that turn.
- **Incapacitated participant:** an advance instruction recorded when the mark formed can end it upon a named condition. Otherwise the mark remains until the participant can choose or a stronger Source Rule severs it.

Ending a mark is not itself betrayal, breach, emotional harm, or a source of Devotion. A hostile creature cannot end another creature's mark by impersonating a participant.

#### Repudiation
A relationship is Repudiated only when one participant knowingly and freely declares that the relationship, promise, or protection represented by the mark is ended, or intentionally performs an act that the recorded vow explicitly identifies as repudiation. Conflict, anger, temporary separation, failure, mind control, memory loss, or inability to perform does not automatically repudiate it.

#### Qualifying Devotion Event
An event grants Devotion only if it arises from a nonallied hostile source or an uncontrolled hazard and pays a real cost: Hit Point loss, a condition lasting at least until the start of the next turn, a Reaction, Resonance, another Cultivation Point, a Hit Die, movement that exposes the creature to danger, or failure of a scene objective. The same triggering activation grants at most 1 Devotion even if it satisfies several bullets.

#### Damage Transfer
Chain of Devotion determines the original creature's damage after the original creature's Resistance, Immunity, vulnerability, and source-specific modifiers, but before its Temporary Hit Points. The receiving creature takes the chosen transferred portion as new damage from the same source. That portion cannot be transferred again, redirected again, or reduced by Resistance a second time unless a Source Rule expressly says it can. The original creature takes the remainder, then applies its Temporary Hit Points.

#### Vow Scar Recovery
Record the original source, Source CL, converted consequence, and Vow Bearer. Remove the Scar through one of these routes:

1. **Shared Cultivation:** complete three Full Cultivation Sessions with the willing Vow Bearer present; during each, the scarred creature or Vow Bearer spends one Hit Die or 1 Cultivation Point.
2. **Specialized Treatment:** a creature with Medicine, Spirit, Healing, Memory, Transformation, or another directly relevant legal Source Rule performs a 1-hour treatment, spends 5 Cultivation Points or equivalent printed materials, and succeeds on a Cultivation Check against the original effect's save DC. One treatment attempt is permitted between the scarred creature's Full Cultivation Sessions.
3. **Source Recovery:** complete the original effect's printed reconstruction route, a breakthrough-scale rite, Foundation repair, or a higher-Source-CL recovery effect that expressly repairs Spirit Scars or Soul Wounds.

Failure on Specialized Treatment consumes the time and cost but does not worsen the Scar.

#### Soul Splitting Expression — Second Heartbeat
While Soul Splitting is active, use **Second Heartbeat** as your Subpath Expression. Move your Soul Fragment up to 20 feet, then choose one willing Vow-Marked creature within 30 feet of the fragment. Until the start of your next turn, treat that creature as within 60 feet of you for Heart's Rebuke, Borrowed Courage, Chain of Devotion, and Unbroken Vow, provided it is on the same plane. This changes range only; it grants no additional Reaction, activation, Devotion, damage transfer, or contribution.

#### Vow and Bond Boundary
A Vow Mark is not a Spirit Bond, contract, Soul Anchor, marriage, legal claim, karmic debt, or permission to possess. A bonded spirit can also bear a Vow Mark only by separate informed consent. Bond Strain and Vow Scar are independent records.

### Integrated Procedure Closure — Heartbinder

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Heartbeat. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 25. Thrum of the Grave

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted grave-singer tradition, burial-drum inheritance, deathwatch sect, battlefield haunting, under-earth spirit pact, or apprenticeship to a keeper of war graves.  
**Identity:** Grave-rhythm, corpse memory, fear of death, burial earth, and the pulse every living body carries toward its grave.  
**Primary role:** Mobile damage stance, forced movement, anti-healing, death-zone control, unquiet echo Assets, and major earthbound finishing pressure.  
**Sphere Lean:** Death, Sound, Earth, Spirit. This tradition grants none of those Spheres.  
**Cultivation boundary:** The Thrum commands the rhythm surrounding death and burial. It does not automatically own souls, animate permanent undead, resurrect corpses, bypass all death immunity, or treat harmless summoned creatures as fuel. Soul Warden governs custody of the dead; Thrum of the Grave governs the battlefield pressure death leaves in bodies and earth.

> *Put your ear to the ground. The dead are keeping time.*

Practitioners hear the beat under burial earth, the cadence of a failing heart, and the remembered march in old battlefields. Their art is not silence. It is the certainty beneath sound: the beat that continues after the drummer is buried.

### Gravebeats

You can hold a number of **Gravebeats** equal to your Proficiency Bonus. You begin each scene with 0 Gravebeats.

You gain 1 Gravebeat when one of the following occurs within 60 feet, no more than once per turn:

- a hostile creature bearing your Resonance Mark becomes Bloodied;
- a hostile creature is reduced to 0 Hit Points or fails a death saving throw;
- an undead, haunt, possession, or death-spirit fails a saving throw against one of your Spirit Awakening features;
- you meaningfully disturb, consecrate, defend, interrogate, or lay to rest a corpse or grave during conflict;
- a hostile creature fails to regain Hit Points because of one of your Thrum features.

You gain no Gravebeats from harmless creatures, allied summons, staged executions, repeated healing loops, or bodies created principally to generate resources.

Unused Gravebeats end when the scene ends.

### CL3 — Gravebeat

You begin the rhythm that every corpse remembers.

**Bonus Action**  
**Cost:** 1 Resonance  
**Duration:** The scene

While Gravebeat persists:

- You know the direction and broad category of corpses, undead, dying creatures, grave-soil, active death magic, and death-haunted objects within 30 feet, unless blocked by higher concealment.
- Once per turn when you deal Psychic or Necrotic damage to a Resonance Marked hostile creature, add your Proficiency Bonus to the damage.
- When a hostile creature within 30 feet becomes Bloodied or is reduced to 0 Hit Points, you may place a Resonance Mark on one hostile creature within 10 feet of it without using an action.
- Your footsteps, weapon impacts, heartbeat, voice, drum, bell, staff, or another chosen rhythm become spiritually audible to creatures you can spiritually perceive.

Gravebeat ends if you dismiss it or become Unconscious. Silence does not automatically end it unless the silence explicitly suppresses spiritual or Resonant techniques.

#### Hear the Burial

As an Action while Gravebeat persists, choose one corpse, grave, battlefield feature, or death-haunted object within 30 feet and spend 1 Resonance. Learn one of the following:

- approximate time and manner of death;
- whether the soul departed, remains, was taken, was consumed, was trapped, or cannot be determined;
- the direction of the strongest creature or effect involved in the death;
- whether the death was ordinary, cursed, sacrificial, possessed, divine, artifact-caused, tribulation-caused, or otherwise unusual.

This is diagnosis, not corpse testimony. It does not create dialogue or summon the dead.

### CL6 — Dead March

You force the target’s body to remember its final procession.

**Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance

Choose one Resonance Marked creature, undead, haunt with a movable manifestation, or creature standing on earth, stone, grave-soil, or a battlefield. It makes a Wisdom saving throw.

**Failed Save:** Choose one March:

- **Toward the Grave:** It uses its Reaction, if available, to move up to half its Speed in a direction you choose.
- **Fall Into Step:** It cannot take Reactions and its Speed is reduced by 15 feet until the start of your next turn.
- **March Past the Living:** It must move by the Safest Available Path defined in the Normalized Execution Notes away from one creature you designate, up to half its Speed.
- **Kneel to the Beat:** If it is Bloodied, undead, Frightened, or bears two or more of your Resonance Marks or equivalent special marks, it falls Prone after moving.

The movement cannot enter an obvious lethal hazard, cross an impassable boundary, or force the target to use teleportation, flight it is not already using, or a limited resource.

**Successful Save:** Its Speed is reduced by 10 feet until the start of your next turn.

#### Processional Chain

Spend up to 2 Gravebeats when you use Dead March. For each Gravebeat spent, choose one additional eligible target within 15 feet of the original target. Each target saves separately. Processional Chain cannot target the same creature more than once and cannot generate additional Gravebeats from its own forced movement.

### CL10 — Burial Drum

You establish a rhythm in which healing, courage, and false immortality struggle to take hold.

**Action**  
**Cost:** 5 Resonance  
**Duration:** 1 minute  
**Area:** 20-foot-radius aura centered on you  
**Concentration:** Required

While the Burial Drum persists:

- The aura moves with you.
- Hostile creatures treat the aura as difficult terrain while moving closer to you.
- When a hostile creature in the aura would regain Hit Points, it makes a Wisdom saving throw.

**Failed Save:** It regains no Hit Points. If it is undead, possessed, Resonance Marked, Frightened, dying, or sustained by a death-related effect, it also takes Necrotic or Psychic damage equal to `2 × Proficiency Bonus`.

**Successful Save:** The healing is halved.

A creature makes this save no more than once per turn, regardless of how many healing sources affect it.

#### Beat of Interment

Once on each of your turns, you may spend 1 Gravebeat to pulse the Drum. Choose one hostile creature in the aura. It makes a Constitution saving throw.

**Failed Save:** It takes `3d8 + Wisdom modifier` Necrotic or Psychic damage and cannot take Reactions until the start of its next turn.

**Successful Save:** It takes half damage.

If the target is at 0 Hit Points, an ordinary creature, and not protected by a death ward, the pulse instead causes one failed death saving throw. Major enemies, player characters, named rivals, and creatures protected by stronger authority use the damage procedure unless the campaign explicitly permits lethal battlefield finishing.

#### Burial Marker Anchor

You may plant a drum, staff, weapon, bell, grave tablet, banner, bone stake, or spiritual marker in an adjacent space as a **Burial Marker Anchor**:

- **AC:** your Cultivation Save DC
- **Hit Points:** `7 × Proficiency Bonus`
- **Resistances:** Necrotic and Psychic damage
- **Source CL:** your effective Spirit Awakening CL

While it remains, the aura is centered on the Anchor and does not require Concentration. Destroying or suppressing it ends the aura.

### CL14 — Call the Unquiet

You call forth the pressure and memory of death without claiming permanent custody of a soul.

**Action**  
**Range:** 60 feet  
**Cost:** 6 Resonance  
**Duration:** The scene  
**Requirement:** A corpse, grave, battlefield, death-haunted object, or at least 2 Gravebeats

Create one **Unquiet Echo** in an unoccupied space adjacent to the source. You can maintain only one Unquiet Echo at a time.

The Echo is a Medium Cultivation Asset:

- **AC:** your Cultivation Save DC
- **Hit Points:** `6 × Proficiency Bonus`
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses
- **Resistances:** Necrotic and Psychic damage
- **Immunities:** Poisoned, Disease, ordinary suffocation
- **Speed:** 30 feet; it can move through creatures and objects as difficult terrain but takes `2d10` Force damage if it ends its turn inside one
- **Source CL:** your effective Spirit Awakening CL

It has no independent turn. On your turn, it moves when you move or when you direct it as a Bonus Action. It cannot use weapons, hold objects, flank, make Opportunity Attacks, maintain Concentration, or provide a second copy of you.

The Echo carries one **Death Memory** chosen when created:

- **Soldier’s March:** When you use Dead March, you may originate it from the Echo and increase one target’s forced movement by 10 feet on a failed save.
- **Mourner’s Cry:** Once per turn when a creature within 15 feet of the Echo fails a Wisdom saving throw against you, it becomes Frightened of the Echo until the end of its next turn.
- **Grave Keeper:** Allies within 10 feet of the Echo have Advantage on death saving throws and cannot have their souls removed by ordinary lower-Source-CL effects.
- **Unfinished Violence:** Once per turn when you deal Psychic or Necrotic damage to a marked hostile creature within 15 feet of the Echo, add `2d8` damage.

#### Grave Cry

Once on each of your turns, you may spend 1 Gravebeat to cause the Echo to release a Grave Cry at one creature within 30 feet. The target makes a Wisdom saving throw.

**Failed Save:** It takes `3d8` Psychic damage and becomes Frightened until the end of its next turn.

**Successful Save:** It takes half damage.

The Unquiet Echo is not automatically the soul of the corpse used. If an actual willing soul remains and chooses to answer, it may shape the Echo’s appearance and provide one sensory impression, but it is not trapped, copied, or permanently bound.

### CL18 — The Earth Beats Once

You strike the grave-rhythm beneath a living body and make the whole battlefield answer.

**Action**  
**Range:** 90 feet  
**Cost:** 10 Resonance  
**Requirement:** A Bloodied or Resonance Marked hostile creature standing on or touching earth, stone, grave-soil, a structure, or a battlefield surface

Choose one primary target. You may spend up to 3 Gravebeats. The target makes a Constitution saving throw.

**Failed Save:** It takes `12d10 + Wisdom modifier` Necrotic or Psychic damage, cannot regain Hit Points until the end of its next turn, and is knocked Prone. For each Gravebeat spent, choose one additional consequence:

- suppress one ordinary lower-Source-CL regeneration or death-prevention expression until the end of the scene;
- reduce its Speed to 0 until the start of your next turn;
- force it to lose Concentration;
- create a **Grave Fracture** under it, a 10-foot-radius area of difficult terrain lasting for the scene;
- if it is undead, possessed, a haunt, or externally soul-sustained, it has Disadvantage on its next save to maintain that state.

**Successful Save:** It takes half damage, its next healing before the end of its next turn is halved, and it is not knocked Prone.

#### Battlefield Afterbeat

Every other hostile creature of your choice within 20 feet of the primary target that is touching the same continuous surface makes a Wisdom saving throw.

**Failed Save:** It takes `5d10` Psychic or Necrotic damage and cannot take Reactions until the start of its next turn.

**Successful Save:** It takes half damage.

A creature can be affected by only one Afterbeat from this activation.

#### Lower-Realm Interment

An ordinary creature whose Source CL is at least 5 lower than yours reduced to 0 Hit Points by The Earth Beats Once can be killed outright, buried beneath the spiritual weight of the blow, or left dying at your choice if the campaign’s stakes permit it.

Against equal or higher authority, major enemies, divine protection, artifact death wards, Secret immortality, reincarnation authority, complete incorporeality, or explicit immunity to earthbound death effects, use the printed save and damage. On a successful Cultivation Check, you may suppress one relevant protection until the end of the target’s next turn, but you do not erase it permanently.

The Earth Beats Once does not grant ownership of the dead, prevent lawful resurrection after the scene, destroy souls, or overwrite dedicated death, burial, reincarnation, or conceptual laws.


---

### Normalized Execution Notes

#### Meaningful Grave Interaction
The grave-interaction Gravebeat trigger qualifies only when the act changes the current objective or a death-related Source Rule. Valid acts are:

- consecrate or desecrate a corpse or grave through a printed Action or rite;
- defend a corpse, grave, funeral route, or Burial Anchor against a hostile attempt;
- diagnose a death through Hear the Burial or another legal feature;
- complete a legal lay-to-rest, exorcism, soul-release, or custody procedure;
- destroy, suppress, or claim a death-related Anchor during conflict.

Touching, naming, moving around, or repeatedly striking the same inert corpse without changing its state does not qualify.

#### Safest Available Path
When Dead March forces movement, identify all legal paths that move generally in the required direction. Exclude paths that enter an obvious lethal hazard, total solid matter, unsupported falling space, or a hostile effect the target knows would immediately deal damage. Choose the shortest remaining path. If several are equal, the target chooses among them. If no legal path exists, no movement occurs, but other printed consequences still apply.

#### Death Diagnosis
Hear the Burial reports one of these soul-state results: departed normally, remains willingly, remains unwillingly, taken, consumed, trapped, reincarnated or routed, protected from diagnosis, no Complete Soul was present, or indeterminate because evidence is absent. It cannot declare a soul destroyed or consumed unless the diagnosed Source Rule left evidence of that result.

#### Lethal Battlefield Finishing
Beat of Interment uses the failed-death-save procedure against ordinary unnamed hostile creatures when lethal combat is active. Player characters, named rivals, major enemies, allied creatures, creatures under nonlethal scene stakes, and creatures protected by a printed survival rule use the damage procedure unless their controller has explicitly accepted lethal resolution.

Lower-Realm Interment can kill outright only when all of the following are true:

- the target is an ordinary hostile creature;
- its Source CL is at least 5 lower than yours;
- it was reduced to 0 Hit Points by The Earth Beats Once;
- no explicit death, reincarnation, Anchor, phylactery, surrender, capture, or nonlethal rule protects it;
- the current scene permits lethal resolution.

Otherwise choose dying or stable as allowed by the ordinary death rules. This clarification does not reduce the damage or suppression of the feature.

#### Burial Marker and Unquiet Echo
A Burial Marker and Unquiet Echo are Spirit Cultivation Assets. Record their source object or site, space, Hit Points, Source CL, active Death Memory, and whether an actual willing soul shaped the appearance.

- Neither Asset grants custody of a Complete Soul.
- An actual soul that volunteers an impression can withdraw immediately; withdrawal removes only its appearance and impression, not the generic Echo Asset.
- The Echo uses your relevant Intelligence, Wisdom, and Charisma saving throw modifiers and gains no general save proficiency.
- It can be repaired only by Asset-, spirit-, or manifestation-compatible effects.
- One creature can be protected by only one Grave Keeper anti-removal effect at a time; higher Source CL governs overlapping protection.

#### Grave Fracture
A Grave Fracture is a 10-foot-radius terrain Field anchored to the continuous surface beneath the target. Record its center, surface, Source CL, and duration. It does not move with a creature. Destroying the surface removes only those spaces that cease to exist; purification or earth repair can suppress it through the normal Source CL procedure.

#### Soul Splitting Expression — Afterbeat Shade
Your Soul Fragment carries the muted rhythm of one Gravebeat. It may serve as the origin for Hear the Burial. Once per round when you spend a Gravebeat while a hostile creature is within 15 feet of the fragment, choose that creature: its Speed is reduced by 5 feet until the start of your next turn, or you learn whether it is Bloodied, dying, undead, possessed, or sustained by a death-related effect. The fragment cannot gain or hold additional Gravebeats, activate Dead March, pulse Burial Drum, create an Unquiet Echo, or use The Earth Beats Once.

#### Realm Suppression
Gravebeats remain but cannot be spent on features above effective CL. Burial Drum, Unquiet Echo, and CL18 effects end if their sustaining feature becomes unavailable. Existing Grave Fractures remain as ordinary difficult terrain until their printed duration ends unless suppression expressly erases Fields.

### Integrated Procedure Closure — Thrum of the Grave

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Afterbeat Shade. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 26. Well of Hours

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted time-spirit inheritance, ancient clock shrine, prophetic dream, ruin that remembers the future, or Secret-adjacent initiation.  
**Classification:** Restricted Inheritance with Secret-adjacent authority.  
**Identity:** Regret, delay, echoes of possible moments, stolen seconds, and the current that eventually collects them.  
**Primary Role:** Initiative control, action compression, delayed consequences, temporal debuffing, emergency restoration, and bounded local time authority.  
**Sphere Lean:** Time, Fate, Spirit. This tradition grants none of those Spheres.  
**Authority Boundary:** Well of Hours changes when an event applies, records a recent local state, or compresses a small immediately possible act into the present. It does not create arbitrary alternate histories, restore spent resources, reverse freely chosen decisions, erase settled narrative consequences without a price, or replace Fate Reader’s probability authority.

**Source Rule:** Every Well of Hours feature uses your current effective Spirit Awakening CL as its Source CL unless the feature states otherwise. Resolve it after the explicit feature text, Spirit Awakening Core R2A, Spirit Awakening Rules Reference R3, this tradition, and universal cultivation authority procedures.

**Movement and weapon boundary:** Conceptual translation still requires a legal destination and can be contested by Time, Space, Boundary, Seal, Formation, Void, divine, artifact, or other relevant authority. A weapon attack permitted by this tradition requires proficiency from another legal source, uses the weapon’s normal attack ability unless another rule changes it, grants no weapon training or Extra Attack, and cannot carry the same once-per-turn rider more than once.

> *Time does not flow. It wells up, and some of us learn to drink before drowning.*

Well of Hours practitioners hear moments collecting beneath the present. A footstep echoes before it lands. A wound can be made to wait outside the body. A failed defense can remain undecided for one breath longer. Every theft is temporary. The stolen hour always returns carrying the weight of everything forced to wait.

---

### Well of Hours Procedures

#### Time Debt

Several Well of Hours features create **Time Debt**.

- Your maximum Time Debt equals your Proficiency Bonus.
- Time Debt is a scene resource, not Resonance.
- A feature cannot give you more Time Debt than your maximum. If it would do so, resolve the feature, set your Time Debt to its maximum, and the **Hour Comes Due** at the start of your next turn.
- At the end of a turn in which you neither gained Time Debt nor activated a Well of Hours feature, remove 1 Time Debt.
- Time Debt cannot be transferred to harmless creatures, disposable Assets, staged enemies, unwilling captives, or another closed-loop source merely to avoid payment.

##### The Hour Comes Due

At the start of your turn while your Time Debt is at its maximum:

- your Speed is halved;
- you cannot take Reactions;
- you cannot activate a Well of Hours feature;
- these restrictions last until the end of the turn;
- remove 1 Time Debt at the end of that turn.

The Hour Comes Due only once for a given turn, even if another effect would raise your Time Debt after the turn begins.

##### Temporal Arrears

When the scene ends, convert each remaining point of Time Debt into 1 **Temporal Arrear**, then set your Time Debt to 0. Temporal Arrears form one pool with a maximum equal to your Proficiency Bonus. New Arrears add to the existing pool up to that maximum; they never create separate overlapping instances.

While you have Temporal Arrears, reduce your maximum Resonance by the number of Arrears. This reduction cannot lower your maximum Resonance below half its normal value. If the reduction lowers your maximum below your current Resonance, reduce your current Resonance to the new maximum; this does not count as reaching 0 Resonance unless it actually becomes 0.

You clear all Temporal Arrears by completing 10 uninterrupted minutes of stillness, clock meditation, controlled sleep, recitation of events in reverse order, supervised temporal realignment, or a recorded equivalent temporal practice using the same uninterrupted 10-minute duration. The procedure cannot be completed while the same immediate conflict, pursuit, hazard, or time-pressure scene continues.

Temporal Arrears are not an injury. A higher-Source-CL temporal curse can convert them into a Hidden Injury only when its Source Rule expressly says so.

#### Deferred Consequences

A **Deferred Consequence** is a resolved consequence whose application has been placed immediately outside the present.

When a consequence is deferred, record:

- its originating Source Rule;
- its damage amount and damage type, condition, movement, restraint, or other exact effect;
- its original target;
- when it will arrive;
- any save, check, Anchor, or special rule that can answer it.

Use the following rules:

1. **No present application.** The deferred consequence does not apply during the delay and cannot trigger a rule requiring it to have already occurred.
2. **Not a second activation.** When it arrives, it is not a new attack, technique activation, critical hit, or new expenditure by its source. It is the delayed application of the original consequence.
3. **Damage and healing.** Healing received by the subject can be assigned first to deferred damage, even when the subject is at its Hit Point maximum. Each point assigned reduces the deferred damage by 1. Any healing left afterward restores Hit Points normally.
4. **Conditions and afflictions.** A suitable cleansing, exorcism, counter-technique, protection, escape, severance, or higher-authority intervention can reduce or remove the corresponding deferred effect before it arrives.
5. **Partial answers.** If an answer removes only part of a consequence, apply the remainder when the delay ends.
6. **No resource rewind.** Actions, Reactions, movement already spent, Cultivation Points, item charges, consumed materials, broken Concentration, and decisions already made are not restored merely because a consequence was deferred.
7. **Arrival.** When deferred damage arrives, it retains its original damage type and bypass properties. Effects triggered by actually taking that damage can respond at that time.
8. **Higher authority.** Permanent, Secret, divine, artifact, heavenly-law, Foundation-breaking, Method-breaking, soul-consuming, or explicitly outside-time consequences remain subject to their own Source Rules and normally require a Cultivation Check to defer or answer.

---

### CL3 — Ripple of Before

Your soul recognizes the pressure of a moment immediately before the body understands it.

#### Before the Bell

**Reaction**  
**Trigger:** You roll Initiative, become Surprised, fail a Wisdom (Perception) or Wisdom (Insight) check, or fail a Cultivation Check to notice an immediate spiritual danger  
**Cost:** 1 Resonance  
**Time Debt:** 1

Choose the result appropriate to the trigger:

- Add your Proficiency Bonus to the Initiative roll, ability check, or Cultivation Check. You decide after rolling but before the final outcome is declared.
- If Surprised, you can move up to half your Speed, speak a short warning, draw or stow one item, use Spiritual Sense, or take the Dodge action during your first turn. You remain Surprised and cannot use another Action or Bonus Action during that turn unless another Source Rule removes Surprise.
- If the check concerned an ambush, trap, possession, dream intrusion, concealed spirit, imminent attack, or immediate temporal disturbance, learn the direction of the danger even if the added bonus does not produce a success.

#### Echo of the Chosen Step

Once on each of your turns, immediately after you move at least 10 feet, you may record the space where that movement began as your **Before-Space** until the start of your next turn.

**Bonus Action**  
**Cost:** 1 Resonance  
**Time Debt:** 1

Return to your Before-Space by conceptual translation, provided it remains a legal destination within 30 feet.

This movement:

- does not provoke opportunity attacks;
- is not ordinary teleportation;
- can be contested by a Source Rule that seals time, Space, routes, or conceptual movement;
- restores only your position.

It does not undo attacks, damage, conditions, expended resources, opened doors, triggered hazards, or any event that occurred after you left the space.

#### Soul Splitting — Yesterday’s Witness

Your soul fragment can record one space it legally occupies as its Before-Space until the end of its next turn. During that turn, it can use its movement to return to the recorded space without spending your Resonance. It cannot transport you or another creature through this option and cannot return more than once per round.

---

### CL6 — Borrowed Second

You pull a small act from the next breath and spend it now.

**Bonus Action**  
**Cost:** 3 Resonance  
**Limit:** Once per turn

Choose one option:

- move up to half your Speed without provoking opportunity attacks;
- stand from Prone and move up to 10 feet;
- draw, stow, pick up, hand off, open, close, or manipulate one ordinary object;
- use Spiritual Sense or Soul Gaze;
- take the Disengage or Search action;
- make one attack with a weapon you are already proficient with against a creature bearing your Resonance Mark and within the weapon’s normal reach or range;
- use Mind Spike against a creature bearing your Resonance Mark, reducing its damage by one die, to a minimum of one die.

The ordinary options create 1 Time Debt. The weapon-attack and Mind Spike options create 2 Time Debt.

Borrowed Second cannot:

- activate a Domain;
- activate a CL10-or-higher Subpath feature;
- activate Soul Vessel, Soul Splitting, or another feature that creates a separately acting Asset;
- activate a full multi-packet Forged Technique;
- activate an item power limited to once per scene or less often;
- activate another feature whose primary effect is to grant an additional Action, Bonus Action, Reaction, or turn;
- be used during a turn granted by another extra-turn effect.

#### Pay the Second Back

At the start of your turn, before moving, taking an Action or Bonus Action, or using a Reaction, you may choose to pay the current.

Until the start of your next turn:

- your Speed becomes 0;
- you cannot take Reactions;
- you cannot voluntarily move, teleport, spiritually step, conceptually translate, or activate a Source Rule whose primary effect moves you;
- you cannot use Borrowed Second.

Then remove 2 Time Debt. Involuntary movement does not cancel this payment and does not restore your ability to move voluntarily.

This declaration occurs before the turn’s actions and cannot be made after you have already benefited from movement, a Reaction, or another Well of Hours feature during that turn.

---

### CL10 — Hourglass Mark

You place a target inside the delay between intention and result.

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance  
**Duration:** Up to 1 minute

Choose one creature you can perceive. It makes a Wisdom saving throw.

**Failed Save:** The creature gains your **Hourglass Mark**. This is a special Resonance Mark. At the end of each of its turns, it repeats the save, ending the mark on a success.

**Successful Save:** It suffers one ordinary Spiritual Pressure effect until the start of your next turn.

You can maintain only one Hourglass Mark. Because it is one of your Resonance Marks, applying it replaces another Resonance Mark you placed on that creature, and applying an ordinary Resonance Mark to that creature replaces the Hourglass Mark unless this feature expressly says otherwise. Creating a new Hourglass Mark ends the previous one.

While the mark lasts, once per round when the marked creature begins one of the following activities, you may spend 1 Resonance and gain 1 Time Debt to apply the corresponding delay.

#### Delayed Movement

When it begins voluntary movement, reduce the distance available to that movement by 15 feet, minimum 0. If this prevents it from reaching a required destination, an action requiring that arrival must be redirected to another legal target or fails under its normal rules.

#### Delayed Strike

When it makes an attack roll, subtract `1d6` from the roll. Decide after seeing the d20 but before the outcome is finalized.

#### Delayed Technique

When it forces one or more creatures to make a saving throw against a technique, choose one target. That target adds `1d6` to its saving throw. This cannot modify an environmental or passive save whose source is no longer the marked creature.

#### Delayed Reaction

When it attempts a Reaction, the Reaction occurs only after the triggering action, movement, or technique fully resolves. If the trigger is no longer valid at that time, the Reaction does not occur and any resource committed specifically to that Reaction is not spent.

You cannot apply more than one Hourglass delay to the same roll, movement, technique, or Reaction.

#### Break the Glass

The marked creature or a creature adjacent to it can use an Action to strike, shatter, dispel, exorcise, or spiritually realign the mark.

The acting creature makes one of the following checks against your Cultivation Save DC:

- Intelligence (Arcana);
- Wisdom (Insight);
- Dexterity (Sleight of Hand);
- a Cultivation Check using an appropriate Source Rule.

On a success, the Hourglass Mark ends. Time, Fate, Spirit, Clock, Sound, anti-curse, and suitable conceptual severance effects can qualify.

---

### CL14 — Refuse the Moment

You place one consequence beside the present and demand that it wait.

**Reaction**  
**Trigger:** You or a creature you can perceive within 30 feet would take damage, gain a condition from a failed saving throw, be forcibly moved, become Grappled or Restrained, become Unconscious, or be reduced to 0 Hit Points by a non-damage effect  
**Cost:** 6 Resonance  
**Time Debt:** 2  
**Delay:** Until the end of the protected creature’s next turn

Defer one discrete consequence of the triggering event. Valid examples include:

- all damage from one attack, technique packet, hazard pulse, or fall;
- one condition, command, possession impulse, or other discrete effect caused by the failed save;
- one instance of forced movement;
- one Grappled or Restrained condition;
- becoming Unconscious;
- being set or reduced to 0 Hit Points by an effect that does not deal damage.

Record the consequence using the Deferred Consequence procedures. The deferred consequence arrives at the end of the protected creature’s next turn unless it has been answered before then.

You can maintain only one Deferred Consequence from Well of Hours at a time. Creating another releases the first immediately before the new consequence is deferred.

#### Authority Limits

Refuse the Moment automatically delays an ordinary, Open, Restricted, or equal-Source-CL consequence when all other requirements are met.

A Rare, Forbidden, Secret, divine, artifact, heavenly-law, Foundation-breaking, Method-breaking, permanent, soul-consuming, or explicitly outside-time consequence requires a Cultivation Check against the originating Source Rule.

On a failed contest:

- the consequence is not delayed;
- the Resonance is spent;
- you gain only 1 Time Debt instead of 2.

Refuse the Moment cannot:

- restore a creature already dead before the trigger;
- undo a completed severance, destroyed Asset, broken Foundation, or consumed soul;
- reverse an event whose Source Rule resolves outside time;
- restore an action, resource, charge, item, or opportunity already spent.

#### Soul Splitting — Hold This Breath

When an ally within 30 feet of your soul fragment takes damage, the fragment can use its Subpath Fragment action and spend 2 Resonance from you to defer up to `2d8 + Wisdom modifier` of that damage until the end of that ally’s turn.

This does not use your Reaction, but it creates 1 Time Debt and still counts against the limit of one Deferred Consequence from Well of Hours. If you are already at maximum Time Debt, the Hour Comes Due normally at the start of your next turn.

---

### CL18 — The Well Has No Bottom

You reveal the local truth that every present moment rests above an immeasurable depth of moments that might have been.

**Action**  
**Range:** 90 feet  
**Area:** 30-foot-radius sphere  
**Cost:** 10 Resonance  
**Duration:** Concentration, up to 1 minute

The area becomes a **Well of Hours**, a spiritual-temporal field and Source Rule.

When the field appears, record the following for every creature of your choice currently in the area:

- its space;
- its current Hit Points;
- its ordinary conditions.

This record is its **Round Image**.

At the start of each of your turns, replace the Round Image of each chosen creature currently in the field with its current state. When a creature enters the field after it appears, you may choose it for the field. If chosen and still in the field, it gains a Round Image at the start of your next turn.

#### Friendly Current

Each willing creature you choose that starts its turn in the field chooses one benefit:

- move up to 10 feet without provoking opportunity attacks;
- stand from Prone without spending movement;
- draw or stow one item and use Spiritual Sense;
- gain Temporary Hit Points equal to `2 × your Proficiency Bonus`;
- suppress one ordinary Spiritual Pressure effect on itself until the end of the turn.

#### Hostile Undertow

The first time each round a hostile creature in the field voluntarily moves, makes an attack, activates a technique, or takes a Reaction, it makes a Wisdom saving throw.

**Failed Save:** Apply Delayed Movement, Delayed Strike, Delayed Technique, or Delayed Reaction without spending Resonance or gaining Time Debt. The creature also becomes Resonance Marked until the end of its next turn.

**Successful Save:** Choose one:

- reduce its Speed by 10 feet until the start of its next turn;
- it cannot take Reactions until the start of its next turn.

A creature that succeeds against Hostile Undertow twice during the same activation becomes immune to it for the remainder of that activation unless your Source CL increases.

#### Return to the Bell

Once during the activation, when a creature of your choice in the field takes damage, fails a saving throw, is moved, gains a condition, or is reduced to 0 Hit Points, you may use your Reaction to return it to its Round Image.

- Place it in its recorded space or the nearest legal space within 15 feet.
- If the recorded Hit Point value is higher, set its Hit Points to that value.
- Remove ordinary conditions gained after the image was recorded.
- Restore no Resonance, Stamina, Qi, Hit Dice, item charges, consumed materials, actions, Bonus Actions, Reactions, movement, Concentration, Sphere resources, Insight uses, Domain activations, or other spent resources.
- Do not restore a destroyed Cultivation Asset, severed limb, broken Foundation, consumed soul, permanent Hidden Injury, completed death, or higher-authority consequence unless a successful Cultivation Check and the originating Source Rule both permit temporal restoration.

After using Return to the Bell:

- set your Time Debt to its maximum;
- take `3d10` Psychic damage.

This damage ignores Resistance and Immunity and cannot be redirected, deferred, transferred, or reduced by a Well of Hours feature.

#### Drink the Unlived Hour

Once on each of your turns, you may gain 1 Time Debt to use Borrowed Second without spending Resonance.

You can choose Borrowed Second’s weapon-attack or Mind Spike option only once during the entire activation of The Well Has No Bottom.

#### Collapse of the Well

When the field ends:

- every Deferred Consequence whose subject is inside it resolves immediately unless already answered;
- your remaining Time Debt is converted into Temporal Arrears normally.

You cannot activate The Well Has No Bottom again until:

1. you have no Time Debt;
2. you have no Temporal Arrears;
3. after the previous field ends, you complete the Temporal Arrears clearing procedure, even if you had no Arrears remaining.

This is a defined cultivation-recharge procedure, not a short-rest or long-rest limit.

A higher-Source-CL Time, Fate, Void, Samsara, Boundary, Seal, Formation, divine, artifact, or conceptual authority can contest individual operations of the field. Ordinary anti-magic does not automatically erase it unless that effect also suppresses cultivation Source Rules.

---

### Well of Hours Interaction Closure

- **No duplicate events:** Returning, delaying, or recording a state never creates a second attack, save, technique activation, critical hit, resource expenditure, or turn.
- **No self-recursion:** A Well of Hours feature cannot defer, redirect, or reduce Time Debt, Temporal Arrears, the Hour Comes Due, or backlash damage created by another Well of Hours feature unless it expressly says so.
- **No action-loop recursion:** Borrowed Second cannot activate itself, activate another extra-action rule, or be used during an extra turn. Return to the Bell restores no action economy or expended resources.
- **Concentration:** If deferred damage later forces a Concentration save, make that save when the damage actually arrives. Returning to a Round Image does not restore broken Concentration.
- **Realm Suppression:** Time Debt and Temporal Arrears remain. Features above the suppressed effective CL become unavailable. A maintained Well of Hours field ends if suppression makes its CL18 feature unavailable. Existing Deferred Consequences still arrive unless a legal counterprocedure answers them.
- **Permanent authority:** Completed death, consumed souls, destroyed Foundations, permanent Hidden Injuries, severed cultivation systems, and effects explicitly outside time are never restored by implication. They require express permission and the applicable Cultivation Check or reconstruction procedure.

#### Normalized Execution Notes

##### Temporal Record
Every Time Debt gain, Deferred Consequence, Hourglass Mark, Round Image, and Temporal Arrear must be recorded when created. The minimum record is:

- source feature and Source CL;
- subject;
- exact amount, condition, movement, roll modifier, or state;
- creation time and arrival or expiration time;
- current answers, healing assigned to deferred damage, and remaining value;
- Anchor, Field, or opposing authority involved.

An AI or GM resolves the recorded values. It cannot replace them with a narratively similar but mechanically stronger consequence.

##### Immediate Conflict
The Temporal Arrears clearing procedure cannot occur while any of these remain continuous: initiative has not ended; the same pursuit is active; the same hazard is resolving at least once per minute; an enemy is actively searching the immediate area; or a deadline shorter than 10 minutes is currently driving the scene. Once none apply, the procedure can begin even if the larger adventure continues.

##### Surprise Compatibility
Before the Bell uses the campaign's finalized Surprise procedure. It does not create a second turn or remove Surprise. It grants only the listed movement, warning, item interaction, Spiritual Sense, or Dodge permission during the practitioner's first turn.

##### Hourglass Mark and Resonance Mark
An Hourglass Mark is a special Resonance Mark. A target can bear one Hourglass Mark from you, and it occupies your normal special-mark relationship with that creature unless a Source Rule expressly permits coexistence. Placing it replaces your ordinary Resonance Mark on that creature; ending it leaves no ordinary mark unless another feature applies one.

##### Delayed Reaction Resources
Under Delayed Reaction, a resource is committed only when the Reaction legally begins after the triggering event finishes. If the trigger is no longer valid, the Reaction does not occur and resources are not spent. A feature that explicitly pays its cost at declaration follows its own Source Rule instead.

##### Round Image State
A Round Image records space, current Hit Points, and ordinary conditions only. “Ordinary conditions” are the system's standard temporary conditions and ordinary Spiritual Pressure. It does not record CP, Concentration, equipment state, temporary feature uses, transformation stages, death saves already failed, Assets, Anchors, wounds, memories, relationships, or identity states unless Return to the Bell expressly names them.

If the recorded space is illegal, use the nearest legal space within 15 feet. Measure by shortest path ignoring creatures but not solid barriers. The returned creature chooses among equally near spaces.

##### Temporal Collision
When another Time, Fate, Samsara, Space, Boundary, Void, Formation, divine, artifact, or outside-time effect conflicts with a Well operation, compare Source CL. Lower authority yields. At equal Source CL, make a Cultivation Check for that operation only. Failure does not end the entire field unless the opposing effect expressly suppresses the Field or its Anchor.

##### Realm Suppression and Records
Suppression never deletes Time Debt, Arrears, Deferred Consequences, Hourglass records, or already-created Round Images. It can end a Field or prevent activation above effective CL. A Deferred Consequence still arrives at its recorded time unless legally answered.

### Integrated Procedure Closure — Well of Hours

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Yesterday’s Witness; Hold This Breath. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 27. Black Current Walker

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted Black Current lineage, river-infiltrator school, moon-canal shrine, drowned-scout inheritance, or teacher who survived the Black Current.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Flowing movement, shadow-water, redirection, wake control, ambush, and passing through a battlefield without becoming fixed in it.  
**Primary role:** Mobile skirmisher, defensive redirection, marked-target pursuit, ally extraction, and flowing battlefield control.  
**Sphere Lean:** Flowing River, Water, Shadow, Athletics, Scoundrel, Spirit. This tradition grants none of those Spheres.  
**Combat boundary:** Black Current movement is spiritual flow, not unrestricted water creation or Qi projection. It can express through bare hands, Mind Spike, a trained weapon, talismans, wire, needles, or another legal attack form.

> *A river does not dodge the stone. It teaches the stone that it was never the center of the current.*

Black Current Walkers cultivate a moving soul. Their bodies are real, but their commitment to any one position is not. They cross rooftops like runoff, turn pursuit into overextension, and leave black-silver wakes that allies can ride and enemies enter at their peril.

### Soulwake

Several features create a **Soulwake**.

- A Soulwake is the path through spaces you actually moved across during the current turn.
- Record up to a number of contiguous 5-foot spaces equal to your Proficiency Bonus.
- A Soulwake lasts until the start of your next turn unless a feature extends it.
- It can cross walls, gaps, water, creatures, or other barriers only if your movement legally crossed them.
- A Soulwake is visible to Spiritual Sense as black water, moonlit spray, wet footprints, drifting reeds, or a silent current.
- You can have only one Soulwake at a time; creating another replaces it.

### CL3 — Enter the Black Current

#### Flow After the Strike

Once on each of your turns, immediately after you deal damage to a meaningful hostile creature with Mind Spike, a Spirit Awakening technique, an unarmed strike, or a weapon attack with a weapon you are proficient with, you may move 10 feet without provoking opportunity attacks.

If the damaged creature is Resonance Marked by you, the movement increases to 15 feet and can pass through its space, though you cannot end there.

Record the movement as a Soulwake.

#### Current Without Footing

During your turn, you may move across liquid surfaces, narrow rails, rope, tree branches, loose rubble, snow, mud, fragile rooftops, and vertical surfaces as though they were stable ground. You fall or sink at the end of the turn unless you reach a surface that can support you or another feature keeps you aloft.

This is a spiritual step. It does not grant a swim Speed, flight, or the ability to pass through solid barriers.

#### Wake Mark

When you pass through a hostile creature’s space using a Black Current feature, you may spend 1 Resonance. It makes a Wisdom saving throw.

**Failed Save:** It becomes Resonance Marked until the end of your next turn and cannot take opportunity attacks against you during that duration.

**Successful Save:** Its Speed is reduced by 5 feet until the start of your next turn.

You can attempt this against a creature only once per turn.

### CL6 — Turn the Pursuer

You make the attacker commit to a position you have already abandoned.

**Reaction**  
**Trigger:** A creature you can perceive targets you with an attack, attempts to Grapple you, or enters a space in your Soulwake  
**Cost:** 2 Resonance

Move up to 10 feet to a legal space connected to your Soulwake or create a new 10-foot Soulwake with this movement. This movement does not provoke opportunity attacks.

Then resolve the trigger:

- If the triggering attack or Grapple no longer has range, reach, line of effect, or a legal target, it misses or fails.
- Otherwise, you gain `+2 AC` against the attack or Advantage on the check or save against the Grapple.
- If the trigger was entering your Soulwake, the creature makes a Wisdom saving throw. On a failure, move it 5 feet to another legal space adjacent to the wake and remove its Reactions until the start of its next turn. On a success, reduce its Speed by 10 feet for the rest of the turn.

#### Carry the Reed

When Turn the Pursuer moves you, you may spend 1 additional Resonance to move one willing adjacent creature 5 feet into the space you left or another legal adjacent space. This movement does not provoke opportunity attacks.

### CL10 — River-Cut Passage

You cut a route through the battle and let the current strike everyone who tried to become a bank.

**Action**  
**Cost:** 5 Resonance

Move up to your Speed by spiritual step. During this movement:

- you can move through the spaces of creatures;
- you ignore nonmagical difficult terrain;
- opportunity attacks against you fail;
- you can move across walls, liquid, narrow surfaces, and open gaps, but must end in a legal supported space;
- record the entire legal route as a Soulwake, with no normal Proficiency Bonus space limit for this activation.

Choose up to your Proficiency Bonus creatures whose spaces you entered or passed adjacent to. Each chosen creature makes a Dexterity saving throw.

**Failed Save:** It takes `5d8` Psychic, Slashing, or Cold damage, becomes Resonance Marked until the end of your next turn, and is moved 5 feet to either side of your route if a legal space exists.

**Successful Save:** It takes half damage and is not moved.

A creature can be affected once per activation. River-Cut Passage is one technique, not multiple attacks, and cannot deliver the same weapon, poison, Insight, or Forged Technique rider to every target unless that rider expressly works with area techniques.

#### Moonlit Extraction

Instead of damaging one chosen creature, you may carry it with you if it is willing. Place it in a legal space adjacent to you when your movement ends. An Unconscious willing ally counts as willing if an ally who can communicate with it consents and no hostile possession contests the movement.

### CL14 — No Bank Holds the River

Your soul no longer treats enemy control zones as fixed geography.

#### Continuous Current

You gain the following benefits:

- Your Speed increases by 10 feet.
- You gain a swim Speed equal to your Speed and can breathe while your spirit remains connected to your body, including underwater or in spiritual dream-rivers.
- Moving through a hostile creature’s space with a Black Current feature does not cost extra movement.
- Once on each of your turns, when you enter the space of a Resonance Marked hostile creature, you may exchange positions with it. The creature makes a Wisdom saving throw. On a success, the exchange fails, but your movement can continue through its space.
- When you leave a Grapple or ordinary Restrained effect through a Black Current spiritual step, make a Cultivation Check against the effect’s DC or Source Rule. On a success, the effect ends. On a failure, the movement fails and is not spent.

#### Undertow Pursuit

**Reaction**  
**Trigger:** A Resonance Marked creature within 60 feet moves at least 15 feet, teleports, or is forcibly moved  
**Cost:** 4 Resonance

Move up to half your Speed by spiritual step toward a legal space within 10 feet of the target’s destination. This movement cannot cross a sealed boundary or exceed 60 feet even if your Speed is greater.

After arriving, choose one:

- use Mind Spike against the target, reducing its damage by one die;
- make one weapon attack against it with a weapon you are proficient with;
- impose one Spiritual Pressure effect on it without a save;
- move one willing creature adjacent to you 10 feet along your Soulwake.

A higher-Source-CL teleportation, boundary, concealment, or route effect can require a Cultivation Check to follow.

#### Soul Splitting — Tributary

Your soul fragment can occupy a space in your Soulwake without blocking it. Once per turn when you use Flow After the Strike, the fragment may move 10 feet along the wake. It cannot trigger Wake Mark or River-Cut Passage independently.

### CL18 — Procession of the Black River

You manifest the battlefield as a nocturnal river whose current recognizes your allies and erodes every hostile attempt to stand still.

**Bonus Action**  
**Cost:** 10 Resonance  
**Area:** 40-foot-radius aura centered on you  
**Duration:** 1 minute  
**Concentration:** Required

The aura moves with you and becomes your **Black River Domain**.

#### Allied Current

Creatures of your choice in the Domain:

- ignore nonmagical difficult terrain;
- gain 10 feet of Speed;
- can move 5 feet without provoking opportunity attacks at the start of their turns;
- can move across liquid, narrow surfaces, and occupied allied spaces during their turns;
- gain `2 × Proficiency Bonus` Temporary Hit Points the first time each round they move at least 15 feet.

#### Hostile Banks

A hostile creature treats the Domain as difficult terrain. The first time each round it voluntarily ends movement without moving at least 10 feet from where that movement began, it makes a Wisdom saving throw.

**Failed Save:** It takes `3d8` Psychic or Cold damage, cannot take Reactions, and is pulled or pushed 10 feet along the current.

**Successful Save:** Its Speed is reduced by 10 feet until the end of its next turn.

#### Ten Thousand Tributaries

Once on each of your turns, choose one:

- move yourself or one willing creature in the Domain up to 20 feet without provoking;
- exchange the positions of two willing creatures in the Domain;
- force one Resonance Marked hostile creature to make a Wisdom save, moving it 15 feet on a failure or 5 feet on a success;
- use River-Cut Passage without spending Resonance, but its movement is limited to half your Speed and its damage becomes `3d8`.

You can choose the free River-Cut option only once during the activation.

#### River Leaves No Corpse Behind

Once during the activation, when an ally in the Domain would be reduced to 0 Hit Points, use your Reaction to move it up to 30 feet to a legal space in the Domain. It is reduced to 1 Hit Point instead and becomes unable to benefit from this feature again until it completes a full cultivation session.

A Secret boundary, execution law, anti-escape Anchor, or higher-Source-CL movement prohibition can contest this rescue.

---

### Normalized Execution Notes

#### Soulwake Record
A Soulwake records its ordered contiguous spaces in the sequence crossed. The route includes only spaces your movement legally entered. Teleportation, conceptual translation, and forced placement create wake spaces only when a Black Current feature expressly says they do.

A space remains part of the Soulwake even after a creature enters it, but a newly created solid barrier, sealed boundary, or destroyed support can make that portion unusable. Effects that move along or connect to the wake follow the ordered route and cannot skip an intervening sealed segment.

#### Passing Through Creatures
When a Black Current feature permits passage through a creature's space:

- you cannot end there;
- the space does not become difficult terrain unless the feature says so;
- you do not Grapple, shove, disarm, or damage the creature by passage alone;
- a creature more than two size categories larger can block the space only through an explicit body, ward, restraint, or anti-passage rule;
- a creature more than two size categories smaller does not provide cover against the movement.

Wake Mark can be attempted once per turn per creature as printed.

#### Exchange Positions
Continuous Current's exchange requires both creatures to fit in each other's destination spaces. On a failed target save, the exchange is simultaneous forced spiritual displacement. It does not provoke opportunity attacks. If either destination is illegal, the exchange fails and you continue through the target's space. An immovable, Anchored, or higher-authority creature contests through its normal rule.

#### Undertow Pursuit Record
Record the triggering creature's origin, destination, movement type, and route Source CL. You must perceive the target or its Resonance Mark at the trigger. The destination must be a legal space within 10 feet of the target's resolved destination and no more than 60 feet from your origin.

Following teleportation does not grant access to a plane, sealed room, vessel, dream, or Domain that your Source Rule cannot enter. On a failed Cultivation Check against the route, you remain in place; Resonance is spent because the pursuit was attempted.

#### Ally Extraction
Moonlit Extraction and River Leaves No Corpse Behind move willing creatures and their worn or carried equipment. A controlled but unwilling Host, possessed creature, restrained prisoner, or creature carrying an independently resisting Artifact uses the relevant consent or Source CL procedure. The rescue does not remove conditions, restraints, or Anchors unless movement itself makes them illegal under their own rules.

#### Domain Current
At activation, designate a current direction or clockwise/counterclockwise circulation. Pushes and pulls under Hostile Banks follow that current unless the feature's controller chooses the reverse direction for a specific target. A target must end in a legal space; reduce distance to the greatest legal amount if blocked.

Each ally can gain the printed Temporary Hit Points at most once per round. Ten Thousand Tributaries is one operation per turn. The free River-Cut option remains once per activation.

#### Soul Splitting Expression — Tributary
The existing Tributary expression is retained. The fragment's 10-foot movement follows contiguous Soulwake spaces and uses the fragment's normal movement permission. It cannot carry a passenger, create a new Soulwake, trigger Wake Mark, or extend Undertow Pursuit range.

#### Realm Suppression
A current Soulwake persists until its normal expiration but cannot support features above effective CL. Black River Domain ends if CL18 becomes unavailable. Movement already completed is not reversed.

### Integrated Procedure Closure — Black Current Walker

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Tributary. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 28. Unwritten Footprint

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted infiltrator monastery, hidden-service clan, erased archive, spirit of forgotten roads, or initiation in which every witness agrees never to record the initiate’s name.  
**Classification:** Restricted Infiltration Tradition; some lineages are condemned, but the tradition is not automatically Forbidden.  
**Identity:** Trace denial, unnoticed passage, witness manipulation, silence between perceptions, and severing an action from the memory that would reveal it.  
**Primary role:** Stealth skirmisher, anti-surveillance infiltrator, ambush control, escape, and selective witness suppression.  
**Sphere Lean:** Shadow, Scoundrel, Illusion, Silence, Spirit, Conceptual Severance. This tradition grants none of those Spheres.  
**Ethical boundary:** Erasing a witness’s understanding of a brief movement is not the same as destroying identity or rewriting a life. Long-term memory theft, historical erasure, or removal of a person from all records requires a Forbidden or Secret source beyond this tradition.

> *The perfect step is not silent. It is the step the world forgets to accuse.*

Unwritten Footprint practitioners do not vanish by bending light. They cultivate the gap between perception and conclusion. A guard sees a curtain move but never decides someone passed it. A divination records an open door but not who opened it. In battle, the practitioner attacks from the interval in which an enemy has perceived motion but has not yet assigned it a source.

### Witnesses and Notice

A creature is a **Witness** when it can currently perceive evidence of you through sight, hearing, scent, Spiritual Sense, tremorsense, a ward, remote observation, or another meaningful sense.

A creature **Notices** you when it can identify your location or can reasonably attribute a current action, movement, technique, or trace to you.

- Being unseen does not automatically make you unnoticed if your presence is obvious.
- Being noticed does not automatically reveal your identity.
- A feature that makes you unnoticed does not make you invisible; it suppresses attribution for the specified creature and duration.
- Directly damaging, Grappling, speaking to, touching, or obviously obstructing a creature normally causes it to notice you after that interaction resolves unless a feature says otherwise.

### Unwritten Traces

Several features create an **Unwritten Trace** on a Witness.

- An Unwritten Trace is a special Resonance Mark and counts as your Resonance Mark.
- It represents a gap in attribution: the Witness perceived evidence but failed to fasten it to you.
- It lasts for the scene unless removed or consumed.
- A creature can bear only one Unwritten Trace from you.
- A traced creature does not forget you exist. It is vulnerable to your notice-denial features.
- The trace can be removed through Spiritual Exorcism, a successful Wisdom (Insight) or Intelligence (Investigation) check against your Cultivation Save DC after studying the scene for an Action, or a suitable equal- or higher-Source-CL clarity effect.

### CL3 — Step No Record Keeps

#### Trace-Eating Passage

Your ordinary movement leaves no mundane footprints, scent trail, displaced dust, bent grass, blood droplets from superficial wounds, loose fibers, or ordinary audible footfalls unless you choose otherwise.

This does not hide major destruction, opened locks, moved bodies, active techniques, obvious blood loss, displaced water, broken wards, or evidence you intentionally leave. Trained spiritual tracking can contest your concealment with a Cultivation Check.

#### Slip the Conclusion

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one creature that can perceive you but that you have not directly damaged, touched, or addressed since the start of your current turn. It makes a Wisdom saving throw.

**Failed Save:** Place an Unwritten Trace on it. Until the start of your next turn, you are unnoticed by that creature unless you directly interact with it. It can perceive changes in the environment but does not identify you as their source.

**Successful Save:** It knows that something attempted to blur its attribution and learns your direction, but not necessarily your exact space if you are otherwise hidden.

After resolving Slip the Conclusion, you may move 10 feet without provoking opportunity attacks from the target.

#### Ambush Without Hatred

Once on each of your turns when you deal damage to a creature that had not noticed you immediately before the attack or technique, add `1d6` Psychic damage and remove its Reactions until the start of its next turn.

At CL10 the extra damage becomes `2d6`; at CL18 it becomes `3d6`.

A creature cannot be made repeatedly “unaware” through harmless staged concealment in the same moment. It must have genuinely lost attribution through movement, cover, a feature, or a meaningful tactical change.

### CL6 — Knife Between Thoughts

You attack during the interval before a Witness finishes understanding where the threat came from.

#### Between-Thought Strike

When you use Mind Spike or make a weapon attack with a weapon you are proficient with against a creature bearing your Unwritten Trace, you may spend 2 Resonance before the roll.

On a hit or failed save:

- Ambush Without Hatred applies even if the target noticed you;
- the target cannot communicate your exact location, target you with a Reaction, or grant another creature a targeting benefit based on your location until the start of your next turn;
- you may move 10 feet without provoking opportunity attacks.

Whether the attack succeeds or fails, consume the target’s Unwritten Trace after resolution.

#### Misattribute the Blow

**Reaction**  
**Trigger:** A traced creature targets you with an attack or single-target hostile technique  
**Cost:** 2 Resonance

Move 10 feet to a legal space. The target then makes a Wisdom saving throw.

**Failed Save:** It assigns your former position, an afterimage, a shadow, or another plausible false source as the origin. If the triggering effect cannot legally reach your new position, it misses or fails. Otherwise it has Disadvantage on the attack roll, or you have Advantage on the saving throw.

**Successful Save:** You gain `+2 AC` against the attack or `+2` to the save.

Misattribute the Blow consumes the trace.

### CL10 — Steal the Witness

You temporarily sever the link between a target’s perception and its ability to identify you as the subject of that perception.

**Action**  
**Range:** 60 feet  
**Cost:** 5 Resonance  
**Duration:** 1 minute  
**Concentration:** Required

Choose one creature that can perceive you or bears your Unwritten Trace. It makes a Wisdom saving throw.

**Failed Save:** You become **Unwritten to the target** for the duration. At the end of each of its turns, it repeats the save, ending the effect on a success.

While you are Unwritten to it:

- it cannot voluntarily target you with attacks or single-target techniques;
- it cannot take opportunity attacks against you;
- it cannot accurately communicate your current location;
- it treats spaces you occupy as apparently empty until physical contact, collision, or an effect requiring an occupied space reveals the obstruction;
- area effects and actions chosen without targeting you can still affect you normally;
- direct damage, a Grapple, a forceful touch, or a spoken declaration addressed specifically to the target gives it an immediate repeat save before the interaction continues. On a success, it notices you and the effect ends; on a failure, the interaction resolves and it remains unable to retain attribution after the interaction.

**Successful Save:** Place an Unwritten Trace on it and remove its Reactions until the start of its next turn.

A creature immune to Charmed is not automatically immune; this is perception-attribution authority. A creature without a mind or sense of subjecthood may be unaffected, while a hive mind, ward network, or spirit collective may use its controlling Source Rule to contest.

#### Counterplay

An ally can use an Action to point you out through touch, a shared sense, a linked spirit, a formation signal, or direct guidance. The target then repeats the save with Advantage. A higher-Source-CL perfect witness, true-name ward, Secret observation law, or artifact surveillance can require an immediate Cultivation Check when the effect begins.

### CL14 — No Trace Returns

Your movement can leave behind an explanation that excludes you.

#### Erase the Last Passage

**Reaction**  
**Trigger:** A creature notices you, a ward identifies you, a tracking effect acquires your trail, or an attack targets you  
**Cost:** 5 Resonance

Move up to half your Speed by spiritual step. You may pass through occupied spaces and ordinary cover during this movement but not sealed solid barriers. You must end in a legal space.

Then choose one result:

- **False Trail:** Create a false spiritual trail from your former space to another point within 30 feet. Lower-Source-CL tracking follows it automatically. Equal authority contests it normally.
- **Blank Interval:** Creatures of your choice that witnessed the movement make a Wisdom saving throw. On a failure, they remember your former and final circumstances but not the route, speed, intermediate spaces, or technique used.
- **Afterimage Victim:** Against the triggering attack, leave a 1-HP afterimage Asset in your former space. If the attack can legally target it, the triggering attack targets the afterimage instead. The afterimage has AC equal to your Cultivation Save DC and vanishes after the attack or at the start of your next turn.
- **Cut the Acquisition:** One ordinary lower-Source-CL tracking lock, scrying lock, scent lock, Resonance lock, or targeting mark on you ends. Equal or higher authority requires a Cultivation Check.

#### Ghost Through the Hold

When Erase the Last Passage moves you while Grappled or Restrained, make a Cultivation Check against the restraint’s escape DC or Source Rule. On a success, the restraint ends and you move. On a failure, you remain in place, but can still choose False Trail or Blank Interval.

#### Soul Splitting — False Author

Your soul fragment can appear to be the source of your Mind Spike or Spiritual Pressure. When you originate either from your space, you may make it appear to originate from the fragment. This changes perceived attribution, not actual range or line of effect, unless another feature already allows the fragment as an origin.

### CL18 — Concept of the Missing Footstep

You unfold a domain in which movement and witness no longer possess a reliable relationship.

**Bonus Action**  
**Cost:** 10 Resonance  
**Area:** 40-foot-radius aura centered on you  
**Duration:** 1 minute  
**Concentration:** Required

The area becomes an **Unwritten Procession**.

#### Unrecorded Movement

When you move at least 5 feet, choose any number of hostile creatures in the aura. Each chosen creature makes a Wisdom saving throw once per turn.

**Failed Save:** Until you next deal damage, touch it, or end your turn without cover or concealment, you are unnoticed by that creature. Your movement does not provoke from it, and it cannot communicate your current route.

**Successful Save:** It can perceive you, but cannot take opportunity attacks against you during that movement.

#### Cut Action From Witness

Once on each of your turns after you damage a creature, use Mind Spike, interact with an object, or cross a ward inside the aura, choose one Witness that failed a save against the Domain this round. Choose one:

- it remembers the result but not your identity as the source;
- it remembers your involvement but not the route or method;
- it cannot communicate the event until the start of your next turn;
- it gains an Unwritten Trace and cannot take Reactions until the start of your next turn.

This cannot erase the event, undo damage, manufacture an innocent culprit, defeat an explicit true-name oath, or alter a permanent record already created by higher authority.

#### Empty Space Assassination

Once during the activation, choose one creature in the aura that currently does not notice you. Move up to your Speed by spiritual step and make one of the following against it:

- one weapon attack with a weapon you are proficient with;
- Mind Spike with maximum damage on its damage dice if it fails the save;
- one single-target Spirit Awakening technique of CL10 or lower that normally costs no more than 5 Resonance, paying its normal cost.

If the attack hits or the target fails its save, add `6d8` Psychic damage and it loses Reactions until the end of your next turn. If it succeeds, it takes half the bonus damage and immediately notices you.

This is one technique resolution and cannot recursively trigger another execution, assassination, or extra-action feature.

#### The World Notices the Wound

At the end of the activation, every creature affected by Cut Action From Witness receives a final Wisdom saving throw. On a success, it reconstructs the missing attribution from context. On a failure, the specific gaps remain for 24 hours, though evidence, testimony, Spiritual Exorcism, Echo Scribe records, mirror confession, perfect witness authority, or investigation can restore the truth.

This capstone does not remove you from history, records, names, karmic consequences, or the memories of creatures outside the Domain.

---

### Normalized Execution Notes

#### Witness Record
For every creature affected by a notice-denial feature, record:

- the sense, ward, remote observer, or shared perception that made it a Witness;
- whether it currently Notices you;
- the event that caused notice or loss of attribution;
- active Unwritten Trace and expiration;
- linked observers or systems that can lawfully share location information;
- Source CL of any perfect-witness, true-name, or surveillance effect.

A hive mind, Formation, ward network, or shared-sense group uses the controlling Source Rule. Affecting one member does not automatically affect every member unless they share one perception controller.

#### Direct Interaction
The following are direct interactions for this tradition: dealing damage, making an attack against the creature, forcing it to save, Grappling or Shoving it, touching it, speaking directly to it, physically blocking it, taking an object it is holding, or activating a feature that expressly identifies it as the subject. Environmental changes not addressed to it are not direct interaction unless they physically collide with or obviously originate from you.

When a direct interaction grants an immediate repeat save, resolve that save before an attack roll or saving throw only when the feature says “before the interaction continues.” On success, the creature Notices you and the interaction proceeds normally. On failure, the interaction proceeds under the feature's restrictions.

#### Plausible False Source
Misattribute the Blow and False Trail can use only a source already present or created by the feature: your former space, an afterimage, a shadow, a visible opening, an existing trail, or another environmental point that could physically or spiritually have produced the evidence. They cannot designate an innocent creature as the attacker, create false spoken testimony, forge a true name, or impose mechanical hostility toward a third party.

#### Afterimage Asset
The Afterimage Victim is a temporary Tiny or Medium Spirit Cultivation Asset matching your apparent size:

- **AC:** your Cultivation Save DC;
- **Hit Points:** 1;
- **Source CL:** your effective Spirit Awakening CL;
- **Duration:** until the triggering attack resolves or the start of your next turn;
- **Immunities:** all conditions;
- **Movement and actions:** none.

It can become the target only if the triggering effect could legally target a creature in that space. Area effects continue to affect their full area.

#### Perfect Witness Collision
When a perfect-witness, true-name ward, Secret observation law, artifact surveillance, or higher-Source-CL record conflicts with Steal the Witness or the Domain, compare Source CL. Lower authority yields. At equal Source CL, make one Cultivation Check when the notice-denial effect first applies. Success allows the printed effect for its duration; failure means that observer continues to Notice you, but other observers are resolved separately.

#### Twenty-Four-Hour Attribution Gaps
At the end of Concept of the Missing Footstep, record for each failed final save exactly which gaps remain: source identity, route or method, communication interval, or location attribution. The underlying event, damage, missing object, opened ward, and physical evidence remain.

A gap is restored by any one of these procedures:

- successful Spiritual Exorcism or equal-authority clarity treatment;
- 10 minutes comparing physical evidence with at least one unaffected witness;
- an Echo Scribe Entry, Mirror Confession, true-name record, or perfect-witness Source Rule directly covering the event;
- a successful Wisdom (Insight), Intelligence (Investigation), or Cultivation Check against your Cultivation Save DC after 10 minutes of reconstruction.

One procedure restores the recorded attribution; it does not reveal unrelated identity or memories.

#### Soul Splitting Expression — False Author
The existing False Author expression is retained. Perceived origin can move to the fragment only for Mind Spike or Spiritual Pressure you activate. The actual range, line of effect, target legality, Source CL, and responsibility remain yours. A perfect witness can contest the false attribution without canceling the underlying technique.

#### Realm Suppression
Unwritten Traces and recorded attribution gaps remain but active benefits above effective CL become unavailable. A maintained Steal the Witness or Unwritten Procession ends if its feature is suppressed. Ending the Domain does not automatically restore a gap whose printed 24-hour duration has begun.

### Integrated Procedure Closure — Unwritten Footprint

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** False Author. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 29. Echo-Step Disciple

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted dueling lineage, afterimage shrine, execution school, reincarnated sword-memory, or soul-fragment combat manual.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Aggressive afterimage movement, repeated positions, duel pressure, marked-target pursuit, and attacks launched from where the soul was a heartbeat ago.  
**Primary role:** Single-target skirmisher, pursuit, reaction defense, line-breaking burst, and high-speed dueling.  
**Sphere Lean:** Sword, Saber, Scoundrel, Sound, Spirit, Space. This tradition grants none of those Spheres.  
**Weapon boundary:** “Echo-Step” is the doctrine’s name, not a proficiency grant. A practitioner may use a trained sword, saber, knife, spear, unarmed strike, Mind Spike, or another legal attack specified by the feature.

> *The body arrives once. The soul arrives at every decision that could have become the killing step.*

Echo-Step Disciples cultivate combat memory so intensely that positions persist after the body leaves them. In a duel, the practitioner appears to attack from a line of abandoned selves. These are not duplicates and do not take turns. They are executable soul-echoes: moments in which the cultivator was ready to strike and has not yet allowed that readiness to disappear.

### Echo Positions

Several features create **Echo Positions**.

- An Echo Position is a 5-foot space you legally occupied during the current or previous turn and deliberately recorded.
- You can maintain a number of Echo Positions equal to your Proficiency Bonus.
- Recording a new position beyond the limit removes the oldest.
- Echo Positions last until the end of your next turn unless a feature extends them.
- An Echo Position is not a creature, object, duplicate, flank provider, or obstruction.
- It is visible to spiritual perception as an afterimage, blade-hum, pressure scar, repeated footfall, or ghostly stance.
- A sealed space, destroyed terrain, or illegal destination removes an Echo Position.

### CL3 — Afterimage Edge

#### Record the Killing Step

Once on each of your turns when you move at least 10 feet, record one space you occupied during that movement as an Echo Position.

#### Strike From the Echo

Once on each of your turns when you use Mind Spike, make an unarmed strike, or make a weapon attack with a weapon you are proficient with, you may treat one Echo Position within 20 feet as the attack’s origin for range, reach, cover, and line of effect.

- You still occupy your actual space.
- The target must be legal from the Echo Position.
- The attack cannot originate from both spaces.
- A melee attack can use an Echo Position adjacent to the target even if you are not adjacent.
- Using an Echo Position this way consumes it after the attack resolves.

If the target is Resonance Marked by you, add your Wisdom modifier to one damage roll of the attack or Mind Spike. This bonus applies once per turn and does not stack with another feature adding the same ability modifier to that damage roll.

#### Step Through the Opening

After Strike From the Echo resolves, you may spend 1 Resonance to move to the consumed Echo Position by spiritual step. This movement does not provoke opportunity attacks.

### CL6 — Echo Counter

You leave the threatened body behind and let the attacker strike the decision you already abandoned.

**Reaction**  
**Trigger:** A creature you can perceive targets you with an attack or enters your reach  
**Cost:** 2 Resonance

Record your current space as an Echo Position, then move 10 feet without provoking opportunity attacks.

If the triggering attack can no longer reach or target you, it misses. Otherwise, you gain `+2 AC` against it.

If the attack misses, choose one:

- the attacker takes `2d8 + Wisdom modifier` Psychic damage;
- use Mind Spike against it, reducing Mind Spike’s damage by one die;
- move to another Echo Position within 20 feet;
- remove its Reactions until the start of its next turn if it is Resonance Marked by you.

#### Cross the Blade-Hum

When a hostile creature moves through or ends movement in one of your Echo Positions, you may consume that Echo Position without using a Reaction. The creature makes a Wisdom saving throw.

**Failed Save:** Its Speed becomes 0 for the rest of the turn and it becomes Resonance Marked until the end of your next turn.

**Successful Save:** Its Speed is reduced by 10 feet for the rest of the turn.

A creature can trigger this once per turn.

### CL10 — Three-Step Soul Execution

You resolve three prepared killing positions as one continuous Spirit Awakening technique.

**Action**  
**Cost:** 5 Resonance

Choose up to three legal origins among your space and your Echo Positions. Each origin must be within 30 feet of the next origin in the sequence.

For each chosen origin, choose one creature legal from that origin. You may choose the same creature more than once. Make a Cultivation Attack for each origin.

**Hit:** `3d8` Psychic, Force, Slashing, or Necrotic damage.

After each attack, you may move to that origin by spiritual step. This movement does not provoke opportunity attacks. Consume every Echo Position used as an origin.

A creature hit more than once takes full damage from the first hit and `2d8` from each later hit. Apply on-hit riders, poison, weapon-delivered effects, and once-per-turn bonuses only to the first hit unless another rule expressly permits multiple delivery.

If all three attacks hit the same Resonance Marked target, it makes a Charisma saving throw after the final hit.

**Failed Save:** It cannot take Reactions, its Speed is halved, and it has Disadvantage on its next Intelligence, Wisdom, or Charisma saving throw before the end of your next turn.

**Successful Save:** It cannot take Reactions until the start of its next turn.

Three-Step Soul Execution is a Spirit Awakening technique, not the Attack action and not three weapon attacks.

### CL14 — Pursuit Without Distance

Once your soul has learned a target’s combat rhythm, escape becomes another recorded position.

#### Pursuit Mark

When you damage a Resonance Marked meaningful hostile creature, you may spend 2 Resonance to convert your Resonance Mark on it into a **Pursuit Mark** lasting for the scene.

- A Pursuit Mark is a special Resonance Mark.
- You can maintain one Pursuit Mark at a time.
- You know the marked creature’s direction and approximate distance while it remains within 1 mile and is not behind stronger concealment.
- The target can remove the mark by spending an Action and succeeding on a Charisma saving throw, receiving Spiritual Exorcism, or crossing a higher-Source-CL boundary that severs pursuit.

#### Follow the Vanishing Point

**Reaction**  
**Trigger:** The creature bearing your Pursuit Mark moves at least 15 feet, teleports, enters invisibility, changes form, crosses a portal, or leaves your current line of sight  
**Cost:** 4 Resonance

Choose one:

- move up to your Speed by spiritual step toward a legal space within 10 feet of its destination;
- move to an Echo Position within 60 feet and use Mind Spike against the target if it is legal from that position;
- if the target teleported or crossed a route, make a Cultivation Check against the movement’s Source Rule. On a success, arrive in a legal space within 10 feet of the destination. On a failure, move up to half your Speed toward the last legal point and learn the route’s authority category.

After arriving, record your space as an Echo Position.

#### Cut the Retreat

Once per round when the pursued creature leaves one of your Echo Positions or attempts to move away from you, you may consume that Echo Position. The target makes a Wisdom saving throw.

**Failed Save:** Its movement ends after 5 feet and it takes `3d8` Psychic damage.

**Successful Save:** Its movement distance is reduced by 10 feet.

#### Soul Splitting — Second Stance

Your soul fragment can maintain one Echo Position of its own. You may use that position as an origin for Strike From the Echo or Three-Step Soul Execution, but doing so destroys the fragment after the technique resolves. Destruction this way does not cause the core Soul Splitting backlash damage.

### CL18 — Hundred Echoes Kill One Moment

You manifest every combat-ready version of your position across a single decisive interval.

**Bonus Action**  
**Cost:** 10 Resonance  
**Duration:** 1 minute  
**Concentration:** Required

You enter the **Hundred-Echo State**.

#### Echo Field

At the start and end of each of your turns, record your current space as an Echo Position without counting against your normal limit. These State-created positions last until the State ends.

You can move through hostile creatures’ spaces, ignore nonmagical difficult terrain, and do not provoke opportunity attacks. You cannot end movement in an occupied space.

#### One Soul, Many Edges

Once on each of your turns when you use Mind Spike, make a weapon attack with a weapon you are proficient with, or activate a single-target Spirit Awakening technique, choose up to three Echo Positions within 60 feet.

After the triggering effect resolves, choose one creature legal from each selected position. Each chosen creature takes `2d8` Psychic or Force damage. A creature chosen multiple times takes damage only once, but if it is your Pursuit Mark target, it takes `4d8` instead.

This is secondary echo damage, not additional attacks and not additional technique activations.

#### Moment of the Final Edge

Once during the State, use an Action to choose one creature within 120 feet that you can perceive or that bears your Pursuit Mark. Select up to six Echo Positions that form a legal sequence ending adjacent to or within 30 feet of the target, depending on your chosen final attack.

Move through the sequence by spiritual step, then choose one:

- make one weapon attack with a weapon you are proficient with;
- use Mind Spike with maximum damage on its damage dice on a failed save;
- make one Cultivation Attack dealing `10d10` Psychic, Force, Slashing, or Necrotic damage on a hit.

On a hit or failed save, the target also makes a Charisma saving throw.

**Failed Save:** Choose two: no Reactions until the end of your next turn; Speed 0 until the start of its next turn; cannot regain Hit Points until the start of its next turn; one active lower-Source-CL movement or concealment effect ends; it is knocked Prone; it is moved 20 feet to a legal space along your echo sequence.

**Successful Save:** Choose one of those effects until the start of its next turn.

If the target’s Source CL is at least 5 lower than yours and it bears your Pursuit Mark, ordinary non-Secret escape, invisibility, and movement defenses cannot prevent the final approach. Equal or higher authority contests normally.

#### After the Last Echo

When the State ends, remove every Echo Position and Pursuit Mark you created. You cannot take Reactions until the start of your next turn as your body and soul agree on which position survived.

---

### Normalized Execution Notes

#### Echo Position Record
Each Echo Position records:

- its exact 5-foot space;
- whether it was created by ordinary movement, Echo Counter, Second Stance, or the Hundred-Echo State;
- the turn and sequence in which it was created;
- its expiration time;
- whether it has been consumed.

An Echo Position is legal only if you actually occupied that space through legal movement when it was recorded. It does not preserve a door, platform, bridge, route, or line of effect that later ceases to exist. If the space becomes solid, ceases to exist, becomes an unknown destination, or is sealed by an authority the Echo cannot cross, remove it immediately. Occupation by another creature does not remove the Echo, but you cannot move into that space unless it is legal when movement resolves.

An Echo Position supplies an attack origin only. It does not supply your body, threaten surrounding spaces, permit opportunity attacks, carry an aura, hold an object, satisfy adjacency for an ally, or allow a creature to target you at the Echo.

#### Strike From the Echo
Choose the Echo Position and target before rolling the attack or resolving Mind Spike. Check range, reach, cover, line of effect, concealment, and target legality from that Echo only. Defensive effects that depend on the attacker’s actual body still measure from your actual space unless they expressly respond to an attack origin.

The Echo is consumed after the attack or save resolves whether the attack hits, misses, succeeds, or fails. Step Through the Opening checks the destination after resolution; if the space is occupied or illegal, you remain in place and do not spend the 1 Resonance.

#### Echo Counter and Cross the Blade-Hum
When Echo Counter triggers from an attack, resolve the movement before the triggering attack roll. When it triggers because a creature enters your reach, pause that creature in the first space that entered your reach, resolve Echo Counter, then resume its remaining movement if legal.

Cross the Blade-Hum triggers when the creature first enters, passes through, or ends movement in the recorded space. Resolve it before later movement from the same activation. The same creature can trigger Cross the Blade-Hum only once per turn regardless of how many Echo Positions it crosses. Consuming an Echo for this feature prevents any later use of that Echo.

#### Three-Step Soul Execution
Declare all selected origins, their order, and their targets before the first Cultivation Attack. Each adjacent pair in the sequence must be within 30 feet and connected by a legal spiritual-step relation. Total cover and sealed boundaries between an origin and its target still apply.

Resolve the attacks in declared order. After each attack, decide whether to move to that origin. Failure or refusal to move does not cancel later attacks if their origins and targets remain legal. Every selected Echo Position is consumed after its attack resolves. A target chosen multiple times receives on-hit riders, poison, weapon delivery, and once-per-turn additions only from the first successful hit unless another Source Rule explicitly permits repeated delivery.

#### Pursuit Mark Record and Removal
A Pursuit Mark records the target, your Source CL when created, creation scene, direction-and-distance limit, and any boundary that currently suppresses it. It remains a special Resonance Mark and counts as your Resonance Mark for features that require one.

The target removes it through one of these procedures:

- use an Action and succeed on the printed Charisma saving throw;
- receive successful Spiritual Exorcism that can remove an external pursuit mark;
- cross or activate an equal-or-higher-Source-CL Boundary, Space, Void, concealment, severance, or route effect and win the normal authority contest;
- end the scene.

A failed removal Action does not reveal your location. Perfect concealment can suppress direction and distance without removing the Mark.

#### Following Movement and Routes
Follow the Vanishing Point resolves after the triggering movement declares its destination but before the mover begins a later unrelated activation. You learn only the destination information the triggering Source Rule normally exposes.

For teleportation or route movement:

- if the destination is known and legal, resolve the printed Cultivation Check;
- if the destination is unknown, sealed, cross-planar, or not a location you could legally reach through the opposing route, you cannot arrive there through this feature;
- on failure, the “last legal point” is the last space along the known traversed route, or the origin if the movement was pathless.

Following never grants passengers, crosses planes by implication, enters an unknown prison, or bypasses a stronger destination seal.

#### Hundred-Echo State
State-created Echo Positions do not count against the normal Proficiency Bonus limit, but each remains a separate recorded space and can be consumed only once. An actual space can hold only one of your Echo Positions at a time; recording it again refreshes that State-created Echo rather than creating duplicates.

For Moment of the Final Edge, declare the complete sequence and final delivery before moving. Every segment must connect legal recorded spaces. You cannot cross a sealed boundary, enter an unknown destination, or use an Echo that has been removed. If the sequence becomes illegal before movement begins, select a shorter legal sequence; if none exists, the Action is not spent and the once-during-the-State use remains available. Once movement begins, later obstruction ends movement at the last legal Echo and the final attack resolves only if legal from that position.

The lower-Source-CL clause overcomes ordinary movement, concealment, and escape defenses only when their Source CL is at least 5 lower than yours. It does not defeat total sealed cover, cross-planar separation, Secret Laws, divine or artifact authority, or an effect that expressly denies the relation without the normal contest.

#### Realm Suppression
Ordinary Echo Positions remain until their listed expiration, but you cannot use a feature above your effective CL. A Pursuit Mark remains as a dormant spiritual record if CL14 is suppressed; it supplies no direction, reaction pursuit, or Cut the Retreat until CL14 returns. Hundred-Echo State ends immediately if CL18 becomes unavailable. Second Stance ends if Soul Splitting or CL14 becomes unavailable.

### Integrated Procedure Closure — Echo-Step Disciple

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Stance. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 30. Law of Near and Far

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Secret Law discovered through a road that never ended, a lover heard across worlds, a prison whose wall was infinitely distant from its door, a star reached in one step, or direct contact with the conceptual distinction between proximity and separation.  
**Classification:** Secret Law.  
**Identity:** Nearness, remoteness, unreachable safety, impossible pursuit, collapsed intervals, and the truth that distance is a relation before it is a measurement.  
**Primary role:** Conceptual mobility, ally rescue, attack denial, pursuit, battlefield separation, and high-authority spatial control.  
**Sphere Lean:** Space, Boundary, Thread, Fate, Spirit. This Secret Law grants none of those Spheres.  
**Authority boundary:** The Law changes the relation of distance. It does not create arbitrary portals, control time, sever ownership, erase existence, or automatically defeat a stronger Boundary, Seal, Formation, Void, or Space Source Rule.

> *The road between two souls is not measured in li. It is measured by what still recognizes the other as reachable.*

Practitioners of the Law of Near and Far discover that distance is partly spiritual agreement. A blade is near because the victim and blade participate in one imminent event. A sanctuary is far because the world refuses the pursuer a relation to it. The Secret Law makes these agreements explicit—and then rewrites them.

### Permanent Price — No Ordinary Measure of Home

Learning this Secret Law permanently alters the practitioner’s relation to place.

Choose one lasting price from the following list and complete the Permanent Price Record in the Normalized Execution Notes:

- one former home, homeland, shrine, or beloved place never again feels spiritually near unless you actively maintain a bond to it;
- you can no longer judge ordinary distance by instinct and must rely on sight, maps, measurement, or deliberate focus outside combat;
- one person you love always feels either painfully near or impossibly far regardless of physical separation;
- ordinary confinement no longer feels safe, and ordinary open space no longer feels free;
- your shadow, voice, reflection, or dreams sometimes arrive before or after you, making your Secret nature identifiable.

This price is not a numerical penalty unless the table agrees on one. It cannot be removed by ordinary retraining, cleansing, or memory alteration. Ordinary retraining cannot abandon the Secret Law. Only the Secret Law Severance procedure in the Normalized Execution Notes or an explicit equal-or-higher-Source-CL rule can end access, and ending access does not automatically restore what was surrendered.

### Near and Far Relations

Several features declare a creature, object, space, or Anchor **Near** or **Far**.

- A relation is between you and one named subject unless the feature says otherwise.
- You can maintain a total number of active Near and Far relations equal to your Proficiency Bonus.
- Creating a relation beyond the limit ends one of your choice.
- A relation lasts for the scene unless ended, consumed, or broken.
- A subject can be Near and Far to different creatures, but cannot be both Near and Far to you at the same time.
- Near does not automatically grant line of sight, line of effect, permission to cross a ward, or the ability to occupy an illegal space.
- Far does not make a subject invisible or invulnerable. It changes specified targeting, movement, and reach relations.
- A willing subject can end its relation as an Action. An unwilling subject can make a Charisma saving throw as an Action, ending it on a success.
- Equal- or higher-Source-CL Boundary, Space, Seal, Formation, Thread, Void, or conceptual effects can contest the relation.

### CL3 — Name What Is Near

#### Near Relation

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance

Choose one willing creature, Resonance Marked creature, unattended object, valid Cultivation Asset, or visible unoccupied space. Declare it **Near** to you for the scene.

While it is Near and within 120 feet:

- you know its direction and approximate distance unless concealed by stronger authority;
- once on each of your turns, after you move at least 5 feet, you may move 10 feet toward it without provoking opportunity attacks;
- Soul Gaze and Spiritual Sense treat it as 30 feet closer for range, minimum actual adjacency;
- if it is a willing creature, it may use its Reaction when you declare it Near to move 5 feet toward you without provoking.

A visible space declared Near ends if it becomes occupied by an unwilling creature, ceases to be legal, or leaves 120 feet.

#### Far Relation

As a Reaction when a creature moves toward you or targets you with a melee attack, spend 1 Resonance and choose that creature. It makes a Charisma saving throw.

**Failed Save:** Declare it Far from you until the start of your next turn. Its current movement toward you costs 2 feet for every 1 foot moved, and its melee reach against you is reduced by 5 feet, minimum 0.

**Successful Save:** Its Speed is reduced by 5 feet for the triggering movement.

This temporary Far relation does not count against your relation limit.

### CL6 — Make the Blow Far

You interpose conceptual remoteness between an attack and its intended victim.

**Reaction**  
**Trigger:** A creature you can perceive targets you or a creature Near to you with an attack or a single-target hostile technique  
**Cost:** 3 Resonance

Choose the attacker or the triggering effect as Far from the protected creature for the resolution of that trigger.

- If the attack or technique no longer has sufficient range or reach, it fails against that target.
- Otherwise, the attack has Disadvantage or the protected creature has Advantage on its saving throw.
- A hostile effect that ignores distance, originates inside the target, follows a true-name link, or uses a higher-Source-CL relation can force a Cultivation Check instead of being automatically made Far.

If the protected creature is Near to you, you may move it 10 feet to a legal space toward you after the trigger resolves, whether it succeeds or fails.

#### Far Shore Counter

If Make the Blow Far causes the attack to miss or the target to succeed on the save, choose one:

- the attacker becomes Resonance Marked until the end of your next turn;
- move yourself 10 feet toward a Near relation;
- move the protected creature 5 additional feet;
- the attacker cannot take Reactions until the start of its next turn.

### CL10 — Collapse the Interval

You make two related points adjacent for one crossing.

**Action or Bonus Action**  
**Range:** 120 feet  
**Cost:** 5 Resonance

Choose yourself or one willing creature you touch, and choose one Near creature, object, Asset, or space within range. Move the traveler to a legal space adjacent to the Near subject by conceptual translation.

- This is not ordinary teleportation, but effects that block teleportation, Space, routes, conceptual movement, or passage can contest it.
- The traveler does not cross the intervening spaces.
- You cannot cross planes, enter an unknown sealed room, bypass a Secret prison automatically, or travel to a subject whose Near relation is being perfectly concealed.
- An unwilling creature cannot be transported.

If used as an Action, you may carry a number of willing creatures adjacent to you up to your Wisdom modifier, minimum one, by paying 2 additional Resonance per additional creature. Every traveler must arrive in a legal adjacent space.

#### Interval Strike

After you personally use Collapse the Interval, you may make one weapon attack with a weapon you are proficient with or use Mind Spike against one creature within legal range of your destination. This does not require an additional Action, but costs 2 Resonance.

You can use Interval Strike once per turn. It cannot be combined with another feature that grants an attack as part of the same movement unless one of them expressly allows the combination.

#### Nearer Than Falling

When you or a Near creature begins falling, you may use your Reaction and spend 2 Resonance. Declare the nearest legal surface within 120 feet Near for the fall and translate the falling creature to a legal space on or adjacent to it. A sealed or hostile surface can contest.

### CL14 — Cast Them to the Far Side

You can make a creature spiritually remote from the battlefield without erasing it from existence.

**Action**  
**Range:** 60 feet  
**Cost:** 7 Resonance  
**Duration:** 1 minute

Choose one creature you can perceive. It makes a Charisma saving throw.

**Failed Save:** The target becomes **Far-Sided**. At the end of each of its turns, it repeats the save, ending the effect on a success.

While Far-Sided:

- every other creature is treated as 30 feet farther away from it for its attacks, hostile techniques, auras, commanded Assets, and voluntary movement toward them;
- it cannot take opportunity attacks;
- it cannot benefit from allied auras, Help, touch effects, or reactions originating from another creature unless the source wins a Cultivation Check against your Source Rule;
- teleportation and route effects it uses have their range halved;
- it remains visible, audible, damageable, and present in its actual space.

**Successful Save:** Until the start of your next turn, its reach and hostile technique ranges are reduced by 10 feet, minimum 5 feet for techniques that normally have range.

#### Far-Side Anchor

When a target fails the initial save, create a conceptual **Far-Side Anchor** in an unoccupied space within 30 feet of it.

- **AC:** your Cultivation Save DC
- **Hit Points:** `5 × Proficiency Bonus`
- **Saving Throws:** uses your Wisdom and Charisma saving throw bonuses
- **Immunities:** Poisoned, Disease, Psychic damage
- **Source CL:** your effective Spirit Awakening CL

Destroying, exorcising, or conceptually reconnecting the Anchor ends Far-Sided immediately. The target and its allies can perceive the Anchor as a distant door, horizon line, receding lantern, endless road, or another symbol of remoteness.

You can maintain one Far-Side Anchor at a time.

#### Soul Splitting — Near Twin

While your soul fragment is within 60 feet, it is always Near to you and does not count against your relation limit. Once per turn, you may exchange spaces with it as a Bonus Action by spending 2 Resonance. This is conceptual translation. The fragment is destroyed after the exchange, but this voluntary destruction does not cause the normal Soul Splitting backlash damage.

### CL18 — World Without Between

You manifest a Secret territory in which you decide which relations remain reachable.

**Action**  
**Range:** 120 feet  
**Area:** 40-foot-radius sphere  
**Cost:** 10 Resonance  
**Duration:** 1 minute  
**Concentration:** Required

Create a **World Without Between** centered on a point you can perceive. The field is a Secret Law Source Rule and a conceptual Domain.

When it appears, designate up to your Wisdom modifier willing creatures, spaces, objects, or Assets in the field as the **Near Constellation**. Designate up to your Proficiency Bonus hostile creatures as the **Far Constellation**. Each unwilling creature makes a Charisma saving throw, avoiding designation on a success.

#### Near Constellation

Members of the Near Constellation:

- know each other’s direction and condition as Bloodied, Unconscious, possessed, or spiritually compromised;
- can move 10 feet toward another Near member at the start of their turns without provoking;
- can originate a touch-range beneficial effect on another Near member within 40 feet as though adjacent, provided line of effect exists and the effect is not an item handoff, Grapple, or physical carry;
- can use a Reaction when another Near member is targeted to move 10 feet toward it;
- may be chosen by your Collapse the Interval without separately maintaining a Near relation.

#### Far Constellation

Members of the Far Constellation:

- treat all creatures outside their own spaces as 20 feet farther away for hostile targeting and movement;
- cannot take opportunity attacks;
- cannot receive Help or reaction-based protection from allies unless the helper succeeds on a Cultivation Check against your Source Rule;
- make a Charisma saving throw the first time each round they teleport, open a route, command a remote Asset, or activate an aura. On a failure, the effect is delayed until the start of their next turn; if its conditions are no longer legal then, it fails without spending the resource.

At the end of each Far creature’s turn, it repeats the save, ending its designation after two total successes during the activation.

#### Rewrite the Constellation

Once on each of your turns, choose one:

- add one willing subject in the field to the Near Constellation;
- require one hostile creature in the field to save against entry into the Far Constellation;
- move one Near creature 20 feet by conceptual translation;
- exchange the positions of two willing Near creatures;
- use Make the Blow Far without spending Resonance;
- use Collapse the Interval on yourself without spending Resonance.

#### No Distance to the Chosen Edge

Once during the activation, choose one creature in the field that is Near to you or belongs to the Far Constellation. For one attack or single-target Spirit Awakening technique, the distance between you and that creature becomes 0 for range and reach while preserving legal line of effect.

Choose one:

- make one weapon attack with a weapon you are proficient with;
- use Mind Spike with maximum damage on its damage dice on a failed save;
- activate one single-target Spirit Awakening technique of CL14 or lower, paying its normal Resonance cost.

If the target is in the Far Constellation and its Source CL is at least 5 lower than yours, ordinary movement, range, cover short of total sealed cover, and non-Secret escape cannot prevent the effect. Equal or higher conceptual, Boundary, Space, Void, Seal, Formation, divine, or artifact authority contests normally.

#### Make Sanctuary Unreachable

Once during the activation, use your Reaction when a Near creature would be reduced to 0 Hit Points, possessed, banished, or struck by a hostile effect. Until the start of that creature’s next turn, declare it Far from every hostile creature in the field.

- Hostile single-target effects lose it as a legal target.
- Area effects already placed still affect its actual space.
- It cannot make attacks or use hostile techniques while protected.
- It may move up to 20 feet toward another Near member without provoking.

A Secret execution, true-name effect, internal possession, effect already inside the creature, or higher-Source-CL authority can contest this sanctuary.

#### End of the World

When the Domain ends, every Near and Far designation created by it ends. Ordinary geometry resumes immediately. Creatures are not moved merely because their relations end.

Using World Without Between leaves a visible or spiritually perceptible sign of your Permanent Price for the remainder of the scene.

---

### Normalized Execution Notes

#### Permanent Price Record
When the Secret Law is learned, record:

- the exact printed price selected;
- the named place, person, condition, or manifestation to which it applies;
- how the price is perceptible to the practitioner;
- how it becomes perceptible to Spiritual Sense after World Without Between is used.

The price supplies no unprinted numerical penalty. A GM or AI cannot add Disadvantage, damage, Exhaustion, a condition, resource loss, or compulsory behavior to the price unless another Source Rule expressly does so.

**Secret Law Severance:** Ordinary retraining, cleansing, memory alteration, death, resurrection, Realm Suppression, or changing Subpaths does not remove the Law or its price. Access ends only when an explicit Source Rule says it can sever a Secret Law and has equal or higher Source CL. Resolve its printed procedure and authority contest. If no such Source Rule is available, the Law cannot be voluntarily abandoned. Ending access does not restore the surrendered relation unless that same Source Rule expressly reconstructs it.

#### Relation Record
Each Near or Far relation records:

- practitioner and named subject;
- Near or Far;
- creation feature and Source CL;
- current range limit;
- duration and relation-limit slot;
- consent status;
- any concealment, Boundary, Space, Seal, Formation, Thread, Void, or conceptual effect suppressing it.

A relation is not a physical tether, object, creature, route, possession, ownership claim, or line of effect. It cannot be transferred, harvested, targeted as an Asset, or used as a passenger route unless a feature says so.

#### Temporary Far Reaction
When Far Relation triggers from movement toward you, pause movement after the creature declares the movement and before it spends the first foot that would reduce its distance to you. On a failed save, the doubled movement cost applies to the qualifying movement for the rest of that activation. When it triggers from a melee attack, resolve the save before the attack roll and recheck reach after the result.

#### Make the Blow Far
Resolve the Reaction after the attack or hostile technique declares its source and target but before attack rolls or saving throws. Recheck only the range, reach, and relation relevant to the protected target. The effect can still affect other legal targets or spaces if its own Source Rule permits them.

The triggering Action, Bonus Action, Reaction, charge, ammunition, or CP is spent normally when the source committed it, even if the protected target becomes illegal, unless the triggering Source Rule expressly refunds it.

#### Collapse the Interval
Record the Near subject used as destination, each traveler, each arrival space, and every passenger cost before movement. Every traveler must be willing when selected and must remain adjacent to the initiating traveler until translation begins.

The destination is one legal unoccupied space adjacent to the Near subject for each traveler. If insufficient legal spaces exist, choose which travelers move before spending additional-passenger Resonance; unplaced travelers remain. A Near unattended object or Asset does not move unless it is the traveler under another legal rule.

#### Far-Sided Movement and Targeting
“Thirty feet farther away” is resolved as follows:

- increase the range or reach required for the Far-Sided creature’s attacks and hostile techniques by 30 feet;
- before it can voluntarily end movement adjacent to, inside the reach of, or in physical contact with another creature, it must have a movement budget at least 30 feet greater than the geometric distance required; spend that additional 30 feet as conceptual approach immediately before entering the final adjacent or contact space;
- if it lacks that movement, it stops in the last legal space before adjacency or contact;
- forced movement, falling, and movement away from another creature are not increased;
- the creature remains physically present and can still be approached, targeted, or affected by others using actual geometry.

For an aura or commanded Asset, add 30 feet to the relation required to include or command another creature. This does not enlarge the Far-Sided creature’s actual space or change area-effect geometry.

#### Far-Side Anchor
The Far-Side Anchor is a stationary Medium conceptual Cultivation Asset and external Anchor occupying one 5-foot space. It takes no turn, cannot move, cannot carry objects, and gains no general saving throw proficiency. Its listed Wisdom and Charisma saving throw bonuses are modifiers only. It is immune to Poisoned, Charmed, Frightened, Grappled, Prone, and Restrained; the printed Psychic immunity remains. It can be repaired only by a feature that repairs Cultivation Assets, Anchors, conceptual structures, or Spirit manifestations.

“Conceptually reconnecting” it means succeeding with a Boundary, Space, Thread, relationship, exorcism, or equivalent Source Rule that expressly restores reachability, using normal Source CL and Cultivation Check procedures. Merely touching the Anchor does not end Far-Sided.

#### Delayed Far-Constellation Activations
When a Far-Constellation creature fails its first save of the round to teleport, open a route, command a remote Asset, or activate an aura:

1. the declared activation consumes its Action, Bonus Action, Reaction, or other timing immediately;
2. record the exact source, target, destination, range, choices, and required resource;
3. do not spend the resource yet;
4. at the start of its next turn, before it takes actions, recheck every legal condition;
5. if legal, spend the resource and resolve the recorded activation;
6. if illegal, the activation fails and the resource is not spent.

The delayed activation cannot be changed, retargeted, upgraded, combined with a new activation, or used to carry a later passenger. If the creature is incapacitated when it would resolve, the activation fails without spending the resource.

#### Domain Designations
When World Without Between appears, record every Near- and Far-Constellation member. Willing subjects can decline or end Near designation as an Action. A hostile creature that succeeds on the entry save is not designated. Rewrite the Constellation records each later addition, removal, translation, exchange, or free core-feature use.

A Far creature’s two successful end-of-turn saves are cumulative during the activation and need not be consecutive. Leaving the Domain ends only that creature’s Domain-created designation; re-entering does not restore it without a new Rewrite the Constellation save.

#### No Distance and Sanctuary
No Distance to the Chosen Edge makes distance 0 only for the one selected delivery. It does not create physical adjacency, opportunity attacks, passengers, item transfer, Grapples, or a persistent route.

Make Sanctuary Unreachable records the protected creature and exact hostile relations suppressed. Area effects already occupying its actual space continue. The protected creature cannot use hostile attacks or techniques, but can take defensive, movement, recovery, exorcism, or aid actions. If a higher-authority effect wins the contest, suppress only the protection against that effect.

#### Realm Suppression
Relations remain recorded but features above effective CL become dormant. Collapse the Interval, Far-Sided, and World Without Between end if their sustaining feature becomes unavailable. The Permanent Price never disappears through Realm Suppression. A Far-Side Anchor disappears when Far-Sided ends.

### Integrated Procedure Closure — Law of Near and Far

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Near Twin. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 31. Compass-Breaking Hand

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted spirit-martial school, battlefield pilgrim lineage, geomantic dueling hall, star-compass inheritance, or teacher who has cultivated motion without accepting a fixed north.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Approach, orbit, withdrawal, orientation, redirection, and authority over the spiritual meaning of direction.  
**Primary role:** Mobile skirmisher, interceptor, positional defender, pursuit breaker, and battlefield reorientation.  
**Sphere Lean:** Athletics, Spirit, Strategy, Space, Formation, and Flowing River. This tradition grants none of those Spheres.  
**Cultivation boundary:** Compass-Breaking Hand does not create unrestricted teleportation, alter the world's cardinal directions, or project bodily force at range. It changes the practitioner's spiritual relation to a chosen Pole and turns completed movement into martial authority.

> *North is only the direction accepted by those who have not yet chosen where heaven should turn.*

### Pole

A **Pole** is the creature, object, Cultivation Asset, Anchor, or fixed space around which you currently interpret combat.

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 1 Resonance  
**Duration:** The scene

Choose one subject you can perceive. It becomes your Pole.

- You can maintain only one Pole. Choosing another ends the previous Pole.
- Choosing a creature as your Pole does not by itself harm, control, mark, reveal, or move it and requires no saving throw.
- If the Pole is a moving subject, distance is measured from the center of its current space except when a Bearing says otherwise.
- If the Pole is a fixed space, record one 5-foot space. Destruction of terrain does not move that Pole, though an effect that removes the space from the battlefield can end it.
- If you and the Pole are on different planes, separated by a sealed conceptual boundary, or unable to participate in the same scene, the Pole becomes dormant. It resumes if the contradiction ends before the scene does.
- While a creature that is your Pole bears your Resonance Mark and remains within 120 feet, you know its direction and whether it is closer than 30 feet, 30–60 feet away, or farther than 60 feet. This does not reveal its exact space through concealment.

### Bearings

At the start of your turn, before moving, you may declare one **Bearing** relative to your Pole. The Pole's position at that moment is the reference point for the declaration until the end of the turn, even if the Pole later moves.

You complete the Bearing as follows:

- **Approach:** You voluntarily move at least 10 feet and end at least 5 feet closer to the reference point than where you began.
- **Orbit:** You voluntarily move at least 10 feet and end at a distance from the reference point no more than 5 feet greater or smaller than where you began.
- **Depart:** You voluntarily move at least 10 feet and end at least 5 feet farther from the reference point than where you began.

Rules for Bearings:

- Measure distance by the shortest legal straight-line distance between spaces, ignoring the path actually traveled.
- Forced movement, falling, being carried, or movement performed by another creature does not complete your Bearing.
- Moving repeatedly between the same spaces does not complete a Bearing unless the movement advanced a meaningful hostile objective.
- You can complete only one declared Bearing per turn.
- When you complete it, gain the corresponding **Bearing token**: Approach, Orbit, or Depart.
- You can hold one token of each type. Gaining a token you already hold refreshes it but does not create another.
- Bearing tokens last for the scene and are not Resonance.

### CL3 — Three-Bearing Footwork

You gain the Pole and Bearing rules above.

#### Compass Strike

Once on each of your turns when you complete your declared Bearing, apply the matching expression below. If you already damaged your Pole with a Martial Strike during the turn, resolve the expression immediately. Otherwise, it applies to the next Martial Strike that damages the Pole before the end of the turn.

- **Approach — Enter the Line:** Deal an additional `1d8` Psychic or Force damage. The Pole cannot take opportunity attacks against you until the start of your next turn.
- **Orbit — Step Beyond the Angle:** Move 5 feet to a legal space. This movement does not provoke opportunity attacks from the Pole. You gain `+2 AC` against attacks made by the Pole until the start of your next turn.
- **Depart — Leave the Needle Behind:** Move up to 10 feet farther from the Pole without provoking opportunity attacks from it. If the Pole is Resonance Marked by you, you may instead require it to make a Strength or Wisdom saving throw. On a failure, move it 5 feet away from you.

Compass Strike is one once-per-turn rider. Extra Attack, echoes, Soul Splitting, reactions, and additional damage packets cannot apply it more than once during the turn.

#### No Blind Side to the Soul

When a creature that is your Pole becomes Hidden from you but remains Resonance Marked and within 60 feet, it does not gain Advantage on its first attack against you solely from being unseen. Total cover, perfect spiritual concealment, invisibility's other effects, and effects that prevent you from perceiving the attack still apply.

### CL6 — Turn the Compass

You can spend a stored Bearing to reorient an attack before it arrives.

**Reaction**  
**Trigger:** Your Pole within 60 feet targets you or a willing creature you can perceive within 15 feet of you with an attack, Grapple, or single-target hostile technique  
**Cost:** 2 Resonance and one matching Bearing token

Choose the expression associated with the token spent.

#### Approach — Intercept the Line

Move up to 10 feet toward the Pole or the protected creature without provoking opportunity attacks from the Pole.

If you end adjacent to the protected creature or within the triggering attack's legal reach or range, you may become the target instead. Use the original attack roll, saving throw procedure, damage, and riders against you. You gain `+2 AC` against an attack roll redirected this way or Advantage on the first saving throw required by the triggering technique.

If you cannot legally become the target, the protected creature instead gains `+2 AC` or Advantage on its saving throw against the trigger.

#### Orbit — Leave the Attack Facing Empty Air

Move the protected willing creature up to 10 feet to a legal space that is no more than 5 feet closer to or farther from the Pole than its original space. This movement does not provoke opportunity attacks from the Pole.

The triggering attack has Disadvantage. The protected creature has Advantage on a saving throw against the triggering Grapple or technique instead.

#### Depart — Put Distance Inside the Blow

Move the protected willing creature up to 10 feet farther from the Pole without provoking opportunity attacks from it.

Recheck reach, range, line of effect, and legal target after the movement:

- If the trigger no longer has a legal target, it fails against that creature. A resource committed solely to the failed attack or technique is spent unless its Source Rule says otherwise.
- If the trigger remains legal, the protected creature gains `+2 AC` or Advantage on its saving throw.

Turn the Compass does not move an unwilling protected creature and does not escape an existing Grapple, Restrained effect, sealed area, or carried state unless the movement remains legal under that effect.

#### Read Their Bearing

Once per round when your Pole voluntarily completes Approach, Orbit, or Depart relative to the space you occupied at the start of its turn, you gain the corresponding Bearing token. The Pole must be a meaningful hostile creature and must have moved at least 10 feet. Its forced movement does not qualify.

### CL10 — Break the Four Directions

You collapse completed movement into one decisive martial line.

**Action**  
**Range:** Your reach after the movement below  
**Cost:** 5 Resonance  
**Requirement:** Your Pole is a meaningful hostile creature or hostile Cultivation Asset you can perceive within 60 feet

Spend one, two, or three different Bearing tokens. For each token spent, you may first move up to 10 feet by spiritual step. Each segment must complete the corresponding movement category relative to the Pole's position when the activation began. These segments:

- do not provoke opportunity attacks from the Pole;
- cannot cross a wall, sealed boundary, or illegal space;
- do not end Grappled or Restrained unless you first win the required contest;
- are one movement created by this activation, not separate movement activations.

After the movement, make one cultivation attack against the Pole through an unarmed strike or a weapon you are proficient with. Use your Cultivation Attack Modifier instead of the normal attack modifier for this attack.

**Hit:** The attack deals its normal damage plus `2d8 + 1d8 for each Bearing spent` Psychic or Force damage. Apply each matching rider:

- **Approach:** Move the Pole up to 10 feet toward you and Resonance Mark it until the end of your next turn. A creature at least two size categories larger than you or a creature protected by equal-or-higher bodily, gravity, Space, or anchoring authority can make a Strength saving throw to prevent the movement.
- **Orbit:** The Pole cannot take Reactions and has Disadvantage on its next attack roll before the end of its next turn.
- **Depart:** Move the Pole up to 15 feet away from you on a failed Strength or Wisdom saving throw. You may then move 10 feet away from it without provoking opportunity attacks from it.

**Miss:** You may move 5 feet in the category of one Bearing spent. No damage or hostile rider occurs.

Break the Four Directions is one attack and one Spirit Awakening technique. It cannot become an Attack action, deliver a full multi-packet Forged Technique, or activate a second movement-granting attack feature.

### CL14 — No Fixed Compass

Your soul can continue a direction even when the body is constrained by ordinary geometry.

#### Direction Without Footing

Your Speed increases by 10 feet.

While completing a declared Bearing, you may move across liquid, narrow surfaces, unstable terrain, vertical surfaces, and open gaps as though they were stable ground. You fall at the end of the turn unless you reach a supporting space or another rule keeps you aloft. This is a spiritual step, not flight.

Nonmagical difficult terrain does not cost you extra movement while completing a Bearing.

#### Break the Restraining Direction

Once on each of your turns when a Grappled, Restrained, pinned, tethered, or similar effect prevents movement required by your declared Bearing, you may spend 2 Resonance and make a Cultivation Check against the effect's escape DC or Source Rule.

- **Success:** End one ordinary Grappled or Restrained effect on yourself, or suppress one equal-authority movement restriction until the end of the turn. You may then continue moving.
- **Failure:** The restriction remains. You do not spend movement that the restriction made illegal, but you cannot attempt this procedure against the same effect again during the turn.
- **Higher authority:** On success, suppress only the expression preventing the current movement unless the effect's own rules permit complete escape.

#### Bearing Without Name

Once per turn when you spend a Bearing token, you may treat it as either of the other two Bearings for one printed rider. The movement you already performed is not rewritten; only the rider changes.

#### Soul Splitting — Counter-Needle

While your Soul Fragment is within 60 feet of your Pole:

- you may originate Turn the Compass or Break the Four Directions from yourself or the fragment, chosen when activated;
- range, line of effect, and movement are measured from the chosen origin;
- you remain the only attacker and mover unless the feature expressly moves the fragment;
- after you spend a Bearing token, the fragment may move 10 feet without an action at the end of the activation.

Once per turn after that movement, if the fragment ends within 10 feet of your Resonance Marked Pole, impose one ordinary Spiritual Pressure effect on the Pole until the start of your next turn.

The fragment cannot generate Bearing tokens, complete Bearings for you, or use Break the Four Directions independently.

### CL18 — Heaven Has No Fixed North

You manifest a battlefield in which orientation follows cultivated intent rather than passive geography.

**Bonus Action**  
**Cost:** 10 Resonance  
**Area:** 40-foot-radius aura centered on you  
**Duration:** 1 minute  
**Concentration:** Required

The aura is your **Compass Domain** and moves with you.

#### Chosen Bearings

At the start of each chosen ally's turn in the Domain, it may declare Approach, Orbit, or Depart relative to you. If it completes that movement category during the turn, it gains the matching benefit until the start of its next turn:

- **Approach:** Temporary Hit Points equal to `2 × Proficiency Bonus`.
- **Orbit:** `+2 AC` against opportunity attacks and attacks made as Reactions.
- **Depart:** 10 feet of additional movement that must be used before the turn ends.

A creature can gain one Chosen Bearing benefit per turn. These benefits do not create your Bearing tokens.

#### False North

At the start of each of your turns, choose one hostile creature in the Domain as your False North until the start of your next turn. It counts as your Pole without ending your underlying Pole.

You gain one temporary token of each Bearing relative to the False North. These temporary tokens expire at the start of your next turn and cannot be carried outside the Domain.

#### Turn the Whole Field

**Bonus Action**  
**Limit:** Once per turn

Choose one Resonance Marked hostile creature in the Domain. It makes a Wisdom saving throw. Choose Approach, Orbit, or Depart relative to you.

- **Failed Save:** Move it up to 15 feet in the chosen category, and it cannot take Reactions until the start of its next turn.
- **Successful Save:** Move it 5 feet in the chosen category if a legal space exists. It retains its Reactions.

For Orbit, the final space must be within 5 feet of the creature's original distance from you. A creature protected by higher-Source-CL anchoring, Space, Formation, Boundary, or bodily authority can force a Cultivation Check.

#### Compass-Breaking Procession

Once on each of your turns, you may use Break the Four Directions against your False North without paying its Resonance cost. You may spend no more than two temporary Bearing tokens on this free use, and its added damage is `2d8 + 1d8 per token spent`. You cannot also use a paid Break the Four Directions during the same turn.

#### No Direction of Escape

Once during the activation, when a Resonance Marked hostile creature in the Domain teleports, uses conceptual movement, enters a route, or crosses the Domain's boundary, you may use your Reaction to contest that movement.

Make a Cultivation Check against the movement's Source Rule.

- **Success:** Choose one result:
  - If the movement has a traversed path, it ends at the last legal space no farther than half the declared distance from its origin.
  - If it is teleportation or another pathless relocation, it arrives in a legal space you choose within 10 feet of the geometric halfway point between origin and declared destination; if no such space exists, it arrives in the nearest legal space to that midpoint that the movement's own Source Rule could reach.
  - It arrives in the nearest legal space still inside the Domain.
  - It completes the movement, and you move to a legal space within 10 feet of its destination.
- **Failure:** The movement resolves normally, but you learn its destination direction and whether it crossed Space, Boundary, Time, Formation, Void, or another route authority.

No Direction of Escape cannot follow a creature across planes or into an unknown sealed location unless the opposing Source Rule already permits that relation.

#### Domain Collision and Ending

A conflicting Domain that fixes direction, seals movement, controls gravity, establishes absolute geometry, or denies conceptual relation contests by Source CL and then Cultivation Check if necessary. Losing the contest suppresses only the contradictory Compass expression.

When the Domain ends, temporary Bearings and False North end. Creatures are not moved merely because ordinary orientation returns.

### Procedural Parity — Compass-Breaking Hand

#### Declaration and Resolution Order

1. At the start of your turn, record the Pole's reference position and declare one Bearing.
2. Complete voluntary movement using that fixed reference position.
3. Gain or refresh the corresponding token.
4. Resolve Compass Strike when its Martial Strike condition is met.
5. Spend tokens only after they exist; a token cannot pay for the movement that generated it unless the feature expressly says so.

#### Source CL and Realm Interaction

Ordinary movement and equal-geometry combat use the printed distances. Gravity, Space, Boundary, Formation, Seal, Domain, or higher-Realm effects contest only when they directly prevent or redefine the movement. Compass-Breaking Hand does not automatically override a superior route or prison.

#### Assets, Anchors, Fields, and Companions

A Pole can be an Asset or external Anchor. Choosing it does not reveal a concealed Anchor, make an untargetable Asset targetable, or bypass its defenses. A companion can be a willing Pole, but movement around an ally cannot generate hostile benefits or Read Their Bearing tokens.

#### Failure, Persistence, and Recovery

Bearing tokens last for the scene. Failed attacks spend tokens committed to Break the Four Directions. A dormant Pole does not refund Resonance. No feature requires a rest counter.

#### Worked Adjudication

A cultivator begins 30 feet from her Pole, declares Orbit, moves 20 feet around a wall, and ends 30 feet from the Pole's recorded start position. She completes Orbit even though the path was not circular. If the wall blocked legal movement, she could not pass through it. If the Pole was pushed during her turn, its recorded start position still determines whether Orbit was completed.

---

### Normalized Execution Notes

#### Pole Record
The Pole record contains its exact subject, space if fixed, current plane, Source CL if it is an Asset or Anchor, creation cost, and dormant status. Selecting a creature does not reveal it through concealment. If a concealed moving Pole cannot be precisely located, direction bands from a Resonance Mark remain available, but features requiring perception, a target, or a legal space still fail normally.

A fixed-space Pole is a relation to that battlefield space, not an Anchor or object. It cannot be attacked, moved, repaired, carried, or used after the space ceases to exist.

#### Bearing Record
At the start of the turn, record your starting space, the Pole’s reference space, and declared Bearing. Measure completion from those two recorded spaces after voluntary movement. Teleportation or conceptual movement counts only if you voluntarily used it and the feature does not forbid it. Forced movement never completes the declaration, but it changes your actual position from which later voluntary movement is measured.

A token records its type and remains until spent or the scene ends. Temporary Domain tokens are separately labeled and expire at the start of your next turn.

#### Turn the Compass
Declare the protected creature and token before movement. Approach can redirect only a single-target attack, Grapple, or hostile technique that could legally affect you after movement. If the trigger has multiple targets, only the protected creature’s portion can be redirected. Use the source’s original attack roll or save DC; do not reroll merely because the target changed.

Orbit and Depart check every destination before movement. If the full distance is illegal, move the creature to the farthest legal space along the chosen path only when that path remains in the required category; otherwise it does not move and still receives the printed AC or save benefit.

#### Break the Four Directions
Declare tokens, movement segments, final attack delivery, and damage type before the first movement. Each segment must satisfy its token relative to the Pole’s activation-start position. A token whose segment cannot be legally completed is not spent and supplies no damage or rider; the practitioner can continue with the remaining declared legal segments.

The Approach size clause treats “substantially larger” as at least two size categories larger than the practitioner. This definition changes no creature’s size and does not override an explicit immovability rule.

#### Counter-Needle
The Soul Fragment origin is selected at activation. If the fragment is the origin, the practitioner still spends tokens, makes the attack, receives consequences, and performs any movement that refers to “you.” The fragment moves only where Counter-Needle expressly moves it. Destroying or suppressing the fragment ends its origin option but does not remove the practitioner’s Pole or tokens.

#### Compass Domain Ally Designation
A “chosen ally” is any willing creature you designate when it begins its turn in the Domain. The designation lasts for that turn, requires no action, and can be refused. There is no additional numerical cap beyond the number of willing allies whose turns occur in the Domain. One creature receives at most one Chosen Bearing benefit on its turn.

#### Turn the Whole Field
For Approach or Depart, choose a straight or curved legal path whose final space is respectively closer to or farther from you than the starting space. For Orbit, the final distance must remain within 5 feet of the starting distance. If no legal space exists for the successful-save 5-foot movement, no movement occurs and the creature retains Reactions as printed.

#### No Direction of Escape
Record origin, declared destination, movement type, Source CL, and whether the movement has a path. A midpoint destination must be a space the opposing movement could legally reach. If the destination is unknown, cross-planar, or sealed from your perception, only the “nearest legal space still inside the Domain” result or the failure information result can apply unless another Source Rule already establishes a legal relation.

#### Realm Suppression
The Pole and stored tokens remain recorded, but features above effective CL cannot use them. The Compass Domain ends if CL18 becomes unavailable. Direction Without Footing and higher movement permissions end immediately when their feature is suppressed; this can cause falling under ordinary rules.

### Integrated Procedure Closure — Compass-Breaking Hand

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Counter-Needle. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 32. Equal Measure Scripture

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted adjudicator-monastery, dueling court, debt-temple, spirit constable lineage, battlefield mediator, or teacher who survived an unequal heavenly judgment.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Reciprocity, proportional answer, accepted consequence, counterforce, and refusing an exchange in which only one side pays.  
**Primary role:** Reactive defender, martial counterattacker, ally protection, forced-movement resistance, and punishment of repeated aggression.  
**Sphere Lean:** Spirit, Karma, Oaths, Strategy, Force, and Medicine. This tradition grants none of those Spheres.  
**Cultivation boundary:** Equal Measure Scripture does not determine moral guilt, create karmic debt, reverse every injury, or copy another technique. It records broad categories of hostile consequence and returns a proportionate martial answer.

> *Heaven may forgive an imbalance. The hand remembers it.*

### Measures

You can hold three kinds of **Measure**:

- **Impact:** bodily harm, direct destructive force, or loss of Hit Points.
- **Motion:** forced movement, Prone, Grappled, Restrained, or denial of meaningful movement.
- **Intent:** hostile spiritual or mental influence, a failed Intelligence, Wisdom, or Charisma saving throw, possession pressure, fear, charm, command, or identity disturbance.

You can hold one Measure of each kind. A Measure lasts for the scene and is not Resonance.

#### Receiving a Measure

Once per round, after one hostile activation fully resolves, gain one Measure for which it qualified if the activation meaningfully affected you or a willing creature bearing your Resonance Mark within 30 feet.

- Gain **Impact** if the activation caused the subject to lose Hit Points equal to at least your Proficiency Bonus.
- Gain **Motion** if it moved the subject at least 5 feet against its will, knocked it Prone, Grappled or Restrained it, or prevented at least 10 feet of movement the subject was legally attempting.
- Gain **Intent** if it caused the subject to fail an Intelligence, Wisdom, or Charisma saving throw or imposed a hostile mental, emotional, spiritual, possession, or identity effect without a save.

If one activation qualifies for multiple Measures, choose one. You cannot receive and spend a Measure during the same triggering activation. Damage or effects voluntarily accepted principally to generate a Measure do not qualify.

### CL3 — Receive and Return

You gain the Measure rules above.

#### Measured Return

Once on each of your turns, when a Martial Strike damages a meaningful hostile creature, you may spend one Measure and apply its expression.

If you use Mind Spike, the expression occurs on a failed save. On a successful save, only Mind Spike's normal result occurs and the Measure is not spent.

- **Impact — Weight for Weight:** Deal an additional `1d8` Psychic or Force damage. You gain Temporary Hit Points equal to your Wisdom modifier + Proficiency Bonus.
- **Motion — Step for Step:** Move yourself up to 10 feet without provoking opportunity attacks from the target, or require the target to make a Strength or Wisdom saving throw. On a failure, move it up to 10 feet. On a success, move it 5 feet if a legal space exists.
- **Intent — Will for Will:** Resonance Mark the target until the end of your next turn and impose one ordinary Spiritual Pressure effect on it.

Measured Return cannot spend more than one Measure on the same Martial Strike.

#### Know the Weight

When Soul Gaze examines a creature, effect, Asset, or Anchor that caused you to receive a Measure during the scene, you also learn:

- which of Impact, Motion, or Intent was its primary expression;
- whether the Source CL was lower than, equal to, or higher than yours;
- whether the effect depended on a weapon, body, spirit, Asset, Anchor, Domain, Formation, possession, or another continuing link.

You do not automatically learn exact statistics, hidden techniques, or protected names.

### CL6 — Exact Counterweight

You can spend a stored Measure to reduce a matching consequence before it is finalized.

**Reaction**  
**Trigger:** You or a willing creature bearing your Resonance Mark within 30 feet is affected by a hostile activation matching a Measure you hold  
**Cost:** 2 Resonance and the matching Measure

Choose the corresponding procedure.

#### Impact Counterweight

Reduce one instance of triggering damage by `3d8 + Wisdom modifier` after Resistance and before Temporary Hit Points.

If this reduces the damage to 0, the source takes Psychic damage equal to your Wisdom modifier + Proficiency Bonus and becomes Resonance Marked until the end of your next turn, provided it is a creature within 60 feet that you can perceive or spiritually locate through your mark.

Impact Counterweight does not reduce Hit Point costs, self-inflicted sacrifice, maximum-Hit-Point reduction, Exhaustion, cultivation harm, or damage that expressly cannot be reduced unless you win the relevant authority contest.

#### Motion Counterweight

Choose one:

- reduce forced movement by up to 20 feet;
- prevent the target from being knocked Prone;
- grant Advantage on the triggering check or save against becoming Grappled or Restrained;
- if the effect imposed Grappled or Restrained without a check or save, make a Cultivation Check against its Source Rule. On a success, suppress that condition until the start of the protected creature's next turn.

If all forced movement is prevented or the protected creature avoids the condition, it may move 5 feet to a legal space without provoking opportunity attacks from the source.

#### Intent Counterweight

If the trigger allows an Intelligence, Wisdom, or Charisma saving throw, add `1d6` to the roll after seeing the d20 but before the outcome is finalized.

If the trigger imposed an ordinary lower-Source-CL effect without a save, make a Cultivation Check against its Source Rule. On a success, suppress one mental, emotional, spiritual, possession, command, or identity expression until the start of the protected creature's next turn.

If the added die changes a failure into a success or the suppression succeeds, impose one ordinary Spiritual Pressure effect on the source until the start of your next turn if it is within 60 feet and can be affected by spiritual authority.

#### No Borrowing from the Same Blow

A Measure gained from a hostile activation becomes available only after that activation and every linked damage packet, movement, condition, and rider have resolved. It cannot pay for Exact Counterweight against the activation that created it.

### CL10 — Threefold Recompense

You return one or more completed Measures through a single martial judgment.

**Action**  
**Range:** Martial Strike range  
**Cost:** 5 Resonance  
**Target:** One meaningful hostile creature bearing your Resonance Mark

Spend one, two, or three different Measures, then make one Martial Strike against the target.

- If you use a weapon or unarmed strike, resolve its normal attack roll.
- If you use Mind Spike, resolve its normal Wisdom saving throw.

**Hit or Failed Save:** The Martial Strike deals its normal damage plus `2d8 + 1d8 for each Measure spent` Psychic or Force damage. Apply every matching rider below.

**Miss:** No added damage or riders occur. Measures are spent.

**Successful Mind Spike Save:** The target takes Mind Spike's normal half damage plus half of the added dice. It suffers no Measure rider. Measures are spent.

#### Impact Recompense

The target cannot reduce the added damage with Temporary Hit Points, though Temporary Hit Points still absorb its normal Martial Strike damage. This does not bypass Resistance or Immunity.

#### Motion Recompense

Move yourself to a legal space adjacent to the target before damage is applied, or move the target up to 15 feet after damage on a failed Strength or Wisdom saving throw. This movement does not provoke opportunity attacks from the target.

#### Intent Recompense

Impose an exceptional pressure package consisting of two different ordinary Spiritual Pressure effects until the start of your next turn.

Threefold Recompense is one activation and cannot generate a new Measure from its own damage, movement, or Pressure.

### CL14 — The Scales Do Not Tremble

#### Convert the Measure

**Bonus Action**  
**Cost:** 1 Resonance  
**Limit:** Once per turn

Convert one Measure you hold into either of the other two kinds. You cannot use this to hold more than one Measure of the same kind.

#### Counterweight Becomes Counterstrike

Once per round, if Exact Counterweight causes one of the following results, you may make one Martial Strike against the hostile source as part of the same Reaction:

- Impact Counterweight reduces the damage to 0;
- Motion Counterweight prevents all forced movement or avoids the condition;
- Intent Counterweight changes a failed save to a success or successfully suppresses the effect.

The source must be within the normal range of the chosen Martial Strike. A weapon or unarmed strike uses its normal attack. Mind Spike reduces its damage by one die, minimum one die. This strike cannot use Measured Return or Threefold Recompense and cannot grant another Reaction.

#### Bear the Unequal Burden

**Reaction**  
**Trigger:** A willing Resonance Marked creature within 30 feet would receive an Impact, Motion, or Intent consequence and you do not hold the matching Measure  
**Cost:** 3 Resonance

Transfer one discrete matching consequence to yourself before it resolves:

- one instance of damage;
- one forced movement, Prone, Grappled, or Restrained result;
- one ordinary mental, emotional, spiritual, possession, command, or identity effect.

You become the target for that consequence and resolve it using your defenses, actual position, and legal immunities. If it cannot legally affect you, it is not erased; the original creature remains the target.

After the transferred consequence resolves, gain the matching Measure. Bear the Unequal Burden cannot transfer death, permanent transformation, maximum-Hit-Point reduction, cultivation-system destruction, Soul Anchor severance, or higher-authority effects without a successful Cultivation Check.

You cannot use Bear the Unequal Burden and Exact Counterweight on the same trigger because both require your Reaction.

#### Soul Splitting — Second Pan

Your Soul Fragment can hold one Measure transferred from you at the end of your turn. Transfer requires no action and does not create a duplicate Measure.

While the fragment holds a Measure:

- you may originate Exact Counterweight from the fragment, protecting a creature within 30 feet of it;
- the fragment spends the Measure when the feature is used;
- if the fragment is destroyed, the held Measure is lost before Soul Splitting's destruction effects resolve.

Once per turn after you spend a Measure through the fragment, it may move 15 feet and grant one willing creature within 10 feet Temporary Hit Points equal to your Proficiency Bonus.

### CL18 — Court of Equal Heaven

You manifest a spiritual court in which hostile consequence cannot remain one-sided.

**Action**  
**Cost:** 10 Resonance  
**Area:** 40-foot-radius aura centered on you  
**Duration:** 1 minute  
**Concentration:** Required

The aura is your **Court of Equal Heaven Domain** and moves with you.

#### Debts of the Aggressor

A hostile creature in the Domain gains one **Debt** of the corresponding kind the first time each round one of its activations causes a chosen ally in the Domain to receive:

- qualifying damage for Impact;
- qualifying movement or restraint for Motion;
- a qualifying spiritual or mental consequence for Intent.

A creature can hold one Debt of each kind. One activation creates only one Debt, chosen by you if several qualify. Debts are visible to Spiritual Sense and end when the creature leaves the Domain or the Domain ends.

#### Any Hand May Answer

Once on each turn when a chosen ally damages a creature with at least one Debt, that ally may discharge one Debt and apply its matching answer:

- **Impact:** Deal an additional `3d8` Psychic or Force damage.
- **Motion:** Move up to 15 feet without provoking opportunity attacks from the indebted creature, or require it to make a Strength or Wisdom saving throw and move it up to 15 feet on a failure or 5 feet on a success.
- **Intent:** Impose one ordinary Spiritual Pressure effect and grant the ally Advantage on its next Intelligence, Wisdom, or Charisma saving throw before the start of its next turn.

A creature can benefit from Any Hand May Answer only once per turn. The added damage and movement cannot generate Measures or new Debts.

#### Nothing Without Answer

Once per round, you may use Exact Counterweight without spending a stored Measure if the hostile source holds the matching Debt. Discharge that Debt instead. You still spend Resonance and your Reaction.

#### Perfect Recompense

Once during the activation, use Threefold Recompense without paying its Resonance cost against a creature in the Domain. You may discharge its Debts as though they were Measures you held.

If all three Debts are discharged and the Martial Strike hits or Mind Spike fails its save, the target also:

- cannot take Reactions;
- has Speed 0;
- has Disadvantage on its next Intelligence, Wisdom, or Charisma saving throw;

until the start of your next turn. This is one exceptional judgment package, not three conditions.

#### Equal Court Is Not Moral Judgment

The Domain records hostile consequence, not justice, innocence, ownership, lawful punishment, karmic merit, or consent. It cannot force restitution, transfer permanent wounds, revive the dead, or determine who deserved an action.

#### Domain Collision and Ending

Karma, Oath, Contract, Sovereignty, Fate, divine judgment, artifact law, or higher-Source-CL reciprocity can contest a Debt or answer that directly contradicts its authority. Losing the contest suppresses only that Debt or answer.

When the Domain ends, all Debts end. Your personal Measures remain until the scene ends.

### Procedural Parity — Equal Measure Scripture

#### Declaration and Resolution Order

1. Resolve the hostile activation completely.
2. Determine whether Impact, Motion, or Intent qualified.
3. Gain no more than one Measure and no more than once per round.
4. A Measure cannot be spent against the activation that created it.
5. Resolve Measured Return or Threefold Recompense only after its Martial Strike hits or Mind Spike fails its save.

#### Source CL and Realm Interaction

Exact Counterweight automatically handles ordinary printed combat consequences within its values. Permanent harm, cultivation-system damage, true-name effects, possession by higher authority, divine judgment, or conceptual erasure require the printed contest and cannot be converted into ordinary damage by inference.

#### Assets, Anchors, Fields, and Companions

Damage to an Asset can generate Impact only if the Asset is a meaningful allied participant and bears your Resonance Mark where legally possible. An Anchor's suppression, movement, or destruction uses its own profile. A companion's injury can qualify, but harmless companion attacks cannot farm Measures or Debts.

#### Failure, Persistence, and Recovery

Measures last for the scene. Failed Threefold Recompense spends them. Debts exist only in the Domain. No feature restores Resonance, Hit Dice, or limited uses through staged exchanges.

#### Worked Adjudication

A hostile technique deals 12 damage, pushes a marked ally 10 feet, and frightens it after one failed Wisdom save. After the entire activation resolves, the practitioner chooses one Measure—Impact, Motion, or Intent—not all three. That Measure cannot be used to reduce the same technique. On a later round it can pay for the matching Counterweight or Recompense.

---

### Normalized Execution Notes

#### Measure Record
Each Measure records its type, the qualifying hostile activation, protected subject, source creature or Source Rule, and round gained. One activation can create only one Measure even if it contains multiple attacks, damage packets, movements, or conditions. “Fully resolves” includes every linked rider, repeated hit, triggered movement, and condition caused by that activation.

Impact uses Hit Points actually lost after Resistance, damage reduction, and Temporary Hit Points. Motion requires involuntary movement or denied movement matching the printed thresholds. Intent requires a failed listed save or a hostile listed effect imposed without a save. An effect voluntarily accepted primarily to generate a Measure does not qualify even if it later becomes harmful.

#### Measured Return and Mind Spike
For a weapon or unarmed strike, declare the Measure after the attack hits but before damage is rolled. For Mind Spike, declare the intended Measure before the target rolls its save; spend it only on a failed save. On a successful save, the Measure remains and no Measured Return expression occurs.

#### Exact Counterweight Ordering
Resolve Resistance first for Impact, then Impact Counterweight, then Temporary Hit Points. Motion Counterweight resolves before forced movement or the relevant condition is applied. Intent Counterweight resolves after the d20 is seen but before success or failure is announced.

If a hostile activation contains multiple matching discrete consequences, Exact Counterweight affects one selected instance unless the feature expressly says otherwise. It does not cancel later packets from the same activation.

#### Bear the Unequal Burden
Record the one transferred consequence before it resolves. Change only its target; preserve source, Source CL, damage type, amount, save DC, duration, end conditions, and linked Anchor. Recalculate only facts that must use the new target, such as actual position, immunities, or legal anatomy.

A consequence that cannot legally exist on the practitioner remains on the original target; it is not erased. Transferring a Grapple, swallowed state, enclosure, or possession requires the source to be able to establish the corresponding physical or spiritual relation to the practitioner. Otherwise the transfer fails and Resonance is not spent.

#### Second Pan
The fragment holds one existing Measure, not a copy. Record the transferred type and source. If Realm Suppression removes Soul Splitting or CL14, return the held Measure to the practitioner if a slot of that type is empty; otherwise it is lost. This suppression return occurs before the fragment ends.

#### Domain Allies and Debts
When Court of Equal Heaven appears, designate any number of willing creatures in the Domain as chosen allies. A willing creature entering later can be designated immediately; it can withdraw consent at any time. A Debt record contains type, indebted creature, qualifying activation, affected ally, round created, and whether discharged.

**Any Hand May Answer is global once per turn across the Domain.** After one chosen ally resolves it on a turn, no other ally can resolve it during that same turn. A different ally can resolve it on a later creature’s turn in the same round. Each creature can benefit no more than once on that turn, as already printed.

The first qualifying activation by an aggressor each round creates at most one Debt. Later activations by that aggressor in the same round do not create another Debt, even of a different type, unless a feature expressly says so.

#### Perfect Recompense
Declare which Debts substitute for Measures before making the Martial Strike. Debts are discharged when committed, even on a miss or successful Mind Spike save, matching Threefold Recompense’s ordinary Measure-spend rule. The three-condition judgment package is one effect for cleansing and suppression.

#### Realm Suppression
Measures and Debts remain recorded but cannot power features above effective CL. Domain Debts end when the Domain ends or CL18 becomes unavailable. A Measure held by the practitioner remains until scene end. Counterweight reductions already resolved are not reversed.

### Integrated Procedure Closure — Equal Measure Scripture

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Pan. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 33. Plain-Truth Fist

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted vowless monastery, honest-duel lineage, spirit magistrate school, confession hall, battlefield witness inheritance, or teacher who has cultivated unity between word and deed.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Declared intent, commitment, visible purpose, anti-feint pressure, and spiritual authority gained by doing exactly what one said.  
**Primary role:** Duelist, pursuer, guardian, anti-deception combatant, and controller of predictable hostile intent.  
**Sphere Lean:** Spirit, Insight, Oaths, Strategy, Mind, and Scoundrel. This tradition grants none of those Spheres.  
**Cultivation boundary:** Plain-Truth Fist does not compel honesty in all speech, prove objective truth, create binding contracts, or erase tactical deception. It turns a deliberately declared combat deed into a temporary spiritual law and punishes contradiction under a printed procedure.

> *A feint deceives the eye. A true fist gives heaven time to watch.*

### Open Declaration

At the start of your turn, before moving or taking an Action or Bonus Action, you may make one **Open Declaration**. It is audible or spiritually perceptible to creatures within 60 feet even if spoken silently through the soul. Ordinary silence does not conceal it from Spiritual Sense.

Choose one meaningful subject you can perceive and one deed:

#### Challenge

Name one hostile creature. Complete the declaration by damaging it with a Martial Strike before the end of the turn.

#### Pursuit

Name one hostile creature. Complete the declaration by voluntarily moving at least 15 feet and ending at least 10 feet closer to it than where you began.

#### Guard

Name one willing creature, Cultivation Asset, or external Anchor within 30 feet. Until the end of the turn, remain within 10 feet of it and complete at least one of the following:

- use a Reaction or feature to reduce, redirect, or contest a hostile effect against it;
- damage a hostile creature that damaged, moved, restrained, or spiritually affected it during the round;
- grant it Temporary Hit Points, a saving-throw benefit, movement, or a Pressure-cleansing effect from one of your legal features;
- take the Dodge or Ready action while it remains meaningfully threatened.

#### Break

Name one hostile Grapple, Restrained effect, Concentration effect, Cultivation Asset, external Anchor, barrier, weapon, or ongoing Source Rule you can legally affect. Complete the declaration by ending, suppressing, breaking, disarming, or dealing meaningful damage to the named subject before the end of the turn, as defined in the Normalized Execution Notes.

### Credence

When you complete an Open Declaration, gain 1 **Credence**, to a maximum equal to your Proficiency Bonus. You can gain Credence no more than once per turn. Credence lasts for the scene and is not Resonance.

- A declaration must advance a real objective under meaningful opposition.
- Repeated declarations against a harmless object, willing ally, staged attack, or already-defeated effect grant no Credence.
- If you voluntarily perform an act that directly contradicts your declaration before completing it, the declaration breaks and you lose 1 Credence, minimum 0.
- If the declaration becomes impossible because the subject leaves the scene, dies, is destroyed, becomes untargetable, or an external effect prevents completion, it ends without gaining or losing Credence.
- You can have one Open Declaration at a time. It ends at the end of the turn.

### CL3 — Word and Hand

You gain Open Declaration and Credence.

#### Truth-Forged Strike

Once on each of your turns when a Martial Strike damages a meaningful hostile creature, you may spend 1 Credence and apply the expression matching your current declaration. If you have no current declaration, choose the expression matching the most recent declaration you completed during the scene.

- **Challenge — Face the Named Blow:** Deal an additional `1d8` Psychic damage. The damaged creature cannot take Reactions until the start of your next turn.
- **Pursuit — The Word Arrives:** Move up to 10 feet toward the declared creature without provoking opportunity attacks from it. If you are already adjacent, you may instead move to another legal space adjacent to it.
- **Guard — The Witness Stands:** The declared subject gains Temporary Hit Points equal to your Wisdom modifier + Proficiency Bonus and may stand from Prone without spending movement.
- **Break — Nothing False Remains Whole:** Deal an additional `2d8` Psychic or Force damage to the named Asset, Anchor, barrier, object, or creature maintaining the named effect. Against Concentration, the source has Disadvantage on the saving throw caused by this damage. This does not bypass an object's or Anchor's immunity or make an untargetable subject targetable.

A Truth-Forged Strike can complete the declaration that supplied its expression, but Credence must have existed before the strike; newly gained Credence cannot be spent retroactively on the same strike.

#### Honest Posture

While you have an active Open Declaration, you have Advantage on Wisdom (Insight) checks and Cultivation Checks made solely to identify a feint, false target, disguised attack origin, illusory duplicate, concealed controller, or whether a visible creature is acting under possession or compulsion.

Honest Posture does not see through every illusion or reveal protected facts automatically. Equal or higher concealment still contests.

### CL6 — Unspoken Intention Made Visible

You force a hostile creature to make the broad shape of its next deed spiritually legible.

**Reaction**  
**Trigger:** A meaningful hostile creature bearing your Resonance Mark begins its turn within 60 feet  
**Cost:** 2 Resonance

The target makes a Wisdom saving throw.

**Successful Save:** Learn whether the first significant thing it presently intends is primarily an attack, movement, technique or Asset activation, defense or recovery, or escape. It may change its plan freely. Impose one ordinary Spiritual Pressure effect until the start of its next turn.

**Failed Save:** Before taking further actions, the target chooses one Intent below that it is presently capable of attempting. It may choose to take no Action and make no voluntary movement instead.

#### Strike Intent

Name one creature or object the target can perceive. Its first hostile attack or single-target hostile technique during the turn must include that subject as a target if the subject remains legal.

#### Advance Intent

Name one creature, object, or space the target can perceive. Before it voluntarily moves farther from that subject, it must move at least 10 feet and end at least 5 feet closer to it.

#### Withdraw Intent

Name one creature or object the target can perceive. Its first voluntary movement must end at least 5 feet farther from that subject, and it cannot voluntarily move closer before completing that movement.

#### Invoke Intent

Its first Action or Bonus Action must activate a technique, item property, Cultivation Asset command, Domain, recovery feature, or other supernatural Source Rule rather than make an ordinary weapon attack.

#### Hold Intent

It cannot voluntarily move more than 5 feet from its starting space before it takes the Dodge, Ready, Help, Search, or another primarily defensive or observational action.

The target chooses the Intent and any named subject. You learn that choice.

#### Contradiction

Before performing an incompatible act, the target chooses one:

- abandon the act before movement, attack rolls, saving throws, or limited resources are committed; or
- proceed and suffer Contradiction.

When it suffers Contradiction:

- it takes `3d8` Psychic damage;
- it cannot take Reactions until the start of its next turn;
- an incompatible attack has Disadvantage;
- targets have Advantage on saving throws against an incompatible technique;
- incompatible voluntary movement costs 2 feet for every 1 foot moved.

After Contradiction resolves, the Intent ends and the target may act normally for the remainder of the turn. Contradiction occurs at most once per activation.

Unspoken Intention does not force a creature to spend a limited resource, attack an ally, enter a hazard, reveal a secret technique, or take an action it cannot legally take.

### CL10 — Deed Follows Word

You compress Credence into one declared martial deed.

**Action**  
**Cost:** 5 Resonance  
**Range:** 60 feet before movement  
**Requirement:** You have at least 1 Credence

Choose Challenge, Pursuit, Guard, or Break and spend 1–3 Credence. State the subject and exact completion condition before moving or rolling.

You may move up to 10 feet per Credence spent as part of this activation. This movement must directly advance the declaration and does not provoke opportunity attacks from creatures other than the declared hostile subject. It cannot cross illegal spaces or escape restraint without a successful contest.

Then make one cultivation attack through an unarmed strike or a weapon you are proficient with. Use your Cultivation Attack Modifier. The legal attack target is determined by the declared deed:

- **Challenge:** the named hostile creature;
- **Pursuit:** the named hostile creature;
- **Guard:** one hostile creature that threatened, targeted, damaged, moved, restrained, or spiritually affected the named protected subject during the current or previous round;
- **Break:** the named creature, Asset, external Anchor, barrier, object, or source maintaining the named effect.

If no legal attack target exists when the attack would be made, the activation fails after its movement and its costs remain spent.

**Hit:** The attack deals its normal damage plus `3d8 + 1d8 per Credence spent` Psychic or Force damage. Apply the matching completion:

- **Challenge:** The target becomes Resonance Marked for the scene. Until the start of your next turn, it has Disadvantage on attacks against creatures other than you while you remain a legal target.
- **Pursuit:** Move to a legal space adjacent to the target after damage. Until the start of your next turn, its voluntary movement away from you costs 2 feet for every 1 foot moved.
- **Guard:** Choose the declared willing subject within 30 feet. It gains Temporary Hit Points equal to `2 × Proficiency Bonus + Wisdom modifier`, may move 10 feet without provoking opportunity attacks, and gains Advantage on its next Intelligence, Wisdom, or Charisma saving throw before the start of your next turn.
- **Break:** Make a Cultivation Check against one ongoing effect, Concentration source, Asset, external Anchor, or barrier damaged by the attack. On a success, end an ordinary lower-authority effect, suppress one equal-authority expression until the end of your next turn, or deal an additional `2d8` Force damage to an Asset, Anchor, or object. Higher authority yields only the printed contest result.

**Miss:** The declaration is not completed by this activation. You may move 5 feet toward or adjacent to the declared subject. Resonance and Credence remain spent.

If the declaration became impossible after activation because the target was removed by another effect, you may redirect the attack to another legal hostile creature within reach, but gain no declaration rider.

Deed Follows Word is one attack and one Spirit Awakening technique. It cannot be divided among multiple targets or used to activate another extra-action feature.

### CL14 — Heaven Rejects the Feint

#### Unbroken Word

While you have an active Open Declaration, you gain Advantage on the first saving throw or Cultivation Check each turn against an effect that would directly prevent its completion by:

- moving you against your will;
- inflicting Grappled, Restrained, Frightened, Charmed, or a command that contradicts the declaration;
- concealing or replacing the declared subject;
- forcing you to target another creature;
- suppressing the movement or Martial Strike required by the declaration.

On a success, you may move 5 feet toward a legal completion without provoking opportunity attacks from the source. This does not ignore a wall or sealed boundary.

#### Call the False Form

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 3 Resonance

Choose one creature, duplicate, disguise, illusion, possession, controlled body, or concealed attack origin you can perceive or have identified with Soul Gaze. State one claim:

- “This is not the true body.”
- “This action is controlled from elsewhere.”
- “This appearance conceals another identity.”
- “This target is an echo, decoy, or projected expression.”
- “This attack originated from another source.”

Make a Cultivation Check against the relevant concealment or control Source Rule.

- **Success:** Learn whether the claim is true. If true, reveal the broad direction of the real body, controller, identity, or origin and suppress one ordinary false-target or misdirection benefit until the end of your next turn.
- **Failure:** Learn only that the claim could not be established. You do not learn whether it was false or protected.

Call the False Form does not reveal exact location through total concealment, dispel an illusion, sever possession, or expose a Secret identity without the required authority.

#### Contradiction Leaves an Opening

Once per round when a creature suffers Contradiction from Unspoken Intention, choose one:

- move up to half your Speed toward it without provoking opportunity attacks from it;
- use Mind Spike against it, reducing the damage by one die, minimum one die;
- make one weapon or unarmed attack against it if it is within normal reach or range;
- impose two different ordinary Spiritual Pressure effects as one exceptional package until the start of its next turn.

This requires no additional Reaction because Unspoken Intention already used it. It cannot activate Truth-Forged Strike, Deed Follows Word, or another feature that grants an attack.

#### Soul Splitting — Witness to the Word

Your Soul Fragment is a perfect witness to declarations made within 60 feet of it.

- You may originate Unspoken Intention or Call the False Form from yourself or the fragment.
- A target cannot conceal its chosen Intent from you while it remains within 60 feet of either origin unless a higher Source Rule wins the contest.
- Once per turn when you complete an Open Declaration, the fragment may move 15 feet and impose one ordinary Spiritual Pressure effect on a Resonance Marked creature within 30 feet.
- The fragment cannot make declarations, gain Credence, suffer Contradiction, or complete a deed for you.

### CL18 — Hall of Spoken Deeds

You manifest a Domain in which every combatant's first purpose becomes visible enough for heaven to judge its consistency.

**Action**  
**Cost:** 10 Resonance  
**Area:** 40-foot-radius sphere centered on a point you can perceive within 60 feet  
**Duration:** 1 minute  
**Concentration:** Required

The sphere is your **Hall of Spoken Deeds Domain**.

#### Willing Declarations

At the start of a chosen ally's turn in the Hall, it may declare one of the following deeds: Challenge, Pursuit, Guard, Break, or Hold.

- **Hold:** Remain within 5 feet of its starting space and take a primarily defensive, observational, recovery, or preparation action.

If the ally completes the declared deed before the turn ends, choose one benefit:

- move 10 feet without provoking opportunity attacks;
- gain Temporary Hit Points equal to `2 × Proficiency Bonus`;
- add `1d8` to one damage or healing roll made as part of the deed;
- gain Advantage on its next Intelligence, Wisdom, or Charisma saving throw before the start of its next turn.

A creature gains one benefit per turn. Its declaration does not create your Credence.

#### Hostile Intention

At the start of each hostile creature's turn in the Hall, it makes a Wisdom saving throw.

- **Failed Save:** It chooses an Intent from Unspoken Intention and is subject to Contradiction until the turn ends.
- **Successful Save:** It is not bound, but you learn the broad category of its first present intention and may impose one ordinary Spiritual Pressure effect until the start of its next turn.

A creature that succeeded on two saves against Hostile Intention during the same activation becomes immune to automatic binding by this Domain for the remainder of the activation, though Unspoken Intention can still target it normally.

#### Credence Before Heaven

You gain 1 Credence the first time each round that:

- you complete an Open Declaration in the Hall; or
- a hostile creature suffers Contradiction in the Hall.

You cannot exceed your normal maximum.

#### Deed Without Hesitation

Once on each of your turns, you may use Deed Follows Word without paying its Resonance cost. You must still spend 1–3 Credence. You cannot also use a paid Deed Follows Word during that turn.

#### Final Pronouncement

Once during the activation, choose one Resonance Marked hostile creature in the Hall and make one declaration:

- **Face Me:** It cannot willingly target another creature with a hostile single-target effect while you remain a legal target.
- **Do Not Flee:** Its Speed is halved when moving away from you, and ordinary teleportation cannot carry it outside the Hall.
- **Release What Is Not Yours:** It must release one ordinary Grapple, possession expression, controlled Asset command, stolen object, or maintained coercive effect of your choice.
- **Speak the Deed:** It must state the broad purpose of one active technique, Domain, Asset, Anchor, or transformation it is maintaining.

The target makes a Charisma saving throw.

- **Failed Save:** The pronouncement lasts until the start of your next turn.
- **Successful Save:** It suffers one ordinary Spiritual Pressure effect until the start of your next turn.

Final Pronouncement cannot force self-harm, reveal a protected secret name or complete technique text, end a willing bond, release a higher-authority possession automatically, or override a Secret, divine, artifact, or equal-or-higher conceptual law without a Cultivation Check.

#### Hall Anchor and Counterplay

The Hall manifests a visible **Witness Stone** in an unoccupied space within 30 feet of its center:

- **AC:** your Cultivation Save DC;
- **Hit Points:** `8 × Proficiency Bonus`;
- **Saving Throws:** uses your Intelligence, Wisdom, and Charisma saving throw bonuses;
- **Resistances:** Psychic damage;
- **Source CL:** your effective Spirit Awakening CL.

A creature adjacent to the Stone can use an Action to make Charisma (Deception), Wisdom (Insight), Intelligence (Arcana), or an appropriate Cultivation Check against your Cultivation Save DC. On a success, it suppresses Hostile Intention for itself until the end of its next turn. Destroying or fully suppressing the Stone ends the Domain.

#### Domain Collision and Ending

Oath, Contract, Sovereignty, Fate, Mind, illusion, true-name, Secret Law, divine command, artifact, or higher-Source-CL authority contests only the contradictory declaration or revelation. When the Hall ends, declarations and Intents created by it end. Credence remains until the scene ends.

### Procedural Parity — Plain-Truth Fist

#### Declaration and Resolution Order

1. Make the Open Declaration at the start of the turn before movement or actions.
2. Voluntary contradiction before completion breaks it and loses 1 Credence.
3. External impossibility ends it without loss.
4. Complete the exact printed deed and gain Credence once.
5. Newly gained Credence cannot be spent retroactively on the strike that completed the declaration.

#### Source CL and Realm Interaction

This tradition governs declared combat intent, not objective truth. Mind shielding, illusion, possession, Oath, Contract, Sovereignty, Secret identity, and higher-authority concealment can contest revelation. A creature can always choose inaction instead of being compelled to spend a resource or commit self-harm.

#### Assets, Anchors, Fields, and Companions

Guard and Break can name legal Assets or external Anchors. An internal Soul Anchor cannot be attacked merely because it was declared. A companion can make a willing declaration in the Hall only if it has agency under its own rules; it does not grant Credence to its cultivator unless a feature says so.

#### Failure, Persistence, and Recovery

Credence lasts for the scene. Failed attacks spend Credence committed to Deed Follows Word. A failed Call the False Form does not confirm the opposite claim. No declaration creates a per-rest counter.

#### Worked Adjudication

A cultivator declares Challenge against a hidden assassin. Before she can attack, the assassin is carried behind total cover by another creature. The declaration becomes externally impossible and ends without Credence loss. If she voluntarily attacks a different legal target while the assassin remains available, she contradicts the declaration and loses 1 Credence.

---

### Normalized Execution Notes

#### Meaningful Damage for Break
Damage is meaningful for a Break declaration when at least one of these is true after Resistance and damage reduction:

- the named creature, object, Asset, Anchor, barrier, or maintaining source loses Hit Points equal to at least your Proficiency Bonus;
- the damage forces a Concentration saving throw or a printed maintenance check for the named effect;
- the damage reaches or exceeds a printed damage threshold for breaking, suppressing, or disabling the subject;
- the damage reduces the named subject to 0 Hit Points or destroys it.

Damage completely absorbed by Temporary Hit Points can qualify against a creature only if the remaining damage still forces the printed Concentration or maintenance check. Repeated harmless taps, damage to an unrelated bearer, or damage that the subject ignores does not complete Break.

#### Declaration Record
Each Open Declaration records deed, named subject, starting space if relevant, exact completion condition, start of turn, and status as active, completed, contradicted, or externally impossible. The declaration’s words can be described freely, but the mechanical deed must be one printed category.

For Guard, record the protected subject and the qualifying protective act. For Break, record the exact effect, source, Asset, Anchor, barrier, weapon, or maintaining creature. Naming a broad Path, Foundation, bloodline, identity, or “all magic” is not a legal Break subject.

#### Credence Timing
Credence is gained immediately after the printed deed is completed. It cannot be spent on the same strike or resolution that completed that declaration. If several effects complete the declaration simultaneously, gain only 1 Credence. A declaration that became impossible from an external event ends before a later voluntary act can contradict it.

#### Unspoken Intention
Pause the target at the start of its turn before it moves or declares another activation. On a failed save, it chooses one Intent it can presently attempt and records any named subject. The target is not required to reveal a secret technique, exact destination, hidden identity, or resource amount.

Contradiction resolves immediately before the incompatible act commits its attack roll, save, movement, or limited resource. If the target proceeds, apply the damage and restrictions, then resolve the incompatible act under those restrictions. One activation can cause Contradiction only once even if it contains several incompatible components.

#### Deed Follows Word
Declare deed, subject, Credence spent, movement path, and legal attack target before movement. If an external effect removes the declared subject after movement begins, use the printed redirect rule. If the subject was never legal when declared, the activation fails before movement and costs are not spent.

#### Call the False Form
An “identified” subject is one for which Soul Gaze, Spiritual Sense, a Witness record, a direct interaction, or another printed feature has supplied a concrete creature, duplicate, disguise, body, controller, or attack origin. A vague suspicion is insufficient.

On success, suppress only one ordinary benefit that depends on the proven false relation, such as Advantage from a duplicate, protection from a decoy, concealment of a controller’s direction, or one false-target selection. The actual illusion, possession, projection, or disguise remains unless another rule ends it.

#### Witness Stone Profile
The Witness Stone is a stationary Medium Spirit Cultivation Asset, Domain Anchor, and external Anchor occupying one 5-foot space. It:

- takes no turn and cannot move or carry objects;
- is immune to Poisoned, Charmed, Frightened, Grappled, Prone, and Restrained;
- uses the printed Intelligence, Wisdom, and Charisma saving throw modifiers and gains no general saving throw proficiency;
- can be repaired only by a feature that repairs Cultivation Assets, Domains, Anchors, stone structures, or Spirit manifestations;
- is visible and targetable from inside the Hall and cannot be hidden by the Hall itself.

The adjacent counterplay check must use Charisma (Deception), Wisdom (Insight), Intelligence (Arcana), or a Cultivation Check whose governing Source Rule concerns Spirit, Mind, Oaths, Insight, Strategy, illusion, testimony, identity, or a directly opposed authority. Success suppresses Hostile Intention only for that creature and only for the printed duration.

#### Hall Allies and Hostile Saves
A willing ally is designated when the Hall appears or when it enters; it can refuse or withdraw designation. Each hostile creature makes Hostile Intention’s save once at the start of each of its turns. Track successful saves per creature. Two total successes during the activation create the printed immunity; they need not be consecutive.

#### Final Pronouncement
Record the selected pronouncement and exact subject or maintained expression. “Release What Is Not Yours” can affect only one ordinary listed relation or maintained effect. It cannot release every Asset, possession, object, and Grapple at once. On a successful Charisma save, no compelled release or restriction occurs; only the printed Spiritual Pressure applies.

#### Realm Suppression
Credence and declaration history remain recorded, but features above effective CL cannot use them. Hall of Spoken Deeds and the Witness Stone end if CL18 becomes unavailable. A declaration requiring a suppressed feature can still be completed through another legal action that satisfies the printed deed.

### Integrated Procedure Closure — Plain-Truth Fist

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Witness to the Word. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---

## 34. Last-Inch Palm

**Integration status:** PASS — Spirit Subpath Integration R6 Candidate.  
**Governing rules:** Spirit Awakening Core R2A; Spirit Awakening Rules Reference R3; Spirit Tradition Procedure Addendum R7.  
**Mechanical state:** No intentional power reduction from the normalized source.


**Access:** Restricted close-contact spirit school, shrine-guardian lineage, exorcist hand tradition, prison-breaker inheritance, or teacher who has cultivated the boundary between touching and not touching.  
**Classification:** Restricted Martial Spirit Tradition.  
**Identity:** Contact, separation, reach, interception, spiritual touch, and the final interval before two beings affect one another.  
**Primary role:** Close controller, anti-Grapple defender, touch-technique interceptor, spiritual striker, and local reach manipulator.  
**Sphere Lean:** Spirit, Unarmed Training, Pressure Points, Medicine, Boundary, and Space. This tradition grants none of those Spheres.  
**Cultivation boundary:** Last-Inch Palm does not create unrestricted ranged bodily force, ordinary telekinesis, or universal distance manipulation. It treats a specific spiritually contacted subject as standing at the threshold of touch for this tradition's features only.

> *There is no distance more dangerous than the last inch before contact.*

### Spirit-Touch Unarmed Strike

You may use Wisdom instead of Strength for the attack and damage rolls of your unarmed strikes. When you do, the strike's damage die is `1d8`, and you may choose for its damage to be Bludgeoning or Psychic.

A Spirit-Touch Unarmed Strike:

- can affect incorporeal spirits and Spirit Cultivation Assets that ordinary physical attacks cannot affect;
- does not become a spell, weapon, Sphere talent, or projected limb;
- cannot manipulate an object, carry weight, open a door, or Grapple at range;
- uses your actual reach unless a Last-Inch feature changes it;
- gains no Weapon Mastery and does not count as a weapon unless another rule expressly treats unarmed strikes as one.

### Handspan Subject

Once on each of your turns when you do one of the following to a creature within 10 feet, you may designate it as your **Handspan Subject** until the end of your next turn:

- damage it with a Spirit-Touch Unarmed Strike;
- cause it to fail against Mind Spike;
- place or refresh your Resonance Mark on it;
- successfully contest its Grapple, possession, touch technique, or bodily contact effect.

You can maintain one Handspan Subject. Designating another ends the previous designation.

A Handspan Subject is not physically adjacent merely because of this designation. It is treated as within spiritual contact only where a Last-Inch feature says so. Total cover, sealed boundaries, planar separation, and perfect spiritual concealment can suppress the designation.

### CL3 — The Last Inch

You gain Spirit-Touch Unarmed Strike and Handspan Subject.

#### Handspan Reach

Your Spirit-Touch Unarmed Strikes have 10-foot reach against your Handspan Subject. This reach is spiritual contact:

- it requires line of effect;
- it cannot pass through total cover or a sealed boundary;
- it cannot deliver a Grapple, Shove, item, poison, bodily secretion, or touch-range feature unless that feature expressly permits spiritual delivery;
- it does not threaten every space within 10 feet for opportunity attacks; you can make an opportunity attack at that reach only against your Handspan Subject.

#### Last-Inch Step

**Reaction**  
**Trigger:** Your Handspan Subject within 15 feet enters your reach, leaves your reach, or attempts to pass through your space  
**Limit:** Once per round

Move 5 feet to a legal space without provoking opportunity attacks from the subject. Then choose one:

- remain adjacent to it if a legal space exists;
- increase your distance from it by 5 feet;
- exchange which side of it you occupy without entering its space;
- impose Heavy Soul or Stilled Intent as Spiritual Pressure until the start of its next turn if it bears your Resonance Mark.

Last-Inch Step cannot escape an existing Grapple or Restrained effect and cannot cross a barrier.

#### Contact Reveals Disturbance

When a Spirit-Touch Unarmed Strike damages your Handspan Subject, you learn whether it is currently affected by ordinary possession, a curse, a Heart Demon, spiritual contamination, an external controlling link, or a disguised spirit-body relation. This reveals only the category, not the source or cure.

### CL6 — Nothing Crosses Unanswered

You can alter the final interval of hostile contact.

**Reaction**  
**Trigger:** Your Handspan Subject within 15 feet targets you or a willing creature adjacent to you with a melee attack, Grapple, Shove, touch-range hostile technique, possession entry, or other effect that requires bodily or spiritual contact  
**Cost:** 2 Resonance

The subject makes a Wisdom saving throw before the trigger resolves.

**Failed Save:** For that trigger, increase the required reach or contact distance by 10 feet.

- If the effect no longer has legal reach or contact, it fails against the protected creature.
- If it remains legal, an attack has Disadvantage, the protected creature has Advantage on its check or saving throw, and the source cannot take Reactions until the start of its next turn.

**Successful Save:** The required distance is unchanged. The protected creature gains `+2 AC` against an attack roll or Advantage on its check or saving throw against the trigger.

After the trigger resolves, you may move 5 feet to a legal space adjacent to the protected creature or the subject. This movement does not provoke opportunity attacks from the subject.

Nothing Crosses Unanswered does not affect an area effect, internal poison already delivered, a true-name effect, an attack originating inside the target, or a technique that expressly ignores distance and contact. Equal or higher contact, Space, Boundary, possession, divine, artifact, or Secret authority can require a Cultivation Check.

#### Palm at the Threshold

If Nothing Crosses Unanswered causes the trigger to fail, miss, or be resisted successfully, choose one:

- make one Spirit-Touch Unarmed Strike against the subject if it is within your Last-Inch reach;
- use Mind Spike against it, reducing the damage by one die, minimum one die;
- move it 5 feet on a failed Strength or Wisdom saving throw;
- impose one ordinary Spiritual Pressure effect until the start of its next turn.

This counter is part of the same Reaction. It cannot activate Truth-Forged Strike, Measured Return, Compass Strike, or another feature that grants an attack.

### CL10 — Palm Across Emptiness

You strike the spiritual fact of contact before the body crosses the intervening space.

**Action**  
**Range:** 30 feet  
**Cost:** 5 Resonance  
**Target:** Your Handspan Subject or one creature bearing your Resonance Mark  
**Requirement:** Line of effect

The target makes a Wisdom saving throw.

**Failed Save:** It takes `5d8 + Wisdom modifier` Psychic or Force damage and becomes your Handspan Subject until the end of the scene. Choose one contact expression:

- **Draw Into the Palm:** Move it to a legal space adjacent to you. A creature at least two size categories larger than you or a creature protected by bodily, gravity, Space, Boundary, anchoring, or higher-Source-CL authority can make a Strength saving throw after the failed Wisdom save to reduce the movement to 10 feet toward you.
- **Cast Beyond Contact:** Move it up to 20 feet away from you.
- **Hold at the Last Inch:** Its Speed becomes 0 and it cannot take Reactions until the start of your next turn.
- **Touch the Spirit, Not the Flesh:** Suppress one ordinary possession entry, disguise-body relation, external controlling link, or incorporeal passage expression until the end of your next turn. Equal or higher authority requires a Cultivation Check.

**Successful Save:** It takes half damage, becomes your Handspan Subject until the end of your next turn, and suffers no contact expression.

Palm Across Emptiness is not a projectile and does not cross intervening spaces, but it still requires legal line of effect. It can pass through an ordinary narrow opening that spiritual contact could cross, but not total cover, a sealed wall, a Domain boundary that denies contact, or an expressly higher-authority separation.

It cannot target an ordinary object, spiritually empty corpse, or mindless nonspiritual construct unless that subject is an external Anchor or Cultivation Asset that can be affected by spirit techniques.

### CL14 — Inside Every Guard

#### Contact Without Adjacency

While your Handspan Subject is within 30 feet and you have line of effect, treat it as within 5 feet of you for the following only:

- Spirit-Touch Unarmed Strikes;
- Nothing Crosses Unanswered;
- Palm Across Emptiness;
- ordinary Spiritual Pressure imposed by a Last-Inch feature;
- one single-target Spirit Awakening technique whose Source Rule expressly requires spiritual touch and does not move, Grapple, carry, or hand off an object.

This rule does not make you physically adjacent, allow opportunity attacks with a weapon, permit Help, allow a Grapple or Shove, deliver poison or bodily substances, bypass total cover, satisfy an ally's adjacency requirement, or let another creature target through you.

#### Follow the Contact

Once per round when your Handspan Subject voluntarily moves, teleports, or uses conceptual movement while remaining within 60 feet, you may move up to 15 feet toward a legal space within 10 feet of its destination. This movement:

- does not provoke opportunity attacks from the subject;
- cannot cross a sealed boundary or unknown destination;
- cannot exceed the distance the subject moved unless you win a Cultivation Check against its movement Source Rule;
- fails while you are Grappled or Restrained unless you first escape or suppress that effect.

If the subject used equal or higher Space, Boundary, Time, Formation, Void, or route authority, make a Cultivation Check to follow. On failure, you remain in place but learn the movement's broad authority category.

#### Open the Gripping Hand

**Bonus Action**  
**Cost:** 2 Resonance

If you are Grappled, Restrained, possessed through bodily contact, swallowed, pinned, or held by your Handspan Subject, make a Cultivation Check against the effect's escape DC or Source Rule.

- **Success:** End one ordinary Grappled or Restrained condition, escape one ordinary bodily enclosure to the nearest legal adjacent space, or suppress one equal-authority contact expression until the end of the turn.
- **Failure:** The effect remains. You cannot attempt Open the Gripping Hand against the same effect again during the turn.
- **Higher authority:** On success, create enough separation to use one Last-Inch feature, but do not automatically end the complete effect unless its own rules permit it.

#### Soul Splitting — Second Palm

While your Soul Fragment exists, it may maintain a second Handspan Subject. Designate the second subject when the fragment damages it with Echo Spike, imposes Pressure on it, or is within 10 feet when you place your Resonance Mark on it.

- You and the fragment each maintain one subject.
- One activation chooses one Handspan Subject and one origin.
- Contact Without Adjacency can originate from the fragment for its subject.
- Nothing Crosses Unanswered can protect a willing creature adjacent to the fragment.
- Palm Across Emptiness can originate from the fragment, but you remain the source and pay the cost.
- The fragment cannot make unarmed strikes, Grapple, carry objects, or create independent contact activations.

When the fragment ends, its Handspan designation ends.

### CL18 — World of One Handspan

You manifest a local spiritual law in which every hostile soul remains at the threshold of your palm.

**Bonus Action**  
**Cost:** 10 Resonance  
**Area:** 30-foot-radius aura centered on you  
**Duration:** 1 minute  
**Concentration:** Required

The aura is your **World of One Handspan Domain** and moves with you.

#### All Within Reach of the Spirit

Every hostile creature of your choice in the Domain that you can perceive counts as your Handspan Subject for Last-Inch features. This does not end your normal designation outside the Domain.

You may make Spirit-Touch Unarmed Strikes against such a creature from anywhere in the Domain with legal line of effect. These strikes use your Cultivation Attack Modifier and deal `1d8 + Wisdom modifier` Bludgeoning or Psychic damage instead of any higher unarmed damage die granted by another source unless that source expressly combines with projected spiritual contact.

This reach does not permit Grapples, Shoves, weapon attacks, object manipulation, opportunity attacks against every creature in the Domain, or delivery of unrelated touch features.

#### Contact Cannot Be Stolen

The first time each round that each hostile Handspan Subject in the Domain targets a chosen ally with a melee attack, Grapple, Shove, touch technique, possession entry, or contact-dependent effect, it makes a Wisdom saving throw.

- **Failed Save:** The effect has Disadvantage or grants Advantage on the protected creature's check or save. If the source is more than 5 feet from the protected creature and the effect does not expressly operate at that distance, it fails against that creature.
- **Successful Save:** The effect resolves normally, but the source cannot take Reactions until the start of its next turn.

This does not consume your Reaction and does not activate Palm at the Threshold.

#### Ten Thousand Hands, One Contact

**Action**  
**Limit:** Once per turn

Choose one:

- use Palm Across Emptiness without spending Resonance, but its damage becomes `3d8 + Wisdom modifier` and it cannot use Touch the Spirit, Not the Flesh;
- make one Spirit-Touch Unarmed Strike against up to your Proficiency Bonus different hostile Handspan Subjects in the Domain, making a separate attack roll for each. Each hit deals only the strike's `1d8 + Wisdom modifier` damage and cannot activate another once-per-turn rider;
- move one willing creature in the Domain up to 15 feet to a legal space as your palm carries its spiritual contact. This movement does not provoke opportunity attacks;
- require one hostile Handspan Subject to make a Wisdom saving throw, moving it up to 15 feet on a failure or 5 feet on a success.

The multi-target option is one technique activation, not an Attack action, and cannot deliver weapons, poisons, Insights, Recorded Arts, or Forged Technique riders.

#### Sanctuary at the Last Inch

Once during the activation, when a chosen creature in the Domain would be Grappled, possessed, swallowed, pulled through a portal, banished through contact, or reduced to 0 Hit Points by a melee or touch-range effect, you may use your Reaction and spend 3 Resonance.

Move the creature to a legal space adjacent to you and defer only the contact-dependent portion of the trigger until the end of its next turn.

- Damage that did not depend on contact still applies immediately.
- The creature can answer the deferred contact by leaving the Domain, ending the source's reach, exorcising the link, destroying an Anchor, or winning the appropriate contest.
- If the source still has legal contact and authority when the delay ends, the deferred portion occurs.
- Permanent, Secret, divine, artifact, true-name, internal, or higher-Source-CL consequences require a Cultivation Check. On failure, the movement can still occur if legal, but the consequence is not deferred.

This is a contact-bound delay, not time manipulation, and cannot defer an unrelated consequence.

#### Domain Collision and Ending

Law of Near and Far, Boundary, Space, possession, true-name contact, Domains, Seals, divine touch, artifacts, and higher-Source-CL contact laws contest only the contradictory expression. World of One Handspan cannot reach through total cover, across planes, or into an unknown sealed space.

When the Domain ends, its temporary Handspan subjects end. Your normal Handspan designation remains for its normal duration.

### Procedural Parity — Last-Inch Palm

#### Declaration and Resolution Order

1. Establish one Handspan Subject through a printed trigger.
2. Check line of effect and actual or conceptual range.
3. Resolve the attack or save.
4. Apply movement or contact rider only after the hit or failed save where required.
5. Recheck legality after any movement; contact does not persist through a sealed boundary merely because it existed before movement.

#### Source CL and Realm Interaction

Ordinary melee reach, Grapples, touch techniques, and spirit contact use the printed procedure. Space, Boundary, possession, internal effects, divine touch, artifact law, Secret contact, and higher-Source-CL separation can contest. Last-Inch Palm does not become general telekinesis or cross-planar targeting.

#### Assets, Anchors, Fields, and Companions

A Spirit Cultivation Asset can be a Handspan Subject if it has a spiritual identity or external profile. An internal Soul Anchor cannot be struck. A companion's body or manifestation can be contacted under its own rules, but the tradition grants no control over the bond or the companion's Nature Spheres.

#### Failure, Persistence, and Recovery

A successful save against Palm Across Emptiness still creates the short Handspan designation but no rider. Failed movement caused by an illegal destination moves the creature as far as legally possible only where the feature says so. No feature uses a rest counter.

#### Worked Adjudication

A Handspan Subject stands 25 feet away behind an ordinary iron portcullis with open gaps. Contact Without Adjacency can permit a Spirit-Touch strike if line of effect exists through the gaps, but the strike cannot open the gate, deliver a Grapple, or pull the creature through a space too small for it. A sealed formation wall with no spiritual line of effect blocks the strike entirely.

---

### Normalized Execution Notes

#### Handspan Record
Each Handspan designation records subject, origin feature, Source CL, creation time, expiration, current line-of-effect status, and whether it belongs to the practitioner or Second Palm. A suppressed designation remains recorded until its duration ends but supplies no contact while total cover, a sealed boundary, planar separation, or perfect spiritual concealment blocks it.

A subject can be designated only through one printed trigger. Causing Mind Spike to fail means the target failed its saving throw against Mind Spike, not that the technique itself failed.

#### Spiritual Contact
Spiritual contact is a targeting permission for listed Last-Inch features. It does not create physical adjacency, a path, a limb, a projectile, a free touch, a passenger relation, or a general origin for other abilities.

The Mind Spike bullet formerly listed under Contact Without Adjacency was redundant because Mind Spike already uses its normal printed range. Its removal changes no range or availability. A Last-Inch feature that explicitly modifies Mind Spike continues to do so.

#### Nothing Crosses Unanswered
Resolve the Wisdom save after the source and protected target are declared but before the attack roll, Grapple check, or hostile-technique save. On a failed save, increase only the contact or reach required for that one trigger. Recheck target legality immediately.

If the trigger has multiple targets, only the protected creature’s portion is affected. A committed Action, Bonus Action, Reaction, charge, ammunition, or CP is spent normally unless the source rule expressly refunds it.

Palm at the Threshold resolves after the trigger’s miss, failure, or successful resistance is final. It is one counter packet and cannot trigger another attack-granting response, including another Palm at the Threshold.

#### Palm Across Emptiness
Declare damage type and contact expression before the saving throw. The size clause treats “substantially larger” as at least two size categories larger than the practitioner.

For Draw Into the Palm, if no legal adjacent space exists, move the target along a legal path toward you up to the distance allowed by the result and stop in the nearest legal space. The effect cannot squeeze it through an opening too small for its body. Cast Beyond Contact uses the same legal-destination rule away from you.

Touch the Spirit, Not the Flesh suppresses one named ordinary expression. Record the possession entry, disguise-body relation, controlling link, or incorporeal passage affected. It does not suppress the target’s entire Path, body, spirit nature, or all movement.

#### Contact Without Adjacency
Choose one origin and one Handspan Subject for each activation. The permission applies only to the listed Last-Inch features and one legal single-target Spirit Awakening technique expressly requiring spiritual touch. It cannot recursively make another creature an origin, satisfy another feature’s adjacency, or pass an object or substance.

#### Follow the Contact
The subject’s destination must be known or revealed by its movement Source Rule. If the destination is unknown, cross-planar, or sealed, you cannot follow there. On a failed equal-or-higher-authority check, no movement occurs and you learn only the broad authority category.

#### Second Palm
The fragment’s second designation is separately recorded. One activation uses either the practitioner’s subject from the practitioner’s origin or the fragment’s subject from the fragment’s origin. It cannot combine both origins, treat both subjects as one, or duplicate a cost, attack, save, or once-per-turn rider.

If Realm Suppression removes Soul Splitting or CL14, the fragment’s Handspan designation ends immediately. The practitioner’s normal designation is unaffected.

#### Domain Ally Designation
A chosen ally is any willing creature designated when World of One Handspan appears or when it enters the Domain. It can refuse or withdraw designation. The Domain’s hostile-subject designation applies only to hostile creatures the practitioner can perceive; perfect concealment suppresses designation until perception is restored.

#### Contact Cannot Be Stolen Timing
Each hostile Handspan Subject makes this save **once per round, on its first qualifying contact-dependent trigger against any chosen ally**. The result applies only to that triggering effect. Later qualifying effects from the same hostile creature during that round resolve normally unless another Last-Inch feature answers them. Track the once-per-round use separately for each hostile creature.

#### Ten Thousand Hands
Declare all targets before making the first attack roll. The multi-target option makes one roll per target in any recorded order. Each creature can be targeted only once by that activation. The free Palm Across Emptiness remains one use of that feature and cannot be combined with a paid use during the same Action.

#### Sanctuary Contact Record
When Sanctuary at the Last Inch is used, record:

- source and Source CL;
- protected creature;
- movement destination;
- exact contact-dependent portion deferred;
- every non-contact portion resolving immediately;
- the end-of-next-turn arrival time;
- each printed answer that could invalidate the contact.

At arrival time, recheck source, reach, line of effect, Anchor, possession link, Domain, and authority. If any required relation is absent, the deferred portion ends harmlessly. If all remain, resolve only the recorded portion; do not reroll the original attack or recreate unrelated damage.

#### Realm Suppression
Handspan records remain until their durations end, but unavailable features supply no contact. World of One Handspan ends if CL18 becomes unavailable. A deferred Sanctuary contact remains recorded; if suppression removes the Domain or contact authority before arrival, the deferred portion ends because its required relation no longer exists.

### Integrated Procedure Closure — Last-Inch Palm

- **Source CL:** This tradition uses the Source CL printed by its feature or, when none is printed, the practitioner’s current effective Spirit Awakening CL.
- **Soul Splitting interface:** Second Palm. It does not grant a second turn, duplicate activation, or independent Cultivation Point pool unless the feature expressly says so.
- **Assets, Anchors, Fields, and Domains:** They possess only their printed statistics, actions, origins, permissions, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; recorded relationships, debts, scars, identity facts, and spirit personhood are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use the finite records, menus, priority procedures, and fallback DCs in Rules Reference R3 and Procedure Addendum R6. Do not invent an additional cost, condition, counter, injury, permanent loss, or action.

---
