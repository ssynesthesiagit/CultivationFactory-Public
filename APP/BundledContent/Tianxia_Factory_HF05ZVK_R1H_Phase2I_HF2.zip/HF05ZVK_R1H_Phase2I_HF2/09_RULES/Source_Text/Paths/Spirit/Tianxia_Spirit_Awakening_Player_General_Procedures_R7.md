# Tianxia Spirit Awakening — Player General Procedures R7

**Publication state:** Player-facing organization of ordinary Spirit Awakening procedures from Rules Reference R3.  
**Mechanical state:** Exact procedural extraction and organization only; no intentional mechanical changes.  
**Authority boundary:** Exceptional Source CL collisions, permanent soul destruction, reincarnation disputes, hostile custody, Secret authority, and unresolved high-authority cases are adjudicated through the GM Authority Appendix.

## How to Use These Procedures

A feature must grant permission before these procedures apply. Defining possession does not grant possession; defining reconstruction does not grant reconstruction; defining a full Spirit Companion does not grant one.

For ordinary play, use the sections below. When a case exceeds the printed procedure, stop at the printed result and consult the GM Authority Appendix rather than inventing a stronger effect.

---

# 2. Central Cultivation Insight Progression

Cultivation Insights are a **shared Tianxia advancement system**, not separate Path-specific subsystems. Spirit Awakening, Qi Cultivation, and Body Refining use the same level-selection schedule unless a later universal rule replaces it.

At **CL4, CL8, CL12, CL16, and CL19**, choose one:

- gain an Ability Score Improvement under the current rules; or
- gain one Cultivation Insight for which every prerequisite is met.

A level-selected Insight grants its printed cultivation benefit and a +1 increase to one of the ability scores listed in its **Ability Increase (Level Selection)** entry, to the maximum allowed by the character's current Realm.

An Insight awarded through a manual, tribulation, relic, shrine, spirit pact, bloodline, reincarnated memory, office, story reward, or another non-level source grants only its cultivation benefit unless that source explicitly grants an ability increase.

## Central Catalogue Authority

Use the central Insight artifacts rather than maintaining a separate Spirit-only list.

- **Player Catalogue:** presents selectable canonical candidates in player-facing form.
- **AI Reference:** records unique IDs, exact prerequisites, ability options, source provenance, access classifications, cadence flags, determinism flags, and superseded source records.
- **Sortable Index:** supports Path, Sphere, Subpath, Realm, prerequisite, and ability-option lookup.

The current central consolidation contains Qi, Body, Sphere Compendium, and Spirit candidate Insights. Its existence does not make every inherited entry publication-final. Entries flagged for cadence, qualitative language, open-ended selection, or missing authority procedures must still be modernized before final PHB insertion.

## Spirit-Facing Insight Classification

A central Insight can be available to a Spirit Awakener through one or more of these classifications:

- **General:** no Path or Sphere prerequisite.
- **Spirit Awakening:** requires the Path or one of its core features.
- **Spirit Companion:** requires the Sphere of Spirit Companions, a Minor Agreement, a Major Bond, a Hosting Bond, or a full companion as printed.
- **Sphere-specific:** requires a named Sphere even when Spirit Awakening is one eligible Path.
- **Subpath-specific:** requires a named Spirit Awakening tradition.
- **Restricted, Forbidden, Secret, or story-awarded:** requires the printed access procedure in addition to all mechanical prerequisites.

A character does not qualify for a Spirit Companion Insight merely because they can perceive, summon, host, or negotiate with a spirit. Use the exact prerequisite.

## Deterministic Insight Requirement

Before final publication, every selectable Insight must state:

- prerequisites;
- Ability Increase options for level selection;
- Source CL;
- action type and trigger, if activated;
- cost and frequency limit;
- range and legal target;
- attack, check, or save procedure;
- duration and Concentration;
- success, failure, and partial-success results;
- recovery or clearing procedure;
- Realm Suppression interaction where material;
- every list from which the player or GM must choose.

An Insight is incomplete if it tells the GM to invent an appropriate power, complication, cost, manifestation, offering, or benefit during play.


# 3. Core Spiritual Terms

## Soul

A **Soul** is the continuing spiritual identity of a creature: its selfhood, memory continuity, cultivated spiritual structure, emotional pattern, true or chosen names, and capacity to remain itself through change.

A creature may possess a soul even if it has no ordinary biology. A construct, undead being, elemental, spirit, incarnation, or projected entity has a soul only when its Source Rule or nature establishes one.

Ordinary Psychic damage does not automatically injure, alter, or destroy a soul. A rule must expressly create soul harm.

## Complete Soul

A **Complete Soul** is a self-continuing spiritual being capable of independent identity and meaningful choice. It may belong to a living creature, ghost, ancestor, spirit, reincarnated being, projected cultivator, or another entity.

Destroying a body, manifestation, vessel, Soul Fragment, shrine, or Cultivation Asset does not automatically destroy the Complete Soul behind it.

Permanent destruction, consumption, erasure, forced reincarnation, or replacement of a Complete Soul requires:

- an explicit Source Rule authorizing that result;
- sufficient Source CL or a successful authority contest;
- a stated consequence for the target;
- and, unless the result is intentionally final, a stated recovery or reconstruction procedure.

## Soul Fragment

A **Soul Fragment** is a separated portion, derivative expression, or cultivated division of a Complete Soul.

Unless its Source Rule states otherwise:

- it is a Cultivation Asset;
- it is not a second complete character;
- it has no independent level progression, Path, Subpath, Sphere catalogue, inventory, or separate action economy;
- it cannot create another Soul Fragment;
- it cannot permanently surrender, rewrite, or destroy the Complete Soul's identity;
- destroying it harms or destabilizes the originating soul only as its Source Rule states;
- safe dismissal reintegrates it without injury.

The Spirit Awakening CL17 Soul Splitting feature supplies the default PC Soul Fragment profile.

## Spiritual Imprint

A **Spiritual Imprint** is residue rather than a Complete Soul. It may be a memory echo, emotional stain, repeated action, battlefield impression, dream remnant, copied voice, dead cultivator's habit, or fragmentary instinct.

An Imprint may appear intelligent because it repeats appropriate behavior, but it cannot make new enduring choices unless its Source Rule says it has become a Complete Soul or independent spirit.

Exorcism may disperse or purify an ordinary hostile Imprint without committing soul destruction.

## Spirit

A **Spirit** is a self-continuing spiritual being whose existence is defined substantially by Nature, memory, relationship, place, office, concept, appetite, or cultivated identity rather than ordinary biology alone. A spirit may possess a stable body, but its body is not necessarily the whole of it.

A Spirit is not automatically:

- a ghost;
- a dead mortal soul;
- a summoned spell effect;
- a Cultivation Asset;
- a full combat companion;
- obedient to the creature that perceives, hosts, summons, feeds, binds, or names it.

A Spirit that is a Complete Soul is a person or independent being for rules purposes. It has its own aims and can consent, refuse, bargain, cultivate, change, and end a relationship unless a specific coercive rule prevents it.

## Spirit Origin Categories

Every significant spirit should record one primary origin category. A spirit can acquire additional tags without changing its primary origin.

### Native Nature Spirit

A being that arises from a place, element, weather pattern, concept, emotion, social practice, repeated event, natural cycle, or accumulated cultivation. Examples include a river spirit, threshold spirit, mourning spirit, market spirit, oath spirit, or storm spirit.

Its Nature must identify the conditions that sustain or weaken it. Destroying one manifestation does not destroy the underlying spirit unless its complete core is also destroyed by an authorized rule.

### Ancestral or Dead Spirit

A surviving Complete Soul, revenant, ancestor, ghost, or posthumous office-holder originating from a deceased person.

It retains only the memories, techniques, and identity that its Source Rule records. Death does not automatically grant a complete copy of every former statistic or ability.

### Embodied Spirit Beast

A spirit born, hatched, cultivated, or evolved with a living body. Its body and soul form one cultivated organism unless its Source Rule permits disembodiment, vessel residence, dantian residence, or manifestation after bodily destruction.

An embodied spirit beast has its own appetites, growth, temperament, and Source CL. A bond does not turn it into equipment.

### Awakened Object or Weapon Spirit

A spirit arising within, entering, or being cultivated through an object, weapon, formation, shrine, vessel, manual, or other Asset.

The object and spirit must be recorded separately unless the Source Rule expressly makes them one inseparable Complete Soul. Destroying the object uses the vessel, Anchor, and reconstruction rules rather than automatically destroying the spirit.

### Cultivated or Created Spirit

A being intentionally formed from qi, Resonance, memory, dream, blood, inscription, alchemy, a Soul Fragment, or another cultivation process.

A created Imprint or Asset does not become a Complete Soul merely because it behaves intelligently. Its creating rule must state when independent personhood emerges, what Source CL it has, and whether the creator retains any authority over it.

### Office, Shrine, or Local God

A spirit whose authority derives from a recognized office, worship, territory, institution, community, lineage, or shrine.

Its personal Source CL and its office's authority must be recorded separately when they differ. Removing it from office does not automatically destroy its Complete Soul; destroying the office's Anchor does not automatically end the person.

### Intrusive, Parasitic, or Heart-Demon Spirit

A being or cultivated presence that survives by occupying, corrupting, consuming, imitating, or pressuring another soul, body, dream, emotion, or spiritual system.

This origin does not automatically authorize its destruction. Exorcism still uses the printed authority and separation procedures.

## Spirit-Ancestry People

A person descended from, transformed by, reincarnated through, or born partly from a spirit can possess visible or invisible spiritual traits while remaining a complete person.

Unless a Source Rule states otherwise, spirit ancestry is **integrated Nature**, not:

- a Hosted spirit;
- a Possession;
- an Intruder;
- a removable Spiritual Affliction;
- a Companion Bond;
- a separate spirit residing inside the person.

Spiritual Sense can recognize that the person's cultivation or ancestry is spiritual in character, but ordinary exorcism cannot remove ancestry, Species traits, Path features, Foundations, Origin Insights, or integrated bodily structures.

When an ancestor or another spirit is separately hosted or bonded within a spirit-descended person, record that presence separately from the person's ancestry.

## Personhood and Autonomy

A Complete Spirit has independent agency unless a Source Rule explicitly establishes a narrower state. It may:

- pursue goals not shared by a cultivator;
- request or refuse an Offering;
- enforce or renegotiate a Covenant;
- withdraw from a voluntary Bond according to its terms;
- cultivate and gain Source CL through its own advancement procedure;
- change temperament, Nature Tags, expressions, or embodiment when a printed evolution rule allows it;
- remember mistreatment and respond according to its recorded crisis rules.

A Binding Seal can impose control, but control is a coercive exception rather than the default meaning of a Bond. A coercive relationship must record resistance, Bond Strain, release conditions, and what the spirit can still choose.

## Spirit Nature

Use the Sphere of Spirit Companions definition. A spirit's **Nature** is the set of concepts, hungers, memories, authorities, Spheres, offerings, taboos, and cultivated expressions that determine what it can do and what sustains it.

A complete Spirit Nature record contains:

- Nature Name;
- Nature Tags;
- one or more Nature Spheres or simplified Nature Expressions;
- temperament and current goals;
- Appetite or Need;
- accepted sustenance and exact cadence;
- Taboo;
- manifestation or embodiment state;
- Source CL and Realm;
- destruction, retreat, and reconstruction rules.

A cultivator does not learn a spirit's Nature Spheres merely by hosting, binding, feeding, naming, or befriending the spirit.

## Embodiment States

A spirit always has one current embodiment state. A Source Rule can permit transitions between listed states.

### Embodied

The spirit has a stable physical body. It uses the body's statistics and can be harmed through that body. Bodily death has only the spiritual consequence printed by its Source Rule.

### Manifested

The spirit has created a temporary expressed form. Use the Manifestation rules. Destruction normally forces retreat, causes Strain, or requires reconstruction; it does not automatically destroy the Complete Soul.

### Hosted

The spirit resides in or upon a Host. Use the Hosting and Possession rules. Hosting does not grant control unless the Hosting rule says so.

### Anchored or Localized

The spirit's active existence is tied to a place, shrine, office, object, grave, formation, route, or other Spiritual Anchor. The record must state how far it can act from that Anchor and what occurs if the Anchor is suppressed or destroyed.

### Unbodied

The spirit currently lacks a stable body or manifestation. The record must state how it can perceive, communicate, move, be targeted, and regain embodiment.

### Contained or Dormant

The spirit is sealed, sleeping, gestating, recovering, or residing within a legal vessel such as an egg, weapon, shrine, mask, seed, dream, or dantian. Containment must state whether the spirit can communicate, provide benefits, consume sustenance, or resist release.

## Embodiment Transition Record

A rule that lets a spirit change state must state:

- starting and ending state;
- action or ritual time;
- Resonance, CP, Offering, or other cost;
- legal destination or vessel;
- range and tether;
- whether the transition provokes or can be interrupted;
- what happens to carried objects and conditions;
- whether Hit Points or injuries transfer;
- dismissal, forced-expulsion, and reconstruction procedure.

A spirit cannot reside in a cultivator's dantian, weapon, shadow, dream, or body merely because such residence is thematically plausible. A Source Rule must grant that state.

## Appetite, Sustenance, and Growth

Many spirits require something that ordinary creatures do not: qi, elemental cores, offerings, emotions, worship, vows, stories, dreams, blood, sunlight, names, memories, service, territory, or another Nature-aligned source.

A spirit's **Sustenance Requirement** must record:

- what qualifies;
- quantity or equivalent value;
- cadence;
- who pays or provides it;
- benefit when fulfilled;
- exact consequence when neglected;
- whether substitute sustenance is possible and its check DC.

Do not create a generic Bond Load or maintenance counter. Use the recorded Offering, Bond Strain, Path resource, Companion rule, or specific spirit procedure.

A spirit's growth is independent of its bonded cultivator unless a Source Rule links them. A relationship can provide training access, shared cultivation, or advancement opportunities, but it does not automatically:

- raise the spirit to the cultivator's CL;
- grant the spirit the cultivator's Path or Spheres;
- grant the cultivator the spirit's expressions;
- make every evolved form available as an action;
- prevent the spirit from outgrowing or renegotiating the Bond.

## Manifestation

A **Manifestation** is a temporary body, image, avatar, projection, voice, environmental presence, or other expressed form through which a spirit acts.

A Manifestation must state whether it is:

- sensory only;
- a point of origin for a technique;
- a Cultivation Asset;
- a creature with a stat block;
- a full bonded companion;
- or a Domain expression.

Destroying a Manifestation normally dismisses or wounds the expression, not the Complete Soul. The Source Rule must state the retreat duration, Bond Strain, damage, reconstruction, or other consequence.

## Vessel

A **Vessel** is a body, object, weapon, shrine, corpse, mask, doll, mark, dream, location, or constructed spiritual container capable of holding, sheltering, imprisoning, or expressing a spirit.

A vessel is not automatically an Anchor or Cultivation Asset. It gains those statuses only when a Source Rule supplies the appropriate profile.

## Host

A **Host** is a creature, object, site, dream, or vessel currently occupied by a spirit or foreign spiritual presence.

Hosting may be willing, inherited, contractual, coerced, parasitic, or hostile. The Source Rule must identify which applies.

## Accepted Presence

An **Accepted Presence** is a spirit or spiritual influence that currently has a printed or acknowledged right to remain in the Host. At least one of the following must apply:

- the Host presently consents;
- a stable Covenant Bond expressly permits hosting;
- the presence is part of the creature's own integrated Nature;
- the presence is an inherited ancestor, office, bloodline, reincarnated component, or spiritual structure expressly recognized by a Source Rule;
- a willing Soul Anchor or Foundation expressly includes the presence;
- another explicit Source Rule grants the presence continuing permission.

Accepted Presence is a rules status, not a declaration that the relationship is morally good.

## Intruder

An **Intruder** is a foreign spiritual presence that lacks an Accepted Presence or whose previous permission has been revoked under its Source Rule.

A presence does not become an Intruder merely because an observer dislikes it. When status is uncertain, use Soul Gaze, Read the Spirit Nature, an Exorcist Designation, or a Cultivation Check against the concealing or sustaining effect's DC.

## Spiritual Affliction

A **Spiritual Affliction** is an ongoing harmful effect acting upon soul, identity, memory, emotion, dream, spiritual circulation, possession status, or spiritual authority.

Examples include:

- hostile possession;
- dream intrusion;
- memory alteration;
- emotional corruption;
- spiritual contamination;
- a Heart Demon effect;
- a curse with a soul or identity component;
- a hostile Resonance, Name, vow, grief, or fate effect;
- a spirit parasite;
- an imposed soul wound or spirit scar.

A condition such as Charmed or Frightened is not automatically a Spiritual Affliction. It qualifies only when its Source Rule identifies a spiritual source or the effect is detected as such.

## Soul Anchor

Use the universal Soul Anchor rules and the Spirit Awakening core.

A Soul Anchor is the root that keeps an awakened identity coherent. It is not automatically a physical object, destructible Anchor, full companion, or Cultivation Asset.

Ordinary damage cannot destroy it. Severing, replacing, consuming, or rewriting it requires an explicit high-authority rule and a recovery or reconstruction procedure.

## Spiritual Anchor

A **Spiritual Anchor** is an external sustaining node for a spirit, curse, possession, Domain, route, manifestation, prison, or other spiritual effect.

A targetable Spiritual Anchor must record:

- form and location;
- AC or contest DC;
- Hit Points, if it can be damaged;
- saving throws, if any;
- resistances and immunities;
- Source CL;
- the effect it sustains;
- what happens when suppressed, moved, or destroyed;
- whether it can be repaired or replaced.

Destroying a Spiritual Anchor ends or weakens only the effect it sustains. It does not automatically destroy a Complete Soul.

## Spirit Cultivation Asset

A **Spirit Cultivation Asset** is a separately targetable spiritual creation or expression such as a Soul Fragment, seal, manifested court, spirit body, dream body, witness stone, mirror-self, gravebeat node, or similar construct.

Every Asset must record:

- size and type;
- AC;
- Hit Points;
- movement, if any;
- saving throws;
- resistances and immunities;
- Source CL;
- action economy;
- range from its creator or Anchor;
- destruction consequence;
- dismissal and reconstruction procedure.

An Asset is never a free additional character unless a rule explicitly upgrades it to a full companion.

---


# 4. Spiritual Perception and Targeting

## Perceiving a Spirit

A spirit may be visible to ordinary sight, visible only to Spiritual Sense, concealed by an effect, hosted inside another target, or present only through an Anchor or Imprint.

Perceiving a spirit does not automatically:

- reveal its true name;
- identify its full Nature;
- reveal every Bond or Anchor;
- permit targeting through total cover;
- make an incorporeal spirit vulnerable to ordinary physical attacks.

## Affecting Spirits

An attack or effect can affect a spirit when at least one of the following applies:

- it is a Spirit Awakening feature that targets a spirit, soul, possession, or spiritual Asset;
- it is magical, cultivated, spiritual, divine, artifact-based, or expressly spirit-affecting;
- it targets the spirit's legal body, vessel, manifestation, or Anchor;
- the spirit's Source Rule says ordinary physical attacks can affect it.

A weapon does not become spirit-affecting merely because its wielder can perceive spirits. A feature must grant the interface.

## Concealment Contest

When a spiritual effect is concealed by equal or higher authority, make a Cultivation Check against its save DC. If no DC is recorded, use:

`8 + source Proficiency Bonus + source key ability modifier`

Success reveals only the information permitted by the detecting feature. It does not automatically suppress the concealment.

---


# 5. Hosting and Possession

## Hosting

Hosting is the presence of a spirit in or upon a Host. Hosting alone does not grant control of the Host.

A Hosting Source Rule must state:

- whether the Host is willing;
- the entry procedure;
- the range and legal target;
- the spirit's permitted senses and communication;
- whether it can use Nature Expressions;
- whether it can influence or control the Host;
- duration;
- dismissal and expulsion procedure;
- what happens if the Host, vessel, or spirit is damaged;
- whether Bond Strain applies.

## Possession

**Possession** is hostile or contested hosting that grants the possessing presence influence over the Host's body, actions, senses, emotions, memories, or spiritual functions.

Defining possession does not grant it. A Source Rule must authorize an attempt.

Every possession effect must specify one control grade.

### Grade 1: Influence

The presence can communicate, create urges, alter surface emotion, observe through limited senses, or impose a narrow effect. It does not choose the Host's actions or movement.

### Grade 2: Contested Control

The presence can compel one or more explicitly listed actions, reactions, movements, speech acts, or technique restrictions. The Host retains its own turn except for the printed intrusion.

### Grade 3: Dominant Control

The presence controls most or all of the Host's turn or body. This grade requires an explicit high-authority Source Rule. It must state what choices remain with the Host, whether the possessor can spend the Host's resources, and how often the Host repeats resistance.

A possessing presence cannot spend the Host's Path resources, item charges, permanent sacrifices, companion actions, or once-limited abilities unless the Source Rule expressly permits each category.

## Default Resistance Requirements

A hostile possession Source Rule must provide:

- initial save or opposed check;
- repeat-save timing;
- the ability used to resist;
- effect on success and failure;
- duration;
- removal or expulsion method;
- Anchor or range dependency;
- Source CL.

If a draft possession omits repeat-save timing, it is incomplete and cannot be published as executable player content.

## Damage to the Host

Damaging a Host does not automatically damage or expel the possessing spirit. Damaging the possessing spirit does not automatically damage the Host.

A Source Rule may create sympathetic damage, but must state:

- damage split or transfer;
- damage type;
- whether Resistance applies;
- whether either side can choose to absorb the damage;
- whether the transfer can reduce a target below 1 Hit Point;
- whether the effect can recurse.

## Ending Possession

Possession can end through one or more printed routes:

- successful repeat save;
- voluntary departure;
- expiry of duration;
- Exorcism;
- destruction or suppression of its Spiritual Anchor;
- removal of the vessel;
- violation or completion of the possessing effect's condition;
- defeat of the possessing spirit;
- completion of a named recovery procedure.

A Host reaching 0 Hit Points does not automatically end possession unless the Source Rule says so.

---


# 6. Exorcism

## What Exorcism Is

**Exorcism** is the diagnosis, suppression, separation, expulsion, purification, release, binding, or destruction of an unlawful or harmful spiritual presence or Spiritual Affliction.

Exorcism does not automatically mean destroying a spirit. Orthodox exorcism usually attempts the least destructive result sufficient to protect the Host and end the intrusion.

## Exorcism Modes

A Source Rule granting Exorcism should authorize one or more of the following modes.

### Diagnose

Identify the broad category of the Intruder, Affliction, Anchor, invitation route, possession grade, or recovery condition.

### Suppress

Make the presence or Affliction inactive for a printed duration. Suppression does not remove it and does not reset its elapsed duration unless stated.

### Separate

Force an Intruder or foreign influence out of the Host into a legal manifestation, vessel, spiritual outline, or adjacent space.

### Expel

Remove the presence from the immediate site, battlefield, Host, Domain, plane, or layer of reality for a printed duration.

### Cleanse

End or reduce spiritual contamination, emotional corruption, dream intrusion, curse pressure, memory interference, or similar Affliction.

### Release

Break or suppress a coercive Binding Seal, prison, possession, or command so that a willing spirit can leave.

### Destroy

Destroy an ordinary hostile Imprint, parasite, fabricated spirit construct, or other target expressly eligible for destruction. Destroying a Complete Soul requires explicit higher authority.

## Exorcism Target

Exorcism targets the spiritual presence, Affliction, Bond, seal, Anchor, or Imprint—not automatically the Host.

The Host may be the physical point through which the effect is reached. The feature must state whether touch, sight, Spiritual Sense, a Resonance Mark, a true name, a vessel, or an Anchor is required.

## Accepted Presence Restriction

Ordinary Exorcism cannot remove an Accepted Presence unless:

- the Host currently requests separation;
- the Bond or Hosting Source Rule permits withdrawal;
- the presence has become coercive, corrupted, or hostile;
- the effect expressly targets consensual separation;
- or a higher-authority rule overrides the relationship.

A willing stable Covenant Bond is not an ordinary hostile possession.

## Exorcism Resolution

Use the procedure printed by the granting feature. When a feature refers to an **Exorcism Check** without defining one, make a Cultivation Check against the highest relevant DC among:

- the Intruder's Cultivation Save DC;
- the Affliction's save DC;
- the binder's Cultivation Save DC;
- the Anchor's contest DC.

If none is recorded, use the default concealment formula based on the source.

## Authority Results

Unless a Source Rule gives a more specific result:

- **Lower Source CL:** A successful Exorcism Check can fully apply one ordinary authorized mode.
- **Equal Source CL:** A successful check can fully apply one ordinary mode when the target's Source Rule permits removal; otherwise it suppresses the effect for the scene, reduces severity by one stage, or exposes its Anchor or recovery condition.
- **Higher Source CL:** A successful check creates a temporary opening: suppress until the end of the target's next turn, grant the Host an immediate repeat save with Advantage, expose the sustaining Anchor, or prevent worsening for the scene. It does not permanently remove the effect unless the higher-authority Source Rule allows it.
- **At least 5 Source CL lower:** A successful high-Realm exorcism may apply printed battlefield expulsion or scene-long exclusion, but permanent soul destruction, divine annulment, Secret-Law reversal, and reincarnation changes still require explicit permission.

Failure does not automatically worsen an effect unless the Source Rule states a backlash. A failed deep rite should still establish whether the effect is beyond the exorcist's present authority.

## Path-Level Exorcism Architecture

The recommended final Path architecture is:

1. **Universal diagnosis:** Spiritual Sense and Soul Gaze identify possession, contamination, memory alteration, dream intrusion, and other broad spiritual disturbances.
2. **Optional early specialization:** a CL4+ Cultivation Insight grants a limited battlefield exorcism before the universal core feature arrives.
3. **Universal advanced exorcism:** the previous CL13 exorcism feature is replaced by the Path's full **Spiritual Exorcism** feature, retaining battlefield and deep-rite modes.
4. **Exorcist Subpath:** remains the dedicated combat and high-authority specialist with Designations, Banishment Strike, Purification Bell, Binding Seal, and Grand Exorcism.
5. **Spirit Companions Sphere:** retains bond-specific and name-specific procedures such as Exorcist's Mercy, Break the Cruel Seal, Possession Contest, Rebirth of the Broken Spirit, and True Name Mercy.

This architecture prevents duplication while ensuring that every experienced Spirit Awakener eventually understands exorcism.

---


# 8. Banishment and Separation

Banishment has five distinct grades. A feature must state which grade it applies.

## Grade 1: Exposure

The spirit or presence becomes perceptible and cannot hide its possession link or manifestation until the printed duration ends.

## Grade 2: Separation

The spirit is forced out of a Host into an adjacent legal space, vessel, or temporary spiritual outline. Separation does not determine what happens after the printed duration.

## Grade 3: Local Expulsion

The spirit is removed from the immediate space or battlefield until the printed return time. This does not send it to another plane.

## Grade 4: Scene or Planar Expulsion

The spirit is excluded for the scene or returned to its home plane or spiritual layer. This normally requires lower Source CL, lack of a sustaining Anchor, or a successful authority contest.

## Grade 5: Permanent Exclusion or Destruction

The spirit cannot return through the same route, is permanently barred, passes onward, reincarnates, or is destroyed. This requires an explicit high-authority Source Rule and a stated consequence.

A feature that says only "banish" is incomplete until its grade, return condition, Anchor interaction, and Source CL limit are stated.

---


# 9. Spiritual Harm Hierarchy

Spiritual harm must use a named severity. A vague instruction to apply a "spiritual consequence" is not executable.

## Disturbance

A short-lived spiritual imbalance, emotional disruption, minor contamination, or pressure effect. It normally ends during the scene, after a rest, or after a simple printed centering action.

## Affliction

An ongoing curse, possession, contamination, dream intrusion, memory interference, hostile vow, or similar effect with a defined removal procedure.

## Spirit Scar

A persistent but reconstructable mark on the soul. A Spirit Scar must state:

- its exact mechanical effect;
- whether it is visible to Spiritual Sense;
- its Source CL;
- what makes it worsen;
- the procedure that reduces or removes it.

A Scar should not require the GM to invent a penalty.

## Soul Wound

A serious injury to spiritual structure. A Soul Wound must state whether it affects:

- maximum Resonance;
- use of a specific feature;
- a Soul Anchor expression;
- memory access;
- identity coherence;
- Soul Splitting;
- Domain Manifestation;
- a Bond or Companion relationship.

It must also state treatment and reconstruction.

## Severance

A Bond, Anchor connection, Soul Fragment, spiritual route, name-link, memory chain, or other structural relationship is cut. Severance affects only the named relationship unless a rule expressly extends it.

## Soul Destruction

A Complete Soul is consumed, erased, irrecoverably scattered, or otherwise ended. This is never an implied result of Hit Point loss, Psychic damage, exorcism, destroying an Asset, or breaking an Anchor. It requires explicit high authority.

---


# 10. Memory and Identity

## Memory Effects

Memory effects use one of the following categories.

- **Obscured:** The memory exists but cannot currently be accessed.
- **Altered:** Specific details are changed or overlaid.
- **Scarred:** The memory remains but carries a persistent emotional or spiritual effect.
- **Removed:** The target cannot recall the specified memory, but the memory may remain in an Anchor, dream, record, or soul structure.
- **Rewritten:** The target accepts a replacement memory as part of continuity.

A memory effect must state:

- the exact memory scope;
- duration;
- whether the target knows something is wrong;
- whether records, witnesses, Soul Anchors, and external evidence remain;
- the removal or restoration procedure;
- whether the change affects identity or only recollection.

## Identity Effects

Identity effects use one of the following categories.

- **Pressure:** A temporary imposed role, emotion, name, command, or self-concept.
- **Fracture:** Conflicting identities or soul patterns interfere with one another.
- **Displacement:** The target's identity is pushed aside while another presence acts.
- **Replacement:** A new identity attempts to overwrite or permanently supplant the old one.

Identity Replacement is high-authority and must provide repeated resistance, Source CL, Anchors, a completion condition, and reconstruction rules.

Immortal Spirit and similar sovereign-identity features protect against involuntary alteration according to their printed rules. They do not prevent voluntary transformation, persuasion, grief, chosen oaths, or consequences arising from the character's own decisions.

---


# 11. Destruction, Death, and Reconstruction

Always distinguish the following events.

## Body Destroyed

The physical body dies or is destroyed. The Complete Soul follows the death, afterlife, reincarnation, Soul Anchor, and Path rules that apply to it.

## Manifestation Destroyed

A temporary manifested form is destroyed. The spirit normally retreats, suffers Bond Strain, loses access to manifestation, or requires an Offering according to its Source Rule. The Complete Soul is not automatically destroyed.

## Vessel Destroyed

The container holding or sheltering a spirit is destroyed. The Source Rule must state whether the spirit:

- escapes;
- manifests adjacent to the vessel;
- retreats to an Anchor;
- becomes trapped in debris;
- suffers a Spirit Scar or Soul Wound;
- is banished;
- requires reconstruction.

## Spiritual Anchor Destroyed

The sustained effect ends, weakens, or loses access to a route. The complete spirit or soul survives unless the Source Rule explicitly identifies the Anchor as its complete core.

## Soul Fragment Destroyed

Use the Soul Fragment's printed backlash and recovery. The originating Complete Soul is not destroyed.

## Complete Soul Destroyed

Use only an explicit high-authority rule. The rule must state whether restoration, reincarnation, retrieval, divine intervention, or reconstruction remains possible.

## Reconstruction Categories

- **Manifestation repair:** Restore access to a temporary form.
- **Vessel replacement:** Prepare a new body, item, shrine, dream, mark, or container.
- **Anchor reconstruction:** Rebuild the sustaining node and re-establish the connection.
- **Fragment reintegration:** Recover, recreate, or reintegrate a Soul Fragment.
- **Spirit reconstruction:** Restore a damaged but surviving Complete Soul.
- **Soul restoration:** Recover a destroyed, erased, consumed, or displaced soul; always high-authority.

The Spirit Companions talent **Rebirth of the Broken Spirit** is a specific bonded-spirit reconstruction procedure. It does not create a universal right to restore every spirit or soul.

---


# 12. Dreams and Dream Entry

Spirit Awakening frequently interacts with dreams, but the Path does not automatically grant unrestricted dreamwalking.

A Source Rule that permits dream entry must state:

- entry target and range;
- whether the dreamer must be sleeping, willing, Resonance Marked, bonded, or linked through an Anchor;
- action or ritual time;
- Resonance or other cost;
- whether a dream body is a Cultivation Asset;
- what happens to the physical body;
- how the entrant leaves;
- what happens if the dream body is destroyed;
- whether damage, conditions, memories, or objects cross between dream and waking reality;
- Source CL and concealment.

The Dreams Sphere governs general dream techniques. A Spirit Subpath may create a narrower exception. Neither automatically grants the other.

---


# 13. Spirit Relationships, Bonds, Companions, and Bond Strain

Use the Sphere of Spirit Companions for Covenant Bonds, Binding Seals, Hosting Bonds, Temporary Scene Bonds, Needs, Offerings, Taboos, Nature Expressions, and Bond Strain. Use the Universal Bonded Companions Combat Chassis R2 for a full companion’s statistics, advancement, command economy, injury, continuity, and restoration.

## Bond Is Not Ownership

A voluntary Bond establishes a relationship and an exchange of permissions. It does not make the spirit an item, technique list, or extension of the cultivator's will.

Unless a specific Binding rule says otherwise:

- the spirit retains independent goals and judgment;
- the spirit can refuse actions outside the Bond's permissions;
- the cultivator does not gain the spirit's Spheres or every Nature Expression;
- the spirit does not gain the cultivator's Path resources or actions;
- either party can invoke the Bond's printed withdrawal, renegotiation, or crisis procedure;
- neither party can spend the other's resources unless the Bond expressly permits it.

## Relationship Tiers

### Minor Spirit Agreement

A limited bargain, service, invitation, or temporary exchange. It grants only the specific expression or permission written in the Agreement. It does not create a full companion stat block or permanent shared action economy.

A Minor Agreement must record duration, service, Offering, Taboo, legal manifestation, and ending condition.

### Major Spirit Bond

A continuing Covenant, Binding, or Hosting relationship with mutual benefits and obligations. It uses the Required Bond Record below.

A Major Bond is not automatically a full companion. It can grant manifestations, shared cultivation, Nature Expressions, Hosting, or other printed benefits without granting an independent combat turn.

### Full Spirit Companion

A spirit explicitly using the Universal Bonded Companions Combat Chassis R2. It has complete statistics, action-economy rules, advancement, Continuity Model, injury, and restoration procedures.

A Path feature, Sphere talent, Subpath, Insight, or story event must explicitly grant or upgrade a relationship to full-companion status. The Spirit Awakening Path alone does not do so.

## Full Spirit Companion Interface

A full Spirit Companion is a spirit that has been explicitly upgraded into a full combat-capable Bonded Companion.

Use the **Universal Bonded Companions Combat Chassis R2** for:

- Companion Archetype and ability scores;
- AC, Hit Points, Speed, skills, senses, and Companion Strike;
- initiative, commands, Dodge default, Reactions, and movement;
- Continuity Model and 0-Hit-Point result;
- rest recovery and restoration;
- Realm Evolutions and Realm Suppression.

Use this reference and the **Sphere of Spirit Companions** for:

- Complete Spirit, Soul Fragment, and personhood status;
- Spirit Nature, Nature Tags, and Nature Expressions;
- Bond Mode, Hosting, possession, and Binding Seals;
- Need, sustenance, Offerings, Taboos, Bond Strain, crises, and consent;
- manifestations, vessels, Spiritual Anchors, and spirit reconstruction;
- exorcism, release, true names, and permanent spiritual harm.

A Nature Expression commanded through a full companion uses the action-economy interface printed in the companion chassis. It does not grant an additional action alongside the companion’s Attack unless its own rule expressly says it is a rider or replaces one strike.

A Major Spirit Bond remains distinct from a full Spirit Companion. A spirit can be a significant ally, Host, guide, weapon spirit, shrine guardian, or Manifesting Source without receiving a full combat turn.

## Required Bond Record

Every Major Spirit Bond must record:

- spirit name and Nature;
- origin category;
- Source CL and Realm;
- current embodiment state;
- Bond Mode: Covenant, Binding, Hosting, or another printed mode;
- consent state of each party;
- exact permissions granted to each party;
- one benefit provided to the cultivator;
- one benefit provided to the spirit, if mechanical;
- Appetite or Need and exact sustenance cadence;
- one Minor Offering;
- one Major Offering;
- one Taboo;
- one ordinary crisis;
- one severe crisis;
- manifestation or Hosting form;
- available Nature Expressions;
- action-economy interface;
- range, tether, and legal movement;
- dismissal and recall procedure;
- withdrawal or renegotiation procedure;
- destruction, retreat, and reconstruction procedure;
- whether the relationship is a Minor Agreement, Major Bond, Hosted Spirit, Bound Spirit, Manifesting Source, or full companion.

No entry can substitute “an appropriate Offering,” “a meaningful price,” “a suitable crisis,” or “a trait approved by the GM” for these recorded choices.

## Sustenance and Offering Values

A spirit's entry must define its offerings rather than asking the GM to decide from nothing.

- **Routine Sustenance:** prevents the exact neglect consequence recorded by the spirit. It does not reduce Bond Strain unless the Bond says it also counts as an Offering.
- **Minor Offering:** reduces Bond Strain by 1, minimum 0, after the printed time and conditions are met.
- **Major Offering:** reduces Bond Strain to 0 or restores one disabled Nature Expression, as the spirit's entry states.
- An inappropriate or trivial gift has no mechanical effect.
- A substitute Offering requires a Cultivation Check against the spirit's Cultivation Save DC and must match its Nature or Need. Success treats it as a Minor Offering. Failure has no effect unless the attempt violates a Taboo.

A Bond should not add a separate generic maintenance counter. Use sustenance cadence, Offerings, Bond Strain, Resonance, CP, or another explicitly defined resource.

## Bond Strain

Bond Strain measures damage to the relationship, unsafe coercion, denied Need, violated Taboo, or overextension of the spirit's manifestation.

A voluntary Covenant does not gain Strain merely because the spirit disagrees with the cultivator. Strain is added only by a listed trigger in the Bond, Sphere, companion rule, or Source Rule.

## Bond Crisis Procedure

When Bond Strain reaches 3, resolve the first applicable result:

1. **Taboo violated:** apply the spirit's recorded severe crisis.
2. **Need deliberately denied or coercive command issued:** the spirit refuses the command, disables one recorded Nature Expression for the scene, and applies its ordinary crisis.
3. **Manifestation or vessel forced beyond safe limits:** the manifestation ends, the spirit retreats to its vessel or Anchor, and cannot manifest again until a Minor Offering is completed.
4. **No specific trigger:** apply the spirit's recorded ordinary crisis.

After the crisis is resolved, Bond Strain becomes 1 unless the Source Rule states that the Bond broke, the spirit escaped, the Host remains contested, or a severe crisis establishes another value.

## Independent Action and Command Economy

A bonded spirit acts only through one of these printed structures:

- an expression resolved as part of the cultivator's action;
- a Reaction or triggered response granted by the Bond;
- a Manifestation with explicitly listed actions;
- a full companion turn under the companion chassis;
- an independent NPC turn controlled by the GM when the spirit is not a player-controlled companion.

A Bond does not grant a free additional turn. A spirit that acts independently can choose actions consistent with its Nature and goals, but it cannot use player-only features unless its record grants them.

## Growth and Renegotiation

When a spirit advances, evolves, changes Nature, acquires a new body, gains an office, or reaches a new Realm, update its Spirit Record and Bond Record.

Growth does not automatically increase every Bond benefit. The relationship must state one of the following:

- benefits scale automatically from the spirit's Source CL;
- benefits scale from the cultivator's CL;
- benefits remain fixed until a named refinement;
- the parties must renegotiate or complete a cultivation procedure.

A spirit that outgrows a vessel, Offering, or Bond can trigger its recorded renegotiation procedure. The GM cannot remove a player benefit solely because growth seems narratively inconvenient; use the printed procedure.


# 14. Spiritual Domains

A Spirit Domain is a scene-scale spiritual law, court, atmosphere, relationship field, dream-space, or authority zone.

Every Domain must state:

- origin point;
- shape and radius;
- movement, if any;
- duration;
- Concentration;
- Resonance cost;
- who is affected;
- entry and start-of-turn timing;
- its ordinary effects;
- its Subpath expression;
- concealment and perception;
- Anchor dependency, if any;
- Domain collision rule;
- end conditions.

## Domain Types

- **Personal Domain:** centered on and moves with the cultivator.
- **Anchored Domain:** centered on a Spiritual Anchor, shrine, Asset, or location.
- **Projected Domain:** originates from a Soul Fragment, Companion, manifestation, or other permitted origin.
- **Court Domain:** primarily governs spirits, bonds, names, invitations, vows, or spiritual relationships.
- **Inner Domain:** exists inside a soul, dream, inner palace, or possession conflict; requires a specific entry rule.

## Domain Collision

Use the Spirit Awakening core rule:

- compatible Domains coexist;
- contradictory expressions contest by Source CL;
- equal Source CL uses a Cultivation Check;
- losing suppresses only the contradictory expression unless a Source Rule states that the whole Domain collapses.

A Domain is not automatically an Anchor, prison, anti-teleport effect, or companion command zone. Those effects require explicit text.

---


# 15. Realm Suppression

When Spirit Awakening is Realm Suppressed:

- use suppressed effective CL for dependent Source CL;
- features above the suppressed CL cannot be activated;
- active higher-CL Path, Subpath, Domain, Soul Fragment, possession, and spirit expressions end or become dormant as their rules state;
- Soul Anchor existence, ordinary memory, personality, and relationships remain;
- a Companion's independent statistics do not change unless its Source Rule scales from the suppressed cultivator;
- a Bond remains a Bond even when higher expressions are unavailable;
- suppression does not itself exorcise, sever, erase, or destroy a spirit.

Suppressing a possessing or hosted effect does not automatically decide where the spirit goes. Its Source Rule must state whether it manifests, retreats, remains dormant, or is expelled.

---
