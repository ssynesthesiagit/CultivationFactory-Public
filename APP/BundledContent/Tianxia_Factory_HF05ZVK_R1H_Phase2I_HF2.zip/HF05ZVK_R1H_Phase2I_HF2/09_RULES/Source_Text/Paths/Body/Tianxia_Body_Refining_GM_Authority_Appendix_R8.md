# Tianxia Body Refining — GM Authority Appendix R8

**Publication state:** Path-specific GM authority source module.  
**Mechanical state:** Organization, deterministic campaign procedures, and authority separation; no intentional changes to Core R2, the 42 Subpaths, or the 77 directly Body-linked Insights.  
**Final destination:** This material is intended to become the Body Refining section of the later **Universal Cultivation Authority Appendix** in the GM Guide. It is not yet inserted into that book.

## How to Use This Appendix

Use this appendix when ordinary player-facing procedures do not fully resolve:

- optional campaign Injury systems;
- Hidden Injury, rupture, severance, destroyed organs, or destroyed bodily cultivation systems;
- Major Reconstruction Components and replacement anatomy;
- artifact, Secret, Tribulation, breakthrough-scale, or Immortal reconstruction;
- Foundation-linked anatomy and Foundation repair;
- Body Assets, living weapons, and detached or projected bodily materials;
- external-projection authority;
- bodily suppression and Realm Suppression;
- complete bodily destruction or Tier V conceptual loss.

The GM supplies world procedures only where a Source Rule or adopted campaign module invokes them. The GM cannot reduce or expand a player feature after activation.

## Authority Order

1. Explicit Source Rule.
2. Body Refining Core R2 / Player Path Chapter R8.
3. Full Body Refining Shared Procedures R1.
4. Individual Subpath and Subpath Procedure Addendum R8.
5. Central Insight or other legal character option.
6. Universal Cultivation Authority procedures.

---

# Part I — Canonical Terminology

**Status:** Integration candidate terminology map.  
**Purpose:** Prevent compilation-history labels, undefined procedure names, and obsolete dependency references from returning during publication, PHB, Factory, or GM Screen work.

| Earlier or ambiguous term | Canonical R7 treatment |
|---|---|
| Additional Open Subpaths | Open School entries in the single canonical catalog |
| Additional Restricted Subpaths | Restricted Scripture entries in the single canonical catalog |
| Additional Rare Subpaths | Rare Inheritance entries in the single canonical catalog |
| Additional Forbidden Subpaths | Forbidden Method entries in the single canonical catalog |
| Body Refining Subpath Procedure Addendum R1–R6 | Body Refining Subpath Procedure Addendum R7 |
| Compilation Draft v0.1 | Integrated Subpath Compendium R7 Candidate |
| “counts as larger” without context | Functional Size under Shared Procedures R1 |
| severe bodily damage from ordinary combat narration | No Injury unless an explicit Source Rule invokes the bodily-harm hierarchy |
| severing label | Temporary impairment unless the rule expressly creates anatomical severance |
| detached blood, bone, hair, organ, or limb under Body Refining | Not controllable or harvestable unless an explicit Source Rule grants that authority |
| bodily shockwave, roar, breath, projectile, or afterimage | External projection only to the exact extent printed by the Source Rule |
| Foundation damage | Separate from ordinary bodily Injury and reconstruction |

## Canonical Catalog

The integrated Body Refining catalog contains **42 Subpaths**, numbered 1 through 42 without gaps or duplicates.


# Part II — Full Body Refining Shared Procedures R1

**Project:** *Tianxia: Cultivation — The Immortal’s Path*  
**Rules family:** Body Refining  
**Status:** Candidate shared procedure layer  
**Date:** 2026-07-12  
**Design constraint:** Non-nerfing normalization; this document does not change inherited feature values.

---

# 1. Purpose and Scope

Body Refining is expressed through cultivated anatomy, physical force, bodily transformation, internal circulation, natural weapons, integrated weapons, and explicit exceptions that allow bodily force to operate beyond the cultivator's immediate body.

This document supplies one executable grammar for recurring Body Refining procedures. It exists so a player, GM, or AI does not have to invent the consequences of a severed limb, a suppressed organ, an altered body plan, a detached bone weapon, a failed reconstruction, or a Stamina Guard interaction.

These procedures do **not** make ordinary combat more lethal by default. In particular:

- Losing Hit Points does not automatically create an injury.
- A critical hit does not automatically sever a limb.
- Falling to 0 Hit Points does not automatically create a Hidden Injury.
- A creature is not dismembered, permanently transformed, or deprived of cultivation unless a Source Rule expressly creates that result or the campaign has adopted a separate universal injury procedure.
- Flavor text never creates anatomy, immunity, projection, regeneration, or destruction authority that the rules do not print.

This document governs only a recurring procedure that an explicit Source Rule invokes. A specific feature may override these defaults to the extent it says so.

---

# 2. Rule Hierarchy

Resolve a Body Refining question in this order:

1. The explicit Source Rule creating, modifying, suppressing, damaging, or restoring the effect.
2. The current Body Refining core chapter.
3. This Body Refining Shared Procedures document.
4. Universal Tianxia rules, including Scene, Source CL, Realm Suppression, Foundations, Methods, Recorded Arts, Forged Techniques, Assets, training, injury, and reconstruction.
5. The underlying D&D 5.5e procedure where Tianxia has not replaced it.

A more specific rule overrides a more general rule only for the stated exception.

A conventional comparison such as “this resembles a barbarian rage,” “this is like a monk technique,” or “this should work like a spell” has no authority. Body Refining features are cultivation rules, not imported class or spell packages.

---

# 3. Core Terms

## Activation

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, or other Source Rule, including every attack, target, movement, projectile, repeated strike, and rider that the use expressly creates.

A once-per-activation limit applies across the entire use.

## Body Refining Technique

A **Body Refining technique** is a supernatural procedure authorized by a Source Rule and expressed through:

- the cultivator's body;
- a natural bodily weapon;
- an integrated weapon;
- bodily material expressly separated by a Source Rule;
- an embodied or detached Body Asset;
- another printed bodily medium.

A Body Refining technique is not automatically an ordinary weapon attack, spell, maneuver, or ability check. Its Source Rule states the procedure it uses.

## Effective CL

**Effective CL** is the Body Refining CL currently available after Realm Suppression or another explicit modifier.

## Source CL

**Source CL** measures the cultivation authority of a feature, injury, transformation, Asset, Anchor, bodily system, treatment, or countermeasure.

Unless a rule says otherwise:

- a Path, Subpath, Sphere, Recorded Art, Forged Technique, or Insight uses the user's effective CL;
- a Body Asset or bodily Anchor uses the Source CL of the feature that created it;
- a permanent injury retains the Source CL of the effect that created it until repaired, overwritten, or transformed;
- a Foundation or Method uses the bearer’s effective CL unless its feature prints a fixed Source CL;
- an item uses its printed Source CL, or the authority assigned by its item rules.

## Anatomy Record

An **Anatomy Record** identifies the structures a creature actually possesses and which rules depend on them. A normal humanoid record may be implicit until an effect changes it. A nonhuman, transformed, multi-limbed, organ-replaced, or otherwise unusual body requires an explicit record.

An Anatomy Record includes, as relevant:

- manipulators, locomotor limbs, wings, tails, and other movement structures;
- sensory organs;
- breath and voice structures;
- vital organs;
- cultivation-critical organs or networks;
- natural weapons;
- additional limbs or organs;
- replacement structures;
- permanent transformations;
- Foundations or Methods embodied as anatomy;
- structures required by particular techniques.

## Anatomical Structure

An **anatomical structure** is one recorded body part, organ, system, or cultivated physical structure.

## Bodily Cultivation System

A **bodily cultivation system** is an anatomical or energetic structure through which Body Refining functions, such as refined meridians, marrow furnaces, a transformed spine, cultivated organs, a blood circuit, a natural weapon system, or another named structure.

Ordinary anatomy is not automatically a cultivation system. A Source Rule must identify that relationship.

## Embodied Structure

An **embodied structure** remains part of the creature and normally shares its Hit Points, space, conditions, action economy, and death state. It is not independently targetable unless a Source Rule says so.

## Detached Bodily Material

**Detached bodily material** is blood, bone, hair, skin, marrow, an organ, a limb, a tooth, a scale, a spine, or another real part that has left the creature's body.

Detached material is not under the creature’s control unless a Source Rule says so.

## Body Asset

A **Body Asset** is a separately profiled cultivation structure created from, attached to, projected from, or grown by the body. A Body Asset has its own statistics only when the Source Rule grants them.

## Natural Bodily Weapon

A **natural bodily weapon** is a body part used to attack because a Source Rule grants it that function. It is normally an unarmed strike unless the rule expressly treats it as a weapon.

## Integrated Weapon

An **integrated weapon** is a real or projected weapon currently benefiting from an explicit Body Refining integration feature. Proficiency alone does not integrate a weapon.

## Transformation

A **transformation** changes a creature's size, anatomy, body plan, material, movement structures, natural weapons, or bodily state through an explicit Source Rule.

A stance, aura, cosmetic sign, or temporary numerical benefit is not a transformation unless the rule identifies it as one or changes anatomy.

## Physical Injury and Cultivation Injury

A **physical injury** impairs anatomy or bodily function.

A **cultivation injury** damages a cultivated structure, Path function, Foundation, Method, meridian, or other supernatural system.

One event can create both, but the Source Rule must identify each consequence separately.

---

# 4. Source CL and Realm Disparity

When two bodily cultivation authorities directly contest and no rule supplies another procedure, use these bands.

## Opposing Source CL 6 or More Lower

The stronger effect has decisive lower-Realm authority.

- It may automatically overcome ordinary resistance, suppression, restraint, or reconstruction barriers created by the lower effect after any explicitly required initial roll.
- A lower-Realm temporary bodily state normally cannot prevent a clearly authorized higher-Realm transformation, reconstruction, or severance defense.
- This does not defeat an artifact, Secret Law, Immortal clause, named immunity, or explicit absolute protection.

## Opposing Source CL 3–5 Lower

The stronger effect has substantial authority.

- Resolve the printed initial attack, save, or check.
- If an ongoing hostile restraint or suppression has no repeat cadence, the affected creature may repeat its resistance at the end of every second turn.
- A suitable specialist may attempt one counterprocedure per Full Cultivation Session outside combat.

## Opposing Source CL Within 2

The effects have contested authority.

- Resolve every printed attack, save, check, Anchor, duration, cost, and treatment requirement.
- If a direct contest requires a check but supplies no DC, use the opposing user's Cultivation Save DC.
- If neither side has a creature user, use `10 + half the opposing Source CL, rounded down`, plus any printed authority modifier.

## Opposing Source CL 3 or More Higher

The lower effect confronts superior authority.

- The higher effect normally blocks, shortens, suppresses, or limits the lower effect.
- A lower effect can still succeed when it has a printed weakness, accumulated setup, broken Anchor, major sacrifice, or successful Cultivation Check after the target’s normal resistance.
- A successful lower-authority hostile suppression or restraint normally lasts no longer than 1 round unless its setup expressly overcomes the disparity.

## Explicit Higher Authorities

Secret, artifact, Immortal, conceptual, Tribulation, Foundation, Samsara, Void, Fate, Name, and similarly tagged authorities use their printed rules. Source CL does not erase their special requirements.

---

# 5. Ordinary Damage Is Not an Injury

Hit Point damage represents injury, exhaustion, spent defenses, disrupted posture, minor wounds, and loss of combat viability at an abstract level.

Unless a Source Rule says otherwise:

- healing Hit Points repairs the abstract combat loss;
- damage does not select or disable an anatomical structure;
- a critical hit does not sever or destroy anatomy;
- damage reduced to 0 does not create a rider that requires the target to take damage;
- reaching 0 Hit Points uses the normal 0-Hit-Point and death-save procedure;
- being killed does not by itself identify which body structures were destroyed;
- complete bodily destruction occurs only when a rule expressly says the body is disintegrated, consumed, erased, reduced beyond reconstruction, or completely destroyed.

A campaign may adopt a separate universal injury procedure. If it does, that procedure must state its trigger, roll, injury ceiling, Source CL, treatment, and interaction with these rules. A GM or AI may not improvise permanent bodily harm merely because an attack was dramatic.

---

# 6. Bodily Harm Severity Hierarchy

Use this hierarchy when a Source Rule invokes a category but does not define a different structure.

## Tier I — Disruption or Lingering Physical Injury

Examples:

- a strained tendon;
- a temporarily numb limb;
- a minor fracture that imposes a printed penalty;
- brief inability to transform;
- a temporary Speed reduction;
- a Bleeding state with a printed trigger;
- a one-scene bodily deformation.

**Default duration:** Until the printed save, scene end, Short Rest, or treatment.  
**Default recovery when the Source Rule invokes this shared procedure but omits one:** 10 uninterrupted minutes of suitable treatment or completion of a Short Rest.

A Tier I state must still state its mechanical effect. The label alone creates no penalty.

## Tier II — Hidden Injury

A **Hidden Injury** is internal cultivation harm that remains after ordinary wounds appear healed.

Examples:

- damaged meridian circulation;
- marrow that no longer refines correctly;
- a partially sealed organ furnace;
- internal bleeding that interferes with Stamina recovery;
- a technique recoil scar;
- a damaged natural-weapon root;
- a Foundation-linked bodily fault that has not yet become Foundation damage.

A Hidden Injury record must state:

1. Name and affected structure.
2. Mechanical penalty.
3. Source CL and originating save DC.
4. Whether it is visible, concealed, or detectable only by a listed procedure.
5. Valid diagnosis methods.
6. Valid treatment methods.
7. Required materials.
8. Failure consequence.
9. Whether treatment removes, suppresses, or transforms it.

**Default diagnosis:** 10 uninterrupted minutes and a Wisdom (Medicine), Intelligence (Medicine), Pressure Points, Meridian Physician, or suitable Cultivation Check against the injury’s save DC. If none exists, use `10 + half the injury Source CL, rounded down`.

**Default treatment:** One Full Cultivation Session led by a valid treatment source whose Source CL is within 2 of the injury, plus a successful check against the diagnosis DC. A success removes the Hidden Injury. A failure consumes the session and any expendable materials but does not worsen the injury unless the treatment warned of that risk.

A treatment source 3–5 Source CL lower cannot remove the injury by this default. On a success, it suppresses the printed penalty for 24 hours. A source 6 or more lower cannot affect it without a printed weakness or major sacrifice.

Ordinary Hit Point healing and a normal rest do not remove a Hidden Injury.

## Tier III — Rupture or Crippling

Examples:

- a limb remains present but unusable;
- a major organ is ruptured;
- a meridian network is severed;
- a natural weapon root is destroyed;
- one bodily cultivation system is disabled;
- maximum Stamina is reduced by a printed amount;
- a transformation cannot be activated;
- a Path feature is disabled by a named injury.

**Default duration:** Indefinite until specialist reconstruction.

**Default reconstruction:** The injury requires **3 Reconstruction Progress**.

- One eligible reconstruction attempt may be made per Full Cultivation Session.
- The lead treatment source must normally be within 2 Source CL of the injury.
- Each successful check against the injury’s save DC, or `10 + half its Source CL` when no DC exists, grants 1 Reconstruction Progress.
- A result exceeding the DC by 5 or more grants 2 Progress.
- A failed attempt grants no Progress and consumes only the expendable materials declared for that attempt.
- At 3 Progress, the named structure becomes functional and the Tier III injury ends.

A source 3–5 CL lower may stabilize the injury and suppress one printed penalty for 24 hours but cannot gain permanent Progress without a printed weakness, rare component, or major sacrifice. A source 6 or more lower cannot attempt reconstruction.

Ordinary rest does not repair Tier III harm.

## Tier IV — Destruction or Severance

Examples:

- a limb or organ is missing;
- a bodily cultivation system is destroyed;
- a natural weapon is torn out at its cultivated root;
- a transformed organ is removed;
- a Path-resource organ is destroyed;
- an embodied Asset is destroyed as a real structure;
- a Foundation function is physically cut away.

**Default duration:** Permanent until reconstructed.

**Default reconstruction:** The injury requires all of the following:

1. A complete diagnosis.
2. A lead restorative source within 2 Source CL of the injury.
3. One **Major Reconstruction Component** appropriate to the structure.
4. **5 Reconstruction Progress**, gained under the Tier III progress procedure.
5. A legal replacement body plan or restored original structure.

A Major Reconstruction Component can be a preserved original part, compatible cultivated organ, rare pill, treasure, bloodline sample, prepared replacement body part, Foundation repair medium, Formation, artifact service, or another component expressly suitable for the structure.

At 5 Progress, the structure is restored. The procedure does not automatically restore Hit Points, Stamina, Foundation damage, soul damage, lifespan, identity, corruption, or a separate injury.

## Tier V — Erasure or Conceptual Loss

Examples:

- the body’s capacity to possess a limb is erased;
- a bloodline principle is removed from existence;
- the relationship between the body and its Foundation is conceptually severed;
- the cultivator’s name no longer refers to their body;
- a transformation lineage is consumed rather than suppressed;
- the body’s ability to heal a named structure is erased.

Tier V harm has no generic reconstruction procedure.

It requires the printed weakness, equal or higher Secret authority, Samsara, Karma, Void, Name, Fate, conceptual restoration, Immortal intervention, or a campaign-defining procedure established before the attempt.

Generic healing, Medicine, dispelling, ordinary resurrection, and ordinary Body Refining reconstruction cannot reverse Tier V harm.

---

# 7. Injury Records and Publication Requirements

Every Tier II–V injury must have an **Injury Record**.

Required fields:

- Injury name and unique ID.
- Tier.
- Physical, cultivation, Foundation, soul, identity, or mixed tags.
- Source Rule and Source CL.
- Save DC or check DC.
- Affected anatomical structure or cultivation system.
- Immediate result.
- Persistent mechanical effect.
- Detection method.
- Valid treatment sources.
- Materials.
- Recovery or Reconstruction Progress.
- Failed-treatment result.
- Realm Suppression interaction.
- Whether the injury can be transferred, inherited, transformed, or accepted as a price.
- Cosmetic scars.
- Any mechanical scar that remains after repair.

A cosmetic scar has no mechanical effect.

A mechanical scar exists only when the Source Rule or completed reconstruction procedure lists it. A GM or AI may not add a permanent weakness merely because the reconstruction was narratively difficult.

If a draft creates a Hidden Injury, rupture, severance, or destruction but omits the persistent effect or recovery record, that draft is incomplete. During play, the effect produces only its explicitly printed consequences; the GM or AI does not invent additional penalties.

---

# 8. Functional Anatomy

## Anatomy Is Recorded, Not Assumed From Appearance

A creature can look monstrous without gaining claws, wings, extra reach, extra hands, poison, armor, or special senses. Those benefits require a Source Rule.

Likewise, a creature can retain a humanoid silhouette while possessing transformed organs or internal systems that must be recorded.

## Default Structure Categories

Use these categories when a Source Rule affects anatomy:

- **Manipulator:** arm, hand, tentacle, trunk, prehensile tail, or similar structure used to hold or manipulate.
- **Locomotor Structure:** leg, foot, serpentine body section, root cluster, or similar structure required for ground movement.
- **Flight Structure:** wing, levitation organ, air sac, or another structure required by a printed Fly Speed.
- **Sensory Structure:** eye, ear, scent organ, tremor organ, spiritual eye, or another printed sense organ.
- **Breath or Voice Structure:** lungs, gills, throat, tongue, bell organ, or another structure required by a printed breath or Audible technique.
- **Vital Structure:** a structure whose complete destruction normally kills the creature under its Anatomy Record.
- **Cultivation Structure:** meridian, marrow furnace, refined organ, blood circuit, dantian-like body organ, transformed spine, or another named system.
- **Natural Weapon Structure:** claw, horn, fang, tail blade, spine cluster, beak, fist root, or another recorded attack structure.
- **Added Structure:** a limb, organ, eye, hide, plate, blood system, or other structure not present in the base body.

## Default Consequences of Disabled or Missing Structures

Use these consequences only when a Source Rule disables or destroys the structure and does not print a different consequence.

### Manipulator

A disabled manipulator cannot:

- hold or wield an item;
- perform an item interaction;
- satisfy a feature requiring that manipulator;
- provide a hand for a Grapple when the underlying procedure requires one.

Losing one manipulator does not prevent unarmed strikes made with another legal body part.

If every manipulator is disabled, the creature cannot wield held weapons or shields and cannot manipulate objects, though it can still use techniques whose printed origin does not require a manipulator.

### Locomotor Structure

For a creature whose ground movement normally depends on two primary locomotor structures:

- disabling one halves its walking Speed;
- standing from Prone costs all of its movement;
- it has Disadvantage on checks to balance or jump;
- it cannot Dash without a support, prosthesis, mount, or Source Rule allowing it.

If all primary ground locomotor structures are disabled, its walking Speed is 5 feet, it remains Prone unless supported, and it cannot stand unaided.

For a creature with more than two equivalent locomotor structures, losing fewer than half causes no default Speed reduction unless its Anatomy Record says otherwise. Losing at least half uses the one-structure consequence above. Losing all uses the all-structures consequence.

### Flight Structure

If a printed Fly Speed requires a pair or set of physical flight structures, disabling enough of them to break that set removes the Fly Speed. A creature aloft falls under the normal falling rules unless another feature supports it.

A supernatural Hover effect that does not depend on the structure remains unless the injury also suppresses that authority.

### Sensory Structure

- Losing one of two functional eyes gives Disadvantage on visual Wisdom (Perception) checks and on ranged attack rolls against targets more than 30 feet away.
- Losing every functional visual organ causes the Blinded condition unless another sense replaces sight for the relevant task.
- Losing one of two functional hearing organs gives Disadvantage on hearing-based Wisdom (Perception) checks.
- Losing every functional hearing organ causes the Deafened condition.

Additional equivalent sensory organs use the same “fewer than half / at least half / all” structure as locomotor anatomy unless their Source Rule states otherwise.

### Breath or Voice Structure

If every structure required for breathing in the current environment is disabled, the creature begins suffocating under the normal rules.

If every structure required by a printed Audible, breath, roar, chant, or voice technique is disabled, the creature cannot activate that technique. Mental recitation and non-Audible techniques remain available unless their rules require the same structure.

### Vital Structure

Complete destruction of a structure designated **Vital** by the Anatomy Record kills the creature unless a Source Rule provides alternate anatomy, distributed life, a replacement structure, a remain-at-1 feature, immediate reconstruction, or another survival procedure.

A GM or AI does not designate a new Vital Structure after the injury occurs. Vital structures must be recorded before they are targeted.

### Cultivation Structure

Disabling or destroying a Cultivation Structure produces only the effect printed by the injury or Source Rule. It does not automatically remove the entire Path, maximum Stamina, a Foundation, every transformation, or every related Subpath feature.

### Natural Weapon Structure

A disabled Natural Weapon Structure cannot make its associated attack or deliver a technique through that structure. Other unarmed strikes remain available unless the rule states that the whole body’s attack system is disabled.

---

# 9. Bleeding, Fractures, and Bodily States

A named bodily state is not a standard condition unless its rule says so.

## Bleeding

**Bleeding** is a state whose Source Rule must define:

- trigger;
- damage or penalty;
- duration;
- Source CL;
- removal procedure.

If a Subpath defines its own Bleeding state and later features in that same Subpath apply “Bleeding” without redefining it, they use that Subpath’s existing definition.

Different Bleeding states can coexist only when they have different names or Source Rules and each expressly permits coexistence. Reapplying the same Bleeding state refreshes it rather than stacking it.

A feature that ends “one Bleeding state” ends one chosen qualifying state whose Source CL satisfies the feature.

## Fracture, Broken Bone, Crushed Limb, and Deformation

These terms create no automatic penalty beyond the feature that uses them.

- If the rule applies a standard condition, use that condition.
- If it applies a temporary bodily state, use its printed duration and removal.
- If it invokes Tier I–IV harm, create the required Injury Record.

A visual description of a bone breaking does not create permanent damage unless the rule assigns an injury tier or persistent consequence.

## Unique States

Unless a state says otherwise:

- one creature can bear only one instance of that state from the same cultivator;
- reapplication replaces and refreshes it;
- different cultivators track their instances separately;
- it ends when its duration expires or its printed removal succeeds;
- it does not become a standard condition merely because it resembles one.

---

# 10. Diagnosis and Treatment

## Diagnosis Is Information, Not Removal

Diagnosing an injury reveals only the information the procedure authorizes. A successful diagnosis does not remove, suppress, or reconstruct the injury unless the Source Rule says so.

A complete Tier II–IV diagnosis reveals:

- injury name and tier;
- affected structure;
- Source CL and DC;
- printed mechanical effect;
- valid treatment categories;
- required Progress and materials;
- whether immediate stabilization is possible;
- whether the injury threatens escalation.

## Valid Treatment Categories

A Source Rule can authorize one or more of these treatment categories:

- mundane Medicine;
- cultivation Medicine;
- Pressure Points;
- Meridian Physician;
- alchemical pill or elixir;
- compatible bloodline or tissue;
- organ replacement;
- Foundation repair;
- breakthrough repair;
- Method-specific circulation;
- Formation or ritual reconstruction;
- Immortal regeneration;
- artifact or Secret intervention.

Having a high check bonus does not grant a treatment category the character does not possess.

## Assistance

One assistant with a valid treatment category may grant Advantage on the lead check. Additional assistants provide no further numerical benefit unless a Source Rule states otherwise.

An assistant can instead maintain life support, preserve a component, or perform another printed project task.

## Stabilization

A valid specialist can attempt to stabilize a Tier III or IV physical injury during 10 uninterrupted minutes.

Use the injury DC. On a success, one immediate escalation or recurring damage procedure identified by the injury is suspended for 24 hours. Stabilization does not restore function or grant Reconstruction Progress.

If the injury lists no escalation or recurring damage, stabilization has no additional effect.

## Treatment Failure

A failed treatment:

- consumes the declared time;
- consumes only materials identified as expendable before the attempt;
- grants no Progress;
- does not automatically worsen the injury;
- does not create a new injury unless the procedure warned of that exact risk.

A GM or AI may not invent catastrophic failure because the check result was low.

---

# 11. Reconstruction, Reattachment, and Regrowth

## Ordinary Healing

Ordinary Hit Point healing:

- restores Hit Points;
- can end a state only when its Source Rule says healing ends it;
- does not reattach or regrow anatomy;
- does not repair Hidden Injuries, Foundation damage, soul damage, identity damage, or destroyed cultivation systems;
- does not remove a permanent price.

## Reattachment

A severed structure can be reattached only through a Source Rule or a Tier IV reconstruction project.

When a procedure permits reattachment:

- the original structure must be physically present and sufficiently preserved;
- it must be placed against a legal original or replacement location;
- it is unavailable until the procedure completes;
- the procedure states whether Hit Points are restored;
- the reattached structure retains no mechanical weakness unless the procedure creates one.

## Regrowth

Regrowth creates a new legal structure. It does not require the original part unless the Source Rule says so.

A regrown structure:

- matches the creature’s current legal Anatomy Record;
- does not duplicate unique items, implants, Foundations, bloodline treasures, or attached Assets;
- does not create additional limbs or organs beyond the record;
- does not restore separate enchantments or item properties;
- is fully functional when reconstruction completes unless the procedure prints a rehabilitation period.

## Replacement Structures

A replacement can be biological, cultivated, alchemical, constructed, spiritual, or artifact-based when the treatment authorizes it.

A Replacement Structure Record states:

- what original function it restores;
- whether it counts as natural anatomy;
- whether it is a Body Asset, item, Foundation component, or ordinary body part;
- Source CL;
- maintenance and sustenance;
- compatibility with transformations;
- what occurs at 0 Hit Points or upon suppression;
- whether later regrowth replaces it or coexists with it.

## Immortal Body

The Body Refining CL20 **Immortal Reconstruction** feature overrides the generic project length for ordinary missing body parts:

- a severed body part held against its original location reattaches after 1 uninterrupted minute;
- a missing body part regrows during one full 2-hour Cultivation Session;
- the restored part is fully functional at completion;
- no Hit Points are restored unless another rule says so.

It does not repair Foundation damage, soul damage, core destruction, Hidden Injuries, permanent identity alteration, Tier V harm, or a structure whose loss removed the body’s legal ability to possess it.

## Complete Bodily Destruction

A body counts as completely destroyed only when a Source Rule expressly says that:

- no reconstructable body remains;
- the body is disintegrated, consumed, erased, or converted into an unusable state;
- a named life-bearing remnant required by the restoration feature is destroyed.

Do not infer complete destruction merely from overkill damage, a dramatic description, fire, acid, decapitation, or ordinary death.

---

# 12. Transformations and Altered Anatomy

## Transformation Record

Every transformation that changes mechanics must record:

- activation and cost;
- duration and ending conditions;
- whether it is temporary, indefinite, or permanent;
- size and occupied space;
- anatomy added, removed, replaced, or merely altered cosmetically;
- movement modes;
- natural weapons;
- reach;
- equipment interaction;
- speech, breath, manipulation, and senses;
- whether it is a form replacement, aspect, stance, or passive anatomy;
- Source CL;
- suppression behavior;
- injury and reconstruction interaction.

## Form Replacements and Aspects

A **form replacement** substitutes a complete active body form. A creature can use only one form replacement at a time unless a Source Rule says otherwise.

An **aspect** modifies the current form without replacing it. Multiple aspects can coexist when their rules do not conflict.

A **stance** changes behavior, posture, circulation, or combat procedure without changing the Anatomy Record unless it says otherwise.

## Size

When multiple effects set size:

- use the largest size currently authorized unless a rule expressly requires a smaller form;
- size increases do not multiply one another;
- a feature granting “count as one size larger” affects only the listed calculations and does not change occupied space, reach, or actual size;
- actual size changes do not increase weapon dice, reach, carrying capacity, Grapple limits, or damage except through the normal size rules or an explicit feature.

If a transformation would create a body too large for the available space and the Source Rule gives no other procedure, the creature assumes the largest authorized size that fits. It takes no damage solely from the failed size increase.

## Equipment During Temporary Transformation

A temporary transformation that changes only size causes ordinary worn and carried equipment to resize to fit. Item statistics do not change.

A transformation that changes body plan must state how equipment behaves. If it does not:

- worn equipment adjusts where physically compatible;
- an incompatible worn item becomes **suspended** within the transformation, cannot be used, and returns unharmed when compatibility returns;
- a held item remains held only if a legal manipulator remains; otherwise it falls in the nearest legal space;
- an integrated weapon follows its integration rule;
- attunement and ownership do not end.

Suspended equipment grants no benefit and cannot be targeted independently.

## Permanent Alteration

A permanent physical alteration changes the Anatomy Record.

It does not automatically:

- grant attacks;
- grant item interactions;
- grant additional actions or Reactions;
- increase carrying capacity;
- satisfy a Sphere or Subpath prerequisite;
- create a Companion or Asset;
- increase maximum Stamina;
- remove an injury;
- merge with a Foundation.

Each benefit must be printed.

## Additional Limbs and Organs

An additional limb or organ has only the functions printed by its Source Rule.

An extra manipulator does not grant:

- another Action, Bonus Action, Reaction, or object interaction;
- another attack in the Attack action;
- another shield benefit;
- the ability to maintain more Grapples;
- additional Concentration;
- permission to use incompatible equipment.

Those benefits require explicit rules.

## Transformation and Existing Injury

A transformation does not remove an injury unless it says so.

- An injured structure that remains represented in the new form remains injured.
- A temporarily absent structure causes the injury to become dormant rather than repaired; it returns when the structure returns.
- A form with a legal replacement structure may suppress the functional penalty for the form’s duration when the transformation says the replacement functions.
- Ending the transformation restores the prior injury state.

## Unconsciousness

A temporary transformation with a once-per-scene activation ends when the user becomes Unconscious unless the Source Rule says otherwise.

Permanent anatomy, passive transformations, and consequences do not end from Unconsciousness.

---

# 13. Natural Weapons and Integrated Weapons

## Natural Bodily Weapon Procedure

Unless a Source Rule says otherwise, a natural bodily weapon:

- makes an unarmed strike;
- can use Iron Fist when the user has it;
- uses either its printed damage die or the current Iron Fist die, not both;
- uses the ability allowed by its Source Rule or Iron Fist;
- does not count as a held weapon;
- does not carry item properties;
- cannot be disarmed while attached;
- can be disabled by an injury to its recorded structure;
- does not grant an extra attack.

If a natural weapon is expressly treated as a weapon, it uses the printed weapon group and properties for those interactions.

## Integrated Weapon Procedure

A weapon is integrated only through an explicit Source Rule.

An integration record states:

- eligible weapon group;
- whether the weapon attack is a Body Refining attack;
- allowed attack ability;
- whether Iron Fist damage can replace weapon damage;
- whether Body Refining riders can be delivered through it;
- whether the integration survives disarm, transformation, or separation;
- Source CL;
- any repair or re-integration procedure.

A weapon does not gain unrelated Body Refining benefits merely because it is integrated.

## Technique Delivery

When a Body Refining technique is delivered through an authorized natural or integrated weapon:

1. Declare the activation and pay its complete cost.
2. Make the authorized attack.
3. On a miss, the technique is not delivered unless the rule says otherwise; paid costs remain spent.
4. On a hit, resolve ordinary weapon or unarmed damage.
5. Resolve the technique’s additional damage, save, movement, state, or injury.
6. Apply once-per-turn and once-per-activation limits.

An additional attack cannot generate another additional attack unless a Source Rule expressly overrides the Granted Attack Rule.

---

# 14. Bodily Material After Separation

## Real Material

Real detached blood, bone, hair, skin, marrow, organs, scales, spines, teeth, and limbs:

- remain physical objects;
- have no independent action economy;
- are not automatically Assets or Anchors;
- cannot be controlled, recalled, detonated, regrown, or transformed at range without an explicit Source Rule;
- can be preserved, treated, crafted, or used as material only under a legal procedure;
- retain any injury, corruption, bloodline, ownership, or Source CL property that a rule says persists.

## Projected Material

Projected bodily material is a cultivation manifestation rather than a harvested real body part.

Unless a Source Rule says otherwise, it:

- has no market value;
- cannot satisfy a real sacrifice or crafting requirement;
- cannot be stored permanently;
- cannot be consumed to create net resources;
- ends when its feature ends;
- carries only the properties printed by its feature.

## Regeneration and Resource Farming

A creature cannot repeatedly remove and regrow body parts solely to create unlimited wealth, rare materials, pills, food, bloodline samples, Stamina, charges, or crafting components.

A harvested regenerated structure has only ordinary biological value unless a Source Rule expressly creates a persistent cultivated component and defines its production limit.

A projected copy never satisfies a real bodily cost.

---

# 15. Body Assets

## Categories

A Body Asset is one of the following:

1. **Embodied Asset:** attached to and part of the user; normally shares Hit Points and action economy.
2. **Attached Independent Asset:** physically attached but separately targetable through a printed profile.
3. **Detached Real Body Asset:** a real separated structure with its own profile.
4. **Projected Body Asset:** a cultivation manifestation with its own profile.
5. **Replacement Structure:** anatomy, item, or Asset installed to restore function.

## Required Asset Profile

A separately targetable Body Asset must state:

- name and category;
- size and creature or object status;
- AC;
- Hit Points;
- Source CL;
- space and movement;
- Resistances, Immunities, and condition interaction;
- senses and communication;
- action economy;
- attack or save profiles;
- tether or range from the user;
- what occurs at 0 Hit Points;
- repair or recreation;
- Realm Suppression behavior;
- whether it is real, projected, replaceable, or unique.

If a draft calls something an independent creature, construct, manifestation, guard, afterimage, cocoon, swarm, or Asset but omits the information required to use it, the draft is incomplete. A GM or AI does not invent statistics.

## Action Economy

A Body Asset does not gain an independent turn unless the Source Rule grants one.

If commanded through the user's Action, Bonus Action, Reaction, attack replacement, or movement, the Asset uses exactly that command procedure.

An Asset cannot use the same activation to create another Asset, refund more resources than were paid, or generate an extra attack that recursively generates another extra attack.

## Position and Tether

An Asset must occupy a legal space unless it is an abstract effect.

A tethered Asset record states:

- maximum distance;
- whether line of effect is required;
- what occurs when the distance is exceeded;
- whether hostile forced movement can break the tether;
- whether teleportation or phasing is permitted;
- whether the user knows its direction.

## At 0 Hit Points

At 0 Hit Points:

- a projected Asset dissipates or becomes inactive as its rule states;
- an attached real Asset is disabled and can create an injury only when its rule says so;
- a detached real Asset is destroyed as an object or creature under its profile;
- destroying an Asset does not damage the user unless its Source Rule states the link;
- an Asset cannot be destroyed and recreated solely to farm resources.

## Repair

A projected Asset normally returns through its printed recreation procedure.

A real Body Asset requires ordinary item repair, bodily treatment, or reconstruction according to its category. A Full Cultivation Session does not automatically repair a real destroyed Asset unless its Source Rule says so.

---

# 16. External Projection Boundary

Body Refining normally originates from:

- the cultivator’s occupied space;
- a body part that physically touches or strikes;
- a natural bodily weapon;
- an integrated weapon;
- bodily movement through a space;
- a detached or projected medium expressly created by a Source Rule.

Body Refining does not automatically grant:

- remote technique origin;
- independent projected creatures;
- control of detached blood, bone, hair, skin, organs, or limbs;
- free-standing Fields;
- ranged energy projection;
- an afterimage with creature statistics;
- attacks from every occupied or previously occupied space;
- the ability to affect a target merely because the user can sense it.

An external-projection exception must state:

1. Origin.
2. Range and area.
3. Target or legal space.
4. Attack, save, or check.
5. Action and resource cost.
6. Duration.
7. Whether the medium is real, projected, an Asset, an Anchor, or only visual.
8. Whether line of effect, line of sight, or a route is required.
9. What can block, suppress, destroy, or sever it.
10. Whether it persists after leaving the body.
11. Whether it can carry another technique.
12. Source CL.

A printed breath, roar, shockwave, thrown body weapon, blood spray, bone projection, hair technique, afterimage, or similar effect functions exactly as printed. Its imagery grants no additional authority.

---

# 17. Stamina Guard and Damage Ordering

## Trigger Window

Stamina Guard triggers **when damage is first applied** to the Body Refiner:

- after the attack or effect has determined its damage;
- after Immunity, Resistance, Vulnerability, conversion, and multiplicative modifiers that resolve before flat reduction;
- before Hit Points are reduced;
- before a rider that requires the target to take damage resolves.

## Standard Ordering

Resolve a damage packet in this order:

1. Determine every damage component in the packet.
2. Apply damage replacement or redirection that occurs before the target takes damage.
3. Apply Immunity.
4. Apply Resistance and Vulnerability.
5. Apply percentage or multiplicative modifiers.
6. Declare Stamina Guard and pay up to Proficiency Bonus Stamina.
7. Roll and subtract Stamina Guard.
8. Apply other flat reductions in the order chosen by the damaged creature unless a rule requires another order.
9. Reduce Hit Points by remaining damage.
10. Resolve riders that require damage, Hit Point loss, 0 Hit Points, or survival.

A rule expressly resolving before or after Stamina Guard overrides this order.

## Damage Packets

A **damage packet** is one amount of damage applied to one target at one resolution point.

- One attack that deals several damage types normally creates one packet.
- Separate attacks create separate packets.
- A feature that says each projectile or strike deals damage separately creates separate packets.
- One area effect applying one total to a creature creates one packet for that creature.
- Recurring damage on later turns creates a new packet each time it applies.
- A single simultaneous damage roll divided among several targets creates one packet per target.

Stamina Guard protects one triggering packet. Because it uses a Reaction, it normally cannot protect another packet until the user regains a Reaction.

## Multiple Damage Types

After rolling Stamina Guard, subtract the reduction from the packet’s total. The defender chooses which damage types are reduced first when that distinction matters.

## Reduction to 0

If Stamina Guard reduces the packet to 0:

- a rider requiring the target to take damage does not occur;
- a rider requiring only a hit still occurs;
- a condition imposed regardless of damage still occurs;
- the attack does not become a miss;
- damage-triggered resource generation does not occur unless it triggers on preventing damage rather than taking damage.

## Excluded Consequences

Stamina Guard cannot reduce:

- maximum-Hit-Point loss;
- Stamina or other Cultivation Point loss;
- a cost willingly paid;
- an injury not expressed as damage;
- a permanent price;
- damage that expressly cannot be reduced or prevented;
- death or destruction that occurs independently of damage;
- a consequence already converted away from damage.

## Area Effects and Multi-Hit Effects

A Body Refiner in an area uses Stamina Guard only against that creature’s own packet.

For a barrage or multi-hit activation, each independently applied hit is a separate trigger. The feature’s once-per-activation riders remain limited across the whole activation.

---

# 18. Forced Movement, Collisions, and Falling

## Movement Categories

Distinguish:

- **Voluntary movement:** movement spent or chosen by the creature.
- **Granted movement:** movement a rule allows the creature to choose.
- **Forced movement:** push, pull, throw, drag, carry, or reposition imposed without the creature spending movement.
- **Spatial movement:** teleportation, phasing, exchange, gate travel, or another route that does not cross every intervening space normally.

## Forced Movement Defaults

Unless a rule says otherwise:

- forced movement does not provoke Opportunity Attacks;
- it does not spend the target’s movement;
- it cannot move a creature into an illegal space;
- it ends in the nearest legal space before an obstruction;
- preventing some or all forced movement does not create damage by itself;
- it can move a Grappled creature and thereby end the Grapple if separation exceeds the legal hold;
- it does not end Restrained unless the restraining rule says distance or position ends it.

## Multiple Movement Reductions

When several effects reduce forced movement, the moved creature chooses the order unless a Source Rule says otherwise.

No effect can reduce the same feet of movement more than once.

## Collisions

A collision deals damage, knocks Prone, breaks terrain, transfers force, or creates a state only when the Source Rule says so.

If forced movement ends against a wall or creature and the feature prints no collision result, the movement simply ends in the nearest legal space.

Falling caused by being moved off a ledge uses the normal falling rules unless the feature replaces them.

## Moving Through Creatures

A feature that permits movement through another creature’s space must state:

- whether the space is difficult terrain;
- whether the moving creature can end there;
- whether the other creature receives a save or attack;
- what occurs if no legal destination exists.

## Failed Spatial Movement

When teleportation, phasing, or other spatial movement fails because of a Body Refining feature:

- the activating action, Bonus Action, Reaction, or movement is spent;
- every Cultivation Point and limited-use cost is spent;
- the creature remains in the nearest legal space on the original side of the obstruction.

When a contest is required, the moving creature makes `d20 + Proficiency Bonus + Path key ability modifier` against the Body Refiner’s Cultivation Save DC unless another procedure is printed.

---

# 19. Grappling, Shoving, Tethers, and Restraint

## Ordinary Grapple and Shove

Use the current underlying Grapple and Shove rules unless a Tianxia Source Rule replaces them.

A feature that says the Body Refiner counts as one or more sizes larger applies only to the calculations it lists.

## Additional Limbs

Additional limbs do not increase the number of creatures that can be Grappled, grant extra Grapple attempts, or remove the need for a legal manipulator unless their Source Rule says so.

## Forced Separation

A Grapple ends when:

- the Grappler is Incapacitated;
- a printed escape succeeds;
- the Grappled creature and Grappler are moved beyond the legal reach or tether distance;
- the required manipulator or structure is disabled;
- the Source Rule ends it.

If both creatures are moved together and remain within the legal hold, the Grapple continues.

## Moving a Grappled Creature

The Grappler can move a Grappled creature only under the underlying Grapple rule or an explicit feature. A supernatural tether is not automatically a Grapple.

## Restraint

Restrained is stronger than Grappled and requires an explicit Source Rule.

A restraint procedure must state:

- initial attack, save, or check;
- range or reach;
- duration;
- repeat save or escape Action;
- Source CL;
- what movement or distance ends it;
- whether destroying an Asset or Anchor ends it;
- whether teleportation or phasing can escape.

If an ongoing hostile restraint lacks a repeat cadence, use the Source CL band procedure in Section 4.

## Tethers

A **Tether** is a named connection that restricts distance or movement. It is not automatically Grappled or Restrained.

A Tether record states:

- endpoints;
- maximum distance;
- whether it is physical, cultivated, conceptual, or spatial;
- break condition;
- movement interaction;
- teleportation and phasing interaction;
- Source CL;
- whether an endpoint is an Anchor.

## Realm Disparity and Bodily Restraint

Realm disparity does not make ordinary Grapple and Shove rolls automatically succeed or fail unless a rule says so.

Cultivation-powered restraint, bodily suppression, space denial, and anti-teleportation use Source CL in addition to their printed rolls.

---

# 20. Bodily Suppression

Suppression disables access or function. It is not destruction, severance, consumption, or erasure.

## Feature Suppression

A suppressed feature cannot be activated and its active benefits are suspended. The feature returns when suppression ends.

## Anatomical Suppression

A Source Rule can suppress a named limb, organ, sense, natural weapon, transformation, or bodily system.

- The structure remains physically present unless the rule says otherwise.
- Use the default disabled-structure consequence if the rule omits one.
- Ending suppression restores function without requiring reconstruction.
- Suppression does not heal existing injury.

## Transformation Suppression

When a transformation is suppressed:

- its granted benefits and anatomy become inactive;
- a temporary form replacement returns to the nearest legal unsuppressed form when necessary;
- permanent anatomy remains present but its named supernatural benefit is inactive;
- suspended equipment returns only if the current anatomy is compatible;
- injuries do not disappear.

## Bodily Cultivation-System Suppression

Suppressing one cultivation system affects only the features and functions explicitly tied to that system.

It does not automatically:

- reduce maximum Hit Points;
- reduce maximum Stamina;
- remove every Body Refining feature;
- destroy the system;
- damage a Foundation;
- erase a transformation lineage.

## Complete Body Refining Suppression

A Source Rule granting **complete Body Refining suppression** must state its scope. Unless it says otherwise:

- the creature cannot activate Body Refining Path or Subpath features;
- active temporary Path and Subpath states are suspended;
- current and maximum Stamina remain recorded;
- Stamina cannot be spent on suppressed Body Refining features;
- ordinary weapon proficiency and ordinary anatomy remain;
- maximum Hit Points, Hit Dice, permanent anatomy, and passive Foundation embodiment are not recalculated;
- injuries, permanent transformations, and consequences remain;
- the creature can still use non-Body Source Rules not independently suppressed.

## Realm Suppression

Realm Suppression follows the Body core summary:

- use suppressed Proficiency Bonus and effective CL for feature access, scaling, DCs, and Source CL;
- do not recalculate maximum Hit Points, Hit Dice, or maximum Stamina solely because of suppression;
- suppress unavailable temporary transformations or Assets rather than destroying them;
- do not heal severed or destroyed anatomy;
- do not automatically remove passive bodily durability or a Foundation’s embodied quality.

## Suppression Versus Destruction

A feature cannot cause permanent loss merely by saying “suppress.”

Destroyed, severed, consumed, or erased structures require reconstruction or higher authority. Suppressed structures normally return when the suppression ends.

---

# 21. Foundations and Body Refining

A Foundation is an embodied cultivation structure, but it is not merely ordinary anatomy.

## Ordinary Interaction

Unless a Source Rule says otherwise:

- Body Refining healing does not repair Foundation damage;
- ordinary physical damage does not damage a Foundation;
- severing a limb does not remove a Foundation benefit that is not located in that limb;
- a Foundation does not grant extra anatomy beyond its printed benefits;
- a Body transformation does not overwrite a Foundation;
- Realm Suppression does not remove the Foundation’s passive embodied quality.

## Foundation-Linked Anatomy

When a Foundation grants or requires a body structure, the character record must identify:

- whether the structure is ordinary anatomy, permanent transformed anatomy, or a Foundation component;
- whether destroying the structure creates physical injury, Foundation damage, or both;
- which benefit is suppressed if the structure is disabled;
- repair authority and Source CL;
- whether ordinary regrowth can reproduce it.

## Foundation Damage

Foundation damage requires an explicit Source Rule.

A Foundation Injury Record states:

- affected Foundation stage or benefit;
- Source CL;
- physical manifestation;
- mechanical effect;
- valid Foundation repair procedure;
- whether bodily reconstruction is also required.

Completing bodily reconstruction does not automatically repair the Foundation record. Repairing the Foundation does not automatically regrow missing anatomy unless the procedure says so.

## Refinement and Reconstruction

A Foundation refinement can reconstruct or improve anatomy only when its breakthrough or refinement procedure says so.

A successful breakthrough does not automatically erase every Hidden Injury, severance, or Foundation Injury. The breakthrough procedure must identify what it repairs.

---

# 22. Concentration, Duration, and Ending Effects

A Body Refining feature requires Concentration only when its Source Rule says so.

Pain, exertion, transformation, stance, active circulation, maintaining a Grip, spending Stamina, or sustaining a Body Asset does not create Concentration by implication.

An effect ends when:

- its duration expires;
- its user ends it under the printed procedure;
- Concentration ends when required;
- its sole Anchor or required Asset is destroyed;
- its range or tether condition says it ends;
- Realm Suppression makes the feature unavailable and the rule says the state cannot persist;
- a valid counterprocedure succeeds.

Leaving the original range does not end an effect unless the Source Rule says range must be maintained.

---

# 23. Qualifying Hostility and Anti-Recursion

## Qualifying Hostile Creature

A qualifying hostile creature:

- is actively hostile to the cultivator or allies;
- was not created or controlled by the cultivator or a willing ally;
- was not deliberately captured, repeatedly revived, or staged to generate resources;
- has a CL no more than 5 lower than the cultivator, or an equivalent encounter threat.

## Qualifying Hostile Damage

Qualifying hostile damage comes from a hostile creature, active trap, or active environmental hazard.

Self-damage, willing-ally damage, harmless objects, and staged interactions do not qualify.

When a feature requires substantial damage, the damage after all reductions must equal or exceed the cultivator’s Proficiency Bonus.

## No Closed Resource Loops

- Stamina cannot generate itself.
- An extra attack cannot generate another extra attack.
- A Body Asset cannot be destroyed and recreated solely to create net resources.
- A regrown body part cannot be repeatedly harvested for unlimited cultivated material.
- Prevented damage cannot count as damage taken.
- Temporary copies cannot satisfy permanent bodily costs.
- A feature cannot refund more of its own cost than was actually paid.
- A transformation cannot end and restart solely to repeat an entry benefit unless the rule permits it.

## Real Costs

Accepted Hidden Injuries, severed parts, permanent maximum-resource loss, lifespan, destroyed Foundations, rare organs, consumed Assets, and sacrificed items must actually be paid. A projected or temporary copy does not satisfy a real cost.

---

# 24. Player, GM, and AI Data Contract

A Body Refining character record must identify:

- Body Refining CL, effective CL, and Source CL;
- Constitution modifier, maximum Stamina, and current Stamina;
- Defensive Disciplines;
- Core Tempering Expressions;
- chosen Subpath;
- every Subpath state and resource;
- integrated weapons and authorizing Source Rules;
- Anatomy Record when nonstandard;
- transformations and equipment interaction;
- natural weapons;
- Body Assets and Anchors;
- injuries and Reconstruction Progress;
- Foundations and Foundation Injuries;
- Methods, Spheres, Insights, Recorded Arts, Forged Techniques, items, and other body-modifying rules;
- active feature, anatomical, system, Foundation, or Realm Suppression.

A player, GM, or AI may not infer:

- an unprinted injury;
- an unprinted organ or natural weapon;
- extra attacks from extra limbs;
- remote control of detached body material;
- extra action economy for an Asset;
- an immunity from visual description;
- regeneration from general Body Refining identity;
- Foundation damage from ordinary physical damage;
- reconstruction from ordinary Hit Point healing;
- a harsher failure consequence than the printed ceiling;
- a weaker result merely because the printed effect is inconvenient.

When a required record is missing, apply only the explicitly printed mechanics and flag the content for repair. Do not fill the gap with invented authority.

---

# 25. Publication Requirements for Body Refining Subpaths

A Body Refining Subpath is publication-ready only when every relevant feature states:

- action type and trigger;
- cost and cost timing;
- range, origin, and target;
- attack, save, or check;
- damage and state timing;
- duration and Concentration;
- repeat save or removal;
- Source CL interaction;
- Realm Suppression behavior;
- transformation and equipment interaction;
- natural or integrated weapon interface;
- Body Asset profile;
- injury tier and recovery;
- forced movement, collision, Grapple, restraint, or spatial procedure;
- once-per-turn, once-per-round, once-per-scene, or buildup limits;
- anti-recursion and anti-farming boundaries;
- every consequence ceiling.

A Subpath can reference this document instead of repeating the complete default. It must print every exception.

---

# 26. Deferred GM Authority

This player-executable shared procedure layer does not replace the later Body Refining GM Authority module.

The GM module will organize campaign-level authority for:

- creating optional injury procedures;
- assigning Source CL to hazards, rare materials, and independent reconstructive services;
- designing Major Reconstruction Components;
- adjudicating artifact, Secret, Tribulation, and Immortal reconstruction;
- determining legal Foundation repair sources;
- campaign access to replacement organs and transformed anatomy;
- resolving world-scale bodily destruction and conceptual loss;
- integrating Body authority into the Universal Cultivation Authority Appendix.

The GM module cannot reduce or expand a player feature after activation. It supplies world procedures only where a player-facing Source Rule expressly invokes them.

---

# 27. Candidate Status and Harmonization Deferrals

This document does not change:

- maximum Stamina;
- current Body recovery cadence;
- Stamina Guard dice or cost;
- any core feature;
- any Subpath feature;
- any Insight;
- any damage, healing, range, duration, target count, Asset statistic, or transformation value.

The following remain deferred to the three-Path harmonization audit:

- whether Body’s two Short-Rest Stamina recoveries are intentional Path identity;
- whether maximum Stamina gains the `2 × CL` minimum used by Qi and Spirit;
- final universal wording for Source CL bands and reconstruction project length;
- final placement between PHB, compendium, and Universal Cultivation Authority Appendix.


# Part III — Body Refining Campaign Authority Procedures

## 1. Default Injury Policy

The default Tianxia campaign uses **Explicit Injury Only**:

- ordinary damage reduces Hit Points;
- critical hits, falling to 0 Hit Points, massive damage, overkill, and dramatic narration do not automatically create bodily Injuries;
- an Injury occurs only when a Source Rule expressly creates one or when the campaign has adopted a written optional injury procedure before the relevant event.

The GM cannot decide after an attack resolves that it also severed a limb, destroyed an organ, damaged a Foundation, or created a Hidden Injury.

## 2. Optional Injury Procedure Record

An optional campaign injury procedure is valid only when its record states all of the following before play:

- eligible event or contest;
- maximum injury tier;
- legal anatomical targets;
- attack, save, check, or stake-resolution procedure;
- whether ordinary Hit Point damage is also dealt;
- Source CL and DC;
- immediate effect;
- escalation, if any;
- diagnosis methods;
- stabilization methods;
- treatment categories;
- Reconstruction Progress and component requirements;
- maximum duration or permanence;
- whether player consent or predeclared duel, Tribulation, breakthrough, or ritual stakes are required.

An optional procedure cannot exceed its recorded tier ceiling. One activation creates at most one Injury unless it explicitly says otherwise.

## 3. Injury Authority Ceiling

When a custom hazard, duel stake, Tribulation, artifact, or monster feature creates bodily harm, use this ceiling:

| Authority written into the Source Rule | Maximum default result |
|---|---|
| Disruption, strain, bruise, temporary impairment | Tier I |
| Hidden damage, meridian blockage, internal instability | Tier II |
| Rupture, crippling, organ failure, destroyed ordinary function | Tier III |
| Severance, destroyed anatomy, destroyed bodily cultivation structure | Tier IV |
| Erasure of the body's legal capacity to possess or reconstruct the structure | Tier V, explicit higher authority only |

A description does not raise the tier. If the Source Rule does not identify a tier or an equivalent result, use the lowest tier that fully expresses its printed mechanics.

## 4. Assigning Source CL to Independent Bodily Hazards and Services

Use the printed creator, creature, item, Formation, Tribulation, or service Source CL when one exists.

When none exists:

1. Identify the strongest bodily authority the effect can produce.
2. Find the lowest printed character or item CL that grants equivalent authority.
3. Use that CL as the Source CL.
4. If no equivalent printed authority exists, the effect cannot exceed Tier II or temporary suppression until a custom Source Rule is completed and audited.

Price, rarity, reputation, or narrative importance does not independently increase Source CL.

## 5. Major Reconstruction Project

A Tier IV reconstruction project must record:

- target Injury and affected structure;
- project Source CL;
- lead treatment category;
- project DC;
- required Reconstruction Progress;
- work interval and check cadence;
- required Major Reconstruction Components;
- expendable and nonexpendable components;
- stabilization requirement;
- valid assistants;
- failure ceiling;
- completed anatomy or Replacement Structure Record.

A project does not begin until these fields are recorded.

### Standard Major Reconstruction Components

Use only the component roles required by the target:

| Component role | Required when |
|---|---|
| **Anatomical Pattern** | Rebuilding a missing or destroyed structure whose shape or function is not preserved elsewhere |
| **Life-Bearing Medium** | Growing living tissue, blood, marrow, organs, skin, or a biological replacement |
| **Meridian Scaffold** | Restoring meridians, acupoints, dantian interfaces, tendon channels, or another bodily cultivation system |
| **Bloodline Key** | Restoring an inherited, species-specific, demonic, draconic, beast, celestial, or otherwise lineage-locked structure |
| **Foundation Interface** | Restoring anatomy that is also an explicit component or Anchor of a Foundation |
| **Authority Key** | Overcoming an explicit seal, curse, conceptual prohibition, artifact effect, Secret authority, or higher-Source-CL destruction |
| **Replacement Vessel** | Installing a constructed, alchemical, spiritual, artifact, or cultivated replacement instead of regrowing natural anatomy |

Ordinary Tier IV anatomy normally requires an Anatomical Pattern, Life-Bearing Medium, and Meridian Scaffold when the structure carries cultivation channels. Add only the roles actually required by the Injury and intended result.

Each component must have a recorded Source CL and compatibility. A component below the Injury's Source CL can contribute material but cannot satisfy the project's controlling authority requirement unless a printed rule says otherwise.

## 6. Reconstruction Results

On completion, choose exactly one result authorized by the project record:

- **Reattachment:** restore the preserved original structure.
- **Regrowth:** create a new natural structure matching the legal Anatomy Record.
- **Replacement:** install a recorded Replacement Structure.
- **Cultivation-system restoration:** restore the printed bodily cultivation function without creating new anatomy.
- **Foundation-interface restoration:** restore the bodily interface only; the Foundation itself still requires Foundation repair.

A completed reconstruction has no scar, weakness, reduced maximum, maintenance burden, or altered quality unless the project record printed it before work began. The GM cannot add a permanent drawback after completion because the reconstruction was difficult or unusual.

## 7. Rehabilitation and Scars

Rehabilitation exists only when the Injury or project record states:

- its duration;
- exact functional restriction;
- valid activities;
- check cadence, if any;
- completion condition.

Cosmetic scars may remain without mechanical effect. A mechanical scar, weakness, altered quality, or new appetite is a separate recorded consequence and requires explicit authority.

## 8. Replacement Anatomy and Altered Bodies

A replacement, additional organ, extra limb, hide, blood system, bone structure, or transformed anatomy must use an Anatomy or Replacement Structure Record.

The record must state:

- whether the structure is natural anatomy, a Body Asset, an item, a Foundation component, or another category;
- functions restored or added;
- action economy;
- natural-weapon profile, if any;
- equipment compatibility;
- sustenance and maintenance;
- Source CL;
- suppression and 0-Hit-Point behavior;
- interaction with transformation and regrowth;
- whether the structure is inherited, removable, replaceable, or unique.

Extra anatomy grants no extra attacks, actions, Reactions, object interactions, Grapples, shields, or item slots unless the Source Rule prints them.

## 9. External Projection Authority

Body Refining normally operates through the cultivator's body. A custom external-projection feature must record the complete projection profile required by Shared Procedures R1.

The GM cannot infer a projectile, aura, remote origin, detached acting limb, free-standing Field, blood control, bone control, hair control, or organ control from visual description. A projected or detached bodily medium gains no independent turn unless explicitly granted one.

## 10. Bodily Suppression and Destruction

Suppression removes access or function for a stated duration; it does not destroy anatomy.

Use the least invasive applicable category:

1. feature suppression;
2. anatomical suppression;
3. transformation suppression;
4. bodily cultivation-system suppression;
5. complete Body Refining suppression;
6. Realm Suppression.

Destruction, severance, and Foundation Injury use separate rules and cannot be inferred from suppression.

When Realm Suppression applies, passive bodily durability, Hit Points, Hit Dice, legal anatomy, and the existence of a Foundation remain unless the universal Realm Suppression rule expressly removes them. Higher-CL activations and scaling use the suppressed effective CL.

## 11. Foundation-Linked Anatomy

A bodily structure is Foundation-linked only when the Foundation record says so.

- Physical damage to the structure does not automatically damage the Foundation.
- Foundation Injury does not automatically sever or destroy the anatomy.
- Bodily reconstruction repairs anatomy, not the Foundation.
- Foundation repair restores the Foundation, not missing anatomy.

A legal Foundation repair source must explicitly state that it repairs, reconstructs, refines, or restores a Foundation or named Foundation component. General Medicine, ordinary Hit Point healing, regeneration, and generic Body Refining do not qualify.

## 12. Living Weapons and Embodied Assets

Natural weapons, integrated weapons, attached bodily Assets, detached real Body Assets, and projected Body Assets remain separate categories.

For each Asset or living weapon, record:

- real or projected status;
- creature, object, item, anatomy, or Asset category;
- AC, Hit Points, size, movement, and position;
- action and command economy;
- attack or technique profile;
- tether and range;
- valid healing or repair;
- result at 0 Hit Points;
- replacement and anti-farming rules;
- Source CL and Realm Suppression.

Destruction of an Asset does not automatically injure the cultivator unless its Source Rule prints the transfer.

## 13. Complete Bodily Destruction

Complete bodily destruction occurs only when a Source Rule expressly says no reconstructable body or required life-bearing remnant remains.

Decapitation, cremation, acid, dismemberment, overkill, falling to 0 Hit Points, or ordinary death does not automatically establish complete destruction.

A restoration feature that requires a corpse, remnant, heart, core, drop of blood, ember, marrow seed, soul, or other Anchor fails only when that exact required remnant is absent, destroyed, suppressed, or inaccessible under its printed rule.

## 14. Tier V Erasure and Conceptual Loss

Tier V harm can remove the body's legal capacity to possess, regrow, reconstruct, or express a structure or cultivation function. It requires an explicit artifact, Secret, divine, Imperial, Immortal, Tribulation, conceptual, or equivalent higher-authority Source Rule.

A Tier V Source Rule must identify:

- the capacity erased;
- Source CL;
- whether suppression can temporarily restore access;
- whether an Authority Key exists;
- valid restoration authorities;
- whether breakthrough-scale or Immortal reconstruction is possible;
- the strongest result on a lower, equal, or higher Source CL target.

When these fields are absent, resolve the effect as Tier IV destruction or the strongest lower printed result. Do not improvise permanent conceptual loss.

## 15. Artifact, Secret, Tribulation, and Immortal Reconstruction

These sources may override ordinary project length, components, or recovery only to the extent printed.

They do not automatically:

- repair a Foundation;
- restore a soul or identity;
- reverse Tier V erasure;
- reproduce unique bloodline treasures;
- duplicate attached items or Assets;
- remove a permanent price;
- create additional legal anatomy.

Every override must identify the exact category it restores.

## 16. GM and AI Adjudication Boundary

The GM or AI may:

- select fiction and sensory presentation;
- choose among outcomes explicitly listed by a Source Rule;
- determine world availability using recorded campaign procedures;
- assign honest NPC knowledge;
- create custom content before play using the publication templates.

The GM or AI may not during resolution:

- invent an Injury;
- raise an Injury tier;
- add a permanent scar or weakness;
- destroy a Foundation through ordinary damage;
- deny printed reconstruction because it seems too powerful;
- reduce a feature because it is inconvenient;
- grant external projection or extra anatomy benefits from imagery;
- invent a catastrophic treatment failure;
- require an unrecorded component, quest, price, or sacrifice;
- decide after the roll that the effect carried a stronger authority.


# Part IV — Subpath and Insight Authority Interface

The complete shared execution rules for all 42 Subpaths are in **Body Refining Subpath Procedure Addendum R8**. The central Insight catalogue is the authority for Insight text and prerequisites. This appendix governs campaign-level availability, exceptional authority, permanent harm, and reconstruction; it does not replace a Subpath or Insight's explicit feature text.

# Part V — Future Universal Cultivation Authority Integration

During three-Path harmonization, move the following shared material into the Universal Cultivation Authority Appendix:

- Source CL and Realm disparity;
- Realm Suppression;
- the five-tier cultivation-harm hierarchy;
- Assets and Anchors;
- suppression versus destruction;
- reconstruction authority and project records;
- permanent prices;
- artifact, Secret, Tribulation, breakthrough-scale, and Immortal restoration.

Retain Body-specific sections for anatomy, Stamina Guard, transformations, natural weapons, bodily materials, Body Assets, living weapons, bodily suppression, and Foundation-linked anatomy.

# Adjudication Boundary

When no printed procedure authorizes a permanent or higher-authority result, the effect stops at the strongest printed temporary or lower-tier result. Narrative intensity never supplies missing mechanical authority.
