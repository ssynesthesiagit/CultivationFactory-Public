# Tianxia Body Refining — Subpath Compendium R8

**Publication state:** Player-facing organization of all 42 normalized Body Refining Subpaths.  
**Integration state:** Consolidated after six controlled non-nerfing normalization batches.  
**Mechanical state:** No intentional changes to inherited feature levels, Stamina costs, dice, ranges, durations, targets, size ceilings, Asset profiles, state ceilings, or cultivation authority.  
**Required rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8; universal cultivation procedures when expressly invoked.

## Using This Compendium

Each Subpath retains complete CL3, CL6, CL10, CL14, and CL18 progression. A Subpath grants only its printed permissions. It does not silently grant a Sphere, Sphere talent, companion, independent Asset turn, additional limb attacks, external projection, permanent injury authority, or Foundation modification.

## Canonical Rule Order

1. Explicit Subpath feature text.
2. Body Refining Core R2.
3. Body Refining Shared Procedures R1.
4. Body Refining Subpath Procedure Addendum R8.
5. Universal cultivation procedures and general Tianxia rules.

## Catalog Summary

| Access category | Count |
|---|---:|
| Open School | 14 |
| Restricted Scripture | 17 |
| Rare Inheritance | 6 |
| Forbidden Method | 5 |
| **Total** | **42** |

## Contents

| # | Subpath | Access | Primary identity | Progression |
|---:|---|---|---|---|
| 1 | Flesh Crucible | Open School | Growth, size, grappling, physical dominance | CL3 Titan's Frame; CL6 Crushing Grip; CL10 Mountain-Demon Might; CL14 Titanic Frame; CL18 World-Shaking Stomp |
| 2 | Iron Shirt | Open School | Damage reduction, defensive efficiency, counterattacks, survival | CL3 Iron Shirt; CL6 Tempered Flesh; CL10 Bell Strike; CL14 Iron Wall; CL18 Invincible Iron |
| 3 | Stone Fist | Open School | Breaking armor, barriers, Constructs, and structures | CL3 Breaking Fist; CL6 Overwhelming Blow; CL10 Shattering Palm; CL14 Earth-Shattering Fist; CL18 Heaven-Cracking Blow |
| 4 | Sumo | Open School | Rooting, collisions, pushing, battlefield control | CL3 Rooted Stance; CL6 Sumo Strike; CL10 Ring Breaker; CL14 Yokozuna Presence; CL18 Immovable God |
| 5 | Drunken Fist | Open School | Evasive instinct, stumbling counters, unpredictable movement | CL3 Swaying Step; CL6 Falling Fist; CL10 Staggering Blow; CL14 Empty Cup; CL18 Heavenly Drunk |
| 6 | Mantis Style | Open School | Joint locks, precision Grappling, disabling strikes | CL3 Mantis Hooks; CL6 Joint Lock; CL10 Rapid Pincer; CL14 Eye of the Mantis; CL18 Death of a Thousand Cuts |
| 7 | Jujutsu | Open School | Redirection, throws, yielding defense | CL3 Redirect Force; CL6 Gentle Fist; CL10 Throw; CL14 Harmonious Body; CL18 Empty Body |
| 8 | Bojutsu | Open School | Staff integration, reach, circular defense | CL3 Staff Form; CL6 Flowing Spin; CL10 Sweeping Strike; CL14 Staff of One; CL18 Heavenly Staff Barrier |
| 9 | Karate | Open School | Efficient unarmed striking, timing, perfected attacks | CL3 Focused Strike; CL6 Perfect Breath; CL10 Precision Strike; CL14 Mushin; CL18 Isshun Sengeki |
| 10 | Yamabushi | Open School | Ascetic endurance, environmental mastery, mountain-body refinement | CL3 Stone Skin; CL6 Waterfall Stance; CL10 Mountain's Wrath; CL14 Ascetic Body; CL18 Avatar of the Mountain |
| 11 | Bone Monarch | Restricted Scripture | Bone armor, marrow regeneration, reconstruction, bone manifestations | CL3 Bone Armor; CL6 Marrow Regeneration; CL10 Bone Guard Manifestation; CL14 Unbroken Bones; CL18 Sovereign Reconstruction |
| 12 | Kensei | Restricted Scripture | Sword intent engraved into flesh and bone | CL3 Blade Fist; CL6 Sword Draws Before Thought; CL10 Flowing Blade Stance; CL14 Severing Palm; CL18 Sword Saint Incarnation |
| 13 | Shinobi | Restricted Scripture | Shadow-flesh conditioning, infiltration, pressure points, afterimages | CL3 Silent Step; CL6 Pressure-Point Strike; CL10 Shadow Afterimage; CL14 Assassination; CL18 Vanishing Flesh |
| 14 | Gōruden | Restricted Scripture | Golden-body refinement, radiant durability, divine-statue transformation | CL3 Golden Sheen; CL6 Gilded Bones; CL10 Radiant Fist; CL14 Golden Aura; CL18 Immortal Gold |
| 15 | Ryūjin | Rare Inheritance | Dragon scales, lightning breath, storm movement, draconic transformation | CL3 Dragon Scales; CL6 Dragon's Breath; CL10 Storm Step; CL14 Dragon's Roar; CL18 Ryūjin Ascendant Form |
| 16 | Kūkishin | Rare Inheritance | Hollow body, phasing, incorporeality, spirit-striking attacks | CL3 Phase Flesh; CL6 Empty Strike; CL10 Hollow Step; CL14 Soul Severance; CL18 Hollow Immortal |
| 17 | Oni Blood | Forbidden Method | Demonic mask, blood hunger, predatory vitality, monstrous transformation | CL3 Oni Mask; CL6 Blood Drinker; CL10 Demon Roar; CL14 Oni Form; CL18 Crimson Oni |
| 18 | Jigoku | Forbidden Method | Hell-tempered body, pain cultivation, fire consumption, infernal endurance | CL3 Hell-Tempered; CL6 Pain Eater; CL10 Flame Fist; CL14 Hellwalker; CL18 Asura's Rage |
| 19 | Sky-Treading Tendon School | Open School | Extreme mobility, aerial pursuit, kicking force, rapid repositioning | CL3 Thousand-Mile Legs; CL6 Heaven-Kicking Leg; CL10 Tread the Empty Sky; CL14 Pursuit Without Horizon; CL18 Body Crosses Heaven |
| 20 | Returning-Heaven Momentum Body | Open School | Stored momentum, charges, rebounds, collision attacks, movement conversion | CL3 Gather and Return; CL6 Store the Collision; CL10 Rebounding Assault; CL14 Avalanche Meridian Circuit; CL18 Heaven-Returning Impact |
| 21 | Vermilion Gate Guardian Body | Open School | Threshold control, protection, anti-teleportation, interception | CL3 Guardian at the Gate; CL6 Shelter Behind the Gate; CL10 Twin Guardian Posts; CL14 Threshold Between Worlds; CL18 Heaven's Closed Gate |
| 22 | White-Heron Crescent Body | Open School | Polearm mastery, sweeping attacks, reach control, graceful movement | CL3 Crescent-Body Integration; CL6 One-Legged Guard; CL10 Crescent Reaping Circle; CL14 White Wing Crosses the Reed Field; CL18 Moon over the Reed Sea |
| 23 | Sun-Piercing Bow Body | Restricted Scripture | Ranged martial cultivation, immense draw strength, piercing shots, battlefield lines | CL3 Bow Body; CL6 Meridian Overdraw; CL10 Sky-Pinning Arrow; CL14 Sun-Chasing Line; CL18 Star-Piercing Shot |
| 24 | Hundred-Venom Body | Restricted Scripture | Poison resistance, venomous strikes, toxin adaptation, bodily contamination | CL3 Venom Furnace; CL6 Swallow the Poison; CL10 Three Sovereign Venoms; CL14 Poisoned Body, Poisoned World; CL18 Myriad-Venom Immortal |
| 25 | Eight Gates of the Heaven-Defying Body | Restricted Scripture | Escalating bodily overclock, extreme speed, additional attacks, dangerous self-damage | CL3 First and Second Gates; CL6 Third and Fourth Gates; CL10 Fifth Gate: Gate of Thunder; CL14 Sixth and Seventh Gates; CL18 Eighth Gate: Heaven-Defying Gate |
| 26 | Hundred-Beast Scripture | Restricted Scripture | Modular beast aspects, adaptive physical abilities, shifting combat roles | CL3 Beast-Scripture Initiate; CL6 Paired Beast Body; CL10 Beast King's Technique; CL14 Chimera Meridian Network; CL18 Sovereign of Ten Thousand Beasts |
| 27 | Nine-Star Meridian Body | Restricted Scripture | Celestial buildup, force projection through the body, orbital movement, falling-star impacts | CL3 Star-Lit Acupoints; CL6 Orbital Body; CL10 Falling-Star Descent; CL14 Constellation Circuit; CL18 Nine-Star Incarnation |
| 28 | Heaven-Thunder Drum Body | Restricted Scripture | Vibration, internal shock, disruption, anti-barrier force | CL3 Bone-Drum Strike; CL6 Internal Echo; CL10 Counter-Resonance; CL14 Heaven-Drum Circulation; CL18 World-Shaking Cadence |
| 29 | Heaven-Binding Chain Body | Restricted Scripture | Reach, tethers, restraint, interception, battlefield imprisonment | CL3 Chain-Body Integration; CL6 Drag the Heavens; CL10 Guardian Chain; CL14 Thousand-Link Meridian Network; CL18 Heaven-Binding Prison |
| 30 | Five-Viscera Immortal Furnace | Restricted Scripture | Organ refinement, internal alchemy, circulating bodily modes, medicine and toxin control | CL3 Five-Viscera Circuit; CL6 Refine the Impure; CL10 Twin Furnace Circulation; CL14 Fivefold Organ Harmony; CL18 Inner Cosmos Furnace |
| 31 | Still-Water Draw Body | Restricted Scripture | Opening strikes, explosive draw-cuts, counters, straight-line execution | CL3 Drawn from Stillness; CL6 Empty-Scabbard Step; CL10 One Breath, Three Horizons; CL14 Moon Reflected Before Motion; CL18 Heaven Divided Before Sound |
| 32 | Thousand-Fold Steel Body | Restricted Scripture | Shifting bodily temper, offense-defense adaptation, armor cutting, disciplined resilience | CL3 Body Forged in Three Forms; CL6 Quench the Impact; CL10 Folded Edge, Hidden Spine; CL14 Ten Thousand Reforgings; CL18 Body Beyond the Hammer |
| 33 | Adamant Thunderbolt Body | Restricted Scripture | Adamant durability, explosive impact, lightning conduction, anti-defense strikes | CL3 Adamant Frame; CL6 Thunder Runs Through Bone; CL10 Heaven-Breaking Knuckle; CL14 Body of the Unbroken Bolt; CL18 Adamantine Descent |
| 34 | Seven-Coiled Serpent Spine | Restricted Scripture | Progressive bodily awakening, flexibility, explosive release, constriction | CL3 First and Second Coils; CL6 Third and Fourth Coils; CL10 Fifth Coil: Ascending Serpent; CL14 Sixth Coil: Crowned Serpent; CL18 Seventh Coil: Heaven-Swallowing Serpent |
| 35 | Hundred-Hand Battle Mandala | Restricted Scripture | Multiweapon combat, attack sequencing, simultaneous defense, many-handed battle patterns | CL3 Four-Hand Sequence; CL6 Weapon-Wheel Body; CL10 Eight-Limb Battle Pattern; CL14 Circle of Uncounted Arms; CL18 Thousand-Hand Incarnation |
| 36 | Phoenix Rebirth Body | Rare Inheritance | Regeneration, condition shedding, fire adaptation, combat rebirth | CL3 Cinder Blood; CL6 Ash-Shedding Reversal; CL10 Flame-Wing Rush; CL14 Furnace Without Fuel; CL18 Rebirth from Cinders |
| 37 | Heaven-Answering Adaptive Body | Rare Inheritance | In-combat adaptation, repeated-effect resistance, counterattacks, evolving defenses | CL3 Flesh Remembers Pain; CL6 Meridians Remember Affliction; CL10 Return the Lesson; CL14 Ten Thousand Answers; CL18 Perfect Counter-Evolution |
| 38 | White Elephant Sovereign Body | Rare Inheritance | Immense mass, charging force, ally protection, remembered enemies | CL3 Sovereign Frame; CL6 Shelter Beneath the Tusks; CL10 The Body Remembers; CL14 Mountain-Walking Sovereign; CL18 World-Bearing Elephant King |
| 39 | Thousand-Eyed Calamity Body | Rare Inheritance | Supernatural perception, weak-point analysis, attack prediction, anti-concealment | CL3 Calamity Appraisal; CL6 Eye beneath the Skin; CL10 Read the Killing Line; CL14 Hundred Eyes Open; CL18 Thousand-Eyed Revelation |
| 40 | Heaven-Devouring Maw Body | Forbidden Method | Consuming hostile power, storing damage types, breaking defenses, returning stolen energy | CL3 Swallow Hostile Power; CL6 Regurgitate Calamity; CL10 Swallow the Technique; CL14 Feast upon Protection; CL18 Devour Heaven and Earth |
| 41 | Black-Thorn Demon Body | Forbidden Method | Reactive spines, bleeding wounds, impalement, close-range battlefield control | CL3 Thorn-Flesh Armory; CL6 Spines Answer Violence; CL10 Impaling Garden; CL14 Crown of Black Thorns; CL18 Calamity Briar Incarnation |
| 42 | Ten-Thousand Parasite Vessel | Forbidden Method | Internal brood, regeneration, infestation, qi punishment, swarm-body transformation | CL3 Internal Brood; CL6 Gnawing Infestation; CL10 Brood Substitution; CL14 Parasite Sovereignty; CL18 Ten-Thousand Worm Demon Body |

---

## 01. Flesh Crucible

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The mountain does not ask permission to grow.*

Flesh Crucible refiners make size, mass, and raw physical dominance into a doctrine. They grapple like collapsing cliffs and treat the battlefield as something to be pushed out of their way.

**Access Category:** Open School  
**Primary Identity:** Growth, size, grappling, physical dominance  
**Common Sphere Synergies:** Brute, Earth, Flesh, Gravity, Transformation, Wrestling

#### CL3 - Titan's Frame

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 2 Stamina

Increase your size by one category, to a maximum of Large.

For the duration:

- Gain Advantage on Strength checks and Strength saving throws.
- Count as one size larger for Grappling, Shoving, carrying, dragging, lifting, and pushing.
- Double your carrying, dragging, lifting, and pushing capacity.
- Your Iron Fist damage die becomes `1d10`.
- Your reach does not increase unless another feature states otherwise.

Once during each of your turns after you hit with a Body Refining melee attack, choose one:

- Push the target 5 feet.
- Move 5 feet toward the target without provoking Opportunity Attacks from it.
- Gain Advantage on your next attempt to Grapple or Shove that target before the end of the turn.

Activating Titan's Frame again refreshes its duration but does not increase your size further.

##### Normalized Procedure — Titan's Frame

- **Transformation record.** Titan's Frame is a temporary size transformation. It changes occupied space, size-dependent reach only where printed, carrying capacity, and equipment fit under Body Refining Shared Procedures. It does not create extra limbs, attacks, Hit Dice, or inherent weapon reach.
- **Legal space.** You can activate the feature only if the new size can occupy your current space. If the available space permits Large but not a later Huge increase, you grow only to the largest legal printed size. A space that becomes too small after you enter it does not crush you; you are Squeezing under the normal rules until you leave or the transformation ends.
- **Existing size effects.** Determine your actual size after all replacement effects, then apply each distinct “count as larger” permission only to the listed operations. Titan's Frame does not stack with itself. A later activation refreshes the duration and may select a different legal size at CL14.
- **Once-turn rider.** The rider triggers after the hit resolves. The movement toward the target must end closer to it and in a legal space. The Advantage option expires at the end of the same turn and applies to only the next Grapple or Shove attempt against that target.
- **Ending the form.** When the form ends, return to your normal recorded size in your current space. If that space is illegal for the returning size, use Failed Spatial Movement to place you in the nearest legal space; no damage occurs unless another rule prints it.

#### CL6 - Crushing Grip

While Grappling a creature:

- You have Advantage on checks or rolls made to prevent its escape.
- You move at full Speed while dragging a creature no more than one size larger than you.
- The creature cannot benefit from movement granted by a willing ally unless that movement first ends your Grapple.

At the start of your turn, you may spend 1 Stamina to crush one creature you are Grappling. It takes damage equal to one Iron Fist damage roll. This requires no attack roll, occurs once per turn, cannot trigger an attack-hit rider, and does not end the Grapple.

##### Normalized Procedure — Crushing Grip

- Choose the Grappled creature when the start of your turn is reached, before taking an action or moving. You must still be Grappling it when the damage resolves.
- “Prevent its escape” includes checks, saves, and opposed Cultivation Checks made specifically to end or break your Grapple. It does not grant Advantage against teleportation, phasing, bodily transformation, or severance unless that procedure directly calls for a Grapple escape roll.
- A willing ally can still target the Grappled creature with granted movement. That movement resolves only if it first ends, transfers, or legally carries the Grapple under its own rule. The clause does not prohibit forced movement, unwilling teleportation, or movement that carries both you and the target together.
- The crush is one damage packet equal to one current Iron Fist damage roll, including the die but not an attack's ability modifier or hit-only riders unless a rule expressly adds them. It is not an attack, cannot critically hit, and cannot trigger “when you hit” or “when an attack deals damage” features.

#### CL10 - Mountain-Demon Might

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 5 Stamina  
**Limit:** Once per scene

Activate Titan's Frame without paying its normal cost. If Titan's Frame is already active, increase your size by one additional category, to a maximum of Huge.

For the duration:

- Gain Temporary Hit Points equal to twice your CL.
- Your reach increases by 5 feet.
- Once per turn when you deal damage with a Body Refining melee attack, add your Constitution modifier to one damage roll.
- Increase every push caused by one of your Body Refining features by 5 feet.
- You count as one additional size larger for Grappling and Shoving.

When Mountain-Demon Might ends, Titan's Frame also ends.

##### Normalized Procedure — Mountain-Demon Might

- Activating this feature activates or refreshes Titan's Frame as part of the same Bonus Action. It ignores Titan's Frame's 2-Stamina cost but not legal-space requirements.
- Temporary Hit Points from this feature follow the normal nonstacking rule. Reapplication replaces them only if the new amount is higher.
- The once-per-turn Constitution damage applies to one damage roll from one Body Refining melee attack after that attack hits. It is not added to Grapple damage, Crushing Grip, a collision, or an area effect unless that effect is itself a Body Refining melee attack.
- “Every push caused by one of your Body Refining features” increases only a printed push distance. It does not create a push where none exists and does not increase a pull, teleport, throw arc, or self-movement.
- If Mountain-Demon Might ends because it is dispelled, suppressed, or its duration expires, Titan's Frame ends at the same time even if Titan's Frame would otherwise have remaining duration.

#### CL14 - Titanic Frame

Titan's Frame gains the following improvements:

- It may increase you directly to Large or Huge.
- Your Iron Fist damage die becomes `1d12`.
- Gain Temporary Hit Points equal to your CL when you activate it.
- Your carrying, dragging, lifting, and pushing capacity is quadrupled rather than doubled.
- You may Grapple creatures up to two sizes larger than you.
- Gain Advantage on saving throws against being pushed, pulled, or knocked Prone.

While Mountain-Demon Might is active:

- Your Iron Fist damage becomes `2d8` before modifiers.
- You may become Huge even if you began Small.
- A creature no more than one size larger than you does not gain size-based protection against your Grapples, Shoves, or forced movement.

##### Normalized Procedure — Titanic Frame

- When activating Titan's Frame, choose Large or Huge, subject to legal space. The choice is a direct replacement; you do not need to pass through an intermediate size or pay more Stamina.
- “Count as one additional size larger” from Mountain-Demon Might is a functional permission for Grappling and Shoving only. It does not enlarge occupied space, reach, natural weapon damage, or carrying capacity beyond the values already printed.
- If another rule changes Iron Fist to a larger damage expression, use the largest applicable replacement unless a rule expressly says the expressions stack. The `2d8` Mountain-Demon expression is a replacement, not `1d12 + 2d8`.
- The Temporary Hit Points granted by ordinary Titan's Frame and Mountain-Demon Might are separate grants but still follow the normal nonstacking Temporary Hit Point rule.

#### CL18 - World-Shaking Stomp

**Action**  
**Area:** 30-foot cone  
**Cost:** 6 Stamina  
**Saving Throw:** Dexterity

On a failed save, a creature takes `10d6` Bludgeoning, Force, or Thunder damage, falls Prone, and is pushed 10 feet away from you. On a successful save, it takes half damage, remains standing, and is pushed 5 feet.

The ground in the cone becomes difficult terrain until cleared or repaired. Unattended objects, temporary barriers, vehicles, structures, terrain sections, and Formation Anchors take double damage.

If you are Huge when you activate this feature, its cone becomes 40 feet.

##### Normalized Procedure — World-Shaking Stomp

- Choose Bludgeoning, Force, or Thunder when you activate the feature; all damage from that activation uses the chosen type.
- The cone originates from your space and requires line of effect. It affects creatures and eligible objects in the area once each.
- Forced movement is directly away from you along the shortest legal route. A creature that cannot move the full distance moves as far as legally possible. No collision damage occurs unless another rule expressly creates it.
- The difficult terrain applies only to ordinary ground, floors, or structural surfaces physically struck by the effect. It does not alter open air, incorporeal terrain, an artifact surface, or a higher-authority area unless the governing rule permits it.
- “Double damage” is applied once to the listed unattended targets after Resistance, Immunity, Damage Threshold, and other modifiers in the universal damage procedure. A Formation Anchor that is also a structure is not doubled twice.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Flesh Crucible

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 02. Iron Shirt

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Strike me again. I am still learning your weakness.*

Iron Shirt disciples cultivate refusal. Their bodies become layered armor, their defenses feed counterattacks, and survival becomes a weapon that punishes impatience.

**Access Category:** Open School  
**Primary Identity:** Damage reduction, defensive efficiency, counterattacks, survival  
**Common Sphere Synergies:** Earth, Force, Guardian, Metal, Yang

#### CL3 - Iron Shirt

When you use Stamina Guard, roll `d12s` instead of `d10s`.

If Stamina Guard reduces the triggering damage to 0, gain +1 AC until the start of your next turn. This bonus does not stack with itself. The triggering attack is still treated as having hit if its attack roll succeeded.

##### Normalized Procedure — Iron Shirt

- Replace each `d10` rolled by Stamina Guard with a `d12`; all other Stamina Guard timing, expenditure ceilings, and damage-ordering rules remain unchanged.
- Determine whether damage was reduced to 0 after the complete damage procedure for the triggering packet. Preventing only one damage type in a mixed packet does not qualify if any damage from that packet remains.
- The +1 AC begins after that packet resolves. It can affect later attacks in the same activation but cannot retroactively change the attack that triggered it. Repeated triggers refresh the duration and never increase the bonus above +1.

#### CL6 - Tempered Flesh

While benefiting from Unarmored Defense, gain +1 AC.

You also gain Advantage on Constitution saving throws against Exhaustion caused by physical exertion, forced bodily transformation, physical paralysis, Petrified, Stunned, and effects that deform, liquefy, crystallize, or corrupt the body.

This does not protect against purely mental, spiritual, or identity-based versions of those effects unless they also directly alter the body.

##### Normalized Procedure — Tempered Flesh

- The +1 AC applies only while your AC is currently calculated by Unarmored Defense. It does not apply while armor, a replacement form, or another AC formula is being used.
- The listed Advantage applies when the effect's primary procedure directly exhausts, paralyzes, petrifies, stuns, deforms, liquefies, crystallizes, or physically corrupts your body. A spiritual, mental, emotional, fate, name, memory, or identity effect does not qualify merely because its narration mentions bodily sensation.
- If one effect has both bodily and nonbodily components, Advantage applies only to the save that resists the qualifying bodily component unless the Source Rule uses one save for the entire inseparable effect.

#### CL10 - Bell Strike

**Reaction**  
**Trigger:** A creature within your reach misses you with a melee attack, or Stamina Guard reduces all damage from a melee attack to 0.  
**Limit:** Once per round

Make one unarmed strike against the triggering creature.

On a hit, choose one:

- Push the target 5 feet.
- Prevent it from taking Reactions until the start of its next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Roll the first Stamina Guard die you use before the start of your next turn twice and use the higher result.

Bell Strike follows the Granted Attack rule.

##### Normalized Procedure — Bell Strike

- The miss trigger is checked after all attack rerolls and attack-roll modifiers resolve. The Stamina Guard trigger is checked after the triggering melee damage packet is fully reduced.
- The triggering creature must still be within your current unarmed reach when you make the strike. If it is no longer legal, the Reaction is not spent unless you declared it before the movement or effect that made the target illegal.
- The Stamina Guard-die option applies to the first die actually rolled before the start of your next turn. Roll that die twice and use the higher result; do not double the number of dice. If no die is rolled before the duration ends, the benefit expires.
- Temporary Hit Points follow the normal nonstacking rule. Bell Strike is a Granted Attack and cannot generate another Bell Strike from the same activation.

#### CL14 - Iron Wall

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 5 Stamina  
**Limit:** Once per scene

For the duration:

- Gain Resistance to all damage except Force, Psychic, and Void.
- Gain Advantage against being Grappled, Restrained, pushed, pulled, or knocked Prone.
- Reduce forced movement affecting you by 10 feet.
- Any Stamina Guard die that rolls lower than your Proficiency Bonus is treated as having rolled your Proficiency Bonus.
- Your Speed is reduced by 10 feet.
- You cannot take the Dash action.

Iron Wall's Resistance does not reduce unavoidable self-damage from another feature.

##### Normalized Procedure — Iron Wall

- The Resistance applies to each qualifying damage type before Stamina Guard, following Body Refining Shared Procedures. Force, Psychic, and Void remain unresisted even if they are part of a mixed packet.
- “Unavoidable self-damage” means damage a Source Rule explicitly states cannot be reduced, prevented, redirected, or resisted, or damage paid as a mandatory cost. Ordinary recoil is reduced normally unless it carries that clause.
- Reduce forced movement once per movement event, to a minimum of 0 feet. It does not reduce a teleport distance, a voluntary move, or movement that carries the ground or vehicle supporting you unless the effect classifies that motion as forced movement.
- The Stamina Guard floor applies after rolling each die and before summing them. It does not change maximum-die effects or dice that are not Stamina Guard dice.
- Apply the printed Speed reduction normally. The Dash prohibition prevents the Dash action but not printed movement granted by a feature.

#### CL18 - Invincible Iron

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 6 Stamina  
**Limit:** Once per scene  
**Action:** None

You are reduced to 1 Hit Point instead and immediately activate Iron Wall without paying its Stamina cost, even if Iron Wall was already used during the scene.

Until the start of your next turn:

- Gain Resistance to Force and Psychic damage.
- You cannot be pushed, pulled, knocked Prone, or moved against your will.
- Stamina Guard rolls its maximum value on every die.

Only one feature that prevents or replaces the same reduction to 0 Hit Points may resolve.

##### Normalized Procedure — Invincible Iron

- Resolve this after damage is calculated but before you become Unconscious, make death saves, or trigger an effect requiring you to have reached 0 Hit Points. You must be able to pay 6 Stamina at that moment.
- This is a replacement effect: the triggering reduction becomes 1 Hit Point. It does not heal damage already suffered from earlier packets and does not prevent riders that apply on a hit unless they require the target to take damage or reach 0 Hit Points.
- The free Iron Wall activation ignores its Bonus Action, Stamina cost, and scene-use limit. It refreshes Iron Wall's duration and uses the current printed form of Iron Wall.
- The temporary immunity to forced movement includes teleportation against your will. It does not prevent movement of a platform, vehicle, plane, or world containing you unless that effect specifically moves you as a creature.
- If more than one replacement would prevent the same reduction to 0 Hit Points, choose one before resolving any of them; the others do not trigger from the replaced event.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Iron Shirt

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 03. Stone Fist

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*A wall is only a fist that has not moved yet.*

Stone Fist breaks armor, guards, floors, weapons, barriers, and Formations through concentrated bodily force.

**Access Category:** Open School  
**Primary Identity:** Breaking armor, barriers, Constructs, and structures  
**Common Sphere Synergies:** Brute, Destruction, Earth, Force, Metal

#### CL3 - Breaking Fist

Your unarmed strikes deal double damage to unattended objects, vehicles, structures, temporary barriers, Formation Anchors, and ordinary terrain sections.

Once per turn when you hit a Construct with an unarmed strike, deal additional damage equal to your Proficiency Bonus.

Breaking Fist does not automatically ignore Resistance, Immunity, or Damage Threshold.

##### Normalized Procedure — Breaking Fist

- Determine and apply the printed double-damage multiplier once using the universal damage and object-damage procedure. If the target belongs to more than one listed category, it is still doubled only once.
- A carried, worn, wielded, piloted, or actively controlled object is not unattended. A Formation Anchor is eligible whether or not a creature is maintaining the Formation, unless its own profile says it cannot be attacked.
- “Ordinary terrain section” requires a discrete section the GM can profile with Hit Points or a Damage Threshold. This feature does not allow one strike to destroy an entire mountain, city, plane, or undefined landscape.
- The Construct bonus is one damage addition per turn, after a hit. It is not doubled merely because the Construct is also an object unless the specific target is unattended and the damage procedure says so.

#### CL6 - Overwhelming Blow

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Strength

On a failed save, choose one:

- Push the target 10 feet.
- Knock the target Prone.
- Push the target 5 feet and enter its former space.
- Prevent it from taking Reactions until the start of its next turn.

On a successful save, push the target 5 feet.

If the target collides with a solid surface, it takes Bludgeoning damage equal to your Proficiency Bonus. If it collides with another creature, the second creature makes a Dexterity saving throw. On a failure, both creatures take that damage; on a success, only the original target does.

##### Normalized Procedure — Overwhelming Blow

- Declare the feature after the hit but before applying its forced movement. The target makes one Strength save.
- Entering the target's former space is self-movement, not part of the push. You may do so only if the target actually leaves that space and the space is legal for you. This movement does not provoke Opportunity Attacks from the target but can provoke from other creatures unless another rule prevents it.
- A collision with a solid surface occurs only if the forced movement is stopped early by a substantial physical obstruction. Merely ending adjacent to a wall is not a collision.
- For a creature collision, the original target must be forced into the second creature's space. On the second creature's successful Dexterity save, place the original target in the nearest legal space before the second creature; only the original target takes the collision damage. On failure, place both in the nearest separate legal spaces after damage. No creature can take this collision damage more than once from the same activation.

#### CL10 - Shattering Palm

**Trigger:** You hit a creature, Construct, object, barrier, vehicle, or Formation Anchor with an unarmed strike.  
**Cost:** 3 Stamina  
**Limit:** Once per turn

Choose one form.

##### Break the Guard

A creature or Construct makes a Constitution saving throw.

- **Failed Save:** Its AC is reduced by 2 for 1 minute. It repeats the save at the end of each turn, ending the reduction on a success.
- **Successful Save:** Its AC is reduced by 1 until the start of your next turn.

A target cannot suffer more than one AC reduction from Shattering Palm. Reapplication replaces and refreshes the existing reduction.

##### Fracture the Structure

The attack deals an additional `5d8` Bludgeoning or Force damage, increasing to `7d8` at CL17.

Against a target whose Source CL is no higher than yours, this damage ignores Resistance to Bludgeoning and Force and treats its Damage Threshold as 0. It does not ignore Immunity.

##### Normalized Procedure — Shattering Palm

- Choose Break the Guard or Fracture the Structure when the feature is declared. A target that is both a creature and Construct can be affected by either form, but not both from the same activation.
- Break the Guard modifies the target's current Armor Class regardless of whether it comes from armor, natural armor, Unarmored Defense, a transformation, or an Asset profile. The repeated save occurs at the end of the affected target's turns; success ends only this reduction.
- Reapplication never stacks. If the target already has the failed-save reduction, a successful-save application does not reduce its magnitude or extend it unless the new duration would last longer.
- Fracture the Structure is legal only against an object, barrier, vehicle, Formation Anchor, terrain section, or Construct. A living creature that is not a Construct is not a “structure” merely because it has armor, stone skin, or a large body.
- Treating Damage Threshold as 0 applies only to the additional `5d8` or `7d8`, not automatically to the triggering attack's base damage.

#### CL14 - Earth-Shattering Fist

**Action**  
**Area:** 20-foot cone  
**Cost:** 4 Stamina  
**Saving Throw:** Dexterity

On a failed save, a creature takes `6d8` Bludgeoning or Force damage and falls Prone. On a successful save, it takes half damage and remains standing.

The ground becomes difficult terrain until cleared or repaired. Unattended objects, temporary barriers, vehicles, structures, terrain sections, and Formation Anchors take double damage.

##### Normalized Procedure — Earth-Shattering Fist

- Choose Bludgeoning or Force on activation. The cone originates from your body or striking limb and requires line of effect.
- Each creature saves once. Each listed unattended object or terrain section in the cone is damaged once and does not make the creature save unless its own profile provides one.
- Difficult terrain is physical disruption of the struck surface. Clearing or repairing one 5-foot square requires one Action with suitable tools or a comparable effect unless the terrain or Source Rule establishes a different procedure.
- A target qualifying under multiple unattended categories takes double damage only once.

#### CL18 - Heaven-Cracking Blow

**Trigger:** You hit with an unarmed strike.  
**Cost:** 7 Stamina  
**Limit:** Once per scene  
**Saving Throw:** Strength

The attack deals an additional `10d10` Bludgeoning or Force damage.

Against a target whose Source CL is no higher than yours, the additional damage ignores Resistance to Bludgeoning and Force, treats Damage Threshold as 0, and deals double damage to objects, vehicles, structures, temporary barriers, Constructs, and Formation Anchors.

On a failed save, push the target 30 feet, knock it Prone, and prevent it from taking Reactions until the start of its next turn. On a successful save, push it 10 feet.

This feature does not automatically ignore Immunity, an Immortal protection, or a permanent artifact property.

##### Normalized Procedure — Heaven-Cracking Blow

- Declare the feature after the hit and choose Bludgeoning or Force before rolling the additional damage.
- The Source CL comparison is between this feature's Source CL and the target or defending structure's relevant Source CL. A mundane target has Source CL 0 unless another rule assigns one.
- The listed double damage applies once to the additional `10d10`; it does not double the triggering attack unless another rule says so.
- Push the target directly away along a legal route. If movement is blocked, move it as far as possible; no collision damage is created by this feature alone.
- “Immortal protection” includes only a printed Immortal, resurrection, reconstruction, conceptual, artifact, or absolute clause. Ordinary high Hit Points, Resistance, or regeneration are handled by the feature's normal damage rules.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Stone Fist

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 04. Sumo

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The ring is wherever my feet decide it begins.*

Sumo refiners master rooted pressure. They dominate space, deny movement, and make every shove and collision feel like ritual judgment.

**Access Category:** Open School  
**Primary Identity:** Rooting, collisions, pushing, battlefield control  
**Common Sphere Synergies:** Brute, Earth, Gravity, Guardian, Wrestling

#### CL3 - Rooted Stance

**Bonus Action**

Enter Rooted Stance. It lasts until you become airborne without a supporting surface, willingly teleport, willingly move more than half your Speed during one turn, become Unconscious, or end it without using an action.

While Rooted:

- Gain Advantage on checks and saving throws against Grapples, Shoves, forced movement, and being knocked Prone.
- Gain Advantage on saving throws or Cultivation Checks against unwilling teleportation.
- Count as one size larger for Grappling, Shoving, carrying, lifting, and resisting forced movement.
- Reduce forced movement affecting you by 5 feet.

You may reenter Rooted Stance with another Bonus Action.

##### Normalized Procedure — Rooted Stance

- Rooted Stance is a stance, not a transformation and not Concentration. Entering it does not spend movement.
- “Touching a supporting surface” includes standing, kneeling, sitting, bracing with a limb, or being physically anchored to a substantial surface. A creature carried entirely by another creature is not supported unless a feature says it can root through that carrier.
- Track the voluntary distance you move during each of your turns. The stance ends immediately when that total exceeds half your current Speed. Forced movement, movement of a platform, and movement while you are Incapacitated do not count. Willingly teleporting ends it regardless of distance.
- The “count as larger” permission applies only to the listed operations and does not change your occupied space, reach, weapon damage, or legal mount size.
- Reduce forced movement once per movement event, to a minimum of 0 feet. This does not reduce teleportation; the separate Advantage against unwilling teleportation applies to that procedure.

#### CL6 - Sumo Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Push the target 10 feet. If the target is more than one size larger than you, it makes a Strength saving throw. On a failure, push it 10 feet; on a success, 5 feet.

If the target collides with a creature or solid surface, both take `1d6` Bludgeoning damage, increasing to `2d6` at CL11 and `3d6` at CL17. A second creature makes a Dexterity saving throw, taking no damage on a success.

##### Normalized Procedure — Sumo Strike

- Declare the feature after the hit. If the target is no more than one size larger, the 10-foot push has no save. A larger target makes the printed Strength save.
- Forced movement is directly away from you unless the target and you share a space, in which case choose a legal direction away from the center of your space.
- Collision damage is one packet per affected creature per activation. If the target collides with a creature, the second creature's successful Dexterity save causes it to take no damage and the original target stops in the nearest legal space; the original target still takes its collision damage.
- A solid-surface collision requires the push to end early because of a substantial obstruction. A creature that completes the full push adjacent to a wall does not collide.

#### CL10 - Ring Breaker

**Action**  
**Range:** Your unarmed reach  
**Cost:** 3 Stamina  
**Saving Throw:** Strength

On a failed save, push the target up to 20 feet, knock it Prone, and you may enter its former space. On a successful save, push it 5 feet and you may enter its former space if unoccupied.

If the target collides with a solid surface, it takes `3d8` Bludgeoning damage. If it collides with another creature, that creature makes a Dexterity saving throw, taking `3d8` and falling Prone on a failure, or half damage and remaining standing on a success.

##### Normalized Procedure — Ring Breaker

- The target must be within your current unarmed reach when the Action begins. This is a Body Refining technique, not an Attack action or weapon attack unless another rule expressly converts it.
- Choose the destination along a line away from you, up to the allowed distance. If the chosen destination is illegal, use the nearest legal space along that route.
- You enter the target's former space only after its movement resolves. On a successful save, you can enter only if the target actually vacated the space.
- A solid-surface collision occurs only if the target's movement is stopped by the surface before reaching the chosen distance.
- For a creature collision, resolve the second creature's save before placing either creature. On failure, both occupy the nearest separate legal spaces around the collision point after taking damage. On success, the second creature remains in place and the original target stops before its space.

#### CL14 - Yokozuna Presence

While Rooted Stance is active:

- Hostile creatures treat spaces within 10 feet of you as difficult terrain.
- A creature cannot move through your space unless it is at least two sizes larger than you.
- An ally gains Half Cover against a ranged attack when it is within 5 feet of you and the line from attacker to ally crosses your space.
- You may use Constitution instead of Charisma for Intimidation checks.
- Gain proficiency in Intimidation. If already proficient, gain a +2 bonus to Intimidation checks.

##### Normalized Procedure — Yokozuna Presence

- Hostile difficult terrain applies while a hostile creature is moving through a space within 10 feet of you, including the space it begins in. It does not stack with itself; use the normal difficult-terrain rule.
- A creature at least two sizes larger can move through your space using the normal occupied-space rules. Smaller creatures remain prohibited unless a specific feature permits them.
- Half Cover is checked for each ranged attack when the attack is declared. “Crosses your space” means a straight line from any point of the attacker’s space to any point of the ally's space passes through your occupied space. This does not grant cover against melee attacks or area effects.
- Constitution replaces Charisma only for the ability modifier of the Intimidation check. Proficiency, Expertise, and other bonuses apply normally.

#### CL18 - Immovable God

Rooted Stance no longer ends when you move more than half your Speed and no longer requires a Bonus Action to enter.

While touching a solid surface:

- An effect whose Source CL is lower than yours cannot push, pull, knock you Prone, or teleport you unwillingly.
- Count as two additional sizes larger for Grappling, Shoving, carrying, and resisting forced movement.

When an equal- or higher-CL effect attempts to move or teleport you unwillingly, make an opposed Cultivation Check against its source. On a success, the movement fails; on a failure, it resolves normally.

Once during each of your turns, after willingly moving at least 10 feet, make one unarmed strike against one creature that entered your reach during that movement. This attack follows the Granted Attack rule.

##### Normalized Procedure — Immovable God

- You are considered to enter Rooted Stance automatically whenever you are touching a qualifying solid surface and are conscious; no action is required. You can end the stance without an action, but it automatically resumes when the conditions are again met unless you choose otherwise.
- Lower-Source-CL immunity applies only to effects that directly push, pull, knock you Prone, or teleport you unwillingly. It does not prevent destruction of the surface, movement of a vehicle or world, Grappling, Restrained, or an effect that transforms your body unless it also performs one of the listed movements.
- Against equal or higher Source CL, use one opposed Cultivation Check per movement event. Success prevents that entire movement event; failure allows it to resolve normally. This check does not consume your Reaction.
- The granted strike triggers once during each of your turns after you have willingly moved at least 10 feet total. Select one creature whose space first became within your reach during that movement. A creature that remained within reach for the entire movement did not “enter” your reach. The strike resolves after the movement ends unless the route ends before the creature leaves your reach.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Sumo

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 05. Drunken Fist

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*If I cannot find my balance, neither can you.*

Drunken Fist looks careless until the miss becomes a trap. Its practitioners turn falls, sways, and broken timing into attacks.

**Access Category:** Open School  
**Primary Identity:** Evasive instinct, stumbling counters, unpredictable movement  
**Common Sphere Synergies:** Drunken Style, Flowing River, Mist, Monkey Style, Scoundrel

#### CL3 - Swaying Step

Gain proficiency in Acrobatics. If already proficient, gain a +2 bonus to Acrobatics checks.

Whenever you use Stomping Step, choose one:

- Move 5 feet without provoking Opportunity Attacks.
- Stand from Prone without spending movement.
- Fall Prone intentionally, then move 5 feet.
- Gain Advantage on your next Dexterity saving throw before the start of your next turn.
- Gain Advantage on your next Acrobatics check before the start of your next turn.

The additional movement is separate from the movement granted by Dash.

##### Normalized Procedure — Swaying Step

- Choose exactly one option each time you activate Stomping Step. The option is part of that same activation and does not require another action.
- The 5-foot movement must end in a legal space. “Fall Prone intentionally, then move” means you become Prone before moving and use your normal Prone movement rules unless the feature or another rule changes them.
- Standing from Prone through this feature spends no movement and can occur even if your Speed is 0, unless a restraint or anatomical effect expressly prevents standing.
- Advantage granted by an option applies to one qualifying roll and expires at the stated time. It does not stack with another source of Advantage.

#### CL6 - Falling Fist

**Reaction**  
**Trigger:** You intentionally fall Prone, are knocked Prone, or stand from Prone.  
**Limit:** Once per round

Make one unarmed strike against a creature within reach.

On a hit, choose one:

- Move 5 feet without provoking Opportunity Attacks.
- Push the target 5 feet.
- Prevent the target from taking Reactions until the start of its next turn.

This attack follows the Granted Attack rule.

##### Normalized Procedure — Falling Fist

- One event can trigger Falling Fist only once. Intentionally falling Prone and then standing during the same movement are two events, but the once-per-round limit still allows only one use.
- Declare the Reaction immediately after the triggering change of posture resolves. The target must then be within current unarmed reach.
- The granted attack cannot trigger another Falling Fist from movement, a fall, or a posture change caused by one of its own riders.
- The 5-foot self-movement occurs after the hit and must use a legal space. The target cannot make an Opportunity Attack against that movement; other creatures can unless another rule says otherwise.

#### CL10 - Staggering Blow

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Dexterity

On a failed save, choose one:

- Knock the target Prone.
- Push it 10 feet.
- Move yourself 10 feet without provoking Opportunity Attacks.
- Reduce its Speed by 10 feet until the start of your next turn.

On a successful save, move yourself 5 feet without provoking Opportunity Attacks.

##### Normalized Procedure — Staggering Blow

- Declare after the hit. The target makes one Dexterity save before the selected failed-save effect resolves.
- The self-movement options are voluntary granted movement. They must end in a legal space and do not permit movement through creatures unless another rule does.
- The push is directly away from you. If blocked, move the target as far as legally possible; no collision damage is created.
- The Speed reduction modifies each of the target's Speeds and cannot reduce a Speed below 0. Reapplication refreshes rather than stacks.

#### CL14 - Empty Cup

**Reaction**  
**Trigger:** An attack roll hits you.  
**Cost:** 2 Stamina  
**Limit:** Once per round

The attacker rerolls the attack with Disadvantage and uses the new result.

After the reroll resolves, move up to 10 feet without provoking Opportunity Attacks. During this movement, you may fall Prone, stand from Prone, move through one hostile creature's space as difficult terrain, or end in an unoccupied space on the opposite side of the attacker.

If the rerolled attack can still reach your new space, resolve it normally. Otherwise, it misses.

##### Normalized Procedure — Empty Cup

- Declare after an attack roll has hit but before damage or hit riders resolve. The reroll replaces the original attack roll even if the new result is higher.
- Determine the rerolled result against your Armor Class before moving, but do not apply damage yet. Then take the granted movement. After movement, recheck the same attack's legal target, reach or range, line of effect, and cover from the attacker's unchanged origin.
- If the reroll misses your Armor Class, the attack misses regardless of movement. If it would hit but can no longer legally reach or target your new space, it misses. Otherwise, resolve the attack and its riders against you normally.
- Passing through one hostile creature's space does not permit you to end there and does not let you pass through an effect that physically blocks passage. The “opposite side” space must be adjacent to the attacker and legal for you.
- This movement occurs during the triggering attack's resolution and cannot itself trigger Empty Cup again.

#### CL18 - Heavenly Drunk

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

For the duration:

- Gain Advantage on Dexterity saving throws.
- Opportunity Attacks against you have Disadvantage.
- Standing from Prone costs no movement.
- Crawl at your full Speed.
- Move through hostile creature spaces as difficult terrain.
- Once per round when an enemy misses you, move up to 10 feet without provoking Opportunity Attacks.
- Use Falling Fist once per round without spending your Reaction.
- Once per turn after intentionally falling Prone, gain +2 AC until the start of your next turn.

The reaction-free Falling Fist still follows the Granted Attack rule.

##### Normalized Procedure — Heavenly Drunk

- “Use Falling Fist without spending your Reaction” removes only the Reaction cost. Falling Fist remains limited to once per round total, whether used normally or through this feature.
- The once-per-round movement when an enemy misses you requires no action and occurs after that attack is fully resolved. A miss created by Empty Cup qualifies, but movement from the same miss occurs only once under this bullet.
- Moving through a hostile space treats each such space as difficult terrain and still requires enough movement. You cannot end in an occupied space.
- The +2 AC begins immediately after you intentionally become Prone and lasts until the start of your next turn. Repeated intentional falls refresh but do not stack it. Being knocked Prone unwillingly does not qualify.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Drunken Fist

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 06. Mantis Style

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*A small hook in the right joint can move a giant.*

Mantis Style attacks joints, tendons, grips, and openings, controlling larger enemies through precision.

**Access Category:** Open School  
**Primary Identity:** Joint locks, precision Grappling, disabling strikes  
**Common Sphere Synergies:** Fencing, Poison, Scoundrel, Thread, Wrestling

#### CL3 - Mantis Hooks

Your unarmed strikes may deal Piercing damage.

Once per turn when you hit a creature with an unarmed strike, attempt to Grapple it without using another action. The target makes a Strength or Dexterity saving throw, its choice. On a failure, it is Grappled by you.

Before rolling the attack's damage, you may choose to deal damage equal only to your ability modifier. If you do, the target has Disadvantage on the Grapple saving throw.

##### Normalized Procedure — Mantis Hooks

- The free Grapple attempt occurs after the triggering hit resolves and requires the target to remain within your Grapple reach. Apply normal size and anatomy restrictions from Body Refining Shared Procedures.
- The target chooses Strength or Dexterity each time it saves. This is a saving throw against your Cultivation Save DC, not an ability check.
- If you reduce the attack's damage, the total damage from that hit becomes only the ability modifier used for the attack roll, minimum 0. Do not roll the weapon or Iron Fist damage dice and do not add other damage riders from that attack unless they state they apply when the attack deals no normal damage.
- The hit still counts as a hit for Mantis Hooks and other non-damage triggers. The reduced-damage choice must be made before any damage dice are rolled.
- Mantis Hooks can activate once per turn, regardless of the number of attacks, reactions, or granted attacks you make.

#### CL6 - Joint Lock

**Bonus Action**  
**Requirement:** You are Grappling the target.  
**Cost:** 1 Stamina  
**Saving Throw:** Dexterity

On a failed save, the target is Restrained until the start of your next turn or until the Grapple ends. On a successful save, it cannot take Reactions until the start of your next turn.

Reusing Joint Lock requires a new saving throw.

##### Normalized Procedure — Joint Lock

- Select one creature you are currently Grappling and within your Grapple reach. The Grapple must be maintained by you, not solely by an ally or independent Asset.
- On failure, Restrained ends at the earlier of the start of your next turn, the Grapple ending, you becoming unable to maintain the required anatomy, or the target leaving your Grapple reach through a legal exception.
- On success, the no-Reactions result applies even though the target avoided Restrained.
- Each use is a new activation and save. Reapplication can refresh but never extend the Restrained duration beyond the start of your next turn.

#### CL10 - Rapid Pincer

Once per turn when you take the Attack action, replace one unarmed strike with two unarmed strikes.

The additional strike cannot grant another attack, cannot cause Mantis Hooks to activate more than once during the turn, cannot apply the same once-per-turn damage rider twice, and cannot be replaced by Rapid Pincer.

##### Normalized Procedure — Rapid Pincer

- Replace one unarmed strike when that strike would be made during your Attack action. Resolve the two replacement strikes sequentially against the same or different legal targets.
- Both strikes are part of one Rapid Pincer activation, but each is a separate attack and damage packet.
- The additional strike is the second of the two. It cannot be replaced by a feature that replaces an attack with multiple attacks, cannot grant an attack, and cannot receive a once-per-turn rider already used during the turn.
- Rapid Pincer can be used only once per turn, even if you take more than one Attack action.

#### CL14 - Eye of the Mantis

**Bonus Action**  
**Range:** 60 feet  
**Duration:** 1 minute  
**Cost:** 3 Stamina  
**Target:** One creature you can see

Learn its current and maximum Hit Points, Armor Class, damage Resistances, damage Immunities, whether it is maintaining Concentration, its active physical conditions, and whether Strength, Dexterity, or Constitution is its lowest physical saving throw.

For the duration:

- Gain Advantage on the first attack roll you make against it during each turn.
- Gain Advantage on attempts to Grapple it.
- It has Disadvantage on the first saving throw it makes against Joint Lock during each of your turns.

The feature ends if the target is more than 1 mile from you.

##### Normalized Procedure — Eye of the Mantis

- The feature reads the target's current mechanical profile when activated. It reveals only the listed data and does not reveal hidden actions, future choices, spell or technique lists, exact ability scores, vulnerabilities, Source CL, or identity unless another rule does.
- If an equal-or-higher-authority effect specifically conceals one listed datum from supernatural diagnosis, make a Cultivation Check against that effect's save DC. On failure, you learn that the datum is concealed rather than receiving false information.
- “Lowest physical saving throw” compares the target's total current Strength, Dexterity, and Constitution save modifiers, including temporary modifiers. If tied, learn all tied abilities.
- Each per-turn first occurrence is tracked separately: first attack roll, first Grapple attempt, and first Joint Lock save. The target being unseen does not by itself end the feature, but normal attack and perception rules still apply.

#### CL18 - Death of a Thousand Cuts

**Trigger:** You hit with an unarmed strike.  
**Cost:** 4 Stamina  
**Limit:** Once per turn

The attack deals an additional `6d6` Piercing damage.

Choose one:

- The target cannot take Reactions until the start of its next turn.
- Its Speed becomes 0 until the start of its next turn.
- It has Disadvantage on its next Concentration saving throw before the end of your next turn.
- It has Disadvantage on its next saving throw against being Grappled or Joint Lock before the end of your next turn.
- It makes a Dexterity saving throw. On a failure, it drops one nonartifact object it is holding.

##### Normalized Procedure — Death of a Thousand Cuts

- Declare after the hit and before rolling the additional damage. The `6d6` is part of the triggering attack's damage packet for Resistance and other damage modifiers.
- Choose exactly one rider. The rider is not contingent on the target taking damage unless its own wording requires a save.
- For the drop-object rider, identify one nonartifact object the target is holding that you can perceive. On a failed save, it falls into the target's space or the nearest legal space. An integrated weapon, body part, worn item, or object physically fused by a higher-authority effect is not “held.”
- Disadvantage riders affect only the next qualifying roll in the duration and are then consumed. Reapplication refreshes rather than stacks.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Mantis Style

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 07. Jujutsu

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Bring force. I will return it with interest.*

Jujutsu refiners cultivate yielding as violence. They redirect attacks, sacrifice damage for control, and turn commitment into defeat.

**Access Category:** Open School  
**Primary Identity:** Redirection, throws, yielding defense  
**Common Sphere Synergies:** Flowing River, Guardian, Drunken Style, Water, Wrestling

#### CL3 - Redirect Force

**Reaction**  
**Trigger:** A creature within your reach misses you with a melee attack.  
**Limit:** Once per round

Choose one:

- Move the attacker 5 feet into an unoccupied space.
- Move yourself 5 feet without provoking Opportunity Attacks.
- Move around the attacker to another unoccupied adjacent space.
- Gain Advantage on your next attempt to Grapple or Shove it before the end of your next turn.

Forced movement from Redirect Force cannot move a creature into a space it cannot occupy.

##### Normalized Procedure — Redirect Force

- The miss trigger is checked after all rerolls and attack modifiers. Declare the Reaction before the attacker begins another action or movement.
- Moving the attacker is forced movement; moving yourself is voluntary granted movement. Neither movement can pass through an illegal space. Moving around the attacker does not permit you to pass through its space unless another rule allows it.
- The attacker movement does not provoke Opportunity Attacks from you. Other creatures can make Opportunity Attacks only if the general forced-movement rules permit them.
- Advantage applies to one next Grapple or Shove attempt against the triggering attacker and expires at the end of your next turn.

#### CL6 - Gentle Fist

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Choose to deal no damage with the triggering attack. The target makes a Constitution saving throw.

On a failed save, choose two different effects; on a successful save, choose one:

- Its Speed is halved until the start of your next turn.
- It has Disadvantage on its next attack roll before the start of your next turn.
- It cannot take Reactions until the start of your next turn.
- It has Disadvantage on its next Strength or Dexterity saving throw before the start of your next turn.

##### Normalized Procedure — Gentle Fist

- Declare after the hit and before rolling damage. The triggering attack deals 0 damage, not merely no weapon-die damage.
- The attack still counts as a hit for Gentle Fist and other non-damage hit triggers. A rider requiring the target to take damage does not trigger.
- On a failed save, choose two different effects; on success, choose one. Reapplying the same effect refreshes its duration and does not stack.
- The Strength-or-Dexterity-save Disadvantage option is chosen when the effect is applied: Strength or Dexterity. It affects the target's next save of that chosen type before the duration ends.

#### CL10 - Throw

**Bonus Action**  
**Requirement:** You are Grappling the target.  
**Cost:** 2 Stamina  
**Saving Throw:** Strength or Dexterity, target's choice

On a failed save, throw the target up to 15 feet to an unoccupied space, deal `3d8` Bludgeoning damage, knock it Prone, and end the Grapple. On a successful save, move it 5 feet and you may end the Grapple.

If it collides with a solid surface, it takes additional Bludgeoning damage equal to your Proficiency Bonus. If it collides with another creature, that creature makes a Dexterity saving throw, taking the same damage on a failure.

##### Normalized Procedure — Throw

- Choose a legal destination within 15 feet. The movement is forced movement along a route you can physically execute with the Grapple; it is not teleportation and cannot pass through a solid obstruction.
- On a failed save, damage and Prone resolve after placement, then the Grapple ends. On a successful save, move the target 5 feet along a legal route and choose whether the Grapple ends.
- A solid-surface collision occurs only when the target's movement is stopped early by a substantial obstruction.
- For a creature collision, the second creature makes the Dexterity save before placement. On failure, it takes the same `3d8` collision damage and is placed in the nearest legal space; on success, it takes no damage and the thrown target stops before its space. The thrown target's own `3d8` from Throw is not duplicated by the collision unless the solid-surface clause applies.
- A creature can suffer collision damage from this activation only once.

#### CL14 - Harmonious Body

**Reaction**  
**Trigger:** A creature within your reach targets you with a melee attack.  
**Cost:** 3 Stamina  
**Limit:** Once per round  
**Saving Throw:** Strength

The target makes the saving throw before resolving its attack roll.

On a failed save, choose one:

- Redirect the attack toward another legal creature within the attacker's reach, using the original attack roll.
- Move the attacker up to 10 feet. If you are no longer within its reach, the attack misses.
- Knock the attacker Prone. The triggering attack misses.

On a successful save, resolve the attack normally. If it hits, reduce its damage by `2d8 + Constitution modifier`.

Harmonious Body cannot redirect an area effect or environmental hazard.

##### Normalized Procedure — Harmonious Body

- Declare after you are targeted but before the triggering attack roll. The attacker makes the Strength save immediately.
- If you redirect the attack, choose a legal creature within the attacker's current reach and legal for the original attack. Then the attacker rolls the original attack against the new target using all modifiers and conditions that would have applied. The attack is still the attacker's activation, not yours.
- If you move the attacker, choose a legal destination within 10 feet. Recheck whether you are a legal target and within reach after movement. If not, the attack misses; otherwise, roll it normally.
- If you knock the attacker Prone, the triggering attack misses without an attack roll. Prone then applies normally.
- On a successful save, resolve the original attack. If it hits, reduce its damage by `2d8 + Constitution modifier` as an other flat reduction under the Body Refining Shared Procedures damage order. This cannot reduce damage below 0.
- A redirected attack cannot be redirected again by Harmonious Body, Empty Body, or another copy of this same procedure.

#### CL18 - Empty Body

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

For the duration:

- Gain Advantage on Dexterity saving throws.
- Gain Advantage on checks and saving throws to escape Grappled or Restrained.
- Opportunity Attacks against you have Disadvantage.
- Whenever a creature misses you with a melee attack, move 5 feet without provoking Opportunity Attacks.
- Use Redirect Force once per round without spending your Reaction.
- Once per round, when a melee attack misses you, redirect it toward another legal creature within the attacker's reach using the original attack roll.

A redirected attack cannot be redirected again.

##### Normalized Procedure — Empty Body

- The 5-foot movement after a melee miss requires no action and occurs after that attack is fully resolved. It cannot pass through an occupied or solid space.
- “Use Redirect Force without spending your Reaction” removes only the Reaction cost. Redirect Force remains once per round total.
- The separate once-per-round attack redirection requires no Reaction. Choose a legal creature within the attacker's reach after the miss is confirmed, and resolve the original attack roll against that creature. If the original attack roll cannot hit the new target's AC, it misses.
- You can use the 5-foot movement and the once-per-round redirection from the same miss, in either order, because both are printed benefits. Recheck legal reach after the chosen order.
- An attack redirected by this feature cannot be redirected again by any feature. The attacker remains the source of the attack, damage, and riders.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place the creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an injury, severance, disabled limb, bodily Asset, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, natural weapon, or additional limb grants only the attacks, movement, actions, and reactions printed by the feature.

### Integrated Procedure Closure — Jujutsu

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 08. Bojutsu

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The staff is a road, a wall, and a storm.*

Bojutsu extends the body through disciplined staff rhythm, controlling reach, space, and physical projectiles.

**Access Category:** Open School  
**Primary Identity:** Staff integration, reach, circular defense  
**Common Sphere Synergies:** Flowing River, Force, Guardian, Monkey Style, Spear

#### CL3 - Staff Form

Gain proficiency with Staff weapons.

While wielding a Staff weapon:

- Use Constitution instead of Strength or Dexterity for its attack and damage rolls.
- You may use your Cultivation Attack Modifier for its attack rolls.
- It is integrated into your Body Refining cultivation.
- Its reach increases by 5 feet during your turn.
- Refined Iron Fist and Heavenly Fist apply to it.

This does not grant the Spear or Weapons Sphere.

##### Normalized Procedure — Staff Form
- **Staff record.** A Staff is a quarterstaff or a weapon carrying the Staff tag. Record the specific weapon integrated by this feature. Its item properties, enhancement, damage type, handedness, and other tags remain unchanged unless this Subpath expressly changes them.
- **Ability and attack choice.** For each Staff attack, choose Constitution or another ability the weapon already permits. If you choose Constitution, use the Cultivation Attack Modifier and Constitution for damage. The same attack cannot add two ability modifiers unless another rule expressly permits it.
- **Integrated weapon.** The wielded Staff is an integrated weapon while you wield it. Refined Iron Fist and Heavenly Fist apply their cultivation-powered, adamantine, Force-damage, and object-damage permissions; they do not replace the Staff's normal damage die with the Iron Fist die unless another Source Rule explicitly does so.
- **Turn-limited reach.** The 5-foot increase applies to Staff attacks and Staff features only during your own turn. It does not enlarge your ordinary threatened reach for Opportunity Attacks outside your turn. Heavenly Staff Barrier changes this geometry as stated in its normalized procedure.
- **No Sphere grant.** Staff Form does not grant a Sphere, Sphere talent, Recorded Art, or proficiency with another Polearm.

#### CL6 - Flowing Spin

**Bonus Action**  
**Requirement:** You took the Attack action and made at least one Staff attack during the turn.  
**Cost:** 1 Stamina

Make one additional Staff attack. Its damage die is `1d6` before modifiers if the weapon's normal damage die is lower.

This attack follows the Granted Attack rule.

##### Normalized Procedure — Flowing Spin
- Confirm the requirement after at least one Staff attack has been made as part of the Attack action during the current turn. The attack need not have hit.
- The Bonus Action makes exactly one additional Staff attack. It is a granted attack and cannot grant another attack.
- If the Staff's normal damage die is lower than `1d6`, use `1d6` before modifiers for this attack. If it is `1d6` or higher, use the normal die. This floor does not add a second die and does not replace other printed damage.
- The requirement is not satisfied by an Opportunity Attack, Reaction attack, Flowing Spin attack, or another attack outside the Attack action.

#### CL10 - Sweeping Strike

**Trigger:** You hit with a Staff attack.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Dexterity

On a failed save, choose one:

- Knock the target Prone.
- Push it 10 feet.
- Move it to another unoccupied space within your reach.
- Prevent it from taking Reactions until the start of its next turn.

On a successful save, push it 5 feet.

##### Normalized Procedure — Sweeping Strike
- Declare the feature after the Staff attack hits and its ordinary hit damage is determined. Spend Stamina before the target rolls the save.
- **Prone** and **Reaction denial** apply after the hit resolves.
- A push moves directly away from you along the shortest legal route. A target that cannot move the full distance moves as far as legally possible; no collision damage is created.
- “Move it to another unoccupied space within your reach” is forced physical repositioning, not teleportation. Choose a legal space within your current Staff reach. The target travels through a legal route no longer than the distance between its original and destination spaces and cannot pass through a solid barrier or an occupied space unless ordinary forced movement permits it.
- On a successful save, the 5-foot push is mandatory. If no legal space exists, the target remains in place and no substitute effect is invented.
- One target can be affected by Sweeping Strike only once per turn from you, even if you make multiple Staff attacks.

#### CL14 - Staff of One

While wielding a Staff weapon:

- Gain +1 AC.
- Gain Advantage against being Disarmed.
- Gain Advantage on Opportunity Attacks made with the Staff.

##### Deflecting Staff

**Reaction**  
**Trigger:** You or an ally within 5 feet takes damage from a ranged weapon attack or physical projectile.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Reduce the damage by `2d10 + Constitution modifier`.

If this reduces the damage to 0, choose one:

- Catch the projectile if it is small enough to hold.
- Deflect it into an unoccupied space within 15 feet.
- Move 5 feet without provoking Opportunity Attacks.
- Grant the protected ally Half Cover until the start of your next turn.

Deflecting Staff does not block a ray, beam, purely energetic projectile, or save-based area effect.

##### Normalized Procedure — Staff of One
- The +1 AC requires you to be wielding a Staff. It is an AC bonus, not a base AC calculation, and does not stack with another instance of Staff of One.
- Advantage against being Disarmed applies to checks and saving throws made specifically to retain the Staff. It does not prevent theft while you are helpless or the destruction of the weapon by a legal higher-authority effect.
- The Opportunity Attack Advantage applies only when the attack is made with the Staff.
- **Deflecting Staff timing.** Declare after the triggering ranged weapon attack or discrete physical projectile has determined damage but before that packet reduces Hit Points. Apply the reduction as an other flat reduction under the shared damage order.
- “Physical projectile” means a discrete material projectile whose path can be intercepted, including ordinary ammunition, thrown weapons, stones, needles, bolts, and comparable manifested matter. It excludes rays, beams, purely energetic bolts, sound, gaze effects, save-based areas, and effects whose rule says they cannot be physically intercepted.
- If a mixed damage packet qualifies because the attack is delivered by a physical projectile, reduce the entire triggering packet. A separate explosion, poison cloud, curse, or area effect created after impact is not canceled unless its Source Rule says interception prevents it.
- If damage becomes 0, choose exactly one printed option. Catching requires a discrete object small enough for one free hand and does not duplicate ammunition or an item. Deflecting into a space ends the triggering attack against its original target; it does not make an attack against another creature. The 5-foot movement must end in a legal space. Half Cover applies only to the protected ally and lasts as printed.
- Deflecting Staff remains once per round even if another feature grants an additional Reaction.

#### CL18 - Heavenly Staff Barrier

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

For the duration:

- Your Staff reach increases by another 5 feet.
- Gain one additional Reaction each round, usable only for a Staff Opportunity Attack, Deflecting Staff, or another Staff feature.
- Hostile creatures provoke Opportunity Attacks when entering your reach.
- A creature hit by your Opportunity Attack has its Speed reduced to 0 for the remainder of the turn.
- You and allies within 10 feet gain Half Cover against ranged weapon attacks and physical projectiles.

Once per turn after hitting with a Staff attack, choose one:

- Push the target 10 feet.
- Move 10 feet without provoking Opportunity Attacks.
- Prevent the target from taking Reactions until the start of its next turn.
- Gain +1 AC until the start of your next turn.

---

##### Normalized Procedure — Heavenly Staff Barrier
- You must wield a Staff to receive its reach, Opportunity Attack, Deflecting Staff, and cover benefits. If you cease wielding one, those benefits become dormant while the duration continues and resume when you wield one again.
- **Reach geometry.** During the barrier, your Staff reach is increased by 5 feet outside your turn and by a total of 10 feet during your turn: 5 feet from Staff Form and another 5 feet from this feature. This lets entry into the barrier reach provoke as printed.
- The additional Reaction refreshes at the start of each round and can be spent only on a Staff Opportunity Attack, Deflecting Staff, or a Reaction explicitly identified as a Staff feature. It does not remove any once-per-round limit.
- A hostile creature provokes when it voluntarily enters your current Staff reach. Forced movement, teleportation, appearing in place, and the reach expanding around a creature do not provoke unless another rule says they do.
- On a Staff Opportunity Attack hit, Speed becomes 0 only for the remainder of the current turn. It does not end a teleport already completed or retroactively cancel movement before the hit.
- The 10-foot Half Cover aura moves with you, requires no action, and applies only against ranged weapon attacks and physical projectiles. A creature receives the benefit while within the aura at the instant the attack is resolved.
- The once-per-turn hit rider is chosen after a Staff hit resolves. The 10-foot self-movement requires a legal route and does not provoke. The AC option lasts exactly until the start of your next turn and does not stack with itself.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Bojutsu

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 09. Karate

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*One breath. One line. One ending.*

Karate refines the striking body into clean intent, precise timing, and decisive force without wasted movement.

**Access Category:** Open School  
**Primary Identity:** Efficient unarmed striking, timing, perfected attacks  
**Common Sphere Synergies:** Brute, Fencing, Force, Light, Yang

#### CL3 - Focused Strike

Once per turn when you hit with an unarmed strike, choose one Iron Fist damage die from the attack. Roll that die twice and use the higher result.

This does not reroll additional damage from another feature.

##### Normalized Procedure — Focused Strike
- After an unarmed strike hits, identify one die that is part of the attack's Iron Fist damage expression. Roll that single die twice and use the higher result.
- If Iron Fist currently rolls multiple dice, only one die receives this treatment. If the attack does not contain an Iron Fist damage die, Focused Strike does not apply.
- This is not a reroll after seeing a completed result. Both rolls are made together for the selected die, and another reroll feature can affect them only if its own rule expressly permits interaction with a roll-twice mechanic.
- Additional dice from a critical hit, Insight, Sphere talent, item, rider, or Subpath feature are not eligible unless they are explicitly identified as Iron Fist dice.

#### CL6 - Perfect Breath

After you use Stomping Step, the first unarmed attack you make before the end of the turn ignores one source of Disadvantage affecting its attack roll. Other sources of Disadvantage still apply normally.

On a hit, once per turn:

- Deal additional damage equal to your Proficiency Bonus.
- Choose one:
  - Move 5 feet without provoking Opportunity Attacks.
  - Push the target 5 feet.
  - Gain +1 AC against the target until the start of your next turn.

##### Normalized Procedure — Perfect Breath
- The first unarmed attack you make after using Stomping Step must occur before the end of the same turn. If it misses or is never made, the benefit expires.
- Ignoring one source of Disadvantage removes one identified cause before Advantage and Disadvantage are combined. Other causes remain. This does not create Advantage by itself.
- The Proficiency Bonus damage and chosen rider apply only if that first unarmed attack hits, and together constitute one once-per-turn use of Perfect Breath.
- The 5-foot movement occurs after the hit resolves, uses no action, must end in a legal space, and does not provoke. The push is directly away and creates no collision damage. The +1 AC applies only against the hit target and does not stack with itself.

#### CL10 - Precision Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 2 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Choose a target area before the saving throw.

- **Arm:** On a failed save, Disadvantage on the target's next weapon attack before the start of your next turn.
- **Leg:** On a failed save, reduce its Speed by 10 feet until the start of your next turn.
- **Breath:** On a failed save, it cannot take Reactions until the start of your next turn.
- **Balance:** On a failed save, it has Disadvantage on its next Strength or Dexterity saving throw before the start of your next turn.

On a successful save, the target cannot take Reactions until the start of its next turn regardless of the selected area.

##### Normalized Procedure — Precision Strike
- Choose Arm, Leg, Breath, or Balance after the triggering hit but before the save. The labels identify a temporary combat impairment; they do not create an injury, severance, disabled organ, Hidden Injury, or permanent anatomical change.
- A creature does not become ineligible merely because its body plan lacks a human arm, leg, lungs, or ordinary balance organ. Apply the selected printed mechanical effect through the closest equivalent bodily function unless the creature has an explicit Source Rule making it immune to that exact form of physical interference.
- **Arm** affects only the next weapon attack and is expended whether that attack hits or misses. **Leg** is a fixed 10-foot Speed reduction and cannot reduce a Speed below 0. **Breath** prevents Reactions. **Balance** affects only the next Strength or Dexterity saving throw.
- On a successful save, the Reaction denial replaces the failed-save result; it does not add the selected failed-save result.
- Multiple Precision Strikes from you do not stack the same named effect. Reapplication refreshes its duration or next-roll expenditure.

#### CL14 - Mushin

While conscious:

- You cannot be Surprised.
- Gain Advantage on Initiative.
- Gain Advantage on your first attack roll during the first round of a scene.
- Gain Advantage on saving throws against effects that directly predict, compel, or overwrite your immediate bodily movement.

When Initiative is rolled at the start of a new scene, regain 2 Stamina. This restoration occurs once per scene and cannot raise you above your maximum.

##### Normalized Procedure — Mushin
- Use the campaign's canonical Surprise procedure. “Cannot be Surprised” prevents the Surprised state; it does not reveal hidden creatures or prevent an ambush from beginning a scene.
- Initiative Advantage and first-round attack Advantage are separate. The first-round benefit applies to your first attack roll of that round, regardless of action type, and is expended on the roll.
- The movement-defense Advantage applies only to a save whose direct purpose is to predict, compel, script, possess, or overwrite your immediate bodily movement. It does not apply merely because an area effect or ordinary forced movement would move you.
- Regain 2 Stamina when Initiative is first rolled for a new scene. Re-rolling Initiative, joining an ongoing scene, a summoned creature rolling separately, or splitting the same conflict into phases does not restore it again.
- The restoration is not a rest and cannot exceed maximum Stamina.

#### CL18 - Isshun Sengeki

**Action**  
**Cost:** 8 Stamina  
**Limit:** Once per scene

Make one unarmed strike.

On a hit:

- Deal an additional `10d10` Force damage.
- Ignore ordinary Resistance to Force.
- Ignore one temporary damage-reduction effect whose Source CL is no higher than yours.
- Deal double damage to unattended objects, temporary barriers, vehicles, structures, terrain sections, and Formation Anchors.
- A reaction whose Source CL is lower than yours cannot redirect the strike.

The target then makes a Constitution saving throw.

On a failed save, choose one:

- Push it 20 feet and knock it Prone.
- Prevent it from taking Reactions until the end of your next turn.
- Reduce its Speed to 0 until the start of its next turn.
- Give it Disadvantage on its next saving throw before the end of your next turn.

On a successful save, it cannot take Reactions until the start of its next turn.

Isshun Sengeki does not ignore Immunity or a permanent artifact defense.

---

##### Normalized Procedure — Isshun Sengeki
- The Action makes exactly one unarmed strike. Pay the Stamina and expend the scene use when the Action is declared; a miss still spends both.
- On a hit, the `10d10` is additional attack damage and follows normal critical-hit rules unless another rule changes them. Choose and resolve the Constitution save after all hit damage is determined.
- “Ordinary Resistance to Force” means non-absolute Resistance from a creature statistic, temporary effect, armor, item, or technique. Immunity, a permanent artifact defense, and a rule explicitly immune to physical or Force authority remain.
- When the damage packet is resolved, choose one temporary damage-reduction effect applying to that packet whose Source CL is no higher than yours. It is ignored for this strike. Its action, Reaction, resource, or limited-use cost remains spent unless its rule says otherwise.
- A lower-Source-CL Reaction cannot redirect the strike. It can still perform a different legal function, such as reducing damage, if not otherwise ignored. Equal- or higher-Source-CL redirection resolves normally.
- Double damage to listed unattended targets applies once. A target belonging to several listed categories is not doubled repeatedly.
- The failed-save options are temporary combat impairments, not injuries. The push uses forced-movement rules. The successful-save Reaction denial is the only save result on success.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Karate

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 10. Yamabushi

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The mountain accepted my weakness and gave me stone in return.*

Yamabushi cultivate the ascetic body through pilgrimage, cold water, mountain pressure, privation, and unwavering endurance.

**Access Category:** Open School  
**Primary Identity:** Ascetic endurance, environmental mastery, mountain-body refinement  
**Common Sphere Synergies:** Cold, Earth, Guardian, Water, Yang

#### CL3 - Stone Skin

While benefiting from Unarmored Defense:

- Gain +1 AC.
- Gain Resistance to Cold damage.
- You can hold your breath for 1 hour.
- Gain Advantage on Constitution saving throws caused by extreme cold, high altitude, forced marches, harsh weather, environmental pressure, and mundane exposure.

##### Normalized Procedure — Stone Skin
- The +1 AC applies only while your chosen AC calculation is Unarmored Defense. It is an AC bonus and does not combine multiple instances of Stone Skin.
- Cold Resistance applies to Cold damage from any source unless that source expressly bypasses Resistance. Environmental cold Immunity gained later at CL14 supersedes but does not stack with it.
- The one-hour breath duration is a fixed replacement for ordinary breath-holding. Other features can replace it only if they provide a longer duration or expressly stack.
- The environmental-save Advantage applies to Constitution saves directly caused by the listed mundane or supernatural environmental pressures. It does not apply to an attack or technique merely flavored as weather unless the effect is adjudicated as environmental exposure.

#### CL6 - Waterfall Stance

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 2 Stamina

For the duration:

- Ignore nonmagical difficult terrain.
- Gain Advantage on saving throws against forced movement, Prone, Frightened, and Exhaustion caused by physical exertion.
- Reduce falling damage by `5 x your CL`.
- Rain, waterfalls, and heavy wind do not interfere with your vision, hearing, or movement.

The stance ends if you become Unconscious.

##### Normalized Procedure — Waterfall Stance
- Record activation time and Source CL. The stance ends immediately if you become Unconscious; losing contact with water or a mountain does not end it.
- “Nonmagical difficult terrain” includes ordinary rubble, mud, snow, undergrowth, stairs, and damaged ground. It does not ignore a cultivation Field, Formation, supernatural terrain, or a creature's occupied space unless that source is expressly nonmagical.
- Advantage against forced movement, Prone, Frightened, and exertion-caused Exhaustion applies to the check or save used to resist or end the listed result. It does not grant a new save where the source permits none.
- Reduce one falling-damage packet by `5 × your effective Body Refining CL` after Resistance and Vulnerability but before Hit Points are reduced. This can reduce the packet to 0. It does not by itself prevent landing Prone unless the normal falling rule or another feature says 0 damage prevents it.
- Rain, waterfalls, and heavy wind cease to impose environmental interference on your vision, hearing, and movement. A specific higher-authority blindness, deafness, silence, current, or wind technique remains governed by its own Source Rule.

#### CL10 - Mountain's Wrath

**Action**  
**Area:** 20-foot-radius sphere centered on you  
**Cost:** 4 Stamina  
**Saving Throw:** Dexterity

On a failed save, a creature takes `6d6` Bludgeoning or Force damage and falls Prone. On a successful save, it takes half damage and remains standing.

Unattended objects, structures, temporary barriers, and terrain take double damage. The ground becomes difficult terrain until cleared or repaired.

##### Normalized Procedure — Mountain's Wrath
- The sphere is centered on you and affects each other creature in the area once. You are not a target. Allies are affected unless another feature protects them.
- Choose Bludgeoning or Force when you activate the feature; all damage from that activation uses the chosen type.
- The effect requires line of effect through the ground or surrounding physical medium. It does not pass a complete barrier that blocks the shock unless that barrier is itself destroyed by the same activation and its rule permits simultaneous passage.
- Listed unattended objects and terrain take double damage once. Worn, carried, wielded, piloted, or actively controlled objects are not unattended.
- Ordinary ground in the area becomes difficult terrain. It remains until each affected 5-foot square is cleared by 1 minute of ordinary work with suitable tools, repaired by an appropriate cultivation or crafting procedure, or replaced by terrain authority of equal or higher Source CL.
- The terrain alteration is bounded to the 20-foot-radius area and does not create world-scale geological damage beyond the printed damage to discrete targets.

#### CL14 - Ascetic Body

You gain:

- Immunity to mundane disease.
- Immunity to environmental cold.
- No requirement for ordinary food or drink.
- The ability to complete a long rest through 4 hours of meditation while remaining aware of your surroundings.
- Advantage on saving throws against Exhaustion, possession, and forced bodily transformation.

##### Still as the Peak

At the start of your turn, if you are touching earth, stone, or worked masonry and have not willingly moved since the end of your previous turn, reduce the Stamina cost of the next Body Refining Path or Subpath feature you activate before the end of the turn by 1, to a minimum of 1. This functions once per round.

##### Normalized Procedure — Ascetic Body
- Mundane disease and environmental cold are distinct from supernatural disease, Cold damage, a curse, a Tribulation, or a cultivation affliction unless its Source Rule classifies it as mundane or environmental.
- Not requiring ordinary food or drink removes normal nutritional upkeep. It does not waive a spirit appetite, Method requirement, Offering, medicine, rare-material cost, or Source Rule that consumes a specific substance.
- The 4-hour meditation completes a Long Rest only if all other Long Rest requirements are met. You remain aware but are still resting and cannot perform strenuous activity, guard through active combat, train, craft, or maintain an incompatible Concentration effect during the meditation.
- Advantage against possession and forced bodily transformation applies to saves and contests resisting entry, control, or alteration. It does not remove an effect already established unless that effect permits a repeated save.
- **Still as the Peak.** Determine eligibility at the start of your turn. Forced movement since the end of your previous turn does not break the requirement; any voluntary movement does. Touching earth, stone, or worked masonry with any part of your body qualifies. Apply the reduction to the first eligible Body Refining Path or Subpath activation before the end of that turn, then expend the once-per-round benefit even if the feature has multiple costs.

#### CL18 - Avatar of the Mountain

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

For the duration:

- Gain Resistance to all damage except Force, Psychic, and Void.
- Gain Tremorsense 30 feet while touching a solid surface.
- Ignore difficult terrain.
- Gain Advantage on Strength and Constitution saving throws.
- Your Speed is reduced by 10 feet.
- An effect whose Source CL is lower than yours cannot push, pull, knock you Prone, or teleport you unwillingly.
- Once per turn when you hit with an unarmed strike or integrated Staff weapon, deal an additional `2d8` Bludgeoning or Force damage.

An equal- or higher-CL effect contests your Cultivation Check when attempting to move or teleport you.

---

## Restricted Scriptures

##### Normalized Procedure — Avatar of the Mountain
- The Resistance applies to all damage types except Force, Psychic, and Void. Immunity, Vulnerability, and bypass rules resolve normally.
- Tremorsense functions only while you are touching a continuous solid surface connected to the sensed subject. It does not perceive through open air, a complete spatial break, or an effect that blocks tremorsense.
- The 10-foot Speed reduction applies to each of your Speeds, to a minimum of 0, unless a Speed's Source Rule says it cannot be reduced. It does not reduce forced movement distances.
- A lower-Source-CL effect fails to push, pull, knock you Prone, or teleport you unwillingly; its costs remain spent. For an equal- or higher-Source-CL attempt, both sides make a Cultivation Check. The higher result succeeds; a tie leaves you in place and standing.
- The once-per-turn `2d8` applies to one hit with an unarmed strike or a Staff weapon integrated by a legal Source Rule. Choose Bludgeoning or Force for that additional damage when it is dealt.
- The transformation ends if you become Unconscious under the universal transformation rule unless another feature expressly preserves it.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Yamabushi

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 11. Bone Monarch

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Flesh bends. Blood spills. Bone remembers the throne.*

Bone Monarch cultivators rule their skeletal structure, marrow, and manifested bone as extensions of bodily sovereignty.

**Access Category:** Restricted Scripture  
**Primary Identity:** Bone armor, marrow regeneration, reconstruction, bone manifestations  
**Common Sphere Synergies:** Bones, Death, Flesh, Guardian, Puppetry

#### CL3 - Bone Armor

**Reaction**  
**Trigger:** An attack deals damage to you.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Reduce the triggering damage by `2d8 + Constitution modifier` if it includes Bludgeoning, Piercing, or Slashing damage, or `1d8 + Constitution modifier` otherwise.

Bone Armor and Stamina Guard both require your Reaction. You cannot use both against the same damage packet unless another feature grants and permits a second Reaction.

##### Normalized Procedure — Bone Armor
- Declare Bone Armor after the attack's damage packet is determined but before that packet reduces your Hit Points. The triggering attack must have hit and be dealing damage.
- If the packet includes any Bludgeoning, Piercing, or Slashing damage, use `2d8 + Constitution modifier` against the entire triggering packet. Otherwise use `1d8 + Constitution modifier`. Mixed packets are not split for this choice.
- Apply the result as an other flat reduction in the shared damage order. It cannot reduce damage below 0.
- Bone Armor and Stamina Guard each require a Reaction. A separate additional Reaction is not enough by itself; another Source Rule must also explicitly permit both to modify the same damage packet.
- Flavorful bone cracking does not create an Injury. Any actual bone Injury follows the shared bodily-harm hierarchy.

#### CL6 - Marrow Regeneration

**Bonus Action**  
**Cost:** 2 Stamina  
**Limit:** Once per turn

Regain `2d10 + Constitution modifier` Hit Points, increasing to `3d10 + Constitution modifier` at CL14.

After healing, choose one:

- End one Bleeding state affecting you whose Source CL is no higher than yours.
- End one temporary Speed reduction caused by a physical injury whose Source CL is no higher than yours.
- Repeat a saving throw against Poisoned with Advantage.
- Repeat a saving throw against Paralyzed or Restrained when caused by a broken bone, crushed limb, physical binding, or bodily deformation.

Marrow Regeneration cannot restore a destroyed Foundation, remove a Hidden Injury, or repair soul or identity damage.

##### Normalized Procedure — Marrow Regeneration
- The healing and selected secondary benefit occur as one Bonus Action activation. Resolve healing first, then choose one legal option.
- The healing applies to you only, is ordinary Hit Point healing, and does not reconstruct missing anatomy unless the shared reconstruction rules and another Source Rule permit it.
- Ending Bleeding or a temporary Speed reduction requires the listed state to have Source CL no higher than yours. A higher-Source-CL state is unaffected and the option is spent if selected.
- “Repeat a saving throw” grants one immediate repeat against the original DC and using the original ability. It applies only if the condition has or had a saving throw. On success, resolve the original effect's successful-repeat result; do not invent a new removal rule.
- The physical Paralyzed or Restrained option requires the condition's record to identify broken bone, crushed limb, physical binding, or bodily deformation as its cause. It does not apply to psychic, spiritual, spatial, oath, or conceptual restraint merely described with physical imagery.
- The CL14 increase replaces `2d10` with `3d10`; it does not add both expressions.

#### CL10 - Bone Guard Manifestation

**Action**  
**Range:** An unoccupied space within 30 feet  
**Duration:** 1 minute  
**Cost:** 5 Stamina

Manifest one Bone Guard. You may maintain only one at a time.

##### Bone Guard Statistics

- **Size:** Medium
- **AC:** `14 + Proficiency Bonus`
- **Hit Points:** `5 x your CL`
- **Speed:** 30 feet
- **Saving Throws:** Uses your saving-throw modifiers
- **Immunities:** Poison damage, Poisoned
- **Cultivation Level:** Your CL

##### Bone Strike

**Melee Cultivation Attack:** Uses your Cultivation Attack Modifier; reach 5 feet; hit `2d8 + Constitution modifier` Piercing or Bludgeoning damage.

##### Guard the Sovereign

**Reaction:** When you or an ally within 5 feet of the Bone Guard is targeted by an attack, impose Disadvantage on that attack roll.

The Bone Guard acts immediately after your turn. As a Bonus Action, command it to Attack, Dash, Disengage, Dodge, Help, Move, or Guard one creature or doorway. Without a command, it takes Dodge and remains within 30 feet of you if possible.

It disappears at 0 Hit Points, when the duration ends, or when you create another.

##### Normalized Procedure — Bone Guard Manifestation
- The Bone Guard is a manifested Body Asset, not a Complete Soul, Companion, independent character, corpse, or harvestable supply of permanent bone. Creating another causes the existing Guard to disappear.
- It occupies a Medium space. It has no ability scores or proficiencies beyond what its printed statistics require. “Uses your saving-throw modifiers” means use the numerical modifier shown on your character record for the called save; it gains no separate save proficiency.
- The Guard can move normally during its turn. When you command **Attack**, it may move and make one Bone Strike. **Dash, Disengage, Dodge,** and **Help** use the corresponding action and allow ordinary movement. **Move** lets it move up to its Speed and take no action. **Guard** lets it move and prepare Guard the Sovereign.
- Issuing the command costs your Bonus Action. The source prints no command distance, so no additional distance limit is imposed while you and the Guard are on the same plane and no effect blocks your direct cultivation control.
- Without a command, it takes Dodge and, if possible, uses movement to remain within 30 feet of you. It does not independently choose attacks or tactics.
- Guard the Sovereign is the Bone Guard's Reaction, usable once per round. Declare after a legal protected creature is targeted but before the attack roll. The Guard must be within 5 feet of that creature at that moment.
- Bone Strike is a cultivation attack made by the Guard using your Cultivation Attack Modifier. The Guard is the attack's origin, but you remain the controlling Source Rule for Source CL and feature attribution. It cannot deliver your personal hit riders unless a feature expressly permits it.
- Ordinary creature healing does not restore the Guard unless the healing rule can target a Body Asset. At 0 Hit Points it disappears with no transferable remains, materials, or injury to you.

#### CL14 - Unbroken Bones

You gain:

- Critical hits against you become normal hits.
- Advantage on saving throws against Prone, forced movement, physical paralysis, forced bodily transformation, and effects that break, deform, or liquefy the body.
- Your bones cannot be permanently broken by an effect whose Source CL is lower than yours.

##### Marrow Memory

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 4 Stamina  
**Limit:** Once per scene

You are reduced to 1 Hit Point instead.

Only one feature that prevents or replaces the same reduction to 0 Hit Points may resolve.

##### Normalized Procedure — Unbroken Bones
- A critical hit against you becomes a normal hit before damage dice and critical-only riders are resolved. It remains a hit and retains noncritical riders.
- The listed Advantage applies only to checks or saves resisting those physical effects. It does not grant a new save where none is permitted.
- A lower-Source-CL effect cannot create a permanent broken-bone Injury. It may still deal damage or impose its printed temporary condition or Injury for its printed duration.
- **Marrow Memory timing.** Declare when a resolved damage packet or effect would reduce you to 0 Hit Points but not kill you outright. Spend 4 Stamina and remain at 1 Hit Point. The feature does not remove conditions, restore anatomy, or negate non-damage riders.
- Marrow Memory competes with every other feature replacing the same reduction to 0 Hit Points. Choose one; all unchosen replacements remain unspent unless their rules say declaration already spent them.

#### CL18 - Sovereign Reconstruction

**Trigger:** You are reduced to 0 Hit Points but are not killed outright.  
**Cost:** 8 Stamina  
**Limit:** Once per scene  
**Action:** None

Instead of falling Unconscious normally, your body collapses into a bone cocoon until the start of your next turn.

While inside:

- You are Incapacitated.
- Your Speed is 0.
- You cannot take actions or Reactions.
- Your body cannot be targeted separately from the cocoon.
- You do not make death saving throws.

##### Bone Cocoon

- **AC:** Your Cultivation Save DC
- **Hit Points:** `5 x your CL`
- **Resistance:** Bludgeoning, Piercing, Slashing
- **Immunity:** Poison and Psychic
- **Source CL:** Your CL

At the start of your next turn, if the cocoon has at least 1 Hit Point:

- Regain Hit Points equal to half your maximum.
- Stand without spending movement.
- End Prone, Grappled, Restrained, and one Bleeding or temporary physical-injury state on yourself.
- Each hostile creature of your choice within 10 feet makes a Dexterity saving throw, taking `6d6` Piercing damage and falling Prone on a failure, or half damage and remaining standing on a success.

If the cocoon reaches 0 Hit Points, reconstruction fails. You remain at 0 Hit Points and begin making death saving throws at the start of your next turn.

---

##### Normalized Procedure — Sovereign Reconstruction
- Declare when you would be reduced to 0 Hit Points but not killed outright, before Unconsciousness or death saves. This is a 0-Hit-Point replacement and cannot resolve together with Marrow Memory or another replacement of the same event.
- The Bone Cocoon is a Body Asset occupying your current space and matching your size. Your body is contained within it and cannot be targeted separately; an area affecting that space targets the Cocoon normally.
- Damage to the Cocoon does not transfer to you. You retain existing conditions unless the feature ends them on emergence. You make no death saves while the Cocoon has at least 1 Hit Point.
- The Cocoon has no actions, movement, or Reactions. It can be moved, restrained, contained, repaired, or suppressed only when a rule can legally affect a Body Asset. Its printed Resistance and Immunities apply normally.
- At the start of your next turn, check the Cocoon before resolving ordinary start-of-turn effects from your body. If it has at least 1 Hit Point, perform every printed reconstruction step, destroy the Cocoon, and take the turn normally.
- If the Cocoon reaches 0 Hit Points before then, it breaks immediately. You remain at 0 Hit Points in its space, do not receive the reconstruction benefits, and begin normal death-saving-throw timing at the start of your next turn. Excess Cocoon damage does not transfer, but an effect that kills or destroys the contained body explicitly can still do so.
- The emergence burst affects only hostile creatures you choose within 10 feet. Each is affected once. It creates no permanent bone Injury or terrain without another rule.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Bone Monarch

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 12. Kensei

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The blade entered my hand and found it was already home.*

Kensei cultivate sword intent through muscle, bone, footwork, and meridian alignment until body and blade become one cutting principle.

**Access Category:** Restricted Scripture  
**Primary Identity:** Sword intent engraved into flesh and bone  
**Common Sphere Synergies:** Fencing, Force, Light, Metal, Sword

#### CL3 - Blade Fist

Your unarmed strikes may deal Slashing damage and gain the Finesse property. You may use Dexterity instead of Strength or Constitution for Iron Fist attack and damage rolls.

While wielding a Blade weapon:

- Use Dexterity or Constitution for its attack and damage rolls.
- If using Constitution, use your Cultivation Attack Modifier.
- It is integrated into your Body Refining cultivation.
- Refined Iron Fist and Heavenly Fist apply to it.

Once per turn when you hit with an unarmed strike or integrated Blade weapon, choose one:

- Deal additional Slashing damage equal to your Proficiency Bonus.
- Reduce the target's Speed by 5 feet until the start of your next turn.
- Prevent it from taking Reactions until the start of its next turn.
- Draw or stow one Blade weapon.

##### Normalized Procedure — Blade Fist
- A Blade is a dagger, sword, saber, cutting-edged axe, or weapon carrying the Blade tag. Record each integrated Blade weapon.
- Granting Finesse to your unarmed strikes permits Strength or Dexterity under the weapon-property rule; this feature additionally permits Constitution through Iron Fist. Choose one ability for each attack and add it once.
- While wielding an integrated Blade, choose Dexterity or Constitution for each attack. Choosing Constitution uses the Cultivation Attack Modifier. The weapon retains its normal item statistics and tags.
- Refined Iron Fist and Heavenly Fist apply their cultivation-powered and high-authority weapon benefits to the integrated Blade; they do not add a second Iron Fist damage die.
- The once-per-turn rider is chosen after a hit. The additional Proficiency Bonus damage is one packet of Slashing damage. The Speed reduction does not stack with itself. Reaction denial lasts as printed. Drawing or stowing one Blade is part of the hit rider and does not create another object interaction.
- An unarmed strike dealing Slashing damage remains an unarmed strike and natural bodily attack; it does not become a held Blade weapon for a feature requiring one.

#### CL6 - Sword Draws Before Thought

When Initiative is rolled at the start of a scene and you are not Surprised, choose one:

- Move up to half your Speed without provoking Opportunity Attacks.
- Draw or manifest a Blade weapon and make one unarmed or integrated Blade attack against a creature within reach.
- Gain +2 AC until the start of your first turn.
- Gain Advantage on your first attack roll during the first round.

This feature functions once per scene. The granted attack follows the Granted Attack rule.

##### Normalized Procedure — Sword Draws Before Thought
- Resolve when Initiative is first rolled for a new scene. If you are Surprised at that instant, the feature does not activate later in the same scene.
- Choose exactly one option. The movement is granted movement, requires a legal route, and does not provoke. It occurs before the first creature's turn.
- To draw a Blade, it must be carried or otherwise legally accessible. To manifest one, choose an integrated Blade recorded to you; the same weapon or bodily expression appears in your free hand and is not duplicated. If it was elsewhere, it is unavailable there until the manifestation ends or you release it under its Source Rule.
- The granted attack occurs immediately after drawing or manifesting, requires a legal target within reach at that moment, and follows the Granted Attack rule. If no target is legal, no attack is made and you do not choose another option.
- The +2 AC ends at the start of your first turn. The attack-roll Advantage applies to your first attack roll in the first round and is expended whether it hits or misses.
- Re-rolling Initiative or entering an ongoing scene does not reactivate the feature.

#### CL10 - Flowing Blade Stance

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 4 Stamina

For the duration:

- Gain +1 AC.
- Your unarmed strikes and integrated Blade attacks may deal Force or Slashing damage.
- Once per turn after hitting, move 5 feet without provoking Opportunity Attacks.
- When a creature within your reach misses you with a melee attack, use your Reaction to make one unarmed or integrated Blade attack against it.

The reaction attack follows the Granted Attack rule.

##### Normalized Procedure — Flowing Blade Stance
- The +1 AC is a bonus, requires no particular weapon, and does not stack with another instance of this stance.
- Choosing Force or Slashing is made separately for each eligible attack. This changes that attack's damage type; it does not add damage.
- The once-per-turn 5-foot movement occurs after the hit is fully resolved, requires no action, must end legally, and does not provoke.
- The Reaction attack is declared after a melee attack within your reach misses you. You must still have the attacker within your current reach and be capable of making the chosen unarmed or integrated Blade attack. It is one granted attack and cannot grant another.
- The stance ends under the universal transformation/state rules only as printed; being Disarmed does not end it, though Blade-specific attacks require an available Blade.

#### CL14 - Severing Palm

**Trigger:** You hit with an unarmed strike or integrated Blade attack.  
**Cost:** 4 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Choose one severing effect:

- **Arm:** On a failed save, Disadvantage on all weapon attacks until the end of your next turn.
- **Leg:** On a failed save, Speed is halved until the end of your next turn.
- **Breath:** On a failed save, no Reactions until the end of your next turn.
- **Flow:** On a failed save, Disadvantage on Concentration saving throws and Cultivation Checks made to maintain techniques until the end of your next turn.
- **Guard:** On a failed save, AC is reduced by 2 until the start of your next turn.

On a successful save, the chosen effect lasts until the start of your next turn. Guard instead reduces AC by 1.

A target cannot suffer multiple instances of the same Severing Palm effect. Reapplication refreshes its duration.

##### Normalized Procedure — Severing Palm
- The term “severing” describes temporary disruption of bodily combat lines. This feature does not sever anatomy, create an Injury, damage a Foundation, or permanently block a meridian.
- Choose Arm, Leg, Breath, Flow, or Guard after the triggering hit but before the save. Apply the printed result even to a nonhumanoid body through the nearest equivalent function unless an explicit Source Rule grants immunity to that exact impairment.
- Distinct named effects can coexist. The same named effect from you does not stack; reapplication refreshes its duration and uses the new save result.
- **Arm** affects all weapon attacks for the failed-save duration. **Leg** halves each applicable Speed after fixed bonuses and before a minimum of 0. **Breath** prevents Reactions. **Flow** affects only Concentration saves and Cultivation Checks made to maintain existing techniques. **Guard** modifies final AC as a penalty and cannot reduce AC below 0.
- On a successful save, the chosen effect still lasts until the start of your next turn, with Guard reduced to -1 AC as printed.
- Ending or repairing an actual bodily Injury does not remove Severing Palm early unless a Source Rule expressly ends temporary technique impairments.

#### CL18 - Sword Saint Incarnation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Gain a Fly Speed of 40 feet and Hover.
- Gain +2 AC.
- Your unarmed strikes and integrated Blade attacks may deal Force or Slashing damage.
- Your critical-hit range becomes 19-20.
- Once per turn when you hit, deal an additional `3d8` Force or Slashing damage.
- Your melee reach increases by 5 feet.
- Move through hostile creature spaces as difficult terrain.
- Opportunity Attacks against you have Disadvantage.

The first time during a turn that a hostile creature enters your reach or starts its turn there, it makes a Dexterity saving throw.

- **Failed Save:** It takes `3d8` Force or Slashing damage and either cannot take Reactions or has its Speed reduced by 10 feet until the start of its next turn.
- **Successful Save:** It takes half damage and its Speed is reduced by 5 feet until the start of its next turn.

---

##### Normalized Procedure — Sword Saint Incarnation
- This is a temporary Body transformation. Record activation, current integrated Blade, Source CL, Fly Speed, reach, and selected damage types. It ends if you become Unconscious unless another rule preserves it.
- Hover prevents falling when your Fly Speed becomes 0, but a feature that removes flight or suppresses the transformation uses normal falling and Failed Spatial Movement rules.
- The critical range of 19–20 applies only to attack rolls made by you with unarmed strikes or integrated Blade attacks unless another rule expressly broadens it. It does not stack with another expanded critical range; use the broadest range.
- The `3d8` additional damage applies once per turn to one eligible hit. Choose Force or Slashing when dealt.
- Moving through a hostile creature's space treats each such space as difficult terrain. You cannot end movement there and gain no protection from that creature's reactions beyond the printed Disadvantage.
- Each hostile creature can trigger the reach save once per turn: the first time it enters your reach during that turn, or when it starts its turn there if it has not already triggered during that turn. Expanding your reach around a stationary creature does not count as entering.
- The reach effect is not an attack and cannot trigger hit riders. On a failed save choose Reaction denial or the 10-foot Speed reduction. On success apply half damage and the 5-foot reduction. Reapplication refreshes, not stacks, a Speed reduction from this feature.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Kensei

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 13. Shinobi

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The shadow is not hiding me. It is wearing me.*

Shinobi cultivate stealth through muscle control, silent circulation, pressure-point violence, afterimages, and momentary killing angles.

**Access Category:** Restricted Scripture  
**Primary Identity:** Shadow-flesh conditioning, infiltration, pressure points, afterimages  
**Common Sphere Synergies:** Mist, Poison, Scoundrel, Shadow, Thread

#### CL3 - Silent Step

Gain proficiency in Stealth. If already proficient, gain a +2 bonus to Stealth checks.

While in Dim Light, Darkness, mist, smoke, or an area that is Lightly or Heavily Obscured:

- Ignore nonmagical difficult terrain.
- Gain Advantage on checks to Hide.
- Gain a Climb Speed equal to your walking Speed while at least one hand is free.
- A creature cannot make an Opportunity Attack against you while you are Invisible to it or Heavily Obscured from it.

Dim Light alone does not prevent Opportunity Attacks from a creature that can see you normally.

##### Normalized Procedure — Silent Step
- If you already have Stealth proficiency, the +2 is a fixed miscellaneous bonus. It is gained once from this feature and does not multiply with repeated proficiency grants.
- Determine Dim Light, Darkness, mist, smoke, and obscuration from the current scene. Dim Light grants the listed terrain and Hide benefits but does not by itself block sight or Opportunity Attacks from a creature that sees normally in it.
- The Climb Speed requires at least one functioning free hand for the entire climb. If that hand becomes occupied or disabled, finish the current movement in the nearest legal supported space or begin falling as normal.
- Opportunity Attack protection is evaluated separately for each observing creature at the instant you leave its reach. You are protected only if Invisible to that creature or Heavily Obscured from it.
- Ignoring nonmagical difficult terrain does not permit movement through solid objects, occupied hostile spaces, supernatural Fields, or cultivation-created terrain unless those are independently legal.

#### CL6 - Pressure-Point Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Constitution

On a failed save, choose one:

- No Reactions until the start of its next turn.
- Speed reduced by 10 feet until the start of its next turn.
- Disadvantage on its next attack roll before the start of its next turn.
- Disadvantage on its next Concentration saving throw before the start of its next turn.
- It cannot speak above a whisper until the start of its next turn.

On a successful save, it cannot take Reactions until the start of its next turn.

##### Normalized Procedure — Pressure-Point Strike
- Choose the failed-save effect after the target fails unless the table requires declarations before saves; record the choice and duration. These are temporary physical disruptions, not Injuries or permanent meridian damage.
- The effect can apply to nonhumanoid anatomy through an equivalent vulnerable function unless an explicit immunity blocks that exact impairment.
- A target unable to speak above a whisper can communicate quietly, but cannot produce a command, shout, projected voice, audible activation, or verbal component that explicitly requires clear speech beyond its space. A rule that functions with whispers remains usable.
- Each named effect from you does not stack with itself. Reapplication refreshes the duration or next-roll expenditure.
- On a successful save, only Reaction denial applies. The free use from Assassination still observes Pressure-Point Strike's once-per-turn limit.

#### CL10 - Shadow Afterimage

**Bonus Action**  
**Range:** An unoccupied space within 15 feet  
**Duration:** 1 minute  
**Cost:** 4 Stamina

Create one Shadow Afterimage. You may maintain only one at a time.

##### Afterimage Statistics

- **AC:** `13 + Proficiency Bonus`
- **Hit Points:** 1
- **Speed:** 30 feet
- **Immunities:** Poison and Psychic
- **Size:** Your size
- **Source CL:** Your CL

The Afterimage cannot attack, deal damage, activate items, or use cultivation features. It acts immediately after your turn and follows your mental commands. It can Move, Dash, Disengage, Dodge, Hide, Help, gesture, produce faint sounds, or manipulate an unattended object weighing no more than 5 pounds.

You may see and hear through it while within 300 feet.

##### Shadow Exchange

**Bonus Action**  
**Range:** 60 feet  
**Cost:** 1 Stamina

Swap spaces with your Afterimage if both spaces are valid and no spatial lock separates them.

The Afterimage is destroyed at 0 Hit Points, when the duration ends, or when you create another.

##### Normalized Procedure — Shadow Afterimage
- The Afterimage is a projected Body Asset and visual-auditory decoy, not a creature, Complete Soul, Companion, independent person, or duplicate of your body. It occupies its space but has no physical mass except for the printed object manipulation.
- You choose one listed action for it when its turn begins without spending an action. It can move before or after that action. If you issue no command, it takes Dodge and remains where it is. The source prints no command range; no added distance limit applies while you are on the same plane and direct control is not blocked.
- **Help** follows the normal Help action and requires the Afterimage to be in a legal position to assist. It cannot grant help based on knowledge, strength, tools, or physical force it does not possess.
- Hide uses its own Stealth check with a modifier equal to your Stealth modifier, because no independent abilities are printed. It cannot become more physically real by Hiding.
- Seeing and hearing through it within 300 feet is simultaneous with your own senses unless a Source Rule says otherwise. It does not grant special senses, perfect memory, or line of effect from your body.
- Manipulating an unattended object is limited to 5 pounds, ordinary object interactions, and the Afterimage's space and reach. It cannot attack with, activate, consume, attune, steal a worn object, or use a cultivation item.
- Shadow Exchange is spatial movement. Both spaces must be legal for the arriving body or Afterimage, on the same plane, within 60 feet, and connected by a route not blocked by a spatial lock. Pay cost and action on a failed exchange and use Failed Spatial Movement.
- At 0 Hit Points the Afterimage is destroyed. Damage does not transfer to you. Creating another immediately ends the prior one, and no remains or materials persist.

#### CL14 - Assassination

**Trigger:** You hit a creature when it is Surprised, has not yet acted during the first round, you were Invisible to it, or you were Heavily Obscured from it.  
**Limit:** Once per turn

Deal additional damage equal to `2d8 + your CL`.

Then choose one:

- It cannot take Reactions until the start of its next turn.
- Move 10 feet without provoking Opportunity Attacks.
- Apply Pressure-Point Strike without spending Stamina.
- Gain Advantage on your next Stealth check before the end of your next turn.

##### Normalized Procedure — Assassination
- Check the trigger at the moment the attack hits. Satisfying more than one listed circumstance does not multiply the benefit.
- “Has not yet acted during the first round” means the target has not taken a turn, action, Bonus Action, or Reaction after Initiative was rolled for that scene. A creature that acted before its first turn no longer qualifies under that clause.
- Invisible or Heavily Obscured status is evaluated from the target's perception, not globally. A creature that perceives you normally does not qualify under those clauses.
- The additional `2d8 + CL` is one damage packet of the triggering attack's damage type unless that attack has multiple types, in which case choose one type dealt by it.
- The movement occurs after the hit, is granted movement, and does not provoke. The free Pressure-Point Strike spends no Stamina but still requires its save, uses its normal effect, and cannot exceed once per turn.
- Advantage on the next Stealth check is expended on that check and expires at the end of your next turn.

#### CL18 - Vanishing Flesh

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

For the duration:

- You are Invisible.
- Gain Advantage on Stealth checks.
- Gain a Climb Speed equal to your walking Speed.
- Move through hostile creature spaces as difficult terrain.
- Create a Shadow Afterimage when the feature activates without paying its cost.
- Shadow Afterimage does not expire while Vanishing Flesh remains active.

When you make an attack or activate a harmful feature, you become visible until the end of the current turn, then become Invisible again if the duration remains.

The first time you hit during each of your turns, deal an additional `3d6` damage of the attack's type.

A creature capable of perceiving Invisible creatures can target you normally.

---

##### Normalized Procedure — Vanishing Flesh
- This is a temporary Body transformation creating supernatural concealment. Invisibility does not make you hidden automatically; Stealth and detection resolve normally.
- Moving through hostile spaces treats them as difficult terrain. You cannot end movement in another creature's space and this permission does not bypass a physical barrier.
- The free Shadow Afterimage appears in a legal unoccupied space within 15 feet when the feature activates. It follows the normal Afterimage rules, can still be destroyed, and ends when Vanishing Flesh ends unless another valid duration would end it sooner.
- Making an attack or activating a harmful feature makes you visible immediately before its first attack roll, save, or harmful resolution and keeps you visible until the end of the current turn. All creatures can perceive that visible state normally. If the duration remains, Invisibility resumes at the end of the turn without an action.
- A harmless movement, defensive feature, Hide action, object interaction, or purely diagnostic effect does not reveal you unless its own rule says otherwise.
- The `3d6` additional damage applies to the first hit during each of your turns, not each attack type or target. Use the triggering attack's chosen damage type.
- A creature with a legal means to perceive Invisible creatures ignores only the Invisibility-based targeting restriction; other cover, concealment, Stealth, and defenses remain.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Shinobi

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 14. Gōruden

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Gold does not rust. Neither will I.*

Gōruden refiners cultivate radiant, incorruptible flesh and statue-like bodily authority.

**Access Category:** Restricted Scripture  
**Primary Identity:** Golden-body refinement, radiant durability, divine-statue transformation  
**Common Sphere Synergies:** Alchemy, Guardian, Metal, Radiance, Yang

#### CL3 - Golden Sheen

While benefiting from Unarmored Defense:

- Gain +1 AC.
- Gain Advantage on saving throws against disease, Poisoned, corrosion, bodily decay, and physical deformation.
- You may use Constitution instead of Charisma for Intimidation checks while your golden transformation is visible.

You may reveal or suppress the visible golden sheen without using an action.

##### Normalized Procedure — Golden Sheen
- The +1 AC applies only while using Unarmored Defense and is an AC bonus, not a second base calculation.
- Advantage applies to checks or saves directly resisting disease, Poisoned, corrosion, bodily decay, or physical deformation. It does not grant immunity or a new save where none exists.
- Using Constitution for Intimidation requires the golden transformation to be perceptible to the target. This changes only the ability modifier; proficiency and other modifiers remain.
- Revealing or suppressing the sheen requires no action and can be done whenever you could communicate or change a cosmetic stance. Suppressing visibility does not suppress the feature's mechanical defenses.

#### CL6 - Gilded Bones

When using Stamina Guard, choose one die type for all dice spent against that damage packet:

- Standard Guard: `1d10` per Stamina.
- Gilded Guard: `2d8` per Stamina.

Once per round, if damage remains after using Gilded Guard, gain Temporary Hit Points equal to your Proficiency Bonus after the damage resolves.

In addition:

- You take no falling damage from falls of 60 feet or less.
- Gain Advantage against effects that crush, fracture, or break your bones.

##### Normalized Procedure — Gilded Bones
- When activating Stamina Guard against one damage packet, choose Standard Guard or Gilded Guard before rolling any reduction dice. Every Stamina die spent for that activation uses the chosen expression.
- Gilded Guard replaces `1d10 per Stamina` with `2d8 per Stamina`; it does not roll both. All other Stamina Guard timing, maximum spend, Reaction cost, and damage ordering remain.
- After the complete triggering damage packet resolves, if at least 1 damage reduced your Hit Points and you have not gained these Temporary Hit Points this round, gain Temporary Hit Points equal to Proficiency Bonus. They do not reduce the triggering packet retroactively and follow ordinary nonstacking rules.
- Falls of 60 feet or less deal no falling damage. A fall longer than 60 feet uses the normal full falling-damage procedure; this feature does not subtract 60 feet from it.
- Bone-protection Advantage applies to checks and saves resisting crushing, fracturing, or bone-breaking. It does not prevent a higher-authority explicit Injury without a save.

#### CL10 - Radiant Fist

Your unarmed strikes may deal Radiant damage.

Once per turn when you hit with an unarmed strike, choose one:

- Deal additional Radiant damage equal to your Proficiency Bonus.
- Cause the target to shed Dim Light in a 10-foot radius until the start of your next turn.
- Prevent the target from benefiting from Invisible until the start of your next turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.

Against Undead, Fiends, creatures with the Daemonic tag, or active daemonic corruption, the additional Radiant damage becomes twice your Proficiency Bonus.

##### Normalized Procedure — Radiant Fist
- Choose the damage type of each unarmed strike when making it. Radiant replaces, rather than adds to, its ordinary damage type.
- Once per turn after an unarmed hit, choose exactly one rider. The additional damage is Radiant. The light is centered on the target and moves with it. Invisible denial suppresses the benefits of the Invisible condition but does not reveal a hidden target's exact location through total cover or another concealment. Temporary Hit Points follow ordinary nonstacking rules.
- If the target is Undead, Fiend, has the Daemonic tag, or bears an active daemonic corruption, only the additional Radiant-damage rider increases from Proficiency Bonus to twice Proficiency Bonus. The other three options are unchanged.
- A target meeting several qualifying categories receives the doubled value only once.

#### CL14 - Golden Aura

**Bonus Action**  
**Area:** 10-foot aura centered on you  
**Duration:** 1 minute  
**Cost:** 5 Stamina  
**Limit:** Once per scene

For the duration, you and allies of your choice in the aura gain Advantage on saving throws against Frightened, Resistance to Necrotic damage, and Temporary Hit Points equal to your Proficiency Bonus the first time they enter the aura or start a turn there during the activation.

A hostile creature that starts its turn in the aura makes a Wisdom saving throw.

- **Failed Save:** Choose Disadvantage on its next attack, inability to benefit from Invisible, or no Reactions until the start of its next turn.
- **Successful Save:** It cannot benefit from Invisible until the start of its next turn.

##### Normalized Procedure — Golden Aura
- The aura moves with you and extends 10 feet from your current space. You choose whether each ally is included whenever that ally would receive a benefit; no action is required.
- Each chosen ally gains the Temporary Hit Points only once per activation: the first time it enters the aura or starts a turn there. Leaving and re-entering does not grant them again during the same activation.
- Advantage against Frightened and Necrotic Resistance apply while the chosen ally is in the aura. They end immediately upon leaving, though already gained Temporary Hit Points remain.
- Each hostile creature that starts its turn in the aura makes one Wisdom save. Choose its failed-save result after it fails. The “next attack” Disadvantage is expended whether the attack hits or misses. Named effects from this aura refresh rather than stack.
- Invisible denial removes the condition's benefits for the printed duration. It does not automatically expose a creature behind cover or identify an illusion not based on Invisible.
- If the aura is suppressed, its duration and scene use continue; it grants no benefits while dormant.

#### CL18 - Immortal Gold

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 6 Stamina  
**Limit:** Once per scene  
**Action:** None

You are reduced to 1 Hit Point instead and become a golden statue until the start of your next turn.

While transformed:

- You are Incapacitated.
- Your Speed is 0.
- You cannot take actions or Reactions.
- Gain Resistance to all damage.
- Gain Immunity to Poison and Psychic damage.
- You remain aware of your surroundings.
- An effect whose Source CL is lower than yours cannot move you.

At the start of your next turn:

- Regain Hit Points equal to `5 x Proficiency Bonus`.
- End the statue transformation.
- Activate Golden Aura without paying its cost or expending its use.
- Take your turn normally.

An equal- or higher-CL effect may move the statue by winning an opposed Cultivation Check.

Only one feature that prevents or replaces the same reduction to 0 Hit Points may resolve.

---

## Rare Inheritances

##### Normalized Procedure — Immortal Gold
- Declare when you would be reduced to 0 Hit Points but not killed outright, before Unconsciousness and death-saving-throw procedures. Pay the cost and expend the scene use, then remain at 1 Hit Point and transform.
- The statue is your transformed body, not a separate object or Asset. Effects targeting you target the statue. Existing conditions remain unless incompatible with the form or ended by another rule.
- You can still take damage while transformed. Resistance and Immunities apply normally. If reduced to 0 Hit Points, use ordinary death and damage-at-0 procedures while remaining a statue; if not killed outright, the start-of-next-turn restoration can still heal you.
- A lower-Source-CL effect cannot move you. For an equal- or higher-Source-CL attempt, both sides make a Cultivation Check; the higher result moves you as the effect states, and a tie leaves you in place.
- At the start of your next turn, if you are alive, regain `5 × Proficiency Bonus` Hit Points even if you are currently at 0, end the transformation, and take the turn normally. This does not remove failed death saves, Injuries, or conditions unless ordinary healing does so.
- Activate Golden Aura as a new activation without Stamina and without expending its scene use. If an earlier Golden Aura is active, it ends and the new 1-minute activation begins; each creature's once-per-activation Temporary Hit Point eligibility resets for the new activation.
- If you are killed outright, your body is completely destroyed, or a legal effect prevents healing or bodily reconstruction before the start of your turn, the restoration fails and Golden Aura is not activated.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Asset, aura, manifestation, or effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, stance, Asset, aura, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, Asset operation, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature or Asset can occupy. If no legal destination exists, use Failed Spatial Movement; do not place it inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled limb, organ loss, bodily Asset, Foundation damage, or permanent transformation. Those results require explicit rules under Body Refining Shared Procedures.
- **No silent extra actions.** A state, transformation, Grapple, forced movement, integrated weapon, natural weapon, Asset, aura, or additional anatomy grants only the attacks, movement, actions, Reactions, and resource access printed by the feature.
- **No hidden balancing.** These procedures resolve ambiguities and dependencies. They do not reduce inherited costs, dice, ranges, durations, target counts, scene access, or conceptual authority.

### Integrated Procedure Closure — Gōruden

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 15. Ryūjin

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The dragon in my blood does not sleep. It coils.*

Ryūjin inherit scales, storm-force, breath, roar, and an ascending draconic body.

**Access Category:** Rare Inheritance  
**Primary Identity:** Dragon scales, lightning breath, storm movement, draconic transformation  
**Common Sphere Synergies:** Lightning, Sound, Transformation, Water, Weather, Yang

#### CL3 - Dragon Scales

While benefiting from Unarmored Defense, gain +1 AC and Resistance to Lightning damage.

Once per turn when you hit with an unarmed strike, deal additional Lightning damage equal to your Proficiency Bonus.

##### Normalized Procedure — Dragon Scales

- The +1 AC is an AC bonus that applies only while Unarmored Defense is the formula currently determining your AC. It does not apply while armor or a replacement AC formula is used.
- Lightning Resistance is a bodily inheritance and remains active while conscious or Unconscious unless an effect specifically suppresses this feature or your Body Refining cultivation.
- The once-per-turn Lightning damage is part of the triggering unarmed strike's damage packet. It applies after the hit is confirmed, cannot critically multiply separately, and cannot trigger another on-hit rider by itself.
- Scales may be visible or concealable as established by the character's recorded anatomy. Visibility has no additional mechanical consequence unless another rule expressly refers to it.

#### CL6 - Dragon's Breath

**Action**  
**Area:** 15-foot cone  
**Cost:** 2 Stamina  
**Saving Throw:** Dexterity

Choose Lightning or Thunder damage.

On a failed save, a creature takes `4d6` damage, increasing to `6d6` at CL11 and `8d6` at CL17. On a successful save, it takes half damage.

Unattended fragile objects automatically fail the save.

##### Normalized Procedure — Dragon's Breath

- Choose Lightning or Thunder when activating the feature. Every damage roll from that activation uses the chosen type.
- The cone originates from your mouth or another recorded breath organ and requires an unobstructed line of effect. It is a bodily projection exception with the printed 15-foot area and does not create a lingering cloud or Field.
- Each creature in the cone makes one save and takes damage once. A creature occupying more than one space in the cone is still affected only once.
- “Unattended fragile object” means a discrete, unworn, uncarried object that the GM has classified as readily breakable, such as ordinary glass, pottery, paper, thin wood, or comparable material. It automatically fails but retains Immunities and Damage Thresholds. Other objects are affected only when their own rules permit the breath to damage them.
- Cover and line of effect are checked from the breath's point of origin. The breath does not pass through total cover.

#### CL10 - Storm Step

**Bonus Action**  
**Range:** 30 feet  
**Cost:** 3 Stamina

Teleport to an unoccupied space you can see.

Each hostile creature of your choice within 5 feet of the destination makes a Dexterity saving throw. On a failure, it takes `2d6` Lightning or Thunder damage and cannot take Reactions until the start of its next turn. On a success, it takes half damage and retains its Reactions.

Storm Step cannot cross a spatial lock, sealed planar boundary, Formation explicitly blocking teleportation, or total planar separation.

##### Normalized Procedure — Storm Step

- Select the destination and damage type when activating the feature. The destination must be an unoccupied legal space you can see on the same plane and within 30 feet.
- Storm Step is teleportation. It does not trace a movement path, does not provoke Opportunity Attacks, and does not count as crossing intervening spaces.
- If a spatial lock, sealed planar boundary, qualifying Formation, total planar separation, or another explicit prohibition blocks the destination, use Failed Spatial Movement. The arrival burst does not occur when the teleport fails.
- After arriving, choose any number of hostile creatures within 5 feet of the destination. Each chosen creature saves once. A creature cannot be affected more than once by the same Storm Step even if it occupies multiple spaces.
- Reaction denial begins after the save resolves. The feature does not reveal hidden creatures; you can choose only hostile creatures you can identify as valid targets through your current senses or another legal targeting rule.

#### CL14 - Dragon's Roar

**Action**  
**Area:** 30-foot cone  
**Cost:** 5 Stamina  
**Limit:** Once per scene  
**Saving Throw:** Constitution

On a failed save, a creature takes `5d8` Thunder damage and is Stunned until the start of your next turn. On a successful save, it takes half damage and cannot take Reactions until the start of your next turn.

Unattended objects, temporary barriers, and Formation Anchors in the cone take double damage.

##### Normalized Procedure — Dragon's Roar

- The cone originates from your body and requires line of effect. Each creature in it makes one Constitution save.
- Stunned and Reaction denial begin after damage is resolved and last exactly as printed. A creature that succeeds is not Stunned.
- An eligible unattended object, temporary barrier, or Formation Anchor takes one damage instance and applies the printed doubling once, even if it belongs to more than one listed category.
- Worn, carried, wielded, piloted, or actively controlled objects are not unattended. Artifact objects and world-scale structures retain their own authority and are not automatically destroyed.
- The roar is a Sound- and body-origin effect. Silence or a rule that specifically blocks supernatural sound can contest or prevent it only to the extent printed by that rule; ordinary ambient noise does not.

#### CL18 - Ryūjin Ascendant Form

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Gain a Fly Speed of 60 feet and Hover.
- Gain Immunity to Lightning damage.
- Gain Resistance to Thunder damage.
- You may become Large.
- Your unarmed reach increases by 5 feet.
- Dragon's Breath becomes a 30-foot cone and deals `8d6`.
- Use Storm Step once per turn for 1 Stamina instead of 3.
- Once per turn when you hit with an unarmed strike, deal an additional `3d6` Lightning or Thunder damage.

A hostile creature that starts its turn within 10 feet makes a Constitution saving throw. On a failure, push it 5 feet and prevent it from taking Reactions until the start of its next turn.

---

##### Normalized Procedure — Ryūjin Ascendant Form

- This is a temporary bodily transformation. Record the chosen size, occupied space, equipment fit, flight, reach, Resistances, and active breath profile when it begins.
- “You may become Large” is optional. If chosen, you become Large only if your current space can legally contain that size. If already Large or larger, the feature does not reduce your size. Ending the form returns you to your prior legal size under the transformation procedure.
- The 5-foot unarmed reach increase is persistent for the duration and applies to unarmed attacks and Body features using unarmed reach. It does not enlarge the range of Dragon's Breath, Dragon's Roar, or Storm Step.
- Dragon's Breath retains its Action and 2-Stamina cost. Its cone becomes 30 feet and its damage is `8d6`; this is a replacement profile, not additional damage.
- Storm Step retains its Bonus Action and all destination restrictions. It costs 1 Stamina during the form and remains usable no more than once during each of your turns.
- The `3d6` rider is once per turn total and replaces no other Dragon Scales damage; both apply to a qualifying hit because the source prints both benefits.
- At the start of each hostile creature's turn, check whether it is within 10 feet. It saves once for that turn. On failure, push it 5 feet directly away along a legal route and deny Reactions. If no legal space exists, it remains in place but still loses Reactions.
- Suppressing the form makes its benefits dormant and does not extend its duration or refund its scene use.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Ryūjin

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 16. Kūkishin

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*An empty body is hardest to strike.*

Kūkishin cultivates hollowness, incorporeal motion, spiritual penetration, and a body capable of briefly refusing solidity.

**Access Category:** Rare Inheritance  
**Primary Identity:** Hollow body, phasing, incorporeality, spirit-striking attacks  
**Common Sphere Synergies:** Force, Shadow, Space, Spirit, Void

#### CL3 - Phase Flesh

**Reaction**  
**Trigger:** An attack deals damage to you.  
**Cost:** 2 Stamina  
**Limit:** Once per round

Halve the triggering damage after Resistance and Vulnerability are applied.

Until the start of your next turn:

- Move through creature spaces and nonartifact solid objects as difficult terrain.
- Ignore nonmagical difficult terrain.
- Gain Advantage on checks and saving throws to escape Grappled or Restrained.

You cannot end a turn inside an occupied space or solid object. If you do, move to the nearest legal space and take `2d10` Force damage that cannot be reduced, prevented, redirected, or absorbed.

##### Normalized Procedure — Phase Flesh

- Declare after the triggering attack's damage has been calculated and Resistance and Vulnerability have been applied, but before Hit Points are reduced. Halve the remaining triggering damage, rounding down, before Stamina Guard and other flat reductions.
- The phasing state begins after the triggering damage packet resolves. It does not make the triggering attack miss or invalidate riders that already resolved.
- During the state, a creature space or nonartifact solid object is difficult terrain. You need enough movement to traverse every entered space and cannot see through an opaque object merely because you can enter it.
- Worn and carried equipment moves with your phased body. You cannot use the feature to leave an unwilling creature, restrained passenger, structure, or oversized object inside solid matter.
- If you end a turn in an illegal occupied or solid space, move by the shortest route to the nearest legal space. If several are equally near, you choose among them. Then take the printed `2d10` Force damage. This damage ignores all reduction, prevention, redirection, absorption, Temporary Hit Points granted specifically against damage, and immunity.
- Phase Flesh does not bypass an artifact barrier, spatial lock, or effect explicitly preventing phasing.

#### CL6 - Empty Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Deal an additional `2d8` Psychic or Force damage.

Choose one:

- No Reactions until the start of the target's next turn.
- It cannot benefit from Invisible until the start of your next turn.
- Disadvantage on its next Concentration saving throw before the start of your next turn.
- Disadvantage on its next saving throw against possession, forced transformation, or a soul-affecting effect before the end of your next turn.

Empty Strike affects Incorporeal creatures, possessing entities, Spirits, and soul-bound Constructs normally.

##### Normalized Procedure — Empty Strike

- Declare after the unarmed strike hits. Spend Stamina before selecting and resolving the rider.
- The additional Psychic or Force damage is part of the triggering attack's damage packet. Choose its type for each use.
- “Cannot benefit from Invisible” suppresses the mechanical benefits of the Invisible condition for that target during the duration; it does not automatically end the condition, reveal disguises, or make the target visible to creatures that otherwise cannot perceive it.
- A Disadvantage option affects only the next qualifying saving throw in its duration and is then consumed. If no qualifying save occurs, it expires without effect.
- Empty Strike can affect a legally targeted Incorporeal creature, Spirit, possessing entity, or soul-bound Construct without losing damage or riders solely because of that nature. It does not by itself reveal an unseen entity, target an Intruder through a Host, or grant authority to strike a Complete Soul that is not otherwise a legal target.

#### CL10 - Hollow Step

**Bonus Action**  
**Duration:** Until the start of your next turn  
**Cost:** 3 Stamina

For the duration:

- Become Invisible.
- Become Incorporeal.
- Gain a Fly Speed equal to your walking Speed and Hover.
- Move through creatures and nonartifact objects as difficult terrain.
- Creatures unable to perceive you cannot make Opportunity Attacks against you.

When the effect ends, gain Advantage on your first attack roll before the end of your next turn. The first hit before then deals an additional `2d8` Psychic or Force damage.

You cannot end the turn inside an occupied space or object. Use the Phase Flesh displacement and damage procedure if you do.

Spatial locks and barriers explicitly blocking phasing prevent passage.

##### Normalized Procedure — Hollow Step

- The state begins when the Bonus Action resolves and ends at the start of your next turn. Invisible, Incorporeal, flight, and phasing are one combined activation.
- You remain one creature with one Hit Point total, action economy, condition set, equipment set, and Concentration limit. Hollow Step does not create a projection or duplicate body.
- Movement through creatures and nonartifact objects uses the Phase Flesh passage procedure. A creature whose space you enter is not damaged, pushed, or automatically aware of you.
- At the start of your next turn, after the state ends, record the attack benefit. Advantage applies to your first attack roll made before the end of that turn. If that attack hits, the same hit gains the `2d8` Psychic or Force damage. If it misses, both benefits are expended.
- If you end your turn in an illegal space, resolve displacement and `2d10` unavoidable Force damage immediately, before the state ends.
- A spatial lock or explicit phasing barrier blocks passage; it does not automatically end Hollow Step's other benefits.

#### CL14 - Soul Severance

**Trigger:** You hit with an unarmed strike.  
**Cost:** 5 Stamina  
**Limit:** Once per scene  
**Saving Throw:** Charisma

On a failed save, the target is Stunned until the end of your next turn, cannot take Reactions, cannot willingly teleport or become Incorporeal, and has Disadvantage on Concentration saving throws. On a successful save, it cannot take Reactions until the start of its next turn.

##### Spiritual Surgery

You may perform Soul Severance as a 10-minute procedure on a willing, Restrained, Incapacitated, or Unconscious target. Choose one:

- **Diagnosis:** Learn the exact source, Source CL, save DC, duration, and removal procedure of one possession, forced transformation, soul-binding, or spiritual state.
- **Exorcism:** A possessing entity makes a Charisma saving throw. On a failure, it is expelled into the nearest legal space.
- **Sever Temporary Bond:** End one temporary possession, forced transformation, or soul-binding whose Source CL is no higher than yours.
- **Suppression:** Suppress one higher-CL qualifying effect for 1 minute. This does not remove it.

##### Normalized Procedure — Soul Severance

- Declare after the unarmed strike hits and spend Stamina before the Charisma save. The save and its riders are part of the same attack activation.
- On failure, all printed restrictions last until the end of your next turn. On success, only Reaction denial applies, with its shorter printed duration.
- The temporary prohibition on willing teleportation or Incorporeality does not cancel an already occupied space or forcibly eject a creature from an existing form. It prevents new willing activations and voluntary use during the duration.
- A target can be affected by only one Soul Severance duration from you at a time; reapplication refreshes rather than stacks.

##### Normalized Procedure — Spiritual Surgery

- The 10-minute procedure requires uninterrupted physical access to the target and a recorded qualifying spiritual state. The target must remain willing, Restrained, Incapacitated, or Unconscious for the full procedure.
- **Diagnosis** reveals only the listed mechanical data. A specific equal- or higher-Source-CL concealment can contest one datum through a Cultivation Check; failure tells you that datum is concealed rather than supplying false information.
- **Exorcism** targets one possessing entity already identified in the target. On a failed Charisma save, use the shared possession-separation procedure and place it in the nearest legal space capable of containing it. This does not destroy, bind, convert, or claim the entity.
- **Sever Temporary Bond** ends one temporary, unwilling possession, forced transformation, or temporary soul-binding whose Source CL is no higher than yours. It cannot end spirit ancestry, a legal character option, a permanent consensual Bond, a Complete Soul's personhood, or a higher-authority relationship without another rule.
- **Suppression** selects one qualifying higher-Source-CL effect. It becomes dormant for 1 minute but retains duration and ownership. This option does not remove it, transfer it, or prevent a higher-authority rule from ending the suppression.
- Use the Spirit Awakening Rules Reference or later Universal Cultivation Authority procedures for possession, Complete Souls, spiritual states, and authority collisions.

#### CL18 - Hollow Immortal

You gain the following passive benefits:

- Move through creature spaces as difficult terrain.
- Pass through openings as narrow as 1 inch.
- Gain Advantage against Grappled, Restrained, possession, forced transformation, and unwilling teleportation.

##### Empty-World Incarnation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Gain a Fly Speed of 40 feet and Hover.
- Gain Resistance to all damage except Force, Radiant, and Void.
- Move through ordinary walls, floors, ceilings, barriers, and creatures as difficult terrain.
- You cannot be Grappled or Restrained by a physical effect whose Source CL is no higher than yours.
- Use Hollow Step once per turn without paying its Stamina cost.
- After emerging from an object, barrier, or creature's space, gain Advantage on your next attack roll before the end of the turn.
- Empty Strike deals `3d8` additional damage instead of `2d8`.

You cannot end a turn inside an occupied space or object.

An artifact barrier, spatial lock, or higher-CL phasing barrier prevents passage unless you win an opposed Cultivation Check.

---

##### Normalized Procedure — Hollow Immortal

- Passing through a 1-inch opening changes only the minimum opening needed by your body and normally carried equipment. It does not allow you to carry an oversized object, unwilling creature, vehicle, or structure through that opening.
- The listed Advantage applies only to the checks and saves directly resisting or escaping the named effects. It does not create immunity.

##### Normalized Procedure — Empty-World Incarnation

- Empty-World Incarnation is a temporary bodily state, not a separate projection. It preserves one body, one turn, one Hit Point total, and one set of conditions.
- Hollow Step retains its Bonus Action, duration, targeting, and once-per-turn practical action limit; only its Stamina cost is waived. Activating Empty-World Incarnation does not automatically activate Hollow Step on the same Bonus Action.
- Physical Grapple or Restraint from a Source CL no higher than yours cannot be newly established and becomes ineffective while the state persists. A higher-Source-CL physical effect remains subject to its normal checks and saves.
- Emerging means leaving an object, barrier, or creature space after occupying at least part of it through this feature. Advantage applies to one next attack before the end of the same turn and does not stack from passing through multiple spaces.
- Empty Strike uses `3d8` instead of `2d8`; this is a replacement, not `2d8 + 3d8`.
- When attempting to enter or cross an artifact barrier, spatial lock, or higher-Source-CL phasing barrier, make one opposed Cultivation Check for that discrete barrier and movement attempt. On failure, movement ends in the nearest legal space before the barrier. On success, pass through for that movement only unless the barrier's rule says otherwise.
- Ending the turn in an illegal space uses the Phase Flesh displacement and unavoidable-damage procedure.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Kūkishin

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 17. Oni Blood

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The hunger is mine. That is why it has not eaten the world yet.*

Oni Blood grants demonic strength, predatory healing, and monstrous transformation at the price of a hunger that must be actively restrained.

**Access Category:** Forbidden Method and Rare Inheritance  
**Primary Identity:** Demonic mask, blood hunger, predatory vitality, monstrous transformation  
**Common Sphere Synergies:** Blood, Brute, Daemonic Cultivation, Flesh, Yang

#### CL3 - Forbidden Consequence: Blood Hunger

While Oni Mask or Oni Form is active, Blood Hunger is tested at the start of your turn when you can perceive a Bloodied hostile creature within 30 feet.

Choose one obligation:

- Move at least 10 feet toward a hostile creature before the end of the turn.
- Make at least one attack against a hostile creature before the end of the turn.
- Attempt to restrain the hunger.

To restrain it, make a Wisdom saving throw against your own Cultivation Save DC.

On a success, no obligation remains. On a failure, until the start of your next turn you cannot willingly end movement farther from every hostile creature you can perceive than where you began that movement, have Disadvantage on Persuasion and Deception, gain Advantage on Intimidation, and your demonic features become visibly obvious.

Blood Hunger never forces you to attack an ally, helpless nonhostile creature, or surrendered creature.

##### Normalized Procedure — Blood Hunger

- Test Blood Hunger once at the start of each of your turns while Oni Mask or Oni Form is active and you can currently perceive at least one Bloodied hostile creature within 30 feet.
- Choose the obligation before moving or attacking. An attack obligation is satisfied by making at least one genuine attack against a hostile creature, whether it hits or misses. A movement obligation is satisfied when your position after at least 10 feet of voluntary movement is closer to at least one perceived hostile creature than before that movement.
- If a printed effect makes the selected obligation impossible, you must attempt the other physical obligation if possible or attempt to restrain the hunger. Blood Hunger does not create a new action, movement, target, or attack.
- The Wisdom save to restrain uses your own current Cultivation Save DC. Advantage, Disadvantage, rerolls, and suppression apply normally.
- On failure, the movement restriction is evaluated at the end of each voluntary movement segment. You may move laterally or toward any perceived hostile creature, but cannot voluntarily finish farther from all of them.
- Visible demonic signs created by failure are a recorded appearance state. Mundane concealment can cover them only when physically plausible; an observer with an explicit supernatural detection rule can still detect them.
- Blood Hunger never treats an ally, helpless nonhostile, surrendered creature, harmless animal, or fabricated resource-loop target as a required target.

#### CL3 - Oni Mask

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 2 Stamina

For the duration:

- Gain Advantage on Intimidation checks.
- Gain Disadvantage on Persuasion checks.
- Once per turn when you hit with an unarmed strike, deal an additional `1d6` Necrotic damage.
- Iron Voice may manifest as a demonic roar.
- Blood Hunger applies.

You may end Oni Mask without using an action.

##### Normalized Procedure — Oni Mask

- Oni Mask is a temporary bodily manifestation. Record its visible traits when first learned. It does not change size, occupied space, equipment, reach, or anatomy unless another Oni Blood feature says so.
- Ending the Mask requires no action and can occur at any time you are able to make decisions, including during your turn. Ending it does not refund Stamina.
- The `1d6` Necrotic rider applies to one qualifying unarmed-strike hit per turn and is part of that attack's damage packet.
- Iron Voice may use demonic presentation but retains its own range, action, costs, saves, and effects.
- Activating or refreshing Oni Mask creates one duration; multiple uses do not stack its social modifiers or damage rider.

#### CL6 - Blood Drinker

While Oni Mask or Oni Form is active:

- Once per turn when an unarmed strike damages a Bloodied qualifying hostile creature, gain Temporary Hit Points equal to your Proficiency Bonus.
- When you reduce a qualifying hostile creature to 0 Hit Points with an unarmed strike, regain Hit Points equal to your Constitution modifier plus your Proficiency Bonus. This healing can occur once per creature.

Blood Drinker cannot generate healing or Temporary Hit Points from harmless animals, allied creatures, creatures created for resource loops, repeatedly revived or recaptured targets, or creatures that do not qualify under the Qualifying Hostile Creature rule.

##### Normalized Procedure — Blood Drinker

- Determine whether the target is Bloodied immediately before the qualifying unarmed strike deals damage. A hit that first makes an unbloodied target Bloodied does not satisfy the first bullet for that hit.
- Temporary Hit Points are granted after the damage packet resolves. They follow the normal nonstacking rule.
- The 0-Hit-Point healing resolves after the target is actually reduced to 0 Hit Points and before later corpse, death, or capture procedures. It can occur only once for that creature from you, regardless of revival, transformation, replacement body, or later recapture.
- “Qualifying hostile creature” uses the universal anti-farming rule. A creature created, summoned, revived, healed, captured, or staged primarily to generate this benefit does not qualify.
- Blood Drinker is bodily predation, not soul consumption. It does not capture a soul, steal a Foundation, copy a Sphere, or create harvestable blood authority.

#### CL10 - Demon Roar

**Action**  
**Area:** 30-foot cone  
**Cost:** 5 Stamina  
**Limit:** Once per scene  
**Saving Throw:** Wisdom

Choose Psychic or Necrotic damage. A Bloodied creature has Disadvantage on its first saving throw against this feature.

On a failed save, a creature takes `4d8` damage and is Frightened of you for 1 minute, repeating the save at the end of each turn and ending Frightened on a success.

On a successful save, it takes half damage and cannot take Reactions until the start of its next turn.

##### Normalized Procedure — Demon Roar

- Choose Psychic or Necrotic when activating the feature. The cone originates from your body and requires line of effect.
- A creature is Bloodied for the initial-save Disadvantage if it is at or below half its maximum Hit Points when that initial save is rolled.
- “Its first saving throw against this feature” means the initial save against that activation. Repeat saves against Frightened are not made with Disadvantage from this clause unless another effect applies it.
- On success, Reaction denial begins after damage resolves. On failure, Frightened uses the printed repeat-save timing and ends only for that creature when it succeeds.
- The roar does not force movement, compel attacks, reveal hidden creatures, or affect unattended objects unless another rule expressly says so.

#### CL14 - Oni Form

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

Activate Oni Mask without paying its cost.

For the duration:

- Become Large if smaller.
- Gain Temporary Hit Points equal to twice your CL.
- Gain Resistance to Cold, Fire, and Necrotic damage.
- Gain Advantage on Strength checks and Strength saving throws.
- Your unarmed reach increases by 5 feet.
- Once per turn when you hit with an unarmed strike, deal an additional `2d6` Necrotic damage instead of Oni Mask's `1d6`.
- Blood Hunger applies whenever you can perceive any Bloodied hostile creature within 30 feet.

When Oni Form ends, Oni Mask also ends.

##### Normalized Procedure — Oni Form

- Oni Form is a temporary transformation and includes one free activation or refresh of Oni Mask as part of the same Bonus Action. Do not pay Oni Mask's Stamina cost.
- If smaller than Large, become Large only if the current space can legally contain that size. If already Large or larger, retain the current size. Equipment follows the shared transformation procedure.
- Temporary Hit Points are granted once when the form begins and do not refresh each turn. Reapplication follows the normal nonstacking rule.
- The unarmed reach increase is persistent for the duration. Advantage on Strength checks and saves does not apply to Constitution-based Cultivation Checks unless another rule says so.
- The `2d6` once-per-turn Necrotic damage replaces Oni Mask's `1d6` rider; do not add both.
- Blood Hunger is checked whenever any perceived Bloodied hostile creature is within 30 feet, as printed. The form creates no obligation when no such creature is perceived.
- When Oni Form ends for any reason, the Oni Mask activation included with it also ends. An independently activated Mask with a separate later duration is not created by the form.

#### CL18 - Crimson Oni

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 6 Stamina  
**Limit:** Once per scene  
**Action:** None

Instead:

- Regain Hit Points equal to half your maximum Hit Points.
- Activate Oni Form without paying its cost, even if it was already used.
- End Frightened, Stunned, or Restrained on yourself when the effect's Source CL is no higher than yours.

During this Oni Form:

- Gain Advantage on unarmed attack rolls against Bloodied hostile creatures.
- Blood Drinker grants Temporary Hit Points equal to twice your Proficiency Bonus.
- Your unarmed strikes deal an additional `3d6` Necrotic damage once per turn instead of `2d6`.

When this Oni Form ends, gain 1 level of Exhaustion and your demonic traits remain impossible to conceal until you complete a full 2-hour Cultivation Session.

Only one feature that prevents or replaces the same reduction to 0 Hit Points may resolve.

---

##### Normalized Procedure — Crimson Oni

- Declare after damage is determined to reduce you to 0 Hit Points but before Unconsciousness, death saves, or other 0-Hit-Point consequences. Pay 6 Stamina and expend the scene use when declared.
- Only one feature can replace that reduction. If killed outright, if your body is completely destroyed, or if an effect expressly forbids this restoration, Crimson Oni cannot resolve unless another rule overrides that prohibition.
- Regain half maximum Hit Points, rounding down, then activate Oni Form without its Stamina cost or scene restriction. This special Oni Form has the normal 1-minute duration and all normal Oni Form rules.
- End only the listed conditions whose creating Source CL is no higher than yours. If multiple qualifying instances exist, all qualifying instances of those three named conditions end.
- During the special form, Blood Drinker's Temporary Hit Points become twice Proficiency Bonus. The `3d6` rider replaces Oni Form's `2d6` and Oni Mask's `1d6`; do not add them together.
- When this special form ends for any reason, gain 1 Exhaustion and begin the visible-trait aftermath. Suppression does not postpone the aftermath beyond the form's original ending time.
- “Full 2-hour Cultivation Session” means two uninterrupted hours of demonic restraint, breath regulation, blood purification, or an equivalent recorded Oni rite. Interruption requires restarting the session. Completing it ends only the concealment aftermath, not Exhaustion or another consequence.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Oni Blood

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 18. Jigoku

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Hell tempered me because heaven would not.*

Jigoku refiners convert pain, fire, punishment, and hell-scarred flesh into combat power.

**Access Category:** Forbidden Method  
**Primary Identity:** Hell-tempered body, pain cultivation, fire consumption, infernal endurance  
**Common Sphere Synergies:** Ash, Brute, Daemonic Cultivation, Fire, Magma, Yang

#### CL3 - Forbidden Consequence: Hell Scars

Your cultivation creates permanent visible hell scars.

You may cover them with clothing, armor, or supernatural concealment, but mundane cosmetics do not remove them.

A creature within 30 feet that can see the scars automatically recognizes them as forbidden bodily cultivation when it has Arcana, Medicine, or Religion proficiency; the Ash, Daemonic Cultivation, Fire, or Magma Sphere; or an Infernal, Daemonic, Exorcist, or Purification tag.

While visible, gain Advantage on Intimidation and Disadvantage on Persuasion checks made to convince a creature that you are harmless, orthodox, or free of forbidden cultivation.

##### Hell-Signaled

When Asura's Rage ends, you become Hell-Signaled until completing a full 2-hour Cultivation Session.

While Hell-Signaled, Infernal and Daemonic creatures within 1 mile know your direction and whether your Realm is lower than, equal to, or higher than their own. This does not reveal your identity or distance.

##### Normalized Procedure — Hell Scars

- Record the scars' locations, visible appearance, and whether ordinary clothing or armor covers them. They are permanent bodily alterations but impose only the printed social effects.
- Automatic recognition reveals that the scars are signs of forbidden bodily cultivation. It does not reveal your exact Subpath features, CL, Source CL, ability scores, history, allegiance, or crimes.
- An observer qualifies through any one listed proficiency, Sphere, or tag and must be within 30 feet with a current line of sight to at least one visible scar.
- Mundane cosmetics cannot remove or convincingly falsify the scars. Physical covering can block ordinary sight. A supernatural concealment or transformation specifically capable of hiding cultivation signs uses its own Source CL and detection procedures.
- Advantage and Disadvantage apply only to the listed social purposes. A creature unaware of the scars receives no modifier from them.

#### CL3 - Hell-Tempered

Gain Resistance to Fire damage.

##### Eat the Flame

**Reaction**  
**Trigger:** Qualifying hostile damage deals Fire damage to you.  
**Cost:** 1 Stamina  
**Limit:** Once per round

After Fire Resistance is applied, gain Temporary Hit Points equal to the Fire damage you actually took, to a maximum of twice your Proficiency Bonus.

Eat the Flame does not function from self-inflicted damage, a willing ally, a harmless flame, a deliberately weakened attack, a repeated staged hazard, or damage reduced to 0.

##### Normalized Procedure — Hell-Tempered and Eat the Flame

- Fire Resistance follows the ordinary damage procedure.
- Eat the Flame is declared after the complete triggering damage packet resolves and only if you actually lost at least 1 Hit Point to its Fire portion. Pay Stamina then gain Temporary Hit Points equal to that Fire damage taken, capped at twice Proficiency Bonus.
- For a mixed packet, record only the Fire damage that remained after Resistance, Vulnerability, redirection, reduction, and prevention. Other damage types do not increase the Temporary Hit Points.
- Temporary Hit Points follow the normal nonstacking rule. Damage absorbed entirely by existing Temporary Hit Points still counts as damage taken only if the universal damage rule treats it as actual damage to you; damage reduced to 0 never qualifies.
- The anti-farming exclusions are absolute. Repeated exposure to a stationary hazard, cooperative attacker, self-created flame, or deliberately weakened source cannot generate the benefit.

#### CL6 - Pain Eater

Once per round when a hostile creature damages you, mark it until the end of your next turn.

The first time you hit the marked creature with an unarmed strike before the mark ends:

- Deal additional damage equal to your Proficiency Bonus.
- End the mark.
- Choose one:
  - Gain Temporary Hit Points equal to your Proficiency Bonus.
  - Move 5 feet without provoking Opportunity Attacks.
  - Gain Advantage on your next saving throw before the start of your next turn.
  - Prevent the target from taking Reactions until the start of its next turn.

A creature can bear only one Pain Eater mark from you at a time. A new mark replaces the previous one.

##### Normalized Procedure — Pain Eater

- Choose whether to mark a hostile creature immediately after one of its damage packets actually damages you. You can create only one mark per round.
- The mark records the creature, your Source CL, and its ending time. A new Pain Eater mark replaces your previous mark, even when placed on a different creature.
- The first unarmed-strike hit against the marked creature before expiration automatically consumes the mark after the hit is confirmed. The additional damage has the same type as one damage type dealt by that strike, chosen by you if the strike deals several.
- Choose exactly one printed benefit after the hit. Temporary Hit Points do not stack. The 5-foot movement is voluntary granted movement and must end legally. Saving-throw Advantage applies to one next save and is consumed. Reaction denial lasts as printed.
- Damage from the mark cannot itself create another Pain Eater mark or qualify as a separate hostile damage event.

#### CL10 - Flame Fist

Your unarmed strikes may deal Fire damage.

##### Burning Brand

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Constitution

On a failed save, the target becomes Burning. It takes `1d8` Fire damage at the start of each turn, repeats the save at the end of each turn and ends Burning on a success, and it or an adjacent creature may use an Action to extinguish the flames automatically.

On a successful save, it takes `1d8` Fire damage immediately and does not become Burning.

At CL17, the damage becomes `2d8`.

A creature can bear only one Burning Brand from you. Reapplication refreshes the state.

##### Normalized Procedure — Flame Fist and Burning Brand

- You choose whether each unarmed strike uses its normal permitted damage type or Fire. This choice does not add damage and does not turn an unrelated weapon attack into Fire.
- Declare Burning Brand after the unarmed strike hits, spend Stamina, then have the target make the Constitution save.
- On failure, Burning is one persistent state with your Source CL. Its start-of-turn damage is one packet. The target repeats the save at the end of each of its turns after taking any start-of-turn damage for that turn.
- The target or an adjacent creature can use one Action to end Burning automatically. This requires the ability to take actions and physically or supernaturally smother the brand; no check, water, tool, or specific equipment is required.
- On success, the immediate `1d8` Fire damage is part of this activation but not the triggering strike's damage packet. It cannot critically hit.
- A target can bear only one Burning Brand from you. Reapplication refreshes duration and Source CL; it does not stack damage or create multiple start-of-turn packets.

#### CL14 - Hellwalker

You gain:

- Immunity to Fire damage.
- Resistance to Necrotic damage.
- Advantage on saving throws against Frightened.
- The ability to see normally through smoke, flame, and Darkness created by your own Jigoku, Ash, Fire, Magma, or Daemonic Cultivation features.

At the start of your turn, when inside or adjacent to active flame, smoke, magma, Ash terrain, or hostile Fire, choose one:

- Move 10 feet without provoking Opportunity Attacks.
- Gain Advantage on your next unarmed attack before the end of the turn.
- Gain Temporary Hit Points equal to your Proficiency Bonus.
- Ignore difficult terrain until the end of the turn.

The same environmental area cannot grant this benefit more than once during the same turn.

##### Normalized Procedure — Hellwalker

- Seeing through smoke, flame, and Darkness applies only when that obscuration was created by one of your own listed features. It does not grant general truesight, the ability to see through solid matter, or immunity to another creature's supernatural concealment.
- At the start of your turn, identify one qualifying environmental area you occupy or are adjacent to. A qualifying area must be active and mechanically present, not a harmless cosmetic ember or staged effect.
- Choose exactly one benefit. The same environmental area cannot grant another Hellwalker benefit to you during that turn, even if you leave and re-enter it.
- The 10-foot movement is voluntary granted movement, must end legally, and does not provoke Opportunity Attacks. Attack Advantage applies to one next unarmed attack and is consumed. Temporary Hit Points do not stack. Difficult-terrain immunity lasts until the end of the turn only.
- “Hostile Fire” means an ongoing Fire effect created or controlled by a hostile source; an instantaneous attack that has already ended is not an area to stand inside or beside.

#### CL18 - Asura's Rage

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Gain Advantage on unarmed attack rolls.
- Gain Resistance to all damage except Force, Radiant, and Void.
- Gain Immunity to Frightened.
- Your unarmed strikes may deal Bludgeoning, Fire, or Necrotic damage.
- Once per turn when you hit with an unarmed strike, deal an additional `3d6` Fire or Necrotic damage.
- Once per round when a hostile creature damages you, move up to 10 feet without provoking Opportunity Attacks.
- Once per round when a hostile creature within your reach damages you, use your Reaction to make one unarmed strike against it.

The reaction attack follows the Granted Attack rule.

When Asura's Rage ends:

- Gain 1 level of Exhaustion.
- Become Hell-Signaled.
- Eat the Flame becomes unavailable until you complete a 10-minute uninterrupted cooling rite after the scene. The rite fails if you take damage, spend Stamina, or perform strenuous activity.

---

##### Normalized Procedure — Asura's Rage

- Asura's Rage is one temporary bodily state. Its Resistances, Immunity, movement response, damage rider, and Reaction attack all use the feature's Source CL.
- Advantage applies to unarmed attack rolls only. The once-per-turn `3d6` rider is part of one qualifying attack packet and uses the chosen Fire or Necrotic type.
- The once-per-round 10-foot movement resolves after the hostile damage packet. It is voluntary granted movement, does not provoke Opportunity Attacks, and must end legally.
- The Reaction attack is available only when the damaging hostile creature is within your current reach after its damage resolves. It follows the Granted Attack rule and cannot grant another attack.
- The movement response and Reaction attack are separate once-per-round benefits and can both respond to the same qualifying damage if their requirements are met and you have a Reaction.
- When the state ends for any reason, gain 1 Exhaustion, become Hell-Signaled, and disable Eat the Flame as printed. Suppression does not prevent the ending consequences.
- Hell-Signaled functions on the same plane. Qualifying Infernal and Daemonic creatures know your current direction and relative Realm category, but not identity, exact distance, route, equipment, or precise CL.
- The cooling rite can begin only after the scene's immediate conflict has ended. It requires 10 uninterrupted minutes without damage, Stamina spending, strenuous activity, or another cultivation activation. Interruption restarts it. Completing it restores Eat the Flame but does not end Hell-Signaled; only the full 2-hour Cultivation Session ends that state.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Jigoku

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 19. Sky-Treading Tendon School

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The road ends at the cliff. My stride does not.*

Sky-Treading disciples temper the legs, hips, tendons, balance, and lower meridians until distance becomes a physical obstacle rather than a limitation.

**Access Category:** Open School  
**Primary Identity:** Extreme mobility, aerial pursuit, kicking force, rapid repositioning  
**Common Sphere Synergies:** Air, Athletics, Flowing River, Force, Lightning, Monkey Style, Weather

#### CL3 - Thousand-Mile Legs

Your walking Speed increases by 10 feet. Your long jump and high jump distances are tripled, and you do not require a running start.

When you use Stomping Step, until the end of the turn you may move across liquids and vertical surfaces without falling during the movement, and ordinary nonmagical difficult terrain does not cost additional movement. If you end unsupported, you fall normally.

Once during each of your turns, after moving at least 20 feet before hitting with an unarmed strike, deal additional damage equal to your Proficiency Bonus and move 5 feet without provoking Opportunity Attacks.

##### Normalized Procedure — Thousand-Mile Legs

- The 10-foot increase modifies your walking Speed and therefore any feature that explicitly derives a Speed from walking Speed. It does not directly increase a fixed climb, swim, burrow, or teleport range.
- Triple the final long-jump and high-jump distances after ordinary Strength calculations and before a feature that supplies a separate fixed jump distance. No running start is required.
- During Stomping Step, movement across liquid or a vertical surface is ordinary movement using your available Speed. You do not sink or fall during that movement. If unsupported when the turn ends, resolve falling normally.
- Ordinary nonmagical difficult terrain costs no extra movement only during that Stomping Step turn. A supernatural Field, Formation, Domain, spatial lock, or explicit movement prohibition retains its authority.
- For the once-per-turn strike rider, count actual distance traveled by voluntary movement during the current turn. Teleportation does not add traveled distance. After a qualifying hit, add Proficiency Bonus damage to the attack packet and take the 5-foot legal movement after the hit resolves.

#### CL6 - Heaven-Kicking Leg

**Trigger:** You hit with an unarmed strike after moving at least 10 feet during the current turn.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Strength

On a failed save, move the target up to 15 feet to an unoccupied space you can see, horizontally, vertically, or both, and it cannot take Reactions until the start of its next turn. If unsupported afterward, it falls.

On a successful save, push it 5 feet horizontally.

A creature more than two sizes larger than you has Advantage on this saving throw.

##### Normalized Procedure — Heaven-Kicking Leg

- Count at least 10 feet of actual movement during the current turn before the hit. Forced movement can qualify only if you willingly accepted or directed it; teleportation does not count as traveled distance.
- Declare after the unarmed strike hits and spend Stamina before the Strength save.
- On failure, choose an unoccupied legal destination within 15 feet of the target's starting space and visible to you. The target travels along the shortest unobstructed physical trajectory, which may be horizontal, vertical, or diagonal. This is forced movement, not teleportation.
- If the full destination is blocked, move the target as far as legally possible along the selected trajectory. If unsupported, falling begins after the forced movement resolves.
- On success, push 5 feet horizontally and directly away from you. If no legal space exists, the target remains in place.
- “More than two sizes larger” means at least three size categories larger than you and grants Advantage only on this save.

#### CL10 - Tread the Empty Sky

Once during each of your turns while airborne, spend 1 Stamina without using an action.

Until the end of the current turn:

- Gain a Fly Speed equal to your walking Speed.
- Hover.
- Your movement does not provoke Opportunity Attacks from creatures at least 10 feet below you.

At the end of the turn, you remain suspended until the start of your next turn. If you do not use Tread the Empty Sky again before that turn ends and remain unsupported, you fall.

Effects explicitly preventing flight, sealing the surrounding air, suppressing Body Refining features, or imposing a spatial lock prevent this movement.

##### Normalized Procedure — Tread the Empty Sky

- Activate once during your turn while any part of your space is unsupported or airborne. Spending Stamina requires no action.
- Until the end of that turn, gain the printed Fly Speed and Hover. The flight uses movement normally and does not create extra movement beyond your remaining movement allowance.
- Creatures at least 10 feet below every part of your space cannot make Opportunity Attacks caused by this movement. Other creatures can.
- At the end of the activation turn, remain suspended in your current legal space until the start of your next turn. During that next turn, you may reactivate the feature once. If you do not reactivate before that turn ends and remain unsupported, you fall at the end of that turn.
- Suppression or an explicit flight prohibition immediately removes flight and suspension. A spatial lock blocks only the movement authority it expressly covers; it does not automatically damage you.

#### CL14 - Pursuit Without Horizon

**Reaction**  
**Trigger:** A hostile creature you can see within 60 feet willingly moves at least 10 feet or teleports using its own feature.  
**Cost:** 2 Stamina  
**Limit:** Once per round

Move up to your Speed without provoking Opportunity Attacks. You may use Thousand-Mile Legs and Tread the Empty Sky without paying Tread's normal cost. You must end closer to the triggering creature.

If you end within unarmed reach, make one unarmed strike against it. The attack follows the Granted Attack rule.

##### Normalized Procedure — Pursuit Without Horizon

- The trigger resolves after the hostile creature completes the qualifying 10 feet of willing movement or its teleport resolves. Movement split into several segments can trigger once when the cumulative willing movement reaches 10 feet.
- A teleport qualifies only when activated by the hostile creature's own feature. Movement imposed by another creature, forced movement, or involuntary teleportation does not.
- After the trigger resolves, move up to your current Speed. Thousand-Mile Legs applies normally. If airborne, you may activate Tread the Empty Sky as part of this Reaction without its Stamina cost; this does not require another action.
- Your final space must be legally closer to the triggering creature by straight-line distance than your starting space. If no such legal space can be reached, move as close as possible; if no movement would end closer, the movement fails but the Reaction and Stamina are spent.
- The unarmed strike occurs after movement and only if the creature remains within reach. It follows the Granted Attack rule and cannot trigger another granted attack.

#### CL18 - Body Crosses Heaven

Gain a permanent Fly Speed equal to your walking Speed and Hover while conscious.

Once during each of your turns, after moving at least 30 feet before hitting with an unarmed strike, spend 2 Stamina. The attack deals an additional `4d8` Force damage, and the target makes a Strength saving throw.

- **Failed Save:** Push it up to 30 feet in a direction you choose and knock it Prone.
- **Successful Save:** Push it 10 feet.

If it collides with a solid surface, it and the surface each take additional Bludgeoning damage equal to your Proficiency Bonus.

---

##### Normalized Procedure — Body Crosses Heaven

- The permanent Fly Speed and Hover function while conscious and derive from your current walking Speed. Losing consciousness removes Hover and causes falling unless another effect supports you.
- For the once-per-turn attack, count 30 feet of actual movement before the hit during that turn. Teleportation does not add traveled distance. The 2-Stamina cost is declared after the hit and before rolling the `4d8` Force damage.
- The `4d8` is part of the triggering attack's damage packet. Then the target makes the Strength save.
- On failure, choose a legal direction and move the target up to 30 feet along a direct trajectory; on success, push it 10 feet directly away from you. Movement stops at the first surviving solid barrier.
- A collision occurs once when the forced movement is stopped early by a solid surface. The target and that discrete surface each take one Bludgeoning damage packet equal to your Proficiency Bonus. Another creature is not a “solid surface” for this clause unless its own rule expressly functions as one.
- The collision damage does not trigger this feature again, create an Injury, or grant additional forced movement.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Sky-Treading Tendon School

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 20. Returning-Heaven Momentum Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Nothing that moves against me is lost. The body remembers every road force has taken.*

Returning-Heaven disciples store movement, impact, recoil, and hostile displacement inside their muscles and meridians.

**Access Category:** Open School  
**Primary Identity:** Stored momentum, charges, rebounds, collision attacks, movement conversion  
**Common Sphere Synergies:** Athletics, Brute, Flowing River, Force, Gravity, Guardian

#### Momentum

- Your maximum Momentum equals your Proficiency Bonus.
- You begin each scene with 0 Momentum, and it disappears when the scene ends.
- You can gain no more than 1 Momentum per round from the normal Momentum rules.

Gain 1 Momentum after willingly moving at least 20 feet during your turn, being pushed, pulled, thrown, or teleported at least 10 feet by a hostile effect, taking qualifying hostile damage, or reducing a damage packet by at least your Proficiency Bonus with Stamina Guard.

Self-inflicted damage, willing-allied movement, harmless falls, and repeated movement against a stationary object cannot generate Momentum.

##### Normalized Procedure — Momentum

- Momentum is a unique scene resource. Record current and maximum Momentum, the round's normal-generation use, and the event that generated each point.
- You cannot exceed maximum Momentum. Excess points are lost. Momentum disappears when the scene ends and is not restored by resting.
- The normal Momentum rules can grant Momentum only once per round, even if one event satisfies several triggers or several qualifying events occur. At CL14, that one normal grant becomes 2 Momentum.
- Voluntary movement requires at least 20 feet of actual distance traveled during your turn. Teleportation is not traveled distance for this trigger. Hostile forced movement or hostile teleportation of at least 10 feet uses the second trigger.
- Qualifying hostile damage requires at least 1 damage after the full damage procedure. A single packet cannot generate a second normal point from both taking damage and using Stamina Guard.
- Reducing a packet by at least Proficiency Bonus with Stamina Guard qualifies even if other reductions also apply. Store the Collision's direct Momentum grant is not a normal grant and can exceed the once-per-round normal-generation limit, subject to maximum Momentum.
- Self-inflicted, willing-allied, staged, harmless, repeated stationary-object, and resource-loop events never qualify.

#### CL3 - Gather and Return

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Momentum  
**Limit:** Once per turn

The attack deals an additional `1d8` Bludgeoning or Force damage, increasing to `2d8` at CL11 and `3d8` at CL17.

Choose one:

- Push the target 5 feet.
- Move 5 feet without provoking Opportunity Attacks.
- Gain +1 AC against the target until the start of your next turn.
- Add 5 feet to the next forced movement you impose before the end of the turn.

##### Normalized Procedure — Gather and Return

- Declare after the unarmed strike hits, spend Momentum, and select the damage type and one option before resolving the rider.
- The additional damage is part of the triggering attack's damage packet and uses the printed scaling.
- A 5-foot push is directly away along a legal route. The 5-foot self-movement is voluntary granted movement after the hit and does not provoke Opportunity Attacks.
- The +1 AC applies only against attacks made by the triggering target and expires at the start of your next turn. Reapplication refreshes and does not stack.
- The forced-movement increase applies to the next forced movement you impose before the end of the same turn. It does not create forced movement, affect teleportation, or stack with another instance from the same activation unless Avalanche Meridian Circuit permits repeated selection.

#### CL6 - Store the Collision

**Reaction**  
**Trigger:** You would be pushed, pulled, thrown, or moved against your will; take falling damage; or take Bludgeoning, Force, or Thunder damage.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Choose one:

- **Store Movement:** Reduce forced movement by up to 15 feet. If reduced to 0, you are not knocked Prone by the same effect and gain 1 Momentum.
- **Store Impact:** Reduce the triggering damage by `2d8 + Constitution modifier`. If reduced to 0, gain 1 Momentum.

Momentum gained through Store the Collision can exceed the normal once-per-round generation limit.

##### Normalized Procedure — Store the Collision

- One triggering event can cause one Reaction and one selected mode, even when it includes both forced movement and qualifying damage.
- **Store Movement** is declared after the movement distance and Prone rider are known but before movement occurs. Reduce the total forced movement by up to 15 feet. If the remaining distance is 0, cancel a Prone rider expressly caused by that same movement and gain 1 Momentum.
- **Store Impact** is declared after Resistance, Vulnerability, and percentage modifiers but before Hit Points are reduced. Apply `2d8 + Constitution modifier` as a flat reduction in the shared damage order. If the final triggering packet is reduced to 0, gain 1 Momentum.
- Store Impact can be combined with Stamina Guard when both are legal. The same packet may grant one direct Momentum from Store Impact and the round's normal Momentum from Stamina Guard if both separate requirements are met.
- Falling damage can trigger Store Impact. A fall cannot use Store Movement unless another rule is moving you against your will rather than gravity merely causing the fall.
- Direct Momentum from this feature can exceed the normal generation limit but not your maximum Momentum.

#### CL10 - Rebounding Assault

**Reaction**  
**Trigger:** A hostile creature within 60 feet moves you, misses you with a melee attack, or damages you with a melee attack.  
**Cost:** 2 Momentum  
**Limit:** Once per round

After the triggering effect resolves, move up to your Speed without provoking Opportunity Attacks. You may move through the triggering creature's space as difficult terrain and must end closer to it.

If you end within unarmed reach, make one unarmed strike. On a hit, deal additional Force damage equal to your Proficiency Bonus and either push the target 10 feet or knock it Prone.

The attack follows the Granted Attack rule.

##### Normalized Procedure — Rebounding Assault

- The trigger occurs after the hostile movement, missed melee attack, or damaging melee attack fully resolves. A single hostile activation can trigger this feature only once.
- Move through the triggering creature's space as difficult terrain only if you have enough movement and can legally pass through its space under this feature. You cannot end in its space.
- Every movement segment must end closer to the triggering creature than the immediately preceding position; the final space must also be closer than your starting space. If no legal closer movement exists, the movement ends.
- The unarmed strike occurs after movement if the target remains within reach. It follows the Granted Attack rule.
- On a hit, Proficiency Bonus Force damage is part of the attack packet. Then choose either a 10-foot push directly away or Prone. No collision damage is created unless another rule expressly supplies it.

#### CL14 - Avalanche Meridian Circuit

Your maximum Momentum becomes `Proficiency Bonus + 3`.

When the normal Momentum rules would grant 1 Momentum, gain 2 instead. A feature directly stating "gain 1 Momentum," such as Store the Collision, still grants exactly 1 unless stated otherwise.

When using Gather and Return, spend between 1 and 3 Momentum. For each Momentum spent, choose one benefit:

- Add one Gather and Return damage die.
- Increase the attack's push by 5 feet.
- Move 5 feet without provoking Opportunity Attacks.

You may choose the same benefit more than once.

##### Normalized Procedure — Avalanche Meridian Circuit

- Replace maximum Momentum with `Proficiency Bonus + 3`.
- The once-per-round normal Momentum grant becomes 2. A feature directly saying “gain 1 Momentum” remains 1 and is not doubled.
- At this level, Gather and Return's cost and option procedure is replaced: spend 1, 2, or 3 Momentum and make one selection for each point spent from the three printed benefits.
- Each damage selection adds one die of Gather and Return's current size (`2d8` at CL14 and `3d8` only when the base feature reaches CL17). Multiple selections add multiple dice.
- The first push selection creates a 5-foot push; each additional push selection adds 5 feet. The push remains directly away unless another rule permits a different direction.
- Each movement selection grants 5 feet of voluntary movement without Opportunity Attacks after the hit. Combine multiple selections into one movement of the total distance or divide them into legal segments during that resolution.
- You may repeat any printed selection. The CL3 +1 AC option is not among Avalanche Meridian Circuit's printed selection list and is unavailable when using this replaced procedure.

#### CL18 - Heaven-Returning Impact

**Action**  
**Requirement:** At least 3 Momentum  
**Cost:** 5 Stamina and all current Momentum  
**Movement:** Up to 120 feet in a straight line

Move to an unoccupied space you can see along the line without provoking Opportunity Attacks. You may move through hostile creature spaces, but not through total cover, a sealed Formation, spatial lock, or solid barrier that survives the damage.

Each creature whose space the line crosses or that is within 5 feet of it makes a Dexterity saving throw.

Damage equals `6d10 Force + 1d10 per Momentum spent`.

- **Failed Save:** Full damage, pushed up to 20 feet perpendicular to the line, knocked Prone, and no Reactions until the start of its next turn.
- **Successful Save:** Half damage, pushed 5 feet, and remains standing.

A creature can take this damage only once per use. Unattended objects, temporary barriers, vehicles, structures, terrain sections, and Formation Anchors take double damage.

If a barrier survives, your movement ends before it and you take Force damage equal to twice your CL. Stamina Guard may reduce this recoil, but no Momentum feature can reduce it or generate Momentum from it.

The destination becomes a 10-foot-radius impact zone of difficult terrain until cleared or repaired.

---

##### Normalized Procedure — Heaven-Returning Impact

- Confirm at least 3 Momentum, choose a visible unoccupied legal destination on a straight line within 120 feet, then pay 5 Stamina and all current Momentum. Record the Momentum spent before rolling damage.
- The line has your normal occupied width unless the map requires a 5-foot-wide line. You travel along it without provoking Opportunity Attacks. Hostile creature spaces are passable; total cover, a surviving solid barrier, sealed Formation, or spatial lock is not.
- Resolve every creature's save once. A creature whose space intersects the line and is also within 5 feet of it still takes damage only once.
- Damage is one `6d10 + 1d10 per Momentum spent` Force packet. On failure, you choose one of the two perpendicular directions and push up to 20 feet along a legal route; on success, push 5 feet in the chosen perpendicular direction.
- Resolve eligible objects, structures, terrain sections, vehicles, barriers, and Formation Anchors as the line reaches them. Apply double damage once. If a solid barrier is destroyed by the activation, movement can continue; if it survives, movement ends in the nearest legal space before it.
- Recoil from a surviving barrier is one Force packet equal to twice your CL. Stamina Guard can reduce it. No Momentum feature can reduce, prevent, redirect, absorb, or generate Momentum from that recoil.
- The destination impact zone consists of the bounded 10-foot radius of ordinary damaged ground. It remains difficult terrain until cleared or repaired under the shared damaged-terrain procedure.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Returning-Heaven Momentum Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 21. Vermilion Gate Guardian Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*I do not chase every enemy. I decide which roads remain open.*

Vermilion Gate disciples cultivate their bodies as living thresholds.

**Access Category:** Open School  
**Primary Identity:** Threshold control, protection, anti-teleportation, interception  
**Common Sphere Synergies:** Guardian, Protection, Ward, Warleader, Wrestling

#### Guarded Threshold

At the start of each of your turns, place one Guarded Threshold on the ground: a straight line up to 15 feet long and 5 feet high with at least one point within your unarmed reach. It lasts until the start of your next turn.

The threshold is visible and is not a solid barrier. Hostile creatures treat its spaces as difficult terrain.

A creature crosses a threshold when any part of its space moves from one side to the other.

##### Normalized Procedure — Guarded Threshold

- At the start of your turn, before taking actions or movement, place or replace the threshold. It requires no action and remains until the start of your next turn.
- Choose two endpoints on the ground no more than 15 feet apart. The straight segment between them is the threshold. At least one point of the segment must be within current unarmed reach when placed.
- The threshold is visible, intangible, and has no Hit Points. It does not block line of sight, line of effect, movement, or attacks except through its printed features.
- The two sides are the half-spaces separated by the vertical plane rising from the line. A creature crosses when any part of its occupied space moves from one side to the other through that plane.
- A creature beginning with space on both sides has not crossed until movement carries its entire space to one side and later back through, or until a new movement segment otherwise satisfies the definition.
- Ordinary movement and forced movement can cross. Teleportation and phasing do not traverse intervening space and are handled only by a feature that expressly governs spatial movement.
- Hostile creatures pay difficult-terrain movement for spaces intersected by the line; a creature pays for each such space only once during one movement segment.

#### CL3 - Guardian at the Gate

**Reaction**  
**Trigger:** A hostile creature crosses your Guarded Threshold.

Make one unarmed strike or melee weapon attack against it before it completes the crossing.

On a hit, its movement ends in the nearest legal space before the threshold, its Speed becomes 0 until the end of the turn, and it cannot take Reactions until the start of its next turn.

A creature can trigger this only once during the same movement. The attack follows the Granted Attack rule.

##### Normalized Procedure — Guardian at the Gate

- Trigger immediately before an ordinary or forced movement segment would complete a crossing. Teleportation, phasing, appearing, or a threshold being placed across a stationary creature does not trigger this Reaction.
- Make exactly one unarmed strike or melee weapon attack against the crossing creature. The attack follows the Granted Attack rule.
- On a miss, the crossing continues. On a hit, finish the attack and its damage, then place the creature in the nearest legal space on the side from which it attempted to cross. End that movement, set every Speed to 0 until the end of the current turn, and deny Reactions.
- If several spaces are equally near, you choose one that does not place the creature across the threshold. If no legal space exists, use Failed Spatial Movement with the status quo on the originating side.
- One creature can trigger Guardian at the Gate only once during one continuous movement, even if its space intersects the threshold repeatedly. A later separate movement can trigger again if you have a Reaction.

#### CL6 - Shelter Behind the Gate

Allies you choose within 5 feet of your threshold gain +1 AC against ranged attacks originating from the opposite side, Advantage against being pushed or pulled across it, and may stand from Prone by spending 5 feet of movement.

**Reaction**  
**Trigger:** A willing ally within 10 feet of the threshold is moved against its will.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Reduce the forced movement by 15 feet. If reduced to 0, the ally is not knocked Prone by the same effect and is moved to the nearest unoccupied space adjacent to the threshold.

##### Normalized Procedure — Shelter Behind the Gate

- Determine “within 5 feet” from the nearest point of the threshold line. Choose allies when each benefit would apply; no action or permanent designation is required.
- A ranged attack originates from the opposite side when the attacker's origin and the target's space are on different sides and the attack line crosses the threshold. The +1 AC applies only against that attack and does not stack from two thresholds.
- Advantage applies to checks and saves directly resisting a push or pull that would cross the threshold. It does not affect teleportation, phasing, or forced movement remaining on the same side.
- Standing from Prone for 5 feet of movement still requires the ally to have at least 5 feet of movement available and be physically capable of standing.
- For the Reaction, the willing ally must be within 10 feet of at least one threshold when the forced movement is declared. Reduce the complete forced movement distance by 15 feet before placement.
- If reduced to 0, cancel only a Prone rider caused by that same movement and place the ally in the nearest unoccupied legal space adjacent to the chosen threshold on either side. If several are equally near, the ally chooses.

#### CL10 - Twin Guardian Posts

You may maintain two Guarded Thresholds simultaneously. Each must have at least one point within 15 feet of you when placed.

When Guardian at the Gate hits, choose one additional result:

- Push the creature 10 feet away from the threshold.
- Knock it Prone.
- Deal an additional `2d8` Force damage.
- Mark it until the start of your next turn; it has Disadvantage on attacks against creatures other than you.

You still have only your normal number of Reactions.

##### Normalized Procedure — Twin Guardian Posts

- At the start of your turn, place up to two thresholds. Each is a separate line and must have at least one point within 15 feet of you when placed. Both expire at the start of your next turn.
- The lines may intersect, share an endpoint, or overlap, but overlapping sections do not multiply difficult terrain, AC, cover, saves, or trigger frequency.
- A crossing that intersects both thresholds can trigger Guardian at the Gate only once from that movement because you still resolve one Reaction and one attack.
- After Guardian at the Gate hits, choose exactly one additional result. Force damage is part of the attack packet. The push is away from the crossed threshold's plane along a legal route. The mark refreshes rather than stacks and affects attack rolls only.
- This feature grants no additional Reaction. An extra Reaction from another rule does not remove Guardian at the Gate's one-trigger-per-continuous-movement rule.

#### CL14 - Threshold Between Worlds

Your thresholds become 10 feet high.

When a hostile creature attempts to teleport, phase, or use spatial movement across one, it makes a Cultivation Check against your Cultivation Save DC.

- **Success:** The movement resolves.
- **Failure:** Use the Failed Spatial Movement rule.

Ranged attacks crossing a threshold grant Half Cover to a target within 5 feet of it. This does not stack with other Half Cover.

##### Normalized Procedure — Threshold Between Worlds

- A hostile spatial movement attempts to cross when its origin and intended destination are on opposite sides of a threshold and the shortest conceptual route would pass through its vertical plane.
- Resolve one Cultivation Check against your Cultivation Save DC before placing the creature at the destination. On success, the movement resolves. On failure, use Failed Spatial Movement; the creature remains at the nearest legal status-quo position on the origin side unless the governing effect specifies another failure result.
- One spatial movement crossing two of your thresholds makes one check, not two. Separate activations make separate checks.
- For ranged attacks, trace the attack line from origin to target. If it crosses a threshold and the target is within 5 feet of that threshold, the target has Half Cover. Multiple thresholds and other Half Cover do not stack; use the greatest applicable cover.
- The thresholds remain intangible and do not block an effect that neither uses an attack roll nor is expressly affected by cover, unless another feature says otherwise.

#### CL18 - Heaven's Closed Gate

**Action**  
**Area:** 30-foot-radius, 30-foot-high cylinder centered on you  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

A vast threshold manifests around the boundary. You and chosen allies cross freely.

A hostile creature attempting to cross makes a Strength or Charisma saving throw, its choice.

- **Failed Save:** Movement ends at the boundary, Speed becomes 0 for the turn, it takes `4d8` Force damage, and cannot attempt to cross again that turn.
- **Successful Save:** It crosses, but the boundary is difficult terrain for that movement.

A hostile teleport or phase attempt instead uses the Cultivation Check and Failed Spatial Movement rules.

Ranged attacks and effects crossing the boundary grant Three-Quarters Cover to targets inside.

Four visible anchor posts appear at cardinal points. Each has AC equal to your Cultivation Save DC, Hit Points `3 x CL`, Resistance to Bludgeoning, Piercing, Slashing, and Force, and Immunity to Poison and Psychic. Destroying two reduces protection to Half Cover; destroying all four ends the Gate.

You may maintain only one Heaven's Closed Gate.

---

##### Normalized Procedure — Heaven's Closed Gate

- When activated, choose the point at the center of your current space. The cylinder and anchor posts are stationary at that point for the duration; they do not move when you move.
- Choose any number of willing allies you can perceive when activating the Gate. You and those allies cross freely. A creature not chosen is treated according to its current hostility and the feature's normal crossing procedure.
- The boundary is the cylinder's vertical outer surface and top. A hostile creature crosses when ordinary movement would take any part of its space from outside to inside or inside to outside through that surface.
- On a failed Strength or Charisma save, place the creature in the nearest legal space on the side where the attempt began, deal `4d8` Force damage, set Speed to 0 for the turn, and prevent another crossing attempt that turn. On success, it crosses; movement through the boundary costs double as difficult terrain for that crossing.
- Hostile teleportation, phasing, and other spatial movement across the boundary use one Cultivation Check and Failed Spatial Movement instead of the Strength or Charisma save.
- Three-Quarters Cover applies only to a target inside when an attack or cover-sensitive effect originates outside and crosses the boundary. Destroying two posts changes this to Half Cover. Destroying all four ends the complete Gate, including crossing restrictions and spatial checks.
- The four posts are visible projected Body Anchors at the cardinal boundary points. Each is a discrete Medium object that does not occupy its space, can attach to ground or a solid surface, and has the printed AC, Hit Points, Resistances, and Immunities. They cannot act, move, attack, or be harvested.
- A post reduced to 0 Hit Points is destroyed. Excess damage does not transfer to you or another post. Healing a post requires a feature that can repair Body Assets or cultivation Anchors and cannot restore a destroyed post during the same activation unless expressly permitted.
- If terrain makes an exact cardinal point impossible, place the post at the nearest point on the boundary with line of effect to the center. This does not change the cylinder's area.
- You may maintain only one Heaven's Closed Gate. A new activation ends the previous one without refunding costs.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a breath, roar, projected medium, threshold, Asset, Field, or spatial exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, mark, threshold, Anchor, or environmental effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, threshold, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, Momentum, or an expended scene limit.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, and environmental result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, teleportation, phasing, and forced movement must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, possession, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, additional anatomy, flight mode, threshold, projected body, Momentum state, or environmental effect grants only the attacks, movement, actions, and Reactions printed by the feature.

### Integrated Procedure Closure — Vermilion Gate Guardian Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 22. White-Heron Crescent Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The long blade does not guard one point. It teaches the battlefield where its edge may pass.*

White-Heron disciples cultivate balance, sweeping movement, long-weapon control, and precise changes of distance.

**Access Category:** Open School  
**Primary Identity:** Polearm mastery, sweeping attacks, reach control, graceful movement  
**Common Sphere Synergies:** Athletics, Fencing, Flowing River, Guardian, Wind

#### CL3 - Crescent-Body Integration

Gain proficiency with Polearm weapons.

While wielding one:

- Use Constitution instead of Strength or Dexterity for attack and damage rolls.
- You may use your Cultivation Attack Modifier for attack rolls.
- It is integrated into Body Refining.
- Its reach increases by 5 feet during your turn.
- Refined Iron Fist and Heavenly Fist apply to it.

This does not grant a weapon Sphere.

##### Heron's Passing Cut

**Trigger:** You hit with a Polearm after moving at least 10 feet during the turn.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Choose one:

- Move 10 feet without provoking Opportunity Attacks.
- Push the target 10 feet.
- Pull it 5 feet into an unoccupied space within reach.
- Deal an additional `1d8` Slashing or Force damage, increasing to `2d8` at CL11 and `3d8` at CL17.

##### Normalized Procedure — Crescent-Body Integration and Heron's Passing Cut

- Record the wielded Polearm as an integrated weapon. Constitution replaces Strength or Dexterity for its attack and damage rolls, and you may use your Cultivation Attack Modifier for its attack rolls. This integration grants no Sphere, talent, ammunition, additional attack, or separate weapon instance.
- Refined Iron Fist and Heavenly Fist apply only to the extent those features expressly modify an integrated weapon. If several rules replace the same weapon damage die, use the highest legal replacement rather than adding several weapon dice.
- The 5-foot reach increase applies only during your own turn. Outside your turn, use the Polearm's printed reach plus any currently active persistent reach increase. At CL14, the two turn-only increases combine for +10 feet during your turn.
- Heron's Passing Cut checks actual voluntary movement completed during the current turn before the hit. Teleportation does not count. Forced movement counts only when you willingly directed or accepted it and the movement rule says it counts as your movement.
- Declare Heron's Passing Cut after the hit is confirmed, pay 1 Stamina, and choose exactly one result. The feature remains once per turn across all Polearm attacks.
- The 10-foot self-movement is voluntary granted movement, follows a legal route, and does not provoke Opportunity Attacks. The push moves directly away from you. The pull must end in an unoccupied space within your current Polearm reach and cannot pull the target through a solid obstruction.
- The additional damage is part of the triggering hit's damage packet, uses Slashing or Force as chosen when applied, and uses only the scaling appropriate to your current CL.

#### CL6 - One-Legged Guard

**Reaction**  
**Trigger:** A creature within your weapon's reach makes a melee attack against you or a creature adjacent to you.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Make one Polearm attack before its attack resolves.

On a hit, choose one:

- Subtract your Proficiency Bonus from the triggering attack roll.
- Move the protected creature 5 feet without provoking Opportunity Attacks.
- Push the attacker 5 feet.
- Prevent the attacker from taking Reactions until the start of its next turn.

If moved outside its reach, the triggering attack misses. The granted attack follows the Granted Attack rule.

##### Normalized Procedure — One-Legged Guard

- Declare after the attacker chooses its target and commits to the melee attack but before the triggering attack roll. Spend the Reaction and Stamina, then resolve the granted Polearm attack first.
- “Within your weapon's reach” uses the reach that applies outside your turn. Turn-only reach increases do not apply. A persistent reach increase, such as the guarded stance from Moon over the Reed Sea, does apply.
- If your Polearm attack misses, the triggering attack resolves unchanged. On a hit, choose exactly one printed result before the triggering attack roll.
- Subtracting Proficiency Bonus modifies the triggering attack roll only. It does not reduce damage or affect later attacks.
- Moving the protected creature requires a legal 5-foot destination. A conscious unwilling creature can decline that movement; if it declines, choose another result. The movement does not provoke Opportunity Attacks.
- Pushing the attacker is forced movement directly away from you. After either movement result, recheck the triggering attack's reach and legal target. If its target is no longer within reach, the triggering attack misses without an attack roll.
- Reaction denial begins after your Polearm attack hits and lasts until the start of the attacker's next turn. It does not cancel a Reaction already spent before this feature resolved.
- The granted attack cannot grant another attack and remains subject to the once-per-round limit.

#### CL10 - Crescent Reaping Circle

When you take the Attack action with a Polearm, replace one attack with a sweeping cut.

**Area:** Every hostile creature of your choice within your weapon's reach  
**Cost:** 2 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Dexterity

On a failed save, a target takes one weapon damage die + Constitution modifier + `3d8` Slashing or Force damage, and you either push it 5 feet or prevent Reactions until the start of its next turn.

On a successful save, it takes half damage and suffers no additional effect.

After the sweep, move up to 10 feet without provoking Opportunity Attacks.

This is not a weapon attack and does not apply attack-hit riders.

##### Normalized Procedure — Crescent Reaping Circle

- Replace one attack of the Attack action before making that attack. The sweep is one Body technique, not a weapon attack, and affects each chosen hostile creature within your current Polearm reach at the moment the sweep resolves.
- Each target makes one Dexterity save and is affected once even if it occupies several spaces. Cover and line of effect are checked from you through the Polearm's physical sweep.
- The damage uses one damage die of the integrated Polearm, adds Constitution modifier once, and adds `3d8` Slashing or Force as chosen for that activation. It does not apply critical hits, attack-hit riders, weapon mastery riders, or effects requiring a weapon attack to hit.
- On a failed save, choose push or Reaction denial separately for each target. A push is 5 feet directly away from you and stops at the nearest legal space. On a successful save, the target takes half total damage and no rider.
- Resolve all saves, damage, and forced movement before taking the printed 10-foot self-movement. That movement is voluntary granted movement, follows a legal route, and does not provoke Opportunity Attacks.
- The sweep remains once per turn even if another feature grants additional Attack actions or replacement attacks.

#### CL14 - White Wing Crosses the Reed Field

Your Polearm reach increases by another 5 feet during your turn.

Once during each of your turns, after hitting a creature with a Polearm, move through that creature's space as difficult terrain without provoking its Opportunity Attacks, up to half your Speed, ending in an unoccupied space.

When you leave its space, choose one:

- Make one Polearm attack against a different creature within reach.
- Push the original creature 10 feet.
- Knock the original creature Prone if it fails a Strength saving throw.
- Gain +2 AC until the start of your next turn.

The additional attack follows the Granted Attack rule.

##### Normalized Procedure — White Wing Crosses the Reed Field

- The additional 5-foot reach increase is turn-only and combines with Crescent-Body Integration for a total +10 feet during your turn. It does not enlarge threatened space outside your turn.
- Trigger after a Polearm hit once during your turn. The movement occurs after that hit resolves and can pass through the triggering creature's occupied space as difficult terrain. It cannot pass through total cover, a solid obstruction, or a space too small for your body.
- Move no more than half your current Speed and end in an unoccupied legal space. This movement does not provoke Opportunity Attacks from the triggering creature; other creatures interact with it normally.
- Choose one printed result after reaching the destination. The additional Polearm attack must target a different creature currently within reach and follows the Granted Attack rule.
- The 10-foot push moves the original creature directly away from your final position unless no legal route exists. The Prone option calls for one Strength save after your movement; on a success, the creature remains standing.
- The +2 AC begins after the movement and lasts until the start of your next turn. It is an AC bonus and does not replace your AC formula.
- If you cannot complete at least 5 feet of legal movement through the triggering creature's space, you do not gain a chosen ending result.

#### CL18 - Moon over the Reed Sea

**Action**  
**Movement:** Up to twice your Speed  
**Cost:** 7 Stamina  
**Limit:** Once per scene

Move without provoking Opportunity Attacks. You may cross liquids and vertical surfaces and move through hostile spaces as difficult terrain, but not through solid barriers, total cover, or spaces too small for you.

Choose any number of hostile creatures that come within Polearm reach. Each makes a Dexterity saving throw and can be affected only once.

- **Failed Save:** `10d8` Slashing or Force damage, pushed up to 15 feet, and no Reactions until the end of its next turn.
- **Successful Save:** Half damage, pushed 5 feet, and no Reactions until the start of its next turn.

When movement ends, enter a guarded stance until the start of your next turn: +2 AC, reach increased by 5 feet, and the first hostile creature entering your reach provokes one Opportunity Attack that does not consume your Reaction. This strike can occur only once and follows the Granted Attack rule.

##### Normalized Procedure — Moon over the Reed Sea

- Choose a continuous route no longer than twice your current Speed. This is voluntary movement, not teleportation. It ignores Opportunity Attacks and permits movement across liquids, vertical surfaces, and hostile spaces as printed, but still requires line of travel and sufficient space for your body.
- Moving across a liquid or vertical surface does not grant lasting flight. If the movement ends unsupported, resolve falling after the feature finishes unless another rule supports you.
- A hostile creature becomes eligible the first time during this activation any part of its space comes within your current Polearm reach. It can be affected only once. A surviving solid barrier or total cover blocks the physical sweep beyond it.
- Resolve a target's save when it first becomes eligible. On a failure, choose Slashing or Force damage for that target, then choose a legal push distance up to 15 feet directly away from your position at that moment. On success, push exactly 5 feet if a legal space exists.
- Reaction denial applies for the printed duration regardless of whether the push is shortened or prevented. Forced movement cannot place a target in an illegal space.
- After all movement and target resolutions, enter the guarded stance. Its +2 AC and +5-foot reach are persistent until the start of your next turn and therefore enlarge your threatened space during that interval.
- The stance's reaction-free Opportunity Attack can occur once. It triggers only when a hostile creature physically enters that reach after the stance begins; expanding your reach around a stationary creature does not count as entry. The attack follows the Granted Attack rule and cannot generate another attack.

---

## Additional Restricted Scriptures

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — White-Heron Crescent Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 23. Sun-Piercing Bow Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The arrow leaves the string. My body has already reached the target.*

Sun-Piercing disciples refine the spine, shoulders, fingers, eyes, and breath into a single weapon.

**Access Category:** Restricted Scripture  
**Primary Identity:** Ranged martial cultivation, immense draw strength, piercing shots, battlefield lines  
**Common Sphere Synergies:** Archery, Athletics, Force, Light, Radiance, Sun, Wind

#### CL3 - Bow Body

Gain proficiency with Bow weapons.

While wielding a Bow:

- Use Constitution instead of Dexterity for attack and damage rolls.
- It is integrated into Body Refining.
- You may use your Cultivation Attack Modifier.
- Being within 5 feet of a hostile creature does not impose Disadvantage on your Bow attacks.
- Drawing or firing requires only the hands required by the weapon.

At CL5, the attacks count as magical; at CL17, magical and adamantine.

This does not grant the Archery Sphere.

##### Normalized Procedure — Bow Body

- Record each wielded Bow used with this feature as an integrated weapon. Constitution replaces Dexterity for its attack and damage rolls, and you may use your Cultivation Attack Modifier for attack rolls.
- This feature grants proficiency but does not grant the Archery Sphere, ammunition, a free Bow, an ammunition-creation effect, additional attacks, or permission to ignore loading, reload, draw-weight, or special ammunition rules printed by a specific weapon.
- Being within 5 feet of a hostile creature does not impose Disadvantage on your Bow attacks. Other sources of Disadvantage remain.
- “Drawing or firing requires only the hands required by the weapon” means the weapon uses its own printed hand requirement and no additional free hand is required solely to draw ordinary ammunition. It does not permit firing while a required hand is disabled, occupied, severed, or suppressed.
- The CL5 and CL17 classifications apply to attacks made with an integrated Bow. They do not transform the physical Bow or its ammunition into an adamantine object for harvesting, crafting, or nonattack interaction.
- If another feature replaces the Bow's damage die, use the highest legal replacement unless a rule explicitly adds a separate die.

#### CL6 - Meridian Overdraw

**Trigger:** You hit with a Bow attack.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Deal an additional `2d8` Piercing or Force damage, increasing to `3d8` at CL11 and `4d8` at CL17.

The target makes a Strength saving throw.

- **Failed Save:** Push it 10 feet, prevent Reactions until the start of its next turn, reduce Speed by 15 feet until then, or move yourself 10 feet without provoking Opportunity Attacks.
- **Successful Save:** Push it 5 feet or move yourself 5 feet without provoking Opportunity Attacks.

##### Normalized Procedure — Meridian Overdraw

- Declare after a Bow attack hits, pay 1 Stamina, and add the appropriate Piercing or Force dice to that hit. The added damage is part of the triggering damage packet and cannot critically multiply separately.
- The target makes the Strength save after damage is resolved. On failure, choose one of the four failed-save results; on success, choose push or self-movement as printed.
- A push moves the target directly away from the projectile's origin along a legal route. If the full distance is blocked, move it as far as legally possible.
- Speed reduction and Reaction denial begin after the save and last until the start of the target's next turn. The Speed reduction does not stack with another Meridian Overdraw from you; reapplication refreshes it.
- Your self-movement is voluntary granted movement, follows a legal route, and does not provoke Opportunity Attacks. It occurs after the target's result resolves and cannot pass through a solid barrier or occupied space.
- Meridian Overdraw remains once per turn across every Bow attack, granted attack, and additional Attack action.

#### CL10 - Sky-Pinning Arrow

**Action**  
**Range:** The Bow's long range  
**Cost:** 3 Stamina

Make one Bow attack.

On a hit, deal normal damage plus `5d8` Piercing or Force damage. The target makes a Strength saving throw.

- **Failed Save:** Until the start of your next turn, its Speed becomes 0, it cannot teleport or willingly leave its space, and cannot benefit from movement granted by an ally.
- **Successful Save:** Its Speed is halved until the start of your next turn.

Hostile forced movement still functions. The restrictions apply to incorporeal creatures unless they are immune to movement suppression.

##### Normalized Procedure — Sky-Pinning Arrow

- The Action includes one Bow attack. Use the Bow's printed long range, line of effect, ammunition requirement, and any Disadvantage that normally applies at long range. Bow Body removes only the close-hostile-creature Disadvantage.
- Spend Stamina when the Action is declared. On a miss, no additional damage or movement suppression occurs.
- On a hit, normal Bow damage and the additional `5d8` form one damage event, then the target makes the Strength save.
- On a failed save, create one **Sky-Pinned** state lasting until the start of your next turn. Its Speed is 0; it cannot use voluntary movement, activate teleportation, willingly change spaces, or accept movement granted by an ally.
- Hostile forced movement, involuntary teleportation, falling, a collapsing surface, or movement imposed by an enemy remains legal. Such movement does not end Sky-Pinned; the target's Speed remains 0 afterward.
- On a successful save, halve every Speed the target currently has, rounding down, until the start of your next turn. A newly gained Speed is also halved while the state lasts.
- Incorporeal movement is suppressed only as printed. A creature explicitly immune to movement suppression ignores the movement restrictions but still takes the attack's damage.
- Sky-Pinning Arrow is not a Grapple, Anchor, or anatomical Injury and does not pin the target to a specific object unless another rule explicitly does so.

#### CL14 - Sun-Chasing Line

When you take the Attack action with a Bow, replace one attack with a line.

**Area:** 120-foot-long, 5-foot-wide line  
**Cost:** 2 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Dexterity

On a failed save, a creature takes one Bow weapon damage die + Constitution modifier + `4d8` Piercing or Force damage. On a successful save, it takes half damage.

The line passes through creatures and stops at an object, barrier, or structure that survives the damage. Unattended ordinary objects, temporary barriers, vehicles, structures, and Formation Anchors take double damage.

Sun-Chasing Line is not an attack and does not apply attack-hit riders.

##### Normalized Procedure — Sun-Chasing Line

- Replace one attack of the Attack action and choose a point up to 120 feet away, creating a 5-foot-wide line from the Bow to that point. The line requires line of effect and is not a weapon attack.
- Choose Piercing or Force for the activation. Each creature in the line makes one Dexterity save and is affected once. Damage uses one damage die of the integrated Bow, Constitution modifier once, and `4d8` of the chosen type.
- The line does not apply critical hits, attack-hit riders, ammunition riders, weapon mastery riders, or effects requiring a Bow attack to hit.
- Resolve targets and obstructions from nearest to farthest. Creatures do not stop the line. When the line reaches an object, barrier, structure, vehicle, or Formation Anchor, apply its damage once and double the final damage if the target is an eligible unattended or listed target.
- If that obstruction is reduced to 0 Hit Points or otherwise destroyed by this activation, the line continues. If it survives and physically blocks the line, creatures and objects beyond it are not affected.
- Worn, carried, wielded, piloted, or actively controlled objects are not unattended. A target belonging to several doubled categories receives the multiplier once.
- Half and Three-Quarters Cover apply normally unless the line's path physically bypasses that cover. Total cover from a surviving obstruction stops the line.

#### CL18 - Star-Piercing Shot

**Action**  
**Area:** 300-foot-long, 10-foot-wide line  
**Cost:** 8 Stamina  
**Limit:** Once per scene  
**Saving Throw:** Dexterity

On a failed save, a creature takes `12d10` Piercing or Force damage; on a success, half.

The shot:

- Ignores Half and Three-Quarters Cover.
- Ignores ordinary Resistance to Piercing and Force.
- Deals double damage to unattended objects, vehicles, structures, temporary barriers, and Formation Anchors.
- Passes through any creature or object reduced to 0 Hit Points.
- Ends at maximum range or at a surviving barrier that blocks cultivation attacks.

It does not automatically ignore Immunity, higher-CL permanent barriers, Immortal defenses, or artifact protections.

##### Normalized Procedure — Star-Piercing Shot

- Choose a point up to 300 feet away and form a 10-foot-wide line from the Bow. The Action is a Body technique, not a weapon attack, and does not require an attack roll or apply attack-hit riders.
- Choose Piercing or Force for the activation. Every creature in the line makes one Dexterity save and is affected once. Half and Three-Quarters Cover provide no bonus; total cover and a surviving cultivation-blocking barrier still stop the line.
- “Ignores ordinary Resistance” means Resistance from mundane material, ordinary creature traits, and lower-authority effects does not halve this damage. Immunity, artifact protection, divine authority, Secret effects, Immortal defenses, and equal- or higher-Source-CL specific barriers retain their printed authority.
- Resolve targets and obstructions from nearest to farthest. Creatures and objects reduced to 0 Hit Points do not stop the line. A surviving barrier, object, structure, vehicle, or Anchor stops it only if that target physically blocks cultivation attacks.
- Eligible objects, vehicles, structures, temporary barriers, and Formation Anchors take double damage once. Damage Thresholds and Immunities remain unless this feature expressly bypasses them.
- The shot creates no lingering tunnel, light beam, environmental hazard, ammunition object, or permanent opening after the activation ends.
- Spending the scene use and Stamina occurs when the Action is declared even if every target succeeds or a surviving barrier ends the line early.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Sun-Piercing Bow Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 24. Hundred-Venom Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*What enters my blood becomes mine. What leaves it becomes death.*

Hundred-Venom disciples refine poisons, diseases, corrosive medicines, and hostile substances inside their organs and meridians.

**Access Category:** Restricted Scripture  
**Primary Identity:** Poison resistance, venomous strikes, toxin adaptation, bodily contamination  
**Common Sphere Synergies:** Alchemy, Blood, Flesh, Life, Medicine, Poison, Predator

#### CL3 - Venom Furnace

Gain Resistance to Poison damage and Advantage on saving throws against Poisoned and disease. Your unarmed strikes may deal Poison damage.

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Deal an additional `2d6` Poison damage. The target makes a Constitution saving throw. On a failure, it is Poisoned until the start of your next turn.

This venom requires no external poison.

##### Normalized Procedure — Venom Furnace

- Resistance, saving-throw Advantage, and disease protection apply only to the listed damage, condition, and disease categories. They do not automatically apply to Acid, curses, parasites, spiritual contamination, Hidden Injuries, or effects merely described as toxic.
- On each unarmed strike, you may replace every ordinary damage type of that strike with Poison. This changes damage type only; it does not add damage or create an external poison item.
- Declare Venom Furnace after an unarmed strike hits, spend 1 Stamina, and add `2d6` Poison damage. The added damage is part of the triggering hit and cannot critically multiply separately.
- The Constitution save occurs after damage. On failure, the target becomes Poisoned until the start of your next turn. Reapplying the same Poisoned duration refreshes it and does not create several conditions.
- The venom is generated by your body, needs no ammunition or dose, cannot be harvested through ordinary collection, and expires without creating a persistent environmental poison unless another feature expressly permits it.
- Before CL18, Poison Immunity and Resistance function normally against this feature.

#### CL6 - Swallow the Poison

**Reaction**  
**Trigger:** You take Acid or Poison damage, fail a saving throw against poison or disease, or would become Poisoned.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Choose the matching response:

- Reduce Acid or Poison damage by `2d10 + Constitution modifier`.
- Add your Proficiency Bonus to the failed saving throw, potentially turning it into a success.
- Delay Poisoned until the end of your next turn.

If you take no Poison damage, succeed on the save, or avoid Poisoned, your next Venom Furnace before the end of your next turn deals additional Poison damage equal to your Proficiency Bonus.

This cannot remove a Hidden Injury, Foundation Burden, permanent disease, Tribulation effect, curse, or poison requiring a special cure.

##### Normalized Procedure — Swallow the Poison

- Use the Reaction for one triggering damage packet, one failed save, or one impending application of Poisoned. If one event satisfies several triggers, choose one response.
- For Acid or Poison damage, declare after Resistance and Vulnerability are applied but before Hit Points are reduced. Reduce only the matching Acid or Poison portion by `2d10 + Constitution modifier`, then continue the ordinary damage procedure.
- For a failed saving throw, declare after the total is known but before consequences are finalized. Add Proficiency Bonus to that roll; if the new total meets the DC, treat the save as successful.
- To delay Poisoned, declare before the condition begins. The condition does not apply until the end of your next turn. If its source would have ended before that time, it never begins; otherwise it begins then for the remaining printed duration. Delay is not removal and does not by itself count as avoiding Poisoned.
- You gain the Venom Furnace bonus only if the chosen response causes you to take 0 matching Poison damage, changes the failed save to a success, or prevents Poisoned from ever beginning. Merely delaying the condition does not qualify unless the source expires during the delay.
- Record one stored adaptation. Your next Venom Furnace before the end of your next turn gains additional Poison damage equal to Proficiency Bonus. A new stored adaptation refreshes this window; it does not stack several bonuses.
- The exclusions for Hidden Injuries, Foundation Burdens, permanent disease, Tribulations, curses, and special-cure poisons apply even when the immediate damage or condition is reduced.

#### CL10 - Three Sovereign Venoms

When a creature fails its Venom Furnace save, choose one unique state until the end of your next turn:

- **Nerve Venom:** No Reactions and Disadvantage on its next attack roll.
- **Blood Venom:** Takes `2d6` Poison damage at the start of its next turn.
- **Marrow Venom:** Speed reduced by 15 feet and Disadvantage on its next Strength or Dexterity saving throw.

Only one Sovereign Venom from you can affect a creature. Reapplication replaces it.

##### Normalized Procedure — Three Sovereign Venoms

- Choose a Sovereign Venom only when a target fails the Venom Furnace Constitution save. The chosen state uses Venom Furnace's Source CL and lasts until the end of your next turn unless its own operation resolves earlier.
- **Nerve Venom:** Reaction denial begins immediately. Disadvantage applies to the target's next attack roll during the duration and is consumed after that roll.
- **Blood Venom:** At the start of the target's next turn, it takes one `2d6` Poison damage packet, then Blood Venom ends. If the state is removed before that turn, the damage does not occur.
- **Marrow Venom:** Reduce every Speed by 15 feet, to a minimum of 0. When applied, choose Strength or Dexterity; the target has Disadvantage on its next saving throw of that type during the duration, then consumes the effect.
- A creature can bear only one Sovereign Venom from you before CL18. Applying a new one replaces the previous state after the new save fails. It does not preserve the previous state's unspent rider.
- A Sovereign Venom is a bodily poison effect, not an anatomical Injury, destroyed organ, disease, curse, or independently harvestable dose.

#### CL14 - Poisoned Body, Poisoned World

Your Poison damage ignores Resistance.

Once per round, after a hostile creature within reach damages you, Grapples you, or begins its turn Grappling you, spend 1 Stamina without using an action. It makes a Constitution saving throw.

- **Failed Save:** `3d8` Poison damage and one Sovereign Venom.
- **Successful Save:** Half damage and no Venom.

This resolves after the triggering damage or Grapple.

##### Normalized Procedure — Poisoned Body, Poisoned World

- Ignoring Poison Resistance applies to Poison damage from your Body Refining features only. It does not affect another creature's poison, a Sphere technique, an item, or environmental poison unless that effect expressly uses this feature.
- Once per round, after a hostile creature within your current unarmed reach damages you, successfully Grapples you, or starts its turn while maintaining a Grapple on you, you may spend 1 Stamina without an action. You must be able to spend Stamina and perceive or identify the qualifying creature.
- The feature resolves after the triggering damage or Grapple state. If the triggering event moves the creature outside your reach before resolution, it is no longer a legal target.
- The target makes one Constitution save. On failure, it takes `3d8` Poison damage and you choose one Sovereign Venom; on success, it takes half damage and gains no Venom.
- One creature cannot trigger several uses from the same event, and the feature remains once per round even if several creatures damage or Grapple you.
- Damage from this feature cannot trigger another copy of Poisoned Body, Poisoned World or count as a hostile poison source for your own Swallow the Poison.

#### CL18 - Myriad-Venom Immortal

Gain Immunity to Poison damage, Poisoned, and ordinary disease.

When one of your Body Refining features deals Poison damage, Poison Immunity is treated as Resistance, then your feature ignores that Resistance. The damage cannot be converted into healing unless a feature explicitly consumes hostile poison.

Venom Furnace deals `4d6` additional Poison damage.

On a failed save, choose two different Sovereign Venoms. On a successful save, the target still suffers one Venom until the start of its next turn but takes no extra effect beyond the Venom's printed rule.

##### Normalized Procedure — Myriad-Venom Immortal

- Poison Immunity, Poisoned Immunity, and immunity to ordinary disease are bodily traits. “Ordinary disease” excludes Tribulation diseases, curses, Foundation afflictions, Secret plagues, conceptual contamination, and effects with explicit higher authority.
- When one of your Body Refining features deals Poison damage, resolve a target's Poison Immunity as Resistance, then apply your feature's Resistance-ignoring rule. The result is normal Poison damage. This conversion applies only to your Body Refining Poison damage and does not suppress unrelated immunity benefits.
- The damage cannot heal, restore resources, feed an Asset, or become a beneficial intake unless a Source Rule explicitly consumes hostile poison and names this interaction.
- Venom Furnace's additional damage becomes `4d6`; this replaces its former `2d6`, not adds to it.
- On a failed Venom Furnace save, choose two different Sovereign Venoms. Both coexist despite the normal one-Venom limit and use the same duration. On a successful save, choose one Sovereign Venom; the target is not Poisoned by Venom Furnace, but it suffers that one Venom until the start of its next turn.
- Reapplication can replace either or both current Venoms. A named Venom from you never stacks with another copy of itself.
- Myriad-Venom Immortal does not grant authority to poison souls, memories, Foundations, artifacts, Domains, or conceptual entities unless another Source Rule makes them legal poison targets.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Hundred-Venom Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 25. Eight Gates of the Heaven-Defying Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The body was built with limits. Limits are only doors that have not been opened.*

The Eight Gates Scripture forces the body beyond safe circulation. Each Gate releases more speed, strength, and cultivated violence while inflicting unavoidable internal damage.

**Access Category:** Restricted Scripture  
**Primary Identity:** Escalating bodily overclock, extreme speed, additional attacks, dangerous self-damage  
**Common Sphere Synergies:** Athletics, Berserker, Blood, Brute, Force, Lightning, Yang

#### Gate Rules

Once per scene, open your Gates as a Bonus Action.

- Spend 1 Stamina for each Gate opened.
- Open any number up to your current maximum.
- Benefits are cumulative.
- At the start of each of your turns, before opening additional Gates, take `1d4` Force damage for each Gate already open.
- This damage cannot be reduced, prevented, redirected, converted, or absorbed; does not trigger Stamina Guard; and does not count as hostile damage.
- At that same start-of-turn point, after taking Gate damage, you may open additional unlocked Gates by spending 1 Stamina each without using an action. Newly opened Gates begin dealing damage at the start of your next turn.
- Close all Gates as a Bonus Action.
- Once all Gates close, willingly or otherwise, they cannot reopen until a new scene begins.

##### Normalized Procedure — Gate State

- Opening the Gates creates one scene state with a recorded **highest open Gate**. Every lower-numbered Gate is also open; Gates cannot be skipped. Your maximum is Gate 2 at CL3, Gate 4 at CL6, Gate 5 at CL10, Gate 7 at CL14, and Gate 8 at CL18.
- The once-per-scene Bonus Action begins the state and may open any unlocked number in ascending order. Pay 1 Stamina for each newly opened Gate. At the printed start-of-turn timing, after Gate damage, you may increase the highest open Gate and pay the same cost without an action.
- At the start of each turn, count the Gates that were open before that turn began. Take one `1d4` Force damage per open Gate, or `1d6` per open Gate while Gate 8 is open. Newly opened Gates do not contribute until the next turn.
- Gate damage is applied directly to Hit Points. Temporary Hit Points cannot absorb it, and it cannot be reduced, prevented, redirected, converted, delayed, shared, or used as a trigger for Stamina Guard, pain intake, predatory healing, hostile-damage features, or similar effects.
- Closing all Gates is a Bonus Action. All Gates also close when the scene ends, you die, you become Unconscious, or your Body Refining cultivation is completely suppressed. Once closed for any reason, they cannot reopen until a new scene.
- Feature-specific Realm Suppression that removes access to a higher Gate closes that Gate and every Gate above the highest one you can currently sustain. This is a closure, not dormancy, and the lost Gates cannot reopen during that scene.
- Gate benefits are cumulative and remain active only while their Gate is open. Closing a Gate removes its benefits immediately and does not refund Stamina or Gate damage.
- If Gate damage reduces you to 0 before CL18 or while Gate 8 is not open, resolve ordinary 0-Hit-Point procedures after all Gates close. The special stable collapse applies only when Gate 8 is open and its Gate damage caused the reduction.

#### CL3 - First and Second Gates

You may open two Gates.

- **First Gate - Gate of Breath:** Speed increases by 10 feet.
- **Second Gate - Gate of Blood:** Once per turn when you hit with an unarmed strike, deal additional damage equal to your Proficiency Bonus.

##### Normalized Procedure — First and Second Gates

- Gate of Breath adds 10 feet to walking Speed. Any movement mode explicitly equal to walking Speed updates from that value; fixed movement modes and teleport ranges do not.
- Gate of Blood's additional damage applies once per turn after an unarmed strike hits. It is part of that hit's damage packet, uses one damage type dealt by the strike as chosen by you, and cannot critically multiply separately.
- The once-per-turn Gate of Blood damage remains one total use across granted attacks, reactions, and additional Attack actions.

#### CL6 - Third and Fourth Gates

You may open four Gates.

- **Third Gate - Gate of Tendons:** Jump distances tripled, Climb Speed equal to walking Speed, Advantage on Strength and Dexterity ability checks.
- **Fourth Gate - Gate of Bone:** +2 AC, Advantage against Prone and forced movement, and reduce forced movement by 10 feet.

##### Normalized Procedure — Third and Fourth Gates

- Gate of Tendons triples final jump distances after ordinary jump calculations and grants a Climb Speed equal to current walking Speed. Its Advantage applies to Strength and Dexterity ability checks, not attack rolls or saving throws.
- Gate of Bone's +2 AC is an AC bonus and does not replace your formula. Its Advantage applies to checks or saves made to avoid or resist being knocked Prone or moved against your will.
- Reduce each instance of forced movement by 10 feet after the source determines distance. A distance reduced to 0 causes no movement and no collision unless the source expressly creates an impact without movement.
- Gate of Bone does not reduce teleportation, planar transfer, voluntary movement, or a bodily transformation unless the effect expressly treats itself as forced physical movement.

#### CL10 - Fifth Gate: Gate of Thunder

While open, once during each of your turns when you take the Attack action, make one additional unarmed strike as part of it.

This attack follows the Granted Attack rule, cannot replace more than one attack, and does not grant another action.

##### Normalized Procedure — Fifth Gate

- Once during each of your turns when you take the Attack action, make one additional unarmed strike as part of that same action. Choose its timing among your other attacks.
- The attack follows the Granted Attack rule, does not create another Attack action, cannot be replaced by several attacks unless a feature expressly permits replacement of a granted attack, and cannot itself grant another attack.
- If you take more than one Attack action during the turn, Gate of Thunder still grants only one additional strike total.

#### CL14 - Sixth and Seventh Gates

- **Sixth Gate - Gate of Heaven:** Fly Speed equal to walking Speed and Hover.
- **Seventh Gate - Gate of the Tyrant:** Resistance to all damage except Force and Psychic; unarmed strikes ignore ordinary damage Resistance; once per turn on a hit, push 10 feet or prevent Reactions until the start of the target's next turn.

Gate damage is not reduced by Seventh Gate.

##### Normalized Procedure — Sixth and Seventh Gates

- Gate of Heaven grants a Fly Speed equal to current walking Speed and Hover. If it closes or is suppressed while you are unsupported, resolve falling immediately unless another flight or support remains.
- Gate of the Tyrant grants Resistance to every damage type except Force and Psychic. It does not reduce Gate damage because Gate damage expressly bypasses reduction.
- Your unarmed strikes ignore ordinary damage Resistance. “Ordinary” excludes Immunity, artifact defenses, divine authority, Secret protections, Immortal defenses, and a specific equal- or higher-Source-CL rule that states it cannot be bypassed.
- The once-per-turn hit rider is chosen after an unarmed hit. A push moves 10 feet directly away from you along a legal route. Reaction denial lasts until the start of the target's next turn. The rider remains once per turn total.

#### CL18 - Eighth Gate: Heaven-Defying Gate

While open:

- Speed doubles.
- Advantage on unarmed attack rolls.
- Once per turn on a hit, deal an additional `4d8` Force damage.
- Ordinary effects cannot Frighten, Paralyze, or Stun you.
- Gate damage becomes `1d6` per open Gate.

When Gate damage reduces you to 0 Hit Points, all Gates close, you fall Unconscious, and Blood Pump, Invincible Iron, Crimson Oni, Sovereign Reconstruction, and similar remain-at-1 features cannot prevent this reduction. You are stable unless another effect states otherwise.

##### Normalized Procedure — Eighth Gate

- Speed doubling applies after fixed additions to walking Speed. A movement mode equal to walking Speed uses the doubled value; a fixed Speed or teleport range is not doubled.
- Advantage applies to unarmed attack rolls only. The `4d8` Force damage is once per turn, part of one qualifying hit, and cannot critically multiply separately.
- “Ordinary effects” cannot Frighten, Paralyze, or Stun you. This automatically blocks mundane effects, ordinary creature traits, and lower-Source-CL effects. Artifact, divine, Secret, Tribulation, Foundation, Method, Immortal, or equal- or higher-Source-CL authority can still contest or apply those conditions according to its own rule.
- While Gate 8 is open, every open Gate contributes `1d6` instead of `1d4` Gate damage at the start of your turn.
- If that Gate damage reduces you to 0 Hit Points, close all Gates immediately, ignore every remain-at-1, 0-Hit-Point replacement, delayed-collapse, cocoon, statue, rebirth, reconstruction, or similar feature for that event, fall Unconscious, and become stable.
- The special collapse applies only to Gate damage. A hostile attack or another damage source can still interact with legal 0-Hit-Point replacement features.
- Stability does not restore Hit Points, remove other conditions, prevent later damage, or end a separate effect already affecting you.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Eight Gates of the Heaven-Defying Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 26. Hundred-Beast Scripture

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*One beast is a bloodline. A hundred beasts are an empire written into flesh.*

Hundred-Beast disciples cultivate multiple beast principles into different organs, muscles, senses, and movement patterns.

**Access Category:** Restricted Scripture  
**Primary Identity:** Modular beast aspects, adaptive physical abilities, shifting combat roles  
**Common Sphere Synergies:** Athletics, Beastmastery, Brute, Predator, Transformation, Wrestling

#### Beast Aspects

At CL3, choose three Aspects. At the start of each turn, choose one known Aspect to be active until the start of your next turn.

- **Tiger:** Once per turn on a hit, additional damage equal to Proficiency Bonus; choose Bludgeoning, Piercing, or Slashing.
- **Crane:** Speed +10 feet, jump distances tripled, falling damage reduced by `5 x CL`.
- **Serpent:** Unarmed reach +5 feet during your turn; Advantage to escape Grappled or Restrained.
- **Ox:** Count as one size larger for carrying, lifting, Grappling, Shoving; Advantage against forced movement and Prone.
- **Turtle:** +1 AC; reduce first Bludgeoning, Piercing, or Slashing damage each round by Proficiency Bonus.
- **Wolf:** First attack each turn against a creature within 5 feet of a conscious ally has Advantage.
- **Ape:** Climb Speed equal to walking Speed; Advantage on Strength checks to climb, Grapple, Shove, lift, or hold.
- **Falcon:** Double normal and long ranges of Thrown weapons; no Disadvantage at long range; draw as part of each attack.

##### Normalized Procedure — Beast Aspect Records

- Record known Aspects and active Aspects separately. You cannot select the same Aspect twice. Changing active Aspects requires only the timing printed by the Subpath and grants no extra action.
- At the start of your turn, choose the permitted number of known Aspects. If you cannot or do not choose, retain the previous legal selection; if none exists, activate the first Aspect recorded on your character sheet.
- **Tiger:** The once-per-turn Proficiency Bonus damage is part of one qualifying hit and uses Bludgeoning, Piercing, or Slashing as chosen on that hit.
- **Crane:** The Speed increase modifies walking Speed. Triple jump distances after ordinary calculations. Reduce one falling-damage event by `5 × effective Body Refining CL`, to a minimum of 0.
- **Serpent:** The +5-foot unarmed reach applies during your turn only. Advantage applies to checks and saves made to escape Grappled or Restrained.
- **Ox:** Functional size applies only to carrying, lifting, Grappling, and Shoving. Advantage applies to resisting forced movement and Prone.
- **Turtle:** +1 AC is an AC bonus. Reduce the first qualifying Bludgeoning, Piercing, or Slashing damage packet each round by Proficiency Bonus after percentage modifiers and Stamina Guard but before Hit Points are reduced. A packet reduced to 0 still counts as the round's use.
- **Wolf:** The first attack you make each turn against a creature currently within 5 feet of a conscious ally has Advantage. If an earlier attack did not meet that requirement, it does not consume this benefit.
- **Ape:** The Climb Speed equals current walking Speed. Advantage applies to the listed Strength checks only.
- **Falcon:** Double the wielded Thrown weapon's printed normal and long ranges. You ignore long-range Disadvantage for those attacks and can draw the weapon or ammunition as part of each attack. This grants no ammunition or extra attack.
- An Aspect is a bodily cultivation state, not a separate creature, bloodline, Companion, or harvestable beast part.

#### CL3 - Beast-Scripture Initiate

Learn three Beast Aspects and use the Aspect rules above.

##### Normalized Procedure — Beast-Scripture Initiate

- Choose and record three different Beast Aspects when gaining this feature. At the start of each turn, one known Aspect is active until the start of your next turn.
- Activating an Aspect requires no action or Stamina. It does not retroactively alter attacks, damage, movement, or saves already resolved earlier in the turn.
- Realm Suppression that removes this feature makes all Aspects dormant; it does not erase which Aspects are known.

#### CL6 - Paired Beast Body

Learn one additional Aspect and maintain two different Aspects simultaneously.

##### Normalized Procedure — Paired Beast Body

- Learn one additional Aspect and record it. At the start of each turn, choose two different known Aspects to remain active until the start of your next turn.
- The two Aspects function simultaneously. Benefits modifying the same statistic follow ordinary stacking rules; functional-size permissions do not stack unless a later feature expressly replaces them with a larger value.
- If one active Aspect becomes suppressed, the other remains active. You cannot replace the suppressed choice until a legal selection timing occurs.

#### CL10 - Beast King's Technique

**Trigger:** You hit with an unarmed strike or weapon attack using Strength, Dexterity, or Constitution.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Choose an active Aspect:

| Aspect | Beast King Effect |
|---|---|
| Tiger | Additional `2d8` damage of the attack's type |
| Crane | Move 15 feet without provoking Opportunity Attacks |
| Serpent | No Reactions and Speed reduced by 10 feet until the start of your next turn |
| Ox | Strength save; failure push 15 feet or Prone, success push 5 feet |
| Turtle | Temporary Hit Points equal to twice Proficiency Bonus and +1 AC until your next turn |
| Wolf | One ally within 30 feet moves 10 feet without provoking and gains Advantage on its next attack against the target |
| Ape | Attempt to Grapple or Shove with Advantage without another action |
| Falcon | Move 20 feet horizontally or vertically without provoking; fall normally if unsupported afterward |

##### Normalized Procedure — Beast King's Technique

- Declare after a qualifying attack hits, spend 1 Stamina, and choose one currently active Aspect. The technique remains once per turn total.
- **Tiger:** Add `2d8` of one damage type already dealt by the triggering attack. It is part of that hit and cannot critically multiply separately.
- **Crane:** Move 15 feet along a legal route without provoking Opportunity Attacks after the hit resolves.
- **Serpent:** Deny Reactions and reduce every Speed by 10 feet, to a minimum of 0, until the start of your next turn. Reapplication refreshes and does not stack.
- **Ox:** The triggering target makes one Strength save. On failure, choose push 15 feet directly away or knock it Prone; on success, push 5 feet if a legal space exists.
- **Turtle:** Gain Temporary Hit Points equal to twice Proficiency Bonus and +1 AC until the start of your next turn. The AC bonus applies even if the Temporary Hit Points are lost.
- **Wolf:** Choose one ally within 30 feet that can move. It moves up to 10 feet without provoking Opportunity Attacks, then has Advantage on its next attack against the triggering target before the end of that ally's next turn. The attack consumes the benefit.
- **Ape:** Attempt to Grapple or Shove the triggering target immediately without another action. Apply the printed Advantage to the attempt under the current Grapple or Shove procedure. This is not an extra attack.
- **Falcon:** Move up to 20 feet horizontally, vertically, or diagonally without provoking Opportunity Attacks. This is granted movement, not flight; if unsupported after it resolves, fall normally.
- A Beast King effect cannot trigger itself or another Beast King's Technique.

#### CL14 - Chimera Meridian Network

Learn every Aspect and maintain three simultaneously.

When Initiative is rolled, choose active Aspects before the first turn. Once per round when a hostile creature ends its turn, replace one active Aspect with another without using an action.

##### Normalized Procedure — Chimera Meridian Network

- Learn every Aspect not already known. When Initiative is rolled, select three different active Aspects before any creature takes a turn.
- At the start of each of your turns, you may choose any three different Aspects under the normal Aspect timing.
- Once per round, immediately after a hostile creature ends its turn, replace one active Aspect with one different inactive Aspect without an action. The new Aspect begins immediately and remains until the next legal selection or replacement.
- Replacing an Aspect does not retroactively change an attack, save, damage packet, movement, or state already resolved. Losing Turtle after its reduction was used does not restore that use; gaining Turtle later in the same round provides its own first-damage use only if Turtle has not already reduced damage for you that round.
- A creature counts as hostile only when it is genuinely opposing you in the current scene; staged hostility cannot farm replacement timings.

#### CL18 - Sovereign of Ten Thousand Beasts

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

All Aspects become active.

For the duration:

- You may become Large.
- Unarmed strikes deal `1d12` before modifiers.
- Once per turn on a hit, deal an additional `3d8` Bludgeoning, Piercing, or Slashing damage.
- Use Beast King's Technique twice per turn by paying each cost, on different attacks and with different Beast King effects.
- Count as two additional sizes larger for Grapple, Shove, carrying, lifting, pushing, and dragging.
- Gain Darkvision 120 feet, Climb Speed equal to Speed, and Fly Speed equal to Speed with Hover.

When the duration ends, choose three Aspects to remain active until the start of your next turn.

##### Normalized Procedure — Sovereign of Ten Thousand Beasts

- This is one temporary bodily transformation and Aspect state. All eight Aspects are active simultaneously for the duration.
- Becoming Large is optional and follows the transformation and legal-space procedures. If already Large or larger, the feature does not reduce your size. Equipment follows the recorded fit procedure.
- Unarmed strikes use a `1d12` base damage die before modifiers. If another legal feature provides a larger unarmed damage die, use the larger die; do not add both.
- The once-per-turn `3d8` rider is part of one hit and uses Bludgeoning, Piercing, or Slashing as chosen on that hit.
- Beast King's Technique can be used twice per turn by paying 1 Stamina for each use. The uses must occur on different attacks and select different Beast King effects. They remain part of the same once-per-turn expansion and cannot generate further Beast King uses.
- During the transformation, the printed “two additional sizes larger” replaces Ox's normal one-size functional benefit for the listed Grapple, Shove, carrying, lifting, pushing, and dragging operations; it does not become three additional sizes.
- Darkvision, Climb Speed, and Fly Speed are bodily senses and movement modes. The Fly Speed equals current Speed and has Hover. If the feature ends while unsupported, resolve falling unless another support remains.
- When the duration ends, choose three Aspects immediately. They remain active until the start of your next turn, when normal Chimera selection resumes. Ending or suppression does not refund Stamina or the scene use.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Hundred-Beast Scripture

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 27. Nine-Star Meridian Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The heavens are distant only because the body has not learned their arrangement.*

Nine-Star disciples open celestial acupoints throughout the body. Each expenditure of Stamina lights another point in the internal constellation.

**Access Category:** Restricted Scripture  
**Primary Identity:** Celestial buildup, force projection through the body, orbital movement, falling-star impacts  
**Common Sphere Synergies:** Force, Gravity, Light, Radiance, Space, Stars, Sun

#### Celestial Marks

- Maximum Celestial Marks equals Proficiency Bonus.
- Begin each scene with 0; they disappear when it ends.
- Gain 1 when Initiative is rolled.
- Once per round, after spending Stamina on a Path or Subpath feature that resolves, gain 1 Mark.

##### Normalized Procedure — Celestial Mark Record

- Record current Marks, maximum Marks, whether the once-per-round Stamina trigger has generated a Mark, and the Source CL of the current scene state.
- Begin each scene with 0 Marks. When Initiative is rolled for that scene, gain 1 Mark, or 3 Marks after gaining Constellation Circuit. This is one initiative grant, not one grant each time initiative is rerolled or a creature joins combat.
- Once per round, after you spend Stamina on a Body Refining Path or Subpath feature and that activation finishes resolving, gain 1 Mark. The feature can miss, be saved against, or have no legal target and still resolve; an activation prevented before it begins or refunded by its own rule does not generate a Mark.
- One activation generates at most one Mark regardless of Stamina spent or number of effects resolved. Self-created loops, staged hazards, and repeated nonhostile activations cannot create extra initiative or round triggers.
- Marks cannot exceed maximum. Before CL14, excess Marks are lost. At CL14, each excess gain can produce one listed overflow benefit.
- All Marks disappear when the scene ends. Suppression makes Mark-dependent benefits dormant but does not erase current Marks unless the scene ends.

#### CL3 - Star-Lit Acupoints

While you have at least 1 Mark, you may emit or suppress Dim Light in 5 feet.

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Mark  
**Limit:** Once per turn

Deal an additional `1d8` Force or Radiant damage and choose one:

- Move 5 feet without provoking Opportunity Attacks.
- Push the target 5 feet.
- Pull it 5 feet toward you.
- Gain +1 AC against it until the start of your next turn.

##### Normalized Procedure — Star-Lit Acupoints

- Emitting or suppressing Dim Light requires no action and can be changed once during your turn. The light reveals your space normally and grants no concealment, truesight, or Radiance authority.
- Declare the strike rider after an unarmed hit, spend 1 Mark, and add `1d8` Force or Radiant damage. It is part of the triggering hit and cannot critically multiply separately.
- Choose one movement or defense result. Self-movement is voluntary granted movement and does not provoke Opportunity Attacks. Push and pull use a legal straight route and cannot place the target in an occupied or solid space.
- The +1 AC applies only against attacks made by the triggering target and lasts until the start of your next turn. It is an AC bonus and does not replace your formula.
- The feature remains once per turn even if Marks are regained during the same turn.

#### CL6 - Orbital Body

**Reaction**  
**Trigger:** An attack hits you, or you fail a Dexterity saving throw against a damaging effect.  
**Cost:** 1 Mark

Reduce the damage by `2d8 + Constitution modifier`, then move 10 feet without provoking Opportunity Attacks. If reduced to 0, move 15 feet instead.

The movement cannot cross a solid barrier, sealed Formation, or occupied space.

##### Normalized Procedure — Orbital Body

- Declare after an attack hits you or after you fail a Dexterity save against a damaging effect, once damage is calculated but before Hit Points are reduced. Spend the Reaction and 1 Mark.
- Reduce one damage packet by `2d8 + Constitution modifier` after Resistance, Vulnerability, and percentage modifiers but before other flat reductions that resolve later under Shared Procedures.
- After that packet resolves, move 10 feet without provoking Opportunity Attacks; move 15 feet instead if the packet was reduced to 0 by this feature and any earlier modifiers.
- The movement is voluntary granted movement. It cannot cross total cover, a solid barrier, sealed Formation, occupied space, or another explicit movement prohibition.
- Moving does not retroactively remove you from the triggering attack or area and does not negate other targets or later damage packets from the same activation.
- If no legal destination exists, remain in place; the damage reduction still applies.

#### CL10 - Falling-Star Descent

**Action**  
**Range:** An unoccupied space within 60 feet  
**Cost:** 2 Stamina and 3 Marks

Move to the selected space without provoking Opportunity Attacks, crossing open air but not solid barriers, total cover, sealed Formations, or spaces too small for you.

Each other chosen creature within 15 feet makes a Dexterity saving throw.

- **Failed Save:** `6d8` Force or Radiant damage, Prone, pushed 10 feet.
- **Successful Save:** Half damage, no Prone or push.

The ground becomes difficult terrain until repaired. Unattended ordinary objects, temporary barriers, vehicles, structures, and Formation Anchors take double damage.

##### Normalized Procedure — Falling-Star Descent

- Choose an unoccupied legal space within 60 feet that you can identify. The movement follows one continuous unobstructed route through open air or open space. It is physical celestial movement, not teleportation, and cannot pass through solid barriers, total cover, sealed Formations, or spaces too small for you.
- The movement does not provoke Opportunity Attacks. If the destination becomes illegal before arrival, stop in the nearest legal space along the route; the impact area is centered on the space where you stop.
- Choose any number of other creatures within 15 feet after arrival. Each makes one Dexterity save and is affected once. Choose Force or Radiant for the activation.
- Resolve damage, Prone, and push after arrival. A push moves directly away from you and stops at the nearest legal space. A successful save prevents Prone and push.
- The impacted ground in the 15-foot area becomes difficult terrain. Each 5-foot square can be cleared or repaired under the Body environmental-terrain procedure. This does not automatically create a crater, chasm, or permanent regional damage.
- Eligible unattended objects, temporary barriers, vehicles, structures, and Formation Anchors take double damage once. A surviving obstruction does not prevent the radial impact unless it provides total cover from your arrival space.

#### CL14 - Constellation Circuit

Maximum Marks becomes `Proficiency Bonus + 3`. When Initiative is rolled, gain 3 Marks.

While you have at least 3 Marks:

- Fly Speed 30 feet and Hover.
- Cannot be knocked Prone while airborne.
- Count as one size larger when resisting forced movement.

When you would gain a Mark at maximum, choose one, each no more than once per round:

- Temporary Hit Points equal to Proficiency Bonus.
- Move 5 feet without provoking Opportunity Attacks.
- Add Proficiency Bonus to your next Strength or Dexterity saving throw before the start of your next turn.

##### Normalized Procedure — Constellation Circuit

- Maximum Marks becomes `Proficiency Bonus + 3`. The initiative grant becomes 3 Marks and replaces the former 1-Mark grant.
- While current Marks are at least 3, gain Fly Speed 30 feet and Hover, cannot be knocked Prone while airborne, and count as one size larger when resisting forced movement. If Marks fall below 3 while unsupported, resolve falling immediately unless another flight remains.
- When a Mark would be gained at maximum, choose one overflow benefit instead. Each of the three benefits can be chosen no more than once per round, allowing up to three different overflow benefits in a round if separate legal Mark gains occur.
- Temporary Hit Points equal Proficiency Bonus and do not stack. The 5-foot movement is voluntary granted movement and does not provoke Opportunity Attacks.
- For the save bonus, choose Strength or Dexterity when gained. Add Proficiency Bonus to one next save of that type before the start of your next turn, then consume the benefit. This is a feature bonus, not proficiency.
- An overflow gain still counts as that round's normal Stamina-generated Mark event. It cannot be repeatedly generated from the same activation.

#### CL18 - Nine-Star Incarnation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina and 5 Marks  
**Limit:** Once per scene

For the duration:

- Fly Speed 60 feet and Hover.
- Resistance to all damage except Psychic and Void.
- Unarmed strikes may deal Force or Radiant.
- Once per turn on a hit, additional `4d8` Force or Radiant damage.
- Hostile creatures treat spaces within 10 feet as difficult terrain.
- A creature of your CL or lower cannot push, pull, knock you Prone, or move you against your will unless its feature explicitly ignores gravity or bodily anchoring.

Once per round when you hit, force a Strength save. On a failure, push or pull 20 feet and knock Prone; on a success, push or pull 5 feet.

Teleportation, spatial displacement, and effects explicitly ignoring gravity still function.

##### Normalized Procedure — Nine-Star Incarnation

- This is one temporary bodily and gravitational transformation. Spend 5 Marks when activating; its benefits do not require retaining 3 Marks afterward.
- The 60-foot Fly Speed and Hover replace the conditional 30-foot flight while the form lasts. Resistance applies to every damage type except Psychic and Void and follows ordinary damage ordering.
- Each unarmed strike may replace its ordinary damage types with Force or Radiant. The once-per-turn `4d8` rider is part of one hit and uses Force or Radiant as chosen.
- Hostile creatures treat every space within 10 feet of you as difficult terrain while moving through it. Starting inside the area does not itself cost movement; each foot moved inside costs according to difficult terrain.
- A physical push, pull, Prone, or involuntary bodily movement with Source CL no greater than your effective Body Refining CL fails unless its Source Rule explicitly ignores gravity or bodily anchoring. Higher-Source-CL effects and explicit bypasses use their own authority. Teleportation and spatial displacement remain legal as printed.
- Once per round after an unarmed hit, choose that target for the Strength save. On failure, push or pull it up to 20 feet along a legal route and knock it Prone; on success, push or pull it 5 feet. If no legal destination exists, shorten or prevent movement, but Prone on a failed save still applies unless the target is immune.
- Suppression makes the transformation dormant, does not refund Marks or Stamina, and does not extend the one-minute duration.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Nine-Star Meridian Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 28. Heaven-Thunder Drum Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Every bone is a drum. Every heartbeat is a war declaration.*

Heaven-Thunder disciples refine muscle tension, bone vibration, heartbeat, and internal pressure into destructive resonance.

**Access Category:** Restricted Scripture  
**Primary Identity:** Vibration, internal shock, disruption, anti-barrier force  
**Common Sphere Synergies:** Boxing, Force, Music, Pressure Points, Sound, Thunder

#### Body Beats

- Maximum Body Beats equals Proficiency Bonus.
- Begin each scene with 0; they disappear when it ends.
- Gain no more than 1 per round.
- Gain 1 after hitting a hostile creature with an unarmed strike after moving at least 10 feet, taking qualifying hostile damage, or reducing damage with Stamina Guard.

##### Normalized Procedure — Body Beat Record

- Record current Beats, maximum Beats, whether a Beat has already been gained this round, the qualifying event, and the current scene.
- Begin each scene with 0 Beats and lose all Beats when it ends. You can gain no more than 1 Beat per round from all listed triggers combined.
- A movement-hit trigger requires at least 10 feet of actual movement during the current turn before the hostile unarmed hit. Teleportation does not count.
- A hostile-damage trigger requires at least 1 damage actually applied to Hit Points or Temporary Hit Points from a qualifying hostile source. Self-damage, allied damage, staged attacks, environmental farming, and Gate damage do not qualify.
- A Stamina Guard trigger occurs after Stamina Guard reduces a hostile damage packet by at least 1, even if other reductions later reduce the packet further.
- If one event qualifies through both taking damage and Stamina Guard, gain only one Beat. Gain the Beat after the triggering event resolves.
- Beats are a scene resource, not sound objects, physical materials, or independent vibration Assets.

#### CL3 - Bone-Drum Strike

Your unarmed strikes may deal Thunder damage.

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Body Beat  
**Limit:** Once per turn

Deal an additional `1d8` Thunder damage, increasing to `2d8` at CL11 and `3d8` at CL17.

Choose one:

- No Reactions until the start of the target's next turn.
- Push 5 feet.
- Disadvantage on its next Constitution save to maintain Concentration before the start of your next turn.
- One object, temporary barrier, or Formation Anchor struck takes additional Thunder damage equal to twice your Proficiency Bonus.

##### Normalized Procedure — Bone-Drum Strike

- You may replace the ordinary damage types of each unarmed strike with Thunder. This changes type only and does not add damage.
- Declare after an unarmed hit, spend 1 Body Beat, and add the CL-appropriate Thunder damage. The added damage is part of the triggering hit and cannot critically multiply separately.
- Choose exactly one printed rider. Reaction denial begins after the hit. A push moves 5 feet directly away along a legal route.
- The Concentration rider applies Disadvantage to the target's next Constitution save to maintain Concentration before the start of your next turn and is consumed after that save.
- The object rider applies only when the struck target is an object, temporary barrier, or Formation Anchor. It adds Thunder damage equal to twice Proficiency Bonus in addition to the feature's ordinary added die; category overlap does not multiply it.
- Bone-Drum Strike remains once per turn even if Beats are regained during that turn.

#### CL6 - Internal Echo

**Trigger:** You hit with an unarmed strike.  
**Cost:** 2 Body Beats  
**Limit:** Once per turn  
**Saving Throw:** Constitution

On a failed save, the target becomes **Echoing** until the end of your next turn.

The first time it takes an Action, Bonus Action, or Reaction; willingly moves at least 10 feet; or spends Cultivation Points, the Echo detonates: `3d8` Thunder damage, no Reactions until the start of its next turn, and Disadvantage on resulting Concentration saves. The state then ends.

On a successful save, it takes `1d8` Thunder damage and does not become Echoing.

##### Normalized Procedure — Internal Echo

- Declare after an unarmed hit, spend 2 Body Beats, and have the target make one Constitution save. On success, apply one `1d8` Thunder damage packet and create no state.
- On failure, record one **Echoing** state lasting until the end of your next turn. A target can bear only one Echoing state from you; reapplication refreshes it and does not stack detonations.
- For an Action, Bonus Action, or Reaction, the Echo detonates after the target commits to that action and pays its costs but before the action's effects resolve. The action is not canceled unless the resulting damage or condition independently prevents it.
- For willing movement, detonate immediately after the target completes the first cumulative 10 feet of willing movement. Teleportation does not count unless the movement rule says it is willing movement through distance.
- For spending Cultivation Points, detonate immediately after the points are spent but before the purchased feature resolves. A single activation satisfying several triggers causes one detonation.
- The detonation is one `3d8` Thunder packet, then denies Reactions until the start of the target's next turn and ends Echoing. Disadvantage applies to Concentration saves caused by this detonation.
- An Echoing state cannot trigger from involuntary movement, a no-action passive effect, automatic upkeep that spends no Cultivation Points, or damage from the Echo itself.

#### CL10 - Counter-Resonance

**Reaction**  
**Trigger:** You or a creature within 10 feet takes damage from an attack or area effect.  
**Cost:** 2 Stamina and 1 Body Beat  
**Limit:** Once per round

Reduce damage to one protected creature by `3d8 + Constitution modifier`.

If reduced to 0, each chosen hostile creature within 10 feet of the protected creature makes a Constitution save, taking `2d8` Thunder damage and being pushed 10 feet on a failure, or half damage and no push on a success.

##### Normalized Procedure — Counter-Resonance

- Declare when you or one creature within 10 feet would take damage from one attack or one area-effect damage packet, after damage is calculated but before Hit Points are reduced. Choose one protected creature, spend the Reaction, 2 Stamina, and 1 Body Beat.
- Reduce only that creature's triggering packet by `3d8 + Constitution modifier` after percentage modifiers and before later flat reductions.
- If the final triggering damage applied to the protected creature becomes 0, choose any number of hostile creatures within 10 feet of that creature. Each makes one Constitution save and is affected once.
- On failure, a chosen creature takes `2d8` Thunder damage and is pushed 10 feet directly away from the protected creature. On success, it takes half damage and is not pushed.
- The burst occurs after the protected packet resolves. It does not protect other creatures in the original area and cannot recursively trigger another Counter-Resonance from you.
- If the reduction is insufficient to reach 0, no burst occurs; the damage reduction remains.

#### CL14 - Heaven-Drum Circulation

Gain Resistance to Thunder and Force damage, Immunity to Deafened, and Tremorsense 30 feet while touching a solid surface.

Maximum Body Beats becomes `Proficiency Bonus + 2`.

Once per round after spending Stamina on a Body Refining Path or Subpath feature, gain 1 Body Beat after it resolves, still obeying the one-per-round gain limit.

Bone-Drum Strike ignores ordinary hardness and Damage Threshold against temporary barriers, objects, structures, vehicles, and Formation Anchors.

##### Normalized Procedure — Heaven-Drum Circulation

- Thunder and Force Resistance follow ordinary damage ordering. Deafened Immunity blocks the condition but does not automatically permit hearing through silence, vacuum, destroyed hearing organs, or a stronger sense-suppression rule.
- Tremorsense functions within 30 feet only while some part of your body touches a continuous solid surface connected to the sensed source. It does not perceive airborne creatures, creatures behind a break in the surface, or exact visual detail.
- Maximum Body Beats becomes `Proficiency Bonus + 2`.
- Once per round after spending Stamina on a Body Refining Path or Subpath feature that resolves, gain 1 Body Beat, still subject to the overall one-Beat-per-round gain limit. If another trigger already generated a Beat that round, this one generates none.
- Bone-Drum Strike ignores ordinary hardness and Damage Threshold only for temporary barriers, objects, structures, vehicles, and Formation Anchors it legally strikes. Immunity, artifact construction, divine authority, Secret protection, Immortal defenses, and equal- or higher-Source-CL explicit thresholds retain their authority.
- Ignoring a threshold does not grant permission to target an otherwise untargetable world-scale structure or deal damage beyond the feature's printed packet.

#### CL18 - World-Shaking Cadence

**Action**  
**Area:** 30-foot-radius sphere centered on you  
**Cost:** 6 Stamina and all current Body Beats  
**Requirement:** At least 3 Body Beats  
**Saving Throw:** Constitution

Damage equals `8d8 Thunder + 1d8 per Body Beat spent`.

- **Failed Save:** Full damage, Prone, no Reactions until the end of its next turn, Concentration ends, and temporary magical or cultivation flight is suppressed until the start of its next turn.
- **Successful Save:** Half damage, remains standing, no Reactions until the start of its next turn, and normal Concentration procedure.

Permanent anatomy-based flight remains. Unattended objects, temporary barriers, vehicles, structures, and Formation Anchors take double damage.

##### Normalized Procedure — World-Shaking Cadence

- Record current Body Beats before activation. Spend all of them with the 6 Stamina cost; the damage is `8d8 + 1d8 per Beat spent`. At least 3 Beats are required.
- The 30-foot-radius sphere originates from you and affects every other creature in the area unless another rule excludes it. Each creature makes one Constitution save and is affected once.
- On failure, apply full damage, Prone, Reaction denial through the end of its next turn, automatic ending of current Concentration, and suppression of temporary magical or cultivation flight until the start of its next turn.
- On success, apply half damage, no Prone, Reaction denial until the start of its next turn, and the ordinary Concentration procedure caused by the damage.
- When temporary flight is suppressed, a creature immediately falls unless permanent anatomy-based flight, a physical support, or another unsuppressed movement feature keeps it aloft. Permanent wings and anatomy remain functional as printed.
- Eligible unattended objects, temporary barriers, vehicles, structures, and Formation Anchors take double Thunder damage once. They do not make saves unless their own profile says they do.
- The cadence does not automatically deafen, destroy organs, create an Injury, shatter every object, suppress permanent anatomy, or bypass artifact, divine, Secret, or higher-Source-CL protection.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, venom, vibration, celestial movement, breath, roar, integrated weapon effect, Body Asset, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, transformation, venom, mark, Gate state, Aspect, terrain effect, Anchor, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, venom, Aspect, mark, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, and terrain result expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement, forced movement, celestial descent, flight, crossing, and repositioning must end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, bodily Asset, permanent transformation, poison reservoir, disease, soul damage, or Foundation damage. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** A transformation, integrated weapon, Gate, Aspect, flight mode, venom, mark, vibration, additional anatomy, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Heaven-Thunder Drum Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 29. Heaven-Binding Chain Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The first chain binds the limb. The final chain binds the road by which escape was possible.*

Heaven-Binding disciples refine the shoulders, spine, tendons, grip, and meridians to wield chains as extensions of the body.

**Access Category:** Restricted Scripture  
**Primary Identity:** Reach, tethers, restraint, interception, battlefield imprisonment  
**Common Sphere Synergies:** Chains, Guardian, Thread, Warleader, Wrestling

#### CL3 - Chain-Body Integration

Gain proficiency with Chain Weapons.

While wielding one:

- Use Constitution instead of Strength or Dexterity for attack and damage rolls.
- You may use your Cultivation Attack Modifier.
- It is integrated into Body Refining.
- Reach increases by 5 feet during your turn.
- Refined Iron Fist and Heavenly Fist apply.

This does not grant the Chains Sphere.

##### Meridian Tether

**Trigger:** You hit with a Chain Weapon or unarmed strike.  
**Cost:** 1 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Strength

On a failed save, the target becomes **Tethered** until the end of your next turn.

While Tethered:

- It cannot willingly move more than 20 feet from you.
- It cannot benefit from willing allied movement that carries it beyond 20 feet.
- Teleportation beyond 20 feet requires a Cultivation Check against your DC; failure uses Failed Spatial Movement.
- You know its direction within 60 feet.

A Tether ends if you become Unconscious, willingly end it, the target ends its turn more than 30 feet away because of hostile forced movement, or an effect severs cultivation bindings.

At CL3, maintain one Tether; a new one replaces it.

##### Normalized Procedure — Chain Integration and Meridian Tethers

- Record each qualifying Chain Weapon by weapon group. While wielding it, Constitution replaces Strength or Dexterity for its attack and damage rolls, and you may use your Cultivation Attack Modifier for its attack rolls. Integration grants no Sphere, talent, extra Chain Weapon, or independent chain manifestation.
- The 5-foot reach increase applies only during your turn. At CL14 the two turn-only increases combine for +10 feet during your turn; they do not enlarge threatened space outside your turn.
- Refined Iron Fist and Heavenly Fist apply only through their printed integrated-weapon interface. If several rules replace the same weapon damage die, use the highest legal replacement rather than adding several base weapon dice.
- Declare Meridian Tether after the triggering hit resolves, spend 1 Stamina, select one creature hit, and have it make one Strength save. A Tether is a cultivation restraint, not Grappled or Restrained, and it does not by itself prevent attacks, actions, forced movement, falling, or movement toward you.
- Record the Tether's source, target, Source CL, maximum distance, direction-sense range, duration, and removal conditions. At CL3 you can maintain one Meridian Tether; creating another immediately ends the previous one after the new target fails its save.
- A Tethered creature can willingly move within the 20-foot boundary and can move closer to you. It cannot use its own willing movement, or accept willing allied movement, to end farther than 20 feet from you. Hostile forced movement can carry it beyond that boundary.
- A willing teleport or other spatial movement that would end farther than 20 feet requires one Cultivation Check against your Cultivation Save DC before movement occurs. On failure use Failed Spatial Movement; on success the movement resolves normally unless another feature intervenes.
- Direction sense functions only while the target is within 60 feet and on the same plane. It gives direction, not exact distance, condition, identity through disguise, line of sight, or permission to target through total cover.
- The Tether ends at its printed duration, when you become Unconscious, when you willingly end it without an action, when a legal effect severs cultivation bindings, or when the target ends its turn more than 30 feet from you after hostile forced movement. Being momentarily farther than 30 feet before that end-of-turn check does not end it.

#### CL6 - Drag the Heavens

**Bonus Action**  
**Target:** One creature Tethered to you  
**Cost:** 1 Stamina  
**Saving Throw:** Strength

On a failed save, pull it 20 feet, move yourself 20 feet toward it without provoking, pull it 10 feet and knock it Prone, or rotate it to another unoccupied space within 20 feet.

On a success, pull it 5 feet or move yourself 5 feet toward it.

A creature more than two sizes larger has Advantage.

If it collides with a surface or creature, both take Bludgeoning damage equal to your Proficiency Bonus; a second creature avoids this damage on a successful Dexterity save.

##### Normalized Procedure — Drag the Heavens

- Select one creature currently Tethered to you, spend the Bonus Action and 1 Stamina, then resolve one Strength save. A creature at least three size categories larger than you has Advantage; functional size expressly applicable to Grappling or forced movement counts.
- On a failed save, choose exactly one printed result. On a success, choose one of the two printed 5-foot results. Self-movement and target movement are part of this activation and do not create another movement trigger from Drag the Heavens.
- A pull moves the target directly toward you along the shortest legal route. Self-movement moves you directly toward the target, does not provoke Opportunity Attacks, and must end in a legal space. The 10-foot pull-and-Prone result applies Prone after movement ends.
- The rotation result moves the target through a curved or straight legal route no longer than 20 feet to an unoccupied space within 20 feet of you. It cannot pass through total cover or a sealed barrier and cannot end beyond the Meridian Tether boundary.
- Forced movement stops at the nearest legal space before an obstruction. If the moving target first collides with a damageable surface or one creature because no legal continuation exists, resolve one collision only. The moved target takes Bludgeoning damage equal to your Proficiency Bonus. A damageable surface takes the same damage; a second creature makes one Dexterity save, taking the same damage on failure and none on success.
- Collision damage is one packet per affected creature, does not repeat for several occupied squares or chained contacts, and does not create an Injury, Grapple, or additional forced movement unless another Source Rule says so.
- A successful-save 5-foot pull or self-movement uses the same route and legal-space rules. If no legal movement is possible, that movement becomes 0; the Stamina and Bonus Action remain spent.

#### CL10 - Guardian Chain

**Reaction**  
**Trigger:** A creature within 30 feet is hit by a ranged attack or would be moved at least 10 feet against its will.  
**Cost:** 2 Stamina  
**Limit:** Once per round

Choose one:

- **Catch the Attack:** Reduce ranged attack damage by `3d10 + Constitution modifier`. If reduced to 0, move the protected creature 10 feet toward you without provoking.
- **Anchor the Body:** Reduce forced movement by 20 feet. If reduced to 0, prevent Prone from the same effect and move it 5 feet toward you.

Guardian Chain cannot prevent teleportation unless the creature is Tethered.

##### Normalized Procedure — Guardian Chain

- Declare after a creature within 30 feet is hit by one ranged attack but before its damage is applied, or after hostile forced movement of at least 10 feet is declared but before that movement resolves. Spend the Reaction and 2 Stamina; the once-per-round limit is consumed even if the result is later reduced by a stronger rule.
- **Catch the Attack:** Reduce the triggering attack's total damage packet by `3d10 + Constitution modifier` at the shared damage-reduction step. This protects only the chosen hit creature and does not reduce later attacks or separate damage packets from the same activation. If final damage applied becomes 0, move that creature up to 10 feet directly toward you along a legal route without provoking Opportunity Attacks. This is granted movement created by you and does not require willingness.
- **Anchor the Body:** Reduce the triggering physical forced-movement distance by 20 feet after the source determines distance. If final distance becomes 0, also prevent Prone caused by that same movement effect and move the protected creature up to 5 feet toward you without provoking. Prevented movement creates no collision unless the source expressly creates one without movement.
- Guardian Chain does not reduce ordinary teleport distance. If the protected creature is Tethered and the trigger is willing or hostile spatial movement, you may use Anchor the Body; replace the 20-foot reduction with one Cultivation Check by the spatial effect's activator against your Cultivation Save DC. On failure, use Failed Spatial Movement; on success, the spatial movement resolves normally. Do not roll both this check and the Meridian Tether check for the same spatial activation; Guardian Chain uses this Reaction-based check instead.
- A creature moved toward you by Guardian Chain must end in a legal space. If no legal route or destination exists, move it as far as legally possible. Guardian Chain does not redirect the ranged attack, change its source, or create a counterattack.

#### CL14 - Thousand-Link Meridian Network

Chain reach increases by another 5 feet during your turn. Maintain Tethers equal to Proficiency Bonus.

While at least one hostile creature is Tethered:

- Tethered creatures treat spaces within your chain reach as difficult terrain.
- You cannot be Disarmed of a Chain Weapon by an ordinary effect.
- Once per turn on a hit against a Tethered creature, deal an additional `2d8` Bludgeoning, Slashing, or Force damage.
- When a Tethered creature willingly moves within your reach, it provokes an Opportunity Attack even if that movement normally would not.

You retain your normal number of Reactions.

##### Normalized Procedure — Thousand-Link Meridian Network

- Your maintained Meridian Tether maximum becomes your Proficiency Bonus. If that maximum decreases, choose excess Tethers to end immediately. Each Tether retains its own target, duration, distance, Source CL, and removal record.
- The additional Chain reach is turn-only and combines with Chain-Body Integration for +10 feet during your turn. Outside your turn use the Chain Weapon's printed reach plus any other persistent reach expressly granted by another rule.
- While at least one hostile creature is Tethered, every hostile creature Tethered to you treats spaces currently within your Chain Weapon reach as difficult terrain. This applies only to its willing movement; forced movement, teleportation, and falling do not pay difficult-terrain cost.
- Reach expansion around a stationary creature does not count as that creature entering or moving within reach. The special Opportunity Attack trigger occurs when a Tethered creature willingly moves at least 5 feet while it is within your current reach, including movement that normally avoids Opportunity Attacks. Teleportation and hostile forced movement do not trigger it.
- The special trigger does not grant an extra Reaction. It uses your normal Opportunity Attack procedure and current out-of-turn reach.
- The `2d8` rider is once per turn total. Declare it after hitting one Tethered creature; choose Bludgeoning, Slashing, or Force. It is part of the triggering hit's damage packet and cannot critically multiply separately.
- Ordinary Disarm immunity prevents mundane or ordinary creature effects from removing the wielded Chain Weapon. Artifact, divine, Secret, Foundation, Method, Immortal, or explicit equal- or higher-Source-CL authority can still contest it.

#### CL18 - Heaven-Binding Prison

**Action**  
**Range:** A point within 60 feet  
**Area:** 30-foot-radius, 30-foot-high cylinder  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

Each chosen hostile creature in the area makes a Strength saving throw.

- **Failed Save:** Restrained, Tethered to the center, cannot willingly leave, and spatial movement outside requires a Cultivation Check; failure uses Failed Spatial Movement.
- **Successful Save:** Not Restrained; Speed halved until the start of its next turn.

A Restrained creature repeats the Strength save at the end of each turn, ending Restrained on a success. It remains Tethered until the start of its following turn.

You and chosen allies ignore movement restrictions. Hostile creatures treat the area as difficult terrain. Temporary barriers, unattended objects, and Formation Anchors take `4d8` Force damage when it appears.

The central anchor has AC equal to your Cultivation Save DC, Hit Points `5 x CL`, Resistance to Bludgeoning, Piercing, and Slashing, Immunity to Poison and Psychic, and occupies the center. Destroying or suppressing it ends the prison.

##### Normalized Procedure — Heaven-Binding Prison

- Select a point on a stable surface within 60 feet that can contain the central Anchor's 5-foot space. The prison is a stationary 30-foot-radius, 30-foot-high cylinder centered on that point and lasts 1 minute without Concentration unless ended by its Anchor.
- When the prison appears, designate any number of allies. Each other chosen hostile creature currently in the cylinder makes one Strength save. A creature is affected once by the creation even if it occupies several spaces.
- On failure, the creature is Restrained and gains a **Prison Tether** to the center. A Prison Tether is separate from Meridian Tethers, does not count against their maximum, prevents willing departure from the cylinder, and requires a Cultivation Check against your Cultivation Save DC for spatial movement outside. Failure uses Failed Spatial Movement.
- At the end of each of its turns, a Restrained creature repeats the Strength save. On success, Restrained ends immediately but its Prison Tether remains until the start of its following turn. While only that Tether remains, it is not Restrained but still cannot willingly leave or spatially escape without the check.
- On the initial successful save, the creature is not Restrained or Prison Tethered and its Speed is halved until the start of its next turn. A creature entering after creation receives no initial save or Tether; it treats the area as difficult terrain while hostile.
- You and designated allies ignore the prison's difficult terrain, Prison Tethers, and movement restrictions. They do not ignore the central Anchor's occupied space or a separate restraint effect.
- On creation, each eligible unattended object, temporary barrier, vehicle, structure, and Formation Anchor in the cylinder takes one `4d8` Force damage packet. Creatures and permanent world terrain are not damaged by this clause.
- The central Anchor is an immobile Body Refining Anchor with Source CL equal to this feature, AC equal to your Cultivation Save DC, Hit Points equal to `5 × effective Body Refining CL`, Resistance to Bludgeoning, Piercing, and Slashing, Immunity to Poison and Psychic, and a 5-foot occupied space. It makes no attacks and grants no cover unless ordinary geometry does so.
- Destroying the Anchor, suppressing it, moving it from the center through an explicit higher-authority rule, your death, or the duration ending immediately ends the prison, every Prison Tether, and every Restrained condition created by it. Damage to the Anchor does not damage you.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Heaven-Binding Chain Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 30. Five-Viscera Immortal Furnace

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The heart burns. The lungs ring. The liver grows. The kidneys descend. The spleen makes the center endure.*

Five-Viscera disciples cultivate the major organs as linked internal furnaces.

**Access Category:** Restricted Scripture  
**Primary Identity:** Organ refinement, internal alchemy, circulating bodily modes, medicine and toxin control  
**Common Sphere Synergies:** Alchemy, Blood, Fire, Life, Medicine, Poison, Water, Wood

#### Organ Furnaces

At the start of each turn, choose one Furnace until the start of your next turn.

- **Heart - Fire and Release:** Once per turn on a hit, additional Fire or Radiant damage equal to Proficiency Bonus.
- **Lung - Metal and Breath:** +1 AC against ranged attacks; hold breath 1 hour; Advantage against inhaled poison, gas, smoke, suffocation, and breathing interference.
- **Liver - Wood and Renewal:** Once per turn after spending Stamina, regain Hit Points equal to Proficiency Bonus; not at 0 Hit Points.
- **Kidney - Water and Reserve:** Once per turn after spending Stamina, move 5 feet without provoking; may stand from Prone.
- **Spleen - Earth and Stability:** Once per turn after using Stamina Guard or succeeding against forced movement, gain Temporary Hit Points equal to Proficiency Bonus.

##### Normalized Procedure — Organ Furnace State

- Record which Furnaces are active and whether each Furnace's once-per-turn benefit has been used. At CL3 one Furnace is active, at CL10 two different Furnaces are active, at CL14 all five are active, and Inner Cosmos Furnace applies its printed improvements without creating duplicate copies.
- Choose active Furnaces at the start of each turn before resolving another start-of-turn choice. If you cannot or do not choose, retain the previous legal selection; if none exists, activate Heart first. A Furnace selected later in the turn is prospective and does not alter an already resolved roll, damage packet, save, or movement.
- Each named Furnace has its own once-per-turn limit. Deactivating and reactivating a Furnace during the same turn does not reset a use already spent.
- **Heart:** Declare after one qualifying hit. Choose Fire or Radiant. The Proficiency Bonus damage is part of that hit's packet and cannot critically multiply separately.
- **Lung:** The +1 AC applies only against ranged attack rolls. Advantage applies to checks and saves against inhaled poison, gas, smoke, suffocation, and effects that expressly interfere with breathing. Holding breath does not grant speech, spellcasting, or sound production without air.
- **Liver:** After one Stamina-spending Path or Subpath activation resolves, regain Hit Points equal to Proficiency Bonus if above 0 Hit Points. Spending several Stamina at once produces one trigger.
- **Kidney:** After one Stamina-spending activation resolves, stand from Prone without spending movement and then move up to 5 feet without provoking, or take either operation alone. The movement follows a legal route.
- **Spleen:** After Stamina Guard resolves or after you succeed on a check or save that prevents or reduces hostile forced movement, gain Temporary Hit Points equal to Proficiency Bonus. Repeated Temporary Hit Points replace rather than add unless another rule says otherwise.
- Visible Furnace signs are cosmetic unless a feature says they reveal information. Suppressing or revealing them does not conceal an activation from a sense that can otherwise detect the cultivation effect.

#### CL3 - Five-Viscera Circuit

Gain the Organ Furnace system. When Initiative is rolled, choose an active Furnace before the first turn. You may suppress or reveal visible signs without using an action.

##### Normalized Procedure — Five-Viscera Circuit

- When Initiative is rolled, choose the Furnace active before your first turn. This choice applies during the interval before that turn and can use its once-per-turn benefit during another creature's turn if its trigger occurs.
- At the start of your first turn, choose again under the normal Organ Furnace procedure. A use spent before your turn does not prevent the Furnace's new-turn use after the turn begins.
- Becoming Unconscious does not destroy the cultivated organs, but active Furnace benefits become dormant while a rule prevents you from using Path features. When that state ends, resume the previous legal Furnace selection until the next start-of-turn choice.

#### CL6 - Refine the Impure

**Bonus Action**  
**Cost:** 2 Stamina

Choose one effect:

- **Poisoned:** Repeat the original save with Advantage. Success ends it; failure suppresses it until the start of your next turn.
- **Disease:** Make a Constitution save against its printed DC. Success suppresses active penalties for 24 hours. Three successes against the same disease end it; failures do not erase successes.
- **Ongoing Acid or Poison:** Repeat its save with Advantage. Success ends it; failure reduces its next damage by `2d8 + Constitution modifier`.
- **Contaminated Substance:** End one temporary numerical penalty directly caused by consumed poison, spoiled medicine, contaminated food, or ordinary alchemical substance.

Cannot remove Exhaustion, Hidden Injuries, Foundation damage, Tribulation scars, curses, possession, permanent corruption, or an effect tagged Curse, Tribulation, Foundation Injury, or Permanent.

##### Normalized Procedure — Refine the Impure

- Choose one effect currently affecting you, spend the Bonus Action and 2 Stamina, and resolve only its matching option. Refine the Impure is a bodily purification procedure, not general dispelling or exorcism.
- **Poisoned:** Use the original save and DC that imposed the Poisoned condition. If no save was printed, make a Constitution save against the source's Cultivation Save DC or its fallback Authority DC. Success ends that one Poisoned condition. Failure suppresses only that condition's effects until the start of your next turn; its duration continues.
- **Disease:** Make a Constitution save against the printed disease DC or fallback Authority DC. Record successes separately for each disease. A success suppresses that disease's active penalties for 24 hours and adds one success; three total successes end it. Failure adds no consequence and erases no successes. A new infection is a new record unless the disease says otherwise.
- **Ongoing Acid or Poison:** Repeat the save printed by one ongoing Acid- or Poison-damage effect. If none exists, make a Constitution save against its source DC. Success ends that effect. Failure reduces only its next damage packet by `2d8 + Constitution modifier`, to a minimum of 0; after that packet the reduction expires.
- **Contaminated Substance:** End one temporary numerical penalty directly and solely caused by consumed poison, spoiled medicine, contaminated food, or an ordinary alchemical substance. This can end a penalty to AC, Speed, an ability check, attack roll, save, damage roll, or maximum Hit Points only when the source explicitly identifies that numerical penalty. It does not end damage, a condition, disease, curse, addiction, beneficial tradeoff, or the source item itself.
- The printed exclusions remain absolute. An effect carrying any excluded tag is not eligible merely because it also uses Poison or Disease language.
- Repeated use can attempt the same effect again on later turns. Stamina and the Bonus Action are spent whether the save succeeds or fails.

#### CL10 - Twin Furnace Circulation

At the start of each turn, choose two different Organ Furnaces. Both remain active until the start of your next turn.

Once per turn after spending Stamina, replace one active Furnace with another without using an action. The new Furnace applies immediately but does not retroactively affect events already resolved.

##### Normalized Procedure — Twin Furnace Circulation

- Choose two different Furnaces at the start of each turn. Both are active simultaneously and track their once-per-turn uses separately.
- Once during the turn after a Stamina-spending activation resolves, replace exactly one active Furnace with one currently inactive Furnace without using an action. You can replace only one Furnace through this clause even if the activation spent several Stamina.
- The newly active Furnace can respond to a later qualifying event during that turn if its own once-per-turn benefit has not already been used. Re-selecting a Furnace whose benefit was used earlier that turn does not refresh it.
- Replacing a Furnace does not cancel a duration already created by it, such as Temporary Hit Points or movement already completed, and does not retroactively grant AC, Resistance, healing, or another result to an earlier event.

#### CL14 - Fivefold Organ Harmony

All five Furnaces are active simultaneously, with separate once-per-turn limits.

Also gain Resistance to Acid and Poison, Immunity to ordinary disease, immunity to spoiled or ordinarily poisonous food, and add Constitution modifier to one healing roll from a potion, pill, medicine, medicinal food, or alchemical consumable.

Excess healing from such a consumable becomes Temporary Hit Points, to a maximum of twice your Proficiency Bonus.

##### Normalized Procedure — Fivefold Organ Harmony

- All five Furnaces are active simultaneously. Each retains one separate once-per-turn limit; a single Stamina activation can legally trigger both Liver and Kidney, and can also trigger Spleen only if Stamina Guard or a qualifying forced-movement save occurred.
- Acid and Poison Resistance use ordinary damage ordering. Immunity to ordinary disease prevents new ordinary diseases and suppresses their active effects; artifact, divine, Secret, Tribulation, Foundation, Method, Immortal, or explicit equal- or higher-Source-CL disease authority can still contest it.
- Immunity to spoiled or ordinarily poisonous food prevents its harmful poison and contamination effects. It does not make nonfood substances edible, supply nutrition, negate curses, or neutralize an alchemical item before another creature consumes it.
- When you receive healing from one potion, pill, medicine, medicinal food, or alchemical consumable, add Constitution modifier to one healing roll made by that consumable. If it has several healing rolls, choose one after rolling but before applying healing.
- After all healing from that consumable is applied, calculate healing that exceeded missing Hit Points. Gain Temporary Hit Points equal to that excess, to a maximum of twice Proficiency Bonus. These Temporary Hit Points replace rather than stack with existing Temporary Hit Points unless another rule says otherwise.
- This benefit applies once per consumed item or dose and does not multiply healing from repeated ticks produced by the same dose.

#### CL18 - Inner Cosmos Furnace

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 6 Stamina  
**Limit:** Once per scene

All Furnaces remain active and improve:

- **Heart:** Once per turn on a hit, additional `3d8` Fire, Radiant, or Force.
- **Lung:** Ranged attacks against you have Disadvantage; no air required; immune to inhaled poison, smoke, gas, and suffocation.
- **Liver:** Once per turn after spending Stamina, regain `2d8 + Constitution modifier` Hit Points.
- **Kidney:** Once per turn after spending Stamina, move 15 feet without provoking, across liquids and vertical surfaces; fall if unsupported afterward.
- **Spleen:** Once per turn after Stamina Guard or a successful saving throw, gain Temporary Hit Points equal to twice Proficiency Bonus and reduce forced movement by 10 feet until your next turn.

Refine the Impure costs 0 Stamina but remains a Bonus Action.

##### Normalized Procedure — Inner Cosmos Furnace

- Activate as a Bonus Action, spend 6 Stamina, and record the 1-minute once-per-scene state. All five Furnaces remain active and their CL18 versions replace their normal numerical effects for the duration; the normal and improved versions do not stack.
- **Heart:** Once per turn on a hit, choose Fire, Radiant, or Force and add `3d8` to that hit's packet.
- **Lung:** Every ranged attack roll against you has Disadvantage. You require no air and are immune to inhaled poison, smoke, gas, and suffocation. This does not grant sight through smoke, immunity to corrosive contact, or immunity to a noninhaled poison.
- **Liver:** Once per turn after a Stamina-spending activation resolves, regain `2d8 + Constitution modifier` Hit Points if above 0. It replaces the normal Proficiency Bonus healing.
- **Kidney:** Once per turn after a Stamina-spending activation resolves, stand from Prone without movement and move up to 15 feet without provoking, across liquids and vertical surfaces. If unsupported at the end, fall immediately. It replaces the normal 5-foot movement.
- **Spleen:** Once per turn after Stamina Guard resolves or after any successful saving throw against a hostile effect, gain Temporary Hit Points equal to twice Proficiency Bonus and reduce hostile physical forced movement against you by 10 feet until the start of your next turn. The reduction applies to each qualifying physical movement packet during that duration, but not teleportation.
- Refine the Impure costs 0 Stamina during the state but remains a Bonus Action and otherwise follows its complete procedure. A 0-Stamina use does not trigger Liver or Kidney because no Stamina was spent.
- Becoming Unconscious ends Inner Cosmos Furnace under the general transformation rule. Ending it does not remove healing, movement, or Temporary Hit Points already resolved.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Five-Viscera Immortal Furnace

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 31. Still-Water Draw Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The blade moves only after the outcome has become still.*

Still-Water disciples refine breath, posture, grip, perception, and explosive muscular release into a single uninterrupted motion.

**Access Category:** Restricted Scripture  
**Primary Identity:** Opening strikes, explosive draw-cuts, counters, straight-line execution  
**Common Sphere Synergies:** Fencing, Flowing River, Pressure Points, Sword, Wind

#### CL3 - Drawn from Stillness

Choose one Draw Blade as your Draw Weapon.

While wielding it:

- Use Constitution instead of Strength or Dexterity for attack and damage rolls.
- You may use your Cultivation Attack Modifier.
- It is integrated into Body Refining.
- Refined Iron Fist and Heavenly Fist apply.
- Draw or sheath it as part of an attack.

##### First Cut

The first time you hit with your Draw Weapon during each turn, provided you made no earlier attack that turn, deal additional Slashing or Force damage equal to Proficiency Bonus and move 5 feet without provoking.

The weapon need not begin physically sheathed; Draw represents the first committed release.

##### Normalized Procedure — Draw Weapon and First Cut

- Choose and record one weapon in the Draw Blade group. While wielding that weapon, Constitution replaces Strength or Dexterity for its attack and damage rolls, and you may use your Cultivation Attack Modifier. It is integrated into Body Refining and grants no Sphere, extra weapon, or additional attack.
- Drawing or sheathing it as part of an attack changes only its carried state; it does not create a free object interaction usable for another item. The weapon need not begin sheathed for any feature unless that feature expressly says so.
- First Cut qualifies only if the triggering hit is produced by the first attack roll you make during that turn. If that first attack misses, an attack was still made and no later hit that turn qualifies. A save-based technique or nonattack damage made before the attack does not by itself disqualify First Cut unless it includes an attack roll.
- Declare First Cut after the hit. Add Proficiency Bonus as Slashing or Force to the triggering packet, then move up to 5 feet without provoking along a legal route. The movement is optional, occurs after the hit resolves, and cannot pass through occupied spaces without another permission.
- Reactions made during another creature's turn use that turn's separate First Cut eligibility. The feature remains once per turn, not once per round.

#### CL6 - Empty-Scabbard Step

**Reaction**  
**Trigger:** A creature makes a melee attack against you.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Move 10 feet before the attack roll resolves, without provoking and without crossing solid barriers or occupied spaces.

Resolve the attack from your new position. If outside reach, it misses. If it misses while you remain within reach, make one Draw Weapon attack after it resolves. The attack follows the Granted Attack rule.

##### Normalized Procedure — Empty-Scabbard Step

- Declare after a creature commits to one melee attack against you but before the triggering attack roll. Spend the Reaction and 1 Stamina, then move up to 10 feet along a continuous legal route without provoking Opportunity Attacks.
- The route cannot cross a solid barrier or any occupied space and must end in a space you can occupy. If no movement is legal, you can remain in place; the feature is still spent.
- After movement, recheck the triggering attack's target, reach, line of effect, and any required facing or adjacency. If you are no longer a legal target, that attack misses without a roll. Otherwise make and resolve the triggering attack roll from the new geometry.
- If the triggering attack misses for any reason and you remain within current Draw Weapon reach of the attacker after it resolves, make one Draw Weapon attack against that attacker. The granted attack occurs after every effect of the miss that must resolve first, follows the Granted Attack rule, and cannot grant another attack.
- If the triggering attack is one attack within a Multiattack or Attack action, only that attack is affected. Later attacks can choose legal targets normally.

#### CL10 - One Breath, Three Horizons

When you take the Attack action, replace two attacks with a line.

**Area:** 30-foot-long, 5-foot-wide line  
**Cost:** 2 Stamina  
**Limit:** Once per turn  
**Saving Throw:** Dexterity

On a failed save, a creature takes two Draw Weapon damage dice + Constitution modifier + `4d8` Slashing or Force damage and cannot take Reactions until the start of its next turn. On a success, half damage and retains Reactions.

After the line, move to any unoccupied space adjacent to it without provoking, up to half your Speed.

This is not a weapon attack and does not apply attack-hit riders.

##### Normalized Procedure — One Breath, Three Horizons

- You must have at least two attacks available in the current Attack action. Replace exactly two of those attacks before either is made, spend 2 Stamina, and create one 30-foot-long, 5-foot-wide line originating from you in a chosen direction.
- Every creature other than you whose space intersects the line makes one Dexterity save and is affected once. Total cover blocks the line; resolve eligible creatures from nearest to farthest until a surviving solid obstruction stops it.
- On failure, roll two copies of the Draw Weapon's printed damage die, add Constitution modifier once, and add `4d8` Slashing or Force as chosen for the activation. The target also cannot take Reactions until the start of its next turn. On success it takes half total damage and retains Reactions.
- This is one Body technique, not an attack. It cannot critically hit and does not apply attack-hit riders, weapon mastery riders, ammunition, First Cut, or effects requiring a weapon attack.
- After every save and damage packet resolves, move up to half your current Speed without provoking to any legal unoccupied space adjacent to any point of the line. This is physical movement along a legal route, not teleportation. If no route exists, remain in place.
- The replacement remains once per turn across additional Attack actions.

#### CL14 - Moon Reflected Before Motion

At the start of your turn, before moving or taking an action, enter Still-Water Posture until the end of the turn.

- The first Draw Weapon attack has Advantage.
- Speed becomes 0 until that attack resolves.
- On a hit, additional `3d8` Slashing or Force damage and no Reactions until the start of the target's next turn.
- Afterward, Speed is restored and you move up to half your Speed without provoking.

You may enter this posture once per round. Forced movement does not end it; voluntary movement does.

##### Normalized Procedure — Still-Water Posture

- At the start of your turn, before movement, an Action, Bonus Action, or another voluntary activation, choose whether to enter Still-Water Posture. Entering requires no action and is limited to once per round.
- While in the posture, current Speed is 0 until your first Draw Weapon attack of that turn resolves or the posture ends. Forced movement does not end it. Any willing movement, teleportation, or spatial relocation before that attack ends the posture immediately and grants none of its attack or follow-up movement benefits.
- The first Draw Weapon attack you make during the posture has Advantage. After it resolves, your Speed returns to its normal current value whether the attack hits or misses.
- On a hit, add `3d8` Slashing or Force to the triggering packet and prevent the target from taking Reactions until the start of its next turn. Then move up to half your restored Speed without provoking along a legal route.
- On a miss, no additional damage, Reaction denial, or follow-up movement occurs, but Speed is restored.
- If you never make the attack, Speed remains 0 until the end of the turn and the posture then ends. Actions that do not move you are legal while waiting to make the attack.

#### CL18 - Heaven Divided Before Sound

**Action**  
**Range:** An unoccupied space within 120 feet  
**Cost:** 7 Stamina  
**Limit:** Once per scene

Move in a straight line without provoking, across liquids, vertical surfaces, and open air, and through hostile spaces. You cannot pass through total cover, sealed Formations, spatial locks, or a surviving barrier.

Choose up to Proficiency Bonus creatures crossed or within 5 feet of the line. Make one Draw Weapon attack against each. On a hit, deal normal damage plus `6d8` Slashing or Force.

After all attacks, each hit creature makes a Constitution save.

- **Failed Save:** Speed 0 and no Reactions until the end of its next turn.
- **Successful Save:** Speed halved until the start of its next turn.

When the line intersects a blocking barrier, make one Draw Weapon attack against it before moving through. On a hit, deal normal damage plus `6d8`. If destroyed, continue. If it survives, end in the nearest legal space before it. The barrier counts against maximum targets.

Each creature can be attacked once. Attacks follow the Granted Attack rule.

##### Normalized Procedure — Heaven Divided Before Sound

- Select an unoccupied legal destination within 120 feet and declare the straight line from your current space to that destination. Spend the Action and 7 Stamina. The route is physical movement, not teleportation, and does not provoke Opportunity Attacks.
- You can cross liquids, vertical surfaces, open air, and hostile occupied spaces as printed, but cannot end in an occupied space. Total cover, a sealed Formation, spatial lock, or surviving solid barrier blocks further travel.
- Before moving, choose up to Proficiency Bonus eligible creatures crossed by or within 5 feet of the line. Resolve chosen creatures and blocking barriers in nearest-to-farthest order. Each creature can be attacked once.
- When the line reaches a blocking barrier, make one Draw Weapon attack against it before entering its space. On a hit deal normal damage plus `6d8` Slashing or Force. It counts against the Proficiency Bonus target maximum. If destroyed, continue; if it survives or the attack misses, end in the nearest legal space before it and ignore selected targets beyond it.
- When you reach each selected creature's position along the line, make one Draw Weapon attack. On a hit deal normal damage plus `6d8` Slashing or Force. These are granted attacks and cannot grant additional attacks.
- After all reachable attacks resolve, each creature hit by this activation makes one Constitution save. On failure its Speed becomes 0 and it cannot take Reactions until the end of its next turn. On success its Speed is halved until the start of its next turn.
- A creature hit several times through an unrelated rule makes one save for this activation. The line does not automatically sever limbs, cut space, destroy an undamaged permanent barrier, or ignore explicit higher-Source-CL movement authority.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Still-Water Draw Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 32. Thousand-Fold Steel Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*Heat gives shape. Cold preserves it. The hammer removes everything that cannot endure.*

Thousand-Fold disciples temper flesh through repeated cycles of tension, impact, recovery, and refinement.

**Access Category:** Restricted Scripture  
**Primary Identity:** Shifting bodily temper, offense-defense adaptation, armor cutting, disciplined resilience  
**Common Sphere Synergies:** Blacksmith, Fencing, Guardian, Metal, Sword, Yang

#### Tempering Forms

At the start of each turn, choose one form until the start of your next turn.

- **Edge Form:** Once per turn on a hit with an unarmed strike or melee weapon, deal additional Slashing or Force damage equal to Proficiency Bonus. Unarmed strikes may deal Slashing.
- **Spine Form:** Reduce the first Bludgeoning, Piercing, or Slashing damage each round by Proficiency Bonus; Advantage against Prone.
- **Reed Form:** Once per turn after you hit with a melee attack or a melee attack misses you, move 5 feet without provoking; Advantage to escape Grappled.

##### Normalized Procedure — Tempering Form State

- Record active Forms and each Form's once-per-turn or once-per-round use. At CL3 one Form is active, at CL14 two different Forms are active, and at CL18 all three are active.
- Choose Forms at the start of each turn before resolving another start-of-turn choice. If you cannot or do not choose, retain the previous legal selection; if none exists, activate Edge first.
- **Edge:** Declare after one qualifying unarmed-strike or melee-weapon hit. Add Proficiency Bonus as Slashing or Force to that hit's packet. Allowing an unarmed strike to deal Slashing changes its damage choice; it does not create a blade or harvestable body part.
- **Spine:** Reduce the first Bludgeoning, Piercing, or Slashing damage packet applied to you each round by Proficiency Bonus at the shared flat-reduction step. A packet reduced to 0 still consumes the round's use. Advantage applies to checks and saves made to avoid or resist Prone.
- **Reed:** Once per turn after you hit with a melee attack or after a melee attack against you misses, move up to 5 feet without provoking along a legal route. Advantage applies to checks and saves made to escape Grappled.
- A Form selected later through Quench the Impact applies prospectively. Deactivating and reactivating a Form does not reset a use already spent during the same turn or round.

#### CL3 - Body Forged in Three Forms

Gain the Tempering Forms.

Your body and a melee weapon currently benefiting from this Subpath's weapon-integration feature count as smithing tools only for maintaining, sharpening, cleaning, or repairing your own weapons and armor during rest or downtime. This does not replace Blacksmith proficiency for crafting.

##### Normalized Procedure — Tempered Weapon Integration and Smithing Use

- The source references this Subpath's weapon-integration feature without printing its record. To make the referenced function executable, choose one melee weapon you are proficient with when you finish a Full Cultivation Session or spend 10 minutes tempering it against your body. It becomes your **Tempered Weapon** until you choose another.
- While wielding the Tempered Weapon, Constitution replaces Strength or Dexterity for its attack and damage rolls, you may use your Cultivation Attack Modifier, and it is integrated into Body Refining. Refined Iron Fist and Heavenly Fist apply through their printed integrated-weapon interface. This grants no proficiency, Sphere, talent, duplicate weapon, or extra attack.
- The Tempered Weapon can be changed through the same 10-minute procedure. A destroyed, lost, or unwielded weapon provides no integration benefit until recovered or replaced.
- Your body and current Tempered Weapon count as smithing tools only for maintaining, sharpening, cleaning, or repairing your own weapons and armor during a rest, Full Cultivation Session, or downtime. This supplies the tool object but not Blacksmith proficiency, formulas, materials, facility authority, or permission to craft a new item.
- This paragraph repairs an explicit missing dependency in the source and does not alter any printed damage die, cost, range, limit, or tier.

#### CL6 - Quench the Impact

**Reaction**  
**Trigger:** You take qualifying hostile damage.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Change your active form immediately and apply its Quench benefit:

- **Edge Quench:** Your next melee attack before the end of your next turn deals an additional `2d8` Slashing or Force damage.
- **Spine Quench:** Reduce triggering damage by `2d8 + Constitution modifier`.
- **Reed Quench:** After damage resolves, move 15 feet without provoking.

The selected form remains until the start of your next turn.

##### Normalized Procedure — Quench the Impact

- Declare when qualifying hostile damage would be applied to you, after percentage modifiers are known but before Hit Points are reduced. Spend the Reaction and 1 Stamina, choose one Form, and make it active immediately until the start of your next turn.
- At CL3–13, the selected Form replaces the current active Form. At CL14+, use the feature's two-Form replacement rule. Selecting a Form already active is legal and still grants its Quench benefit.
- **Edge Quench:** After the triggering damage resolves, record one charge. Your next melee attack before the end of your next turn adds `2d8` Slashing or Force to its damage on a hit. A new Edge Quench refreshes rather than stacks with an unused charge.
- **Spine Quench:** Reduce the triggering packet by `2d8 + Constitution modifier` at the shared damage-reduction step. This is separate from Spine Form's first-packet reduction and can apply to the same packet if both are available.
- **Reed Quench:** After the triggering damage resolves, move up to 15 feet without provoking along a legal route. The movement occurs even if final damage became 0, but not if the damage event was canceled before it existed.
- Changing Forms is prospective. It does not retroactively alter the triggering attack roll, percentage modifiers, damage type, or another event already resolved.

#### CL10 - Folded Edge, Hidden Spine

Your Body Refining melee attacks ignore ordinary Resistance to Bludgeoning, Piercing, and Slashing.

Once per turn when you hit while Edge Form is active, choose one:

- Reduce target AC by 1 until the start of your next turn.
- Prevent Reactions until the start of its next turn.
- Deal an additional `2d8` Slashing or Force damage.
- Deal double damage to an unattended object, temporary barrier, vehicle, structure, or Formation Anchor.

The AC reduction does not stack with itself.

##### Normalized Procedure — Folded Edge, Hidden Spine

- Body Refining melee attacks ignore ordinary Resistance to Bludgeoning, Piercing, and Slashing. “Ordinary” excludes Immunity, artifact defenses, divine authority, Secret protections, Immortal defenses, and an explicit equal- or higher-Source-CL rule that cannot be bypassed.
- Once per turn after hitting while Edge Form is active, choose exactly one printed result. This is separate from Edge Form's Proficiency Bonus damage and can be applied to the same hit.
- AC reduction begins after the hit resolves and lasts until the start of your next turn. Reapplication refreshes duration and does not stack with itself.
- Reaction denial lasts until the start of the target's next turn and does not cancel a Reaction already spent.
- The `2d8` Slashing or Force is part of the triggering hit's packet and cannot critically multiply separately.
- Against an eligible unattended object, temporary barrier, vehicle, structure, or Formation Anchor, calculate the triggering hit's final damage under ordinary modifiers and then double that hit's damage once. The doubling does not apply to later damage packets or world-scale terrain that is not a legal target.
- A target cannot receive several choices from one use even if several effects would be legal.

#### CL14 - Ten Thousand Reforgings

Maintain two different Tempering Forms simultaneously. When using Quench the Impact, replace one or both active forms but apply only one Quench benefit.

Improvements:

- Edge additional damage becomes twice Proficiency Bonus.
- Spine damage reduction becomes twice Proficiency Bonus.
- Reed movement becomes 10 feet.

##### Normalized Procedure — Ten Thousand Reforgings

- Choose two different active Forms at the start of each turn. Each Form keeps its own limit and benefit.
- When you use Quench the Impact, choose one Quench benefit. You may replace one active Form with another, replace both active Forms with the other two-Form combination, or retain the current pair. Forms must remain different.
- Applying one Quench benefit does not apply the benefit of the second newly selected Form. Its normal Form benefit becomes active prospectively.
- Edge Form's once-per-turn damage becomes twice Proficiency Bonus. Spine Form's first-packet reduction becomes twice Proficiency Bonus. Reed Form's once-per-turn movement becomes 10 feet. These replace, rather than add to, their earlier numerical values.
- If effective CL suppression removes this feature, retain one legal active Form chosen by you and make the second dormant until access returns or the next start-of-turn choice.

#### CL18 - Body Beyond the Hammer

All three Forms are active simultaneously.

- You cannot be Disarmed by an ordinary effect.
- Unarmed strikes and integrated melee weapons count as adamantine.
- Immune to ordinary effects permanently breaking, rusting, warping, corroding, or dulling your body or integrated weapons.
- When an effect would destroy or permanently deform a limb, take `4d10` Force damage instead and the limb remains functional. This damage cannot be reduced by this Subpath.

Once per turn on a melee hit, choose one:

- **Perfect Edge:** Additional `4d8` Slashing or Force and reduce AC by 1 until your next turn.
- **Perfect Spine:** Temporary Hit Points equal to `2 x Proficiency Bonus + Constitution modifier`; cannot be pushed, pulled, or knocked Prone until your next turn.
- **Perfect Reed:** Move 20 feet without provoking and through hostile spaces as difficult terrain.

Each option can be selected only once per turn.

##### Normalized Procedure — Body Beyond the Hammer

- All three Forms are active simultaneously and no start-of-turn Form choice is required.
- Ordinary Disarm immunity and immunity to ordinary permanent breaking, rusting, warping, corrosion, or dulling protect your body and current Tempered Weapon. They do not restore an item already destroyed, protect another creature's weapon, or override artifact, divine, Secret, Foundation, Method, Immortal, or explicit equal- or higher-Source-CL authority.
- Unarmed strikes and the Tempered Weapon count as adamantine for rules that recognize that material. This does not change their damage type or grant an item property not printed here.
- When a Source Rule would destroy or permanently deform one physical limb, natural-weapon structure, or equivalent reconstructable appendage, replace only that anatomical result with `4d10` Force damage and keep the structure functional. This replacement does not apply to conceptual erasure, complete bodily destruction, Foundation destruction, or an effect that does not target anatomy.
- The replacement damage cannot be reduced by Thousand-Fold Steel Body, including Spine Form, Spine Quench, or Perfect Spine. Other independent legal defenses can interact unless the original Source Rule says otherwise. Other nonanatomical consequences of the triggering effect still resolve.
- Once per turn after one melee hit, choose one Perfect result. This use is separate from Folded Edge, Hidden Spine and can coexist on the same hit.
- **Perfect Edge:** Add `4d8` Slashing or Force and reduce AC by 1 until the start of your next turn. It refreshes, not stacks with, this Subpath's other AC reduction.
- **Perfect Spine:** Gain Temporary Hit Points equal to `2 × Proficiency Bonus + Constitution modifier` and become immune to physical push, pull, and Prone until the start of your next turn. It does not block teleportation or voluntary movement.
- **Perfect Reed:** Move up to 20 feet without provoking. You can pass through hostile spaces as difficult terrain but cannot end in an occupied space or pass through a solid obstruction.
- Each Perfect option can be selected at most once during the same turn even if another rule would permit another Perfect choice.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Thousand-Fold Steel Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 33. Adamant Thunderbolt Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The storm strikes once. The body answers forever.*

Adamant Thunderbolt disciples refine bone density, nerve conduction, muscle contraction, and internal pressure until the body becomes an unbreakable weapon and living conduit.

**Access Category:** Restricted Scripture  
**Primary Identity:** Adamant durability, explosive impact, lightning conduction, anti-defense strikes  
**Common Sphere Synergies:** Force, Guardian, Lightning, Metal, Pressure Points, Thunder

#### Thunder Charges

- Maximum equals Proficiency Bonus.
- Begin each scene with 0; disappear at scene end.
- Gain no more than 1 per round.
- Gain 1 after Stamina Guard reduces hostile damage by at least Proficiency Bonus, succeeding on a hostile Strength or Constitution save, taking hostile Lightning, Thunder, or Force damage, or hitting after moving 10 feet.

##### Normalized Procedure — Thunder Charge Record

- Record current Thunder Charges, maximum Charges equal to Proficiency Bonus, whether a normal Charge has been gained this round, and scene expiration. Begin each scene at 0 and lose all unused Charges when the scene ends.
- The normal gain limit is one total Charge per round across all listed triggers. If several triggers occur in one event, choose one and gain one Charge. A trigger after the limit is spent grants none.
- Qualifying triggers resolve after their event: Stamina Guard must reduce one hostile packet by at least Proficiency Bonus; the hostile Strength or Constitution save must succeed; hostile Lightning, Thunder, or Force damage must actually be applied; or an attack must hit after you physically moved at least 10 feet during the current turn.
- Teleportation does not count as moving 10 feet unless its Source Rule expressly says it counts as movement. Forced movement counts only if you willingly directed or accepted it and its rule says it counts as your movement.
- A Charge granted by Thunder Runs Through Bone after reducing damage to 0 ignores the one-per-round gain limit but not the maximum. If already at maximum, no additional Charge is stored.
- Spending Charges occurs when the feature is declared. If an activation later misses or is prevented, spent Charges are not refunded unless that feature expressly says so.
- Charges are a scene resource, not Lightning objects, ammunition, bodily Assets, or transferable energy.

#### CL3 - Adamant Frame

Unarmed strikes may deal Bludgeoning, Force, Lightning, or Thunder. Gain Resistance to Lightning.

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Thunder Charge  
**Limit:** Once per turn

Deal an additional `1d8` Lightning, Thunder, or Force, increasing to `2d8` at CL11 and `3d8` at CL17.

Choose one:

- Push 5 feet.
- No Reactions until the start of the target's next turn.
- Gain Temporary Hit Points equal to Proficiency Bonus.
- Add Proficiency Bonus to your next Strength or Constitution save before your next turn.

##### Normalized Procedure — Adamant Frame

- Choose Bludgeoning, Force, Lightning, or Thunder separately for each unarmed strike's damage. This choice changes that strike's damage type and does not create an external projectile.
- After one unarmed strike hits, spend 1 Thunder Charge and declare the once-per-turn rider. Choose Lightning, Thunder, or Force for the added damage. It is part of the triggering packet and uses `1d8`, `2d8` at CL11, or `3d8` at CL17; it cannot critically multiply separately.
- Choose exactly one secondary result after applying the damage.
- A push moves 5 feet directly away along a legal route. Reaction denial lasts until the start of the target's next turn.
- Temporary Hit Points equal to Proficiency Bonus replace rather than stack unless another rule says otherwise.
- The save bonus applies to the next Strength or Constitution saving throw you make before the start of your next turn. Several applications refresh the bonus and expiration; they do not stack.
- The once-per-turn rider remains one total use across granted attacks, Reactions, and additional Attack actions.

#### CL6 - Thunder Runs Through Bone

**Reaction**  
**Trigger:** You take Bludgeoning, Force, Lightning, or Thunder damage.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Reduce damage by `2d10 + Constitution modifier`.

If reduced to 0, gain 1 Thunder Charge, move 10 feet without provoking, and your next unarmed strike before the end of your next turn has Advantage. This Charge can exceed the normal gain limit.

##### Normalized Procedure — Thunder Runs Through Bone

- Declare when one Bludgeoning, Force, Lightning, or Thunder damage packet would be applied to you, after percentage modifiers are known but before Hit Points are reduced. Spend the Reaction and 1 Stamina.
- Reduce that packet by `2d10 + Constitution modifier` at the shared flat-reduction step. It can combine with Stamina Guard or another legal reduction according to damage ordering.
- If final triggering damage applied becomes 0, gain 1 Thunder Charge even if you already gained a normal Charge this round, up to the normal maximum. Then move up to 10 feet without provoking along a legal route.
- Record Advantage on your next unarmed strike made before the end of your next turn. A new successful use refreshes, rather than stacks with, this pending Advantage.
- The movement and Advantage occur after the damage packet resolves. If no legal movement exists, remain in place and retain the other benefits.
- A packet that was canceled before damage existed, was not one of the listed types, or was reduced to 0 solely before this feature applied does not produce the extra Charge or follow-up benefits.

#### CL10 - Heaven-Breaking Knuckle

**Trigger:** You hit with an unarmed strike.  
**Cost:** 2 Stamina and 2 Thunder Charges  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Deal an additional `4d8` Force or Thunder.

On a failed save, choose two; on a success, choose one of the first four:

- Push 15 feet.
- Knock Prone.
- No Reactions until the start of its next turn.
- Reduce AC by 2 until the start of your next turn.
- End one temporary barrier, ward, or defensive stance whose Source CL is no higher than yours.

The AC reduction does not stack.

##### Normalized Procedure — Heaven-Breaking Knuckle

- Declare after an unarmed strike hits, spend 2 Stamina and 2 Thunder Charges, and add `4d8` Force or Thunder to the triggering hit's packet. The same target then makes one Constitution save.
- On failure choose two different results. On success choose one of the first four results; ending a defense is not available on success.
- The 15-foot push moves directly away along a legal route. Prone applies after movement. Reaction denial lasts until the start of the target's next turn.
- AC reduction begins after the hit and lasts until the start of your next turn. Reapplication refreshes and does not stack with itself.
- To choose the fifth result, identify one temporary barrier, ward, or defensive stance currently benefiting the target or occupying its space whose Source CL is no higher than this feature's Source CL. It must be a persistent temporary effect that expressly grants AC, cover, Resistance, damage reduction, attack Disadvantage, movement denial, or another defensive benefit.
- The selected defense ends after the triggering hit resolves. This result does not end permanent anatomy, armor, a Foundation, Method, Domain, artifact property, Immortal feature, beneficial condition without a persistent source, or an effect with higher Source CL.
- One use cannot select the same result twice.

#### CL14 - Body of the Unbroken Bolt

Gain Resistance to Force and Thunder, Immunity to Deafened, Advantage against Paralyzed and Stunned, and Immunity to ordinary bone-breaking effects.

Unarmed strikes ignore ordinary Resistance to Bludgeoning, Lightning, Thunder, and Force.

Once per round when a hostile creature within reach misses you with a melee attack, gain 1 Thunder Charge.

##### Normalized Procedure — Body of the Unbroken Bolt

- Force and Thunder Resistance use ordinary damage ordering. Deafened Immunity blocks the condition but does not create hearing in silence, vacuum, destroyed hearing anatomy, or a stronger sensory suppression.
- Advantage applies to saving throws made to avoid or end Paralyzed and Stunned. Immunity to ordinary bone-breaking effects prevents ordinary physical fracture and its direct penalties; it does not prevent Hit Point damage, nonbone Injury, Foundation damage, conceptual destruction, or explicit higher-authority anatomical effects.
- Unarmed strikes ignore ordinary Resistance to Bludgeoning, Lightning, Thunder, and Force. “Ordinary” excludes Immunity, artifact defenses, divine authority, Secret protections, Immortal defenses, and an explicit equal- or higher-Source-CL rule that cannot be bypassed.
- Once per round after a hostile creature currently within your reach resolves a melee attack against you and misses, gain 1 Thunder Charge subject to the normal maximum and one-normal-Charge-per-round limit.
- Reach expansion around a creature does not retroactively make an earlier miss qualify.

#### CL18 - Adamantine Descent

**Action**  
**Range:** An unoccupied space within 120 feet  
**Cost:** 7 Stamina and all current Thunder Charges  
**Requirement:** At least 3 Charges  
**Limit:** Once per scene

Move to the selected space without provoking, crossing open air but not total cover, sealed Formations, spatial locks, or surviving solid barriers.

Each chosen creature within 20 feet makes a Dexterity saving throw.

Damage equals `8d10 Force or Thunder + 1d10 per Charge spent`.

- **Failed Save:** Full damage, Prone, pushed 20 feet, no Reactions until the end of its next turn.
- **Successful Save:** Half damage, pushed 5 feet, retains Reactions.

Objects, temporary barriers, vehicles, structures, and Formation Anchors take double damage.

Afterward, gain Resistance to all damage except Psychic and Void until your next turn, and your next unarmed strike before the end of your next turn deals an additional `4d8` Force.

##### Normalized Procedure — Adamantine Descent

- Choose an unoccupied legal destination within 120 feet and a continuous physical route through open air from your current space. At least 3 Thunder Charges are required. Spend the Action, 7 Stamina, and every current Thunder Charge when declared.
- Move along that route without provoking. This is not teleportation. Total cover, a sealed Formation, spatial lock, or a surviving solid barrier stops the movement at the nearest legal space before it. Occupied spaces and ordinary open gaps can be crossed only when your body can physically pass; you cannot end in an occupied space.
- After reaching the final space, choose any number of creatures within 20 feet. Each makes one Dexterity save and is affected once. Damage is `8d10` Force or Thunder, chosen for the activation, plus `1d10` for each Thunder Charge spent.
- On failure apply full damage, Prone, a 20-foot push directly away, and Reaction denial through the end of the target's next turn. On success apply half damage and a 5-foot push; it retains Reactions.
- Resolve pushes after damage. A blocked push stops at the nearest legal space and creates no collision unless another rule expressly creates one.
- Each eligible unattended object, temporary barrier, vehicle, structure, and Formation Anchor in the area takes one packet equal to twice the rolled damage. It makes no save unless its own profile says otherwise. Permanent world terrain must still be a legal target.
- After all area effects resolve, gain Resistance to all damage except Psychic and Void until the start of your next turn. Record one pending unarmed-strike rider before the end of your next turn; on a hit it adds `4d8` Force to that hit's packet. Reapplication is impossible because the feature is once per scene.
- Adamantine Descent does not automatically create a crater, destroy anatomy, silence an area, or pass through a surviving barrier.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Adamant Thunderbolt Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 34. Seven-Coiled Serpent Spine

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*The body appears still because its violence has not yet reached the surface.*

Seven-Coiled disciples refine the spine, breath, hips, nervous system, and circulation into successive coils of stored power.

**Access Category:** Restricted Scripture  
**Primary Identity:** Progressive bodily awakening, flexibility, explosive release, constriction  
**Common Sphere Synergies:** Athletics, Flowing River, Jujutsu, Lightning, Pressure Points, Wrestling

#### Coil Rules

At the start of your turn, open or close Coils without using an action.

- Benefits are cumulative and Coils open in order.
- Coils remain until closed or scene end.
- At the end of your turn, after all other end-of-turn effects you choose, spend 1 Stamina if four or more Coils are open, or 2 if all seven are open.
- If you cannot pay, all Coils close.

##### Normalized Procedure — Coil State and Upkeep

- Record the highest open Coil. Every lower-numbered Coil is also open, and benefits are cumulative. At the start of your turn, before another start-of-turn choice, you may set the highest open Coil to any Coil you can access or close all Coils; no action is required and Coils cannot be skipped.
- A Coil opened during that start-of-turn choice applies prospectively for the turn. Closing a Coil immediately removes its ongoing benefits but does not reverse movement, damage, senses, or another result already resolved.
- Coils remain open between turns until changed, the scene ends, you die, become Unconscious, or your Body Refining cultivation is completely suppressed.
- At the end of your turn, resolve every other end-of-turn effect in an order you choose. If you remain conscious with Coils open, then pay upkeep: 2 Stamina if all seven are open; otherwise 1 Stamina if four, five, or six are open; otherwise 0.
- The seven-Coil cost replaces the four-or-more cost; it is not added to it. If you cannot or decline to pay the full required amount, all Coils close immediately. Partial payment is not permitted.
- If Realm Suppression removes access to higher Coils, close every Coil above the highest one you can sustain. This is closure, not dormancy, and does not refund earlier upkeep or damage.
- A Coil is a bodily cultivation state, not a separate transformation, creature, Asset, detachable spine, or transferable resource.

#### CL3 - First and Second Coils

- **Root Serpent:** Advantage against Grappled, Shoved, and Prone; standing costs 5 feet.
- **Swift Serpent:** Speed +10 feet; once per turn after a hit, move 5 feet without provoking.

##### Normalized Procedure — First and Second Coils

- **Root Serpent:** Advantage applies to checks and saves made to avoid, resist, or escape Grappled, Shoved, or Prone. Standing from Prone costs 5 feet of movement regardless of current Speed, unless Speed is 0.
- **Swift Serpent:** Add 10 feet to walking Speed. Once per turn after one attack hits, move up to 5 feet without provoking along a legal route. The movement occurs after the hit resolves and does not require an unarmed strike.
- Each benefit operates only while its Coil remains open. Closing Swift Serpent does not retract movement already completed.

#### CL6 - Third and Fourth Coils

- **Crushing Serpent:** Count as one size larger while Grappling; at start of each turn deal Constitution modifier damage to a Grappled creature; drag at full Speed if no more than one size larger.
- **Striking Serpent:** Once per turn on a hit, additional `1d8` Bludgeoning or Force, or `2d8` if the target is Grappled by you.

##### Normalized Procedure — Third and Fourth Coils

- **Crushing Serpent:** Functional size increases by one category only for initiating, maintaining, escaping, and dragging a Grapple. At the start of each of your turns, choose one creature currently Grappled by you; it takes Bludgeoning damage equal to Constitution modifier, minimum 0. This is not an attack and does not trigger hit riders.
- While dragging no more than one Grappled creature that is no more than one size category larger than your actual or applicable functional size, your Speed is not halved by the ordinary Grapple drag rule. Terrain and other movement penalties still apply.
- **Striking Serpent:** Once per turn after any hit, add `1d8` Bludgeoning or Force to that hit's packet, or `2d8` if the target is currently Grappled by you when damage is applied. Choose damage type on use. It cannot critically multiply separately.
- The once-per-turn damage remains one total use across all attacks and turns normally reset it.

#### CL10 - Fifth Coil: Ascending Serpent

While open:

- Climb Speed equal to Speed.
- Jump distances quadrupled.
- Move across liquids and vertical surfaces during your turn.
- Once per turn after moving 15 feet, your next unarmed strike has Advantage.

On a hit with that attack, spend 1 Stamina. The target makes a Strength save. On a failure, throw it 20 feet; on a success, push 5 feet.

A target thrown into another creature causes both to take Bludgeoning damage equal to Proficiency Bonus; the second creature avoids it on a successful Dexterity save.

##### Normalized Procedure — Ascending Serpent

- Climb Speed equals current walking Speed. Quadruple jump distances after ordinary jump calculations. During your turn you can move across liquids and vertical surfaces while movement remains; if unsupported when movement ends, resolve falling immediately.
- Once per turn, after you have physically moved at least 15 feet during the current turn, record Advantage on your next unarmed strike before the end of that turn. Teleportation does not count unless expressly treated as movement.
- After that advantaged strike hits, you may spend 1 Stamina. The target makes one Strength save. On failure, throw it up to 20 feet in a direction you choose along a legal trajectory. On success, push it 5 feet directly away from you.
- A throw or push stops at the nearest legal space before a solid obstruction. If the failed-save target first enters another creature's space and cannot continue, both creatures take Bludgeoning damage equal to your Proficiency Bonus; the second creature makes one Dexterity save and takes no collision damage on success. Resolve one second-creature collision only.
- The thrown target takes its collision damage automatically. Collision damage does not create Prone, an Injury, another throw, or repeated contacts unless another Source Rule says so.

#### CL14 - Sixth Coil: Crowned Serpent

While open:

- Blindsight 20 feet.
- Advantage against Charmed and Frightened.
- Cannot be Surprised while conscious.
- Unarmed reach +5 feet during your turn.

Once per round when a hostile creature within Blindsight moves or teleports, spend 1 Stamina to move 10 feet without provoking, ending closer to it.

##### Normalized Procedure — Crowned Serpent

- Blindsight functions within 20 feet through the senses of your cultivated body. It does not see through total cover, identify a creature beyond the sense's range, or automatically reveal a creature protected by stronger supernatural concealment.
- Advantage applies to saves made to avoid or end Charmed and Frightened. You cannot be Surprised while conscious, following the finalized Surprise procedure.
- The +5-foot unarmed reach applies only during your turn and does not enlarge threatened space outside your turn.
- Once per round, after a hostile creature that was within your Blindsight at the start or end of its movement or teleportation finishes that movement, you may spend 1 Stamina to move up to 10 feet without provoking.
- Your movement is physical, follows a legal route, and must end closer to that creature than you began. If no legal destination is closer, you cannot activate the movement. The feature does not follow the creature through a teleport, grant its destination, or bypass total cover.

#### CL18 - Seventh Coil: Heaven-Swallowing Serpent

While open:

- Speed doubles.
- Fly Speed equal to walking Speed and Hover.
- Resistance to all damage except Psychic and Void.
- Unarmed strikes deal an additional `2d8` Force.
- Grapple creatures up to two sizes larger.
- A Grappled creature cannot teleport unless it succeeds on a Cultivation Check against your DC; failure uses Failed Spatial Movement.

Once per turn when you hit a Grappled creature, spend 2 Stamina for **Heaven-Swallowing Constriction**. It makes a Constitution save.

- **Failed Save:** `6d8` Bludgeoning or Force, no Reactions, Speed 0, and Disadvantage on Strength, Dexterity, and Constitution saves until your next turn.
- **Successful Save:** Half damage and Speed halved until your next turn.

At the end of each turn with the Seventh Coil open, take `2d8` Force damage that cannot be reduced, prevented, redirected, absorbed, or used to generate resources.

##### Normalized Procedure — Heaven-Swallowing Serpent

- Double walking Speed after fixed additions. A movement mode explicitly equal to walking Speed uses the doubled value; fixed Speeds and teleport ranges do not.
- Gain Fly Speed equal to current walking Speed and Hover. If the Coil closes or is suppressed while unsupported, resolve falling immediately unless another support remains.
- Resistance to all damage except Psychic and Void follows ordinary ordering. The `2d8` Force added to every unarmed-strike hit is part of that hit's packet and does not have a once-per-turn limit.
- Functional size increases by two categories only for Grappling. It combines with Crushing Serpent by using the highest applicable value rather than increasing by three categories.
- A creature Grappled by you that attempts any teleportation or spatial movement must first make one Cultivation Check against your Cultivation Save DC. On failure use Failed Spatial Movement; on success the spatial movement resolves and ordinarily ends the physical Grapple unless its rule says otherwise.
- Once per turn after hitting a creature currently Grappled by you, spend 2 Stamina to use Heaven-Swallowing Constriction. It makes one Constitution save. On failure it takes `6d8` Bludgeoning or Force, cannot take Reactions, has Speed 0, and has Disadvantage on Strength, Dexterity, and Constitution saves until the start of your next turn. On success it takes half damage and its Speed is halved until the start of your next turn.
- Constriction damage is a separate packet created by the same activation and does not automatically create an Injury or destroy organs.
- At the end of each turn while the Seventh Coil remains open, before Coil upkeep, take `2d8` Force damage applied directly to Hit Points. It cannot be reduced, prevented, redirected, absorbed by Temporary Hit Points, delayed, shared, or converted into healing, Stamina, Charges, Beats, Momentum, or another resource.
- If that damage makes you Unconscious, all Coils close before upkeep and no Stamina is paid. Otherwise pay the printed 2-Stamina seven-Coil upkeep after the damage.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Seven-Coiled Serpent Spine

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 35. Hundred-Hand Battle Mandala

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.


*One body is enough when every motion contains a hundred completed strikes.*

Hundred-Hand disciples refine coordination, balance, peripheral perception, shoulder rotation, weapon transitions, and afterimage-like bodily force.

**Access Category:** Restricted Scripture  
**Primary Identity:** Multiweapon combat, attack sequencing, simultaneous defense, many-handed battle patterns  
**Common Sphere Synergies:** Boxing, Fencing, Open Hand, Pressure Points, Warleader, Weapons

#### Battle Hands

You have Battle Hands equal to your Proficiency Bonus. All refresh at the start of your turn and unused Hands disappear at the start of your next turn. Spending a Hand requires no action unless stated otherwise.

##### Normalized Procedure — Battle Hand Record

- Record current Battle Hands, maximum Hands equal to Proficiency Bonus, Hands spent during the current turn, and the current round's Circle of Uncounted Arms uses.
- At the start of each of your turns, every unused Hand from the prior cycle disappears and current Hands become the maximum. Hands remain available during other creatures' turns until the start of your next turn.
- Spending a Hand requires no action unless its feature states otherwise. If an activation is illegal or lacks enough Hands, it cannot be declared. Spent Hands are not refunded because an attack misses, a save succeeds, movement is blocked, or a target becomes illegal unless a feature says so.
- Battle Hands are an abstract coordination resource. They are not literal additional limbs, attacks, Reactions, objects, Body Assets, or permission to hold more equipment.
- Outside Thousand-Hand Incarnation, the maximum is Proficiency Bonus. When that state ends, current Hands above the normal maximum disappear immediately.

#### Weapon Forms

Weapons are assigned one printed Form: Unarmed, Blade, Hafted, Polearm, Flexible, Thrown, or Shield. Switching between weapons of the same Form does not satisfy a different-Form requirement.

##### Normalized Procedure — Weapon Form Records

- Every weapon, shield used as a weapon, natural bodily weapon, and unarmed strike used with this Subpath has exactly one recorded Form: Unarmed, Blade, Hafted, Polearm, Flexible, Thrown, or Shield.
- Use the item's printed Form tag when present. Otherwise use its ordinary construction: edged cutting weapon as Blade; mace, hammer, club, or striking axe as Hafted; spear, staff, glaive, or halberd as Polearm; chain, whip, rope dart, or flexible segmented weapon as Flexible; a weapon with the Thrown property as Thrown when thrown; a shield attack as Shield; and an unarmed strike or natural bodily weapon as Unarmed.
- A custom or ambiguous weapon must choose one Form in its item record before use. It cannot change Forms from attack to attack unless an explicit item or feature says so.
- Switching between weapons of the same Form does not satisfy a different-Form requirement. A single attack counts as one Form even if another rule would describe the weapon with several categories.
- A Shield Form does not grant an attack by itself; it applies only when another rule permits an attack with the shield.

#### CL3 - Four-Hand Sequence

Once per turn when you take the Attack action, spend 1 Battle Hand to choose one:

- Draw or stow two weapons.
- Move 5 feet without provoking.
- Gain +1 AC until your next turn.
- After one attack misses, add Proficiency Bonus to the attack roll, potentially turning it into a hit.
- After one attack hits, deal additional damage equal to Proficiency Bonus.

Only one Battle Hand can modify the same attack roll.

##### Normalized Procedure — Four-Hand Sequence

- Once during each of your turns when you take the Attack action, spend 1 Battle Hand and choose one printed operation. The operation can occur at a legal point during that Attack action unless its trigger specifies a hit or miss.
- Drawing or stowing two weapons changes only those two item states and does not grant another object interaction.
- The 5-foot movement follows a legal route and does not provoke Opportunity Attacks.
- The +1 AC begins when chosen and lasts until the start of your next turn. Reapplication refreshes and does not stack with itself.
- After an attack roll misses, but before resolving any miss consequence, spend the Hand to add Proficiency Bonus to that roll. Recalculate the outcome against the same target and defenses. This can turn the miss into a hit but is not a reroll.
- After an attack hits, add Proficiency Bonus as one damage type dealt by that attack to the triggering packet. It cannot critically multiply separately.
- Only one Battle Hand operation can modify the same attack roll. A later operation that does not modify the roll, such as movement or AC, still cannot be selected because Four-Hand Sequence is once per turn.

#### CL6 - Weapon-Wheel Body

Any one-handed melee weapon you are proficient with may be integrated into Body Refining.

While wielding at least two different Weapon Forms, or a weapon and Unarmed Form:

- Use Constitution for attack and damage rolls.
- You may use your Cultivation Attack Modifier.
- Draw or switch weapons as part of each attack.
- Once per turn after attacking with one Form, your next attack using a different Form has Advantage.

##### Normalized Procedure — Weapon-Wheel Body

- Any one-handed melee weapon you are proficient with is integrated into Body Refining while you wield it and satisfy the printed multi-Form condition. Constitution replaces Strength or Dexterity for its attack and damage rolls, and you may use your Cultivation Attack Modifier. This grants no proficiency, Sphere, duplicate weapon, or extra attack.
- You satisfy the condition while simultaneously wielding or ready to use at least two different attack-capable Weapon Forms, or one weapon Form plus Unarmed Form. A carried but inaccessible weapon does not qualify. A shield qualifies only when you possess a legal shield attack.
- Drawing or switching weapons as part of each attack applies only to equipment you can physically carry and wield. It does not waive hand requirements, Attunement, ammunition, object weight, or an item's activation rules.
- Once per turn after you make an attack using one Form, record that Form. The next attack you make during the same turn using a different Form has Advantage. After that attack resolves, hit or miss, the benefit is spent.
- If you make another attack with the same Form first, the pending benefit remains available for the next different-Form attack. It expires at the end of the turn.

#### CL10 - Eight-Limb Battle Pattern

When you take the Attack action, spend 2 Battle Hands to make one additional attack as part of it.

The attack must use a different Form from the immediately preceding attack, follows the Granted Attack rule, cannot replace multiple attacks, and does not grant another action.

Once per turn after hitting with three different Forms during the same turn, choose one Completion Effect:

- Push one hit target 10 feet.
- Knock one hit target Prone.
- Prevent one hit target from taking Reactions until its next turn.
- Gain Temporary Hit Points equal to twice Proficiency Bonus.
- Move 15 feet without provoking.

##### Normalized Procedure — Eight-Limb Battle Pattern

- Once during your turn when you take the Attack action, after resolving at least one attack in that action, spend 2 Battle Hands to make one additional attack as part of the same action.
- The additional attack must use a Form different from the immediately preceding attack in that Attack action. It follows the Granted Attack rule, cannot replace itself with several attacks, and cannot grant another attack or Attack action.
- Track distinct Forms that hit during your current turn. Once per turn immediately after the third different Form hits, or after a later different-Form hit if the Completion was not yet used, choose one Completion Effect.
- A push or Prone result must target one creature hit by one of those Forms during the current turn. Push moves 10 feet directly away from you along a legal route. Reaction denial on one hit target lasts until the start of its next turn.
- Temporary Hit Points equal to twice Proficiency Bonus replace rather than stack unless another rule says otherwise.
- The 15-foot movement follows a legal route and does not provoke Opportunity Attacks.
- Repeated hits with the same Form do not increase the distinct-Form count. Changing weapons within one Form does not create a new Form.

#### CL14 - Circle of Uncounted Arms

**Reaction**  
**Trigger:** A hostile creature within reach makes an attack roll, attempts Grapple or Shove, willingly moves at least 5 feet, takes Dash or Disengage, activates a feature that makes an attack roll, or activates a feature forcing a Strength, Dexterity, or Constitution save.  
**Cost:** 2 Battle Hands  
**Limit:** Once per round

Choose one:

- **Intercepting Hand:** Make one unarmed or melee weapon attack. On a hit, subtract Proficiency Bonus from the triggering attack roll or Cultivation Check.
- **Seizing Hand:** Attempt to Grapple. On success, triggering movement becomes 0.
- **Deflecting Hand:** Gain +3 AC against the triggering attack.
- **Silencing Hand:** On a successful unarmed strike, the creature cannot take Reactions until its next turn.

This does not interrupt an already activated feature unless the printed result causes the attack to miss, movement to become 0, or its required target to become illegal.

##### Normalized Procedure — Circle of Uncounted Arms

- Declare after a listed hostile creature commits to the triggering attack, Grapple, Shove, willing movement, Dash, Disengage, or feature activation but before the triggering attack roll, Cultivation Check, movement, or forced save resolves. Spend the Reaction and 2 Battle Hands.
- The feature is once per round. It does not grant an additional Reaction and can be used only while the triggering creature is within your current melee reach.
- **Intercepting Hand:** Make one unarmed or melee-weapon attack first. On a hit, subtract Proficiency Bonus from the triggering attack roll or Cultivation Check, if that activation has one. This does not alter a saving throw DC. If the trigger has neither roll, the hit deals damage but provides no subtraction.
- **Seizing Hand:** Attempt one Grapple using the ordinary procedure. On success, any triggering willing movement, Dash movement, Disengage movement, or Shove movement by that creature becomes 0 for that activation. A Grapple does not automatically cancel a committed attack or save-based feature.
- **Deflecting Hand:** Gain +3 AC only against the triggering attack roll. This option is legal only for an attack-roll trigger and expires immediately after that attack resolves.
- **Silencing Hand:** Make one unarmed strike. On a hit, the creature cannot take Reactions until the start of its next turn. This does not cancel the triggering non-Reaction activation by itself.
- Granted attacks follow the Granted Attack rule and cannot grant another attack. If your result makes the required target, range, movement, or attack outcome illegal, resolve the source accordingly; otherwise the already activated feature continues.
- A creature that triggers several listed clauses with one activation produces one trigger, not several Circle uses.

#### CL18 - Thousand-Hand Incarnation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Battle Hands become `2 x Proficiency Bonus` and refresh at the start of each turn.
- Once per turn, Eight-Limb Battle Pattern costs 1 Hand.
- Circle of Uncounted Arms may be used twice per round, but not twice during the same creature's turn.
- Gain one additional Reaction each round usable only for Circle of Uncounted Arms.
- Melee reach increases by 5 feet.
- Once per turn after hitting the same creature at least three times, deal an additional `5d8` Force damage.

##### Mandala Completion

Once per turn after spending at least 4 Battle Hands, choose one:

- Move up to your Speed without provoking.
- Gain +3 AC until your next turn.
- Make one additional unarmed strike.
- Apply two different Eight-Limb Completion Effects.

The additional strike follows the Granted Attack rule and cannot trigger Mandala Completion.

##### Normalized Procedure — Thousand-Hand Incarnation

- Activate as a Bonus Action, spend 7 Stamina, and record the 1-minute once-per-scene state. Current and maximum Battle Hands immediately become `2 × Proficiency Bonus`; thereafter they refresh to that amount at the start of each turn.
- Eight-Limb Battle Pattern costs 1 Battle Hand during the state. Its once-per-turn limit and different-Form requirement remain unchanged.
- Circle of Uncounted Arms can be used twice per round, never twice during the same creature's turn. At the start of your turn gain one additional Reaction that expires at the start of your next turn and can be spent only on Circle of Uncounted Arms. This Reaction does not stack with another copy of itself.
- Persistent melee reach increases by 5 feet for the duration and enlarges threatened space. A creature does not trigger movement merely because the reach expands around it.
- Once per turn after the third hit against the same creature during the current turn, add `5d8` Force to that third or a later hit. Count all your legal hits, regardless of Form; the damage occurs once and cannot critically multiply separately.
- Track Battle Hands spent during the current turn. Once per turn immediately after the total reaches at least 4, use Mandala Completion. Spending 4 in one operation is not required, and later spending does not grant another Completion that turn.
- **Move:** Move up to current Speed without provoking along a legal route.
- **Guard:** Gain +3 AC until the start of your next turn. It refreshes and does not stack with itself.
- **Strike:** Make one unarmed strike following the Granted Attack rule. It cannot trigger Mandala Completion, but it can count for the same-creature hit total or distinct-Form Completion if those uses remain available.
- **Double Completion:** Apply two different Eight-Limb Completion Effects. Target-based effects must choose creatures you hit during the current turn. The effects do not require the ordinary three-Form threshold because Mandala Completion expressly grants them.
- Ending or suppressing the state returns maximum Hands to Proficiency Bonus and removes current Hands above that maximum. It does not refund Hands, Stamina, Reactions, or operations already spent.

---

## Additional Rare Inheritances

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a chain projection, Furnace effect, draw-line release, integrated weapon effect, thunder discharge, aerial route, Body Asset, Anchor, Field, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent Tether, Furnace state, posture, Tempering Form, Thunder Charge effect, Coil state, Battle Hand effect, Anchor, Field, or other created effect uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, state, Tether, Furnace, posture, Charge, Coil, Hand, Anchor, or other effect already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore spent scene resources, or reverse damage already resolved.
- **One activation.** Every attack, movement, save, damage packet, rider, repeated operation, object interaction, barrier result, and state change expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces and routes.** Movement, forced movement, rotation, draw-lines, aerial descent, passing movement, and repositioning must follow the printed route and end in a space the creature can legally occupy. If no legal destination exists, use the applicable failed movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, destroyed organ, broken spine, damaged meridian, permanent transformation, soul damage, Foundation damage, or harvestable bodily Asset. Those results require an explicit Source Rule and the governing shared procedure.
- **No silent extra actions.** An integrated weapon, Furnace, Tempering Form, Charge, Coil, Battle Hand, additional reach, afterimage-like force, or scene state grants only the attacks, movement, actions, Reactions, and resource operations printed by the feature.

### Integrated Procedure Closure — Hundred-Hand Battle Mandala

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 36. Phoenix Rebirth Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*The flame is not what kills me. The flame is what remains after death fails.*

Phoenix Rebirth cultivators refine injury, hostile force, and near-death experiences into Rebirth Embers.

**Access Category:** Rare Inheritance  
**Primary Identity:** Regeneration, condition shedding, fire adaptation, combat rebirth  
**Common Sphere Synergies:** Ash, Blood, Fire, Life, Radiance, Yang


#### Rebirth Embers

- Maximum equals Proficiency Bonus.
- Begin each scene with 0 and lose all at scene end.
- Gain no more than 1 per round.
- Gain 1 after qualifying hostile damage equal to at least Proficiency Bonus, or after failing a save and becoming Blinded, Deafened, Frightened, Poisoned, Restrained, or Stunned.

##### Normalized Procedure — Rebirth Ember Record

- Record current Embers, maximum Embers, whether the once-per-round gain has been used, the qualifying event, and scene expiration.
- Qualifying hostile damage is the final damage applied to your Hit Points from one hostile packet after Resistance, Vulnerability, Stamina Guard, and other reductions. It must equal or exceed Proficiency Bonus. Damage entirely prevented does not qualify.
- Failing one save and receiving several listed conditions from that save grants only 1 Ember. The Ember is gained after the effect finishes resolving and the condition is actually applied.
- Damage and failed-save triggers share the same once-per-round gain limit. A later feature that says it obeys that limit uses the same flag.
- Embers cannot be generated by self-damage, willing allies, controlled creatures, the unavoidable cost of one of your own features, or a hazard maintained solely to farm Embers. Furnace Without Fuel expressly permits a genuine active Fire hazard.
- An Ember gained during another creature's turn is immediately available after the triggering event resolves.

#### CL3 - Cinder Blood

Gain Resistance to Fire damage.

At the start of your turn, spend 1 Rebirth Ember to regain `1d8 + Constitution modifier` Hit Points, increasing to `2d8` at CL11 and `3d8` at CL17. This requires no action and functions once per turn, but not while at 0 Hit Points.

##### Normalized Procedure — Cinder Blood

- Fire Resistance follows normal damage ordering.
- At the start of your turn, after resolving mandatory start-of-turn damage and before taking an Action, you may spend 1 Ember. This is not an Action, Bonus Action, Reaction, technique activation, or Stamina expenditure.
- Roll the printed healing once. Add Constitution modifier once, to a minimum of 0 Hit Points regained. The die scaling replaces the earlier die rather than adding to it.
- Cinder Blood can function once during each of your turns. It cannot be declared while you are at 0 Hit Points and cannot retroactively interrupt damage.
- Healing from Cinder Blood is self-generated Body Refining healing for Flesh Rejects Gentleness and similar procedures.

#### CL6 - Ash-Shedding Reversal

**Reaction**  
**Trigger:** You fail a Strength, Dexterity, or Constitution saving throw.  
**Cost:** 2 Rebirth Embers

Reroll the save and use the new result.

On a success, resolve the successful-save result, do not apply conditions imposed only on failure, and move 5 feet without provoking after the effect resolves.

Cannot reroll death saves, breakthrough checks, training checks, Hidden Injury repair checks, or a roll already rerolled.

##### Normalized Procedure — Ash-Shedding Reversal

- Declare immediately after learning that the Strength, Dexterity, or Constitution save failed, before applying failure-only damage, conditions, movement, or other consequences.
- Spend 2 Embers and reroll the same save against the same DC. The new roll replaces the old roll even if worse.
- On a new success, resolve the feature's printed successful-save result. A condition or rider that applies only on failure is not applied. Damage or another effect that also occurs on success still occurs.
- After the triggering effect finishes resolving, move up to 5 feet without provoking along a legal route. This movement occurs even if the successful-save result still dealt damage, but not if you became Incapacitated or unable to move before it occurs.
- One roll can be rerolled only once. This feature cannot chain with itself or another reroll after a reroll has already replaced that roll.
- The exclusions in the source are absolute and cannot be bypassed through an Insight, item, or Subpath interaction unless that Source Rule explicitly names Ash-Shedding Reversal.

#### CL10 - Flame-Wing Rush

Whenever you spend a Rebirth Ember through Cinder Blood, move up to half your Speed without provoking.

Until the end of the turn, the first unarmed strike you hit with deals an additional `2d8` Fire or Radiant damage.

Moving through open flame or burning terrain during this movement does not damage you or count as difficult terrain.

##### Normalized Procedure — Flame-Wing Rush

- After Cinder Blood resolves and restores at least 1 Hit Point, move up to half your current Speed without provoking. This movement is physical movement, not flight or teleportation, and follows legal-space and terrain rules except as printed below.
- Open flame and burning terrain crossed during this granted movement deal no damage to you and do not count as difficult terrain. An unrelated hazard, solid barrier, creature space, or non-Fire terrain remains relevant.
- If you end this movement inside an ongoing Fire hazard, Furnace Without Fuel or Fire Resistance/Immunity applies normally to later instances; Flame-Wing Rush does not create continuing immunity.
- Record one Flame-Wing charge until the end of the current turn. The first unarmed strike you hit with consumes it and adds `2d8` Fire or Radiant damage, chosen on the hit. A second Cinder Blood use is impossible during the same turn and cannot create another charge.
- The extra damage is part of the hit's damage event and does not separately trigger hit riders or critical multiplication.

#### CL14 - Furnace Without Fuel

Gain Immunity to Fire damage.

When a hostile creature, active supernatural effect, or active environmental hazard would deal Fire damage equal to at least Proficiency Bonus before Immunity, gain 1 Rebirth Ember after the damage resolves, obeying the once-per-round limit.

Ash-Shedding Reversal may also respond to Paralyzed, Petrified, or Stunned. Petrified costs 3 Embers.

##### Normalized Procedure — Furnace Without Fuel

- Fire Immunity replaces Fire Resistance.
- For Ember generation, calculate the Fire portion the hostile source or genuine active environmental hazard would have applied before your Fire Immunity, but after any other reductions that would still apply. If that amount equals or exceeds Proficiency Bonus, gain 1 Ember after the instance resolves.
- The damage need not reduce Hit Points because Immunity prevents it. It must nevertheless be a real damaging instance with a legal source; standing in a harmless decorative flame does not qualify.
- This generation obeys the shared once-per-round Ember limit. Several Fire packets in the same area or activation cannot grant additional Embers that round.
- Ash-Shedding Reversal can respond to Paralyzed, Petrified, or Stunned even if the failed save uses an ability other than Strength, Dexterity, or Constitution only when the effect itself imposed one of those named conditions and its Source Rule permits a save reroll. Paralyzed and Stunned cost 2 Embers; Petrified costs 3.
- A successful reroll against Petrified prevents only failure-only Petrification consequences. It does not reconstruct anatomy or reverse an already completed permanent Petrification.

#### CL18 - Rebirth from Cinders

**Reaction**  
**Trigger:** You would be reduced to 0 Hit Points.  
**Cost:** 6 Stamina and at least 3 Rebirth Embers  
**Limit:** Once per scene

Consume all Embers. Instead of reaching 0:

- Regain half your maximum Hit Points.
- Stand without movement.
- End Blinded, Deafened, Frightened, Paralyzed, Poisoned, Restrained, and Stunned.
- Each chosen hostile creature within 20 feet makes a Dexterity save, taking `8d8` Fire or Radiant damage and being pushed 10 feet on a failure, or half damage and no push on a success.
- Move up to your Speed without provoking.

Cannot activate against instant death, total bodily destruction, an effect explicitly preventing recovery, or a reduction that another zero-Hit-Point replacement already resolves.

##### Normalized Procedure — Rebirth from Cinders

- Declare after all damage modifiers and reductions are determined, at the moment the event would reduce you to 0 Hit Points but before entering the 0-Hit-Point state, making a death save, or applying a rider that requires you to reach 0.
- You must have 6 Stamina and at least 3 Embers. Spend the Stamina, then consume every Ember. The cost is paid even if a later collision or authority rule prevents some secondary result.
- This use replaces reaching 0 Hit Points. Set your Hit Points to half maximum, rounded down, with a minimum of 1. It does not count as healing from 0, resurrection, or reconstruction.
- Resolve the printed results in order: regain Hit Points; stand without spending movement if a legal standing posture is possible; end the listed conditions; choose Fire or Radiant for the entire burst; resolve chosen hostile creatures within 20 feet; then move up to your Speed without provoking.
- A chosen creature makes one Dexterity save. On failure it takes `8d8` and is pushed 10 feet directly away from you; on success it takes half and is not pushed. The burst originates from you and requires line of effect. A creature can be chosen once.
- The final movement is physical movement and must follow a legal route. It does not grant flight or passage through creatures or barriers.
- Only one 0-Hit-Point replacement can resolve against an event. Instant death, total bodily destruction, Erasure, a legal effect that explicitly prevents recovery, or an event already replaced by another feature bars this use.
- Realm Suppression after activation does not reverse the regained Hit Points, but can make the burst or movement dormant if suppression occurs before that component resolves.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Phoenix Rebirth Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 37. Heaven-Answering Adaptive Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*Strike me once and I suffer. Strike me twice and you teach me.*

The Heaven-Answering Body changes in response to hostile techniques while the battle is still occurring.

**Access Category:** Rare Inheritance  
**Primary Identity:** In-combat adaptation, repeated-effect resistance, counterattacks, evolving defenses  
**Common Sphere Synergies:** Flesh, Guardian, Life, Predator, Transformation, Yang


#### Damage Adaptations

Valid types are Acid, Bludgeoning, Cold, Fire, Force, Lightning, Necrotic, Piercing, Poison, Psychic, Radiant, Slashing, and Thunder.

Void, untyped damage, maximum-Hit-Point loss, and effects stating they cannot be adapted to do not qualify.

##### Normalized Procedure — Adaptation Records

- A Damage Adaptation record includes damage type, source creature or effect, Source CL, acquisition round, whether its first-instance reduction was used this round, and scene expiration.
- An Affliction Adaptation record includes condition, imposing source, original save ability and DC, Source CL, acquisition round, and scene expiration.
- You cannot maintain duplicate Adaptations of the same damage type or condition. When exceeding a limit, choose which existing record is replaced immediately.
- “About to damage you” reveals only that the pending damage packet contains an adapted type. It does not reveal exact damage, hidden riders, attack result, other damage types, or the source's complete technique.
- Damage that is Void, untyped, maximum-Hit-Point loss, willing cost, unavoidable self-damage, or expressly unadaptable never creates or benefits from an Adaptation.

#### CL3 - Flesh Remembers Pain

Once per round after qualifying hostile damage, choose one valid type in the packet. Gain a Damage Adaptation until scene end.

At CL3, maintain one; a new one replaces it.

While adapted:

- Reduce the first instance of that damage each round by Proficiency Bonus.
- You know when an effect about to damage you includes that type.

**Reaction**  
**Trigger:** You take adapted damage.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Gain Resistance to that type against the triggering packet.

##### Normalized Procedure — Flesh Remembers Pain

- After one qualifying hostile damage event resolves and applies at least 1 damage of a valid type to your Hit Points, choose one valid type present and gain its Adaptation. This acquisition can occur once per round.
- At CL3, if another Damage Adaptation is already maintained, choose whether the new record replaces it. Declining the new record is legal.
- The first instance reduction applies to the first packet each round that would apply at least 1 damage of that type after percentage modifiers. Reduce that type's portion by Proficiency Bonus at the shared flat-reduction step, to a minimum of 0. It is then spent for the round even if the portion becomes 0.
- The Reaction is declared when an adapted damage packet is about to be applied, after the packet and type are known but before Resistance and Hit Point loss are finalized. Spend 1 Stamina and gain Resistance to that type for the triggering packet only.
- The Reaction and the Adaptation's flat reduction can apply to the same packet: apply Resistance first under normal damage ordering, then the flat reduction. Immunity or a canceled packet does not require or consume the Reaction.
- The once-per-round acquisition limit, first-instance reduction, and Reaction limit are separate records.

#### CL6 - Meridians Remember Affliction

Once per round after failing a save and becoming Blinded, Charmed, Frightened, Paralyzed, Poisoned, Restrained, or Stunned, record it as your Affliction Adaptation until scene end. Maintain one.

While affected by the adapted condition:

- Add Proficiency Bonus to saves made to end it.
- If no save is normally allowed during your turn, spend 2 Stamina at the end of your turn to repeat the original save against the original DC, once per round.

##### Normalized Procedure — Meridians Remember Affliction

- Gain an Affliction Adaptation only after failing a hostile save and actually becoming one of the listed conditions. Several eligible conditions from one failed save create one chosen Adaptation.
- Acquisition occurs once per round. At the current one-record limit, a new record can replace the existing one or be declined.
- Add Proficiency Bonus to every save made specifically to end the adapted condition, including repeat saves printed by its source. This bonus does not apply to the initial save that created the Adaptation.
- When the condition normally grants no save during your turn, at the end of your turn you may spend 2 Stamina to repeat the original save using the original ability and DC. This can occur once per round.
- A successful repeat ends only the adapted condition and failure-only ongoing functions directly dependent on it. It does not reverse damage, movement, consumed resources, a completed transformation, or another condition unless its Source Rule links them.
- If the original source no longer exists, use its recorded DC. If no valid original DC was recorded, use the fallback Authority DC for its Realm.

#### CL10 - Return the Lesson

**Trigger:** You hit a creature that dealt your adapted damage type to you or imposed your adapted condition during the current scene.  
**Cost:** 1 Stamina  
**Limit:** Once per turn

Deal an additional `2d8` Force damage and choose one:

- Push 10 feet.
- No Reactions until the start of its next turn.
- Speed 0 until the start of its next turn.
- Disadvantage on its next save against one of your Body Refining features before the end of your next turn.
- Move 10 feet without provoking.

##### Normalized Procedure — Return the Lesson

- Every Adaptation records the creature that dealt the adapted damage or imposed the adapted condition. A creature qualifies if it appears in at least one maintained record from the current scene.
- Declare after hitting a qualifying creature. Spend 1 Stamina, add `2d8` Force to that hit, and choose one printed result. This can occur once per turn.
- Push is directly away from you and follows forced-movement rules. Reaction denial begins after the hit and lasts until the start of the target's next turn. Speed 0 uses the same duration.
- For the save penalty, name one Body Refining feature you possess when applying the rider. The target has Disadvantage on its next save against that named feature before the end of your next turn; the rider expires after that save or at the stated time.
- The movement option moves you up to 10 feet without provoking after the hit resolves. It is physical movement along a legal route.
- Environmental hazards, unattended objects, and effects without a source creature can create Adaptations but cannot be targets of Return the Lesson unless they are represented by a legal creature.

#### CL14 - Ten Thousand Answers

Maintain three Damage Adaptations and two Affliction Adaptations.

Gain automatic Resistance to adapted Acid, Bludgeoning, Cold, Fire, Lightning, Necrotic, Piercing, Poison, Radiant, Slashing, and Thunder damage.

Force and Psychic Adaptations instead reduce the first instance each round by twice Proficiency Bonus. Flesh Remembers Pain may still grant Resistance to Force or Psychic against one packet.

##### Normalized Procedure — Ten Thousand Answers

- Increase maintained capacities to three different Damage Adaptations and two different Affliction Adaptations. When a new record exceeds capacity, choose one record of the same category to replace or decline the new record.
- For Acid, Bludgeoning, Cold, Fire, Lightning, Necrotic, Piercing, Poison, Radiant, Slashing, and Thunder, the maintained Adaptation grants Resistance continuously until scene end.
- For Force and Psychic, replace the CL3 first-instance reduction with twice Proficiency Bonus. Do not add both the Proficiency Bonus and twice-Proficiency-Bonus reductions.
- Flesh Remembers Pain's Reaction remains legal against Force or Psychic and can grant packet-only Resistance before the twice-Proficiency-Bonus reduction. It is redundant for types already receiving automatic Resistance but can still be declared if another rule would temporarily remove that Resistance.
- Several maintained Adaptations do not combine against one type or create double Resistance.

#### CL18 - Perfect Counter-Evolution

**Reaction**  
**Trigger:** You take a valid unadapted damage type or fail a save imposing an eligible condition.  
**Cost:** 2 Stamina  
**Limit:** Once per round

- **Damage Response:** Gain the Adaptation before damage is finalized and apply its benefits to the triggering packet.
- **Affliction Response:** Gain the Affliction Adaptation and reroll the failed save, using the new result.

Return the Lesson deals `4d8` Force instead of `2d8`.

You still cannot adapt to Void, untyped damage, maximum-Hit-Point loss, aging, Realm Suppression, CL reduction, permanent identity rewriting, or an effect explicitly barring adaptation.

##### Normalized Procedure — Perfect Counter-Evolution

- Declare the Damage Response after an unadapted valid damage type in a hostile packet is identified but before damage is finalized. Spend 2 Stamina and choose one valid type in that packet.
- Create the Adaptation immediately, replacing an existing record if capacity requires. Apply its CL14 benefit to the triggering packet: automatic Resistance for listed ordinary types, or twice-Proficiency-Bonus reduction for Force or Psychic.
- Perfect Counter-Evolution itself does not also activate the 1-Stamina Flesh Remembers Pain Reaction; one Reaction cannot pay both features. Force and Psychic therefore receive their printed flat reduction, not packet Resistance, from this response.
- Declare the Affliction Response after failing a save that would impose an eligible condition but before applying that condition. Spend 2 Stamina, create the Adaptation, and reroll the same save against the same DC. Use the new result.
- On success, do not apply conditions or riders imposed only on failure. On failure, resolve the failure and retain the new Affliction Adaptation for later ending saves.
- Return the Lesson's damage becomes `4d8`; this replaces `2d8`.
- The printed prohibited categories remain absolute. A broad “adapt to anything” interpretation cannot override them or a higher-authority Source Rule that expressly bars adaptation.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Heaven-Answering Adaptive Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 38. White Elephant Sovereign Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*The earth does not move me. It remembers that I arrived.*

White Elephant cultivators refine mass, balance, memory, breath, and protective instinct.

**Access Category:** Rare Inheritance  
**Primary Identity:** Immense mass, charging force, ally protection, remembered enemies  
**Common Sphere Synergies:** Earth, Guardian, Gravity, Warleader, Wrestling


#### CL3 - Sovereign Frame

Count as one size larger for carrying, dragging, lifting, pushing, Grappling, Shoving, and determining whether another creature can move you.

Gain Advantage on saves against being pushed, pulled, knocked Prone, or moved against your will.

##### Ivory Charge

Once per turn after moving at least 15 feet directly toward a creature before hitting with an unarmed strike, deal additional Bludgeoning or Force damage equal to Proficiency Bonus.

The target makes a Strength save. On a failure, push 10 feet; on a success, 5 feet.

##### Normalized Procedure — Sovereign Frame and Ivory Charge

- Sovereign Frame grants functional size one category larger only for carrying, dragging, lifting, pushing, Grappling, Shoving, and determining whether another creature can move you. It does not change occupied space, reach, weapon damage, equipment size, or actual creature size.
- Advantage applies to checks and saves made to resist push, pull, Prone, or unwilling movement. It does not automatically prevent teleportation unless that effect is adjudicated as moving you and permits such a save.
- Ivory Charge tracks voluntary movement during the current turn. You must move at least 15 feet along a route that continuously decreases the distance to the target before the qualifying unarmed-strike hit.
- The extra damage applies once per turn and is part of the hit. Choose Bludgeoning or Force on the hit.
- The target makes the Strength save after damage. On failure push 10 feet; on success push 5 feet. The push is directly away from you and follows legal-placement and collision procedures. A target immune to forced movement still takes the extra damage.

#### CL6 - Shelter Beneath the Tusks

**Reaction**  
**Trigger:** A creature within 15 feet is hit by an attack.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Move 10 feet toward it without provoking. If you end adjacent, choose one:

- Become the target instead.
- Grant it Half Cover against the attack.
- Reduce its damage by `2d10 + Constitution modifier`.

If you become the target, compare the attack roll to your AC. If the attack cannot legally target you, choose another option.

##### Normalized Procedure — Shelter Beneath the Tusks

- Declare after the attack hits the protected creature but before damage is rolled or applied. Spend the Reaction and 1 Stamina, then move up to 10 feet toward it without provoking.
- The movement is physical and must end in a legal space adjacent to the protected creature to choose an option. If no such space is reachable, the feature ends after movement and the attack resolves normally.
- **Become the Target:** The attacker must be able to target you from its original position with the same attack. Replace the target and compare the existing attack roll to your AC; do not reroll. Effects requiring the original target's unique anatomy, bond, mark, or identity cannot be redirected.
- **Half Cover:** Apply Half Cover retroactively against the triggering attack. Recompare the same roll to the protected creature's modified AC. If the attack now misses, it deals no hit damage.
- **Reduce Damage:** The attack remains a hit. Reduce its damage by `2d10 + Constitution modifier` at the shared flat-reduction step after its percentage modifiers. This protects one target and one triggering attack packet.
- If the first option is illegal, choose either other option; illegality does not refund the Reaction or Stamina after movement has begun.

#### CL10 - The Body Remembers

When a hostile creature damages you, mark it as **Remembered** until scene end. Maintain a number equal to Proficiency Bonus; exceeding the limit requires forgetting one.

Against a Remembered creature:

- Know its direction within 120 feet.
- It cannot gain Advantage against you merely by being unseen.
- Once per turn on a hit, deal an additional `2d8` Bludgeoning or Force.
- Add Proficiency Bonus to checks and saves against being moved, Grappled, Frightened, or Restrained by it.

##### Normalized Procedure — Remembered Creature Records

- After a hostile creature deals at least 1 damage to your Hit Points, record it as Remembered until scene end. Record identity, Source CL, last known direction, and acquisition event.
- Maintain up to Proficiency Bonus distinct creatures. When exceeding the limit, choose one existing record to forget or decline the new record.
- Direction sense functions within 120 feet and does not reveal exact distance, route, current condition, disguise, plane, or identity of an unknown creature.
- A Remembered creature cannot gain Advantage against you merely because it is unseen. Other sources of Advantage still apply, and you can still have Disadvantage from inability to see it.
- The additional `2d8` applies once per turn on one hit against any Remembered creature. Choose Bludgeoning or Force on the hit.
- Add Proficiency Bonus only to checks and saves against being moved, Grappled, Frightened, or Restrained by that Remembered creature or its active effect.

#### CL14 - Mountain-Walking Sovereign

As a Bonus Action, become Large or return to normal size, lasting until changed.

While Large:

- Unarmed reach +5 feet.
- Count as two additional sizes larger for carrying, lifting, Grappling, Shoving, and resisting forced movement.
- Speed reduced by 5 feet.
- Ignore ordinary difficult terrain.
- Once per turn after moving 10 feet, automatically push one adjacent creature 5 feet unless it is more than two sizes larger.

##### Normalized Procedure — Mountain-Walking Sovereign

- The Bonus Action changes actual size to Large or returns you to normal size. The transformation lasts until changed, Unconscious, complete Body suppression, or another Source Rule replaces your form.
- Use the Shared Transformation procedure for occupied space, equipment, Squeezing, and legal placement. If no Large space exists, the transformation fails without changing size but still spends the Bonus Action.
- While Large, the “two additional sizes larger” permission applies to the listed carrying, lifting, Grappling, Shoving, and forced-movement operations. It replaces Sovereign Frame's one-category functional-size benefit rather than adding a third additional category.
- The 5-foot Speed reduction and ordinary-difficult-terrain immunity apply while Large. Supernatural, hazardous, creature-created, and Source-CL-governed terrain remains unless expressly ordinary.
- Once per turn after you have willingly moved at least 10 feet, choose one adjacent creature. If it is not more than two actual size categories larger, push it 5 feet without a save. This is one movement event and does not deal collision damage unless another rule prints it.

#### CL18 - World-Bearing Elephant King

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

Become Huge if space permits, otherwise Large with all other benefits.

For the duration:

- Resistance to all damage except Psychic and Void.
- Speed +20 feet.
- Unarmed strikes deal `2d8` before modifiers.
- Once per turn on a hit, additional `4d8` Bludgeoning or Force.
- Hostile creatures treat spaces within 10 feet as difficult terrain.
- Allies within 10 feet gain Half Cover against ranged attacks.
- A creature of your CL or lower cannot push, pull, knock you Prone, or move you against your will unless its feature explicitly ignores bodily anchoring.

##### Sovereign Trampling Advance

Once per turn after moving 20 feet in a straight line, move through hostile spaces. Each creature entered makes a Dexterity save.

- **Failed Save:** `4d8` Bludgeoning, Prone, moved to nearest legal space outside your path.
- **Successful Save:** Half damage, moved to nearest legal space, remains standing.

A creature is affected once per turn.

##### Normalized Procedure — World-Bearing Elephant King

- On activation, become Huge if a legal Huge space exists. Otherwise become Large and retain every other benefit. Use the transformation and equipment procedures; the form does not destroy terrain merely because space is tight.
- The duration, 7-Stamina cost, and once-per-scene limit are unchanged. If suppressed below CL18, the transformation becomes dormant and your size returns to the largest legal unsuppressed state.
- Resistance excludes Psychic and Void. The `2d8` unarmed die replaces the normal base die; the once-per-turn `4d8` rider is separate and applies on one hit.
- Hostile difficult terrain applies to every hostile space within 10 feet and does not stack with itself. Ally Half Cover is checked for each ranged attack when the line crosses or is substantially obstructed by your occupied space.
- The movement immunity compares the hostile effect's Source CL to your current effective Body Refining CL. A lower- or equal-CL creature cannot perform the listed movement unless its feature expressly ignores bodily anchoring. Higher-CL effects use their normal procedure.
- **Sovereign Trampling Advance:** Track 20 feet of straight-line voluntary movement during your turn. Once per turn thereafter, you may move through hostile spaces along that continuing route. Each creature whose space you enter saves once.
- Resolve entered creatures nearest to farthest. On failure deal `4d8`, knock Prone, and place it in the nearest legal space outside your path; on success deal half and place it likewise standing. If no legal placement exists, your movement stops before entering that creature's space. This movement does not silently damage terrain or allow passage through solid barriers.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — White Elephant Sovereign Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 39. Thousand-Eyed Calamity Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*One eye watches the hand. One watches the breath. One watches the intention that moves before either.*

Thousand-Eyed cultivators awaken demonic eyes throughout skin, bones, palms, brow, and internal organs.

**Access Category:** Rare Demonic Inheritance  
**Primary Identity:** Supernatural perception, weak-point analysis, attack prediction, anti-concealment  
**Common Sphere Synergies:** Divination, The Hidden Eye, Light, Pressure Points, Predator, Sniper


#### Forbidden Consequence - Too Many Open Eyes

If you fail a save against Blinded while 3 or more Eyes are open, take `2d8` Psychic damage per Eye beyond the second, close all Eyes, and cannot open another until the end of your next turn. This damage cannot be reduced by this Subpath.

##### Normalized Procedure — Ocular Backlash

- Check the number of Eyes open immediately after a save against Blinded fails and before applying the Blinded condition's continuing effects.
- If 3 or more Eyes are open, take `2d8` Psychic damage for each Eye beyond the second, then close every Eye and apply the failed save normally.
- This Psychic damage is one unavoidable Subpath packet. It cannot be reduced, prevented, redirected, converted, or used to generate a Body resource through this Subpath. Other rules can affect it only if they explicitly affect unavoidable self-inflicted cultivation backlash.
- You cannot open an Eye until the end of your next turn. Realm Suppression, condition removal, or ending Blinded early does not shorten that lockout.

#### Open Eyes

Maximum Open Eyes equals Proficiency Bonus. At the start of your turn, choose how many are open without using an action. They remain until closed, Unconscious, or scene end.

| Open Eyes | Benefit |
|---:|---|
| 1 | Cannot be Surprised while conscious |
| 2 | Advantage on Wisdom (Perception) relying on sight |
| 3 | Creatures do not gain Advantage merely by being unseen |
| 4 | Blindsight 20 feet |
| 5 | See invisible creatures and objects within 60 feet |
| 6+ | Truesight 30 feet |

Truesight does not automatically penetrate higher-CL Secret, artifact, or Immortal concealment.

##### Normalized Procedure — Open-Eye State

- Record the current number of open Eyes, maximum, active sense benefits, whether the start-of-turn choice has occurred, and scene expiration.
- At the start of each turn, choose any legal number from 0 to maximum without using an action. If you cannot choose, retain the previous legal number. Eyes close when you become Unconscious or the scene ends.
- Benefits are cumulative by threshold. Opening 5 Eyes includes the benefits of 1–4; opening 6 includes every lower benefit.
- “Cannot be Surprised” functions only while conscious. “Unseen does not grant Advantage” removes that one reason for Advantage but does not reveal the creature or cancel your Disadvantage.
- Blindsight and Truesight use their ordinary sense rules and ranges. They do not automatically pierce a higher-Source-CL Secret, artifact, divine, Immortal, or expressly superior concealment. Resolve an authority contest when such a source provides one.
- Eyes are integrated anatomy, not separate creatures or targetable Assets unless a Source Rule explicitly creates that exception.

#### CL3 - Calamity Appraisal

At the start of your turn, choose one creature within 60 feet as Appraised until the start of your next turn.

Learn its AC, whether Strength, Dexterity, or Constitution is highest and lowest, and whether it is above or below half maximum Hit Points.

Once per turn on a hit against it, deal additional damage equal to Proficiency Bonus.

##### Normalized Procedure — Calamity Appraisal Record

- At the start of your turn after choosing Open Eyes, select one creature you can perceive within 60 feet. It becomes Appraised until the start of your next turn.
- Record identity, Source CL, known AC, highest and lowest among Strength/Dexterity/Constitution, half-Hit-Point band, and expiration.
- If two or more physical abilities tie for highest or lowest, learn every tied ability. You learn only whether current Hit Points are above or below half maximum, not exact Hit Points or maximum.
- Appraisal reads current observable combat structure. A higher-authority disguise, false body, Secret concealment, or anti-divination effect can produce a contest or block the information under its own rules.
- The additional damage equal to Proficiency Bonus applies once per turn on one hit against the currently Appraised target and uses the triggering attack's damage type unless you choose Force. It is part of that hit and cannot critically multiply separately.

#### CL6 - Eye beneath the Skin

**Reaction**  
**Trigger:** A creature you can see makes an attack roll against you.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Add Proficiency Bonus to AC against that attack.

If it misses, the attacker becomes Appraised until the end of your next turn, you move 5 feet without provoking, and it cannot gain Advantage against you merely by becoming unseen before your next turn.

##### Normalized Procedure — Eye beneath the Skin

- Declare after a visible creature makes an attack roll against you but before the roll's success is announced. Spend the Reaction and 1 Stamina, then add Proficiency Bonus to AC against that attack only.
- If the modified attack misses, resolve the printed benefits after the miss: Appraise the attacker until the end of your next turn, move up to 5 feet without provoking, and deny unseen-only Advantage until before your next turn ends.
- The movement is physical and follows legal-space rules. It cannot change whether the already resolved attack hit.
- If the attack still hits, none of the miss benefits occur. The Reaction and Stamina remain spent.
- The temporary Appraisal can coexist with the start-of-turn Appraisal at CL18 only when the feature's maintained-target limit permits it; before CL18, it replaces the prior Appraised target for overlapping duration unless the source explicitly permits more.

#### CL10 - Read the Killing Line

Once per turn when targeting an Appraised creature, spend 1 Stamina and choose one:

- **Unclouded Line:** Ignore Disadvantage, Half Cover, and Three-Quarters Cover on one attack roll.
- **Piercing Appraisal:** On a hit, additional `2d8` damage.
- **Exposed Meridian:** When a Body Refining feature forces its identified lowest physical save, subtract `1d4` from that save.
- **Denied Escape:** On a hit, no Reactions until the start of its next turn.
- **Read Resistance:** The triggering attack ignores one Resistance revealed by the Appraisal; not Immunity.

##### Normalized Procedure — Read the Killing Line

- Use once per turn while targeting an Appraised creature. Spend 1 Stamina and choose exactly one mode at the mode's required timing.
- **Unclouded Line:** Declare before one attack roll. Remove Disadvantage from that roll and ignore Half and Three-Quarters Cover. Total cover, blocked line of effect, and an illegal target remain.
- **Piercing Appraisal:** Declare after a hit. Add `2d8` damage to that hit using one of the hit's damage types or Force.
- **Exposed Meridian:** Declare when one of your Body Refining features forces the physical save identified as the target's lowest. Subtract `1d4` from that save result after the roll. If several abilities tied for lowest, any tied save qualifies.
- **Denied Escape:** Declare after a hit. The target cannot take Reactions until the start of its next turn; this does not cancel a Reaction already resolved.
- **Read Resistance:** Declare on an attack before damage is applied. Ignore one ordinary Resistance you actually learned through Appraisal or another explicit information source. This never ignores Immunity or an unconfirmed guessed Resistance.
- One use cannot combine modes. A miss after choosing an attack-dependent mode spends the Stamina and use unless the mode expressly declared on hit.

#### CL14 - Hundred Eyes Open

While at least 4 Eyes are open:

- Blindsight 40 feet.
- See in every direction and cannot be flanked.
- Automatically notice visible creatures entering your reach.
- Advantage against illusions and gaze effects.
- Know when a visible creature begins casting, invoking, or circulating a technique, though not necessarily its identity.

**Reaction**  
**Trigger:** Your Appraised Target moves, teleports, attacks, or activates a technique within 60 feet.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Choose one:

- Move 15 feet without provoking.
- Make one unarmed strike if within reach.
- Impose Disadvantage on one attack roll it makes.
- Add Proficiency Bonus to one save you make against the triggering feature.

The attack follows the Granted Attack rule.

##### Normalized Procedure — Hundred Eyes Open

- The passive benefits function while at least 4 Eyes remain open. Closing below 4 makes them dormant immediately.
- Seeing in every direction prevents flanking benefits that rely only on facing or an unwatched side. It does not see through total cover or negate concealment beyond your senses.
- Automatically noticing a visible creature entering reach reveals that entry; it does not grant an Opportunity Attack or interrupt unless another rule supplies one.
- You know that a visible creature has begun casting, invoking, or circulating a technique when its activation becomes observable. You do not automatically learn the technique's name, target, cost, hidden mode, or result.
- The Reaction trigger occurs when the Appraised target commits movement, teleportation, an attack, or a technique activation within 60 feet. Choose one response and spend 1 Stamina.
- Movement occurs immediately after the trigger commits and before later effects when legally possible. A granted unarmed strike occurs before the triggering movement finishes or attack resolves if the target is currently within reach; it follows Granted Attack rules and does not automatically cancel the trigger.
- Imposing Disadvantage affects one attack roll from the triggering activation, chosen before that roll. Adding Proficiency Bonus affects one save you make against the triggering feature, chosen before that save is resolved.
- A trigger without an attack roll or save can still be answered by movement or the granted strike.

#### CL18 - Thousand-Eyed Revelation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

All Eyes open.

For the duration:

- Truesight 120 feet and Blindsight 60 feet.
- Cannot be Surprised.
- Attack rolls against you cannot gain Advantage.
- Maintain Appraised Targets equal to Proficiency Bonus.
- Learn exact Strength, Dexterity, and Constitution save bonuses.
- Once per turn on a hit against an Appraised Target, additional `4d8` Psychic or Force.
- Read the Killing Line costs 0 Stamina once per turn.

##### Calamity Gaze

**Action**  
**Area:** 60-foot cone  
**Cost:** 3 Stamina  
**Saving Throw:** Wisdom

- **Failed Save:** `8d8` Psychic, Appraised for the duration, cannot become Invisible to you, and no Reactions until the start of its next turn.
- **Successful Save:** Half damage and Appraised until the start of your next turn.

A creature is affected once per use.

##### Normalized Procedure — Thousand-Eyed Revelation

- Activation opens every Eye to your current maximum and overrides the ordinary start-of-turn choice for the duration. Suppression can lower the effective maximum and closes excess Eyes first.
- Truesight 120 feet and Blindsight 60 feet replace lower ranges. “Attack rolls cannot gain Advantage” removes every Advantage source from attacks against you; Disadvantage still applies normally and can make the roll disadvantaged.
- Maintain Appraised targets up to Proficiency Bonus. Each record uses the normal Appraisal data plus exact Strength, Dexterity, and Constitution save bonuses. When exceeding the limit, choose a record to end.
- The once-per-turn `4d8` Psychic or Force rider applies to one hit against any Appraised target and replaces no other Appraisal rider.
- Read the Killing Line costs 0 Stamina for one use each turn. Additional legal uses, if another rule grants them, pay normal cost.
- **Calamity Gaze:** The cone originates from you and requires line of effect. Each creature is affected once per use. On failure it takes `8d8` Psychic, becomes Appraised for the transformation's remaining duration, cannot become Invisible to you, and loses Reactions until the start of its next turn. On success it takes half and is Appraised only until the start of your next turn.
- “Cannot become Invisible to you” means Invisibility does not make that creature invisible to your senses; it does not dispel Invisibility for other observers. A superior Source CL concealment can contest this authority under its own rule.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Thousand-Eyed Calamity Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 40. Heaven-Devouring Maw Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*Heaven sends lightning. Earth raises mountains. All things become food when the mouth is deep enough.*

Heaven-Devouring disciples cultivate a demonic furnace through the stomach, throat, teeth, meridians, and dantian-adjacent organs.

**Access Category:** Forbidden Method  
**Primary Identity:** Consuming hostile power, storing damage types, breaking defenses, returning stolen energy  
**Common Sphere Synergies:** Blood, Daemonic Cultivation, Devouring, Hunger, Life, Void


#### Forbidden Consequence - Undigested Calamity

When a scene ends, take `1d6` Force damage for each Devoured Essence you still possess, then lose all remaining Essence.

This damage cannot be reduced, prevented, redirected, absorbed, or converted; does not trigger Stamina Guard; and does not count as hostile damage.

You may expel all Essence as an Action before scene end, taking the same damage immediately.

##### Normalized Procedure — Undigested Calamity

- At scene end, count every remaining Devoured Essence before removing any. Take one Force packet equal to `1d6` per Essence, then lose all Essence.
- This damage applies directly to Hit Points and cannot be reduced, prevented, redirected, delayed, shared, absorbed by Temporary Hit Points, or converted into a resource or benefit. It does not trigger Stamina Guard and is not hostile damage.
- As an Action before scene end, you may expel all Essence. Resolve the same damage immediately from the current Essence count, then lose all Essence. Partial voluntary expulsion is not permitted.
- Becoming Unconscious does not automatically expel Essence. Death, complete Body suppression, or total destruction ends the state and resolves any applicable metaphysical consequence only if the governing campaign rule permits effects after death.

#### Devoured Essence

- Maximum equals Proficiency Bonus.
- Begin each scene with 0.
- Each Essence records one valid damage type from the effect that generated it.
- Valid types: Acid, Cold, Fire, Force, Lightning, Necrotic, Poison, Psychic, Radiant, Thunder.
- Gain no more than 1 per round unless stated otherwise.

##### Normalized Procedure — Devoured Essence Record

- Each Essence is a separate record containing one valid damage type, originating source, Source CL, acquisition round, and scene expiration.
- Maximum equals Proficiency Bonus unless Devour Heaven and Earth increases it. When full, a new Essence can replace one existing record or be declined.
- The once-per-round gain limit applies to ordinary generation. A feature that expressly grants additional Essence or bypasses that limit follows its own language but cannot exceed maximum unless stated.
- Essence is abstract stored hostile power, not a free spell, technique, item charge, soul, or transferable object. It can be spent only through features that name Devoured Essence.
- A consumed type remains available for that activation even though the Essence is removed as cost. Several Essence spent together must satisfy any same-type requirement printed by the feature.

#### CL3 - Swallow Hostile Power

**Reaction**  
**Trigger:** Qualifying hostile damage includes a valid stored type.  
**Cost:** 1 Stamina  
**Limit:** Once per round

Choose one type and reduce that portion by `2d8 + Constitution modifier`.

If at least 1 point is reduced, gain 1 Devoured Essence of that type after damage resolves.

Cannot reduce Bludgeoning, Piercing, Slashing, Void, untyped, maximum-Hit-Point loss, willing costs, or damage explicitly immune to consumption.

##### Maw Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Devoured Essence  
**Limit:** Once per turn

Consume it and deal an additional `2d8` of its stored type, increasing to `3d8` at CL11 and `4d8` at CL17.

##### Normalized Procedure — Swallow Hostile Power and Maw Strike

- Declare when a qualifying hostile packet containing at least one valid stored type would apply damage, after percentage modifiers are known but before Hit Points are reduced.
- Choose one valid type in that packet. Spend 1 Stamina and reduce only that type's portion by `2d8 + Constitution modifier` at the shared flat-reduction step, to a minimum of 0.
- If at least 1 point of that portion is actually prevented, gain one Essence of the chosen type after the packet resolves, obeying the normal gain limit and maximum.
- Invalid physical, Void, untyped, maximum-Hit-Point-loss, willing-cost, and explicitly unconsumable portions are unaffected. A mixed packet can still have one valid portion reduced.
- **Maw Strike:** After hitting with an unarmed strike, consume one Essence and add the printed damage of its stored type. The die scaling replaces the prior die. The extra damage is part of the hit and can be used once per turn.

#### CL6 - Regurgitate Calamity

**Action**  
**Range:** 60 feet  
**Area:** One creature or 30-foot-long, 5-foot-wide line  
**Cost:** Up to 3 Devoured Essence of the same type

- **One Creature:** Make a Cultivation Attack. On a hit, `3d8` damage per Essence.
- **Line:** Dexterity save; `2d8` damage per Essence on a failure, half on a success.

Damage uses the stored type.

##### Normalized Procedure — Regurgitate Calamity

- Choose one damage type and spend 1–3 Essence of that type when taking the Action. Essence of different types cannot be combined in one use.
- **One Creature:** The target must be within 60 feet and line of effect. Make one Cultivation Attack. On a hit, deal `3d8` per Essence; on a miss, deal no damage. Spent Essence is not refunded.
- **Line:** Create a 30-foot-long, 5-foot-wide line from your mouth or another recorded maw origin. Each creature in it makes one Dexterity save, taking `2d8` per Essence on failure and half on success.
- Resolve solid obstructions under the line procedure. A surviving total-cover barrier stops the line beyond it unless the feature's damage destroys it first.
- The use is a Body Refining projected technique, not a weapon attack. It does not require ammunition or apply attack-only mastery and critical-hit riders.

#### CL10 - Swallow the Technique

**Reaction**  
**Trigger:** You are affected by a ranged attack, line, cone, burst, other area effect, or hostile technique that forces a save and deals a valid stored type.  
**Cost:** 3 Stamina  
**Limit:** Once per round

Resolve the attack or save normally, then reduce all valid stored damage types in the effect by `4d10 + Constitution modifier`.

If every valid type is reduced to 0:

- You suffer no non-damage rider that applies only when the effect deals damage.
- Gain 2 Devoured Essence after resolution, divided among valid types present.

Conditions applying regardless of damage still resolve.

Cannot consume a melee attack, effect dealing only physical weapon damage, a persistent zone as a whole, permanent artifact effect, or technique explicitly barring consumption. It may reduce one triggering instance from a persistent zone.

##### Normalized Procedure — Swallow the Technique

- Declare after the ranged attack, save result, or affected area is known but before valid damage is applied to you. Spend 3 Stamina and the Reaction.
- Resolve the triggering attack or save normally, including whether you are a legal target. Then roll `4d10 + Constitution modifier` once and reduce the combined valid stored-type damage portions of that one instance by the result, allocated by you among those valid portions.
- Invalid physical-only, Void, untyped, maximum-Hit-Point-loss, and expressly barred portions remain. This feature does not erase the entire activation, other targets, a persistent zone, or non-damage consequences that apply regardless of damage.
- If every valid damage portion in your instance becomes 0, ignore only riders that explicitly require the effect to deal damage to you. Conditions or movement that apply on a hit, failed save, presence in the area, or regardless of damage still resolve.
- Gain 2 Essence after resolution, assigning each to a valid type present. This direct gain can exceed the ordinary once-per-round gain limit but not maximum.
- Against a persistent zone, one use affects one triggering damage instance only. The zone remains and can trigger again at its normal timing.

#### CL14 - Feast upon Protection

**Trigger:** You hit with an unarmed strike.  
**Cost:** 3 Devoured Essence  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Consume the Essence.

On a failed save, suppress one qualifying protection until the start of your next turn: Temporary Hit Points, temporary AC bonus, one Resistance, temporary damage reduction, or temporary ward/barrier attached to the creature. Also deal `4d8` damage of one consumed type.

On a successful save, do not suppress the protection but deal `2d8` additional damage of one consumed type.

Cannot suppress permanent bodily traits, Foundation passives, permanent artifact properties, Realm Suppression, Immunity, or a protection whose Source CL exceeds yours by 3 or more.

##### Normalized Procedure — Feast upon Protection

- Declare after an unarmed-strike hit. Spend exactly 3 Essence and choose one of their stored types for damage. The three Essence need not share a type unless another effect requires it.
- The target makes one Constitution save. On failure, choose one qualifying temporary protection currently affecting it and suppress that protection until the start of your next turn, then deal `4d8` of the chosen type.
- Qualifying protections are: Temporary Hit Points; a temporary numerical AC bonus; one temporary ordinary Resistance; one temporary flat or rolled damage reduction; or one temporary ward/barrier attached to the creature.
- Suppression makes the chosen benefit inactive without ending its duration or destroying its source. If its duration expires while suppressed, it ends normally. A protection cannot be selected if its Source CL exceeds yours by 3 or more.
- On success, suppress nothing and deal `2d8` of the chosen type.
- Permanent bodily traits, Foundation passives, Methods, Path features, Immunity, Realm Suppression, permanent artifact properties, and unlisted protections are illegal selections.

#### CL18 - Devour Heaven and Earth

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 8 Stamina  
**Limit:** Once per scene

For the duration:

- Maximum Devoured Essence +3.
- Swallow Hostile Power reduces `4d10 + Constitution modifier`.
- Bludgeoning, Piercing, and Slashing from supernatural attacks become valid stored types.
- Once per round when a hostile creature within 60 feet spends Cultivation Points, gain 1 Essence after its feature resolves. Choose a damage type dealt by it, or Force if none.
- Maw Strike deals `6d8` additional damage.
- Feast upon Protection can treat Immunity as Resistance until the start of your next turn on a failed save.

##### World-Eating Bite

**Trigger:** You hit with an unarmed strike.  
**Cost:** 5 Devoured Essence  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Deal an additional `10d8` of one consumed type.

- **Failed Save:** End one temporary ward, transformation, aura, stance, or damage-reduction effect. If none, remove Temporary Hit Points and prevent gaining them until the start of your next turn.
- **Successful Save:** No effect ends, but Temporary Hit Points cannot be gained until the start of your next turn.

Permanent Foundation stages, Methods, Path features, and item properties do not end.

##### Normalized Procedure — Devour Heaven and Earth

- For the duration, increase maximum Essence by 3. When the transformation ends, any excess records remain until scene end or expenditure; the maximum returning to normal does not itself choose records to discard, but no new Essence can be gained while above maximum.
- Swallow Hostile Power's reduction becomes `4d10 + Constitution modifier`; this replaces its earlier roll. Supernatural Bludgeoning, Piercing, and Slashing become valid for every Subpath feature during the duration.
- Once per round after a hostile creature within 60 feet spends Cultivation Points and its activation resolves, gain 1 Essence. Choose a damage type actually dealt by that activation, or Force if it dealt none. This is direct generation and can exceed the ordinary gain limit but not maximum.
- Maw Strike's additional damage becomes `6d8`; this replaces its earlier scaling.
- On a failed Feast upon Protection save, Immunity can be treated as Resistance until the start of your next turn. This does not remove the Immunity, permit another feature to suppress it as a Resistance, or affect an Immunity whose Source Rule expressly cannot be downgraded by your Source CL.
- **World-Eating Bite:** After an unarmed-strike hit, consume 5 Essence and choose one consumed type. Deal `10d8` of that type, then the target makes one Constitution save.
- On failure, end one temporary ward, transformation, aura, stance, or damage-reduction effect with legal Source CL. “End” terminates that chosen temporary effect, not its underlying Path, Method, Foundation, item, or permanent source. If no legal effect exists, remove all Temporary Hit Points and bar new Temporary Hit Points until the start of your next turn.
- On success, end nothing but bar Temporary Hit Points for the same duration. One use cannot end several nested effects. The printed permanent exclusions are absolute.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Heaven-Devouring Maw Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 41. Black-Thorn Demon Body

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*Every wound is a place where the body learns to grow a weapon.*

Black-Thorn disciples cultivate jagged bone, keratin, demon-wood, and blood-fed spines beneath the skin.

**Access Category:** Forbidden Method  
**Primary Identity:** Reactive spines, bleeding wounds, impalement, close-range battlefield control  
**Common Sphere Synergies:** Blood, Bones, Daemonic Cultivation, Flesh, Predator, Wood


#### Forbidden Consequence - Flesh Rejects Gentleness

While you have 3 or more Demon Spines, healing received from another creature is reduced by Proficiency Bonus per healing instance after the roll, to a minimum of 1. Your own Body Refining features heal normally.

##### Normalized Procedure — Flesh Rejects Gentleness

- Check current Demon Spines when another creature's healing instance would restore your Hit Points. At 3 or more Spines, reduce the final healing after the roll by Proficiency Bonus, to a minimum of 1 Hit Point restored.
- Apply the reduction once per healing instance, not once per die or target. A healing effect that restores no Hit Points is not raised to 1.
- Healing from your own Body Refining features is exempt. Temporary Hit Points, Hit Dice, maximum-Hit-Point increases, regeneration from another source, and reconstruction are not “healing received” unless their rules say they restore Hit Points.
- During Calamity Briar Incarnation, the threshold becomes 6 or more Spines as printed.

#### Demon Spines

- Maximum equals Proficiency Bonus.
- Begin each scene with 0 and lose them at scene end.
- Gain no more than 1 per round.
- Gain 1 after hostile Piercing or Slashing damage, or qualifying hostile damage from a creature within reach.

##### Normalized Procedure — Demon Spine Record

- Record current Spines, maximum, normal once-per-round gain, direct gains, scene expiration, and current healing-reduction threshold.
- Gain 1 after hostile Piercing or Slashing damage applies at least 1 damage to your Hit Points, or after qualifying hostile damage from a creature currently within your unarmed reach. One event grants at most 1 Spine.
- These triggers share the once-per-round normal gain limit. Start-of-turn generation and “gain to maximum” expressly provided by Calamity Briar Incarnation are direct gains and follow that feature.
- Spines are embodied natural structures, not free projectiles, ammunition, detached Assets, or additional limbs. Spending a Spine represents breaking, shedding, or discharging one cultivated structure without creating harvestable material.

#### CL3 - Thorn-Flesh Armory

Unarmed strikes may deal Piercing or Slashing.

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Demon Spine  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Deal an additional `2d6` Piercing or Slashing.

On a failed save, the target becomes **Bleeding** until the start of your next turn. The first time it willingly moves 10 feet or makes an attack, it takes damage equal to your Proficiency Bonus and Bleeding ends.

##### Normalized Procedure — Thorn-Flesh Armory and Bleeding

- Your unarmed strikes can choose Bludgeoning, Piercing, or Slashing for each attack. This changes damage type but grants no separate weapon, reach, or attack.
- After a hit, spend 1 Spine, choose Piercing or Slashing, and add `2d6` to the hit once per turn. The target then makes one Constitution save.
- On failure, create one Bleeding record until the start of your next turn. A new Bleeding from this Subpath refreshes the duration and does not stack damage.
- The first time the target willingly moves a cumulative 10 feet or makes an attack while Bleeding, it takes damage equal to your Proficiency Bonus using the selected Piercing or Slashing type and Bleeding ends after the triggering action or movement commits.
- Forced movement, teleportation, involuntary falling, standing, and movement below 10 cumulative feet do not trigger it. An attack still triggers when it misses.
- Bleeding is a temporary Subpath condition, not an Injury, ordinary wound rule, or automatic blood loss. Immunity to ordinary bleeding applies only if its Source Rule covers supernatural Body conditions.

#### CL6 - Spines Answer Violence

**Reaction**  
**Trigger:** A creature within reach hits you with a melee attack, Grapples you, or begins its turn Grappling you.  
**Cost:** 1 Demon Spine  
**Limit:** Once per round  
**Saving Throw:** Dexterity

- **Failed Save:** `3d8` Piercing, Bleeding, and pushed 5 feet if not Grappling you.
- **Successful Save:** Half damage and no Bleeding.

If Grappling you, resolve damage before any check to maintain or move the Grapple.

##### Normalized Procedure — Spines Answer Violence

- Declare after one listed trigger occurs. A melee hit triggers before its damage is applied; becoming Grappled triggers after the Grapple succeeds; beginning a turn Grappling you triggers at that turn's start before movement.
- Spend the Reaction and 1 Spine. The triggering creature makes one Dexterity save.
- On failure, deal `3d8` Piercing, apply Bleeding, and push 5 feet if it is not currently Grappling you. On success, deal half and apply no Bleeding.
- When the target is Grappling you, resolve damage before it attempts to move you or before another maintenance check. Damage alone does not automatically break the Grapple; use the normal Grapple and anatomy procedures.
- A single event triggers one use. Beginning the turn Grappling you does not also count as a new Grapple event.

#### CL10 - Impaling Garden

**Action**  
**Area:** 15-foot-radius sphere centered on you  
**Cost:** 3 Stamina and 2 Demon Spines  
**Duration:** Until the start of your next turn  
**Saving Throw:** Dexterity

- **Failed Save:** `5d8` Piercing, Restrained until the start of your next turn, and Bleeding.
- **Successful Save:** Half damage, Speed reduced by 10 feet until the start of your next turn, not Restrained.

The area is difficult terrain for hostile creatures. A Restrained creature may use its Action for a Strength check against your DC, ending the restraint on a success.

##### Normalized Procedure — Impaling Garden

- The Action creates a temporary projected Body Field in a 15-foot-radius sphere centered on you until the start of your next turn. It moves with you because it remains centered on you.
- Choose hostile creatures in the area or affect every hostile creature according to the campaign's area convention; record the selection consistently. Each target makes one Dexterity save once per activation.
- On failure, deal `5d8` Piercing, apply Bleeding, and Restrict until the start of your next turn. On success, deal half, reduce Speed by 10 feet for the same duration, and do not Restrict.
- A Restrained target can use its Action for one Strength check against your Cultivation Save DC, ending only this restraint on success.
- Hostile creatures treat the area as difficult terrain. The Field does not block line of effect, create cover, damage unattended creatures, or produce permanent thorns unless another rule says so.
- Suppression or loss of the feature makes the Field dormant and ends its restraint and difficult terrain; already dealt damage remains.

#### CL14 - Crown of Black Thorns

Gain Resistance to Piercing and Slashing, Immunity to ordinary bleeding effects, and your Demon Spine damage ignores Resistance to Piercing and Slashing. While you have at least 1 Spine, unarmed reach increases by 5 feet during your turn.

Once per turn, when a hostile creature reaches the first qualifying space while willingly entering your unarmed reach or moving 10 feet within it, spend 1 Demon Spine without using an action. It makes a Dexterity save.

- **Failed Save:** `3d8` Piercing, movement ends in that space, and Bleeding.
- **Successful Save:** Half damage and movement continues.

A creature triggers once per turn.

##### Normalized Procedure — Crown of Black Thorns

- Piercing and Slashing Resistance follows normal ordering. Immunity to ordinary bleeding does not grant Immunity to every blood, Injury, poison, or supernatural curse effect.
- Demon Spine damage ignores ordinary Piercing and Slashing Resistance, not Immunity or a superior Source CL defense expressly immune to penetration.
- The 5-foot reach increase functions during your turn while at least 1 Spine remains. Spending the last Spine removes the reach after the current feature's trigger finishes.
- For the movement trigger, identify the first space a hostile creature reaches while willingly entering your unarmed reach or after it accumulates 10 feet of willing movement within that reach. It can trigger once per turn.
- Spend 1 Spine without an action before the creature leaves that qualifying space. It makes one Dexterity save. On failure deal `3d8`, end its current movement in that space, and apply Bleeding; on success deal half and allow movement to continue.
- Teleportation, forced movement, and being carried do not trigger unless the movement is willingly performed by the target itself.

#### CL18 - Calamity Briar Incarnation

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

Gain Demon Spines to maximum.

For the duration:

- Become Large if smaller.
- Unarmed reach +10 feet.
- Resistance to all damage except Fire, Psychic, and Void.
- Unarmed strikes deal `1d12` before modifiers.
- Once per turn on a hit, additional `4d8` Piercing or Slashing.
- Gain 1 Demon Spine at the start of each turn.
- Maximum Spines +3.
- Healing reduction applies only at 6 or more Spines.

##### Forest of Impalement

**Action**  
**Area:** 30-foot-radius sphere centered on you  
**Cost:** 4 Demon Spines  
**Saving Throw:** Dexterity

- **Failed Save:** `8d8` Piercing, Restrained, Bleeding, and lifted up to 10 feet.
- **Successful Save:** Half damage, pushed 10 feet, not Restrained.

A Restrained creature repeats the Dexterity save at the end of each turn, ending the state and falling safely to the nearest legal space on a success.

The thorn forest remains until the start of your next turn and is difficult terrain for hostile creatures.

##### Normalized Procedure — Calamity Briar Incarnation

- On activation, gain Spines to the transformed maximum after increasing that maximum by 3. Become Large if smaller using transformation and legal-space procedures.
- The printed +10-foot reach is the transformation's reach increase and does not stack with Crown of Black Thorns' +5-foot reach unless the source explicitly says both apply; use the higher +10-foot increase.
- Resistance excludes Fire, Psychic, and Void. The `1d12` unarmed die replaces the normal base die; the once-per-turn `4d8` rider is separate.
- Gain 1 Spine at the start of each turn as a direct gain, even if the ordinary once-per-round gain flag is already used. Healing reduction uses the temporary 6-Spine threshold.
- **Forest of Impalement:** The Action creates a 30-foot-radius projected Body Field centered on you until the start of your next turn. Each affected creature saves once.
- On failure deal `8d8` Piercing, apply Restrained and Bleeding, and lift the target up to 10 feet vertically if a legal space exists. On success deal half, push 10 feet directly away, and do not Restrict.
- A Restrained creature repeats the Dexterity save at the end of each turn. On success it ends this restraint and moves or falls to the nearest legal supporting space without taking falling damage from the feature's own lift.
- The Field is difficult terrain for hostile creatures and moves with you because it remains centered on you. It creates no permanent terrain, harvestable demon-wood, or automatic Injury.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Black-Thorn Demon Body

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---

## 42. Ten-Thousand Parasite Vessel

**Integration status:** PASS — Body Refining Subpath Integration R7 Candidate.  
**Governing rules:** Body Refining Core R2; Body Refining Shared Procedures R1; Body Refining Subpath Procedure Addendum R8.  
**Mechanical state:** No intentional power increase or reduction from the normalized source.

*The body is not one life. It is a kingdom whose smallest citizens have learned hunger.*

Parasite Vessel disciples cultivate demonic worms, medicinal larvae, marrow insects, and blood parasites inside their organs.

**Access Category:** Forbidden Method  
**Primary Identity:** Internal brood, regeneration, infestation, qi punishment, swarm-body transformation  
**Common Sphere Synergies:** Blood, Daemonic Cultivation, Disease, Flesh, Life, Poison


#### Forbidden Consequence - Purification Shock

Once per round, when you take Radiant damage or fail a save against an effect carrying the Purification tag or explicitly naming parasites, disease, corruption, or daemonic influence:

- Lose 1 Brood.
- Take additional Radiant damage equal to Proficiency Bonus.

This additional damage cannot be reduced by this Subpath. If you have no Brood, you still take it.

##### Normalized Procedure — Purification Shock

- This consequence can trigger once per round from either Radiant damage or a failed save against a source carrying the Purification tag or explicitly naming parasites, disease, corruption, or daemonic influence.
- Resolve the triggering damage or failed save normally. Then lose 1 Brood if available and take additional Radiant damage equal to Proficiency Bonus.
- The additional damage is one Subpath backlash packet. It cannot be reduced by this Subpath, converted into Brood, or used as qualifying hostile damage. Other rules can affect it only if they explicitly affect purification backlash.
- If you have no Brood, you still take the damage. Losing 1 Brood is not a cost and cannot prevent the consequence.
- Several qualifying tags or damage types in one activation produce one trigger.

#### Brood

- Maximum equals Proficiency Bonus.
- Begin each scene with 0 and lose all at scene end.
- Gain no more than 1 per round unless stated otherwise.
- Gain 1 after qualifying hostile damage.

##### Normalized Procedure — Brood Record

- Record current Brood, maximum, normal once-per-round gain, direct gains, scene expiration, and whether Internal Brood has been used this turn.
- Qualifying hostile damage must apply at least 1 damage to your Hit Points. One event grants at most 1 Brood and obeys the ordinary once-per-round limit.
- Parasite Sovereignty and Ten-Thousand Worm Demon Body can grant direct Brood as printed. Direct gain can bypass the ordinary generation limit but not maximum unless a feature increases maximum.
- Brood represents cultivated internal organisms and biomass. It is not a group of free creatures, a Companion, transferable item, spell component, harvestable swarm, or independent action economy.

#### CL3 - Internal Brood

Gain Resistance to Poison damage and Advantage against disease.

At the start of your turn, spend 1 Brood to regain `1d8 + Constitution modifier` Hit Points, increasing to `2d8` at CL11 and `3d8` at CL17. This requires no action, functions once per turn, and cannot heal you at 0 Hit Points.

##### Infesting Strike

**Trigger:** You hit with an unarmed strike.  
**Cost:** 1 Brood  
**Limit:** Once per turn  
**Saving Throw:** Constitution

Deal an additional `1d8` Poison or Necrotic damage. On a failed save, the target becomes **Infested** until the end of your next turn.

##### Normalized Procedure — Internal Brood and Infesting Strike

- Poison Resistance and Advantage against disease use ordinary procedures. “Disease” includes effects explicitly tagged or described as diseases, not every Poison or corruption.
- At the start of your turn, spend 1 Brood to restore the printed Hit Points. This uses no action, functions once per turn, and cannot operate at 0 Hit Points before CL18.
- The die scaling replaces the earlier die. Add Constitution modifier once, to a minimum of 0 Hit Points regained.
- **Infesting Strike:** After an unarmed-strike hit, spend 1 Brood, choose Poison or Necrotic, and add `1d8` to the hit once per turn. The target then makes one Constitution save.
- On failure create one Infested record until the end of your next turn. Record source, Source CL, damage type, trigger status, save DC, and expiration. A new Infestation from you refreshes rather than stacks unless CL14 capacity permits several different creatures.

#### CL6 - Gnawing Infestation

When an Infested creature first spends Cultivation Points, takes Dash, willingly moves 15 feet, regains Hit Points, or gains Temporary Hit Points during its turn:

- It takes `3d8` Poison or Necrotic damage.
- It cannot regain Hit Points or gain Temporary Hit Points until the start of its next turn.
- The Infestation ends.

If not triggered, it repeats the Constitution save at the end of its turn, ending Infestation on a success.

##### Normalized Procedure — Gnawing Infestation

- During an Infested creature's turn, monitor the first qualifying event: spending Cultivation Points; taking Dash; accumulating 15 feet of willing movement; regaining Hit Points; or gaining Temporary Hit Points.
- The event commits before Gnawing resolves. Cultivation Points remain spent, Dash remains taken, movement already completed remains, and healing/Temporary Hit Points are first gained, then the feature deals damage and imposes its prohibition.
- Deal `3d8` Poison or Necrotic using the Infestation's recorded type. The creature cannot regain Hit Points or gain Temporary Hit Points until the start of its next turn, and that Infestation ends.
- One turn can trigger one Infestation from you once. If no trigger occurs, the creature repeats the recorded Constitution save at the end of its turn and ends the Infestation on success.
- Forced movement, teleportation, involuntary falling, and Cultivation Point loss that is not spending do not satisfy the trigger. A 0-point activation is not spending Cultivation Points.

#### CL10 - Brood Substitution

**Reaction**  
**Trigger:** You are hit by an attack or fail a Dexterity or Constitution save against a damaging effect.  
**Cost:** 2 Brood  
**Limit:** Once per round

Reduce damage by `4d8 + Constitution modifier`, move 10 feet without provoking, and leave a swarm-shell in your original space until the start of your next turn.

##### Swarm-Shell

- **AC:** Your Cultivation Save DC
- **Hit Points:** `2 x CL`
- **Immunity:** Poison and Psychic
- **Vulnerability:** Fire and Radiant
- **Space:** 5 feet; creatures move through as difficult terrain

##### Normalized Procedure — Brood Substitution and Swarm-Shell

- Declare after an attack hits you or after you fail the listed save, before triggering damage is applied. Spend the Reaction and 2 Brood.
- Roll `4d8 + Constitution modifier` once and reduce the triggering damage packet at the shared flat-reduction step. The feature does not turn a failed save into a success or remove non-damage consequences.
- After damage resolves, move up to 10 feet without provoking along a legal route. The movement is physical swarm displacement, not teleportation. Leave the Swarm-Shell in your original space only if that space is legal for the Asset.
- The Swarm-Shell is a projected Body Asset with the printed AC, Hit Points, Immunities, Vulnerabilities, and 5-foot space. It is stationary, takes no actions, grants no cover unless normal geometry does so, and lasts until the start of your next turn or until destroyed.
- Creatures can move through its space as difficult terrain but cannot end there unless they could normally share its space. Destroying it causes no damage, Brood loss, Injury, or effect on you.
- If movement fails, the damage reduction still applies and the Shell appears in your current space only when legal; otherwise no Shell is created.

#### CL14 - Parasite Sovereignty

Poison and Necrotic damage from this Subpath ignores Resistance. Maintain Infested creatures equal to Proficiency Bonus.

Once per round when an Infested creature takes Gnawing Infestation damage, choose one:

- Regain Hit Points equal to Proficiency Bonus.
- Gain 1 Brood.
- Move 10 feet without provoking.
- Gain Temporary Hit Points equal to twice Proficiency Bonus.

Brood gained this way can exceed the ordinary gain limit, but this feature remains once per round.

##### Normalized Procedure — Parasite Sovereignty

- Poison and Necrotic damage from this Subpath ignores ordinary Resistance, not Immunity or a superior defense expressly immune to penetration.
- Maintain Infested creatures up to Proficiency Bonus. When exceeding the limit, choose one existing Infestation to end or decline the new one.
- Once per round after one Infested creature takes Gnawing Infestation damage, choose one printed benefit.
- Healing restores Proficiency Bonus Hit Points and is self-generated Body Refining healing. Brood gain is direct and can bypass the ordinary gain limit but not maximum. Movement is up to 10 feet without provoking along a legal route. Temporary Hit Points equal twice Proficiency Bonus and follow the normal nonstacking rule.
- Several Infestations triggering in the same round grant one benefit total. The benefit occurs after Gnawing damage and its healing prohibition are applied; choosing healing therefore cannot restore Hit Points if that same target's trigger somehow made you subject to an applicable prohibition.

#### CL18 - Ten-Thousand Worm Demon Body

**Bonus Action**  
**Duration:** 1 minute  
**Cost:** 7 Stamina  
**Limit:** Once per scene

For the duration:

- Resistance to all damage except Fire, Radiant, Psychic, and Void.
- Move through creature spaces as difficult terrain.
- Pass through openings as narrow as 1 inch.
- Cannot be Grappled or Restrained by ordinary physical effects.
- Gain 1 Brood at the start of each turn.
- Maximum Brood +3.
- Internal Brood can heal you at 0 Hit Points.

If Internal Brood heals you at 0 Hit Points, regain the rolled amount, stand without movement, lose all remaining Brood, and end this transformation. This can happen once per activation.

##### Brood Tide

**Action**  
**Area:** 30-foot cone  
**Cost:** 3 Brood  
**Saving Throw:** Constitution

- **Failed Save:** `8d8` Poison or Necrotic, Infested, and Speed reduced by 15 feet until the end of its next turn.
- **Successful Save:** Half damage, not Infested, and Speed reduced by 5 feet until the start of its next turn.

A creature already Infested when it fails immediately triggers Gnawing Infestation after Brood Tide, then gains a new Infestation.

##### Normalized Procedure — Ten-Thousand Worm Demon Body

- This is a whole-body swarm transformation. Equipment is carried and merged or suspended under the transformation procedure; it does not fall into individual worms or create duplicates.
- Resistance excludes Fire, Radiant, Psychic, and Void. You can move through creature spaces as difficult terrain and through openings at least 1 inch wide, but must end in a legal space large enough for your current body unless another rule permits compression at the end.
- Ordinary physical Grapples and restraints cannot affect you. Supernatural, spatial, spiritual, conceptual, higher-Source-CL, or expressly swarm-binding effects use their normal procedures.
- Increase maximum Brood by 3 and gain 1 at the start of each turn as a direct gain.
- Internal Brood can function at 0 Hit Points once during each activation. When used, spend 1 Brood, regain the rolled amount, stand without movement if possible, lose every remaining Brood, and end the transformation. This replaces remaining at 0 but is not usable against instant death, total destruction, Erasure, or recovery prevention.
- **Brood Tide:** The 30-foot cone originates from you and requires line of effect. Choose Poison or Necrotic for the use. On failure deal `8d8`, Infest, and reduce Speed by 15 feet until the end of the target's next turn. On success deal half, do not Infest, and reduce Speed by 5 feet until the start of its next turn.
- If a failed target was already Infested by you, resolve its existing Gnawing Infestation immediately after Brood Tide damage, end that old record, then create the new Infestation. This immediate trigger counts as Gnawing damage for Parasite Sovereignty and does not require one of the ordinary trigger events.
- A target can be affected once per use. The cone does not leave a persistent swarm, contaminate terrain, or create independent parasite creatures.

---

### Procedural Parity

- **Body source.** Unless a feature expressly creates a projectile, Asset, Field, aura, or other exception, it originates from your body, natural bodily weapon, or integrated weapon and follows the Body Refining external-projection boundary.
- **Effective CL and Source CL.** This Subpath uses your effective Body Refining CL. A persistent state, Adaptation, mark, Asset, transformation, Field, or other effect it creates uses the Source CL of the feature that created it.
- **Realm Suppression.** If your effective CL falls below a feature's level, you cannot activate that feature. A duration, transformation, adaptation, mark, or other state already created by that feature becomes dormant unless its specific normalized rule says it ends. Dormancy does not refund Stamina, restore a consumed resource, or restore an expended scene limit.
- **One activation.** Every attack, movement, target, save, rider, reduction, stored resource, and repeated operation expressly created by one use is part of the same activation. A rider cannot trigger itself or another copy of itself unless the feature expressly permits recursion.
- **Legal spaces.** Movement must end in a space the creature can occupy. If no legal destination exists, use the Failed Spatial Movement procedure; do not place a creature inside a solid object or another creature.
- **Conditions and anatomy.** Flavor does not create an Injury, severance, disabled organ, bodily Asset, permanent transformation, infection, soul damage, Foundation damage, or other lasting consequence. Those results require explicit rules under Body Refining Shared Procedures or another legal Source Rule.
- **No silent extra actions.** A transformation, Adaptation, mark, additional eye, spine, parasite, Grapple, natural weapon, or altered body plan grants only the attacks, movement, actions, Reactions, senses, and equipment permissions printed by the feature.
- **Qualifying hostility and anti-farming.** A resource trigger requiring hostile damage, a failed hostile save, or a hostile activation cannot be generated through willing allies, controlled creatures, trivial hazards created solely to farm the resource, self-damage, or repeated harmless contact. A genuine active environmental hazard expressly permitted by a feature can qualify.

### Integrated Procedure Closure — Ten-Thousand Parasite Vessel

- **Source CL:** Use the Source CL printed by the feature or, when none is printed, the practitioner’s current effective Body Refining CL.
- **Body boundary:** The Subpath acts through the cultivator’s body unless its feature expressly prints external origin, range, target, duration, and persistence.
- **Anatomy and transformation:** Additional anatomy, size, form, or natural weapons grant only their printed attacks, actions, reach, movement, and equipment permissions.
- **Injury and reconstruction:** Ordinary damage does not create an Injury, severance, destroyed organ, or Foundation damage unless a Source Rule expressly invokes the bodily-harm hierarchy.
- **Assets and Anchors:** They possess only their printed statistics, actions, origins, permissions, command economy, and reconstruction procedures.
- **Realm Suppression:** Features above effective CL become unavailable; existing physical anatomy and ordinary bodily durability are not erased unless a Source Rule expressly says so.
- **GM and AI execution:** Use Shared Procedures R1 and Procedure Addendum R7. Do not invent additional damage, cost, condition, injury, permanent loss, action, limb attack, or external projection permission.

---
