# Tianxia Body Refining — Player Path Chapter R8

**Publication state:** Player-facing organization of Body Refining Core R2.  
**Mechanical state:** No intentional mechanical changes from Core R2.  
**PHB state:** Source-ready only. This volume has not yet been inserted into the Player's Handbook.  
**Companion volumes:** *Body Refining Player General Procedures R8*, *Body Refining Subpath Compendium R8*, the central Cultivation Insight catalogue, and the full Body GM Authority Appendix when exceptional adjudication is required.

## How to Use This Chapter

This volume contains the Body Refining CL1–20 chassis, Stamina, Stamina Guard, Iron Fist, Body Tempering, Core Tempering Expressions, Immortal Body, and the Path's ordinary boundaries.

At CL3, choose one Body Refining Subpath from the companion compendium. At CL4, CL8, CL12, CL16, and CL19, choose an Ability Score Improvement or a legal Cultivation Insight from the **central** Insight catalogue. Body Refining does not maintain a separate final Insight authority.

Use *Player General Procedures R8* whenever a feature involves bodily injury, Hidden Injury, severance, reconstruction, transformations, altered anatomy, natural or integrated weapons, detached bodily material, Body Assets, external projection, Stamina Guard ordering, forced movement, Grappling, Tethers, restraint, bodily suppression, or Foundation-linked anatomy.

## Publication Rule Hierarchy

1. The explicit Source Rule creating or modifying the effect.
2. This Body Refining core.
3. Body Refining Player General Procedures R8.
4. The individual Subpath and Subpath Procedure Addendum R8.
5. The central Cultivation Insight catalogue and other legal character options.
6. Universal Tianxia cultivation rules.
7. Ordinary fifth-edition resolution rules where Tianxia has not replaced them.

A dramatic description never grants unprinted injury, regeneration, projection, additional limbs, extra attacks, remote control of bodily material, Foundation damage, or reconstruction.

## Publication Boundary

This chapter is organized now so Body Refining can be audited independently. Final PHB insertion waits until Qi Cultivation, Body Refining, and Spirit Awakening complete the three-Path harmonization audit.

---

> *The sword breaks. The mountain erodes. The heavens fade. But the body tempered for ten thousand years endures.*

Body Refiners perfect the physical vessel until flesh, bone, blood, breath, meridians, instinct, and will become supernatural weapons. A Body Refiner does not reject supernatural power; a Body Refiner rejects power that remains external to the body.

A Qi Cultivator shapes lightning into a technique. A Body Refiner engraves lightning into the blood until breath becomes thunder and movement becomes storm. A Spirit Awakener impresses cultivated identity and authority upon the world. A Body Refiner tempers power into the physical vessel until the body itself becomes impossible to ignore.

Sword intent may be forged into bone. Gold may be refined into skin. Shadow may become movement. Hellfire may become endurance. Dragon blood may become scales, breath, and predatory instinct.

**The Body Refiner does not merely perform the technique. The Body Refiner becomes the technique.**

**Publication status.** This chapter is the player-facing source volume derived from the normalized forty-two-Subpath corpus. The numerical chassis remains unchanged. Final PHB canon placement awaits three-Path harmonization.

---

# Canonical Rule Order

Resolve Body Refining rules in this order:

1. The explicit Source Rule creating or modifying the effect.
2. This Body Refining core.
3. The current **Body Refining Player General Procedures R8** document.
4. Universal Tianxia cultivation rules, including Scene, Realm, Cultivation Points, training, Foundations, Methods, Recorded Arts, Forged Techniques, injury, reconstruction, and Realm Suppression.
5. The underlying D&D 5.5e resolution procedure where Tianxia has not replaced it.

A specific rule overrides a general rule only to the extent stated. Visual description, reputation, a similar technique name, or a conventional class or spell analogy never grants unprinted bodily authority.

# Activation, Body Techniques, and Concentration

An **activation** is one declared use of a feature, talent, Recorded Art, Forged Technique, Immortal Art, item property, or other Source Rule, including every attack, target, repeated strike, movement, and rider that the use expressly creates. Once-per-activation limits apply across the entire use.

A **Body Refining technique** is a supernatural procedure authorized by a Source Rule and expressed through the cultivated body, a natural bodily weapon, an integrated weapon, or another printed bodily medium. It is not automatically an ordinary weapon attack, spell, maneuver, or ability check. Its Source Rule states which resolution procedure it uses.

A Body Refining feature requires Concentration only when its Source Rule says so. Bodily effort, pain, transformation, maintaining a stance, or spending Stamina does not create Concentration by implication.

# Effective CL and Source CL

Your normal effective CL is your Body Refining CL. Realm Suppression or another explicit rule can lower the effective CL used by a feature. Source CL determines authority and interaction; it does not replace attack rolls, saving throws, Stamina costs, Asset profiles, injury procedures, or recovery procedures printed by the Source Rule.

# Body Refining Origin and Projection Boundary

Body Refining normally acts through your own body, a natural bodily weapon, an integrated weapon, bodily material expressly separated by a Source Rule, or a space your body physically occupies, touches, strikes, crosses, or directly affects.

Body Refining does not automatically grant remote technique origin, independent projected creatures, detached acting body parts, free-standing Fields, ranged energy projection, or control of blood, bone, hair, skin, organs, or other bodily material after separation. A Subpath, Insight, Sphere, Method, Foundation, item, Recorded Art, Forged Technique, or other explicit Source Rule may grant a defined exception.

A printed breath, roar, shockwave, thrown bodily weapon, blood spray, bone projection, hair technique, afterimage, or similar effect functions exactly as printed. Its imagery does not grant additional range, targets, persistence, action economy, or external control.

---

# Body Refining at a Glance

| Rule | Body Refining |
|---|---|
| **Key Ability** | Constitution |
| **Hit Die** | d12 |
| **Cultivation Points** | Stamina |
| **Primary Roles** | Durable martial combatant, grappler, frontline protector, mobile physical threat |
| **Saving-Throw Proficiencies** | None |
| **Armor Training** | Light armor, medium armor, shields |
| **Weapon Training** | Simple weapons, martial weapons |
| **Skills** | Choose two: Acrobatics, Athletics, Intimidation, Perception, Survival |

## Hit Points

**Hit Points at CL1:** 12 + your Constitution modifier

**Hit Points at later CLs:** 1d12 - or 7 - plus your Constitution modifier for each Body Refining level after CL1

## Cultivation Mathematics

**Cultivation Save DC:** `8 + Proficiency Bonus + Constitution modifier`

**Cultivation Attack Modifier:** `Proficiency Bonus + Constitution modifier`

**Cultivation Check:** `d20 + Proficiency Bonus + Constitution modifier`

---

# Stamina

A Body Refiner's Cultivation Points are called **Stamina**.

Stamina represents the body's ability to exert cultivated force through physical conditioning, pain tolerance, reinforced flesh, hardened bone, refined blood, controlled breathing, meridian circulation, and supernatural bodily exertion.

## Maximum Stamina

Your maximum Stamina equals:

`Body Refining CL x Constitution modifier`

Only a Source Rule that explicitly modifies maximum Cultivation Points changes this amount.

## Spending Stamina

You spend Stamina when a feature says that you do.

Unless a feature states otherwise:

- Stamina is spent when the feature is activated.
- You cannot activate a feature without enough Stamina to pay its cost.
- Current Stamina cannot exceed maximum Stamina.
- A feature that fails because its declared target was invalid does not resolve.
- Whether its cost is spent follows the feature's printed cost timing.

## Reaching 0 Stamina

When your current Stamina is reduced from a value above 0 to exactly 0, you gain 1 level of Exhaustion.

If you later regain Stamina and are reduced to 0 again, this consequence can occur again.

Beginning a scene at 0 Stamina does not trigger another level of Exhaustion by itself.

## Recovering Stamina

### Short Rest

During a short rest, you may recover half your maximum Stamina, rounded down.

You can use this short-rest recovery twice between long rests.

### Long Rest

Completing a long rest restores all missing Stamina.

### Full Cultivation Session

A full Cultivation Session requires 2 uninterrupted hours.

Completing one restores all missing Stamina. You can receive this full restoration from one Cultivation Session per long rest unless another Source Rule states otherwise.

---

# Body Refining Attacks

A **Body Refining attack** is either:

- An unarmed strike; or
- A weapon attack that a Path, Subpath, Sphere, Recorded Art, Forged Technique, Foundation, Method, or item feature explicitly integrates into your Body Refining cultivation.

A weapon does not become a Body Refining weapon merely because you are proficient with it.

When a rule refers to an **integrated weapon**, it means a weapon currently benefiting from an explicit Body Refining integration feature.

---

# Body Refining Progression

| CL | Features |
|---:|---|
| **1** | Tempered Response, Unarmored Defense, Iron Fist, Stomping Step |
| **2** | Stamina Guard |
| **3** | Body Refining Subpath |
| **4** | Ability Score Improvement or Cultivation Insight |
| **5** | Extra Attack, Body Tempering, Refined Iron Fist |
| **6** | Subpath Feature |
| **7** | Meridian Reinforcement |
| **8** | Ability Score Improvement or Cultivation Insight |
| **9** | Iron Voice |
| **10** | Core Tempering Expression, Subpath Feature |
| **11** | Extra Attack Improvement |
| **12** | Ability Score Improvement or Cultivation Insight |
| **13** | Indomitable Body |
| **14** | Subpath Feature |
| **15** | Blood Pump |
| **16** | Ability Score Improvement or Cultivation Insight |
| **17** | Extra Attack Improvement, Heavenly Fist, Perfected Core Tempering |
| **18** | Subpath Feature |
| **19** | Ability Score Improvement or Cultivation Insight |
| **20** | Immortal Body, Second Core Tempering Expression |

---

# Core Path Features

## CL1 - Tempered Response

Body Refiners do not receive saving-throw proficiencies from their Path. Instead, they cultivate an active physical response against danger.

Choose one Defensive Discipline.

### Rooted Frame

Your chosen saving throw is Strength.

### Flowing Frame

Your chosen saving throw is Dexterity.

### Enduring Frame

Your chosen saving throw is Constitution.

When you fail a saving throw using your chosen ability, you may spend 1 Stamina to add your Proficiency Bonus to the result, potentially turning the failure into a success.

- No action is required.
- You may use it once per round.
- You may use it after learning that the saving throw failed.
- You may use it only once on the same saving throw.
- This bonus is not saving-throw proficiency.
- It does not stack with saving-throw proficiency from another source.
- It cannot modify death saving throws, breakthrough checks, training checks, or another roll that is not a saving throw.

You gain a second Defensive Discipline through Indomitable Body at CL13.

## CL1 - Unarmored Defense

While you are not wearing armor, your Armor Class equals:

`10 + Constitution modifier + Proficiency Bonus`

You may use a shield and retain this Armor Class calculation.

You choose whether to use Unarmored Defense or another available AC calculation. You cannot combine multiple base AC calculations.

## CL1 - Iron Fist

Your body is a cultivated weapon.

Your unarmed strikes deal:

`1d8 + Strength or Constitution modifier`

Choose Strength or Constitution separately for each attack. You may use the chosen ability for both the attack roll and damage roll.

Your unarmed strike may deal Bludgeoning, Piercing, or Slashing damage. Choose the damage type when you make the attack.

For Tianxia features, an Iron Fist attack is both an unarmed strike and a Body Refining melee attack. It does not become a held weapon or an unattended object.

## CL1 - Stomping Step

**Bonus Action**

Take either the Dash action or Disengage action.

Stomping Step represents explosive footwork, controlled bodily release, tendon refinement, practiced breathing, and the ability to place the body exactly where its force is required.

It does not require Stamina.

## CL2 - Stamina Guard

**Reaction**

**Trigger:** Damage is first applied to you.  
**Cost:** Up to your Proficiency Bonus in Stamina

After the damage amount is determined but before your Hit Points are reduced, spend up to your Proficiency Bonus in Stamina.

Reduce the triggering damage by:

`1d10 per Stamina spent`

Roll all dice and total the reduction.

### Damage Procedure

1. Determine the attack or effect's damage.
2. Apply Immunity, Resistance, Vulnerability, and other modifiers that resolve before flat damage reduction.
3. Activate Stamina Guard.
4. Subtract the Stamina Guard result.
5. Reduce your Hit Points by any remaining damage.

If the damage contains multiple damage types, subtract the reduction from the total damage. You choose which damage types are reduced first when that distinction matters.

If Stamina Guard reduces the damage to 0:

- A rider requiring the target to **take damage** does not occur.
- A rider requiring only that the attack **hit** still occurs.
- A condition imposed regardless of damage still occurs.
- The triggering attack or effect is not treated as having missed.

Stamina Guard cannot reduce maximum-Hit-Point loss, Cultivation Point loss, a cost willingly paid, damage that explicitly cannot be reduced or prevented, or a consequence that is not expressed as damage.

## CL3 - Body Refining Subpath

Choose one Body Refining Subpath for which you have legal access. Your Subpath represents the school, scripture, inheritance, bodily transformation, martial focus, or forbidden method through which your cultivated body develops its defining expression.

You gain its features at CL3, CL6, CL10, CL14, and CL18.

| Classification | Meaning |
|---|---|
| **Open School** | Commonly teachable or institutionally available. Open access does not imply low power. |
| **Restricted Scripture** | Controlled military, medical, sect, weapon, technical, political, inherited, or hazardous instruction. |
| **Rare Inheritance** | Uncommon bloodline, transformed anatomy, destiny, treasure, vessel, species, or singular transmission. |
| **Forbidden Method** | A bodily cultivation method carrying a prohibited, condemned, predatory, corruptive, or physically catastrophic price. Forbidden does not automatically mean Daemonic. |

A campaign may alter access requirements without changing a Subpath's mechanics. A Subpath does not automatically grant a Sphere or Sphere talent unless its rules explicitly state otherwise.

## CL4, CL8, CL12, CL16, and CL19 - Ability Score Improvement or Cultivation Insight

At each listed CL, choose one of the following:

- **Normal Ability Score Improvement:** Increase one ability score by 2, or increase two different ability scores by 1 each. No score can exceed the maximum allowed by your current Realm.
- **Cultivation Insight:** Choose one Cultivation Insight for which you meet every prerequisite. Gain its cultivation benefit and increase one ability score listed in that Insight's **Ability Increase (Level Selection)** entry by 1, to the maximum allowed by your current Realm.

An Insight gained through a manual, tribulation, relic, sect instruction, bloodline awakening, experimentation, bodily transformation, story reward, or another non-level source does not grant its ability increase unless that source explicitly says otherwise. Background ability-score increases and Origin Insights are separate character-creation benefits and do not activate this increase.

Use the current **Tianxia Central Cultivation Insights** catalogue as the rules authority. Path, Sphere, and Subpath access tags are prerequisites only when the Insight expressly prints them. Advisory affinity or recommendation tags never grant access.

If an Insight grants a new Sphere, it also grants the normal free first talent received whenever a character learns a new Sphere.

## CL5 - Extra Attack

When you take the Attack action, you may make two attacks instead of one.

This increases to three attacks at CL11 and four attacks at CL17.

An attack granted outside the ordinary attacks of your Attack action cannot itself trigger another feature that grants an additional attack unless that feature explicitly overrides this rule.

## CL5 - Body Tempering

Your body has passed beyond ordinary mortal frailty.

You gain Resistance to nonmagical Bludgeoning, Piercing, and Slashing damage.

This Resistance applies to qualifying damage from mundane weapon attacks, falling, collisions, nonmagical traps, rubble, cave-ins, ordinary machinery, and nonmagical environmental hazards.

An attack or hazard is cultivation-powered rather than mundane when its damage is created or empowered by a Path feature, Subpath feature, Sphere talent, Recorded Art, Forged Technique, Immortal Art, Foundation feature, Method feature, supernatural item power, or another rule explicitly identifying it as magical or cultivation-powered.

Body Tempering does not grant Resistance against cultivation-powered physical damage unless another feature states otherwise.

In addition:

- You have Advantage on saving throws against extreme heat, extreme cold, high altitude, forced marches, starvation, dehydration, and suffocation.
- You can hold your breath for ten times the normal duration.
- Ordinary caltrops, thorns, splinters, and similarly minor environmental hazards cannot damage you unless they are supernatural or part of an active attack or trap.

## CL5 - Refined Iron Fist

Your unarmed strikes count as magical and cultivation-powered for the purpose of overcoming Resistance and Immunity.

A weapon integrated into your Body Refining cultivation also gains this property while you wield it.

This feature does not cause a mundane attack made by another creature to bypass your Body Tempering.

## CL7 - Meridian Reinforcement

Your meridians, organs, blood, and nervous system resist contamination and physical collapse.

You gain Advantage on saving throws against the Poisoned condition, disease, Exhaustion caused by physical exertion or environmental exposure, effects that obstruct breathing, and effects that directly disrupt your bodily meridians.

At the end of your turn, if you are Poisoned or affected by a disease with a printed saving throw DC, you may spend 1 Stamina to repeat the original saving throw against the original DC.

- No action is required.
- You may make this additional saving throw once per round.
- On a success, the Poisoned condition or disease ends if the original effect would end on a successful repeated save.
- If the disease normally requires multiple successful saves, this success counts as one such success.

Meridian Reinforcement cannot remove or suppress Exhaustion gained from reaching 0 Cultivation Points, Hidden Injuries, Foundation damage, Tribulation scars, curses, possession, permanent corruption, or a condition whose Source Rule states that ordinary saves cannot remove it.

## CL9 - Iron Voice

**Bonus Action**

**Range:** 30 feet  
**Target:** One creature that can hear you  
**Cost:** 1 Stamina  
**Saving Throw:** Constitution

On a failed save, the creature is Frightened of you until the end of your next turn. On a successful save, it suffers no effect.

A creature immune to the Frightened condition automatically succeeds.

Iron Voice is blocked by total silence, an effect preventing the target from hearing, total cover that also prevents sound from passing, or a feature explicitly suppressing cultivation pressure or bodily sound.

Iron Voice does not require shared language.

## CL10 - Core Tempering Expression

When you enter Core Formation Realm, your accumulated bodily refinement settles into a stable internal expression.

Choose one Core Tempering Expression. Your choice is permanent until you complete a later Realm breakthrough. When you successfully enter Nascent Soul Realm at CL15, you may replace your chosen expression with another before using any CL15 feature.

At CL17, your chosen expression becomes Perfected.

At CL20, choose a second expression. Both expressions function simultaneously, and both use their Perfected benefits.

### Golden Bell Circulation

**Bonus Action**  
**Cost:** 3 Stamina  
**Duration:** 1 minute

For the duration:

- Gain +2 AC.
- You have Advantage on checks and saving throws against being pushed, pulled, or knocked Prone.
- Once per round, when Stamina Guard reduces a damage packet to 0, gain Temporary Hit Points equal to your Proficiency Bonus.

The effect ends early if you become Unconscious. Activating Golden Bell Circulation again replaces and refreshes its duration.

#### Perfected Golden Bell - CL17

While Golden Bell Circulation is active:

- Stamina Guard uses d12s instead of d10s.
- Your Temporary Hit Points from Golden Bell equal twice your Proficiency Bonus.
- You cannot be moved against your will by a creature whose CL is lower than yours unless its feature explicitly ignores bodily anchoring.

A creature of equal or higher CL resolves forced movement normally.

### Blood-Furnace Circulation

Once per turn, immediately after you spend one or more Stamina on a feature that successfully resolves, regain Hit Points equal to your Proficiency Bonus.

If you are at your maximum Hit Points, gain Temporary Hit Points equal to your Proficiency Bonus instead.

Blood-Furnace Circulation does not function while you are at 0 Hit Points, cannot be triggered by refunded Stamina or an invalid activation, and functions no more than once per turn.

#### Perfected Blood Furnace - CL17

The Hit Points or Temporary Hit Points gained become `2 x Proficiency Bonus`.

When this feature restores Hit Points, you may also end one ongoing Bleeding state affecting you if that state has a Source CL no higher than your CL.

### Mountain-Rending Pulse

Once per turn, immediately after you spend one or more Stamina on a feature that successfully resolves, empower your next Body Refining melee attack before the end of your next turn.

On a hit:

- Deal an additional `1d8` Force damage.
- Choose either to push the target 5 feet or prevent it from taking Reactions until the start of its next turn.

If the empowered attack misses, the empowerment remains until its duration expires.

You cannot hold more than one Mountain-Rending empowerment at a time. Gaining another replaces the previous one.

#### Perfected Mountain-Rending Pulse - CL17

The additional damage becomes `2d8` Force damage.

On a hit, choose one:

- Push the target 10 feet.
- Knock the target Prone if it fails a Strength saving throw.
- Prevent it from taking Reactions until the start of its next turn.
- Deal double damage to an unattended object, temporary barrier, vehicle, structure, or Formation Anchor.

## CL11 - Extra Attack Improvement

When you take the Attack action, you may make three attacks instead of two.

## CL13 - Indomitable Body

Choose a second Defensive Discipline from Tempered Response.

In addition, when you fail a saving throw, you may spend 3 Stamina to reroll it.

- No action is required.
- You may use Indomitable Body once per round.
- You must use the new result.
- A die cannot be rerolled more than once.
- You may use Indomitable Body after Tempered Response failed to turn the original roll into a success.
- If you used Tempered Response on the original roll, you cannot use it again on the reroll.
- Indomitable Body cannot reroll a death saving throw, breakthrough check, training check, or another roll that is not a saving throw.

## CL15 - Blood Pump

**Trigger:** You would be reduced to 0 Hit Points but are not killed outright.  
**Cost:** 6 Stamina  
**Limit:** Once per scene  
**Action:** None

You are reduced to 1 Hit Point instead.

Blood Pump resolves after all damage reduction has been applied.

Blood Pump cannot prevent instant death, total bodily destruction, an effect explicitly stating that reaching 0 Hit Points cannot be prevented, unavoidable damage from a feature that prohibits zero-Hit-Point substitution, death caused by a non-damage effect, or maximum-Hit-Point reduction that leaves your maximum at 0.

Only one feature that replaces or prevents the same reduction to 0 Hit Points can resolve. If several are available, choose one.

## CL17 - Extra Attack Improvement

When you take the Attack action, you may make four attacks instead of three.

## CL17 - Heavenly Fist

Your unarmed strikes and integrated weapons:

- Count as magical.
- Count as cultivation-powered.
- Count as adamantine.
- May deal Force damage instead of their normal damage type.
- Ignore ordinary Resistance to damage from nonmagical weapons.
- Cannot be broken or rendered unusable by a mundane disarm, rust, dulling, or weapon-breaking effect while you wield them.

Against an unattended object, vehicle, structure, temporary barrier, terrain section, or Formation Anchor whose Source CL is no higher than yours:

- Your Body Refining attacks deal double damage.
- Ignore Resistance to Bludgeoning, Piercing, Slashing, and Force damage.
- Treat its Damage Threshold as 0.

Against a target with a higher Source CL, resolve its Resistance and Damage Threshold normally.

Heavenly Fist does not automatically bypass Immunity, permanent artifact properties, Immortal protections, Void protections, or a Source Rule explicitly stating that physical force cannot damage the target.

## CL17 - Perfected Core Tempering

Your chosen Core Tempering Expression gains its Perfected benefits.

## CL20 - Immortal Body

Your physical vessel no longer obeys ordinary mortal limitations.

### Immortal Regeneration

At the start of each of your turns, if you have at least 1 Hit Point, regain 20 Hit Points.

### Body Recalls Life

At the start of your turn, if you are at 0 Hit Points, alive, and have at least 10 Stamina, you may spend 10 Stamina to regain 20 Hit Points.

- No action is required.
- You may use this benefit once per scene.
- You immediately regain consciousness.
- You may stand by spending 5 feet of movement.
- Failed death saving throws remain until removed under the normal rules.
- This cannot restore you after death.
- It cannot function if your body has been completely destroyed.
- It cannot function while an effect explicitly prevents healing or bodily reconstruction.

### Immortal Reconstruction

- A severed body part held against its original location reattaches after 1 uninterrupted minute.
- A missing body part regrows during a full 2-hour Cultivation Session.
- A regrown body part is fully functional when the session ends.
- This reconstruction does not restore Hit Points unless another rule says so.
- It does not repair Foundation damage, soul damage, core destruction, Hidden Injuries, or permanent identity alteration.

### Transcended Mortal Needs

You cease aging unless you choose to continue aging, cannot die from old age, do not require food, drink, air, or sleep, and are immune to mundane disease and ordinary bodily poison.

You must still complete rests or Cultivation Sessions to gain their mechanical benefits.

Cultivation-powered disease, curses, corruption, Tribulation effects, Foundation injuries, and poisons with a Source CL remain capable of affecting you unless another feature protects you.

### Complete Defensive Tempering

You gain all three Defensive Disciplines from Tempered Response.

### Second Core Tempering Expression

Choose a second Core Tempering Expression. Both are active and use their Perfected CL17 benefits.

---

# Realm Suppression — Body Summary

Use the universal Realm Suppression procedure unless an explicit Body Refining Source Rule states otherwise.

- Use the suppressed Proficiency Bonus and effective CL for attacks, saving throw DCs, scaling, Source CL, and feature access.
- You cannot activate a Body Refining feature gained above the suppressed CL.
- A transformation, stance, projected bodily Asset, or other state granted solely by an unavailable feature is suppressed for the duration rather than destroyed.
- Maximum Hit Points, Hit Dice, maximum Stamina, and permanent anatomy are not recalculated solely because of Realm Suppression.
- Passive bodily durability and an existing Foundation are not automatically removed. A Source Rule that suppresses a named feature, bodily system, transformation, Foundation benefit, or complete Body Refining cultivation applies only to the authority it expressly states.
- A suppressed severed limb, organ, mutation, or embodied Asset is not healed or reconstructed merely because its feature is unavailable.

The Body Refining GM Authority module governs collisions involving complete bodily suppression, Foundation damage, destroyed cultivation systems, altered anatomy, and reconstruction.

---

# Realm Integration

| Realm | CL | Core Body Refining Expression |
|---|---:|---|
| **Mortal** | 1-4 | Iron Fist, Stomping Step, Stamina Guard, initial Subpath |
| **Foundation** | 5-9 | Extra Attack, Body Tempering, refined cultivation attacks, reinforced meridians |
| **Core Formation** | 10-14 | Core Tempering Expression, three attacks, Indomitable Body |
| **Nascent Soul** | 15-19 | Blood Pump, perfected circulation, four attacks, Heavenly Fist |
| **Immortal** | 20 | Immortal regeneration, bodily reconstruction, second Core Tempering Expression |

Realm entry does not automatically waive a Heavenly Tribulation, breakthrough requirement, AP requirement, or another universal advancement rule.

---

# Universal Subpath Rules

These rules apply to every Body Refining Subpath in this document.

## Cultivation Save DC

Unless stated otherwise, a Subpath saving throw uses your Body Refining Cultivation Save DC.

## Bloodied

A creature is **Bloodied** while it has half its maximum Hit Points or fewer.

## Qualifying Hostile Creature

A **qualifying hostile creature** must be actively hostile to you or your allies, must not be controlled or created by you or a willing ally, must not be deliberately captured or repeatedly revived to generate resources, and must have a CL no more than 5 lower than yours.

A creature without a CL qualifies when its encounter rank or threat is intended to challenge a character within 5 CL of you.

## Qualifying Hostile Damage

**Qualifying hostile damage** is damage caused by a hostile creature, active trap, or active environmental hazard.

Damage caused by yourself, a willing ally, a harmless object, or a deliberately staged interaction does not qualify.

Where a feature requires substantial damage, the damage must equal or exceed your Proficiency Bonus after all reductions.

## Source CL

A creature feature uses its user's CL as its Source CL.

An item, trap, Formation, hazard, or other independent effect uses its printed Source CL. If none is printed, use the encounter's CL.

When a feature automatically overcomes an opposing effect whose Source CL is no higher than yours, a higher-CL effect remains unaffected unless the feature provides a contest.

## Failed Spatial Movement

When teleportation, phasing, or spatial movement fails because of a Body Refining feature:

- The action, Bonus Action, Reaction, or movement expenditure used to activate it is spent.
- All Cultivation Point and limited-use costs are spent.
- The creature remains in the nearest legal space on the original side of the obstruction.

When a contest is required, the moving creature rolls `d20 + Proficiency Bonus + Path key ability modifier` against your Cultivation Save DC.

## Granted Attack Rule

An attack granted outside the normal attacks of the Attack action cannot trigger another feature that grants an attack.

A named once-per-turn damage or control rider can affect only one attack during the same turn unless its rule explicitly states otherwise.

## Unique States

A unique state is not a standard condition unless its rule says otherwise.

Unless a state states differently:

- One creature can bear only one instance of that state from you.
- Reapplying it replaces and refreshes the previous instance.
- Different cultivators track their states separately.
- The state ends immediately if its printed duration expires or its removal procedure succeeds.

## Transformations

A Subpath transformation with a once-per-scene limit cannot be activated more than once during the same scene, cannot be refreshed by paying its cost again, and ends if you become Unconscious unless stated otherwise.

## Weapon Groups

| Weapon group | Included weapons |
|---|---|
| **Bow** | Shortbow, longbow, and a weapon carrying the Bow tag |
| **Draw Blade** | Dagger, shortsword, saber, scimitar, one-handed sword, and a weapon carrying the Draw Blade tag |
| **Polearm** | Spear, staff, glaive, halberd, and a weapon carrying the Polearm tag |
| **Chain Weapon** | Chain, whip, flail, rope dart, meteor hammer, and a weapon carrying the Chain Weapon tag |
| **Blade** | Dagger, sword, saber, axe with a cutting edge, and a weapon carrying the Blade tag |
| **Hafted Weapon** | Axe, mace, hammer, club, and a weapon carrying the Hafted Weapon tag |
| **Thrown Weapon** | A weapon with the Thrown property |
| **Staff** | Quarterstaff and a weapon carrying the Staff tag |
| **Unarmed Form** | Unarmed strike or natural bodily weapon |

Custom weapons must list their weapon group in their item statistics.

---

# Canonical Integration Contract

A Body Refining character record must identify:

- Body Refining CL, effective CL, and Source CL;
- Constitution modifier, maximum Stamina, and current Stamina;
- Defensive Disciplines;
- current Core Tempering Expression or Expressions;
- chosen Subpath and every Subpath-specific state or resource;
- integrated weapons and the Source Rule granting each integration;
- permanent bodily transformations, altered anatomy, embodied Assets, injuries, Hidden Injuries, and reconstruction requirements;
- Foundations, Methods, Spheres, Insights, Recorded Arts, items, and other Source Rules that modify the body;
- any active Realm Suppression or bodily-system suppression.

An AI, GM, or automation may not infer unprinted external projection, anatomy, immunity, regeneration, companion action economy, Asset statistics, injury recovery, or Foundation interaction from flavor text alone.
