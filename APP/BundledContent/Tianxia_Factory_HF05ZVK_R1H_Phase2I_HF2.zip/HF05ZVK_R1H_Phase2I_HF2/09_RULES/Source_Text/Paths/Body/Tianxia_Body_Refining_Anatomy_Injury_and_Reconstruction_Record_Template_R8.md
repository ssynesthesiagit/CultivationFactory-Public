# Tianxia Body Refining — Anatomy, Injury, and Reconstruction Record Template R8

Use this template whenever a character has nonstandard anatomy, a Tier II–V bodily injury, a replacement structure, or an active reconstruction project.

## A. Anatomy Record

- **Character:**
- **Base body plan:**
- **Current size:**
- **Temporary form replacement:**
- **Permanent transformations:**
- **Manipulators:**
- **Primary locomotor structures:**
- **Flight structures:**
- **Sensory structures:**
- **Breath and voice structures:**
- **Vital structures:**
- **Cultivation structures:**
- **Natural weapon structures:**
- **Added structures:**
- **Foundation-linked structures:**
- **Integrated weapons:**
- **Equipment incompatibilities or suspended items:**

## B. Injury Record

- **Injury ID:**
- **Name:**
- **Tier:** I / II / III / IV / V
- **Tags:** Physical / Cultivation / Foundation / Soul / Identity / Mixed
- **Originating Source Rule:**
- **Source CL:**
- **Save or check DC:**
- **Affected structure:**
- **Immediate result:**
- **Persistent mechanical effect:**
- **Detection status:** Visible / Concealed / Specialist only
- **Diagnosis methods:**
- **Valid treatment categories:**
- **Required materials:**
- **Required Reconstruction Progress:**
- **Current Reconstruction Progress:**
- **Attempt cadence:**
- **Failure consequence:**
- **Suppression interaction:**
- **Transformation interaction:**
- **Foundation interaction:**
- **Cosmetic scar after repair:**
- **Mechanical scar after repair, if explicitly created:**

## C. Reconstruction Attempt

- **Date or session:**
- **Lead specialist/source:**
- **Lead Source CL:**
- **Assistant:**
- **Treatment category:**
- **Materials declared:**
- **Check used:**
- **DC:**
- **Result:**
- **Progress gained:**
- **Materials consumed:**
- **Stabilization or suppression gained:**
- **Remaining requirements:**

## D. Replacement Structure Record

- **Replacement name:**
- **Structure replaced:**
- **Type:** Biological / Cultivated / Alchemical / Constructed / Spiritual / Artifact
- **Source CL:**
- **Restored functions:**
- **New functions:**
- **Functions not restored:**
- **Natural anatomy, Asset, Foundation component, or item:**
- **Maintenance and sustenance:**
- **Transformation compatibility:**
- **Suppression behavior:**
- **0-Hit-Point or destruction behavior:**
- **Regrowth interaction:**
- **Removal procedure:**

## E. Body Asset Record

- **Asset name:**
- **Category:** Embodied / Attached Independent / Detached Real / Projected / Replacement
- **Source Rule:**
- **Source CL:**
- **Size and status:**
- **AC:**
- **Hit Points:**
- **Resistances and Immunities:**
- **Conditions:**
- **Space and movement:**
- **Senses and communication:**
- **Action economy:**
- **Attacks or saves:**
- **Tether or range:**
- **At 0 Hit Points:**
- **Repair or recreation:**
- **Realm Suppression:**
- **Real or projected:**
