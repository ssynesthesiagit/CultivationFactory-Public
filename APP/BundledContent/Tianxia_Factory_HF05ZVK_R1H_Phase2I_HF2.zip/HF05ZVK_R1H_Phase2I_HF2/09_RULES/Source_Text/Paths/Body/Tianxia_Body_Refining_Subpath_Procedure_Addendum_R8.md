# Tianxia Body Refining — Subpath Procedure Addendum R8
**Status:** Complete integrated procedure candidate through all 42 normalized Body Refining Subpaths.  
**Purpose:** Shared execution rules invoked by Body Refining Subpaths. This document grants no ability by itself.  
**Mechanical state:** Consolidation and cross-reference repair only; no intentional power increase or reduction.

**Scope:** Controlled normalization Batches 1–5, Subpaths 1–35.
**Status:** Cumulative candidate procedure module.  
**Authority:** This addendum grants no feature by itself. It supplies shared execution rules only when a legal Body Refining Source Rule invokes the relevant procedure.

---

## 1. Size, Functional Size, and Space

A feature can alter **actual size** or allow a creature to **count as larger** for listed operations.

- Actual size changes occupied space and ordinary size interactions.
- Functional size applies only to the operations named by the feature.
- Functional-size permissions from different features do not stack unless one expressly says they do.
- A size change requires a legal space. Use the Body Transformation and Failed Spatial Movement procedures when the space cannot contain the new or returning body.
- Equipment follows the transformation record; it does not duplicate, fall away, or cease functioning unless the selected fit procedure says so.

## 2. Grapple and Restraint Records

A Subpath Grapple uses the normal Grapple plus these recorded facts:

1. Grappler and target.
2. Anatomy or medium maintaining the Grapple.
3. Applicable functional sizes.
4. Current reach.
5. Escape procedure and DC.
6. Any attached state, such as Joint Lock or Crushing Grip.

If the required anatomy is disabled, severed, transformed away, or suppressed, the Grapple ends unless another recorded structure maintains it. Granted movement does not automatically end a Grapple; resolve whether it carries both creatures, transfers the Grapple, or breaks it.

## 3. Forced Movement and Collisions

Unless the feature prints another direction, a push moves directly away from the source. A throw uses its chosen legal route.

A collision requires forced movement to be stopped early by a substantial solid obstruction or to enter another creature's occupied space. Merely ending adjacent to a creature or wall is not a collision.

For a creature collision:

1. The second creature makes any printed save before placement.
2. On success, it remains in place and the moved creature stops in the nearest legal space.
3. On failure, apply printed damage and place both creatures in nearest separate legal spaces around the collision point.
4. One creature takes a given feature's collision damage no more than once per activation unless the feature explicitly creates repeated collisions.

## 4. Attack Redirection

A redirected attack remains the original attacker's activation.

- Preserve its attack modifier, resource expenditures, damage, riders, and legal-target restrictions.
- Select a legal replacement target before rolling unless the feature redirects an already-rolled attack.
- Recheck reach, range, cover, line of effect, and target permissions.
- A redirected attack cannot be redirected again unless a higher-authority rule expressly permits recursive redirection.
- The redirecting cultivator does not become the attack's source and does not gain hit credit.

## 5. Granted Attacks and Replacement Attacks

Use the core Granted Attack rule. In addition:

- A granted attack cannot grant another attack unless the feature explicitly permits it.
- Replacing one attack with multiple attacks does not create additional Attack actions.
- A once-per-turn rider can apply only once across the original and replacement attacks.
- A reaction-free use removes only the Reaction cost; printed frequency limits remain.

## 6. Damage Reduction and Zero Damage

Resolve Resistance, Vulnerability, redirection, percentage modifiers, Stamina Guard, other flat reductions, and damage riders in the order established by Body Refining Shared Procedures.

- An attack that hit remains a hit if its damage becomes 0.
- A rider requiring “a hit” can still trigger.
- A rider requiring “the target takes damage” does not trigger.
- A 0-Hit-Point replacement resolves before Unconsciousness and death procedures.

## 7. Objects, Structures, Terrain, and Formation Anchors

A feature affects only a discrete target that can be profiled or reasonably bounded.

- “Unattended” excludes worn, carried, wielded, piloted, or actively controlled objects.
- A target belonging to multiple eligible categories receives a printed damage multiplier only once.
- Damage Threshold and Immunity remain unless the feature expressly changes them.
- Terrain damage does not grant authority to destroy undefined world-scale geography.

## 8. Diagnostic Information

A diagnostic feature reveals exactly the listed mechanical data.

- It does not reveal unlisted secrets, future choices, hidden techniques, true identity, or exact ability scores.
- A specific equal-or-higher-authority concealment can contest a listed datum through a Cultivation Check.
- Failure reveals that the datum is concealed rather than providing false data unless the concealment rule expressly creates false information.

## 9. Scene and State Records

Record each scene state with:

- feature name and activation time;
- cost paid;
- duration and ending conditions;
- selected options;
- current size, stance, target, or state;
- whether its once-per-scene use has been expended;
- Source CL and effective CL.

Suppression does not refund cost or scene use. Reactivation after suppression is permitted only if the feature's own duration and activation rules still allow it.

---

## 10. Integrated Weapon Records

Each integrated weapon record identifies:

1. Weapon instance or bodily expression.
2. Weapon group.
3. Ability choices for attack and damage.
4. Whether the Cultivation Attack Modifier applies.
5. Which Path features apply to it.
6. Damage-type permissions.
7. Manifestation, storage, and anti-duplication procedure.
8. Source CL and suppression behavior.

Integration does not grant a Sphere, a Sphere talent, an extra attack, or ownership of a separate weapon. A manifested integrated weapon cannot exist in two places at once.

## 11. Reach and Threatened-Space Geometry

A reach increase states whether it functions during the cultivator's turn, outside the turn, or both.

- Turn-only reach applies to attacks and features during that turn but does not enlarge Opportunity Attack reach later.
- Persistent reach enlarges legal melee targeting and threatened space while active.
- Expanding reach around a stationary creature does not count as that creature entering reach.
- A creature can trigger an entry effect only as often as the feature states, regardless of leaving and re-entering repeatedly.

## 12. Projectile Interception and Cover

An interceptable physical projectile is a discrete material object traveling through a path that can be physically struck or caught.

- Resolve interception after damage is calculated but before Hit Points are reduced.
- A qualifying projectile can carry mixed damage, but a separate explosion, curse, cloud, or area event is not automatically canceled.
- Deflection does not create a new attack unless the feature expressly supplies an attack roll, target, and damage.
- Catching or deflecting never duplicates ammunition, thrown weapons, items, or cultivation materials.
- Cover is checked when the attack resolves and applies only against the attack categories printed by the feature.

## 13. Precision, Pressure-Point, and Severing Labels

Arm, Leg, Breath, Balance, Flow, Guard, pressure point, and severing labels are temporary combat impairments unless a feature expressly invokes the bodily-harm hierarchy.

- They do not create Injuries, sever limbs, destroy organs, or damage Foundations.
- Apply them through the closest equivalent bodily function for a nonhumanoid target.
- An explicit immunity to the exact impairment can block it; unusual anatomy alone does not.
- The same named temporary effect from the same source refreshes rather than stacks.

## 14. Environmental Effects and Damaged Terrain

An environmental feature identifies its bounded area, damage type, line of effect, and whether it affects allies.

Ordinary damaged ground remains difficult terrain until each 5-foot square is cleared by 1 minute of work with suitable tools, repaired by a legal crafting or cultivation procedure, or replaced by terrain authority of equal or higher Source CL. Terrain text never grants undefined world-scale destruction.

A feature that ignores mundane weather or terrain does not automatically ignore a supernatural Field, Formation, Domain, or higher-authority environmental technique.

## 15. Body Assets and Direct Commands

A Body Asset record includes AC, Hit Points, size, Speed, Source CL, actions, Reactions, command cost, default behavior, destruction, healing compatibility, and suppression.

- A Body Asset is not automatically a creature, Companion, Complete Soul, or independent turn.
- If the Source Rule prints no command distance, normalization does not invent a shorter one; direct control functions on the same plane unless blocked.
- A commanded Asset can use only its printed actions and cannot deliver the cultivator's personal riders without express permission.
- Destroyed manifested Assets leave no harvestable material unless their Source Rule says otherwise.

## 16. Concealment, Invisibility, and Afterimages

Invisibility and obscuration are evaluated separately for each observer.

- Invisible does not mean hidden.
- Dim Light does not block sight from a creature that can see normally in it.
- An Afterimage is a decoy or projected Asset only to the extent printed; it does not gain independent personhood, cultivation, equipment activation, or attack authority.
- Seeing through an Afterimage does not replace the cultivator's own senses unless the feature says it does.
- A harmful action reveals an invisible cultivator only for the timing printed by its Source Rule.

## 17. Zero-Hit-Point Replacements and Protective Forms

When multiple features would replace the same reduction to 0 Hit Points, choose one unless a feature expressly permits combination.

- Resolve the chosen replacement before Unconsciousness and death saves.
- A transformed body remains the creature unless the feature creates a separate Asset.
- A cocoon, shell, statue, or vessel record states whether damage transfers, whether death saves occur, and what happens at 0 Asset Hit Points.
- Costs and scene uses are spent when the replacement is declared.
- Being killed outright, complete bodily destruction, or an explicit healing/reconstruction prohibition defeats a later restoration unless the feature says otherwise.

## 18. Auras and Once-per-Activation Entry Benefits

An aura moves with its source unless stated otherwise.

- Determine inclusion and benefits at the instant a creature enters, starts a turn, or is targeted.
- “The first time during the activation” is once per creature for that activation, not once per entry.
- Starting a new activation resets once-per-activation eligibility; refreshing the same activation does not unless the feature says it creates a new activation.
- Suppression makes the aura dormant without refunding costs or extending duration.

## 19. Source CL Contests and Status Quo

When an equal- or higher-Source-CL effect calls for opposed Cultivation Checks:

1. Each side rolls its Cultivation Check once.
2. The higher result controls the contested movement, suppression, transformation, or authority.
3. A tie preserves the current state: the creature remains in place, the existing form remains, and no transfer or forced change occurs.
4. A failed activating effect still spends its action, resource, and limited use unless its own rule says otherwise.


---

## 20. Breath, Roar, and Elemental Body Projection

A breath or roar is a printed exception to the ordinary Body external-projection boundary only for its stated origin, area, damage, targets, and duration.

- Select damage type when activating unless the feature says otherwise.
- A cone or line requires line of effect and affects each target once.
- It creates no lingering Field, weather, smoke, flame, or object authority unless expressly printed.
- Object multipliers apply once per target even when categories overlap.
- Silence, sealed air, or another countermeasure matters only when its rule expressly contests the effect's physical or supernatural medium.

## 21. Incorporeal Bodies, Phasing, and Illegal End Spaces

An Incorporeal or phased Body remains the same creature with one body record, Hit Point total, turn, action economy, condition set, and equipment set.

- Passing through matter costs movement as printed and does not grant sight through opaque matter.
- Worn and carried equipment follows the body; passengers and oversized objects require express permission.
- Artifact barriers, spatial locks, and explicit phasing prohibitions retain their authority.
- If a turn ends in an illegal space, use the Source Rule's displacement and damage. If none is printed, use Failed Spatial Movement without inventing damage.
- Phasing never grants automatic access to an Intruder, Complete Soul, hidden chamber, or sealed cultivation system.

## 22. Spiritual Surgery Through the Body

A bodily procedure affecting possession, transformation, soul-binding, or a spiritual state must record:

1. Legal patient state and procedure time.
2. Targeted effect and Source CL.
3. Diagnosis data.
4. Save or Cultivation Check.
5. Expulsion destination or suppression duration.
6. Complete Soul, ancestry, consent, and Bond protections.

Body Refining does not silently grant ownership, destruction, conversion, or permanent severance of a spirit. Use the Spirit Awakening Rules Reference or Universal Cultivation Authority procedures for those questions.

## 23. Forbidden Hunger, Scars, and Signaling

A Forbidden Method records each consequence separately.

- **Hunger** states its trigger, obligation, restraint save, failure behavior, excluded targets, and ending condition.
- **Scars** state visibility, recognition criteria, concealment, and exact social modifiers.
- **Signaling** states range, plane, information revealed, qualifying observers, and removal procedure.
- Failure never forces an unprinted attack, action, target, crime, or loss of character control.
- A consequence is not removed by ordinary healing unless its Source Rule provides that procedure.

## 24. Predatory Vitality and Pain Records

A predatory or pain-based feature must use qualifying hostile creatures and anti-farming rules.

- Determine Bloodied status at the timing printed by the feature.
- Temporary Hit Points never stack.
- Once-per-creature healing remains spent across revival, recapture, and replacement-body loops unless the feature expressly resets it.
- A pain mark records its source, target, ending time, and consumption trigger.
- Predatory vitality does not automatically consume souls, copy traits, steal Foundations, or create harvestable cultivation materials.

## 25. Fire Intake, Brands, and Cooling Rites

When a Body feature consumes hostile Fire:

- Calculate the Fire portion after the full damage procedure.
- Only Fire damage actually taken can fuel the printed benefit.
- Mixed packets contribute only their Fire portion.
- Self-created, allied, staged, harmless, and repeated stationary sources do not qualify.

A burning state records start-of-turn damage, repeat-save timing, extinguishing action, stacking rule, and Source CL. A cooling rite records start time, interruption conditions, duration, and exactly which disabled feature it restores.

## 26. Aerial Movement and Pursuit

- Actual movement distance excludes teleportation unless the feature expressly counts it.
- Temporary flight states record activation timing, remaining movement, suspension, falling, and suppression.
- A pursuit Reaction resolves after the triggering movement or teleport, then grants only the movement and attack printed.
- “End closer” compares straight-line distance from starting and ending positions.
- Collision damage occurs only when expressly printed and only once for the stopping surface.

## 27. Momentum Resources

A Momentum record includes current points, maximum points, scene ending, normal generation used this round, direct generation, and the event creating each point.

- One event cannot satisfy several normal triggers for several points.
- Direct grants remain the printed amount and can exceed the normal-generation limit but not maximum Momentum.
- Teleportation counts only when the trigger expressly names it.
- A feature spending all Momentum records the amount before resolving damage.
- Recoil or self-created loops excluded by the Source Rule cannot be reduced or converted by Momentum features.

## 28. Threshold Geometry and Crossing

A threshold record identifies endpoints or boundary, height, sides, duration, Source CL, crossing definition, and whether spatial movement is governed.

- Ordinary and forced movement cross a line only by physically passing through its plane.
- Teleportation, phasing, appearing, and boundary placement do not count as ordinary crossing.
- A single continuous movement triggers a crossing Reaction only as often as printed.
- Overlapping thresholds do not multiply cover, difficult terrain, saves, or trigger frequency.
- Cover applies only when the attack line crosses the threshold and the target meets the printed proximity or inside requirement.

## 29. Threshold Anchors

A projected threshold Anchor record states:

1. Position and size.
2. Whether it occupies space.
3. AC and Hit Points.
4. Resistances and Immunities.
5. Cover or boundary effects linked to remaining Anchors.
6. Repair and destruction.
7. Whether damage transfers to the cultivator.
8. Suppression and ending procedure.

An Anchor is not a creature, Companion, Formation, or independent turn unless its Source Rule says so. Destroyed projected Anchors produce no harvestable material.


---

## 30. Integrated Polearms, Sweeps, and Passing Movement

- A turn-only reach increase applies only during the cultivator's turn. A persistent guarded reach applies during the full printed duration and enlarges threatened space.
- A sweeping replacement technique is one activation, not several attacks. It affects each legal target once and does not apply hit-only riders.
- Passing through a hostile creature's space requires the printed permission, counts as difficult terrain, and cannot end in that space.
- A creature does not “enter reach” merely because reach expands around it. Entry requires movement across the reach boundary after the relevant state begins.

## 31. Integrated Bows, Piercing Lines, and Pinning

- Bow integration does not create ammunition, remove weapon hand requirements, or waive long-range Disadvantage unless expressly stated.
- A projectile line resolves from nearest to farthest. Creatures do not stop it unless the feature says so; a surviving solid obstruction does.
- Ignoring Half and Three-Quarters Cover does not ignore total cover or a surviving cultivation-blocking barrier.
- A pinning state must specify voluntary movement, teleportation, granted movement, forced movement, falling, duration, and immunity interactions.
- An area line that is not an attack does not apply ammunition, critical-hit, mastery, or attack-hit riders.

## 32. Venoms, Delayed Conditions, and Toxic Adaptation

- A venom record identifies source, target, Source CL, damage, save, condition, duration, removal, and stacking.
- Delaying a condition is not removing it. If its source expires before delayed onset, the condition never begins; otherwise it begins for the remaining duration.
- A stored adaptation records one use, bonus, eligible next activation, and expiration. Several adaptations refresh rather than stack unless expressly stated.
- Converting Poison Immunity into Resistance and then ignoring that Resistance applies only to the Source Rule that prints the conversion.
- Poison flavor does not create disease, anatomical destruction, soul poison, Foundation damage, or harvestable doses.

## 33. Gate States and Unavoidable Overclock Damage

- A Gate sequence records highest open Gate, every cumulative lower Gate, Stamina paid, scene use, current damage die, and closure condition.
- Gates open in order and cannot be skipped. Increasing the highest Gate opens every intervening Gate and pays each cost.
- Unavoidable Gate damage applies directly to Hit Points and cannot be reduced, prevented, redirected, delayed, shared, absorbed by Temporary Hit Points, or converted into a benefit.
- Becoming Unconscious, dying, scene end, complete Body suppression, or explicit closure closes every Gate. Closed Gates cannot reopen during that scene.
- A Gate-granted attack follows the Granted Attack rule. Gate damage is never qualifying hostile damage.

## 34. Modular Beast Aspects and Chimera States

- Record known Aspects and active Aspects. Duplicate selections are illegal unless expressly permitted.
- At a legal selection time, an unmade choice retains the prior legal selection rather than producing no rules state.
- Each Aspect grants only its printed senses, movement, defense, attack, or functional-size permission.
- Switching an Aspect is prospective and does not retroactively alter an already resolved roll or damage packet.
- A sovereign all-Aspect state must define whether a larger functional-size value replaces or stacks with an Aspect's normal value.

## 35. Celestial Marks, Overflow, and Gravitational States

- A celestial resource record includes current and maximum Marks, scene ending, initiative grant, once-per-round generation, and overflow choices.
- A Stamina activation generates at most one Mark after it resolves. Spending more Stamina or affecting more targets does not create more Marks.
- At maximum, each legal overflow event grants one listed benefit. If each option is limited once per round, several different options can be gained from separate events.
- Falling-star movement is physical movement through a legal route unless explicitly called teleportation.
- A gravitational protection must identify which physical movement categories it blocks and must not silently block teleportation or spatial displacement.

## 36. Body Beats, Internal Echoes, and Counter-Resonance

- A Body Beat record includes current and maximum Beats, the once-per-round gain flag, qualifying event, and scene ending.
- A delayed internal echo records exactly which first event detonates it and whether detonation occurs before or after the triggering action's effects.
- One event can detonate one Echo only once even when it satisfies several trigger categories.
- A counter-resonance reduction protects one creature and one packet unless expressly expanded. Its burst occurs only if final triggering damage becomes 0.
- Temporary flight suppression causes falling only when no permanent anatomy, support, or unsuppressed flight remains.
- Vibration and Thunder flavor do not automatically deafen, shatter organs, create Injuries, or destroy every object.


---

## 37. Chain Tethers, Rotation, and Prison Anchors

- A Tether record identifies source, target, Source CL, maximum distance, direction-sense range, duration, maintained-limit slot, and every removal condition.
- A Tether is not automatically Grappled or Restrained. It limits only the movement and spatial operations printed by its source.
- Hostile forced movement can exceed a willing-movement boundary unless the Tether expressly contests it. End-of-turn break distance is checked only at its printed timing.
- Rotation around a source must state route length, permitted final radius, legal-space requirements, and collision handling.
- A prison Tether anchored to a Field center is separate from personal Tethers unless the source says otherwise.
- A persistent prison must profile its center Anchor, entry behavior, repeat saves, ally exemptions, and ending conditions.

## 38. Organ Furnace Modes and Purification

- Record active Furnaces and each named once-per-turn use. Deactivating and reactivating a Furnace does not reset a use spent during that turn.
- A Stamina-spending activation creates one trigger regardless of Stamina amount. A 0-Stamina activation does not count as spending Stamina.
- A purification feature must identify the exact condition, source DC, success result, failure result, success tracking, and excluded authority tags.
- Suppression is not removal. An effect's duration continues while its penalties are suppressed unless the source says otherwise.
- Healing overflow becomes Temporary Hit Points only after actual missing Hit Points are restored and uses the printed cap.

## 39. Draw Postures, Replacement Lines, and Execution Routes

- A first-attack condition checks whether any attack roll was made earlier in the same turn, not whether an earlier attack hit.
- A posture entered before movement must define voluntary movement, teleportation, forced movement, attack resolution, and missed-attack behavior.
- Replacing two attacks requires two attacks still available in the same Attack action.
- A save-based draw line is one technique, not a weapon attack, and does not apply critical hits or hit-only riders.
- A high-speed execution route resolves selected creatures and blocking barriers in nearest-to-farthest order and must define where movement ends if a barrier survives.

## 40. Tempering Forms and Reforged Anatomy

- Record active Forms and their turn- or round-based limits. A Form change is prospective and does not retroactively alter an earlier event.
- A damage-triggered Quench declares before Hit Points are reduced so a printed reduction can affect the triggering packet.
- A missing weapon-integration reference must be repaired with the narrowest explicit record necessary to execute the source, without changing printed damage or action values.
- Replacing a limb-destruction result with damage applies only to reconstructable anatomy and only to the anatomical consequence expressly replaced.
- Separate once-per-turn Form riders can coexist when their source grants them independently; identical AC reductions refresh rather than stack.

## 41. Thunder Charges and Conductive Impact

- A Charge record includes current and maximum Charges, normal gain flag, qualifying event, direct exceptional gain, spending timing, and scene expiration.
- “Can exceed the normal gain limit” bypasses the per-round generation limit, not the maximum, unless expressly stated otherwise.
- A temporary defense can be ended only when its record identifies it as a persistent barrier, ward, stance, or equivalent defensive source and its Source CL is legal.
- Physical thunderbolt movement is not teleportation. It must record route, barriers, occupied spaces, final position, and area origin.
- Area impact against objects must identify whether damage is doubled before or after ordinary modifiers and cannot silently target world-scale terrain.

## 42. Coil States, Upkeep, and Constriction

- A Coil record uses one highest-open value; all lower Coils are cumulative and cannot be skipped.
- End-of-turn self-damage resolves before the printed Coil upkeep when upkeep is stated to occur after all other end-of-turn effects.
- A higher upkeep replaces a lower threshold upkeep rather than adding to it unless expressly stated.
- Functional size for Grappling uses the highest applicable value rather than stacking several “counts as larger” clauses.
- A pursuit Reaction must identify whether the trigger checks the creature before or after movement and whether the response is movement or teleportation.
- Unavoidable Coil damage cannot produce resources or be converted into a benefit.

## 43. Battle Hands, Weapon Forms, and Intercept Timing

- A Battle Hand record includes current maximum, current Hands, turn spending total, refresh timing, and round-limited Reaction uses.
- Battle Hands are abstract coordination, not literal limbs or permission to hold additional equipment.
- Every attack uses one recorded Weapon Form. Same-Form weapon changes do not satisfy different-Form sequences.
- A reactive intercept occurs before the triggering roll, movement, or forced save and changes only the part expressly modified.
- A granted counterattack does not automatically cancel a committed feature; cancelation requires an illegal target, a miss, movement reduced to 0, or another printed failure.
- A four-Hand threshold is cumulative spending during the turn unless its source says one payment must spend four at once.
- An additional Reaction restricted to one feature cannot be spent on another Reaction feature.
## 44. Rebirth Embers and Zero-Hit-Point Rebirth

- A Rebirth resource record includes current and maximum Embers, the shared once-per-round gain flag, qualifying event, and scene expiration.
- A failed save creating several eligible conditions grants one Ember. A damage packet containing several qualifying portions grants one Ember.
- A 0-Hit-Point replacement declares after final damage is known but before the 0-Hit-Point state begins. Only one replacement can resolve against an event.
- Replacement healing, condition ending, burst damage, forced movement, and granted movement resolve in the printed order.
- Fire-hazard generation must identify the pre-Immunity Fire amount and a genuine active hazard; decorative or self-maintained harmless flame cannot be farmed.

## 45. Damage and Affliction Adaptations

- Every Adaptation records type or condition, originating source, Source CL, acquisition round, maintained slot, and scene expiration.
- A new record exceeding capacity replaces one record of the same category or is declined. Duplicate types do not stack.
- Packet-only Resistance applies at the normal percentage step; flat Adaptation reduction applies afterward.
- A repeated save against an adapted condition uses the original ability and DC and ends only the condition unless its source links further effects.
- Immediate counter-evolution declares before damage or failure consequences are finalized and cannot combine two Reaction costs in one Reaction.

## 46. Sovereign Mass, Remembrance, and Protective Interception

- Functional size changes only the listed operations. Actual size changes use transformation, occupied-space, Squeezing, and equipment procedures.
- A charge route must continuously approach its target for the required distance and records the once-per-turn rider.
- Protective interception declares after a hit but before damage. Movement, target replacement, retroactive cover, and damage reduction are distinct options and follow their own legality checks.
- A remembered-creature record grants only printed direction, visibility, rider, and resistance benefits; it is not omniscience or a permanent mark.
- Trampling movement resolves entered creatures nearest to farthest and must place every creature in a legal space outside the route.

## 47. Multi-Eye States, Appraisal, and Perception Authority

- An Open-Eye record includes current and maximum Eyes, cumulative threshold benefits, start-of-turn choice, and backlash lockout.
- Additional eyes are integrated anatomy, not separate Assets, actions, attacks, or independently targetable creatures.
- Appraisal records only the statistics and bands printed by its source. Ties are revealed as ties; exact hidden data is not inferred beyond the feature.
- Truesight, Blindsight, anti-Invisibility, and anti-Advantage clauses do not automatically defeat superior Secret, artifact, divine, or Immortal concealment.
- A predictive Reaction identifies whether it occurs before movement, attack resolution, or save resolution and cannot cancel a committed activation unless its result makes that activation illegal.

## 48. Devoured Essence, Consumption, and Protection Suppression

- Every Essence records one damage type, source, Source CL, gain round, and scene expiration. Essence is not transferable and carries no full technique authority.
- A consumption reduction affects only named valid damage portions in one packet or one persistent-zone instance.
- Riders are prevented only when their text requires damage to have been dealt; hit-, failure-, presence-, and activation-based riders remain.
- Temporary protection suppression makes one recorded benefit dormant for the printed duration. Ending a protection terminates that temporary effect but not its permanent source.
- Unavoidable undigested backlash applies directly to Hit Points and cannot be converted, delayed, redirected, or farmed.

## 49. Demon Spines, Bleeding, and Impalement Fields

- A Spine record includes current and maximum Spines, normal gain flag, direct gain, reach threshold, healing threshold, and scene expiration.
- Bleeding records one source, damage type, movement/attack trigger, duration, and ending condition. It is not automatically an Injury.
- Entry or movement within reach identifies the exact qualifying space before resolving damage and movement stopping.
- A projected impalement Field must state center, radius, movement with source, save frequency, restraint escape, difficult terrain, lift/fall behavior, duration, and suppression.
- Reach increases use the highest applicable replacement unless the feature expressly says they stack.

## 50. Brood, Infestation, Swarm-Shells, and Swarm Bodies

- A Brood record includes current and maximum Brood, normal gain flag, direct gain, scene expiration, and healing-use timing.
- An Infestation records source, Source CL, save DC, damage type, first qualifying trigger, expiration, and maintained slot.
- Spending points, taking Dash, willing movement, healing, and Temporary Hit Points commit before Gnawing damage; the printed prohibition applies afterward.
- A Swarm-Shell is a stationary projected Body Asset with no actions unless expressly granted. Destroying it does not injure the source.
- A swarm-body transformation must define equipment, openings, legal ending spaces, Grapple/Restrained exceptions, 0-Hit-Point recovery, and whether a cone or tide creates any persistent creatures or terrain.
