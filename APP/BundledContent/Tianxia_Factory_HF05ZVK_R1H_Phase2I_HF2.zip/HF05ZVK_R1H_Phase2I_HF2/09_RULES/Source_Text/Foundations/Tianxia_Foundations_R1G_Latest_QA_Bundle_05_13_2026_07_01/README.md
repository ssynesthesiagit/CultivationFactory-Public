# Tianxia Foundations R1G Latest QA Bundle — 05–13

Purpose: give a QA chat the latest finished/audited Foundation rewrite packages worked in this lane, starting at Heavenly Body and ending at Iron Oath Skin.

## Scope

- Included: Foundations 05–13 latest available audited/clean packages.
- Excluded by request: Foundation 14 Moonlit Yin Vein work, including the latest CP-terminology patch.

## Current CP terminology reminder

- CP = Cultivation Points.
- Body Refining CP is Stamina.
- Qi Cultivation CP is Qi.
- Spirit Awakening CP is Resonance.
- Future rewrites should use `CP` / `Cultivation Points`, not generic `Path resource` wording.

## Included packages

- 05 Heavenly Body — `Tianxia_Foundations_R1G_Rewrite_Chunk_05F_Heavenly_Body_v0_2F_LINEAGE_POLICY_CLEAN(1).zip` — SHA-256 `23925935bd6ff6953e061ed5d5eb60df32938c0d48f37ed967fd420487b615c9` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_05
- 06 True Blackblood Physique — `Tianxia_Foundations_R1G_Rewrite_Chunk_06C_True_Blackblood_Physique_v0_2C_LINEAGE_POLICY_CLEAN(1).zip` — SHA-256 `d6742449a5a83d3848950f099fa3bb1730b8f7ea3620c02c3559428f1e5e74e3` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_06
- 07 Sword Bones — `Tianxia_Foundations_R1G_Rewrite_Chunk_07B_Sword_Bones_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `e66a6c3eba6948527587b236611a12450f6c06d685fc036a53d7ac1036eeac65` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_07
- 08 Karma Knot Root — `Tianxia_Foundations_R1G_Rewrite_Chunk_08B_Karma_Knot_Root_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `01117e3686069b3c3f7a5d306f04cde30661343a7f429a85ad841ae4d62948ca` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_08
- 09 Weak Reed Tendons — `Tianxia_Foundations_R1G_Rewrite_Chunk_09B_Weak_Reed_Tendons_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `aa6c5228b1a3911e9db44f764c3aeab1e16f37531cd9f22be29104ab4920b58f` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_09
- 10 Furnace Heart Record — `Tianxia_Foundations_R1G_Rewrite_Chunk_10B_Furnace_Heart_Record_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `3b135c2b9d8366f33fdaba74a9eaabec2ba29be88799c3c538f5e25a223470a6` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_10
- 11 Dream-Mirror Soul Anchor — `Tianxia_Foundations_R1G_Rewrite_Chunk_11B_Dream_Mirror_Soul_Anchor_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `fa508c1dac0c7ba8fce9983a088b152ed28e64b7fe9722ccbfa69658ada81123` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_11
- 12 Star-Sovereign Core Imprint — `Tianxia_Foundations_R1G_Rewrite_Chunk_12B_Star_Sovereign_Core_Imprint_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `487668ba48603af113d63886268a634c08a69fd2956d146aa2bd92ff4cfac6bd` — integrity `None` — AUDITED_CLEAN_BY_USER_WITH_KNOWN_VERDICT_LABEL_MISMATCH
- 13 Iron Oath Skin — `Tianxia_Foundations_R1G_Rewrite_Chunk_13B_Iron_Oath_Skin_v0_2B_GMSCREEN_POLICY_CLEAN(1).zip` — SHA-256 `e6c2a97bcd16d7038156570b750f63c1f96a6ff3059f01eff49fd3b9d78899aa` — integrity `None` — PASS_CANON_CLEAN_BASELINE_FOR_FOUNDATION_13

## QA watch items

- Confirm each inner package still opens with `zipfile.testzip() is None`.
- Confirm runtime/catalog/registry status surfaces are `Stable` where applicable.
- Confirm GM Screen rows have visible `damage_or_effect` / `effect_summary`.
- Confirm lineage rows do not leak into GM Screen combat action rows.
- Foundation 12 may need a metadata-only verdict-label normalization if QA confirms the label mismatch persists.
