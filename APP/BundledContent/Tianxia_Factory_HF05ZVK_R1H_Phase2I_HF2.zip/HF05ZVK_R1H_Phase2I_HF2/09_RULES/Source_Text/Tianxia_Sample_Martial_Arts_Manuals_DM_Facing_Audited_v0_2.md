# Tianxia Sample Martial Arts Manuals - DM-Facing Audited Draft v0.2

## Purpose

This draft provides sample martial arts manuals for use as sect treasure, jade tablet fragments, rival-school inheritances, training rewards, NPC styles, ruin discoveries, or doctrine seeds.

Each technique follows the Martial Arts Manual structure:

**Sphere of [Sphere] — [Technique Name] — [Reproduced Ability / Talent Package] — DC [Number]**

A character who learns one of these techniques learns only that fixed expression. They do not gain the listed sphere, the listed talent, a general package, or permission to modify the technique unless they later learn the sphere and required talents normally.

## Audit Status

This v0.2 pass removes the loose placeholder package names from the earlier sample page. Entries now use one of the following:

- a named base ability, such as Active Defense, Interpose, Second Silhouette, Shadow Step, Sword Intent Strike, Sword Qi Wave, Precision Contact, or Read the Spirit Nature;
- a named talent, such as Numbing Point, Reading Touch, Pinning Strike, Spear Guard, Flowing Water Slash, Sword Drawing Stance, Venomous Strike, River-Step Footwork, or Minor Spirit Agreements;
- a clear sphere package term that the sphere itself uses, such as Point talent, Seal talent, Deflect talent, Patrol Zone talent, Spirit Nature Expression, or Manhandle talent.

The following cleanup changes were made from the prior sample list:

- replaced generic **Technique** package labels with actual base abilities, talents, or package terms;
- replaced unverified **Trip** language with Wrestling Slam, Pin, Capture, or Spear Pinning Strike;
- replaced vague Guardian **Intercept** language with Interpose, Patrol Practice, Patrol Zone talents, or Bodyguard;
- removed ambiguous **Fear / Dark** syntax;
- removed restricted Stars examples from the clean sample list;
- marked Foundation techniques at DC 22 or higher;
- kept all entries as fixed manual techniques rather than new free-form forged techniques.

## DM Adjudication Reminder

These manuals are examples. If a listed package is later renamed in the final sphere document, rename the manual entry to match the final sphere text before publishing.

Most manuals should contain three to seven techniques. Larger manuals may be split into Mortal Chapter, Foundation Chapter, and higher chapters. A character cannot learn a Foundation technique before reaching Foundation Realm, even if they beat the DC.

A technique that combines multiple spheres, reproduces a Foundation talent, provides strong control, or grants unusual action efficiency should usually start at DC 22 or higher.

# Sample Martial Arts Manuals

## Iron Bridge Ox-Shoulder Manual

**DM Use:** A sturdy village, military, or Body Refining manual for grapplers, guards, and front-line disciples.

**Sphere of Athletics — Bridge-Crossing Step — Tumble — DC 14**

**Sphere of Brute — Ox-Shoulder Crash — Brutal Shove — DC 16**

**Sphere of Brute — Broken-Door Shove — Manhandle, Takedown — DC 20**

**Sphere of Wrestling — Root-Seizing Clinch — Grapple, Hold — DC 18**

**Sphere of Wrestling — Iron Bridge Pin — Pin, Capture — DC 20**

**Sphere of Guardian — Body-Between-Gates Guard — Interpose — DC 18**

**Sphere of Brute and Wrestling — Ox Breaks the Bridge — Manhandle, Takedown, Hold — Foundation Technique — DC 22**

## White Crane Crossing Water Manual

**DM Use:** A graceful evasive style for scouts, duelists, dancers, light-body cultivators, and soft-style Body Refiners.

**Sphere of Athletics — Reed-Step Balance — Tumble — DC 14**

**Sphere of Athletics — Crane Takes the Rafter — Rope Swing — DC 16**

**Sphere of Flowing River — Sleeve-Turning Defense — Flowing Stance — DC 16**

**Sphere of Flowing River — Crane Skims the Pond — River-Step Footwork — DC 18**

**Sphere of Flowing River — White Wing Redirection — Redirecting Palm — DC 20**

**Sphere of Shield — Feather Guard — Active Defense — DC 18**

**Sphere of Athletics and Flowing River — Water-Crossing Crane Step — Tumble, River-Step Footwork — Foundation Technique — DC 22**

## Black Tiger Gate-Breaking Manual

**DM Use:** An aggressive sect, arena, frontier, or bandit-school manual for direct pressure fighters.

**Sphere of Berserker — Tiger Enters the Courtyard — Adrenaline — DC 16**

**Sphere of Brute — Black Claw Impact — Brutal Shove — DC 16**

**Sphere of Brute — Gate-Splitting Shoulder — Manhandle, Takedown — DC 20**

**Sphere of Iron Fist — Tiger Fang Strike — Unarmed Strike, Opening — DC 18**

**Sphere of Pressure Points — Hip-Gate Claw — Precision Contact, Numbing Point — DC 20**

**Sphere of Berserker and Brute — Black Tiger Breaks the Gate — Adrenaline, Manhandle, Takedown — Foundation Technique — DC 22**

## Seven Coils Prison-Yard Manual

**DM Use:** A restraint manual for prison guards, bounty hunters, sect enforcers, caravan guards, and capture-focused NPCs.

**Sphere of Wrestling — First Coil Clinch — Grapple, Hold — DC 16**

**Sphere of Wrestling — Elbow-Locking Coil — Hold, Slam — DC 18**

**Sphere of Wrestling — Seven-Coil Pin — Pin — DC 20**

**Sphere of Wrestling — Bound Prisoner Method — Capture — DC 20**

**Sphere of Guardian — No-Escape Yard Step — Patrol Practice — DC 18**

**Sphere of Guardian — Iron Line of Guards — Steel Hedge — DC 20**

**Sphere of Wrestling and Guardian — Seven Coils Close the Court — Pin, Capture, Patrol Zone — Foundation Technique — DC 22**

## Drunken Moon Beggar Manual

**DM Use:** A chaotic street or wandering-master manual. Good for tricksters, tavern fighters, loose cultivators, and NPCs who look harmless until the second exchange.

**Sphere of Drunken Style — Wine-Cup Sway — Swaying Guard — DC 16**

**Sphere of Drunken Style — Crooked Step Refuses the Line — Reeling Step — DC 16**

**Sphere of Drunken Style — Laughing False Opening — Broken-Rhythm Strike — DC 18**

**Sphere of Drunken Style — Loose-Cup Footwork — Loose-Cup Footwork — DC 18**

**Sphere of Monkey Style — Stumbling Monkey Turn — Capering Footwork — DC 18**

**Sphere of Drunken Style — Moon-in-the-Cup Mockery — Laughing Feint — DC 20**

**Sphere of Drunken Style and Monkey Style — Beggar Steals the Moon — Reeling Step, Capering Footwork, Laughing Feint — Foundation Technique — DC 22**

## Jade Needle Quiet-Hand Manual

**DM Use:** A precise and dangerous manual for physicians, assassins, pressure-point adepts, hidden sects, and soft-handed duelists.

**Sphere of Pressure Points — Quiet Pulse Reading — Precision Contact, Reading Touch — DC 16**

**Sphere of Pressure Points — Sleeping Meridian Touch — Precision Contact, Numbing Point — DC 18**

**Sphere of Pressure Points — Close the Shallow Gate — Touch the Point, Point Talent — DC 18**

**Sphere of the Piercing Needle — Needle-Point Feint — Feint — DC 18**

**Sphere of the Piercing Needle — Returning Needle Step — Footwork, Returning Point — DC 20**

**Sphere of the Piercing Needle — Needle-Catching Sleeve — Parry and Riposte, Needle-Catching Reversal — Foundation Technique — DC 22**

**Sphere of Pressure Points and the Piercing Needle — Quiet Hand Seals the Breath — Precision Contact, Point Talent, Feint — Foundation Technique — DC 22**

## Storm Drum Spear Manual

**DM Use:** A military spear manual for battlefield disciples, sect guards, militia captains, and storm-themed martial artists.

**Sphere of Spear — Thunder Line Thrust — Spear Thrust — DC 16**

**Sphere of Spear — Spear-Wall Warning — Intercepting Thrust — DC 18**

**Sphere of Spear — Shaft Turns the Gate — Shaft Reversal — DC 18**

**Sphere of Spear — Drumbeat Root — Rooted Spear Stance — DC 18**

**Sphere of Spear — Point Holds the Road — Pinning Strike — DC 20**

**Sphere of Guardian — Guard the Standard Line — Patrol Practice — DC 18**

**Sphere of Spear and Guardian — Storm Drum Holds the Gate — Intercepting Thrust, Patrol Practice — Foundation Technique — DC 22**

## Red Lantern Ghost-Step Manual

**DM Use:** A Spirit Awakening or exorcist-leaning manual. Excellent for haunted roads, funeral sects, ghost markets, and spirit-companion users.

**Sphere of Shadow — Red-Lit Second Self — Second Silhouette — DC 18**

**Sphere of Shadow — Lantern Shadow Step — Shadow Step — DC 18**

**Sphere of Shadow — Black Wick Bite — Shadow Fang — DC 18**

**Sphere of Spirit Companions — Ask the Roadside Dead — Read the Spirit Nature — DC 16**

**Sphere of Spirit Companions — Lantern Guide Agreement — Minor Spirit Agreements — DC 18**

**Sphere of Spirit Companions — Recall the Funeral Moth — Spirit Recall — DC 18**

**Sphere of Shadow and Spirit Companions — Red Lantern Leads the Dead — Shadow Step, Minor Spirit Agreement — Foundation Technique — DC 22**

## Golden Bell Rooted Mountain Manual

**DM Use:** A defensive Body Refining or temple warden manual for durable front-line characters.

**Sphere of Shield — Bell-Cover Guard — Active Defense — DC 16**

**Sphere of Shield — Raised Face of the Bell — Shield Face — DC 18**

**Sphere of Guardian — Temple Gate Interpose — Interpose — DC 18**

**Sphere of Guardian — Bell Courtyard Formation — Assist the Line — DC 20**

**Sphere of Guardian — Stone Gate Passage — Clear Path — DC 20**

**Sphere of Force — Hammer-Answering Breath — Counterpressure — DC 20**

**Sphere of Shield and Guardian — Golden Bell Answers the Hammer — Active Defense, Interpose, Assist the Line — Foundation Technique — DC 22**

## Green Serpent Coil Manual

**DM Use:** A venomous mobility and restraint manual used by poison sects, swamp cultivators, assassins, and serpent-blooded Body Refiners.

**Sphere of Flowing River — Serpent Belly Slide — River-Step Footwork — DC 16**

**Sphere of Wrestling — Coiling Arm Hold — Grapple, Hold — DC 18**

**Sphere of Poison — Green Fang Touch — Deliver the Dose — DC 18**

**Sphere of Poison — Venomous Bite Follow-Up — Venomous Strike — DC 20**

**Sphere of Poison — Numbing Fang Method — Numbing Venom — DC 20**

**Sphere of Pressure Points — Venom-Gate Finger — Precision Contact, Numbing Point — DC 20**

**Sphere of Poison and Wrestling — Green Serpent Locks the Heart — Hold, Deliver the Dose, Venomous Strike — Foundation Technique — DC 22**

## River Staff of the Laughing Sage Manual

**DM Use:** A mobile staff and redirection manual for wandering masters, river schools, monkey-style disciples, and comedic but dangerous NPCs.

**Sphere of Flowing River — Third Foot in the Current — Flowing Stance — DC 16**

**Sphere of Flowing River — Borrow the Enemy's Step — Borrowed Momentum — DC 18**

**Sphere of Flowing River — Pass Around the Blade — Flow Around the Blade — DC 20**

**Sphere of Monkey Style — Laughing Grip on the Staff — Monkey Grip — DC 16**

**Sphere of Monkey Style — Vaulting Laugh — Vaulting Strike — DC 18**

**Sphere of Monkey Style — Staff of the Laughing Sage — Staff of the Laughing Sage — DC 20**

**Sphere of Flowing River and Monkey Style — Tripod Turns the Moon — Borrowed Momentum, Vaulting Strike, Monkey Grip — Foundation Technique — DC 22**

## Mirror-Sword Shadow Fragment

**DM Use:** A partial jade tablet rather than a full sect school. Good for duelists, assassins, reincarnated sword cultivators, or shadow-stepping sword users. It is intentionally narrow.

**Sphere of Sword — Mirror-Line First Cut — Sword Intent Strike — DC 16**

**Sphere of Sword — Still Water Draw — Sword Drawing Stance — DC 18**

**Sphere of Sword — Edge Turns Beside the Face — Flowing Water Slash — DC 18**

**Sphere of Shadow — Reflected Second Silhouette — Second Silhouette — DC 18**

**Sphere of Shadow — Step Behind the Reflection — Shadow Step — DC 20**

**Sphere of Sword — Heart Reflected in Steel — Heart of the Sword — Foundation Technique — DC 22**

**Sphere of Sword and Shadow — Second-Silhouette Blade — Sword Intent Strike, Shadow Step — Foundation Technique — DC 22**

## Shrine Fox Companion Steps

**DM Use:** A Spirit Companion manual for shrine disciples, fox-spirit lineages, spirit mediums, and soft-social investigators.

**Sphere of Spirit Companions — Bow Before the Little Shrine — Read the Spirit Nature — DC 14**

**Sphere of Spirit Companions — Fox Lantern Courtesy — Spirit Speech — DC 16**

**Sphere of Spirit Companions — One Tail Promise — Covenant Spirit — DC 18**

**Sphere of Spirit Companions — Hidden Cup Offering — Gentle Offering Method — DC 18**

**Sphere of Spirit Companions — Fox in the Sleeve — Host the Small God — DC 20**

**Sphere of Shadow — Tail in the Lamplight — Second Silhouette — DC 18**

**Sphere of Spirit Companions and Shadow — Fox Steps Through the Offering Smoke — Host the Small God, Shadow Step — Foundation Technique — DC 22**

## Hundred-Step Rope Courtyard Manual

**DM Use:** A pure movement manual for scouts, messengers, rooftop runners, ruin delvers, and sect couriers.

**Sphere of Athletics — Alley-Corner Tumble — Tumble — DC 14**

**Sphere of Athletics — Red Cord Crossing — Rope Swing — DC 16**

**Sphere of Athletics — Wall-Lotus Step — Wall Stunt — DC 18**

**Sphere of Athletics — Giant's Shoulder Road — Scale Foe — DC 18**

**Sphere of Athletics — Messenger Relay Pattern — Coordinated Movement — DC 18**

**Sphere of Athletics — Ten-Thousand-Step Passage — Tumble, Rope Swing, Wall Stunt — Foundation Technique — DC 22**

## Temple Shield Warden Manual

**DM Use:** A shield-and-escort manual for bodyguards, sect escorts, caravan defenders, and shrine wardens.

**Sphere of Shield — First Face Toward Danger — Active Defense — DC 16**

**Sphere of Shield — Catch the Raised Blade — Catch Blade — DC 18**

**Sphere of Guardian — Step Before the Disciple — Interpose — DC 18**

**Sphere of Guardian — Escort Through the Yard — Clear Path — DC 20**

**Sphere of Guardian — Shield the Companion — Shield Companion — DC 20**

**Sphere of Guardian — Warden's Fast Answer — Swift Guardian — DC 20**

**Sphere of Shield and Guardian — Temple Shield Takes the Calamity — Active Defense, Interpose, Shield Companion — Foundation Technique — DC 22**

## Dream-River Exorcist Manual

**DM Use:** A Spirit Awakening manual for gentle exorcists, nightmare doctors, spirit investigators, and dream-walking disciples.

**Sphere of Dreams — First Dream Seed — Dream Seed — DC 16**

**Sphere of Dreams — Needle Through Sleep — Dream Needle — DC 18**

**Sphere of Dreams — Little Dream Court — Dreamscape — DC 20**

**Sphere of Spirit Companions — Ask the Haunting What It Wants — Read the Spirit Nature — DC 16**

**Sphere of Spirit Companions — Restless Dead Agreement — Temporary Scene Bond — DC 18**

**Sphere of Spirit Companions — Shared Lantern Senses — Shared Senses — DC 18**

**Sphere of Dreams and Spirit Companions — Dream-River Guides the Restless — Dreamscape, Minor Spirit Agreement — Foundation Technique — DC 22**

## Sword-Bone Courtyard Manual

**DM Use:** A Body Refining sword-body manual for characters who treat the blade as a bone, stance, or internal decision rather than just a weapon.

**Sphere of Sword — First Bone Cut — Sword Intent Strike — DC 16**

**Sphere of Sword — Still-Bone Draw — Sword Drawing Stance — DC 18**

**Sphere of Iron Fist — Empty-Hand Guard Break — Unarmed Strike, Opening — DC 18**

**Sphere of Pressure Points — Wrist-Gate Touch — Precision Contact, Numbing Point — DC 20**

**Sphere of Sword — Edge Against Edge — Edge Against Edge — DC 20**

**Sphere of Sword — Cut the Moving Meridian — Meridian-Cutting Strike — Foundation Technique — DC 22**

**Sphere of Sword and Iron Fist — Sword Bone Opens the Gate — Sword Intent Strike, Opening — Foundation Technique — DC 22**

# Final Audit Notes

## Clean Entries

The sample manuals now follow the Martial Arts Manual structure and avoid broad free-form grants. Each line provides a sphere, a technique name, a reproduced package, and a DC.

The reproduced packages are either named sphere base abilities, named talents, or sphere-recognized package terms. They are not intended to create new general-purpose talents.

## Realm Gate Check

All listed Foundation techniques are DC 22 or higher and explicitly marked **Foundation Technique**. They should not be learnable by Mortal Realm characters.

## Abuse Check

No entry says the learner gains the source sphere. No entry grants permission to add unrelated talents, metasphere effects, forged-technique modifications, or custom upgrades. The DM should still enforce the fixed-technique rule from the Martial Arts chapter.

## Remaining Human Review Items

Before treating this as final canon, review the entries that use spheres still in working-draft status, especially Drunken Style, Monkey Style, the Piercing Needle, and Spirit Companions. The structure is valid, but final sphere naming may change before publication.

If a sphere renames a talent later, update only that manual line's reproduced package name. The martial art concept can remain intact.
