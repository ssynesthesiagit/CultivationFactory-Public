# Tianxia AI Character Generation Bootstrap Rules Reference v0.1

**Document type:** AI-facing character generation bootstrap reference.  
**Generated:** 2026-07-07T17:22:22.219119+00:00  
**Rules authority:** Tianxia Core Rules Reference v0.3.  
**Procedure support:** AI-Facing Tianxia Pure Mechanics Core v0.3.  
**Use target:** character factory, character package generation, GM Screen export preparation, validation gates, AI-assisted NPC/PC cultivator construction.  
**Scope:** legal generation of usable Tianxia cultivator characters at a requested CL, starting with a chosen Path, Background/Origin records, point buy, Sphere/Talent accounting, and factory export expectations.

---

## 1. Purpose

This document is the front-line reference for AI-generated Tianxia character packages.

It is not the player-facing Level 0 creation chapter.  
It is not a sect-trial scene procedure.  
It is not a campaign discovery workflow.  
It is not a replacement for Core v0.3, the PHB, the Foundation catalog, the Method catalog, the Sphere catalog, or the character factory.

Use this document when an AI or factory process must generate a legal cultivator package at a requested Cultivation Level.

Core execution principle:

```text
AI-generated characters start with a chosen Path and are built directly as usable cultivators.
```

---

## 2. Explicit Scope Boundary

The character generation bootstrap does not run the player-start procedure.

Do not include these as required AI generation steps:

```yaml
out_of_scope_for_AI_character_generation:
  - Level_0_pathless_player_creation
  - sect_trial_scene_resolution
  - player_discovery_flow
  - trial_generated_Path_selection
  - pre_Path_character_state
```

Those are player-facing campaign procedures.

AI character generation should instead begin with:

```yaml
AI_character_generation_start:
  requested_CL: integer
  chosen_Path: Body_Refining | Qi_Cultivation | Spirit_Awakening
  concept_or_source_inspiration: string
  Background: string
  Origin_or_Origin_Insight: null_or_record
  build_role: string
```

---

## 3. Authority and Load Order

Use this load order.

```yaml
character_generation_load_order:
  1: Tianxia_AI_Character_Generation_Bootstrap_Rules_Reference_v0_1
  2: Tianxia_Core_Rules_Reference_v0_3
  3: AI_Facing_Tianxia_Pure_Mechanics_Core_v0_3
  4: Tianxia_PHB_v0_3_current_player_facing_reference
  5: Current_Character_Factory_baseline
  6: Current_factory_hotfix_gates
  7: Sphere_catalog
  8: Foundation_catalog_if_CL_supports_Foundation
  9: Method_catalog_if_Method_is_used
  10: GM_Screen_import_and_action_schema_expectations
```

If this document conflicts with Core v0.3, Core v0.3 controls.

If the factory template conflicts with current rules, preserve package structure but repair the generated character record to current rules.

---

## 4. Generation Flow

Use this flow for AI-generated characters.

```yaml
AI_character_generation_flow:
  - define_requested_CL
  - define_character_concept
  - choose_Path
  - assign_Human_baseline_unless_source_expansion_says_otherwise
  - assign_27_point_buy
  - assign_Background
  - assign_Background_equipment
  - assign_Background_Sphere_and_Background_Talent_or_compensation
  - assign_Origin_or_Origin_Insight_if_used
  - assign_CL1_free_Sphere_and_talent
  - assign_later_level_talents_by_CL
  - assign_trained_choices_by_CL_if_build_requires_training_history
  - assign_manual_or_lineage_source
  - assign_Recorded_Arts_if_legal
  - assign_Method_if_legal
  - assign_Foundation_if_CL_and_source_support_it
  - assign_Forged_Techniques_if_CL_and_source_support_them
  - assign_equipment_items_and_source_records
  - calculate_HP_AC_PB_CP
  - create_combat_action_packets
  - create_GM_Screen_import_surfaces
  - run_validation_checklist
  - produce_final_package
```

The generation flow is a construction procedure. It does not simulate every training day unless the requested output requires a detailed advancement history.

---

## 5. Required Character Core

Every generated character needs a core record.

```yaml
character_core:
  character_id: string
  name: string
  requested_CL: integer
  Realm: string
  Path: Body_Refining | Qi_Cultivation | Spirit_Awakening
  species: Human
  Background: string
  Origin_or_Origin_Insight: null_or_record
  concept_summary: string
  build_role: string
  rules_authority: Tianxia_Core_Rules_Reference_v0_3
```

### 5.1 Path Required

Generated characters must have a Path.

```yaml
Path_required_for_AI_generation: true
```

Do not create a pathless Level 0 build for AI-generated factory packages unless the user explicitly requests a Level 0 player-facing character.

---

## 6. Ability Scores and Point Buy

Use 27-point buy unless a specific generation request or Source Rule says otherwise.

```yaml
ability_score_generation:
  method: 27_point_buy
  maximum_before_background_or_source_modifiers: normal_point_buy_limit
  validation_required: true
```

The package should include a point-buy ledger.

```yaml
point_buy_ledger:
  STR: integer
  DEX: integer
  CON: integer
  INT: integer
  WIS: integer
  CHA: integer
  points_spent: integer
  legal: boolean
  notes: []
```

### 6.1 Saving Throw Proficiencies

Do not invent saving throw proficiencies.

```yaml
saving_throw_proficiency_rule:
  default_saving_throw_proficiencies: []
  granted_only_by: explicit_Source_Rule
  validation_required: true
```

If a character has saving throw proficiency, cite the exact source.

---

## 7. Path Chassis

Use the selected Path chassis.

```yaml
Paths:
  Body_Refining:
    key_ability: CON
    hit_die: d12
    CP_type: Stamina
  Qi_Cultivation:
    key_ability: INT_or_CHA
    hit_die: d8
    CP_type: Qi
  Spirit_Awakening:
    key_ability: WIS
    hit_die: d8
    CP_type: Resonance
```

### 7.1 Maximum CP

Use the current formula.

```yaml
Maximum_CP: CL * Path_key_ability_modifier
```

Do not use the old `+ CL` formula.

### 7.2 Proficiency Bonus

Use the proficiency bonus appropriate to the character’s CL under the current Tianxia/D&D progression.

```yaml
PB:
  source: current_CL_progression
  validation_required: true
```

---

## 8. Background Integration

Backgrounds are required unless the character concept explicitly uses a special source.

```yaml
background_record:
  name: string
  equipment: []
  Background_Sphere: null_or_string
  Background_Talent: null_or_string
  compensation_if_no_Sphere_or_talent: null_or_record
  source: string
  notes: []
```

### 8.1 Background Grants

A normal Background grants:

```yaml
background_grants:
  - equipment
  - Background_Sphere
  - Background_Talent
```

Background grants do not count against:

```yaml
background_grants_do_not_count_against:
  - CL1_free_Sphere_and_talent
  - later_level_talents
  - trained_choices
```

### 8.2 Background Compensation

Some Backgrounds may grant no Sphere, no Talent, or only a partial combat/cultivation benefit. If so, the package must include a compensation record.

```yaml
background_compensation:
  reason: string
  benefit: string
  mechanical_weight: comparable_to_missing_Background_grant
  source: string
```

Do not leave a Background mechanically empty unless the Background explicitly compensates elsewhere.

### 8.3 Current Background Exceptions

Use these current exception rules.

```yaml
background_exceptions:
  Cursed_Bloodline:
    allowed_Sphere: Dark
    note: may express strange inherited shadow, curse, or bloodline pressure without needing full supernatural casting language
  Dream_Touched:
    allowed_Sphere: Dreams
    note: may express strange knowledge, omen, or future-facing mystery without needing castable supernatural use at creation
  River_Child:
    allowed_Spheres:
      - Flowing_River
      - Athletics
  Spirit_Medium:
    allowed_Sphere: Spirit_Companions
    note: knowledge, relationship preparation, and spirit-facing literacy; does not begin with an active spirit companion unless a later Source Rule grants one
```

---

## 9. Origin and Origin Insight Integration

Origins and Origin Insights are separate from Background unless the source explicitly merges them.

```yaml
origin_record:
  name: string
  type: Origin | Origin_Insight | source_inspiration | other
  benefit: string
  restrictions: []
  source: string
  counts_against_Background: false
  counts_against_level_talent: false
  counts_against_trained_choices: false
```

Origin benefits must be explicit. Do not infer a Sphere, talent, item, Method, Foundation, or Recorded Art from origin flavor alone.

---

## 10. CL1 Free Sphere and Talent

For AI-generated characters, CL1 includes a free level 1 Sphere and one talent from that Sphere.

```yaml
CL1_free_Sphere_and_talent:
  grants:
    - one_free_level_1_Sphere
    - one_talent_from_that_Sphere
  counts_against_Background: false
  counts_against_trained_choices: false
  required_for_generated_CL1_or_higher: true
```

This is separate from Background grants.

### 10.1 Accounting Example

```yaml
CL1_generated_character_minimum_accounting:
  Background:
    grants:
      - Background_Sphere
      - Background_Talent
  CL1_free_grant:
    grants:
      - level_1_Sphere
      - talent_from_level_1_Sphere
```

The Background Sphere and CL1 free Sphere may be different if the build needs breadth. If a Source Rule or deliberate build choice causes overlap, the package must clearly record what each grant contributed and avoid double-counting the same talent.

---

## 11. Later Level Talents

Each CL grants one free level talent from a known Sphere.

```yaml
level_talent_by_CL:
  grant: one_free_level_talent
  requirement: talent_from_known_Sphere
  check_required: false
  counts_against_trained_choices: false
```

For CL higher than 1, the build should include a level-talent ledger.

```yaml
level_talent_ledger:
  - CL: integer
    Sphere: string
    talent: string
    source: level_talent
    legal_known_Sphere_at_time: boolean
```

If the generated character has a high CL package, the AI may allocate these directly rather than narrating each level of play, but the ledger must remain legal.

---

## 12. Trained Choices

Each CL allows up to 3 trained choices.

```yaml
trained_choice_rule:
  limit_per_CL: 3
  counts_only_trained_choices: true
  does_not_count:
    - Background_grants
    - CL1_free_Sphere_and_talent
    - level_talents
    - New_Sphere_Bonus_Talent
```

Use a trained-choice ledger when the build includes learned Spheres, talents, Recorded Arts, or other trained options beyond free grants.

```yaml
trained_choice_ledger:
  - CL: integer
    choice_type: new_Sphere | known_Sphere_talent | Recorded_Art | other
    source: string
    DC_or_auto_source: string
    result: learned
    counts_against_limit: true
```

Do not exceed 3 trained choices per CL.

---

## 13. Sphere and Talent Training Formulas

### 13.1 New Sphere Training

```yaml
New_Sphere_Learning_DC: 10 + 1d4 + number_of_different_Spheres_known
```

On success:

```yaml
new_Sphere_success:
  - gain_base_Sphere_ability
  - gain_one_New_Sphere_Bonus_Talent
```

The New-Sphere Bonus Talent does not count against trained choices.

### 13.2 Known-Sphere Talent Training

```yaml
Known_Sphere_Talent_Training_DC: 10 + number_of_talents_already_known_from_that_Sphere
```

### 13.3 Training Time

```yaml
Training_Time: 1d6 + PB - Intelligence_or_Wisdom_modifier
minimum_training_time: 2_days
training_day: 8_hours
```

For generated packages, these formulas validate the training history if one is included. The factory does not need to simulate all training unless requested.

---

## 14. No Default Retraining

Generated characters must not use default retraining, default respec, default refunds, default swaps, or default replacement.

```yaml
no_default_retraining:
  applies_to:
    - Spheres
    - talents
    - Recorded_Arts
    - Forged_Techniques
    - Methods
    - Foundations
    - learned_character_choices
  exception: explicit_Source_Rule_only
```

If a build changes a prior learned choice, cite the Source Rule that transformed, sealed, removed, or replaced it.

---

## 15. Manuals, Lineages, and Recorded Arts

Every generated character should include at least one manual, lineage, teacher, inheritance, or comparable source record unless the user explicitly asks for an incomplete scaffold.

```yaml
manual_or_lineage_requirement:
  required_for_complete_generated_character: true
  acceptable_sources:
    - manual
    - jade_slip
    - mural
    - teacher
    - sect_lineage
    - inheritance
    - family_record
    - spirit_relation
    - battlefield_journal
    - item_source
```

### 15.1 Manual Record

```yaml
manual_record:
  name: string
  type: manual | jade_slip | mural | inheritance | journal | teacher_record | other
  contents:
    Recorded_Arts: []
    Methods: []
    warnings: []
    recipes: []
    theory: []
    false_routes: []
  restrictions: []
  risks: []
  mechanics_granted: []
```

### 15.2 Recorded Art Boundary

A Recorded Art is a fixed technique learned from a source.

```yaml
Recorded_Art_boundary:
  grants_source_Sphere: false
  grants_source_talent: false
  grants_modification_rights: false
  effect: as_written
```

### 15.3 Recorded Art Training

```yaml
Recorded_Art_Training_DC: 10 + Recorded_Art_Difficulty + 2 * number_of_Recorded_Arts_already_learned_at_current_CL
```

The count resets when CL changes.

```yaml
recorded_art_record:
  name: string
  source: string
  Difficulty: integer
  CL_learned: integer
  activation: string
  cost: null_or_record
  effect: string
  duration: string
  limits: []
  status: active | known | sealed | dormant | unstable | transformed | suppressed | removed
```

---

## 16. Foundations

Foundations are actual cultivation architectures, not flavor tricks.

For AI generation:

```yaml
Foundation_generation:
  required_if_CL_at_or_above_Foundation_and_build_needs_current_standard: true
  normal_realm_entry: CL5_Foundation
  source_required: true
  record_required: true
```

A Foundation should include:

```yaml
Foundation_record:
  name: string
  family: string
  grade_or_depth: string
  source: string
  benefits: []
  burdens_or_risks: []
  compatibility: []
  action_exports: []
  passive_exports: []
```

Do not invent a Foundation name when a current catalog Foundation is required unless the user explicitly asks for a source-inspired custom Foundation.

---

## 17. Methods

A character may know more than one Method, but only one Primary Method applies its active shapes.

```yaml
Method_rule:
  may_know_multiple_Methods: true
  active_Primary_Methods: 1
  stacking_without_Source_Rule: false
```

```yaml
Method_record:
  name: string
  source: string
  status: known | Primary | dormant | sealed | provisional | transformed
  Resource_Shape: string
  Breakthrough_Shape: string
  Foundation_Shape: string
  compatibility: []
  incompatibility: []
```

Changing Method is a cultivation project, not a daily loadout.

---

## 18. Forged Techniques and Emergency Forging

Forged Techniques normally begin at Foundation / CL5.

```yaml
Forged_Technique_generation:
  normal_start: CL5_or_later
  Mortal_Realm_exception: GM_approved_only
  max_known: PB
  replacement_by_default: false
```

```yaml
forged_technique_record:
  name: string
  source_Spheres: []
  Complexity: integer
  activation: string
  cost: null_or_record
  effect: string
  drawback_or_limit: null_or_string
  learned_at_CL: integer
```

Emergency Forging is not a permanent learned technique until formalized later.

```yaml
Emergency_Forging_boundary:
  crisis_only: true
  one_time_effect: true
  permanent_technique_created_by_default: false
  farmable: false
```

---

## 19. Equipment, Items, and Source IDs

Generated character packages should use current Equipment/Source identifier expectations.

```yaml
current_equipment_source_ID_prefixes:
  executable_or_visible_equipment_action: ACT_EQUIPMENT_
  executable_or_visible_source_action: ACT_SOURCE_
  procedure_equipment_record: PROC_EQUIPMENT_
  procedure_source_record: PROC_SOURCE_
  modifier_equipment_record: MOD_EQUIPMENT_
  modifier_source_record: MOD_SOURCE_
```

Legacy IDs may be retained only as provenance.

```yaml
legacy_provenance_ID_prefixes:
  - EQ_
  - SRC_
```

Do not use legacy IDs as the only current executable identifier when a current GM Screen/export ID is required.

### 19.1 Item Boundary

An item does what its Source Rule says it does.

An item does not automatically grant:

```yaml
item_does_not_automatically_grant:
  - Sphere
  - talent
  - Recorded_Art
  - Method
  - Foundation
  - CP_recovery
  - AP
  - purification
  - crafting_permission
```

---

## 20. GM Screen Action Export

Use only these executable buckets.

```yaml
GM_Screen_executable_buckets:
  - action
  - bonus_action
  - reaction
  - passive
```

Do not use `split_required` as an executable bucket.

```yaml
non_executable_export_records:
  - procedure
  - training
  - downtime
  - crafting
  - recovery_project
  - source_note
  - audit_note
  - split_required
```

Every exported action should resolve.

```yaml
exported_action_requirements:
  action_id: string
  name: string
  executable_bucket: action | bonus_action | reaction | passive
  source_id: string
  activation_or_trigger: string
  cost: null_or_record
  target_or_area: null_or_string
  roll_save_check: null_or_record
  effect: string
  duration: string
  limit: null_or_string
  linked_components: []
```

Composite actions must link to exported, executable component actions or complete action records.

---

## 21. Required Character Package Surfaces

A complete generated package should include these surfaces or equivalents.

```yaml
required_character_package_surfaces:
  - Character_Core_Sheet
  - Character_Import_Surface
  - Action_Registry
  - Combat_Action_Packets
  - Passive_Feature_Records
  - Background_Record
  - Origin_Record_if_any
  - Sphere_Talent_Ledger
  - Level_Talent_Ledger
  - Trained_Choice_Ledger_if_used
  - Manual_Lineage_Record
  - Recorded_Arts
  - Foundation_Record_if_any
  - Method_Record_if_any
  - Forged_Technique_Records_if_any
  - Equipment_Record
  - Source_Map
  - Validation_Report
```

Do not place critical mechanics only in prose. The factory needs structured records.

---

## 22. Character Generation Validation Checklist

Use this checklist before finalizing the package.

```yaml
character_generation_validation:
  identity:
    name_present: true
    requested_CL_present: true
    Path_present: true
    species_Human_or_source_defined: true

  ability_scores:
    point_buy_27_legal: true
    point_buy_ledger_present: true
    no_unjustified_saving_throw_proficiencies: true

  Path:
    key_ability_correct: true
    hit_die_correct: true
    CP_type_correct: true
    Maximum_CP_uses_current_formula: true

  Background:
    Background_record_present: true
    equipment_present: true
    Background_Sphere_or_compensation_present: true
    Background_Talent_or_compensation_present: true
    Background_grants_not_counted_against_trained_choices: true

  Origin:
    Origin_record_present_if_used: true
    Origin_benefits_explicit: true
    no_mechanics_inferred_from_origin_flavor: true

  CL1:
    free_level_1_Sphere_present: true
    talent_from_level_1_Sphere_present: true
    CL1_grant_not_counted_against_Background_or_trained_choices: true

  Spheres_and_talents:
    known_Sphere_ledger_present: true
    talent_ledger_present: true
    level_talent_ledger_present: true
    trained_choice_limit_not_exceeded: true
    no_max_known_Spheres_rule_used: true

  manuals_and_arts:
    manual_or_lineage_source_present: true
    Recorded_Arts_do_not_grant_source_Spheres: true
    Recorded_Arts_do_not_grant_source_talents: true
    Recorded_Art_Difficulty_present_if_trained: true

  Methods_and_Foundations:
    only_one_Primary_Method_active: true
    Method_stacking_absent_unless_Source_Rule: true
    Foundation_record_present_if_CL_requires_current_standard: true

  Forged_Techniques:
    no_pre_CL5_Forged_Technique_without_exception: true
    max_known_not_above_PB: true
    no_default_replacement_or_retraining: true

  GM_Screen_export:
    executable_buckets_valid: true
    split_required_not_executable: true
    action_ids_resolve: true
    linked_components_resolve: true
    passive_records_exported: true

  package_integrity:
    source_map_present: true
    validation_report_present: true
    no_stale_lineage_tokens: true
    no_stale_equipment_names: true
    no_unresolved_execution_components: true
```

---

## 23. Common AI Failure Modes

Reject or repair these before final package delivery.

```yaml
common_AI_generation_failures:
  pathless_AI_character:
    problem: Level_0_player_flow_used_for_factory_generation
    repair: choose_Path_at_generation_start

  missing_Background_grants:
    problem: Background_has_no_Sphere_or_Talent_without_compensation
    repair: add_Background_Sphere_and_Talent_or_compensation

  CL1_talent_only:
    problem: CL1_grant_has_talent_but_no_free_Sphere
    repair: add_free_CL1_Sphere_and_talent_from_that_Sphere

  Background_counted_as_trained_choice:
    problem: free_Background_grant_consumes_training_slot
    repair: remove_from_trained_choice_count

  old_CP_formula:
    problem: Maximum_CP_uses_CL_times_modifier_plus_CL
    repair: use_CL_times_Path_key_modifier

  invented_saving_throw_proficiency:
    problem: saving_throw_proficiency_without_source
    repair: remove_or_cite_Source_Rule

  Recorded_Art_grants_source_Sphere:
    problem: fixed_art_treated_as_Sphere_training
    repair: keep_Recorded_Art_as_fixed_technique_only

  Method_stacking:
    problem: multiple_Method_shapes_active
    repair: choose_one_Primary_Method

  split_required_exported_as_action:
    problem: GM_Screen_bucket_invalid
    repair: split_packet_or_convert_to_non_executable_note

  unresolved_component:
    problem: composite_action_links_to_missing_action
    repair: create_or_link_valid_component_action
```

---

## 24. Minimal Output Contract

A generated character package is not complete unless it can answer these questions.

```yaml
minimal_output_contract:
  who_is_the_character: Character_Core_Sheet
  what_Path_do_they_use: Path_record
  how_were_ability_scores_built: point_buy_ledger
  what_did_Background_grant: Background_Record
  what_did_Origin_grant: Origin_Record_if_any
  what_was_the_CL1_free_Sphere_and_talent: Sphere_Talent_Ledger
  what_level_talents_exist: Level_Talent_Ledger
  what_trained_choices_exist: Trained_Choice_Ledger_if_used
  what_sources_taught_their_arts: Manual_Lineage_Record
  what_actions_can_GM_Screen_execute: Action_Registry_and_Combat_Action_Packets
  what_passives_modify_state: Passive_Feature_Records
  what_items_and_equipment_exist: Equipment_Record
  what_validation_was_run: Validation_Report
```

---

## 25. Final Bootstrap Rule

For AI character generation, prioritize legal structured package construction over player-facing discovery flow.

```text
The factory builds a usable cultivator package. It does not reenact the player’s Level 0 origin scene unless explicitly asked.
```
