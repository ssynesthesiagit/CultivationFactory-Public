# Tianxia Machine-Readable Path Indexes — Phase 2A

These indexes project the current canonical player Path chapters into deterministic machine-readable records for character generation.

## Files

- `body_refining.path_index.p2a.json`
- `qi_cultivation.path_index.p2a.json`
- `spirit_awakening.path_index.p2a.json`
- `Tianxia_Path_Index_Master_P2A.json`

Each individual Path index contains:

- stable Path, resource, feature, and component canonical IDs;
- key ability and cultivation mathematics;
- complete CL1–20 progression references;
- structured resource maximum, recovery, and 0-resource rules;
- exact source line ranges, hashes, and source text;
- Source CL rules;
- structured Realm Suppression rules;
- authority-overlay records where current canon supersedes wording embedded in an older Path source section.

Indexes are reference and selection tools. They do not grant abilities and do not replace the cited canonical source text.

Validate with:

```bash
python 06_VALIDATORS/validate_path_indexes.py --factory-root .
```

Query with:

```bash
python 07_TOOLS/query_path_index.py "Stamina Guard"
python 07_TOOLS/query_path_index.py --path spirit_awakening --cl 17 --json
```
