# HF05ZTA_R1A — AI Character Generation Sphere-Talent Accounting and Diversity Gate

**Status:** Portable hotfix overlay and factory integration patch.  
**Date:** 2026-07-07  
**Applies after:** Dao Arts v0.1 + Methods v0.1 + HF05ZW/HF05ZX/HF05ZY/HF05ZZ.  
**Primary source:** `Tianxia_AI_Character_Generation_Bootstrap_Rules_Reference_v0_1.md`.

## Purpose

This hotfix turns the AI-facing character generation rules into enforceable factory accounting requirements.
It is specifically designed to stop the common drift where generated characters:

- start as Level 0/pathless player-discovery characters instead of chosen-Path cultivators;
- use the old CP formula with `+ CL`;
- omit point-buy or saving-throw-source evidence;
- treat Background grants as trained choices;
- give the CL1 talent without the CL1 free Sphere;
- learn a new Sphere but forget the free talent gained with that Sphere;
- count the free new-Sphere bonus talent against the 3 trained choices per CL;
- sprawl into implausible sphere diversity without DC math, source support, or GM approval;
- export invalid GM Screen buckets such as `split_required`.

## Canonical rule added

Whenever a character legally gains a Sphere for the first time, they also gain one free talent from that Sphere unless the source explicitly says otherwise.

This applies to:

- the CL1 free Sphere grant;
- a Background Sphere when the Background provides a Background Talent or compensation;
- trained new-Sphere learning;
- explicit source-rule Sphere grants, unless the source says no talent is granted.

The free talent gained with a newly acquired Sphere does not count against trained choices unless the source explicitly says otherwise.

## Trained new-Sphere accounting

A trained new Sphere consumes one trained choice.
The free talent gained with that Sphere is recorded separately and does not consume a trained choice.

```yaml
trained_new_Sphere:
  trained_choice_cost: 1
  grants:
    - new_Sphere
    - one_free_bonus_talent_from_that_Sphere
  new_Sphere_bonus_talent_counts_against_trained_choices: false
```

## New Sphere DC math

The default new-Sphere learning DC remains:

```text
10 + 1d4 + number_of_different_Spheres_known
```

Any trained new Sphere must record:

```yaml
new_sphere_learning_dc:
  base: 10
  d4_roll: 1_to_4
  prior_different_spheres_known: integer
  total: base + d4_roll + prior_different_spheres_known
```

## AI sphere-diversity budget

AI-generated characters must observe a default sphere-diversity budget. This is a generation safety rail, not an in-world metaphysical impossibility.
Over-budget builds require source support, GM approval, and DC/training evidence.

| CL | Default maximum different Spheres | Exceptional maximum with source/GM override |
|---:|---:|---:|
| 1 | 2 | 4 |
| 2 | 3 | 5 |
| 3 | 4 | 6 |
| 4 | 4 | 6 |
| 5 | 5 | 7 |
| 6 | 5 | 7 |
| 7 | 6 | 8 |
| 8 | 6 | 8 |
| 9 | 7 | 9 |
| 10 | 8 | 10 |
| 11 | 8 | 10 |
| 12 | 9 | 11 |
| 13 | 9 | 11 |
| 14 | 10 | 12 |
| 15 | 11 | 13 |
| 16 | 11 | 13 |
| 17 | 12 | 14 |
| 18 | 12 | 14 |
| 19 | 13 | 15 |
| 20 | 14 | 16 |

## New required profile/template

Character packages should include:

```text
AI_Character_Generation_Profile.json
```

or an equivalent `Character_Generation_Accounting_Profile.json` containing the same ledgers.

The profile is the source of truth for:

- chosen Path;
- point buy;
- Path chassis and CP formula;
- Background grants or compensation;
- CL1 free Sphere + talent;
- Sphere acquisition ledger;
- talent source ledger;
- trained-choice ledger;
- level-talent ledger;
- new-Sphere DC records;
- sphere-diversity assessment;
- Method/Foundation/Forged-Technique boundaries;
- GM Screen executable bucket validation.

## New validator

```text
validate_hf05zta_r1a_ai_character_generation_accounting_gate.py
```

The validator fails on:

- missing AI character generation profile;
- pathless AI-generated character;
- illegal or missing 27-point-buy ledger;
- un sourced saving throw proficiency;
- old CP formula;
- missing Background equipment/Sphere/Talent/compensation;
- missing CL1 free Sphere or CL1 talent;
- new Sphere without a free bonus talent;
- free new-Sphere bonus talent counted against trained choices;
- trained choices over 3 per CL;
- trained new-Sphere missing DC math;
- sphere-diversity over default maximum without source/GM override;
- sphere-diversity over exceptional maximum;
- missing manual/lineage record for a complete package;
- missing Foundation record at CL5+ when current-standard complete generation applies;
- multiple active Primary Methods;
- pre-CL5 Forged Technique without exception;
- Forged Techniques above PB;
- invalid GM Screen executable bucket.

## Updated gate order

1. ZIP integrity
2. JSON parse
3. SHA256SUMS validation
4. HF05ZTA_R1A AI character-generation accounting gate
5. Dao Arts profile/action gate
6. Methods profile gate
7. ordinary factory validators
8. HF05ZW-R1A
9. HF05ZX-R1A
10. HF05ZY-R1A
11. HF05ZZ-R1A
12. independent deep audit

## Claim boundary

This hotfix is a static/package validation patch. It does not claim live GM Screen browser/render testing.

```text
NO_LIVE_GMSCREEN_BROWSER_EVIDENCE_CLAIMED
```
