# Canon Source Replacement Map — Phase 1

| Prior source | Status | Current authority | Reason |
|---|---|---|---|
| `09_RULES/Needed.zip` | retired_to_deprecated | `09_RULES/Tianxia_Canonical_Rules_Corpus_P1.zip` | Old bundle contained PHB v0.3 and no finalized Path/Insight canon. |
| `Source_Text/Tianxia_PHB_Manuscript_v0_3.md` | prohibited_production_authority | `Source_Text/PHB/Tianxia_PHB_Manuscript_v0_7_Subpaths_Inserted.md` | Shared Path, Path chapters, Insights, and Subpath access are updated. |
| `Path rules embedded only in PHB v0.3 / old drafts` | replaced | `Qi R19, Body R8, Spirit R7 source components` | Current normalized publication rules. |
| `Path-specific and Sphere-embedded Insight text` | superseded_for_insight_authority | `Central Cultivation Insights R4 and Compendium R1` | 451 ability-integrated executable canonical Insight records. |
| `Older Spirit Companions assumptions` | superseded_where_conflicting | `Spirit Rules Reference R3 + Bonded Companions R2 + integration overlay` | Current personhood, Bond, manifestation, and action-economy procedures. |
| `Foundations, Methods, Backgrounds, Origin Insights, manuals, Sphere Compendium` | retained | `Same retained support sources` | Not replaced by Path/Insight publication handoff, except subject-specific precedence in authority overlay. |
