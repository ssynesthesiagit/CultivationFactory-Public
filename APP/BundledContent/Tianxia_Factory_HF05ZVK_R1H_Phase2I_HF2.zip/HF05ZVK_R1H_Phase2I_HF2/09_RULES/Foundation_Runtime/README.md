# Authoritative Foundation Runtime Catalog

This directory is the HF05ZVK-R1F semantic authority for Foundation runtime validation.

- Exactly **30 authoritative non-Chakra Foundations** are playable.
- The 32 theoretical Chakra Foundation concepts are deliberately excluded until complete executable mechanics, progression, risks, and repairs are authored.
- The readable source is used to verify resource names, legal starting values, attained-stage feature coverage, lifecycle categories, and theoretical-status exclusion.
- This catalog does not replace character-specific source packets; it supplies a shared minimum runtime contract.
