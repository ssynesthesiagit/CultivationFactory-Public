# Tianxia Item Book
## Final Audited Reading Copy R1

## Table of Contents

- Chapter 1: Treasures of the Cultivation World
- Chapter 2: Spiritual Weapons
  - Chapter 2A: Weapon Chassis and Creating a Weapon
  - Chapter 2B: Primary Weapon Materials
  - Chapter 2C: Weapon Enchantments
- Chapter 3: Spiritual Armor
  - Chapter 3A: Armor Chassis and Armor Types
  - Chapter 3B: Armor Materials
  - Chapter 3C: Armor Enhancements
- Chapter 4: Wondrous Treasures — Complete 200-Item Catalog
  - Chapter 4A: Wondrous Treasures — Production Chunk 1
  - Chapter 4B: Wondrous Treasures — Production Chunk 2
  - Chapter 4C: Wondrous Treasures — Production Chunk 3
  - Chapter 4D: Wondrous Treasures — Final Production Chunk
- Chapter 5: Consumable Treasures
- Chapter 6: Growth Treasures and Item Spirits
- Chapter 7: Treasure Sets and Set Resonances
- Chapter 8: Identification, Appraisal, Repair, Reforging, and Salvage
- Chapter 9: Treasure Availability and Distribution
- Chapter 10: Random and Curated Treasure Tables
- Chapter 11: Factory and GM Screen Item Schema

## Release Status

- Final rules audit: `PASS_FINAL_ITEM_BOOK_AUDIT_R1`
- Item schema: `PASS_ITEM_SCHEMA_R2`
- Bad-fixture regression: `PASS_BAD_FIXTURE_REGRESSION`
- Canonical normalized item definitions: 318
- Treasure Sets: 9
- Live GM Screen browser render: not claimed by this document

---


# Chapter 1: Treasures of the Cultivation World

*Rules Baseline v0.3*

Cultivators do not measure wealth only in coins. A wandering disciple may own little more than a patched robe and a chipped sword, yet carry a single jade talisman capable of saving a life. A sect elder may command vaults of spirit stones, medicinal herbs, formation plates, inherited scriptures, and weapons refined across generations. At the highest reaches of cultivation, a treasure may awaken a spirit, carry the Dao of its creator, shelter a lineage, or become a world unto itself.

This book presents the weapons, armor, rings, talismans, pills, vessels, furnaces, formation tools, sect treasures, and Immortal Artifacts of **Tianxia: Cultivation — The Immortal’s Path**.

Tianxia treasures use the rules framework of Dungeons & Dragons 5.5e. Their effects resolve through familiar actions, attacks, saving throws, conditions, movement, damage, healing, duration, concentration, charges, and Attunement. Their identity, however, belongs to cultivation. A treasure is shaped by its materials, inscriptions, refinement history, spiritual affinities, wielder, and the Dao principle it embodies.

The central rule of this book is simple:

> **Cultivation determines the principle. The game rules determine its execution.**

A treasure may be ancient, overwhelming, intelligent, or capable of expressing a fragment of a great Dao. Whenever that treasure is used at the table, its rules state exactly what happens.

---

## Treasures in Tianxia

Magic items in Tianxia are usually called **treasures**. The term includes more than weapons and protective gear. A treasure can be a storage ring, alchemical furnace, jade slip, medicinal gourd, formation flag, beast bell, flying sword case, sect seal, cultivation mat, spirit lamp, or pocket domain.

Some treasures are portable tools used by individual cultivators. Others are fixed structures, such as defensive bells, star-road altars, refinement halls, and sect-protecting formations. The greatest artifacts may contain inner worlds, preserve living beings for ages, or carry authority left behind by a vanished immortal.

Treasure design in Tianxia follows three principles.

### A Treasure Has a Clear Purpose

A treasure normally has one primary mechanical role, such as offense, defense, movement, control, healing, storage, cultivation, crafting, sealing, or exploration.

Powerful treasures can have several expressions, but those expressions should arise from the same central principle. A mountain seal may resist forced movement, slow enemies, and pin a creature beneath spiritual weight. Those are separate effects, but all express stability, weight, and suppression.

A treasure should not become a collection of unrelated abilities merely because it is ancient or valuable.

### A Treasure Uses Complete Mechanics

An active treasure effect states all information required to resolve it:

- the Action, Bonus Action, Reaction, ritual, or trigger used to activate it;
- its range and target or area;
- any attack roll, saving throw, or ability check;
- the save DC or attack modifier used;
- its damage, healing, movement, condition, or other effect;
- what happens on a successful saving throw;
- its duration and whether it requires Concentration;
- its resource cost, uses, charges, and recovery method;
- any size, creature-type, realm, or frequency limit.

The GM adjudicates unusual circumstances, as normal, but does not need to invent missing rules to make a treasure function.

### A Treasure Should Not Overload Combat

Tianxia characters already possess Paths, Spheres, Talents, Foundations, Methods, Recorded Arts, and other cultivation options. Treasures should add identity and power without burying each turn beneath additional buttons and temporary states.

Most treasures therefore favor:

- passive benefits;
- improvements to attacks, defenses, movement, or Sphere actions the bearer already uses;
- persistent properties that function whenever their printed conditions are met;
- explicit stacking limits when repeated application would become unclear;
- one shared charge pool;
- clear reactions with a single trigger;
- major activations reserved for effects that deserve them.

A generic once-per-turn limit is not the default. Use frequency limits only when a treasure releases a discrete missile, burst, seal, reflection, escape, domain, or similarly exceptional manifestation. When repetition must be controlled, prefer an Action, Reaction, CP cost, charge cost, successful-save immunity window, stacking cap, dormancy rule, or per-rest recovery.

Per-rest utility is not restricted in the same way. A treasure can freely provide exploration, crafting, divination, storage, travel, ritual, recovery, social, or downtime functions when those uses do not create substantial turn-by-turn complexity.

---

# Treasure Grades

Tianxia uses six treasure grades. These grades replace the usual rarity names in player-facing rules.

| D&D Compatibility | Tianxia Grade | Meaning |
|---|---|---|
| Common | **Mortal Item** | Nonmagical equipment, including exceptional masterwork objects |
| Uncommon | **Spiritual Treasure** | The first true cultivation treasures |
| Rare | **Saint Treasure** | Powerful personal treasures with major combat or cultivation functions |
| Very Rare | **Sovereign Treasure** | Encounter-shaping treasures, advanced vessels, and important sect resources |
| Legendary | **Imperial Treasure** | Lineage-defining or sect-protecting treasures of exceptional authority |
| Artifact | **Immortal Artifact** | Unique campaign objects, living legacies, world-machines, and heaven-defying vessels |

A treasure’s grade describes its general mechanical and narrative authority. It does not automatically establish the cultivation Realm required to use it. An item states any bearer, Cultivation Level, Path, Sphere, bloodline, sect, or Realm requirement it possesses.

## Mortal Items

A Mortal Item is not magical. It may still be exquisitely made, historically important, unusually durable, or valuable because of its materials.

Masterwork weapons, ceremonial armor, alchemical instruments, engraved coins, court seals, and high-quality crafting tools can all be Mortal Items.

Because Mortal Items are nonmagical, they do not normally overcome resistance or immunity that requires magical equipment.

## Spiritual Treasures

A Spiritual Treasure is the first true grade of cultivation item. It can hold a stable inscription, circulate qi, preserve materials, store objects in folded space, produce a minor supernatural effect, or assist a cultivator’s training.

Storage rings, communication jade, movement anklets, medicinal gourds, simple talismans, and low-grade spirit weapons are commonly Spiritual Treasures.

Although this is the lowest supernatural grade, Spiritual Treasures are not ordinary household goods. Even a modest storage ring is expensive and rare outside cultivator society.

## Saint Treasures

A Saint Treasure has a substantial supernatural identity. It may produce a strong attack, reinforce a bearer’s defenses, suppress movement, enhance a Sphere expression, or contain a specialized cultivation technique.

Saint Treasures are major personal possessions. Disciples may receive one for exceptional service, inherit one from a teacher, claim one from an ancient ruin, or spend years gathering the materials required to create it.

## Sovereign Treasures

A Sovereign Treasure can influence an entire encounter, perform advanced refinement, bind powerful creatures, sustain specialized cultivation environments, or serve as a major resource for a sect.

Such treasures often contain advanced Dao marks, rare materials, limited autonomy, or several closely related expressions of one principle.

## Imperial Treasures

An Imperial Treasure is rarely treated as ordinary personal property. It may define a lineage, protect a mountain gate, serve as the central vessel of a great cultivator, or carry enough authority to alter the course of a war.

Imperial Treasures can possess awakened spirits, extraordinary defenses, powerful area effects, or a deep relationship with a specific inheritance. Many are issued as sect loans, bound to a bloodline, or guarded as institutional treasures.

## Immortal Artifacts

An Immortal Artifact is unique. It is not simply a stronger Imperial Treasure.

An Immortal Artifact may be a pocket world, world-machine, surviving fragment of immortal authority, star-road vessel, living weapon, or proof-of-Dao treasure. Its acquisition, awakening, repair, destruction, or inheritance should matter to the campaign.

Immortal Artifacts are not normally created through standard downtime crafting.

---

# Reading a Treasure Entry

A treasure entry follows the familiar presentation used for D&D equipment.

## Name, Type, Grade, and Attunement

The first lines identify the treasure’s name, item type, grade, and whether it requires Attunement.

> **Mountain-Root Suppression Seal**  
> *Wondrous Item, Saint Treasure, Requires Attunement*

The normal D&D item types remain useful. Common examples include:

- Armor
- Potion
- Ring
- Rod
- Scroll
- Staff
- Wand
- Weapon
- Wondrous Item

Tianxia also uses descriptive families such as talisman, pill, furnace, formation plate, jade slip, spirit weapon, Dao vessel, sect infrastructure, and world-machine. These families describe a treasure’s place in the setting but do not replace its rules type.

### Wondrous Treasures

The broad category **Wondrous Treasure** covers permanent supernatural objects that are not primarily weapons, armor, shields, potions, or scrolls.

Examples include:

- storage rings and spatial containers;
- movement anklets, travel cloaks, and ferry tokens;
- communication jade and memory slips;
- cultivation mats, incense burners, and recovery beads;
- crafting tools, furnaces, and appraisal instruments;
- spirit lamps, offering bowls, and ancestral tablets;
- formation cores, sect seals, pavilions, and world-machines.

A ring, rod, staff, wand, or another familiar D&D item type can still use its normal rules type. “Wondrous Treasure” is the default when no narrower type is mechanically necessary.

Every Wondrous Treasure entry states:

- treasure family;
- Sphere Influences;
- whether it requires Attunement;
- its primary material or construction principle when relevant;
- all passive and activated mechanics;
- charge, recovery, Concentration, strain, or dormancy rules;
- whether it can hold creatures, create space, or serve as infrastructure.

## Attunement and Bonding

Attunement represents establishing a stable bond between a treasure and its bearer. Depending on the object, this may involve qi circulation, blood marking, meditation, reciting an inheritance formula, receiving recognition from an item spirit, or completing a normal period of study.

### Attunement Capacity

A character can be attuned to **four treasures at the same time**.

Each treasure that requires Attunement normally occupies one Attunement slot. A character cannot complete Attunement to a fifth treasure until one of their four slots becomes available.

A Path feature, Talent, Foundation, Method, Dao Insight, treasure property, or other ability can increase or reduce this capacity. When an ability changes Attunement capacity, use the capacity stated by that ability.

A treasure can occupy more than one Attunement slot only if its stat block explicitly says so. Sect infrastructure, vehicles, world-machines, and similar installations do not occupy a personal Attunement slot unless their rules specifically require personal Attunement.

Except for the four-slot capacity established here, beginning and ending Attunement follows the normal D&D rules.

### Additional Requirements

A treasure may impose additional requirements, such as:

- being a cultivator;
- knowing a particular Sphere;
- following a particular Path;
- possessing a compatible Foundation or Dao Insight;
- belonging to a lineage or sect;
- reaching a minimum Cultivation Level;
- receiving recognition from the treasure’s spirit.

Failure to meet an additional requirement means the creature cannot attune to the item unless the item specifies a lesser function available to an incompatible bearer.

## Passive Properties

A passive property functions continuously while the treasure is worn, wielded, carried, installed, or attuned as stated.

Passive effects are used extensively in Tianxia because they give a treasure a stable identity without adding another activation decision every round.

## Activations

An activation tells you how to use a treasure’s active power.

An activation begins with its name, followed by the required Action, Bonus Action, Reaction, ritual, or trigger.

> **Fivefold Gale.** As an Action, expend 2 charges to release a 30-foot cone of cutting wind.

An item that produces multiple active effects normally uses one shared charge pool unless it says otherwise.

## Resonance

Some treasures respond more strongly to a compatible bearer. This is called **Resonance**.

A Resonance property may refer to a Path, Sphere, Talent, Foundation, Method, Dao Insight, bloodline, item material, or other defined affinity.

> **Earth Resonance.** If you know the Earth Sphere or possess an Earth-, Mountain-, Weight-, or Suppression-aligned Dao Insight, Mountain Holds has a range of 30 feet.

Resonance normally improves an existing property. It should not be assumed to grant an entirely separate Sphere, Talent, or prerequisite.

## Growth Treasures

A growth treasure changes as its bearer advances, as new materials are refined into it, or as specific story conditions are fulfilled.

Growth should normally occur at major thresholds rather than every Cultivation Level. A growth treasure may improve an existing property, expand its internal space, awaken an item spirit, or unlock a new expression of its established principle.

The treasure’s entry states exactly when and how it advances.

---

# Item Attacks and Saving Throws

## Bonded Item Save DC

When a treasure refers to **your item save DC**, calculate it as follows:

**Item Save DC = 8 + your Proficiency Bonus + your Path key ability modifier**

If you possess more than one Path, use the Path key ability selected when you attune to the treasure. You use that ability for the treasure until your Attunement ends, unless the item says otherwise.

## Bonded Item Attack Modifier

When a treasure requires an item attack roll, calculate it as follows:

**Item Attack Modifier = your Proficiency Bonus + your Path key ability modifier**

## Fixed Item DCs

Some treasures contain a complete independent inscription and use a fixed saving throw DC. Talismans, formation traps, inherited seals, autonomous weapons, and ancient relics commonly use fixed DCs.

When an item lists a fixed DC, use that DC instead of the bonded item formula.

### Default Fixed Item Statistics

When a treasure needs an independent grade-based statistic and its entry does not print a different value, use the following defaults.

| Treasure Grade | Fixed Save DC | Fixed Item Attack Modifier |
|---|---:|---:|
| Mortal Item | 12 | +4 |
| Spiritual Treasure | 13 | +5 |
| Saint Treasure | 15 | +7 |
| Sovereign Treasure | 17 | +9 |
| Imperial Treasure | 19 | +11 |
| Immortal Artifact | 21 or bespoke | +13 or bespoke |

A printed item statistic overrides this table. Attuned treasures that use the bearer's bonded item formula continue to use that formula instead.

## Sphere-Like Effects

A treasure can reproduce an effect associated with a Sphere, Talent, Recorded Art, or other cultivation technique.

Using that effect does not grant the bearer ownership of the Sphere, Talent, or technique. It does not satisfy prerequisites and does not count toward the bearer’s known Spheres or Talents unless the treasure explicitly says otherwise.

The treasure uses its printed parameters, including its action type, range, target, save, damage, duration, and cost.

---

# Charges, Uses, and Recovery

Treasures use several methods to limit powerful effects.

## Charges

A treasure with charges states its maximum charges, activation cost, and recovery rule.

> The fan has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

Unless an item says otherwise:

- it cannot spend more charges than it currently has;
- charges cannot be transferred between treasures;
- a treasure at 0 charges remains functional except for properties that require charges;
- completing more than one Long Rest in a 24-hour period does not cause the treasure to recover charges more than once.

## Existing Path Resources

Some treasures use CP, Stamina, Resonance, or another existing resource. This is preferred when the treasure channels or reinforces the bearer’s cultivation rather than operating independently.

A treasure cannot reduce a resource below 0.

## Per-Rest Uses

A treasure may have a property usable once per Short Rest, Long Rest, or another stated interval.

Combat-facing per-rest properties are normally reserved for major defensive, escape, suppression, awakening, or encounter-shaping effects.

Out-of-combat properties can use per-rest recovery more freely. Divination, material appraisal, travel, preservation, cultivation assistance, crafting, ritual cleansing, and similar abilities do not significantly increase combat complexity.

## Strain and Dormancy

Certain treasures can be overloaded or pushed beyond safe operation. Such an item may gain **strain** or become **dormant**.

An item’s entry defines:

- when it gains strain;
- the maximum strain it can hold;
- what happens at that maximum;
- how strain is removed;
- which properties cease functioning while dormant.

Strain is used only when it is central to the treasure. It is not a universal subsystem applied to every item.

---

# Concentration and Sustained Effects

A treasure that creates a powerful sustained field, transformation, restraint, or similar ongoing effect may require Concentration.

When an item says you maintain Concentration as though concentrating on a spell, use the normal D&D Concentration rules.

You cannot maintain Concentration on an item effect and another effect at the same time unless a feature explicitly permits it.

Short effects that last until the start or end of a turn generally do not require Concentration.

---

# Storage Treasures

Extradimensional storage is strongly associated with cultivator society. The standard personal storage treasure is the **storage ring**.

A storage ring is expensive, difficult to create, and uncommon outside sects, cultivation clans, merchant houses, and established adventuring groups. Possessing one can mark a person as wealthy, dangerous, well-connected, or worth robbing.

Other storage forms exist, including:

- treasure gourds;
- storage sleeves;
- spatial pouches;
- jade belts;
- beast-holding bags;
- medicinal cases;
- sect vault tokens;
- formation-linked keys.

These forms are usually specialized. Storage rings remain the default portable choice.

Each storage treasure defines:

- its weight and volume capacity;
- the action needed to store or retrieve objects;
- whether it preserves contents;
- whether it can hold creatures;
- what happens when placed inside another extradimensional space.

A normal storage treasure cannot hold living creatures unless it explicitly provides a habitat or creature-storage function.

---

# Cultivation Currency

Tianxia uses ordinary money for daily commerce and spirit stones for cultivation trade.

## Ordinary Currency

| Currency | Abbreviation | D&D Equivalent | Conversion |
|---|---:|---:|---:|
| Copper Cash | CC | 1 Copper Piece | Base unit |
| Silver Tael | ST | 1 Silver Piece | 1 ST = 10 CC |
| Gold Tael | GT | 1 Gold Piece | 1 GT = 10 ST = 100 CC |

**Gold Taels replace GP** in equipment prices, wages, mundane treasure, and ordinary crafting costs.

Platinum is not a standard circulating coin in Tianxia. Large mundane transactions are conducted through weighed gold, merchant-house notes, bank credit, sealed trade bars, or spirit stones.

## Spirit Stones

Spirit stones are both high-value currency and concentrated cultivation resources.

| Spirit-Stone Grade | Abbreviation | Value |
|---|---:|---:|
| Spirit Shard | Shard | 10 GT |
| Low-Grade Spirit Stone | LSS | 100 GT |
| Mid-Grade Spirit Stone | MSS | 1,000 GT |
| High-Grade Spirit Stone | HSS | 10,000 GT |
| Perfect Spirit Stone | PSS | 100,000 GT |

Ten stones or shards of one grade equal one stone of the next grade.

Spirit stones are physical resources. A rule may require a stone to be **spent as currency** or **consumed for its energy**. Either use removes the stone. The same stone cannot satisfy both a monetary and energy requirement.

The listed values represent stable default exchange rates used for rules and treasure budgeting. Local scarcity, damaged trade routes, sect monopolies, regional qi quality, war, and political restrictions can affect availability.

## Sect Contribution Points

**Sect Contribution Points (SCP)** record service, trust, and entitlement within a sect.

They are not ordinary currency. Contribution Points cannot normally be:

- sold;
- transferred;
- inherited;
- stolen;
- exchanged directly for Gold Taels;
- used outside the sect that issued them.

For rules and GM budgeting, 1 SCP represents approximately 10 GT of requisition value. Access remains subject to rank, department, mission authorization, stock, and sect policy.

| Requisition | Typical SCP | Typical Access |
|---|---:|---|
| Mundane equipment worth 100 GT | 10 SCP | Outer disciple or recognized agent |
| Spiritual Treasure worth 200 GT | 20 SCP | Appropriate standing |
| Saint Treasure worth 2,000 GT | 200 SCP | Inner disciple, officer, or sponsor |
| Sovereign Treasure worth 20,000 GT | 2,000 SCP | Core disciple, elder sponsor, or council approval |
| Imperial Treasure worth 100,000 GT | 10,000 SCP | Sect council; normally issued as a loan |
| Immortal Artifact | Not purchasable | Campaign-level authority only |

A sect can issue a treasure temporarily for a mission. Requisitioning access does not necessarily grant permanent ownership.

---

# Creating Treasures

Treasure crafting follows the familiar D&D 5.5e structure while adding cultivation materials, facilities, formulas, and institutional access.

To create a permanent treasure, a crafter normally needs:

1. **A Formula.** A complete design, inscription sequence, inherited method, recipe, or construction diagram.
2. **A Skill.** Arcana is the default skill for supernatural item creation. Another skill can replace it when appropriate.
3. **A Tool.** The tool must match the item being created.
4. **Materials.** These include ordinary materials, spirit stones, and at least one appropriate special component for significant treasures.
5. **A Facility.** A suitable forge, furnace, refinement chamber, formation table, alchemical hall, or equivalent workspace.
6. **Time.** The required workdays must be completed.
7. **Access.** Advanced treasures may require Realm, sect, lineage, legal, or political permission.

## Skills and Tools

Arcana remains the universal default for qi inscription and supernatural refinement, but other skills may apply.

| Treasure Family | Typical Skill | Typical Tool |
|---|---|---|
| Weapons, armor, and metal treasures | Arcana | Smith’s Tools |
| Rings, seals, and jade treasures | Arcana | Jeweler’s Tools |
| Talismans and command slips | Arcana | Calligrapher’s Supplies |
| Pills, elixirs, and medicinal treasures | Arcana or Medicine | Alchemist’s Supplies or Herbalism Kit |
| Robes, banners, and spirit-thread items | Arcana | Weaver’s Tools or Leatherworker’s Tools |
| Formation plates and array flags | Arcana | Calligrapher’s Supplies, Cartographer’s Tools, or Mason’s Tools |
| Religious or ancestral relics | Religion | Appropriate tool |
| Sourcecraft and geomantic treasures | Arcana or Investigation | Cartographer’s Tools, Mason’s Tools, or Jeweler’s Tools |
| Beast gear | Animal Handling or Arcana | Leatherworker’s Tools or Smith’s Tools |
| Cultivation foods | Medicine or Nature | Cook’s Utensils |

The GM determines whether a proposed substitution matches the item’s actual construction.

## Time and Base Material Value

| Grade | Workdays | Base Material Value |
|---|---:|---:|
| Mortal Item | 5 | 50 GT |
| Spiritual Treasure | 10 | 200 GT |
| Saint Treasure | 50 | 2,000 GT |
| Sovereign Treasure | 125 | 20,000 GT |
| Imperial Treasure | 250 | 100,000 GT |
| Immortal Artifact | Special | Special |

Convenient spirit-stone equivalents are:

| Grade | Spirit-Stone Expression |
|---|---:|
| Mortal Item | 5 Spirit Shards |
| Spiritual Treasure | 2 Low-Grade Spirit Stones |
| Saint Treasure | 2 Mid-Grade Spirit Stones |
| Sovereign Treasure | 2 High-Grade Spirit Stones |
| Imperial Treasure | 1 Perfect Spirit Stone |

These values represent ordinary materials and labor. They do not replace named special components, rare catalysts, formulas, facility access, or story requirements.

Consumable Treasures use the dedicated Formula, batch, time, and material-cost rules in Chapter 5. Chapter 5 supersedes the earlier generic half-time and half-cost assumption.

## Material Principles

Cultivation materials are not interchangeable bundles of value. A significant material carries an inherent principle that helps determine what the completed treasure can do.

Examples include:

- mountain-root jade expressing stability and suppression;
- storm bamboo expressing speed, flexibility, and lightning conduction;
- phoenix-blood metal expressing fire, yang energy, endurance, or rebirth;
- enlightenment wood expressing clarity and comprehension;
- void crystal expressing storage, distance, concealment, or teleportation;
- divine source expressing preservation, sealing, and stored vitality.

A treasure’s principal material should support its primary mechanical identity.

## When Crafting Requires a Check

Routine crafting with a complete formula, proper materials, sufficient time, and an appropriate facility does not normally require a check.

A check may be required when a crafter:

- works without a complete formula;
- substitutes an important material;
- rushes the work;
- attempts a grade beyond safe capability;
- awakens an item spirit;
- repairs an ancient or damaged treasure;
- adds an overload property;
- creates a forbidden or unstable item.

The specific crafting chapter provides complete procedures for complications, partial success, material recovery, flaws, and breakthroughs gained through failed refinement.

---

# Treasures and the Dao

A treasure is more than a container for an effect.

The strongest Tianxia treasures possess an internal logic. Their material, form, history, and powers all express a connected principle.

A cauldron of immense spiritual weight may defend by interposing itself, attack by descending upon a target, suppress movement through pressure, and refine materials by stabilizing unstable forces. Each property is different, but all belong to one Dao expression.

A mirror treasure may reveal illusions, reflect attacks, preserve images, divide real from false, or create a still-water sanctuary. A bell may calm minds, transmit warnings, shatter concentration, impose rhythm, or awaken a defensive formation.

When creating or interpreting a treasure, ask:

- What principle does this treasure embody?
- What material gives it permission to express that principle?
- What is its primary mechanical role?
- How does its active effect resolve through D&D rules?
- Does each property reinforce the same identity?
- Does it add power without adding unnecessary combat procedure?

The result should feel unmistakably like cultivation while remaining fast, exact, and playable at the table.

---

# The Place of Great Treasures

Not every treasure is available for purchase. A market may sell medicinal pills, basic talismans, low-grade spirit weapons, and occasionally a storage ring. Saint and Sovereign Treasures are more likely to be inherited, commissioned, awarded, discovered, won, stolen, or claimed from dangerous places.

Imperial Treasures are usually bound to sects, clans, courts, ancient lineages, or exceptional cultivators. Immortal Artifacts belong to the history of the world.

This difference matters. The value printed for a treasure supports crafting and campaign budgeting. It does not guarantee that the treasure can be found for sale.

In Tianxia, obtaining the right formula, material, teacher, furnace, permission, or opportunity is often more difficult than gathering the nominal price.

A treasure therefore serves several roles at once:

- a mechanical tool;
- a reward;
- a mark of status;
- a record of cultivation history;
- a connection to a sect or inheritance;
- a reason to explore, negotiate, fight, or refine;
- a vessel through which a cultivator’s own Dao may eventually be expressed.

The following chapters present these treasures by grade, function, origin, and method of creation.


# Chapter 2: Spiritual Weapons

This combined production file presents the weapon rules in their required reading and construction order:

1. **Chapter 2A — Weapon Chassis and Creating a Weapon**
2. **Chapter 2B — Primary Weapon Materials**
3. **Chapter 2C — Weapon Enchantments**


## Chapter 2A: Weapon Chassis and Creating a Weapon
### Canonical Profile Catalog v0.2

A cultivation weapon must begin with a legal weapon chassis.

The chassis determines the weapon’s damage die, damage type, handedness, range, ordinary properties, and weapon family. Primary Material and enchantments modify that chassis; they do not replace it.

This catalog carries forward the legal weapon profiles from the Sphere of Weapons. Dedicated Spheres such as Sword, Spear, Axes, Sabers, Chains, Dual Wielding, and Sniper remain the specialist homes for deeper techniques. The profiles here establish what the physical weapon is.

---

# Creating a Cultivation Weapon

Build every weapon in the following order:

> **1. Weapon Type → 2. Primary Material → 3. Treasure Grade and Refinement Bonus → 4. Enchantments → 5. Final Weapon Entry**

The order matters. A later choice cannot silently rewrite an earlier one.

## Step 1: Choose the Weapon Type

Choose one legal profile from this chapter.

Record:

- weapon name and cultural form;
- category;
- proficiency class;
- base damage;
- damage type;
- properties;
- tags;
- specialist-Sphere relationship.

The weapon type determines what the object physically does before supernatural construction begins.

## Step 2: Choose the Primary Material

Choose one material from **Chapter 2B: Primary Weapon Materials**.

Confirm:

- its Material Grade;
- its Normal Refinement Ceiling;
- its affinity tags;
- its inherent Material Property;
- its preferred enchantments;
- any opposed enchantments;
- whether a stabilizing Secondary Material is required.

The material property does not consume enchantment capacity.

## Step 3: Choose the Finished Treasure Grade

The finished grade determines the actual Refinement Bonus to attack and damage rolls.

| Finished Grade | Refinement Bonus | Enchantment Capacity |
|---|---:|---:|
| Spiritual Treasure | **+1** | **+1** |
| Saint Treasure | **+2** | **+3** |
| Sovereign Treasure | **+4** | **+6** |
| Imperial Treasure | **+6** | **+10** |
| Immortal Artifact | **+8 baseline or bespoke** | **Bespoke; normally +12 or higher** |

The chosen Primary Material must be capable of supporting that grade unless the formula includes a specific ceiling-breaking method.

## Step 4: Choose Enchantments

Choose enchantments from **Chapter 2C: Weapon Enchantments**.

For each enchantment, verify:

- the weapon meets its Minimum Grade;
- the chassis can deliver the effect;
- the material is compatible;
- any opposed affinity has been stabilized;
- the sum of Equivalent Bonuses does not exceed capacity;
- every action, trigger, target, save, cost, and recovery rule remains explicit.

The weapon's enchantments do not increase its attack and damage bonus unless an enchantment explicitly says otherwise.

## Step 5: Compile the Final Weapon

Calculate:

> **Total Enchantment Value = Sum of all Equivalent Bonuses**

> **Total Effective Bonus = Refinement Bonus + Total Enchantment Value**

The Total Effective Bonus is used for construction, comparison, and valuation. Only the Refinement Bonus is added directly to attack and damage rolls.

---

# Worked Example: Creating a Storm-Iron Flying Thunder Jian

This example creates a Saint Treasure weapon from beginning to end.

## 1. Select the Weapon Type

Choose the **Jian (劍) — Straight Sword** profile.

**Recorded chassis:**

- Category: Short Weapon
- Proficiency: Martial melee
- Base Damage: `1d8` piercing or slashing
- Versatile Damage: `1d10`
- Properties: Finesse, Versatile `1d10`, Balanced Edge Method
- Tags: Cut, Thrust, Guard, Duel
- Specialist Sphere: Sword

The jian is a melee weapon. It does not naturally have the Thrown, Ammunition, or Reach property.

## 2. Select the Primary Material

Choose **Storm Iron**.

**Recorded material:**

- Material Grade: Spiritual
- Normal Refinement Ceiling: Saint Treasure
- Affinities: Lightning, Thunder, Metal
- Preferred Enchantments: Lightning, Thunder, Storm, Magnetism
- Opposed Enchantments: Ice unless stabilized

**Residual Charge.** Whenever the weapon hits, the target takes 1 additional lightning damage. If the target is wearing metal armor or is made primarily of metal, it takes 2 additional lightning damage instead.

Storm Iron can support the intended Saint Treasure grade without a special ceiling-breaking formula.

## 3. Select the Treasure Grade

Choose **Saint Treasure**.

The weapon receives:

- **+2 Refinement Bonus** to attack and damage rolls;
- **+3 enchantment capacity**.

The weapon requires no ceiling-breaking component because Storm Iron's Normal Refinement Ceiling is Saint Treasure.

## 4. Select the Enchantments

### Thunder-Conducting Inscription +1

- Minimum Grade: Spiritual Treasure
- Equivalent Bonus: +1
- Sphere Influences: Lightning, Thunder, Storm
- Material Compatibility: Storm Iron is a preferred material

Whenever the weapon hits, it deals an additional `1d4` lightning damage. Against a target wearing metal armor or made primarily of metal, this becomes `1d6`.

### Flying Sword Command +2

- Minimum Grade: Saint Treasure
- Equivalent Bonus: +2
- Sphere Influences: Telekinesis, Weapons, Space
- Chassis Compatibility: A jian can be released and remotely directed as a flying weapon
- Material Compatibility: Storm Iron is not a preferred material, but it is not opposed; no stabilizer is required

As a Bonus Action, the wielder can release the jian to hover. Its attacks can originate from its space, and it can move before or after each attack as defined by the enchantment.

### Capacity Check

| Enchantment | Value |
|---|---:|
| Thunder-Conducting Inscription | +1 |
| Flying Sword Command | +2 |
| **Total Enchantment Value** | **+3** |

The Saint Treasure capacity is +3, so the construction is legal.

## 5. Calculate the Final Weapon

- Refinement Bonus: +2
- Total Enchantment Value: +3
- Total Effective Bonus: +5
- Attunement Slots: 1
- Final Grade: Saint Treasure

## Final Item Entry

### Storm-Iron Flying Thunder Jian +2
*Weapon (Jian), Saint Treasure, Requires Attunement*

**Weapon Chassis:** Jian — Straight Sword  
**Primary Material:** Storm Iron  
**Refinement Bonus:** +2 to attack and damage rolls  
**Enchantments:** Thunder-Conducting Inscription (+1), Flying Sword Command (+2)  
**Total Enchantment Value:** +3  
**Total Effective Bonus:** +5  
**Attunement Slots:** 1

You gain a **+2 bonus to attack and damage rolls** made with this weapon.

The jian deals `1d8` piercing or slashing damage, or `1d10` when wielded with two hands, before adding the attack's normal ability modifier and its +2 Refinement Bonus.

**Residual Charge.** Whenever the jian hits, the target takes 1 additional lightning damage. If the target is wearing metal armor or is made primarily of metal, it takes 2 additional lightning damage instead.

**Thunder-Conducting Inscription.** Whenever the jian hits, the target takes an additional `1d4` lightning damage. If the target is wearing metal armor or is made primarily of metal, the additional damage becomes `1d6`.

**Flying Sword Command.** As a Bonus Action while the jian is in your hand, you can release it to hover in an unoccupied space within 5 feet. It remains hovering until you recall it as a Bonus Action, become Incapacitated, end your Attunement, or it moves more than 60 feet from you.

While the jian hovers within 60 feet, you are considered to be wielding it, and one of your hands remains occupied for rules purposes. Whenever you make an attack with the jian, the attack can originate from the jian's space. Before or after each such attack, move it up to 30 feet through unoccupied spaces.

The jian cannot pass through Total Cover and falls in its space if this enchantment ends.

### Example Damage

Against an ordinary target, a one-handed hit deals:

> `1d8 + ability modifier + 2` piercing or slashing damage  
> plus `1` lightning damage from Storm Iron  
> plus `1d4` lightning damage from Thunder-Conducting Inscription

Against a target wearing metal armor or made primarily of metal, the same hit deals:

> `1d8 + ability modifier + 2` piercing or slashing damage  
> plus `2` lightning damage from Storm Iron  
> plus `1d6` lightning damage from Thunder-Conducting Inscription

All three damage components apply on every qualifying hit.

---

# Blank Weapon Construction Worksheet

## Concept

**Weapon Name:**  
**Intended Grade:**  
**Intended Dao or Combat Role:**  

## Step 1 — Weapon Type

**Legal Profile:**  
**Category:**  
**Proficiency:**  
**Base Damage:**  
**Properties:**  
**Tags:**  
**Specialist Sphere:**  

## Step 2 — Primary Material

**Material:**  
**Material Grade:**  
**Normal Ceiling:**  
**Affinities:**  
**Material Property:**  
**Preferred Enchantments:**  
**Opposed Enchantments:**  
**Required Stabilizer, if any:**  

## Step 3 — Grade

**Finished Grade:**  
**Refinement Bonus:**  
**Enchantment Capacity:**  
**Ceiling Check:**  

## Step 4 — Enchantments

| Enchantment | Minimum Grade | Equivalent Bonus | Chassis Legal? | Material Compatible? |
|---|---|---:|---|---|
|  |  |  |  |  |

**Total Enchantment Value:**  

## Step 5 — Final Calculation

**Refinement Bonus:**  
**Total Enchantment Value:**  
**Total Effective Bonus:**  
**Attunement Slots:**  
**Final Attack and Damage Bonus:**  

---

# Legal Weapon Chassis Rules

## Required Weapon Record

Every finished weapon must state:

- common and cultural name;
- legal weapon profile;
- weapon category;
- proficiency class;
- base damage die;
- base damage type;
- handedness and range;
- ordinary weapon properties;
- weapon tags;
- specialist-Sphere overlap, when relevant;
- Primary Material;
- Refinement Bonus;
- enchantments and Equivalent Bonuses.

## Weapon Categories

| Category | General Role |
|---|---|
| **Short Weapons** | One-handed, concealed, paired, defensive, or close-combat implements |
| **Long Weapons** | Reach, formation control, sweeping arcs, thrusting lines, and heavy leverage |
| **Soft Weapons** | Flexible trajectories, binding, unusual reach, flowing attacks, and specialist handling |
| **Projectile and Throwing Weapons** | Ranged attacks, ammunition, thrown implements, marks, and concealed projectiles |

## Proficiency and Enchantments

An enchanted weapon does not grant proficiency with its chassis unless its own rules explicitly say so.

An enchantment that requires a melee, ranged, thrown, ammunition, Heavy, Light, Reach, Finesse, or Two-Handed weapon checks the chassis after all permanent construction modifications have been applied.

## Hybrid Weapons

A hybrid weapon uses one legal profile for each attack unless its special rule explicitly permits switching profiles. A polearm with a spear point and axe head might use a Spear profile for a thrust and an Axes-compatible profile for a hewing technique.

The same attack cannot claim two chassis profiles merely to collect extra benefits.

## Primary Materials

A Primary Material normally preserves the chassis’s base damage die and properties. A material changes those statistics only when its own property explicitly says so.

## Enchantments

Enchantments add supernatural behavior. They do not silently alter the chassis.

Examples:

- Returning Inscription requires a thrown attack or another legal method of launching the weapon.
- Flying Sword Command can make a melee weapon attack from the hovering weapon’s space, but it does not transform the chassis into a bow.
- Pursuing-Star benefits a ranged weapon, thrown weapon, or a weapon with another property that gives it a ranged attack.
- Long-Reach modifies a melee chassis rather than creating an undefined weapon type.

---

# Legal Weapon Profiles

## Short Weapons

### Jian (劍) - Straight Sword
**Weapon Family:** Short / Balanced Blade Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Piercing or Slashing  
**Properties:** Finesse, Versatile 1d10, Balanced Edge Method  
**Weapon Tags:** Cut, Thrust, Guard, Duel  

The classic straight, double-edged sword. Sword sphere remains the specialist home for jian mastery; Weapons sphere treats it as a precise balanced blade.

---

### Duan Jian (短劍) - Short Sword
**Weapon Family:** Short / Concealed Blade Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d6 Piercing or Slashing  
**Properties:** Finesse, Light, Concealed Method  
**Weapon Tags:** Cut, Thrust, Guard, Hidden  

A shorter jian used as a secondary or hidden weapon.

---

### Dao (刀) - Saber / Broadsword
**Weapon Family:** Short / Cutting Blade Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Slashing  
**Properties:** Versatile 1d10, Chopping Edge Method  
**Weapon Tags:** Cut, Smash, Guard, Sweep  

A single-edged saber for slashing, cutting, and hacking.

---

### Duan Dao (短刀) - Short Saber
**Weapon Family:** Short / Thrown Blade Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d6 Slashing  
**Properties:** Light, Thrown 20/60, Paired Method  
**Weapon Tags:** Cut, Cast, Hidden  

A shorter saber that may be thrown or used in pairs.

---

### Hu Die Dao (蝴蝶刀) - Butterfly Sabers
**Weapon Family:** Short / Paired Saber Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d6 Slashing  
**Properties:** Finesse, Light, Paired, Guarding Hilt Method  
**Weapon Tags:** Cut, Guard, Bind, Paired  

Paired sabers with protective guards, suitable for cuts, traps, and close defense.

---

### Gou / Shuang Gou (钩 / 双钩) - Hook Sword / Double Hooks
**Weapon Family:** Short / Hooking Blade Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d6 Slashing  
**Properties:** Finesse, Hooking, Paired, Special Method  
**Weapon Tags:** Hook, Bind, Cut, Disarm  

Hook swords used for catching, disarming, linking, and unusual paired attacks.

---

### Fu (斧) - Short Axe
**Weapon Family:** Short / Axe Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d6 Slashing  
**Properties:** Light, Thrown 20/60, Armor-Breaking Method  
**Weapon Tags:** Smash, Cut, Cast  

A compact axe, often paired, brutal against armor and shields but less precise than a sword.

---

### Tie Jian (鐵鐧) - Iron Rod / Sword Breaker
**Weapon Family:** Short / Bar Mace Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Bludgeoning  
**Properties:** Sword-Breaker, Heavy-Headed Method  
**Weapon Tags:** Smash, Bind, Break  

A plain iron bar mace used to batter, parry, and damage weapons.

---

### Tie Bian (鐵鞭) - Iron Whip / Sectioned Bar Mace
**Weapon Family:** Short / Bar Mace Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Bludgeoning  
**Properties:** Sword-Breaker, Heavy-Headed, Ribbed Method  
**Weapon Tags:** Smash, Bind, Break  

A rigid bamboo-section-style iron mace, not the flexible chain whip.

---

### Chui (锤) - Hammer
**Weapon Family:** Short / Heavy Mace Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Bludgeoning  
**Properties:** Heavy-Headed, Strength 13 Method  
**Weapon Tags:** Smash, Break, Guard  

A round hammer, often paired by very strong warriors.

---

### Tie Chi (铁尺) - Iron Ruler
**Weapon Family:** Short / Officer Weapon Proficiency  
**Proficiency Class:** Simple or martial melee  
**Base Damage:** 1d6 Bludgeoning  
**Properties:** Finesse, Nonlethal, Disarming Method  
**Weapon Tags:** Guard, Bind, Disarm  

A flat metal ruler used by guards and officers for restraint and disabling.

---

### Bi Shou (匕首) - Dagger
**Weapon Family:** Short / Concealed Blade Proficiency  
**Proficiency Class:** Simple melee  
**Base Damage:** 1d4 Piercing or Slashing  
**Properties:** Finesse, Light, Thrown 20/60, Concealed Method  
**Weapon Tags:** Thrust, Cast, Hidden  

A common dagger, easily hidden and often carried in pairs.

---

### Zi-Wu (子午) - Deer Horn Knives
**Weapon Family:** Short / Crescent Knives Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d4 Slashing  
**Properties:** Finesse, Light, Paired, Disarming, Hooking Method  
**Weapon Tags:** Hook, Bind, Cut, Disarm  

Overlapping crescent blades used for seizing, cutting, hooking, and disarming.

---

### Emei Ci (峨嵋刺) - Emei Piercers
**Weapon Family:** Short / Piercing Rods Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d4 Piercing  
**Properties:** Finesse, Light, Concealed, Paired, Spinning Method  
**Weapon Tags:** Thrust, Hidden, Bind  

Palm-hidden spinning piercers associated with Mount Emei.

---

## Long Weapons

### Qiang (枪) - Spear
**Weapon Family:** Long / Spear Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Piercing  
**Properties:** Reach, Two-Handed, Tassel Method  
**Weapon Tags:** Thrust, Guard, Pin  

The Chinese spear. Spear sphere remains the specialist home for spear mastery.

---

### Mao (矛) - Long Spear / Lance
**Weapon Family:** Long / Armor-Piercing Spear Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d10 Piercing  
**Properties:** Reach, Heavy, Two-Handed, Mounted Method  
**Weapon Tags:** Thrust, Pin, Break  

A very long spear or lance suited to armor-piercing thrusts and cavalry or formation work.

---

### Gun (棍) - Staff
**Weapon Family:** Long / Staff Proficiency  
**Proficiency Class:** Simple melee  
**Base Damage:** 1d8 Bludgeoning  
**Properties:** Two-Handed, Reach, Nonlethal Method  
**Weapon Tags:** Guard, Sweep, Smash  

The staff, grandfather of weapons, strong for defense, leverage, and nonlethal control.

---

### Guandao / Yanyuedao (关刀 / 偃月刀) - Reclining Moon Blade
**Weapon Family:** Long / Heavy Polearm Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d10 Slashing  
**Properties:** Reach, Heavy, Two-Handed, Sweeping Method  
**Weapon Tags:** Cut, Sweep, Smash  

A heavy bladed polearm associated with Guan Yu and battlefield power.

---

### Yue Ya Chan (月牙铲) - Crescent Moon Spade / Monk Spade
**Weapon Family:** Long / Spade Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d8 Slashing or Bludgeoning  
**Properties:** Reach, Two-Handed, Hooking, Sweeping Method  
**Weapon Tags:** Hook, Sweep, Guard  

A Shaolin-associated traveling spade with crescent and spade ends.

---

### Cha / Hu Cha (叉 / 虎叉) - Fork / Tiger Fork
**Weapon Family:** Long / Trident Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Piercing  
**Properties:** Reach, Two-Handed, Pinning Method  
**Weapon Tags:** Pin, Thrust, Bind  

A hunting and guard weapon used to pin, hold, and restrain.

---

### Duan Cha (短叉) - Short Trident
**Weapon Family:** Short / Fork Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d6 Piercing  
**Properties:** Light, Thrown 20/60, Pinning Method  
**Weapon Tags:** Pin, Thrust, Cast  

A lighter short fork, sometimes thrown or used in pairs.

---

### Ji (戟) - Halberd
**Weapon Family:** Long / Halberd Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d10 Piercing or Slashing  
**Properties:** Reach, Heavy, Two-Handed, Hooking Method  
**Weapon Tags:** Thrust, Hook, Cut  

A halberd with spear and crescent-hook forms, good for thrusting and pulling.

---

### Ge (戈) - Dagger-Axe
**Weapon Family:** Long / Hooking Polearm Proficiency  
**Proficiency Class:** Martial melee  
**Base Damage:** 1d8 Slashing  
**Properties:** Reach, Two-Handed, Hooking, Pulling Method  
**Weapon Tags:** Hook, Cut, Sweep  

An older L-shaped polearm used for hooking, cutting, and dragging enemies from position.

---

## Soft Weapons

### Sheng Biao (绳镖) - Rope Dart
**Weapon Family:** Soft / Rope Projectile Proficiency  
**Proficiency Class:** Exotic martial ranged/melee  
**Base Damage:** 1d4 Piercing  
**Properties:** Reach 15, Finesse, Two-Handed, Returning Line, Special Method  
**Weapon Tags:** Cast, Bind, Flow  

A dart attached to a rope, thrown and retrieved along a controlled line.

---

### Liu Xing Chui (流星錘) - Meteor Hammer
**Weapon Family:** Soft / Chain Weight Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d6 Bludgeoning  
**Properties:** Reach 15, Two-Handed, Heavy-Headed, Flexible, Special Method  
**Weapon Tags:** Smash, Flow, Sweep  

A weighted chain weapon thrown in arcs to smash poorly defended targets.

---

### Jie Bian (节鞭) - Sectional Steel Whip / Chain Whip
**Weapon Family:** Soft / Chain Whip Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d6 Bludgeoning or Slashing  
**Properties:** Reach 10, Flexible, Finesse, Special Method  
**Weapon Tags:** Flow, Bind, Sweep  

A flexible whip of short metal sections, hard to master and dangerous in motion.

---

### San Jie Gun (三節棍) - Three-Sectional Staff
**Weapon Family:** Soft / Sectional Staff Proficiency  
**Proficiency Class:** Exotic martial melee  
**Base Damage:** 1d8 Bludgeoning  
**Properties:** Two-Handed, Flexible, Variable Reach, Special Method  
**Weapon Tags:** Guard, Flow, Sweep, Smash  

Three linked staves able to shift between short and long range.

---

## Projectile and Throwing Weapons

### Gong Jian (弓箭) - Bow and Arrow
**Weapon Family:** Projectile / Bow Proficiency  
**Proficiency Class:** Martial ranged  
**Base Damage:** 1d8 Piercing  
**Properties:** Ammunition, Range 150/600, Two-Handed Method  
**Weapon Tags:** Cast, Mark  

A bow and arrow. Sniper sphere remains the specialist home for precision archery.

---

### Nu Gong (弩弓) - Crossbow
**Weapon Family:** Projectile / Crossbow Proficiency  
**Proficiency Class:** Martial ranged  
**Base Damage:** 1d10 Piercing  
**Properties:** Ammunition, Range 100/400, Loading, Two-Handed Method  
**Weapon Tags:** Cast, Mark, Break  

A crossbow, powerful but slower to reload.

---

### Dan Gong (弹弓) - Pellet Bow / Sling Bow
**Weapon Family:** Projectile / Pellet Bow Proficiency  
**Proficiency Class:** Simple ranged  
**Base Damage:** 1d4 Bludgeoning  
**Properties:** Ammunition, Range 30/120, Quiet Method  
**Weapon Tags:** Cast, Hidden  

A pellet bow or slingshot-style weapon, often used for small game and subtle strikes.

---

### Fei Biao (飞镖) - Flying Dart
**Weapon Family:** Projectile / Throwing Dart Proficiency  
**Proficiency Class:** Simple ranged or melee  
**Base Damage:** 1d4 Piercing  
**Properties:** Thrown 20/60, Concealed, Poison-Ready Method  
**Weapon Tags:** Cast, Hidden  

A small thrown dart with needle-like point, often concealed and sometimes poisoned.

---

### Tong Zhu (铜箸) - Brass Chopsticks
**Weapon Family:** Projectile / Improvised Dart Proficiency  
**Proficiency Class:** Simple ranged  
**Base Damage:** 1d4 Piercing  
**Properties:** Thrown 20/60, Concealed, Improvised-Familiar Method  
**Weapon Tags:** Cast, Hidden  

Metal chopsticks used as surprise projectiles; bamboo versions require greater power or technique.

---
# Weapon-Type Compatibility Tags

For item construction, use these compatibility tags in addition to the weapon’s printed properties.

| Compatibility Tag | Chassis Requirement |
|---|---|
| **Any Weapon** | Any legal weapon profile |
| **Melee Weapon** | A profile classified as melee |
| **Ranged Weapon** | A profile classified as ranged |
| **Thrown Weapon** | A profile with the Thrown property |
| **Ammunition Weapon** | A profile using Ammunition |
| **Short Weapon** | A profile in the Short Weapons category |
| **Long Weapon** | A profile in the Long Weapons category |
| **Soft Weapon** | A profile in the Soft Weapons category |
| **Projectile Weapon** | A profile in the Projectile and Throwing Weapons category |
| **Concealable Weapon** | A profile with the Hidden or Concealed method/tag |
| **Paired Weapon** | A profile with the Light or Paired property and a legal paired construction |
| **Reach Weapon** | A profile with Reach, or a property that explicitly grants Reach |
| **Heavy Weapon** | A profile with Heavy or an explicit heavy-head construction |
| **Armor-Breaking Weapon** | A profile with Armor-Breaking, Sword-Breaker, Heavy-Headed, Smash, or equivalent printed support |
| **Specialist Weapon** | A profile whose deeper techniques are owned by Sword, Spear, Axes, Sabers, Chains, Sniper, Dual Wielding, or another specialist Sphere |

# New or Regional Weapons

A new weapon can enter the Item Book only after receiving a complete legal profile with:

- family;
- proficiency class;
- damage die and type;
- properties;
- tags;
- special rule;
- specialist boundary note.

Until that profile exists, use the nearest legal chassis rather than inventing statistics during play.


## Chapter 2B: Primary Weapon Materials
### Production Catalog v0.2 — Ordered Weapon-Creation Baseline

A cultivation weapon begins with matter.

Its enchantments determine what supernatural techniques it can perform, but its primary material determines what the weapon naturally conducts, resists, amplifies, and rejects. A weapon forged from storm iron should not behave like one carved from enlightenment wood, even before either weapon receives a formal inscription.

Primary materials are therefore mechanical components, not decorative descriptions.

This is the **second** stage of weapon construction.

1. Select a legal weapon chassis in **Chapter 2A: Weapon Chassis and Creating a Weapon**.
2. Select the Primary Material in this chapter.
3. Add enchantments from **Chapter 2C: Weapon Enchantments**.

The worked example in Chapter 2A demonstrates the complete sequence.

---

# Material Construction Rules

## Primary Material

Every cultivation weapon has one **Primary Material**.

The Primary Material grants:

- one inherent material property;
- one or more affinity tags;
- a normal refinement ceiling;
- preferred enchantment families;
- any opposed enchantments or stabilizer requirements;
- its durability and repair profile.

The Primary Material’s inherent property does not consume Equivalent Bonus.

## Secondary Materials

A weapon can include one or more Secondary Materials as part of its formula.

A Secondary Material normally does one of the following:

- stabilizes an opposed enchantment;
- provides a required catalyst;
- permits an unusual weapon chassis;
- supports an item spirit;
- raises the weapon’s refinement ceiling;
- qualifies the weapon for a specific growth path.

A Secondary Material does not grant its full inherent property unless the finished weapon explicitly says it does.

## Material Grade and Refinement Ceiling

A material’s grade represents the highest finished weapon grade it can normally support without extraordinary intervention.

| Material Grade | Normal Refinement Ceiling |
|---|---|
| Mortal Material | Spiritual Treasure |
| Spiritual Material | Saint Treasure |
| Saint Material | Sovereign Treasure |
| Sovereign Material | Imperial Treasure |
| Imperial Material | Immortal Artifact |
| Immortal Material | Bespoke |

A weapon can exceed its material’s normal ceiling only through a special formula, rare stabilizer, growth-vessel structure, item spirit, tribulation refinement, or explicit campaign exception.

## Refinement Bonus

The weapon’s finished grade determines its actual attack and damage bonus.

| Finished Weapon Grade | Refinement Bonus |
|---|---:|
| Spiritual Treasure | **+1** |
| Saint Treasure | **+2** |
| Sovereign Treasure | **+4** |
| Imperial Treasure | **+6** |
| Immortal Artifact | **+8 baseline or bespoke** |

The Primary Material does not replace this bonus. Its property is added separately.

## Material Effects Apply Naturally

Ordinary material effects are not limited to once per turn unless their individual rules say otherwise.

If storm iron adds lightning damage, the lightning is present whenever the weapon strikes. If ghost iron harms incorporeal creatures, it does so on every qualifying hit. Frequency limits are reserved for effects that release a discrete technique, projectile, burst, missile, seal, or other exceptional manifestation.

## Material Affinities

Affinity tags identify what a material supports naturally.

Examples include:

- Air
- Blood
- Dark
- Earth
- Fire
- Force
- Ice
- Light
- Lightning
- Metal
- Moon
- Poison
- Sealing
- Soul
- Space
- Spirit
- Thunder
- Water
- Wood
- Yin
- Yang

An enchantment sharing an affinity with the Primary Material requires no special stabilizer unless its own formula says otherwise.

## Opposed Enchantments

Some materials resist specific enchantment families.

Adding an opposed enchantment requires:

- a formula that explicitly permits the combination;
- one appropriate stabilizing Secondary Material;
- an additional special-component cost equal to 25 percent of the weapon’s base crafting cost.

The opposed enchantment functions normally after the weapon is completed.

## Material Durability

Unless a material says otherwise, a cultivation weapon uses the normal rules for damaging objects.

When a weapon receives a material property that grants Resistance, Immunity, or Advantage on saving throws, that protection applies only to the weapon itself.

## Material Replacement

Replacing a finished weapon’s Primary Material is not a repair. It is a complete reforging project using the weapon’s full grade, time, formula, and material requirements.

Its existing enchantments can be preserved only if the new material is compatible with them and the formula explicitly supports transfer.

---

# Material Cost Guidance

Named materials are special components and are normally required in addition to the ordinary base material value of the finished weapon.

| Material Grade | Typical Special-Component Value |
|---|---:|
| Mortal | 10–50 GT |
| Spiritual | 1–5 Low-Grade Spirit Stones |
| Saint | 1–5 Mid-Grade Spirit Stones |
| Sovereign | 1–5 High-Grade Spirit Stones |
| Imperial | 1–5 Perfect Spirit Stones |
| Immortal | Unique; not assigned a standard market value |

Availability is not guaranteed by possessing the listed value. Saint-grade and higher materials are commonly acquired through harvesting, inheritance, sect requisition, dangerous trade, or exploration.

---

# Mortal Materials

Mortal materials are nonmagical, but a master crafter can use them as the foundation of a Spiritual Treasure.

## Refined Hundred-Fold Steel
**Material Grade:** Mortal  
**Affinities:** Metal, Weapons  
**Normal Ceiling:** Spiritual Treasure  
**Preferred Enchantments:** Universal Refinement, Metal, Guarding  
**Opposed Enchantments:** None

**Material Property — Reliable Edge.** When you roll a 1 on one of the weapon’s normal damage dice, you can reroll that die and must use the new result.

This property applies only to the weapon’s base damage dice, not additional damage from enchantments or other features.

---

## Black Iron
**Material Grade:** Mortal  
**Affinities:** Metal, Earth, Weight  
**Normal Ceiling:** Spiritual Treasure  
**Preferred Enchantments:** Mountain, Suppression, Unbreaking  
**Opposed Enchantments:** Air and delicate Space enchantments

**Material Property — Heavy Construction.** The weapon weighs twice as much as normal.

When the weapon deals damage to an unattended object or structure, add one additional weapon damage die.

A creature with a Strength score below 13 has Disadvantage on attack rolls made with the weapon unless the weapon has the Light property.

---

## Spirit-Beast Bone
**Material Grade:** Mortal  
**Affinities:** Beast, Spirit  
**Normal Ceiling:** Spiritual Treasure  
**Preferred Enchantments:** Spirit, Predator, Poison, Blood  
**Opposed Enchantments:** Fire unless stabilized

**Material Property — Living Grain.** The weapon counts as silvered against creatures whose resistance or immunity is bypassed by silvered weapons.

It also weighs half as much as an equivalent metal weapon.

---

## Cloudwood
**Material Grade:** Mortal  
**Affinities:** Air, Wood, Movement  
**Normal Ceiling:** Spiritual Treasure  
**Preferred Enchantments:** Wind, Returning, Cloud-Riding  
**Opposed Enchantments:** Weight and heavy Earth enchantments

**Material Property — Flexible Balance.** If the weapon has the Two-Handed or Versatile property, drawing or stowing it does not require your free object interaction.

If it is a ranged weapon, its normal range increases by 10 feet.

---

## White Jade Composite
**Material Grade:** Mortal  
**Affinities:** Earth, Spirit, Sealing  
**Normal Ceiling:** Spiritual Treasure  
**Preferred Enchantments:** Sealing, Soul-Guarding, Formation  
**Opposed Enchantments:** Thunder unless stabilized

**Material Property — Stable Inscription Surface.** The first time during a crafting project that an ability check made to inscribe or repair this weapon fails, the crafter can reroll the check and must use the new result.

This property has no effect after the weapon is completed unless it is later repaired or reforged.

---

# Spiritual Materials

## Spirit Iron
**Material Grade:** Spiritual  
**Affinities:** Metal, Qi, Weapons  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Universal Refinement, Meridian-Conducting, Elemental  
**Opposed Enchantments:** None

**Material Property — Qi Conduction.** While wielding the weapon, you can use it as a focus for Sphere actions and treasure activations that require a held focus.

The weapon counts as magical even before it receives an enchantment.

---

## Storm Iron
**Material Grade:** Spiritual  
**Affinities:** Lightning, Thunder, Metal  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Lightning, Thunder, Storm, Magnetism  
**Opposed Enchantments:** Ice unless stabilized

**Material Property — Residual Charge.** Whenever you hit with the weapon, the target takes 1 additional lightning damage.

If the target is wearing metal armor or is made primarily of metal, it takes 2 additional lightning damage instead.

---

## Moon Silver
**Material Grade:** Spiritual  
**Affinities:** Moon, Yin, Light, Reflection  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Yin, Mirror, Illusion, Spirit  
**Opposed Enchantments:** Solar Fire unless stabilized

**Material Property — Pale Reflection.** The weapon sheds Dim Light in a 5-foot radius while drawn unless you suppress or restore the light as a Bonus Action.

Attacks made with the weapon ignore Disadvantage caused solely by dim light or nonmagical darkness.

---

## Sun Copper
**Material Grade:** Spiritual  
**Affinities:** Fire, Yang, Light  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Fire, Radiant, Yang, Vitality  
**Opposed Enchantments:** Yin and Cold unless stabilized

**Material Property — Solar Heat.** Whenever you hit with the weapon, the target takes 1 additional fire damage.

Against an Undead creature, the additional damage becomes radiant damage.

---

## River Jade
**Material Grade:** Spiritual  
**Affinities:** Water, Flow, Movement  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Water, River-Flow, Ice, Movement  
**Opposed Enchantments:** Weight unless stabilized

**Material Property — Flowing Balance.** After you make an attack with the weapon, you can move 5 feet during the same turn without provoking an Opportunity Attack from the target of that attack.

You can use this movement only once during each of your turns.

---

## Thunderwood
**Material Grade:** Spiritual  
**Affinities:** Lightning, Wood, Sound  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Thunder, Lightning, Sound, Spirit  
**Opposed Enchantments:** Rot and Drain unless stabilized

**Material Property — Resonant Strike.** Whenever the weapon scores a Critical Hit, the target takes additional thunder damage equal to your Proficiency Bonus.

The sound is audible out to 100 feet.

---

## Frost Jade
**Material Grade:** Spiritual  
**Affinities:** Ice, Water, Yin  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Cold, Ice, Yin, Preservation  
**Opposed Enchantments:** Fire unless stabilized

**Material Property — Cold Edge.** Whenever you hit with the weapon, the target takes 1 additional cold damage.

The weapon cannot be damaged by ordinary fire or environmental heat.

---

## Spirit Bamboo
**Material Grade:** Spiritual  
**Affinities:** Wood, Air, Spirit  
**Normal Ceiling:** Saint Treasure  
**Preferred Enchantments:** Wind, Spirit, Returning, Sound  
**Opposed Enchantments:** Weight unless stabilized

**Material Property — Hollow Qi Channel.** The weapon weighs half as much as normal.

If the weapon has the Reach property, its Reach increases by 5 feet during your turn only.

---

# Saint Materials

## Mountain-Root Jade
**Material Grade:** Saint  
**Affinities:** Earth, Weight, Suppression  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Mountain-Weight, Chain-Binding, Sovereign Suppression  
**Opposed Enchantments:** Air and teleportation effects unless stabilized

**Material Property — Rooted Impact.** Whenever you hit a Large or smaller creature with the weapon, the target must succeed on a Strength saving throw against your item save DC or be moved 5 feet directly downward if airborne, or 5 feet horizontally away from you if grounded.

A creature that succeeds is immune to this material property until the start of your next turn.

---

## Star Silver
**Material Grade:** Saint  
**Affinities:** Light, Space, Metal  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Pursuing-Star, Returning, Space, Radiant  
**Opposed Enchantments:** Dark unless stabilized

**Material Property — Celestial Trajectory.** Ranged attacks made with the weapon ignore Half Cover.

If the weapon has the Thrown property, its normal and long ranges are doubled.

---

## Dragonfang Ivory
**Material Grade:** Saint  
**Affinities:** Beast, Force, Authority  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Armor-Piercing, Fear, Force, Bloodline  
**Opposed Enchantments:** None

**Material Property — Predatory Penetration.** Attacks made with the weapon ignore Resistance to piercing damage.

If the weapon does not deal piercing damage, it instead deals 1 additional force damage whenever it hits.

---

## Ghost Iron
**Material Grade:** Saint  
**Affinities:** Spirit, Soul, Dark  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Spirit-Striking, Ghost-Slaying, Soul-Locking  
**Opposed Enchantments:** Radiant-Sun unless stabilized

**Material Property — Ethereal Edge.** The weapon can affect creatures on the Ethereal Plane as though they were on your plane, provided they are within the weapon’s normal reach or range.

Whenever you hit an incorporeal creature or an Undead creature, it takes 1 additional psychic damage.

---

## Phoenix-Ash Steel
**Material Grade:** Saint  
**Affinities:** Fire, Yang, Renewal  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Flame-Vein, Solar-Yang, Radiant-Sun, Growth  
**Opposed Enchantments:** Deep Yin unless stabilized

**Material Property — Rekindled Edge.** The weapon has Resistance to all damage dealt to objects.

If the weapon is broken but not disintegrated, placing it in a mundane or magical fire for 8 hours repairs it to full Hit Points.

---

## Voidglass Alloy
**Material Grade:** Saint  
**Affinities:** Space, Sealing, Reflection  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Returning, Void-Nail, Shadow-Passing, Mirror  
**Opposed Enchantments:** Thunder unless stabilized

**Material Property — Folded Reach.** The weapon’s melee reach increases by 5 feet for Opportunity Attacks.

If it is a ranged weapon, its normal range increases by 30 feet instead.

---

## Blood Jade
**Material Grade:** Saint  
**Affinities:** Blood, Vitality, Lineage  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Blood-Drinking, Ancestral Recognition, Life-Burning  
**Opposed Enchantments:** Purification and Radiant unless stabilized

**Material Property — Blood Recognition.** When you attune to the weapon, it records your blood signature.

A creature other than you has Disadvantage on attack rolls made with the weapon until it completes its own Attunement to it.

---

## Deepsea Cold Iron
**Material Grade:** Saint  
**Affinities:** Ice, Water, Pressure  
**Normal Ceiling:** Sovereign Treasure  
**Preferred Enchantments:** Frost-Meridian, Water, Suppression  
**Opposed Enchantments:** Fire unless stabilized

**Material Property — Abyssal Cold.** Whenever you hit with the weapon, the target’s Speed is reduced by 5 feet until the start of your next turn, to a maximum reduction of 15 feet from this material.

A creature immune to cold damage is immune to this Speed reduction.

---

# Sovereign Materials

## Tribulation Steel
**Material Grade:** Sovereign  
**Affinities:** Lightning, Thunder, Tribulation, Growth  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Heaven-Calamity, Tribulation-Tempered Growth, Calamity-Hungry  
**Opposed Enchantments:** None

**Material Property — Calamity Memory.** When you succeed on a saving throw against lightning or thunder damage while wielding the weapon, it becomes charged until the end of your next turn.

While charged, each hit with the weapon deals 1 additional lightning or thunder damage, chosen when the charge is gained.

---

## Five-Phase Alloy
**Material Grade:** Sovereign  
**Affinities:** Fire, Water, Earth, Metal, Wood  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Five-Phase Cycling and any elemental enchantment  
**Opposed Enchantments:** None

**Material Property — Balanced Conduction.** When the weapon is completed, choose acid, cold, fire, lightning, or poison.

The weapon’s base bludgeoning, piercing, or slashing damage can be changed to the selected type whenever you make an attack with it.

You can change the selected type during a Long Rest using Smith’s Tools and one Spirit Shard.

---

## Soul Jade
**Material Grade:** Sovereign  
**Affinities:** Soul, Spirit, Mind  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Soul-Locking, Spirit-Striking, Weapon-Spirit  
**Opposed Enchantments:** Devouring effects unless stabilized

**Material Property — Soul Resonance.** Whenever you hit a creature with Intelligence 4 or higher, the weapon deals 1 additional psychic damage.

The weapon has Advantage on saving throws against possession or hostile item-spirit control.

---

## Heaven-Splitting Stone
**Material Grade:** Sovereign  
**Affinities:** Force, Earth, Penetration  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Armor-Piercing, Heaven-Splitting, Suppression  
**Opposed Enchantments:** Delicate illusion enchantments

**Material Property — Structural Ruin.** Weapon attacks against unattended objects and structures deal double damage.

Against a creature wearing Heavy Armor or possessing Natural Armor of 18 or higher, the weapon deals 2 additional force damage whenever it hits.

---

## Cloud-Void Crystal
**Material Grade:** Sovereign  
**Affinities:** Air, Space, Movement  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Space-Cutting Step, Shadow-Passing, Returning  
**Opposed Enchantments:** Weight unless stabilized

**Material Property — Spatial Lightness.** The weapon weighs nothing while carried by its attuned bearer.

Drawing or stowing it requires no action, and it cannot be disarmed from the bearer unless the bearer is Incapacitated.

---

## Demon-Heart Iron
**Material Grade:** Sovereign  
**Affinities:** Blood, Drain, Dark  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Blood-Drinking, Devouring Furnace, Life-Burning  
**Opposed Enchantments:** Radiant and Purification unless stabilized

**Material Property — Hungry Metal.** Whenever the weapon deals necrotic damage, add your Proficiency Bonus to one necrotic damage roll from that hit.

If the weapon deals no necrotic damage, this property provides no benefit.

---

## Mirror-Sea Silver
**Material Grade:** Sovereign  
**Affinities:** Moon, Mirror, Water, Illusion  
**Normal Ceiling:** Imperial Treasure  
**Preferred Enchantments:** Mirror-Polished Countermark, Moonless-Yin, Reflection  
**Opposed Enchantments:** Thunder unless stabilized

**Material Property — Still Reflection.** While wielding the weapon, you have Advantage on saving throws against illusions.

When you succeed on such a saving throw, you immediately identify the source of the illusion if it is within 60 feet and not behind Total Cover.

---

# Imperial Materials

Imperial materials are not normal commodities. Each supply is typically controlled by a sect, lineage, court, ancient ruin, or singular cultivator.

## Phoenix-Blood Scarlet Gold
**Material Grade:** Imperial  
**Affinities:** Fire, Yang, Renewal, Authority  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Fire, Radiant, Yang, Growth, Weapon Spirit  
**Opposed Enchantments:** Deep Yin unless stabilized by an Imperial material

**Material Property — Phoenix Authority.** Whenever the weapon hits, it deals 2 additional fire damage.

The first time each Long Rest that the weapon would be destroyed, it instead becomes dormant and drops to 1 Hit Point. It regains full Hit Points and ceases to be dormant after remaining in a magical fire for 1 hour.

---

## Heaven-Mark Violet Gold
**Material Grade:** Imperial  
**Affinities:** Dao, Spirit, Inscription, Growth  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Dao-Vessel Foundation, Weapon-Spirit, any coherent Sphere alignment  
**Opposed Enchantments:** None

**Material Property — Natural Dao Surface.** The weapon’s enchantment capacity increases by +1 Equivalent Bonus.

This increase cannot raise an Immortal Artifact beyond a bespoke limit established by its own entry.

---

## Calamity-Tempered Imperial Gold
**Material Grade:** Imperial  
**Affinities:** Tribulation, Lightning, Defense  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Heaven-Calamity, Calamity-Hungry, Guardian-Reversal  
**Opposed Enchantments:** None

**Material Property — Tribulation Guard.** While wielding the weapon, you have Resistance to lightning damage.

If you already have Resistance to lightning damage, you instead reduce lightning damage you take by your Proficiency Bonus after applying Resistance.

---

## Immortal-Tear Verdant Gold
**Material Grade:** Imperial  
**Affinities:** Water, Wood, Sanctuary, Suppression  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Guarding, Sealing, Healing, Sovereign Suppression  
**Opposed Enchantments:** Devouring effects unless stabilized by an Imperial material

**Material Property — Sanctuary Edge.** While wielding the weapon, allied creatures within 5 feet of you have Advantage on saving throws against being Frightened.

The weapon also deals 2 additional radiant damage whenever it hits an Aberration, Fiend, or Undead.

---

## Dragon-Patterned Abyssal Gold
**Material Grade:** Imperial  
**Affinities:** Force, Dragon, Weight, Authority  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Suppression, Force, Fear, Binding  
**Opposed Enchantments:** None

**Material Property — Dragon Pressure.** Whenever the weapon hits a Huge or smaller creature, the creature must succeed on a Strength saving throw against your item save DC or be pushed 5 feet directly away from you.

After a creature succeeds on this saving throw, it is immune to this material property until the start of your next turn.

---

## Feathered Celestial Green Gold
**Material Grade:** Imperial  
**Affinities:** Space, Air, Ascension, Containment  
**Normal Ceiling:** Immortal Artifact  
**Preferred Enchantments:** Space, Movement, Sealing, Flying Weapon  
**Opposed Enchantments:** Weight unless stabilized by an Imperial material

**Material Property — Celestial Passage.** Attacks made with the weapon ignore Three-Quarters Cover.

If the weapon has the Thrown property or is used through a flying-weapon enchantment, its normal and long ranges are tripled.

---

# Immortal Materials

Immortal materials are unique campaign resources. They do not have stable prices, ordinary formulas, or guaranteed properties outside their individual entries.

## Primordial Mother-Weight Essence
**Material Grade:** Immortal  
**Affinities:** Weight, Suppression, Earth, Origin  
**Normal Ceiling:** Bespoke  
**Preferred Enchantments:** Suppression, Dao Vessel, Sealing, Force  
**Opposed Enchantments:** Air and Space unless reconciled by an Immortal formula

**Material Property — One Strand Weighs a Mountain.** Weapon attacks deal 4 additional force damage.

Whenever the weapon hits a Gargantuan or smaller creature, that creature must succeed on a Strength saving throw against your item save DC or be knocked Prone.

After a creature succeeds on this saving throw, it is immune to this material property until the start of your next turn.

A creature with Strength below 20 cannot wield the weapon unless attuned to it.

---

## Origin-Void Copper
**Material Grade:** Immortal  
**Affinities:** Origin, Space, Suppression, Counteraction  
**Normal Ceiling:** Bespoke  
**Preferred Enchantments:** Dao Vessel, Sealing, Anti-Magic, Space  
**Opposed Enchantments:** None

**Material Property — Autonomous Counteraction.** While the weapon is on your person, you have Advantage on saving throws against possession, forced teleportation, and effects that would directly control your actions.

Once per Long Rest, when you fail one of those saving throws, the weapon allows you to reroll it and use either result.

---

## Enlightenment Tree Heartwood
**Material Grade:** Immortal  
**Affinities:** Wood, Dao, Mind, Comprehension  
**Normal Ceiling:** Bespoke  
**Preferred Enchantments:** Spirit, Soul-Guarding, Dao Vessel, Growth  
**Opposed Enchantments:** Devouring and corruption effects unless reconciled by an Immortal formula

**Material Property — Dao-Clarity Grain.** While wielding the weapon, you have Advantage on Intelligence and Wisdom ability checks made to understand inscriptions, formations, cultivation methods, Dao marks, or supernatural materials.

Once per Long Rest, after you fail such a check, you can treat the d20 roll as a 15.

---

## World-Heart Crystal
**Material Grade:** Immortal  
**Affinities:** Space, Growth, World, Formation  
**Normal Ceiling:** Bespoke  
**Preferred Enchantments:** Pocket Domain, Formation, Dao Vessel, Growth  
**Opposed Enchantments:** Destructive Devouring effects unless explicitly integrated

**Material Property — Seeded Domain.** The weapon can serve as the anchor for a demiplane, formation domain, or growth-vessel property.

By itself, this material grants no portable interior space. The exact domain must be defined by a separate Immortal Artifact property with complete mechanics.

The weapon has Immunity to force damage dealt to objects and cannot be teleported against its bearer’s will.

---

# Material and Enchantment Examples

## Storm-Iron Thunder Spear +2
*Weapon (Spear), Saint Treasure, Requires Attunement*

**Primary Material:** Storm Iron  
**Refinement Bonus:** +2 to attack and damage rolls  
**Enchantments:** Thunder-Conducting Inscription (+1), Returning Inscription (+1)  
**Total Enchantment Value:** +2  
**Total Effective Bonus:** +4

**Storm-Iron Property.** Whenever the spear hits, the target takes 1 additional lightning damage, or 2 additional lightning damage if it is wearing metal armor or made primarily of metal.

**Thunder-Conducting Inscription.** Whenever the spear hits, the target takes an additional 1d4 lightning damage. If it is wearing metal armor or made primarily of metal, the additional damage becomes 1d6.

**Returning Inscription.** Immediately after you make a thrown attack with the spear, it returns to your free hand. If you have no free hand, it lands in your space.

---

## Mountain-Root Binding Hammer +4
*Weapon (Warhammer), Sovereign Treasure, Requires Attunement*

**Primary Material:** Mountain-Root Jade  
**Refinement Bonus:** +4 to attack and damage rolls  
**Enchantments:** Chain-Binding Inscription (+2), Mountain-Weight Inscription (+1)  
**Total Enchantment Value:** +3  
**Total Effective Bonus:** +7

**Mountain-Root Property.** Whenever the hammer hits a Large or smaller creature, it must succeed on a Strength saving throw against your item save DC or be moved 5 feet horizontally away from you. After a creature succeeds, it is immune to this property until the start of your next turn.

**Mountain-Weight Inscription.** Whenever the hammer hits, the target takes an additional 1d4 force damage, or 1d8 if the target is Large or larger, an unattended object, or a structure.

**Chain-Binding Inscription.** When the hammer hits a Large or smaller creature, you can spend 1 CP to force it to make a Strength saving throw against your item save DC. On a failure, its Speed becomes 0 until the start of your next turn.

---

# Final Weapon Requirements

Every finished cultivation weapon must state:

- legal weapon chassis selected from Chapter 2A;
- Primary Material;
- the material’s full inherent property;
- finished treasure grade;
- explicit Refinement Bonus;
- every enchantment selected from Chapter 2C and its Equivalent Bonus;
- Total Enchantment Value;
- Total Effective Bonus;
- preferred or opposed material interactions relevant to the finished construction;
- every action, trigger, save, range, duration, cost, and recovery rule;
- factory and GM Screen action rows.

A material name never substitutes for its mechanical property.


## Chapter 2C: Weapon Enchantments
### Production Catalog v0.9 — Ordered Weapon-Creation Baseline

Weapon enchantments are inscriptions, tempers, seals, embedded cores, refined Dao marks, and other supernatural modifications added after a weapon’s chassis and primary material have been selected.

An enchantment should reinforce the weapon’s material and intended Dao principle. Materials determine what a weapon conducts, resists, amplifies, or rejects. Enchantments give that foundation explicit supernatural functions.

Every enchantment in this chapter uses closed D&D 5.5e mechanics. An enchantment name or Dao description never substitutes for its action, trigger, target, saving throw, duration, or resource rules.

**Sphere Influences** identify the Tianxia Spheres that most directly inspire an enchantment’s mechanical expression. They are design and compatibility tags, not automatic prerequisites.

This is the **third** stage of weapon construction.

1. Select the weapon chassis in **Chapter 2A**.
2. Select the Primary Material in **Chapter 2B**.
3. Use this chapter to fill the weapon's enchantment capacity.

The complete Storm-Iron Flying Thunder Jian example appears in Chapter 2A.

---

# Weapon Construction

A finished cultivation weapon normally consists of:

> **Weapon Chassis + Primary Material + Refinement Bonus + Enchantments**

- **Weapon Chassis** supplies the base weapon statistics.
- **Primary Material** supplies its inherent material property and affinities.
- **Refinement Bonus** is the actual bonus to attack and damage rolls.
- **Enchantments** add special abilities and consume enchantment capacity.

## Weapon Chassis and Type Compatibility

Before choosing a Primary Material or enchantment, select one legal weapon profile from **Chapter 2A: Weapon Chassis and Creating a Weapon**.

Every enchantment is compatible only with a chassis capable of delivering its effect.

Use the following default interpretations:

- **Any Weapon** means any legal weapon profile.
- **Melee Weapon** means a profile classified as a melee weapon.
- **Ranged Weapon** means a profile classified as a ranged weapon.
- **Thrown Weapon** requires the Thrown property or another explicit method of throwing the weapon.
- **Projectile Weapon** means a bow, crossbow, pellet bow, dart, or another legal projectile profile.
- **Soft Weapon** means a rope dart, meteor hammer, sectional whip, three-sectional staff, or another legal flexible profile.
- **Reach Weapon** requires Reach or an explicit effect that grants Reach.
- **Paired Weapon** requires a legal paired profile or two weapons that qualify for the campaign’s two-weapon rules.
- **Flying Weapon** requires Flying Sword Command or another effect that explicitly allows remote weapon attacks.

An enchantment does not grant proficiency, ammunition, range, Reach, thrown capability, or a second weapon profile unless its rules explicitly say so.

A hybrid weapon chooses which legal chassis profile it uses for each attack. One attack cannot use multiple profiles merely to satisfy several enchantment prerequisites.

## Refinement Bonus: Actual Attack and Damage

Every completed cultivation weapon states its actual bonus to attack and damage rolls.

| Finished Weapon Grade | Refinement Bonus |
|---|---:|
| Spiritual Treasure | **+1** |
| Saint Treasure | **+2** |
| Sovereign Treasure | **+4** |
| Imperial Treasure | **+6** |
| Immortal Artifact | **+8 baseline or bespoke** |

The Refinement Bonus is the only grade-derived number added directly to attack and damage rolls.

Example:

> You gain a **+2 bonus to attack and damage rolls** made with this Saint Treasure weapon.

## Equivalent Bonus: Enchantment Capacity

Every enchantment has an **Equivalent Bonus**, written as **+1, +2, +3, or +4**.

The Equivalent Bonus:

- measures the enchantment’s mechanical strength;
- counts against the weapon’s enchantment capacity;
- helps determine crafting requirements and final treasure value;
- must be printed in the weapon’s construction record;
- does **not** add to attack or damage rolls unless the enchantment’s own rules explicitly say it does.

This follows the familiar logic of an “equivalent enhancement bonus”: the number represents special-ability value, not an additional accuracy bonus.

### Enchantment Capacity

| Finished Weapon Grade | Maximum Total Equivalent Bonus |
|---|---:|
| Spiritual Treasure | **+1** |
| Saint Treasure | **+3** |
| Sovereign Treasure | **+6** |
| Imperial Treasure | **+10** |
| Immortal Artifact | **Bespoke; normally +12 or higher, including +5 and +6 Immortal enchantments** |

Add together the Equivalent Bonuses of every enchantment on the weapon. The result cannot exceed the weapon’s capacity unless a unique material, growth-vessel rule, item spirit, dangerous flaw, or explicit campaign exception increases it.

### Total Effective Bonus

For crafting and treasure comparison, a weapon’s **Total Effective Bonus** equals:

> **Refinement Bonus + Total Equivalent Bonus**

A Saint Treasure weapon with a +2 Refinement Bonus, a +1 Returning Inscription, and a +2 Armor-Piercing Dao Mark has:

- actual attack and damage bonus: **+2**;
- total enchantment value: **+3**;
- Total Effective Bonus: **+5**.

The weapon does not gain +5 to attack and damage. It gains +2 to attack and damage and carries +3 worth of special abilities.

## Minimum Grade

Minimum Grade remains a separate restriction. Meeting an enchantment’s Equivalent Bonus cost does not allow a lower-grade weapon to carry an inscription whose minimum grade it does not meet.

## Save DCs and Item Attacks

When an enchantment refers to **your item save DC**, use:

**8 + your Proficiency Bonus + your Path key ability modifier**

When it refers to an **item attack**, use:

**your Proficiency Bonus + your Path key ability modifier**

An independent or disposable weapon may instead list a fixed DC or attack modifier.

## Persistent and Discrete Enchantments

An ordinary weapon enchantment functions on **every qualifying hit** unless its own rules explicitly say otherwise.

Elemental damage, spirit damage, armor penetration, healing prevention, and similar persistent properties are part of the weapon’s normal behavior. If a weapon carries several compatible damage enchantments, each enchantment applies to the same hit and consumes its full Equivalent Bonus as normal.

Frequency limits are reserved for **discrete manifestations**, such as:

- firing a separate missile or sword-light projectile;
- releasing an area burst;
- creating a seal or binding technique;
- triggering a major defensive reversal;
- activating an item-spirit Instinct;
- producing an effect whose repeated resolution would require excessive saving throws.

When repetition must be controlled, use an explicit Action, Bonus Action, Reaction, CP cost, charge cost, successful-save immunity window, or other printed limit. Do not apply a blanket once-per-turn restriction to ordinary enchantment behavior.

## Material Affinities

Each enchantment lists preferred material affinities. A preferred material satisfies ordinary compatibility, avoids a stabilizing-component requirement, and can support later refinements of the same principle.

A mismatched material can be used only when the formula permits it and supplies an appropriate stabilizer.

---

# Enchantment Summary by Equivalent Bonus

| Value | Enchantment | Minimum Grade | Family |
|---:|---|---|---|
| **+1** | Returning Inscription | Spiritual Treasure | Universal Refinement |
| **+1** | Unbreaking Temper | Spiritual Treasure | Universal Refinement |
| **+1** | Meridian-Conducting Channels | Saint Treasure | Universal Refinement |
| **+1** | Flame-Vein Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Frost-Meridian Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Thunder-Conducting Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Gale-Edge Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Mountain-Weight Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | River-Flow Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Venom-Bloom Inscription | Saint Treasure | Elemental and Natural |
| **+1** | Cloud-Riding Inscription | Saint Treasure | Defensive and Mobility |
| **+1** | Pursuing-Star Inscription | Saint Treasure | Defensive and Mobility |
| **+1** | Ghost-Slaying Inscription | Spiritual Treasure | Spirit, Soul, and Awakening |
| **+1** | Soul-Guarding Inscription | Saint Treasure | Spirit, Soul, and Awakening |
| **+1** | Balanced-Grip Inscription | Spiritual Treasure | Universal Refinement |
| **+1** | Hidden-Sheath Inscription | Spiritual Treasure | Utility and Concealment |
| **+1** | Long-Reach Inscription | Spiritual Treasure | Universal Refinement |
| **+1** | Stonebreaker Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Beast-Hunter Inscription | Spiritual Treasure | Hunting and Pursuit |
| **+1** | Blood-Scent Tracking Mark | Spiritual Treasure | Hunting and Pursuit |
| **+1** | Soundless Edge Inscription | Spiritual Treasure | Utility and Concealment |
| **+1** | Talisman Channel Groove | Spiritual Treasure | Talisman and Technique Conduction |
| **+1** | Formation-Sundering Inscription | Spiritual Treasure | Anti-Formation |
| **+1** | Water-Cutting Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Wood-Severing Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Corrosion-Vein Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Resonant-Sound Inscription | Spiritual Treasure | Elemental and Natural |
| **+1** | Dream-Piercing Inscription | Spiritual Treasure | Spirit, Soul, and Awakening |
| **+1** | Phasing Edge Inscription | Spiritual Treasure | Universal Refinement |
| **+1** | Harvesting Edge Inscription | Spiritual Treasure | Crafting and Harvesting |
| **+1** | Qi-Sensing Inscription | Spiritual Treasure | Detection and Appraisal |
| **+1** | Light-Bearing Inscription | Spiritual Treasure | Utility and Detection |
| **+1** | Poison-Shedding Temper | Spiritual Treasure | Defensive and Utility |
| **+1** | Gravity-Hook Inscription | Spiritual Treasure | Control, Sealing, and Suppression |
| **+2** | Armor-Piercing Dao Mark | Saint Treasure | Universal Refinement |
| **+2** | Radiant-Sun Inscription | Saint Treasure | Elemental and Natural |
| **+2** | Moonless-Yin Inscription | Saint Treasure | Elemental and Natural |
| **+2** | Solar-Yang Inscription | Saint Treasure | Elemental and Natural |
| **+2** | Five-Phase Cycling Inscription | Sovereign Treasure | Elemental and Natural |
| **+2** | Chain-Binding Inscription | Saint Treasure | Control, Sealing, and Suppression |
| **+2** | Meridian-Sealing Point | Saint Treasure | Control, Sealing, and Suppression |
| **+2** | Silent-Heaven Inscription | Saint Treasure | Control, Sealing, and Suppression |
| **+2** | Void-Nail Inscription | Sovereign Treasure | Control, Sealing, and Suppression |
| **+2** | Soul-Locking Inscription | Sovereign Treasure | Control, Sealing, and Suppression |
| **+2** | Guardian-Reversal Inscription | Saint Treasure | Defensive and Mobility |
| **+2** | Mirror-Polished Countermark | Sovereign Treasure | Defensive and Mobility |
| **+2** | Shadow-Passing Inscription | Sovereign Treasure | Defensive and Mobility |
| **+2** | Spirit-Striking Inscription | Saint Treasure | Spirit, Soul, and Awakening |
| **+2** | Weapon-Spirit Seed | Sovereign Treasure | Spirit, Soul, and Awakening |
| **+2** | Ancestral Recognition Seal | Sovereign Treasure | Spirit, Soul, and Awakening |
| **+2** | Tribulation-Tempered Growth | Saint Treasure | Growth and Forbidden |
| **+2** | Blood-Drinking Inscription | Saint Treasure | Growth and Forbidden |
| **+2** | Life-Burning Overload | Sovereign Treasure | Growth and Forbidden |
| **+2** | Flying Sword Command | Saint Treasure | Flying Weapons |
| **+2** | Sword-Light Missile Inscription | Saint Treasure | Projectile Techniques |
| **+2** | Blazing Detonation Seal | Saint Treasure | Burst Techniques |
| **+2** | Phasing Strike Inscription | Sovereign Treasure | Universal Refinement |
| **+2** | Qi-Disrupting Dao Mark | Saint Treasure | Control, Sealing, and Suppression |
| **+2** | Vitality-Returning Inscription | Saint Treasure | Defensive and Recovery |
| **+2** | Thousand-Needle Division | Saint Treasure | Projectile Techniques |
| **+2** | Formation-Anchor Breaker | Saint Treasure | Anti-Formation |
| **+2** | Talisman-Launching Groove | Saint Treasure | Talisman and Technique Conduction |
| **+2** | Predator's Pursuit Mark | Saint Treasure | Hunting and Pursuit |
| **+3** | Sovereign Suppression Mark | Sovereign Treasure | Control, Sealing, and Suppression |
| **+3** | Devouring Furnace Mark | Sovereign Treasure | Growth and Forbidden |
| **+3** | Calamity-Hungry Edge | Imperial Treasure | Growth and Forbidden |
| **+4** | Heaven-Splitting Edge | Imperial Treasure | Universal Refinement |
| **+4** | Heaven-Calamity Inscription | Imperial Treasure | Elemental and Natural |
| **+4** | Space-Cutting Step | Imperial Treasure | Defensive and Mobility |
| **+4** | Awakened Weapon Spirit | Imperial Treasure | Spirit, Soul, and Awakening |
| **+4** | Dao-Vessel Foundation | Imperial Treasure | Growth and Forbidden |
| **+3** | Gravitational Prison Seal | Sovereign Treasure | Control, Sealing, and Suppression |
| **+3** | Mirror-Heaven Reversal | Sovereign Treasure | Defensive and Reflection |
| **+3** | Thousand-Li Pursuit Inscription | Sovereign Treasure | Hunting and Pursuit |
| **+4** | Ten-Thousand Sword Domain | Imperial Treasure | Flying Weapons and Domains |
| **+4** | Law-Denying Edge | Imperial Treasure | Anti-Technique and Suppression |
| **+4** | Heaven-Earth Severing Wave | Imperial Treasure | Projectile Techniques |
| **+5** | One Vessel Suppresses Ten Thousand Laws | Immortal Artifact | Dao Vessel and Suppression |
| **+6** | World-Severing Immortal Edge | Immortal Artifact | Immortal Offense |

# +1 Enchantments — Minor Inscriptions

## Returning Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Telekinesis, Space, Weapons  
**Preferred Materials:** Spirit iron, star silver, magnetic stone

Immediately after you make a thrown attack with the weapon, it returns to your hand if you have a free hand. If you do not, it lands in your space.

The weapon cannot return while inside an area that blocks teleportation or extradimensional movement.

---

## Unbreaking Temper
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Metal, Earth, Vitality  
**Preferred Materials:** Spirit iron, mountain jade, black gold

The weapon has Resistance to all damage dealt to objects and Advantage on saving throws against effects that would break, corrode, suppress, or permanently deform it.

If the weapon would be destroyed while it has at least 1 Hit Point, it instead drops to 1 Hit Point. Once this protection functions, it cannot function again until the weapon is repaired during a Long Rest or downtime.

---

## Meridian-Conducting Channels
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Qiweaving, Imbuement, Weapons  
**Preferred Materials:** Spirit jade, conductive metals, beast sinew

You can use the weapon as a focus for Sphere actions and item activations that require a held focus.

Whenever you deal damage with a Sphere action while holding the weapon, you can change one damage type dealt by that action to a damage type produced by another enchantment on the weapon.

This does not change the Sphere action’s other tags or prerequisites.

---

## Flame-Vein Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Fire, Yang, Imbuement  
**Preferred Materials:** Sun copper, phoenix ash, fire beast cores

Whenever you hit with the weapon, the target takes an additional 1d4 fire damage.

You can ignite or extinguish the weapon’s flame as a Bonus Action. While extinguished, this additional damage does not apply.

---

## Frost-Meridian Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Ice, Water, Yin  
**Preferred Materials:** Cold iron, frost jade, glacial crystal

Whenever you hit a creature with the weapon, it takes an additional 1d4 cold damage, and its Speed is reduced by 5 feet until the start of your next turn.

Speed reductions from this enchantment stack to a maximum reduction of 15 feet.

---

## Thunder-Conducting Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Lightning, Thunder, Storm  
**Preferred Materials:** Storm iron, thunderwood, lightning beast cores

Whenever you hit with the weapon, the target takes an additional 1d4 lightning damage.

If the target is wearing metal armor or is made primarily of metal, the additional damage becomes 1d6.

---

## Gale-Edge Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Air, Wind, Movement  
**Preferred Materials:** Wind jade, cloud steel, spirit bamboo

Whenever you hit a Large or smaller creature with the weapon, you can move it 5 feet horizontally to an unoccupied space.

The target can make a Strength saving throw against your item save DC to negate this movement. After a creature succeeds on this saving throw, it is immune to this enchantment until the start of your next turn.

---

## Mountain-Weight Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Earth, Force, Weight  
**Preferred Materials:** Mountain jade, heavy iron, Xuanhuang-infused material

Whenever you hit with the weapon, the target takes an additional 1d4 force damage.

If the target is Large or larger, an unattended object, or a structure, the additional damage becomes 1d8.

---

## River-Flow Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Water, Flowing River, Movement  
**Preferred Materials:** River jade, water silver, spirit reed

After each time you hit a creature with the weapon, you can move up to 5 feet without provoking an Opportunity Attack from that creature.

---

## Venom-Bloom Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Poison, Alchemy, Predator  
**Preferred Materials:** Poison beast fangs, toxic jade, alchemical alloys

Whenever you hit a creature with the weapon, it takes an additional 1d4 poison damage.

A creature immune to the Poisoned condition takes no additional damage from this enchantment unless the finished weapon explicitly overcomes that immunity.

---

## Cloud-Riding Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Air, Wind, Movement  
**Preferred Materials:** Cloud steel, wind jade, crane feather

While wielding the weapon, your Speed increases by 5 feet.

When you take the Dash action, you can move across liquids and vertical surfaces during that movement. If you end the movement without a supporting surface, you fall.

---

## Pursuing-Star Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Light, Space, Ranged Weapons  
**Preferred Materials:** Star silver, sun gold, comet stone

Attacking at long range with the weapon does not impose Disadvantage.

The weapon’s ranged attacks ignore Half Cover.

If the weapon normally lacks a ranged attack, this enchantment has no effect unless combined with Returning Inscription, Flying Sword Command, or another property that gives it one.

---

## Ghost-Slaying Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Spirit, Light, Weapons  
**Preferred Materials:** Peach wood, spirit iron, prayer jade

The weapon can damage creatures on the Ethereal Plane as though they were on your plane, provided they are within the weapon’s normal reach or range.

Whenever you hit an Undead or an incorporeal creature, it takes an additional 1d6 radiant damage.

---

## Soul-Guarding Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Spirit, Protection, Mind  
**Preferred Materials:** Soul jade, bodhi wood, guardian metal

While wielding the weapon, you have Advantage on saving throws against possession and effects that would directly control your actions.

Once per Long Rest, when you fail such a saving throw, you can reroll it and must use the new result.

---


## Balanced-Grip Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Weapons, Athletics, Equipment  
**Preferred Materials:** Spirit iron, cloudwood, beast sinew

While you are conscious and wielding the weapon, it cannot be disarmed from you unless you choose to release it.

Drawing or stowing the weapon does not consume your free object interaction.

---

## Hidden-Sheath Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Utility and Concealment  
**Sphere Influences:** Space, Talismans, Imbuement  
**Preferred Materials:** Voidglass, moon silver, spatial jade

As a Bonus Action, you can transform the weapon into a Tiny ornamental object chosen when the enchantment is created, such as a ring, hairpin, bracelet, belt clasp, or jade token. The transformed weapon weighs 1 ounce and cannot be used to make attacks.

As a Bonus Action, you can return it to its weapon form in your hand. If you have no free hand, it appears in your space.

A creature physically inspecting the ornament can identify it as transformed equipment with a successful Intelligence (Arcana) check against your item save DC.

---

## Long-Reach Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Space, Weapons, Qiweaving  
**Preferred Materials:** Spirit bamboo, voidglass alloy, star silver

If the weapon is a melee weapon, its Reach increases by 5 feet during your turn.

This does not increase the weapon’s Reach for Opportunity Attacks unless another property explicitly says otherwise.

If the weapon already has Reach, this increase stacks with that property.

---

## Stonebreaker Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Earth, Metal, Force  
**Preferred Materials:** Black iron, mountain jade, heaven-splitting stone

Whenever the weapon hits a Construct, an unattended object, or a structure, it deals an additional 1d6 force damage.

The weapon’s attacks against those targets ignore Resistance to bludgeoning, piercing, and slashing damage.

---

## Beast-Hunter Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Hunting and Pursuit  
**Sphere Influences:** Predator, Weapons, Spirit Companions  
**Preferred Materials:** Spirit-beast bone, dragonfang ivory, beast sinew

Whenever the weapon hits a Beast or Monstrosity, it deals an additional 1d4 damage of the weapon’s normal damage type.

You have Advantage on Wisdom (Survival) checks made to track a creature damaged by the weapon within the previous 24 hours.

---

## Blood-Scent Tracking Mark
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Hunting and Pursuit  
**Sphere Influences:** Blood, Predator, Medicine  
**Preferred Materials:** Blood jade, beast fang, crimson steel

When the weapon deals damage to a creature that has blood, you can mark that creature until you mark a different creature or complete a Long Rest.

While the marked creature is within 1 mile and on the same plane, you know its direction but not its exact distance. The mark ends if the creature regains all its Hit Points.

A creature can identify and remove the mark during a Short Rest with a successful Wisdom (Medicine) check against your item save DC.

---

## Soundless Edge Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Utility and Concealment  
**Sphere Influences:** Sound, Dark, Weapons  
**Preferred Materials:** Hush jade, shadow iron, black bamboo

The weapon produces no sound when drawn, moved, or used to make an attack.

An attack made with the weapon does not reveal your location solely through sound. Other evidence, including sight, impact, displaced objects, blood, or visible effects, can still reveal you normally.

---

## Talisman Channel Groove
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Talisman and Technique Conduction  
**Sphere Influences:** Talismans, Imbuement, Weapons  
**Preferred Materials:** White jade, spirit iron, talisman wood

During a Short or Long Rest, you can attach one consumable talisman to the weapon. The talisman remains attached until removed, activated, or destroyed.

While the talisman is attached, you can activate it without holding it in a free hand. Its normal action type, range, targets, save DC, and other rules remain unchanged.

The weapon can hold only one talisman at a time.

---

## Formation-Sundering Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Anti-Formation  
**Sphere Influences:** Formations, Force, Metal  
**Preferred Materials:** Source stone, star iron, formation jade

Whenever the weapon hits a magical barrier, formation anchor, summoned object, or object created by a supernatural effect, it deals an additional 1d6 force damage.

The weapon’s attacks against those targets count as magical and ignore Resistance to the weapon’s bludgeoning, piercing, and slashing damage.

---

## Water-Cutting Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Water, Flowing River, Weapons  
**Preferred Materials:** River jade, deepsea cold iron, water silver

Attacks made with the weapon do not suffer Disadvantage or reduced range from being made underwater.

Whenever the weapon hits a creature that is swimming or fully submerged, it deals an additional 1d4 cold damage.

---

## Wood-Severing Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Metal, Fire, Weapons  
**Preferred Materials:** Refined steel, sun copper, dragonfang ivory

Whenever the weapon hits a Plant creature or a wooden object or structure, it deals an additional 1d6 slashing damage.

The weapon’s attacks against those targets ignore Resistance to slashing damage.

If the weapon normally deals bludgeoning or piercing damage, the additional damage remains slashing damage.

---

## Corrosion-Vein Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Alchemy, Poison, Metal  
**Preferred Materials:** Toxic jade, acid beast gland, alchemical alloy

Whenever the weapon hits, the target takes an additional 1d4 acid damage.

The weapon and its sheath are immune to nonmagical corrosion caused by acid, saltwater, rust, or similar environmental exposure.

---

## Resonant-Sound Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Elemental and Natural  
**Sphere Influences:** Sound, Thunder, Weapons  
**Preferred Materials:** Thunderwood, bronze, resonant crystal

Whenever the weapon hits, the target takes an additional 1d4 thunder damage.

The impact is audible out to 100 feet unless another property suppresses the sound.

---

## Dream-Piercing Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Dreams, Spirit, Dark  
**Preferred Materials:** Dream jade, moon silver, bodhi wood

Whenever the weapon hits a creature that is Charmed, Frightened, Unconscious, or affected by a Dreams Sphere effect, it takes an additional 1d6 psychic damage.

The additional damage is applied before the target makes any saving throw caused by taking damage.

---

## Phasing Edge Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Universal Refinement  
**Sphere Influences:** Phasing, Space, Weapons  
**Preferred Materials:** Ghost iron, voidglass alloy, spatial jade

Attacks made with the weapon ignore Half Cover provided by nonmagical objects and creatures.

The weapon can strike an incorporeal creature normally and can be drawn or moved through nonmagical restraints, scabbards, or containers no more than 1 inch thick.

This property does not allow attacks through Total Cover.

---

## Harvesting Edge Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Crafting and Harvesting  
**Sphere Influences:** Predator, Medicine, Alchemy  
**Preferred Materials:** Spirit-beast bone, surgical steel, harvesting jade

You have Advantage on Intelligence (Nature), Wisdom (Medicine), and Wisdom (Survival) checks made to harvest useful materials from a creature using the weapon as a tool.

The time required for such harvesting is halved.

This property does not create additional material or increase a Harvest Lot’s grade.

---

## Qi-Sensing Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Detection and Appraisal  
**Sphere Influences:** Qiweaving, Source, Spirit  
**Preferred Materials:** Source jade, soul jade, spirit iron

As an Action, awaken the inscription until the end of your next turn.

During that time, you perceive the location of active magical effects, qi inscriptions, attuned treasures, and creatures currently spending or maintaining CP or another Path resource within 30 feet. Total Cover blocks this sense.

Once used, this property cannot be used again until you complete a Short or Long Rest.

---

## Light-Bearing Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Utility and Detection  
**Sphere Influences:** Light, Talismans, Spirit  
**Preferred Materials:** Sun crystal, moon silver, white jade

As a Bonus Action, you can cause the weapon to shed Bright Light in a 20-foot radius and Dim Light for an additional 20 feet, or extinguish that light.

Invisible writing, talisman ink, and formation marks within the Bright Light become visible if they are not behind Total Cover. This property reveals their location and shape but does not explain their function.

---

## Poison-Shedding Temper
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Defensive and Utility  
**Sphere Influences:** Vitality, Medicine, Poison  
**Preferred Materials:** Purified silver, medicine jade, serpent pearl

While wielding the weapon, you have Advantage on saving throws against the Poisoned condition.

As an Action, you can touch the weapon to one nonmagical food or drink container holding no more than 1 gallon. You learn whether its contents are poisoned, though not the poison’s identity.

---

## Gravity-Hook Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Force, Telekinesis, Chains  
**Preferred Materials:** Magnetic iron, mountain jade, chain steel

Whenever the weapon hits a Large or smaller creature, you can pull it 5 feet directly toward you.

The target can make a Strength saving throw against your item save DC to negate this movement. After a creature succeeds on this saving throw, it is immune to this enchantment until the start of your next turn.

---


# +2 Enchantments — Major Inscriptions

## Armor-Piercing Dao Mark
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Universal Refinement  
**Sphere Influences:** Metal, Force, Pressure Points, Weapons  
**Preferred Materials:** Star iron, black gold, dragon fang

Attacks made with the weapon ignore Resistance to its bludgeoning, piercing, or slashing damage.

Whenever you hit a target that has none of those Resistances, the attack deals an additional 1d6 force damage.

This enchantment does not ignore Immunity.

---

## Radiant-Sun Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Elemental and Natural  
**Sphere Influences:** Light, Fire, Yang  
**Preferred Materials:** Sun gold, phoenix-blood metal, solar crystal

Whenever you hit with the weapon, the target takes an additional 1d6 radiant damage.

If the target is Undead, a Fiend, or currently within magical darkness, the additional damage becomes 2d6.

---

## Moonless-Yin Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Elemental and Natural  
**Sphere Influences:** Yin, Dark, Cold  
**Preferred Materials:** Moon silver, yin jade, grave iron

Whenever you hit with the weapon, the target takes an additional 1d6 cold damage and cannot regain Hit Points until the start of your next turn.

---

## Solar-Yang Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Elemental and Natural  
**Sphere Influences:** Yang, Fire, Vitality  
**Preferred Materials:** Sun copper, phoenix-blood metal, golden jade

Whenever you hit with the weapon, the target takes an additional 1d6 fire damage.

Until the start of your next turn, you have Advantage on saving throws against being Frightened and against effects that would reduce your Speed.

---

## Five-Phase Cycling Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Elemental and Natural  
**Sphere Influences:** Fire, Water, Earth, Metal, Wood  
**Preferred Materials:** Five-phase alloy, balanced jade, five aligned beast cores

When you finish a Long Rest, choose acid, cold, fire, lightning, or poison.

Whenever you hit with the weapon, the target takes an additional 1d8 damage of the chosen type.

As an Action, you can spend 1 CP to change the selected damage type. The new type remains until changed again or until you finish a Long Rest.

---

## Chain-Binding Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Chains, Binding, Force  
**Preferred Materials:** Chain steel, dragon sinew, binding jade

When you hit a Large or smaller creature with the weapon, you can spend 1 CP to force it to make a Strength saving throw against your item save DC.

On a failure, its Speed becomes 0 until the start of your next turn.


---

## Meridian-Sealing Point
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Pressure Points, Sealing, Medicine  
**Preferred Materials:** Needle steel, white jade, spirit bone

When you hit a creature with the weapon, you can spend 1 CP to force it to make a Constitution saving throw against your item save DC.

On a failure, it cannot take Reactions until the start of your next turn and cannot spend CP, Stamina, Resonance, or another Path resource during that time.

On a success, it cannot take Reactions until the end of the current turn.

---

## Silent-Heaven Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Sound, Silence, Sealing  
**Preferred Materials:** Hush jade, void glass, black bamboo

Whenever you hit a creature with the weapon, you can force it to make a Constitution saving throw against your item save DC.

On a failure, it cannot speak or use effects requiring speech until the start of your next turn.

After a creature succeeds on this saving throw, it is immune to this enchantment until the start of your next turn.

---

## Void-Nail Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Space, Sealing, Force  
**Preferred Materials:** Void crystal, star iron, spatial jade

Whenever you hit a creature with the weapon, it cannot teleport or travel between planes until the start of your next turn.

If the target was already prevented from teleporting when the attack hit, it instead takes an additional 1d8 force damage.

---

## Soul-Locking Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Spirit, Soul, Sealing  
**Preferred Materials:** Soul jade, ghost iron, spirit beast cores

Whenever you hit a creature with the weapon, it takes an additional 1d8 psychic damage.

If the creature is reduced to 0 Hit Points before the start of your next turn, its soul cannot be moved, consumed, transformed, or trapped by another effect until the end of your next turn.

This does not prevent normal death, stabilization, or revival.

---

## Guardian-Reversal Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Protection, Weapons, Strategy  
**Preferred Materials:** Mirror steel, guardian jade, turtle shell

When a creature you can see hits you with an attack while you are wielding the weapon, you can use your Reaction and spend 1 CP to reduce the damage by 2d8 + your Proficiency Bonus.

If this reduces the damage to 0, you can move 5 feet without provoking Opportunity Attacks.

---

## Mirror-Polished Countermark
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Mirror, Light, Reflection  
**Preferred Materials:** Mirror steel, moon silver, polished jade

When a creature you can see misses you with a melee attack, you can use your Reaction to make one weapon attack against it.

You can use this property a number of times equal to your Proficiency Bonus, regaining all expended uses when you complete a Long Rest.

---

## Shadow-Passing Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Dark, Shadow, Space  
**Preferred Materials:** Shadow iron, void glass, night jade

When you hit a creature with the weapon, you can spend 1 CP to teleport to an unoccupied space you can see within 15 feet of that creature.


---

## Spirit-Striking Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Spirit, Soul, Psychic  
**Preferred Materials:** Heartwood, soul jade, ghost iron

Whenever you hit with the weapon, the attack deals an additional 1d8 psychic damage.

If the target is an Aberration, Celestial, Elemental, Fey, Fiend, or Undead, the additional damage becomes 2d8.

---

## Weapon-Spirit Seed
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Spirit, Imbuement, Weapons  
**Preferred Materials:** Spirit-bearing materials, ancient weapon fragments, beast cores

The weapon develops a dormant spirit seed.

Choose one Instinct when the enchantment is created:

- **Guard.** Once per Long Rest, when you are hit by an attack, the weapon imposes a -1d6 penalty on the attack roll, potentially causing it to miss.
- **Pursue.** Once per Long Rest, when you miss with a weapon attack, the weapon rerolls the attack and must use the new result.
- **Warn.** You cannot be surprised while the weapon is on your person and not dormant.
- **Suppress.** Once per Long Rest, when you fail a saving throw against being Charmed, Frightened, or possessed, you reroll it and must use the new result.

The weapon spirit does not speak, take turns, or activate other properties unless later awakened.

---

## Ancestral Recognition Seal
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Blood, Spirit, Lineage, Authority  
**Preferred Materials:** Blood jade, ancestral metal, lineage relic fragments

When the enchantment is created, define one lineage, sect, oath, or named inheritance.

A qualifying bearer can attune to the weapon in 10 minutes rather than during a Short Rest.

A nonqualifying creature can wield the weapon as a nonmagical weapon but cannot use its enchantments, attack bonus, or damage bonus.

The seal’s qualification must be objective and written into the finished item. It cannot depend on an undefined judgment of worthiness.

---

# Growth and Forbidden Enchantments

---

## Tribulation-Tempered Growth
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Lightning, Tribulation, Growth  
**Preferred Materials:** Tribulation-tempered metal, calamity crystal

The weapon records major breakthroughs survived by its attuned bearer.

When the bearer successfully completes a Realm breakthrough while attuned to the weapon, choose one of the following permanent improvements, subject to the weapon’s normal grade limits:

- increase one enchantment’s additional damage die by one step, to a maximum of d10;
- increase one enchantment’s forced movement by 5 feet;
- increase one enchantment’s range by 10 feet;
- grant the weapon +1 to saving throws against being damaged, suppressed, or broken.

The same improvement cannot be selected more than twice.

This enchantment can record no more than three successful Realm breakthroughs unless the weapon becomes an Immortal Artifact.

---

## Blood-Drinking Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Blood, Drain, Predator  
**Preferred Materials:** Blood steel, demon beast fang, crimson jade

Whenever you reduce a hostile creature to 0 Hit Points with the weapon, you gain Temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier.

The weapon cannot gain this benefit from Constructs, creatures summoned by you, or creatures with a CR lower than one-quarter your Cultivation Level, rounded down.

---

## Life-Burning Overload
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Fire, Blood, Vitality, Forbidden Arts  
**Preferred Materials:** Blood jade, phoenix ash, cursed metal

When you hit with the weapon, you can expend one Hit Die and roll it.

The target takes additional fire or necrotic damage, chosen when the enchantment is created, equal to twice the number rolled.

You also take damage equal to the number rolled. This damage cannot be reduced or prevented.


---


## Flying Sword Command
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Flying Weapons  
**Sphere Influences:** Telekinesis, Weapons, Space  
**Preferred Materials:** Star silver, cloud-void crystal, spirit iron

As a Bonus Action while the weapon is in your hand, you can release it to hover in an unoccupied space within 5 feet. It remains hovering until you recall it as a Bonus Action, become Incapacitated, end your Attunement, or it moves more than 60 feet from you.

While the weapon hovers within 60 feet, you are considered to be wielding it, and one of your hands remains occupied for rules purposes. Whenever you make an attack with the weapon, the attack can originate from the weapon’s space. Before or after each such attack, move the weapon up to 30 feet through unoccupied spaces.

The weapon cannot pass through Total Cover and falls in its space if this enchantment ends.

---

## Sword-Light Missile Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Projectile Techniques  
**Sphere Influences:** Light, Force, Weapons  
**Preferred Materials:** Star silver, sun crystal, spirit jade

The weapon has 3 Sword-Light charges and regains 1d3 expended charges when you complete a Long Rest.

**Sword-Light Missile.** As an Action, expend 1 charge and make a ranged item attack against one creature or object within 120 feet. On a hit, the target takes 4d8 force damage.

The missile travels in a straight line from the weapon and cannot pass through Total Cover.

---

## Blazing Detonation Seal
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Burst Techniques  
**Sphere Influences:** Fire, Talismans, Alchemy  
**Preferred Materials:** Sun copper, fire beast core, talisman steel

The weapon has 3 Detonation charges and regains 1d3 expended charges when you complete a Long Rest.

When the weapon hits a creature, you can expend 1 charge to release a 10-foot-radius burst centered on that creature. Each other creature in the area makes a Dexterity saving throw against your item save DC.

On a failed save, a creature takes 3d6 fire damage. On a successful save, it takes half as much damage.

The creature hit by the weapon is not affected by the burst.

---

## Phasing Strike Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Universal Refinement  
**Sphere Influences:** Phasing, Space, Weapons  
**Preferred Materials:** Ghost iron, origin-void copper, voidglass alloy

Attacks made with the weapon ignore Half Cover and Three-Quarters Cover.

An attack can pass through up to 5 feet of nonmagical solid matter if you can perceive the target through another sense or through an opening. The attack cannot pass through lead, a magical barrier, or Total Cover provided by more than 5 feet of matter.

The weapon does not create an opening in the matter it passes through.

---

## Qi-Disrupting Dao Mark
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Drain, Pressure Points, Qiweaving  
**Preferred Materials:** White jade, ghost iron, meridian needle steel

When the weapon hits a creature, you can spend 1 CP to force it to make a Constitution saving throw against your item save DC.

On a failed save, the creature cannot take Reactions, and the save DCs of its Sphere actions, treasure effects, and other cultivation abilities are reduced by 2 until the start of your next turn.

On a successful save, it cannot take Reactions until the end of the current turn.

---

## Vitality-Returning Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Defensive and Recovery  
**Sphere Influences:** Vitality, Blood, Medicine  
**Preferred Materials:** Blood jade, phoenix-ash steel, medicine jade

Whenever you score a Critical Hit with the weapon or reduce a hostile creature to 0 Hit Points with it, you regain Hit Points equal to your Proficiency Bonus.

You gain no healing from a Construct, a creature summoned by you, or a creature with a Challenge Rating lower than one-quarter your Cultivation Level, rounded down.

---

## Thousand-Needle Division
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Projectile Techniques  
**Sphere Influences:** Telekinesis, Weapons, Metal  
**Preferred Materials:** Needle steel, star silver, spirit bamboo

The weapon has 3 Division charges and regains 1d3 expended charges when you complete a Long Rest.

**Thousand-Needle Division.** As an Action, expend 1 charge and choose a number of creatures you can see within 60 feet up to your Proficiency Bonus. Make one ranged item attack against each target.

On a hit, a target takes 2d8 piercing damage. A creature can be targeted only once by each activation.

---

## Formation-Anchor Breaker
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Anti-Formation  
**Sphere Influences:** Formations, Force, Source  
**Preferred Materials:** Source stone, heaven-splitting stone, star iron

Whenever the weapon hits a Construct, magical barrier, formation anchor, summoned object, or object created by a supernatural effect, it deals an additional 2d6 force damage.

The weapon’s attacks against those targets ignore Resistance to all damage dealt by the weapon, but not Immunity.

If the target is sustaining a visible area or barrier and is destroyed by the attack, that area or barrier ends immediately unless its rules state that it persists without the target.

---

## Talisman-Launching Groove
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Talisman and Technique Conduction  
**Sphere Influences:** Talismans, Imbuement, Weapons  
**Preferred Materials:** White jade, talisman wood, spirit iron

During a Short or Long Rest, attach one consumable talisman to the weapon. The weapon can hold only one talisman at a time.

When you take the Attack action, you can replace one attack with activating the attached talisman, provided the talisman normally requires an Action or Bonus Action. The talisman uses its normal range, targets, save DC, and other rules, and is consumed normally.

If the talisman creates an effect originating from its user, it originates from you rather than from the weapon.

---

## Predator's Pursuit Mark
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Family:** Hunting and Pursuit  
**Sphere Influences:** Predator, Blood, Dark  
**Preferred Materials:** Demon-beast fang, blood jade, shadow iron

Whenever the weapon hits a creature, that creature cannot benefit from being Invisible against attacks made with this weapon until the start of your next turn.

You also know the direction and exact distance to any creature damaged by the weapon within the previous hour while it remains within 1 mile and on the same plane.

A creature that has no blood or spiritual essence, such as most unattended Constructs, cannot be tracked by this property.

---


# +3 Enchantments — Greater Inscriptions

## Sovereign Suppression Mark
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Force, Earth, Suppression, Authority  
**Preferred Materials:** Mountain-root jade, heavy divine metal, sovereign beast core

**Suppressing Strike.** Whenever you hit a Huge or smaller creature, it must make a Strength saving throw against your item save DC.

On a failure, its Speed is reduced by 20 feet and it has Disadvantage on the next Strength or Dexterity saving throw it makes before the start of your next turn. Further hits while this effect lasts do not require another saving throw.

On a success, its Speed is reduced by 10 feet until the start of your next turn, and it is immune to further saving throws from this enchantment until then.

---

# Defensive and Mobility Enchantments

---

## Devouring Furnace Mark
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Drain, Imbuement, Alchemy, Dark  
**Preferred Materials:** Devouring beast core, black furnace iron, abyssal jade

When the weapon reduces a hostile creature of CR 1 or higher to 0 Hit Points, it gains 1 Devouring charge, to a maximum of 3.

Whenever you hit with the weapon, you can expend 1 Devouring charge to deal an additional 2d8 necrotic damage and regain Hit Points equal to half the necrotic damage dealt.

All unused Devouring charges disappear when you complete a Long Rest.

The weapon gains no charge from Constructs, creatures summoned by you, or creatures created solely to be sacrificed.

---

## Calamity-Hungry Edge
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Tribulation, Drain, Lightning, Growth  
**Preferred Materials:** Tribulation remnants, calamity crystal, divine metal

When you succeed on a saving throw against a damaging effect, the weapon stores 1 Calamity charge, to a maximum of 3.

Whenever you hit with the weapon, you can expend 1 Calamity charge to deal an additional 2d8 damage of a type dealt by the triggering effect that created the charge.

All unused Calamity charges disappear when you complete a Long Rest.

---


## Gravitational Prison Seal
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Control, Sealing, and Suppression  
**Sphere Influences:** Force, Earth, Telekinesis, Sealing  
**Preferred Materials:** Mountain-root jade, magnetic iron, heavy divine metal

When the weapon hits a Huge or smaller creature, you can spend 2 CP to force it to make a Strength saving throw against your item save DC.

On a failed save, the creature is Restrained until the end of your next turn.

On a successful save, its Speed is reduced by 10 feet until the end of your next turn, and it is immune to Gravitational Prison Seal until the start of your next turn.

A creature that is already Restrained by this enchantment is not required to make another saving throw when hit.

---

## Mirror-Heaven Reversal
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Defensive and Reflection  
**Sphere Influences:** Mirror, Light, Water, Strategy  
**Preferred Materials:** Mirror-sea silver, moon silver, stillwater jade

When an attack made by a creature you can see damages you, you can use your Reaction and spend 2 CP to reduce the damage by `4d8 + your Proficiency Bonus`.

If this reduces the triggering damage to 0, make one ranged item attack against the attacking creature, provided it is within 120 feet and not behind Total Cover.

On a hit, the creature takes 4d8 force damage. This reflected attack is a separate attack and does not apply the weapon’s other on-hit enchantments.

---

## Thousand-Li Pursuit Inscription
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Family:** Hunting and Pursuit  
**Sphere Influences:** Predator, Space, Blood, Weapons  
**Preferred Materials:** Star silver, blood jade, cloud-void crystal

This enchantment can be applied only to a ranged weapon, a weapon with the Thrown property, or a weapon bearing Flying Sword Command.

Attacks made with the weapon do not have Disadvantage at long range and ignore Half Cover and Three-Quarters Cover.

When the weapon damages a creature, you can mark it until you mark another creature or complete a Long Rest. While the marked creature is within 10 miles and on the same plane, you know its direction and exact distance.

The marked creature gains no benefit from being Invisible against attacks made with this weapon.

A creature can remove the mark during a Long Rest with a successful Wisdom (Medicine) or Intelligence (Arcana) check against your item save DC.

---


# +4 Enchantments — Apex Inscriptions

## Heaven-Splitting Edge
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Universal Refinement  
**Sphere Influences:** Metal, Force, Space, Weapons  
**Preferred Materials:** Divine metal, void crystal, tribulation-tempered steel

Whenever you hit a creature or object with the weapon, it takes an additional 3d8 force damage.

If the target is an unattended object or structure, the additional damage is maximized.

The attack ignores Resistance to bludgeoning, piercing, slashing, and force damage, but not Immunity.

---

# Elemental and Natural Enchantments

---

## Heaven-Calamity Inscription
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Elemental and Natural  
**Sphere Influences:** Lightning, Thunder, Fire, Tribulation  
**Preferred Materials:** Tribulation-tempered metal, thunder crystal, calamity beast core

Whenever you hit with the weapon, the target takes an additional 2d8 lightning damage.

**Calamity Descent.** Once per Long Rest, when you hit a creature, you can call down a 20-foot-radius, 40-foot-high cylinder of tribulation lightning centered on it. Each other creature in the area makes a Dexterity saving throw against your item save DC.

On a failed save, a creature takes 8d8 lightning damage and cannot take Reactions until the start of its next turn. On a success, it takes half damage and suffers no other effect.

The original target automatically fails this saving throw but does not take the enchantment’s normal 2d8 additional lightning damage a second time.

---

# Control, Sealing, and Suppression Enchantments

---

## Space-Cutting Step
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Defensive and Mobility  
**Sphere Influences:** Space, Movement, Weapons  
**Preferred Materials:** Void crystal, spatial jade, divine metal

Whenever you make an attack as part of the Attack action while wielding the weapon, you can teleport up to 20 feet to an unoccupied space you can see immediately before or after that attack.

This teleportation cannot pass through an effect that blocks teleportation.

---

# Spirit, Soul, and Weapon-Awakening Enchantments

---

## Awakened Weapon Spirit
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Spirit, Soul, and Awakening  
**Sphere Influences:** Spirit, Imbuement, Weapons, Command  
**Preferred Materials:** A weapon already bearing Weapon-Spirit Seed

The weapon’s spirit awakens and can communicate telepathically with its attuned bearer while on the same plane.

Choose two Instincts from Weapon-Spirit Seed. Each selected Instinct can function once per Long Rest.

**Independent Guard.** When you are Incapacitated but not dead, the weapon can use one of its unused defensive Instincts without requiring your action.

The weapon remains an item and does not take independent turns.

---

## Dao-Vessel Foundation
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Growth and Forbidden  
**Sphere Influences:** Any coherent Dao expression  
**Preferred Materials:** A unique principal material compatible with the bearer’s intended Dao

The weapon becomes a personal Dao vessel.

When this enchantment is created, choose one existing Minor or Major enchantment on the weapon as its **Core Expression**.

The Core Expression gains one of the following improvements:

- its additional damage increases by 1d8;
- its forced movement increases by 10 feet;
- its range increases by 30 feet;
- one target affected by it has Disadvantage on its first saving throw against it each Long Rest;
- its CP cost is reduced by 1, to a minimum of 0, whenever the Core Expression is activated.

The chosen improvement must be written into the final weapon entry.

The weapon can later receive bespoke growth through Dao Insights, Realm breakthroughs, unique materials, or item-spirit awakening, but every new function must remain mechanically explicit and thematically connected to the Core Expression.

---

## Ten-Thousand Sword Domain
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Flying Weapons and Domains  
**Sphere Influences:** Weapons, Telekinesis, Formations, Metal  
**Preferred Materials:** Heaven-mark violet gold, star silver, formation jade

The weapon has 5 Domain charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

**Open the Sword Domain.** As an Action, expend 3 charges to create a 20-foot-radius domain centered on you for up to 1 minute. You must maintain Concentration as though concentrating on a spell.

When a hostile creature enters the domain for the first time on a turn or starts its turn there, it makes a Dexterity saving throw against your item save DC. On a failed save, it takes 4d8 slashing damage. On a successful save, it takes half as much damage.

While the domain lasts, when you make an attack with this weapon, you can treat the attack as originating from any unoccupied point inside the domain that you can see. Determine range and cover from that point. The weapon remains in your possession.

---

## Law-Denying Edge
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Anti-Technique and Suppression  
**Sphere Influences:** Sealing, Drain, Force, Dao  
**Preferred Materials:** Origin-void copper, heaven-mark violet gold, sealing jade

When the weapon hits a creature, you can spend 3 CP and choose one ongoing effect on that creature that:

- has a duration longer than Instantaneous;
- originates from a spell, Sphere action, treasure, formation, or other supernatural ability;
- is perceptible to you or identified by a feature you possess.

The creature makes a Charisma saving throw against your item save DC.

On a failed save, the chosen effect is suppressed until the end of your next turn. While suppressed, it provides no benefit, imposes no condition, and cannot be activated or extended, but its duration continues to elapse.

On a successful save, the effect is not suppressed, and that creature is immune to Law-Denying Edge until the start of your next turn.

This enchantment cannot suppress Attunement, a creature’s Path or Foundation, an item’s existence, an instantaneous effect, or an Immortal Artifact property unless that property explicitly permits suppression.

---

## Heaven-Earth Severing Wave
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Family:** Projectile Techniques  
**Sphere Influences:** Force, Metal, Air, Weapons  
**Preferred Materials:** Heaven-splitting stone, divine metal, cloud-void crystal

The weapon has 3 Severing charges and regains 1 expended charge when you complete a Long Rest.

**Sever Heaven and Earth.** As an Action, expend 1 charge to release a cutting wave in a line 120 feet long and 10 feet wide.

Each creature in the line makes a Dexterity saving throw against your item save DC. On a failed save, a creature takes 12d8 force damage. On a successful save, it takes half as much damage.

Unattended objects and structures in the line take the maximum possible damage. A magical barrier or formation segment reduced to 0 Hit Points by this damage is destroyed immediately.

---

# +5 and +6 Enchantments — Immortal Inscriptions

## One Vessel Suppresses Ten Thousand Laws
**Minimum Grade:** Immortal Artifact  
**Equivalent Bonus:** **+5**  
**Family:** Dao Vessel and Suppression  
**Sphere Influences:** Dao, Force, Sealing, Imbuement  
**Preferred Materials:** Primordial mother-weight essence, origin-void copper, heaven-mark violet gold  
**Prerequisite:** Dao-Vessel Foundation

Attacks made with the weapon ignore Resistance to all damage dealt by the weapon and its enchantments. They do not ignore Immunity.

The weapon has 3 Law-Suppression charges and regains 1 expended charge when its bearer completes a Long Rest.

**Ten Thousand Laws Fall Silent.** As an Action, expend 2 charges to create a 30-foot-radius suppression domain centered on you for up to 1 minute. You must maintain Concentration as though concentrating on a spell.

When a hostile creature enters the domain for the first time on a turn or starts its turn there, it makes a Charisma saving throw against your item save DC.

On a failed save, until the start of its next turn the creature:

- cannot activate a treasure;
- cannot spend CP, Stamina, Resonance, or another Path resource;
- cannot teleport or travel between planes;
- cannot benefit from Resistance granted by a supernatural effect.

On a successful save, it suffers none of these effects and is immune to this domain until the start of its next turn.

Immortal Artifact properties are unaffected unless their own rules explicitly permit suppression.

---

## World-Severing Immortal Edge
**Minimum Grade:** Immortal Artifact  
**Equivalent Bonus:** **+6**  
**Family:** Immortal Offense  
**Sphere Influences:** Space, Force, Metal, Dao  
**Preferred Materials:** Immortal divine metal, origin-void copper, world-heart crystal

Whenever the weapon hits a creature or object, the target takes an additional 4d8 force damage.

Attacks made with the weapon ignore Resistance to bludgeoning, piercing, slashing, and force damage. Against Immunity to one of those damage types, treat the Immunity as Resistance instead.

**World-Severing Stroke.** Once per Long Rest, as an Action, release a spatial cut in a line 300 feet long and 20 feet wide.

Each creature in the line makes a Dexterity saving throw against your item save DC.

On a failed save, a creature takes 20d8 force damage and is teleported to the nearest unoccupied space outside the line, choosing the side if more than one space is equally near.

On a successful save, it takes half as much damage and is not teleported.

Unattended objects and structures in the line take the maximum possible damage. A magical barrier, formation segment, or non-Immortal portal reduced to 0 Hit Points by this damage is destroyed and cannot be restored until the end of your next Long Rest.

This stroke cannot destroy a plane, demiplane, world, or Immortal Artifact unless a separate campaign rule explicitly permits it.

---

# Sphere Influence Index


The following list provides starting points when selecting enchantments for Sphere-aligned weapons. Sphere influence does not grant the listed Sphere and is not a prerequisite unless a finished weapon explicitly makes it one.

| Sphere or Theme | Common Enchantments |
|---|---|
| Air / Wind | Gale-Edge, Cloud-Riding, Pursuing-Star, Long-Reach |
| Alchemy | Venom-Bloom, Corrosion-Vein, Harvesting Edge, Blazing Detonation |
| Athletics | Balanced-Grip, Cloud-Riding, River-Flow |
| Blood | Blood-Drinking, Life-Burning, Ancestral Recognition, Blood-Scent Tracking, Vitality-Returning, Predator's Pursuit |
| Chains | Chain-Binding, Sovereign Suppression, Gravity-Hook |
| Dark / Shadow | Moonless-Yin, Shadow-Passing, Devouring Furnace, Soundless Edge, Predator's Pursuit |
| Dao | Dao-Vessel Foundation, Law-Denying Edge, One Vessel Suppresses Ten Thousand Laws, World-Severing Immortal Edge |
| Drain | Devouring Furnace, Blood-Drinking, Calamity-Hungry, Qi-Disrupting |
| Dreams | Dream-Piercing |
| Earth / Mountain | Mountain-Weight, Sovereign Suppression, Unbreaking Temper, Stonebreaker, Gravity-Hook |
| Equipment | Balanced-Grip, Unbreaking Temper, Hidden-Sheath |
| Fire | Flame-Vein, Radiant-Sun, Solar-Yang, Life-Burning, Wood-Severing, Blazing Detonation |
| Flowing River | River-Flow, Water-Cutting |
| Force | Armor-Piercing, Mountain-Weight, Heaven-Splitting, Stonebreaker, Formation-Sundering, Formation-Anchor Breaker, Gravitational Prison, Law-Denying Edge, Heaven-Earth Severing Wave, World-Severing Immortal Edge |
| Formations | Formation-Sundering, Formation-Anchor Breaker, Ten-Thousand Sword Domain |
| Ice / Cold | Frost-Meridian, Moonless-Yin, Water-Cutting |
| Imbuement | Meridian-Conducting, Weapon-Spirit Seed, Awakened Weapon Spirit, Talisman Channel, Talisman-Launching |
| Light | Radiant-Sun, Pursuing-Star, Ghost-Slaying, Light-Bearing, Sword-Light Missile |
| Lightning / Thunder | Thunder-Conducting, Heaven-Calamity, Tribulation-Tempered, Resonant-Sound |
| Medicine | Soul-Guarding, Blood-Scent Tracking, Harvesting Edge, Poison-Shedding, Vitality-Returning |
| Mirror / Reflection | Mirror-Polished Countermark, Mirror-Heaven Reversal |
| Metal | Grade Refinement Bonus, Armor-Piercing, Heaven-Splitting, Stonebreaker, Wood-Severing, Thousand-Needle, Ten-Thousand Sword Domain, Heaven-Earth Severing Wave, World-Severing Immortal Edge |
| Movement | River-Flow, Cloud-Riding, Shadow-Passing, Space-Cutting Step, Long-Reach |
| Phasing | Phasing Edge, Phasing Strike |
| Poison | Venom-Bloom, Corrosion-Vein, Poison-Shedding |
| Predator | Blood-Drinking, Beast-Hunter, Blood-Scent Tracking, Harvesting Edge, Predator's Pursuit, Thousand-Li Pursuit |
| Pressure Points | Meridian-Sealing Point, Armor-Piercing, Qi-Disrupting |
| Qiweaving | Meridian-Conducting, Qi-Sensing, Qi-Disrupting, Long-Reach |
| Sealing | Chain-Binding, Meridian-Sealing, Void-Nail, Soul-Locking, Gravity-Hook, Gravitational Prison, Law-Denying Edge, One Vessel Suppresses Ten Thousand Laws |
| Sound | Silent-Heaven, Soundless Edge, Resonant-Sound |
| Source | Qi-Sensing, Formation-Anchor Breaker |
| Space | Returning, Void-Nail, Shadow-Passing, Space-Cutting Step, Hidden-Sheath, Long-Reach, Phasing Edge, Flying Sword Command, Phasing Strike, Thousand-Li Pursuit, World-Severing Immortal Edge |
| Spirit / Soul | Spirit-Striking, Ghost-Slaying, Soul-Guarding, Weapon-Spirit Seed, Dream-Piercing, Qi-Sensing |
| Spirit Companions | Beast-Hunter |
| Talismans | Talisman Channel, Light-Bearing, Blazing Detonation, Talisman-Launching |
| Telekinesis | Returning, Gravity-Hook, Flying Sword Command, Thousand-Needle, Gravitational Prison, Ten-Thousand Sword Domain |
| Vitality | Solar-Yang, Soul-Guarding, Poison-Shedding, Vitality-Returning |
| Water | River-Flow, Frost-Meridian, Water-Cutting |
| Weapons | Grade Refinement Bonus, Returning, Guardian-Reversal, Dao-Vessel Foundation, Balanced-Grip, Long-Reach, Flying Sword Command, Sword-Light Missile, Thousand-Li Pursuit, Ten-Thousand Sword Domain, Heaven-Earth Severing Wave |
| Yin | Frost-Meridian, Moonless-Yin, Dream-Piercing |
| Yang | Flame-Vein, Radiant-Sun, Solar-Yang |

---

# Production Requirements

A finished enchanted weapon must state:

- its base weapon chassis;
- its Primary Material and material property;
- its finished treasure grade;
- its explicit Refinement Bonus: **+1 Spiritual, +2 Saint, +4 Sovereign, +6 Imperial, or +8 baseline Immortal**;
- every enchantment’s printed Equivalent Bonus;
- the weapon’s Total Equivalent Bonus and Total Effective Bonus;
- the sentence granting that bonus to attack and damage rolls;
- every enchantment in full;
- the save DC source used by each effect;
- every action type, trigger, range, target, success result, and failure result;
- each resource cost and recovery method;
- any Attunement, Sphere, Path, lineage, or Realm requirement;
- whether it occupies the normal one Attunement slot or explicitly occupies more;
- its factory and GM Screen action rows.

An enchantment name or Dao description never substitutes for these mechanics.

## Required Final-Weapon Header

Every finished cultivation weapon must make its numerical bonus immediately visible. Use one of these forms:

> **Storm-Iron Thunder Spear +2**  
> *Weapon (Spear), Saint Treasure, Requires Attunement*

or:

> **Storm-Iron Thunder Spear**  
> *Weapon (Spear), Saint Treasure, Requires Attunement*  
> You gain a **+2 bonus to attack and damage rolls** made with this weapon.

The second sentence remains required even when the bonus appears in the weapon's name or header.


# Chapter 3: Spiritual Armor

This combined production file presents armor construction in its required order:

1. **Chapter 3A — Armor Chassis and Armor Types**
2. **Chapter 3B — Armor Materials**
3. **Chapter 3C — Armor Enhancements**


## Chapter 3A: Armor Chassis and Armor Types
### Core Armor Profile Catalog v0.2 — Construction Baseline

Armor begins with a chassis just as a spiritual weapon does.

The armor chassis determines the wearer’s base Armor Class calculation, Dexterity allowance, Strength requirement, Stealth limitation, weight, donning time, and proficiency category. Materials and armor enchantments are added afterward.

The Sphere of Equipment governs wearing armor well. It does not replace the armor profile, create extra armor slots, or allow several Armor Class formulas to stack.

---

# Creating Cultivation Armor

Build armor in this order:

> **1. Armor Type → 2. Primary Material → 3. Treasure Grade and Refinement Bonus → 4. Armor Enhancements → 5. Final Armor Entry**

## Step 1: Choose the Armor Type

Choose one legal armor or shield profile from this chapter.

Record:

- armor category;
- base Armor Class formula;
- maximum Dexterity contribution;
- Strength requirement;
- Stealth limitation;
- weight;
- construction tags;
- whether the item is worn armor or a carried shield.

## Step 2: Choose the Primary Material

Choose one material from **Chapter 3B: Armor Materials**.

Confirm:

- Material Grade;
- Normal Refinement Ceiling;
- compatible armor construction tags;
- affinity tags;
- inherent Material Property;
- preferred enhancement families;
- opposed enhancements and stabilizer requirements.

The material property does not consume enchantment capacity.

## Step 3: Choose the Finished Grade

The finished grade determines the armor or shield's actual Refinement Bonus and enchantment capacity.

| Finished Grade | Armor or Shield Refinement Bonus | Enchantment Capacity |
|---|---:|---:|
| Spiritual Treasure | **+1 AC** | **+1** |
| Saint Treasure | **+2 AC** | **+3** |
| Sovereign Treasure | **+3 AC** | **+6** |
| Imperial Treasure | **+4 AC** | **+10** |
| Immortal Artifact | **+5 AC baseline or bespoke** | **Bespoke; normally +12 or higher** |

The Refinement Bonus is added to the armor's printed Armor Class or the shield's printed Armor Class bonus.

A suit of armor and a shield are separate treasures. Their Refinement Bonuses stack if both are worn or carried legally, but each normally requires its own Attunement slot.

## Step 4: Choose Armor Enhancements

Choose enhancements from **Chapter 3C: Armor Enhancements**.

For each enhancement, verify:

- Minimum Grade;
- Equivalent Bonus;
- armor-profile compatibility;
- material affinity;
- opposed-enhancement stabilizers;
- action type, trigger, target, range, cost, duration, and recovery.

Add all Equivalent Bonuses together. The total cannot exceed the item's enchantment capacity.

## Step 5: Compile the Final Armor

Calculate:

> **Total Enhancement Value = Sum of all enhancement Equivalent Bonuses**

> **Total Effective Bonus = Refinement Bonus + Total Enhancement Value**

Total Effective Bonus is used for crafting, comparison, and valuation. Only the Refinement Bonus adds directly to Armor Class.

---

# Worked Example: Mountain-Root Silent Fortress Half Armor

## 1. Select the Armor Type

Choose **Mountain-Pattern Half Armor**.

**Recorded profile:**

- Category: Medium Armor
- Base Armor Class: 15 + Dexterity modifier, maximum +2
- Strength Requirement: None
- Stealth: Disadvantage
- Weight: 40 pounds
- Construction Tags: Interlocking Plate, Layered, Mountain, Heavy Medium, Helmet-Compatible

## 2. Select the Primary Material

Choose **Mountain-Root Jade Plates** from Chapter 3B.

**Recorded material:**

- Material Grade: Saint
- Normal Refinement Ceiling: Sovereign Treasure
- Compatible Profiles: Lamellar, Plate, Mountain, and Full-Coverage armor
- Affinities: Earth, Weight, Suppression
- Material Property: forced movement affecting the wearer is reduced by 10 feet, and the wearer has Advantage on saving throws against being knocked Prone
- Preferred Enhancements: Mountain, Stability, Suppression, Impact
- Opposed Enhancements: Air and weightless movement unless stabilized

The material can support a Saint Treasure without special intervention.

## 3. Select the Treasure Grade

Choose **Saint Treasure**.

The armor gains:

- **+2 Refinement Bonus to AC**;
- **+3 enhancement capacity**.

Its final Armor Class formula is currently:

> **17 + Dexterity modifier, maximum +2**

## 4. Select the Enhancements

### Silent Lacing +1

Silent Lacing removes Disadvantage on Dexterity (Stealth) checks imposed by the armor.

The enhancement is compatible with medium armor and does not oppose Mountain-Root Jade.

### Stone-Root Stabilizers +2

Stone-Root Stabilizers prevent the wearer from being moved against their will unless they choose to permit the movement, but the wearer must spend 10 feet of movement to activate the rooted stance until the start of their next turn.

This enhancement shares the Earth and Stability affinities of Mountain-Root Jade.

### Capacity Check

| Enhancement | Value |
|---|---:|
| Silent Lacing | +1 |
| Stone-Root Stabilizers | +2 |
| **Total Enhancement Value** | **+3** |

The Saint Treasure capacity is +3, so the construction is legal.

## 5. Final Item Entry

### Mountain-Root Silent Fortress Half Armor +2
*Armor (Mountain-Pattern Half Armor), Saint Treasure, Requires Attunement*

**Base Armor Class:** 15 + Dexterity modifier, maximum +2  
**Primary Material:** Mountain-Root Jade Plates  
**Refinement Bonus:** +2 AC  
**Final Armor Class:** 17 + Dexterity modifier, maximum +2  
**Enhancements:** Silent Lacing (+1), Stone-Root Stabilizers (+2)  
**Total Enhancement Value:** +3  
**Total Effective Bonus:** +5  
**Attunement Slots:** 1  
**Fitted Armor:** Eligible

**Mountain-Root Stability.** Forced movement affecting you is reduced by 10 feet. You have Advantage on saving throws against being knocked Prone.

**Silent Lacing.** The armor does not impose Disadvantage on Dexterity (Stealth) checks.

**Stone-Root Stance.** At the start of your turn, you can spend 10 feet of movement to root the armor until the start of your next turn. While rooted and standing on a solid surface, you cannot be moved against your will or knocked Prone unless you choose to be. You can end the stance early without an action.

---

# Blank Armor Construction Worksheet

## Concept

**Armor Name:**  
**Intended Grade:**  
**Intended Dao or Defensive Role:**  

## Step 1 — Armor Type

**Legal Profile:**  
**Category:**  
**Base Armor Class Formula:**  
**Dexterity Limit:**  
**Strength Requirement:**  
**Stealth Limitation:**  
**Weight:**  
**Construction Tags:**  

## Step 2 — Primary Material

**Material:**  
**Material Grade:**  
**Normal Ceiling:**  
**Compatible Tags:**  
**Affinities:**  
**Material Property:**  
**Preferred Enhancements:**  
**Opposed Enhancements:**  
**Required Stabilizer:**  

## Step 3 — Grade

**Finished Grade:**  
**Refinement Bonus:**  
**Enhancement Capacity:**  
**Ceiling Check:**  

## Step 4 — Enhancements

| Enhancement | Minimum Grade | Equivalent Bonus | Profile Legal? | Material Compatible? |
|---|---|---:|---|---|
|  |  |  |  |  |

**Total Enhancement Value:**  

## Step 5 — Final Calculation

**Base Armor Class:**  
**Refinement Bonus:**  
**Final Armor Class:**  
**Total Enhancement Value:**  
**Total Effective Bonus:**  
**Attunement Slots:**  
**Fitted Armor Eligibility:**  

---

# Core Armor Rules

## Armor Categories

Tianxia retains the familiar armor categories:

- **Light Armor**
- **Medium Armor**
- **Heavy Armor**
- **Shields**

A suit’s visual style does not determine its category. Lamellar, lacquered hide, brigandine robes, beast-hide armor, mirror-bright plates, mountain-pattern armor, sect uniforms, and ceremonial battle dress can use different profiles depending on their actual construction.

The completed item must state its category and profile.

## Armor Class Formulas

A character cannot stack multiple Armor Class formulas.

When wearing armor, use the Armor Class formula printed by that armor profile. An unarmored defense formula, Reinforced Robes, natural armor, or another feature that sets Armor Class is a different formula; choose one.

A shield or explicit bonus can apply to the chosen formula only when its own rule permits it.

## Armor Proficiency

Wearing enchanted armor does not grant proficiency with its category.

A creature wearing armor without proficiency suffers the normal consequences unless a feature explicitly changes them.

## Fitted Armor

A character with the Equipment Sphere can designate one proficient suit as Fitted Armor under that Sphere’s rules.

Fitted Armor is a relationship between the wearer and one suit. It is not a separate armor category, magical grade, material, or enchantment.

## Battle Robes and Clothing

Ordinary robes, sect uniforms, court dress, travel clothing, and ceremonial garments are not armor.

A garment described as an **armored robe** must name the armor profile it uses, such as Padded Battle Robes, Hidden Brigandine Robes, or Mirror-Bright Breastplate beneath court garments.

A character using Reinforced Robes or another unarmored Armor Class formula is not wearing armor. Such clothing cannot receive armor-only enchantments unless an enchantment or item entry explicitly permits an unarmored battle-dress chassis.

## Armor Components Do Not Create Extra Slots

Helmets, masks, pauldrons, vambraces, greaves, underlayers, lacing, skirts, mantles, and mirror plates are normally components of one suit.

They do not each grant Armor Class or accept independent armor enchantments unless an item entry explicitly makes one of them a separate Wondrous Item requiring its own Attunement slot.

## Shields

A shield is carried protection, not worn armor.

A shield uses one hand and grants its printed Armor Class bonus. Proficiency with armor does not automatically grant shield proficiency.

The Shield Sphere owns active shield techniques. The Equipment Sphere and armor item rules can still improve a shield’s construction, durability, comfort, and passive protection.

## Donning and Doffing

Use the normal 5.5e donning and doffing times unless an Equipment talent or item property changes them.

| Category | Don | Doff |
|---|---:|---:|
| Light Armor | 1 minute | 1 minute |
| Medium Armor | 5 minutes | 1 minute |
| Heavy Armor | 10 minutes | 5 minutes |
| Shield | Utilize action | Utilize action |

---

# Armor Profile Record

Every finished armor entry must state:

- armor name;
- legal armor profile;
- armor category;
- base Armor Class formula;
- maximum Dexterity contribution, if any;
- Strength requirement, if any;
- whether it imposes Disadvantage on Dexterity (Stealth) checks;
- weight;
- construction tags;
- Primary Material;
- Refinement Bonus or other grade-derived defense, once defined;
- armor enchantments and their Equivalent Bonuses;
- Attunement requirement;
- whether it can be Fitted Armor.

---

# Light Armor

Light Armor favors mobility, concealment, travel, robe silhouettes, leather, cloth, and small hidden plates. It allows the wearer’s full Dexterity modifier to contribute to Armor Class.

| Profile | Armor Class | Strength | Stealth | Weight | Common Tianxia Forms |
|---|---:|---:|---|---:|---|
| **Padded Battle Robes** | 11 + Dex modifier | — | Disadvantage | 8 lb. | Quilted robes, layered cotton armor, winter battle dress, padded under-robes |
| **Lacquered Leather** | 11 + Dex modifier | — | Normal | 10 lb. | Hardened leather, border armor, beast-hunter coats, weatherproof hide |
| **Hidden Brigandine Robes** | 12 + Dex modifier | — | Normal | 13 lb. | Plates sewn beneath cloth, court armor, caravan coats, concealed sect robes |

## Padded Battle Robes

Padded Battle Robes use layered cloth, quilted silk, felt, wool, cotton, paper armor, or comparable flexible padding.

**Construction Tags:** Cloth, Layered, Flexible, Concealable, Insulating

## Lacquered Leather

Lacquered Leather includes hardened hide, boiled leather, lacquered scales over flexible backing, and beast-hunter armor.

**Construction Tags:** Hide, Leather, Flexible, Weatherproof, Beast-Compatible

## Hidden Brigandine Robes

Hidden Brigandine Robes place small plates, studs, scales, or reinforced strips beneath an ordinary-looking outer garment.

**Construction Tags:** Cloth, Hidden Plate, Concealable, Layered, Metal-Compatible

---

# Medium Armor

Medium Armor combines substantial protection with limited Dexterity contribution. Add no more than +2 from Dexterity unless a feature says otherwise.

| Profile | Armor Class | Strength | Stealth | Weight | Common Tianxia Forms |
|---|---:|---:|---|---:|---|
| **Beast-Hide Harness** | 12 + Dex modifier (max +2) | — | Normal | 12 lb. | Thick hide, monster leather, fur-lined hunting armor |
| **Light Lamellar Vest** | 13 + Dex modifier (max +2) | — | Normal | 20 lb. | Short lamellar coat, chain shirt analog, scale vest beneath robes |
| **Lacquered Lamellar** | 14 + Dex modifier (max +2) | — | Disadvantage | 45 lb. | Full scale coat, lacquered lamellar, military scale armor |
| **Mirror-Bright Breastplate** | 14 + Dex modifier (max +2) | — | Normal | 20 lb. | Polished chest plates, mingguang-inspired torso armor, officer cuirass |
| **Mountain-Pattern Half Armor** | 15 + Dex modifier (max +2) | — | Disadvantage | 40 lb. | Interlocking plates over torso and limbs, heavy brigandine, half-plate battle dress |

## Beast-Hide Harness

Beast-Hide Harness uses thick hide, layered leather, fur, horn, bone splints, or monster skin.

**Construction Tags:** Hide, Beast-Compatible, Flexible, Organic, Insulating

## Light Lamellar Vest

A Light Lamellar Vest uses small plates, rings, scales, or hardened segments over a flexible underlayer, protecting the torso without enclosing the whole body.

**Construction Tags:** Lamellar, Layered, Flexible, Metal-Compatible, Robe-Compatible

## Lacquered Lamellar

Lacquered Lamellar uses rows of tied plates or scales with substantial shoulder, torso, and skirt coverage.

**Construction Tags:** Lamellar, Layered, Lacquered, Helmet-Compatible, Military

## Mirror-Bright Breastplate

A Mirror-Bright Breastplate uses polished torso plates while leaving the limbs comparatively free.

**Construction Tags:** Plate, Mirror, Officer, Ceremonial, Metal-Compatible

## Mountain-Pattern Half Armor

Mountain-Pattern Half Armor uses interlocking plates, brigandine, or layered shells to spread impact through the suit.

**Construction Tags:** Interlocking Plate, Layered, Mountain, Heavy Medium, Helmet-Compatible

---

# Heavy Armor

Heavy Armor provides a fixed Armor Class and does not add Dexterity. Its burden, sound, and coverage are part of its profile.

| Profile | Armor Class | Strength | Stealth | Weight | Common Tianxia Forms |
|---|---:|---:|---|---:|---|
| **Ring-Lamellar Harness** | 14 | — | Disadvantage | 40 lb. | Ring-sewn coats, heavy scale remnants, reinforced militia armor |
| **Full Lamellar Battle Dress** | 16 | Str 13 | Disadvantage | 55 lb. | Jiǎzhòu battle dress, full iron lamellar, heavy cavalry armor |
| **Mountain-Pattern Grand Shell** | 17 | Str 15 | Disadvantage | 60 lb. | Interlocking splint armor, mountain-pattern plates, fortress harness |
| **Imperial Plate Battle Dress** | 18 | Str 15 | Disadvantage | 65 lb. | Full articulated plate, imperial guard armor, complete war shell |

## Ring-Lamellar Harness

Ring-Lamellar Harness is an inexpensive heavy profile made from rings, reinforced panels, scales, or older pieces assembled into a complete suit.

**Construction Tags:** Ring, Lamellar, Layered, Heavy, Repairable

## Full Lamellar Battle Dress

Full Lamellar Battle Dress combines torso, shoulder, skirt, arm, leg, and helmet protection into one complete military garment.

**Construction Tags:** Jiǎzhòu, Lamellar, Full Coverage, Helmeted, Cavalry-Compatible

## Mountain-Pattern Grand Shell

Mountain-Pattern Grand Shell uses interlocking plates or heavy splints that distribute force through a flexible but imposing shell.

**Construction Tags:** Mountain, Interlocking Plate, Full Coverage, Heavy, Suppression-Compatible

## Imperial Plate Battle Dress

Imperial Plate Battle Dress uses fitted articulated plates, a complete helmet, underlayers, joint defenses, and carefully distributed weight.

**Construction Tags:** Plate, Articulated, Full Coverage, Imperial, Helmeted, High-Refinement

---

# Shields

All ordinary shield appearances use the same basic profile unless a special item says otherwise.

| Profile | Armor Class Bonus | Strength | Stealth | Weight | Common Tianxia Forms |
|---|---:|---:|---|---:|---|
| **Shield** | +2 AC | — | Normal | 6 lb. | Round shield, rattan shield, lacquered shield, iron shield, war shield |

A character can benefit from only one shield at a time.

Shield shape and material can affect enhancement compatibility later, but do not alter the basic +2 Armor Class bonus unless a special profile explicitly says so.

**Construction Tags:** Carried, Guard, Wood-Compatible, Metal-Compatible, Hide-Compatible

---

# Armor Style Traditions

The following traditions describe how an armor profile appears. They do not change statistics by themselves.

| Tradition | Typical Profiles |
|---|---|
| **Lacquered Hide** | Lacquered Leather, Beast-Hide Harness |
| **Lamellar Scale** | Light Lamellar Vest, Lacquered Lamellar, Full Lamellar Battle Dress |
| **Jiǎzhòu Battle Dress** | Full Lamellar Battle Dress, Mountain-Pattern Grand Shell |
| **Mingguang Bright Armor** | Mirror-Bright Breastplate, Mountain-Pattern Half Armor, Imperial Plate Battle Dress |
| **Mountain-Pattern Armor** | Mountain-Pattern Half Armor, Mountain-Pattern Grand Shell |
| **Hidden Brigandine Robes** | Hidden Brigandine Robes, Light Lamellar Vest beneath clothing |
| **Sect Battle Robes** | Padded Battle Robes, Hidden Brigandine Robes, Mirror-Bright Breastplate beneath robes |
| **Beast-Hide Harness** | Lacquered Leather, Beast-Hide Harness, specially constructed heavier profiles |

---

# Armor Construction Tags

Armor enchantments and materials can refer to these tags.

| Tag | Meaning |
|---|---|
| **Cloth** | Primarily woven, quilted, felted, silk, paper, or fabric construction |
| **Hide / Leather** | Primarily animal hide, monster skin, leather, fur, horn, or organic backing |
| **Lamellar** | Many small plates, scales, or segments tied or fixed to a backing |
| **Plate** | Large rigid plates or articulated plate assemblies |
| **Layered** | Protection comes from several overlapping materials or underlayers |
| **Concealable** | Can plausibly be disguised as clothing using an appropriate feature |
| **Flexible** | Designed to bend with the body and preserve broad mobility |
| **Full Coverage** | Protects most of the body and normally includes integrated limb protection |
| **Helmet-Compatible** | Designed as a complete suit with a matching helmet or mask |
| **Mirror** | Includes polished reflective plates suitable for Light, Reflection, or authority effects |
| **Mountain** | Uses interlocking or force-spreading construction suitable for Earth, Weight, or Suppression effects |
| **Beast-Compatible** | Can incorporate hide, shell, bone, horn, scales, or beast cores naturally |
| **Metal-Compatible** | Can naturally conduct Metal, Lightning, Magnetic, or forge-based effects |
| **Robe-Compatible** | Can be worn under or integrated into robes without changing its profile |
| **Carried** | A shield or separate guard item held rather than worn |

---

# Enhancement Compatibility Rules

The armor enhancement chapter will use the following default compatibility labels:

- **Any Armor:** Any light, medium, or heavy armor profile.
- **Light Armor:** Padded Battle Robes, Lacquered Leather, or Hidden Brigandine Robes.
- **Medium Armor:** Beast-Hide Harness, Light Lamellar Vest, Lacquered Lamellar, Mirror-Bright Breastplate, or Mountain-Pattern Half Armor.
- **Heavy Armor:** Ring-Lamellar Harness, Full Lamellar Battle Dress, Mountain-Pattern Grand Shell, or Imperial Plate Battle Dress.
- **Shield:** The Shield profile only.
- **Worn Protection:** Any armor or shield.
- **Cloth Armor:** A profile with the Cloth tag.
- **Hide Armor:** A profile with the Hide or Leather tag.
- **Lamellar Armor:** A profile with the Lamellar tag.
- **Plate Armor:** A profile with the Plate tag.
- **Concealable Armor:** A profile with the Concealable tag.
- **Full-Coverage Armor:** A profile with the Full Coverage tag.
- **Helmeted Armor:** A profile with Helmet-Compatible construction whose completed item includes its helmet.
- **Unarmored Battle Dress:** Clothing using an unarmored Armor Class formula; it does not qualify as armor unless an enhancement explicitly permits it.

# Final Armor Entry Requirement

A finished armor treasure must print its complete Armor Class formula. The reader must never infer the profile merely from a name such as “lamellar,” “bright armor,” “war robe,” or “mountain shell.”


## Chapter 3B: Armor Materials
### Primary Material Catalog v0.1

Armor materials determine what a suit naturally resists, conducts, amplifies, and rejects.

This is the second stage of armor construction:

1. Choose an armor or shield profile in Chapter 3A.
2. Choose one Primary Material in this chapter.
3. Choose armor enhancements in Chapter 3C.

A Primary Material grants one inherent property and does not consume enchantment capacity.

---

# Material Rules

## Compatible Profiles

A material can be used only with a profile whose construction can physically support it. A special formula can combine unusual materials, but it must state how the material is integrated.

## Secondary Materials

Secondary Materials can stabilize an opposed enhancement, provide lacing or underlayers, support a helmet or mask, raise a refinement ceiling, or satisfy a special formula.

A Secondary Material does not grant its full material property unless the finished item explicitly says otherwise.

## Material Grade and Ceiling

| Material Grade | Normal Refinement Ceiling |
|---|---|
| Mortal | Spiritual Treasure |
| Spiritual | Saint Treasure |
| Saint | Sovereign Treasure |
| Sovereign | Imperial Treasure |
| Imperial | Immortal Artifact |
| Immortal | Bespoke |

## Opposed Enhancements

Adding an opposed enhancement requires:

- a formula explicitly allowing the combination;
- an appropriate stabilizing Secondary Material;
- an additional special-component cost equal to 25 percent of the armor's base crafting cost.

## Refinement and Armor Class

The armor profile establishes base Armor Class. Treasure grade adds the Refinement Bonus from Chapter 3A. The material property is applied separately.

## Shields

A shield uses the same material rules. Its material property applies while the shield is wielded unless the property says otherwise.

---

# Material Cost Guidance

| Material Grade | Typical Special-Component Value |
|---|---:|
| Mortal | 10–50 GT |
| Spiritual | 1–5 Low-Grade Spirit Stones |
| Saint | 1–5 Mid-Grade Spirit Stones |
| Sovereign | 1–5 High-Grade Spirit Stones |
| Imperial | 1–5 Perfect Spirit Stones |
| Immortal | Unique; no standard market value |


# Mortal Armor Materials

## Hundred-Fold Steel Plates
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Lamellar, plate, ring, and shield profiles  
**Sphere Influences:** Metal, Equipment, Blacksmith  
**Preferred Enhancements:** Impact, Reinforcement, Guard, Repair  
**Opposed Enhancements:** None

**Layered Hardness.** Reduce bludgeoning, piercing, or slashing damage you take from nonmagical attacks by 1. This reduction applies after Resistance.

---

## Lacquered Beast Hide
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Hide, leather, flexible, and beast-compatible profiles  
**Sphere Influences:** Beast, Equipment, Water  
**Preferred Enhancements:** Weather, Poison, Concealment, Mobility  
**Opposed Enhancements:** Fire unless stabilized

**Sealed Hide.** The armor is not damaged by ordinary rain, saltwater, mold, rot, or humidity. You have Advantage on saving throws against environmental cold caused by wet clothing or exposure.

---

## Hundred-Layer Battle Cotton
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Cloth, padded, layered, and robe-compatible profiles  
**Sphere Influences:** Equipment, Force, Life  
**Preferred Enhancements:** Impact, Rest, Breath, Concealment  
**Opposed Enhancements:** Fire unless stabilized

**Impact Padding.** Reduce falling and collision damage you take by 2. The armor can be used as bedding without becoming damaged or unusable.

---

## Rattan-Bamboo Lamellae
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Lamellar, shield, light, and medium profiles  
**Sphere Influences:** Wood, Air, Water  
**Preferred Enhancements:** Mobility, Floating, Returning, Weather  
**Opposed Enhancements:** Fire and heavy Weight enhancements unless stabilized

**Buoyant Weave.** The armor weighs half as much as normal. While conscious, you float in calm water and have Advantage on checks made to avoid sinking.

---

## Spirit-Beast Bone Lamellae
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Lamellar, hide, shield, and beast-compatible profiles  
**Sphere Influences:** Beast, Spirit, Equipment  
**Preferred Enhancements:** Predator, Spirit Guard, Harvesting, Fear  
**Opposed Enhancements:** Corrosion and Fire unless stabilized

**Nonmetal Shell.** The armor is nonmetallic and immune to ordinary rust. Effects that specifically target metal armor do not treat it as metal.

---

## Paper-Lamellar Scripture Sheets
**Material Grade:** Mortal  
**Normal Refinement Ceiling:** Spiritual Treasure  
**Compatible Profiles:** Cloth, layered, concealable, and robe-compatible profiles  
**Sphere Influences:** Ink, Talismans, Equipment  
**Preferred Enhancements:** Concealment, Talismans, Formation, Knowledge  
**Opposed Enhancements:** Water and Fire unless stabilized

**Folded Construction.** Donning or doffing the armor takes half the normal time. A creature has Disadvantage on a visual-only check to recognize it as armor while it is covered by ordinary robes.

---


# Spiritual Armor Materials

## Spirit Iron Lamellae
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Any metal-compatible armor or shield  
**Sphere Influences:** Metal, Qiweaving, Equipment  
**Preferred Enhancements:** Qi Conduction, Reinforcement, Elemental Guard  
**Opposed Enhancements:** None

**Qi-Conductive Shell.** While wearing the armor, you can use it as a focus for Sphere actions and treasure activations that require a worn or held focus. The armor counts as magical before receiving an enhancement.

---

## Cloud Silk
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Cloth, flexible, robe-compatible, and concealable armor  
**Sphere Influences:** Air, Thread, Equipment  
**Preferred Enhancements:** Mobility, Concealment, Falling, Breath  
**Opposed Enhancements:** Weight and heavy Earth enhancements unless stabilized

**Weightless Draping.** The armor weighs one-quarter as much as normal. It does not impose Disadvantage on Dexterity (Acrobatics) checks.

---

## Storm Iron Mesh
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Metal-compatible, lamellar, ring, and plate armor  
**Sphere Influences:** Lightning, Thunder, Metal  
**Preferred Enhancements:** Lightning Guard, Grounding, Retaliation  
**Opposed Enhancements:** Ice unless stabilized

**Grounded Circuit.** Reduce lightning damage you take by your Proficiency Bonus. If this reduces the damage to 0, the armor emits a harmless crack of thunder audible to 100 feet.

---

## Moon Silver Thread
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Cloth, lamellar lacing, hidden plate, and mirror armor  
**Sphere Influences:** Moon, Yin, Reflection  
**Preferred Enhancements:** Illusion Guard, Concealment, Spirit Guard, Mirror  
**Opposed Enhancements:** Solar Fire unless stabilized

**Pale Reflection.** You have Advantage on ability checks made to discern visual illusions affecting your clothing, armor, reflection, or immediate space.

---

## Sun Copper Plates
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Plate, lamellar, shield, and metal-compatible armor  
**Sphere Influences:** Fire, Yang, Radiance  
**Preferred Enhancements:** Fire Guard, Radiance, Vitality, Fear Resistance  
**Opposed Enhancements:** Deep Yin and Cold unless stabilized

**Warm Circulation.** Reduce cold and necrotic damage you take by 1. The armor remains comfortably warm in ordinary freezing weather.

---

## River Jade Scales
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Scale, lamellar, flexible, and shield profiles  
**Sphere Influences:** Water, Flowing River, Movement  
**Preferred Enhancements:** Water Guard, Mobility, Cleansing, Redirection  
**Opposed Enhancements:** Weight unless stabilized

**Flowing Fit.** The armor imposes no penalty on swimming. If you lack a Swim Speed, you can swim at your normal Speed while wearing it.

---

## Frost Jade Segments
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Lamellar, plate, shield, and mountain profiles  
**Sphere Influences:** Ice, Water, Yin  
**Preferred Enhancements:** Cold Guard, Preservation, Slow, Stillness  
**Opposed Enhancements:** Fire unless stabilized

**Cold Preservation.** Reduce fire damage you take by 1. The armor and anything stored in its ordinary pockets are protected from ordinary environmental heat.

---

## Spirit-Beast Hide
**Material Grade:** Spiritual  
**Normal Refinement Ceiling:** Saint Treasure  
**Compatible Profiles:** Hide, leather, flexible, and beast-compatible armor  
**Sphere Influences:** Beast, Predator, Spirit  
**Preferred Enhancements:** Tracking, Mobility, Natural Weapons, Spirit Guard  
**Opposed Enhancements:** Varies by the harvested beast

**Beast Adaptation.** When the armor is created, choose Climb, Swim, or Harsh Climate. You gain a Climb Speed of 10 feet, a Swim Speed of 10 feet, or Advantage on saving throws against ordinary extreme heat and cold, according to the choice.

---


# Saint Armor Materials

## Mountain-Root Jade Plates
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Lamellar, plate, mountain, shield, and full-coverage armor  
**Sphere Influences:** Earth, Weight, Suppression  
**Preferred Enhancements:** Mountain, Stability, Suppression, Impact  
**Opposed Enhancements:** Air and weightless movement unless stabilized

**Mountain-Root Stability.** Forced movement affecting you is reduced by 10 feet. You have Advantage on saving throws against being knocked Prone.

---

## Dragon Scale Lamellae
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Lamellar, plate, hide, and full-coverage armor  
**Sphere Influences:** Dragon, Elemental, Authority  
**Preferred Enhancements:** Elemental Guard, Fear, Flight, Presence  
**Opposed Enhancements:** An element opposed to the dragon source

**Draconic Resistance.** Choose acid, cold, fire, lightning, or poison when the armor is created. You have Resistance to the chosen damage type while wearing it.

---

## Phoenix-Ash Silk
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Cloth, robe-compatible, flexible, and hidden armor  
**Sphere Influences:** Fire, Yang, Renewal  
**Preferred Enhancements:** Fire Guard, Healing, Rebirth, Radiance  
**Opposed Enhancements:** Deep Yin unless stabilized

**Rekindled Weave.** You have Resistance to fire damage. If the armor is destroyed but not disintegrated, placing its remains in a magical fire for 8 hours restores it.

---

## Ghost Iron Mail
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Ring, lamellar, plate, and metal-compatible armor  
**Sphere Influences:** Spirit, Soul, Dark  
**Preferred Enhancements:** Spirit Guard, Possession Defense, Ghost Ward  
**Opposed Enhancements:** Radiant-Sun effects unless stabilized

**Ethereal Barrier.** Incorporeal creatures cannot move through your space unless you permit it. You have Advantage on saving throws against possession.

---

## Voidglass Scales
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Lamellar, plate, mirror, and shield profiles  
**Sphere Influences:** Space, Force, Reflection  
**Preferred Enhancements:** Teleportation Guard, Force Guard, Concealment  
**Opposed Enhancements:** Thunder unless stabilized

**Folded Surface.** Reduce force damage you take by your Proficiency Bonus. Effects cannot teleport the armor away from you while you are attuned to it.

---

## Blood Jade Links
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Lamellar, ring, hidden plate, and beast-compatible armor  
**Sphere Influences:** Blood, Vitality, Lineage  
**Preferred Enhancements:** Healing, Death Guard, Ancestral, Blood  
**Opposed Enhancements:** Purification unless stabilized

**Blood Recognition.** You have Advantage on death saving throws. A creature other than the attuned bearer has Disadvantage on checks made to remove the armor against the bearer's will.

---

## Mirror-Sea Silver
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Mirror, plate, lamellar, and shield profiles  
**Sphere Influences:** Mirror, Moon, Water, Illusion  
**Preferred Enhancements:** Reflection, Illusion Guard, Radiance, Counter  
**Opposed Enhancements:** Thunder unless stabilized

**Still Mirror.** You have Advantage on saving throws against visual illusions and gaze effects. A creature relying on a reflected gaze treats the armor as a valid mirror.

---

## Deepsea Cold Iron
**Material Grade:** Saint  
**Normal Refinement Ceiling:** Sovereign Treasure  
**Compatible Profiles:** Plate, lamellar, heavy, shield, and full-coverage armor  
**Sphere Influences:** Ice, Water, Pressure  
**Preferred Enhancements:** Cold Guard, Pressure, Suppression, Water  
**Opposed Enhancements:** Fire unless stabilized

**Abyssal Pressure.** You have Resistance to cold damage and suffer no harm from ordinary deep-water pressure within the campaign's normal adventuring environments.

---


# Sovereign Armor Materials

## Tribulation Steel
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Any metal-compatible armor or shield  
**Sphere Influences:** Lightning, Thunder, Tribulation  
**Preferred Enhancements:** Calamity Guard, Lightning, Retaliation, Growth  
**Opposed Enhancements:** None

**Calamity Memory.** You have Resistance to lightning and thunder damage. When you succeed on a saving throw against either type, the armor becomes charged until the end of your next turn; the first creature that hits you with a melee attack while charged takes lightning damage equal to your Proficiency Bonus.

---

## Five-Phase Alloy
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Lamellar, plate, ring, shield, and metal-compatible armor  
**Sphere Influences:** Fire, Water, Earth, Metal, Wood  
**Preferred Enhancements:** Five-Phase, Elemental Guard, Adaptation  
**Opposed Enhancements:** None

**Balanced Protection.** At the end of each Long Rest, choose acid, cold, fire, lightning, or poison. You have Resistance to the chosen damage type until you choose again.

---

## Soul Jade Plates
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Plate, lamellar, mirror, helmeted, and full-coverage armor  
**Sphere Influences:** Soul, Spirit, Mind  
**Preferred Enhancements:** Psychic Guard, Possession Defense, Ancestral  
**Opposed Enhancements:** Devouring effects unless stabilized

**Soul Resonance.** You have Resistance to psychic damage and Advantage on saving throws against possession or effects that would directly control your actions.

---

## Heaven-Bearing Stone
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Mountain, plate, shield, and heavy armor  
**Sphere Influences:** Earth, Force, Weight  
**Preferred Enhancements:** Fortress, Impact, Suppression, Guard  
**Opposed Enhancements:** Air and concealment unless stabilized

**Bearing the Blow.** Reduce all damage you take by 2 after applying Resistance. This property cannot reduce damage below 1.

---

## Cloud-Void Crystal
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Plate, lamellar, mirror, and robe-integrated armor  
**Sphere Influences:** Air, Space, Movement  
**Preferred Enhancements:** Mobility, Teleportation, Concealment, Flight  
**Opposed Enhancements:** Weight unless stabilized

**Spatial Lightness.** The armor weighs nothing while worn by its attuned bearer. It imposes no Strength requirement and cannot reduce the bearer's Speed.

---

## World-Turtle Shell
**Material Grade:** Sovereign  
**Normal Refinement Ceiling:** Imperial Treasure  
**Compatible Profiles:** Shield, plate, mountain, and full-coverage heavy armor  
**Sphere Influences:** Earth, Water, Life, Protection  
**Preferred Enhancements:** Fortress, Barrier, Vitality, Stability  
**Opposed Enhancements:** Air unless stabilized

**Ancient Shell.** Your Hit Point maximum increases by twice your Proficiency Bonus while wearing the armor. The armor weighs twice as much as its normal profile unless an Attunement property negates the weight.

---


# Imperial Armor Materials

## Phoenix-Blood Scarlet Gold
**Material Grade:** Imperial  
**Normal Refinement Ceiling:** Immortal Artifact  
**Compatible Profiles:** Plate, lamellar, mirror, and full-coverage armor  
**Sphere Influences:** Fire, Yang, Renewal, Authority  
**Preferred Enhancements:** Fire Guard, Rebirth, Radiance, Armor Spirit  
**Opposed Enhancements:** Deep Yin unless stabilized by an Imperial material

**Phoenix Authority.** You are immune to ordinary environmental fire and have Resistance to fire damage. The first time each Long Rest the armor would be destroyed, it becomes dormant at 1 Hit Point instead.

---

## Heaven-Mark Violet Gold
**Material Grade:** Imperial  
**Normal Refinement Ceiling:** Immortal Artifact  
**Compatible Profiles:** Any metal-compatible armor or shield  
**Sphere Influences:** Dao, Spirit, Inscription, Growth  
**Preferred Enhancements:** Dao Vessel, Armor Spirit, Integration, Growth  
**Opposed Enhancements:** None

**Natural Dao Surface.** The armor's enchantment capacity increases by +1 Equivalent Bonus.

---

## Calamity-Tempered Imperial Gold
**Material Grade:** Imperial  
**Normal Refinement Ceiling:** Immortal Artifact  
**Compatible Profiles:** Plate, lamellar, shield, and full-coverage armor  
**Sphere Influences:** Tribulation, Defense, Lightning  
**Preferred Enhancements:** Calamity Guard, Saving Throws, Barrier, Retaliation  
**Opposed Enhancements:** None

**Tribulation Guard.** When you finish a Short or Long Rest, choose acid, cold, fire, force, lightning, necrotic, radiant, or thunder. You have Resistance to the chosen type until you choose again.

---

## Immortal-Tear Verdant Gold
**Material Grade:** Imperial  
**Normal Refinement Ceiling:** Immortal Artifact  
**Compatible Profiles:** Plate, lamellar, mirror, and robe-integrated armor  
**Sphere Influences:** Water, Wood, Sanctuary, Life  
**Preferred Enhancements:** Healing, Sanctuary, Fear Guard, Purification  
**Opposed Enhancements:** Devouring effects unless stabilized

**Sanctuary Metal.** You have Resistance to necrotic and radiant damage. Allied creatures within 5 feet of you have Advantage on saving throws against being Frightened.

---

## Dragon-Patterned Abyssal Gold
**Material Grade:** Imperial  
**Normal Refinement Ceiling:** Immortal Artifact  
**Compatible Profiles:** Heavy armor, shield, mountain, and full-coverage armor  
**Sphere Influences:** Force, Dragon, Weight, Authority  
**Preferred Enhancements:** Suppression, Force Guard, Fear, Fortress  
**Opposed Enhancements:** None

**Dragon Pressure.** You have Resistance to force damage. Forced movement affecting you is reduced by 20 feet.

---


# Immortal Armor Materials

## Primordial Mother-Weight Essence
**Material Grade:** Immortal  
**Normal Refinement Ceiling:** Bespoke  
**Compatible Profiles:** Heavy armor, shield, mountain, and Dao-vessel armor  
**Sphere Influences:** Origin, Weight, Earth, Suppression  
**Preferred Enhancements:** Immortal Fortress, Suppression, Barrier, Dao Vessel  
**Opposed Enhancements:** Air and Space unless reconciled by an Immortal formula

**One Strand Bears a Mountain.** Reduce all damage you take by your Proficiency Bonus after applying Resistance. You cannot be moved against your will while conscious and standing on a solid surface.

---

## Origin-Void Copper
**Material Grade:** Immortal  
**Normal Refinement Ceiling:** Bespoke  
**Compatible Profiles:** Any armor or shield built by an Immortal formula  
**Sphere Influences:** Origin, Space, Counteraction, Suppression  
**Preferred Enhancements:** Anti-Teleportation, Anti-Control, Law Guard, Dao Vessel  
**Opposed Enhancements:** None

**Autonomous Counteraction.** You are immune to forced teleportation and have Advantage on saving throws against possession and effects that would directly control your actions.

---

## World-Heart Crystal
**Material Grade:** Immortal  
**Normal Refinement Ceiling:** Bespoke  
**Compatible Profiles:** Plate, shield, formation armor, and world-vessel armor  
**Sphere Influences:** World, Space, Formation, Growth  
**Preferred Enhancements:** Domain, Formation, Barrier, Dao Vessel  
**Opposed Enhancements:** Destructive Devouring unless explicitly integrated

**Seeded Sanctuary.** The armor can anchor a domain, demiplane entrance, or formation property defined by a separate Immortal enhancement. It is immune to force damage dealt to objects and cannot be removed or teleported against the attuned bearer's will.

---

## Enlightenment Tree Heartwood
**Material Grade:** Immortal  
**Normal Refinement Ceiling:** Bespoke  
**Compatible Profiles:** Shield, lamellar, cloth-reinforced, and spirit armor  
**Sphere Influences:** Wood, Dao, Mind, Comprehension  
**Preferred Enhancements:** Mind Guard, Dao Clarity, Spirit, Growth  
**Opposed Enhancements:** Corruption and Devouring unless reconciled

**Clarity Grain.** You have Advantage on Intelligence and Wisdom saving throws and on checks made to understand hostile inscriptions, formations, curses, or supernatural armor effects currently affecting you.

---

# Final Armor Material Record

Every finished armor or shield must state:

- legal profile from Chapter 3A;
- Primary Material;
- Material Grade and ceiling;
- material property;
- finished treasure grade;
- Refinement Bonus;
- every enhancement from Chapter 3C;
- required stabilizers;
- final Armor Class formula;
- Attunement slots.


## Chapter 3C: Armor Enhancements
### Equivalent-Bonus Catalog v0.1

Armor enhancements are inscriptions, lacing methods, hidden circuits, seals, lining, plates, masks, mirror surfaces, and awakened defensive techniques added after selecting the armor profile and Primary Material.

This is the third stage of armor construction.

1. Select an armor or shield profile in Chapter 3A.
2. Select a Primary Material in Chapter 3B.
3. Fill the item's enhancement capacity with enhancements from this chapter.

---

# Refinement Bonus and Enhancement Capacity

| Finished Grade | Armor or Shield Refinement Bonus | Enchantment Capacity |
|---|---:|---:|
| Spiritual Treasure | **+1 AC** | **+1** |
| Saint Treasure | **+2 AC** | **+3** |
| Sovereign Treasure | **+3 AC** | **+6** |
| Imperial Treasure | **+4 AC** | **+10** |
| Immortal Artifact | **+5 AC baseline or bespoke** | **Bespoke; normally +12 or higher** |

## Refinement Bonus

The Refinement Bonus is the actual bonus added to the armor's Armor Class or the shield's Armor Class bonus.

## Equivalent Bonus

Each enhancement has an Equivalent Bonus from +1 to +6.

Equivalent Bonus:

- measures the enhancement's power;
- counts against enhancement capacity;
- does not add directly to Armor Class unless its rules explicitly say it does;
- must be printed in the final item record.

## Total Effective Bonus

> **Total Effective Bonus = Refinement Bonus + Total Enhancement Value**

This is a construction and valuation number, not the item's Armor Class bonus.

## Armor and Shield Stacking

A suit of armor and a shield can each provide their own Refinement Bonus. Both can apply when worn or wielded legally.

Each normally requires Attunement and occupies one of the character's four Attunement slots.

## Persistent and Activated Defense

Ordinary passive enhancements function whenever their conditions are met.

Frequency limits are reserved for:

- a discrete reflection;
- a barrier activation;
- a teleportation escape;
- a shield interception;
- a domain;
- an automatic saving throw success;
- an Immortal manifestation.

Use explicit Reactions, charges, CP costs, dormancy, or per-rest recovery instead of a blanket once-per-turn limitation.

## Sphere Influences

Sphere Influences identify the Tianxia spheres that inspire or naturally align with an enhancement. They do not grant a Sphere and are not prerequisites unless an item explicitly says otherwise.

---

# Enhancement Summary

| Value | Enhancement | Minimum Grade | Compatibility |
|---:|---|---|---|
| **+1** | Silent Lacing | Spiritual Treasure | Any armor that normally imposes Stealth Disadvantage |
| **+1** | Weightless Harness | Spiritual Treasure | Any armor |
| **+1** | Sure-Strap Inscription | Spiritual Treasure | Any armor or shield |
| **+1** | Quick-Release Clasps | Spiritual Treasure | Any armor or shield |
| **+1** | Restful Inner Robe | Spiritual Treasure | Any armor |
| **+1** | Hidden Plates Glamour | Spiritual Treasure | Light or medium armor; concealable heavy armor by explicit formula |
| **+1** | Helmet-Seal Inscription | Spiritual Treasure | Helmet-compatible armor |
| **+1** | Padded Impact Layers | Spiritual Treasure | Any armor |
| **+1** | Fire-Shedding Lining | Spiritual Treasure | Any armor |
| **+1** | Frost-Shedding Lining | Spiritual Treasure | Any armor |
| **+1** | Lightning-Grounding Mesh | Spiritual Treasure | Metal-compatible, lamellar, plate, or shield |
| **+1** | Poison-Filtering Collar | Spiritual Treasure | Any armor with a collar, mask, hood, or helmet |
| **+1** | Sound-Dampening Felt | Spiritual Treasure | Cloth, layered, hidden, or helmeted armor |
| **+1** | Water-Sealed Weave | Spiritual Treasure | Any armor |
| **+1** | Featherfall Skirt | Spiritual Treasure | Any worn armor |
| **+1** | Dark-Sight Visor | Spiritual Treasure | Helmet-compatible armor |
| **+1** | Qi-Conductive Lacing | Spiritual Treasure | Any armor |
| **+1** | Talisman Socket | Spiritual Treasure | Any armor or shield |
| **+1** | Formation-Guard Stitching | Spiritual Treasure | Any armor |
| **+1** | Beast-Scent Masking | Spiritual Treasure | Hide, cloth, or concealable armor |
| **+1** | Self-Mending Lacquer | Spiritual Treasure | Any armor or shield |
| **+1** | Meridian-Clear Underlayer | Spiritual Treasure | Any worn armor |
| **+1** | Anti-Corrosion Temper | Spiritual Treasure | Metal, plate, lamellar, ring, or shield |
| **+1** | Grasp-Breaking Plates | Spiritual Treasure | Medium or heavy armor |
| **+1** | Pilgrim's Pocket Lining | Spiritual Treasure | Any armor |
| **+1** | Rank-Bearing Mirror Plates | Spiritual Treasure | Mirror, plate, lamellar, or ceremonial armor |
| **+2** | Elemental Resistance Weave | Saint Treasure | Any armor or shield |
| **+2** | Force-Dispersal Circuit | Saint Treasure | Any armor or shield |
| **+2** | Mirror-Flash Reversal | Saint Treasure | Mirror, plate, shield, or robe-compatible armor |
| **+2** | Guardian Intercession Harness | Saint Treasure | Medium or heavy armor |
| **+2** | Spirit-Guarding Hood | Saint Treasure | Helmeted or hooded armor |
| **+2** | Void-Step Escape Lining | Saint Treasure | Any armor |
| **+2** | Stone-Root Stabilizers | Saint Treasure | Medium or heavy armor |
| **+2** | Cloud-Walking Greaves | Saint Treasure | Any worn armor |
| **+2** | Iron Rain Deflection | Saint Treasure | Medium armor, heavy armor, or shield |
| **+2** | Blood-Sealing Inner Layer | Saint Treasure | Any armor |
| **+2** | Regenerative Lacquer | Saint Treasure | Any armor or shield |
| **+2** | Law-Resisting Seal Plates | Saint Treasure | Any armor or shield |
| **+2** | Concealing Mist Mantle | Saint Treasure | Cloth, robe-compatible, hide, or concealable armor |
| **+2** | Thorn-Retaliation Plates | Saint Treasure | Medium armor, heavy armor, or shield |
| **+2** | Cold-Iron Spirit Cage | Saint Treasure | Metal-compatible or helmeted armor |
| **+2** | Formation-Circuit Armor | Saint Treasure | Any armor |
| **+2** | Second-Skin Transformation | Saint Treasure | Any armor |
| **+2** | Shield-Link Inscription | Saint Treasure | Shield only |
| **+2** | Deflecting Shield Face | Saint Treasure | Shield only |
| **+2** | Heaven-Breath Filter | Saint Treasure | Helmeted armor |
| **+3** | Sovereign Resistance Matrix | Sovereign Treasure | Any armor or shield |
| **+3** | Mountain-Pattern Fortress | Sovereign Treasure | Mountain, plate, heavy armor, or shield |
| **+3** | Mirror-Heaven Counter | Sovereign Treasure | Mirror armor or shield |
| **+3** | Walking Barrier Mantle | Sovereign Treasure | Any armor |
| **+3** | Space-Folded Evasion | Sovereign Treasure | Light or medium armor |
| **+3** | Ancestral Battle-Dress Spirit | Sovereign Treasure | Any armor |
| **+3** | Elemental Conversion Shell | Sovereign Treasure | Any armor or shield |
| **+3** | Ninefold Dragon Guard | Sovereign Treasure | Shield only |
| **+4** | Ten-Thousand Plate Domain | Imperial Treasure | Medium or heavy armor |
| **+4** | Heaven-Veil Imperial Robe | Imperial Treasure | Cloth, robe-compatible, or concealable armor |
| **+4** | Calamity-Sheltering Shell | Imperial Treasure | Any armor or shield |
| **+4** | Immovable Mountain Grand Shell | Imperial Treasure | Heavy armor or shield |
| **+4** | Voidless Sanctuary Armor | Imperial Treasure | Any armor |
| **+4** | Heaven-Turning Shield Face | Imperial Treasure | Shield only |
| **+5** | One Armor Bears Ten Thousand Calamities | Immortal Artifact | Immortal armor or shield |
| **+6** | World-Sheltering Immortal Battle Dress | Immortal Artifact | Immortal armor |


# +1 Enhancements — Minor Armor Enhancements

## Silent Lacing
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor that normally imposes Stealth Disadvantage  
**Family:** Mobility and Concealment  
**Sphere Influences:** Equipment, Shadow, Thread  
**Preferred Materials:** Cloud silk, moon silver thread, hidden brigandine

The armor does not impose Disadvantage on Dexterity (Stealth) checks.

---

## Weightless Harness
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Mobility and Comfort  
**Sphere Influences:** Equipment, Air, Athletics  
**Preferred Materials:** Cloud silk, cloud-void crystal, rattan-bamboo

The armor weighs half as much as normal. You ignore its Strength requirement when determining whether it reduces your Speed.

---

## Sure-Strap Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor or shield  
**Family:** Fitting and Security  
**Sphere Influences:** Equipment, Athletics, Wrestling  
**Preferred Materials:** Spirit iron, blood jade, layered leather

The item cannot be removed, disarmed, or dropped against your will while you are conscious.

---

## Quick-Release Clasps
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor or shield  
**Family:** Fitting and Security  
**Sphere Influences:** Equipment, Space, Blacksmith  
**Preferred Materials:** Spirit iron, voidglass, paper-lamellar

Donning or doffing the item takes half the normal time. If another feature already halves that time, it instead takes one-quarter the normal time.

---

## Restful Inner Robe
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Rest and Recovery  
**Sphere Influences:** Equipment, Life, Medicine  
**Preferred Materials:** Cloud silk, battle cotton, phoenix-ash silk

You can complete a Long Rest while wearing the armor without suffering a penalty solely from sleeping in armor.

---

## Hidden Plates Glamour
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Light or medium armor; concealable heavy armor by explicit formula  
**Family:** Mobility and Concealment  
**Sphere Influences:** Equipment, Illusion, Shadow  
**Preferred Materials:** Moon silver thread, paper-lamellar, voidglass

As a Bonus Action, make the armor appear to be ordinary clothing of the same general size. Physical inspection reveals the armor. A creature studying it from sight alone must succeed on an Intelligence (Investigation) check against your item save DC.

---

## Helmet-Seal Inscription
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Helmet-compatible armor  
**Family:** Critical Protection  
**Sphere Influences:** Equipment, Protection, Metal  
**Preferred Materials:** Spirit iron, mountain jade, dragon scale

When a critical hit is scored against you, you can cause it to become a normal hit. Once used, this property cannot be used again until you complete a Long Rest.

---

## Padded Impact Layers
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Impact Protection  
**Sphere Influences:** Equipment, Force, Life  
**Preferred Materials:** Battle cotton, beast hide, world-turtle shell

Reduce falling and collision damage you take by your Proficiency Bonus. Reduce bludgeoning damage from unattended falling objects by the same amount.

---

## Fire-Shedding Lining
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Elemental Guard  
**Sphere Influences:** Fire, Protection, Equipment  
**Preferred Materials:** Sun copper, phoenix-ash silk, fireproof hide

Reduce fire damage you take by your Proficiency Bonus. This reduction applies after Resistance.

---

## Frost-Shedding Lining
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Elemental Guard  
**Sphere Influences:** Ice, Protection, Equipment  
**Preferred Materials:** Frost jade, deepsea cold iron, winter beast fur

Reduce cold damage you take by your Proficiency Bonus. This reduction applies after Resistance.

---

## Lightning-Grounding Mesh
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Metal-compatible, lamellar, plate, or shield  
**Family:** Elemental Guard  
**Sphere Influences:** Lightning, Earth, Metal  
**Preferred Materials:** Storm iron, tribulation steel, spirit copper

Reduce lightning damage you take by your Proficiency Bonus. This reduction applies after Resistance.

---

## Poison-Filtering Collar
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor with a collar, mask, hood, or helmet  
**Family:** Hazard Protection  
**Sphere Influences:** Poison, Medicine, Equipment  
**Preferred Materials:** Medicine jade, purified silver, beast filters

You have Advantage on saving throws against inhaled poison and the Poisoned condition caused by an inhaled effect.

---

## Sound-Dampening Felt
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Cloth, layered, hidden, or helmeted armor  
**Family:** Mobility and Concealment  
**Sphere Influences:** Sound, Shadow, Equipment  
**Preferred Materials:** Hush felt, cloud silk, black bamboo fiber

The armor produces no sound from plates, rings, lacing, or movement. This does not silence your voice, footsteps on noisy terrain, weapons, or impacts.

---

## Water-Sealed Weave
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Hazard Protection  
**Sphere Influences:** Water, Equipment, Flowing River  
**Preferred Materials:** River jade, lacquered hide, water silk

The armor functions normally underwater, never becomes waterlogged, and protects ordinary worn clothing and papers beneath it from rain and brief immersion.

---

## Featherfall Skirt
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any worn armor  
**Family:** Mobility  
**Sphere Influences:** Air, Athletics, Equipment  
**Preferred Materials:** Cloud silk, feathered jade, spirit bamboo

When you fall, reduce the distance used to calculate falling damage by 30 feet. You land on your feet if you are not Incapacitated.

---

## Dark-Sight Visor
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Helmet-compatible armor  
**Family:** Detection  
**Sphere Influences:** Dark, The Hidden Eye, Equipment  
**Preferred Materials:** Moon silver, ghost iron, dark crystal

While the visor is worn, you have Darkvision out to 60 feet. If you already have Darkvision, its range increases by 30 feet.

---

## Qi-Conductive Lacing
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Integration  
**Sphere Influences:** Qiweaving, Imbuement, Equipment  
**Preferred Materials:** Spirit iron, spirit silk, heaven-mark gold

You can use the armor as a focus for Sphere actions and treasures that require a worn focus. Wearing it does not interfere with somatic movement required by a Tianxia technique.

---

## Talisman Socket
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor or shield  
**Family:** Integration  
**Sphere Influences:** Talismans, Imbuement, Equipment  
**Preferred Materials:** White jade, paper-lamellar, spirit iron

During a Short or Long Rest, attach one consumable talisman to the item. You can activate it without holding it in a free hand. The item can hold only one talisman at a time.

---

## Formation-Guard Stitching
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Integration  
**Sphere Influences:** Formations, Protection, Equipment  
**Preferred Materials:** Formation jade, spirit thread, source stone

You have Advantage on saving throws against harmful effects created by a Formation Anchor you can see within 30 feet.

---

## Beast-Scent Masking
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Hide, cloth, or concealable armor  
**Family:** Hunting and Concealment  
**Sphere Influences:** Predator, Beastmastery, Shadow  
**Preferred Materials:** Spirit-beast hide, cloud silk, scentless lacquer

Creatures relying primarily on smell have Disadvantage on Wisdom (Perception) and Wisdom (Survival) checks made to detect or track you.

---

## Self-Mending Lacquer
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor or shield  
**Family:** Maintenance  
**Sphere Influences:** Blacksmith, Life, Equipment  
**Preferred Materials:** Phoenix ash, living lacquer, spirit iron

During a Short Rest, the item repairs all ordinary dents, cuts, torn straps, scorch marks, and cosmetic damage. This does not restore a destroyed item or remove a supernatural flaw.

---

## Meridian-Clear Underlayer
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any worn armor  
**Family:** Integration  
**Sphere Influences:** Pressure Points, Qiweaving, Equipment  
**Preferred Materials:** Medicine silk, spirit cotton, meridian thread

You have Advantage on saving throws against effects that would prevent you from spending CP, Stamina, or Resonance.

---

## Anti-Corrosion Temper
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Metal, plate, lamellar, ring, or shield  
**Family:** Maintenance  
**Sphere Influences:** Alchemy, Metal, Blacksmith  
**Preferred Materials:** Spirit iron, purified silver, alchemical lacquer

The item is immune to nonmagical rust and corrosion. You have Advantage on saving throws against effects that specifically corrode or destroy worn armor.

---

## Grasp-Breaking Plates
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Medium or heavy armor  
**Family:** Escape and Stability  
**Sphere Influences:** Wrestling, Force, Equipment  
**Preferred Materials:** Mountain jade, smooth plate, voidglass

You have Advantage on ability checks and saving throws made to escape a Grapple.

---

## Pilgrim's Pocket Lining
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Any armor  
**Family:** Utility  
**Sphere Influences:** Space, Equipment, Sect Stewardship  
**Preferred Materials:** Voidglass, folded silk, spatial jade

The armor contains extradimensional pockets holding up to 50 pounds or 5 cubic feet. Retrieving a hand-held object requires a Bonus Action. Living creatures cannot enter the pockets.

---

## Rank-Bearing Mirror Plates
**Minimum Grade:** Spiritual Treasure  
**Equivalent Bonus:** **+1**  
**Compatibility:** Mirror, plate, lamellar, or ceremonial armor  
**Family:** Authority and Display  
**Sphere Influences:** Warleader, Radiance, Equipment  
**Preferred Materials:** Mirror-sea silver, sun copper, polished jade

You have Advantage on Charisma checks made to display recognized military, sect, clan, court, or ancestral authority while the armor is visible. This property does not create authority you do not possess.

---


# +2 Enhancements — Major Armor Enhancements

## Elemental Resistance Weave
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor or shield  
**Family:** Elemental Guard  
**Sphere Influences:** Protection, Five-Phase, Equipment  
**Preferred Materials:** A material aligned with the chosen element

Choose acid, cold, fire, lightning, poison, or thunder when the enhancement is created. You have Resistance to the chosen damage type.

---

## Force-Dispersal Circuit
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor or shield  
**Family:** Impact Protection  
**Sphere Influences:** Force, Equipment, Protection  
**Preferred Materials:** Voidglass, mountain jade, spirit iron

You have Resistance to force damage. If another property already grants this Resistance, reduce force damage you take by your Proficiency Bonus after applying Resistance.

---

## Mirror-Flash Reversal
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Mirror, plate, shield, or robe-compatible armor  
**Family:** Defensive Reaction  
**Sphere Influences:** Mirror, Light, Flowing River  
**Preferred Materials:** Mirror-sea silver, moon silver, stillwater jade

When a creature you can see makes an attack roll against you, you can use your Reaction and spend 1 CP to impose Disadvantage on that roll. If it misses, you can move up to 10 feet without provoking Opportunity Attacks from that creature.

---

## Guardian Intercession Harness
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Medium or heavy armor  
**Family:** Ally Protection  
**Sphere Influences:** Guardian, Equipment, Protection  
**Preferred Materials:** World-turtle shell, mountain jade, spirit iron

When an ally within 5 feet is hit by an attack, you can use your Reaction to exchange spaces with that ally if both spaces can hold you. You become the target of the attack, which is resolved against your Armor Class.

---

## Spirit-Guarding Hood
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Helmeted or hooded armor  
**Family:** Spirit Defense  
**Sphere Influences:** Spirit, Radiance, Protection  
**Preferred Materials:** Soul jade, moon silver, enlightenment wood

You have Advantage on saving throws against the Charmed and Frightened conditions and against possession.

---

## Void-Step Escape Lining
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor  
**Family:** Escape  
**Sphere Influences:** Space, Shadow, Equipment  
**Preferred Materials:** Voidglass, cloud-void crystal, moon silver thread

When you take damage, you can use your Reaction and spend 2 CP to teleport to an unoccupied space you can see within 30 feet after the damage resolves.

---

## Stone-Root Stabilizers
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Medium or heavy armor  
**Family:** Stability  
**Sphere Influences:** Earth, Equipment, Gravity  
**Preferred Materials:** Mountain-root jade, heaven-bearing stone, heavy alloy

At the start of your turn, you can spend 10 feet of movement to root the armor until the start of your next turn. While rooted on a solid surface, you cannot be moved against your will or knocked Prone unless you choose to be.

---

## Cloud-Walking Greaves
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any worn armor  
**Family:** Mobility  
**Sphere Influences:** Air, Athletics, Equipment  
**Preferred Materials:** Cloud silk, feathered crystal, spirit bamboo

During your turn, you can move across liquids and open air as though they were solid ground. If you end your turn unsupported, you fall.

---

## Iron Rain Deflection
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Medium armor, heavy armor, or shield  
**Family:** Projectile Defense  
**Sphere Influences:** Equipment, Shield, Air  
**Preferred Materials:** Spirit iron, mountain jade, mirror silver

Ranged weapon attacks against you have Disadvantage while you are at least 30 feet from the attacker. This does not affect siege weapons or attacks that ignore cover.

---

## Blood-Sealing Inner Layer
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor  
**Family:** Vitality  
**Sphere Influences:** Blood, Medicine, Life  
**Preferred Materials:** Blood jade, medicine silk, phoenix ash

When you would drop to 0 Hit Points but not die outright, you can drop to 1 Hit Point instead. Once used, this property cannot be used again until you complete a Long Rest.

---

## Regenerative Lacquer
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor or shield  
**Family:** Recovery  
**Sphere Influences:** Life, Verdant Growth, Blacksmith  
**Preferred Materials:** Living lacquer, phoenix ash, verdant gold

Whenever you spend one or more Hit Dice to regain Hit Points, regain additional Hit Points equal to your Proficiency Bonus. The item also repairs itself fully during the rest.

---

## Law-Resisting Seal Plates
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor or shield  
**Family:** Supernatural Defense  
**Sphere Influences:** Protection, Dao, Talismans  
**Preferred Materials:** Sealing jade, heaven-mark gold, spirit iron

You have Advantage on saving throws against spells, Sphere actions, treasure effects, and other explicitly supernatural effects.

---

## Concealing Mist Mantle
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Cloth, robe-compatible, hide, or concealable armor  
**Family:** Concealment  
**Sphere Influences:** Smoke, Shadow, Water  
**Preferred Materials:** Cloud silk, moon silver thread, smoke crystal

The armor has 3 Mist charges and regains 1d3 charges after a Long Rest. As a Bonus Action, expend 1 charge to become Invisible until the start of your next turn or until you make an attack, deal damage, or force a saving throw.

---

## Thorn-Retaliation Plates
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Medium armor, heavy armor, or shield  
**Family:** Retaliation  
**Sphere Influences:** Verdant Growth, Metal, Retribution  
**Preferred Materials:** Thornwood, dragon scale, hooked plate

Whenever a creature within 5 feet hits you with a melee attack, it takes piercing damage equal to your Proficiency Bonus.

---

## Cold-Iron Spirit Cage
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Metal-compatible or helmeted armor  
**Family:** Spirit Defense  
**Sphere Influences:** Spirit, Metal, Sealing  
**Preferred Materials:** Ghost iron, deepsea cold iron, soul jade

A possessing creature cannot enter you while you are conscious. If an effect would possess you despite this property, you have Advantage on the saving throw and the possessing creature takes psychic damage equal to twice your Proficiency Bonus on a failed attempt.

---

## Formation-Circuit Armor
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor  
**Family:** Integration  
**Sphere Influences:** Formations, Qiweaving, Equipment  
**Preferred Materials:** Formation jade, spirit iron, source stone

While you are inside a friendly Formation, add 1 to saving throws and to your item save DC. This bonus does not stack with another Formation-Circuit Armor.

---

## Second-Skin Transformation
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Any armor  
**Family:** Fitting and Concealment  
**Sphere Influences:** Equipment, Imbuement, Space  
**Preferred Materials:** Cloud silk, voidglass, living lacquer

As an Action, the armor folds into a Tiny ornament or unfolds around you. Transforming it does not provoke Opportunity Attacks. While folded, it provides no Armor Class or other worn benefits.

---

## Shield-Link Inscription
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Shield only  
**Family:** Ally Protection  
**Sphere Influences:** Shield, Guardian, Equipment  
**Preferred Materials:** World-turtle shell, mountain jade, spirit iron

An ally within 5 feet of you gains Half Cover while you wield the shield and are not Incapacitated. This does not stack with other Half Cover.

---

## Deflecting Shield Face
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Shield only  
**Family:** Shield Reaction  
**Sphere Influences:** Shield, Equipment, Force  
**Preferred Materials:** Mirror silver, mountain jade, spirit iron

When you or an ally within 5 feet takes damage from an attack, use your Reaction and spend 1 CP to reduce the damage by `2d8 + your Proficiency Bonus`.

---

## Heaven-Breath Filter
**Minimum Grade:** Saint Treasure  
**Equivalent Bonus:** **+2**  
**Compatibility:** Helmeted armor  
**Family:** Hazard Protection  
**Sphere Influences:** Air, Poison, Equipment  
**Preferred Materials:** Cloud silk, medicine jade, spirit filters

You can breathe normally in smoke, gas, underwater, and in airless environments for up to 1 hour. Afterward, the filter must recharge during a Short or Long Rest.

---


# +3 Enhancements — Greater Armor Enhancements

## Sovereign Resistance Matrix
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Any armor or shield  
**Family:** Elemental Guard  
**Sphere Influences:** Protection, Five-Phase, Equipment  
**Preferred Materials:** Five-phase alloy, dragon scale, calamity gold

Choose two damage types from acid, cold, fire, lightning, poison, psychic, radiant, necrotic, or thunder when the enhancement is created. You have Resistance to both chosen types.

---

## Mountain-Pattern Fortress
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Mountain, plate, heavy armor, or shield  
**Family:** Fortress  
**Sphere Influences:** Earth, Force, Equipment  
**Preferred Materials:** Mountain-root jade, heaven-bearing stone, world-turtle shell

Reduce all damage you take by your Proficiency Bonus after applying Resistance. This property cannot reduce damage below 1.

---

## Mirror-Heaven Counter
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Mirror armor or shield  
**Family:** Reflection  
**Sphere Influences:** Mirror, Light, Retribution  
**Preferred Materials:** Mirror-sea silver, moon silver, stillwater jade

When an attack made by a creature you can see damages you, use your Reaction and spend 2 CP to reduce the damage by `4d8 + your Proficiency Bonus`. If reduced to 0, make a ranged item attack against the attacker within 120 feet; on a hit, it takes 4d8 force damage.

---

## Walking Barrier Mantle
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Any armor  
**Family:** Barrier  
**Sphere Influences:** Protection, Force, Equipment  
**Preferred Materials:** World-turtle shell, voidglass, formation jade

The armor has 5 Barrier charges and regains `1d4 + 1` after a Long Rest. As a Bonus Action, expend 2 charges to gain a barrier with 30 Hit Points for 1 minute. Damage is dealt to the barrier before you. The barrier has your AC and ends at 0 Hit Points.

---

## Space-Folded Evasion
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Light or medium armor  
**Family:** Escape  
**Sphere Influences:** Space, Athletics, Shadow  
**Preferred Materials:** Cloud-void crystal, voidglass, cloud silk

When an attack roll would hit you, use your Reaction and spend 2 CP to teleport up to 30 feet to a visible unoccupied space. If the new space is outside the attack's reach or line, the attack misses; otherwise, it is resolved normally.

---

## Ancestral Battle-Dress Spirit
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Any armor  
**Family:** Armor Spirit  
**Sphere Influences:** Spirit Companions, Equipment, Warleader  
**Preferred Materials:** Soul jade, heaven-mark gold, ancestral cloth

The armor contains an awakened ancestral instinct. You cannot be surprised while conscious, and when you roll initiative with 0 Temporary Hit Points, you gain Temporary Hit Points equal to twice your Proficiency Bonus.

---

## Elemental Conversion Shell
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Any armor or shield  
**Family:** Adaptation  
**Sphere Influences:** Five-Phase, Qiweaving, Equipment  
**Preferred Materials:** Five-phase alloy, dragon scale, calamity gold

At the end of each Short or Long Rest, choose acid, cold, fire, lightning, or poison. You have Resistance to that type, and when you take damage of that type, you can change it to another type from the list before applying Resistance.

---

## Ninefold Dragon Guard
**Minimum Grade:** Sovereign Treasure  
**Equivalent Bonus:** **+3**  
**Compatibility:** Shield only  
**Family:** Shield and Suppression  
**Sphere Influences:** Shield, Dragon, Force  
**Preferred Materials:** Dragon scale, abyssal gold, mountain jade

When you take the Utilize action to raise the shield, choose a 15-foot cone originating from you until the start of your next turn. You and allies in the cone have Three-Quarters Cover against attacks and effects originating outside the cone.

---


# +4 Enhancements — Apex Armor Enhancements

## Ten-Thousand Plate Domain
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Medium or heavy armor  
**Family:** Defensive Domain  
**Sphere Influences:** Equipment, Formations, Protection  
**Preferred Materials:** Heaven-mark gold, world-turtle shell, formation jade

The armor has 5 Domain charges and regains `1d4 + 1` after a Long Rest. As an Action, expend 3 charges to create a 20-foot Emanation for 1 minute, requiring Concentration. Allies in the area reduce all damage they take by your Proficiency Bonus. Hostile creatures treat the area as Difficult Terrain.

---

## Heaven-Veil Imperial Robe
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Cloth, robe-compatible, or concealable armor  
**Family:** Imperial Guard  
**Sphere Influences:** Force, Radiance, Equipment  
**Preferred Materials:** Cloud silk, immortal-tear gold, heaven-mark gold

You have Resistance to force damage. When a creature within 60 feet damages you, use your Reaction and spend 2 CP to make a ranged item attack against it. On a hit, it takes 6d8 force damage and cannot take Reactions until the start of its next turn.

---

## Calamity-Sheltering Shell
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Any armor or shield  
**Family:** Saving Throw Defense  
**Sphere Influences:** Tribulation, Protection, Equipment  
**Preferred Materials:** Calamity-tempered gold, tribulation steel, dragon scale

When you fail a saving throw, you can choose to succeed instead. Afterward, this enhancement becomes dormant until you complete a Long Rest. While dormant, it provides no benefit.

---

## Immovable Mountain Grand Shell
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Heavy armor or shield  
**Family:** Fortress  
**Sphere Influences:** Earth, Gravity, Suppression  
**Preferred Materials:** Mother-weight essence, abyssal gold, heaven-bearing stone

You cannot be moved against your will, knocked Prone, or teleported against your will while conscious. You count as one size larger when determining your carrying capacity and whether another creature can Grapple or Shove you.

---

## Voidless Sanctuary Armor
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Any armor  
**Family:** Sanctuary  
**Sphere Influences:** Space, Protection, Sealing  
**Preferred Materials:** Origin-void copper, world-heart crystal, voidglass

You and allied creatures within 10 feet cannot be teleported or moved between planes against your will. Teleportation into the area by a hostile creature requires a Charisma saving throw against your item save DC; on a failure, the teleportation is wasted.

---

## Heaven-Turning Shield Face
**Minimum Grade:** Imperial Treasure  
**Equivalent Bonus:** **+4**  
**Compatibility:** Shield only  
**Family:** Shield Apex  
**Sphere Influences:** Shield, Force, Retribution  
**Preferred Materials:** Abyssal gold, mirror-sea silver, world-turtle shell

The shield has 3 Turning charges and regains 1 charge after a Long Rest. When a line, cone, or ranged attack would affect you, use your Reaction and expend 1 charge. You gain Total Cover against that effect until it resolves. If it is a line or ranged attack, choose a new legal direction or target for the effect from your space.

---


# +5 Enhancements — Immortal Armor Enhancements

## One Armor Bears Ten Thousand Calamities
**Minimum Grade:** Immortal Artifact  
**Equivalent Bonus:** **+5**  
**Compatibility:** Immortal armor or shield  
**Family:** Immortal Defense  
**Sphere Influences:** Dao, Protection, Tribulation, Equipment  
**Preferred Materials:** Primordial mother-weight essence, origin-void copper, world-heart crystal

You have Resistance to all damage except psychic. Whenever you take damage, reduce it by your Proficiency Bonus after applying Resistance. As an Action once per Long Rest, create a 30-foot Emanation for 1 minute, requiring Concentration. Allies in the area gain your damage reduction and Advantage on all saving throws.

---


# +6 Enhancements — Supreme Immortal Armor Enhancements

## World-Sheltering Immortal Battle Dress
**Minimum Grade:** Immortal Artifact  
**Equivalent Bonus:** **+6**  
**Compatibility:** Immortal armor  
**Family:** World Sanctuary  
**Sphere Influences:** World, Formation, Protection, Dao  
**Preferred Materials:** World-heart crystal, origin-void copper, Immortal divine material

Your Armor Class increases by an additional +2 beyond the item's Refinement Bonus. You are immune to forced movement, forced teleportation, possession, and effects that would directly control your actions. Once per Long Rest, as an Action, create a 60-foot-radius sanctuary for 1 minute without Concentration. Allies inside have Resistance to all damage and cannot be reduced below 1 Hit Point while you remain conscious. When the sanctuary ends, the armor becomes dormant until you complete a Long Rest; while dormant, it loses the additional +2 AC and all benefits of this enhancement.

---


# Sphere Influence Index

| Sphere | Common Enhancements |
|---|---|
| Air | Weightless Harness, Featherfall Skirt, Cloud-Walking Greaves, Iron Rain Deflection, Heaven-Breath Filter |
| Alchemy | Anti-Corrosion Temper |
| Athletics | Weightless Harness, Sure-Strap Inscription, Featherfall Skirt, Cloud-Walking Greaves, Space-Folded Evasion |
| Beastmastery | Beast-Scent Masking |
| Blacksmith | Quick-Release Clasps, Self-Mending Lacquer, Anti-Corrosion Temper, Regenerative Lacquer |
| Blood | Blood-Sealing Inner Layer |
| Dao | Law-Resisting Seal Plates, One Armor Bears Ten Thousand Calamities, World-Sheltering Immortal Battle Dress |
| Dark | Dark-Sight Visor |
| Dragon | Ninefold Dragon Guard |
| Earth | Lightning-Grounding Mesh, Stone-Root Stabilizers, Mountain-Pattern Fortress, Immovable Mountain Grand Shell |
| Equipment | Silent Lacing, Weightless Harness, Sure-Strap Inscription, Quick-Release Clasps, Restful Inner Robe, Hidden Plates Glamour, Helmet-Seal Inscription, Padded Impact Layers, Fire-Shedding Lining, Frost-Shedding Lining, Poison-Filtering Collar, Sound-Dampening Felt, Water-Sealed Weave, Featherfall Skirt, Dark-Sight Visor, Qi-Conductive Lacing, Talisman Socket, Formation-Guard Stitching, Self-Mending Lacquer, Meridian-Clear Underlayer, Grasp-Breaking Plates, Pilgrim's Pocket Lining, Rank-Bearing Mirror Plates, Elemental Resistance Weave, Force-Dispersal Circuit, Guardian Intercession Harness, Void-Step Escape Lining, Stone-Root Stabilizers, Cloud-Walking Greaves, Iron Rain Deflection, Formation-Circuit Armor, Second-Skin Transformation, Shield-Link Inscription, Deflecting Shield Face, Heaven-Breath Filter, Sovereign Resistance Matrix, Mountain-Pattern Fortress, Walking Barrier Mantle, Ancestral Battle-Dress Spirit, Elemental Conversion Shell, Ten-Thousand Plate Domain, Heaven-Veil Imperial Robe, Calamity-Sheltering Shell, One Armor Bears Ten Thousand Calamities |
| Fire | Fire-Shedding Lining |
| Five-Phase | Elemental Resistance Weave, Sovereign Resistance Matrix, Elemental Conversion Shell |
| Flowing River | Water-Sealed Weave, Mirror-Flash Reversal |
| Force | Padded Impact Layers, Grasp-Breaking Plates, Force-Dispersal Circuit, Deflecting Shield Face, Mountain-Pattern Fortress, Walking Barrier Mantle, Ninefold Dragon Guard, Heaven-Veil Imperial Robe, Heaven-Turning Shield Face |
| Formation | World-Sheltering Immortal Battle Dress |
| Formations | Formation-Guard Stitching, Formation-Circuit Armor, Ten-Thousand Plate Domain |
| Gravity | Stone-Root Stabilizers, Immovable Mountain Grand Shell |
| Guardian | Guardian Intercession Harness, Shield-Link Inscription |
| Ice | Frost-Shedding Lining |
| Illusion | Hidden Plates Glamour |
| Imbuement | Qi-Conductive Lacing, Talisman Socket, Second-Skin Transformation |
| Life | Restful Inner Robe, Padded Impact Layers, Self-Mending Lacquer, Blood-Sealing Inner Layer, Regenerative Lacquer |
| Light | Mirror-Flash Reversal, Mirror-Heaven Counter |
| Lightning | Lightning-Grounding Mesh |
| Medicine | Restful Inner Robe, Poison-Filtering Collar, Blood-Sealing Inner Layer |
| Metal | Helmet-Seal Inscription, Lightning-Grounding Mesh, Anti-Corrosion Temper, Thorn-Retaliation Plates, Cold-Iron Spirit Cage |
| Mirror | Mirror-Flash Reversal, Mirror-Heaven Counter |
| Poison | Poison-Filtering Collar, Heaven-Breath Filter |
| Predator | Beast-Scent Masking |
| Pressure Points | Meridian-Clear Underlayer |
| Protection | Helmet-Seal Inscription, Fire-Shedding Lining, Frost-Shedding Lining, Formation-Guard Stitching, Elemental Resistance Weave, Force-Dispersal Circuit, Guardian Intercession Harness, Spirit-Guarding Hood, Law-Resisting Seal Plates, Sovereign Resistance Matrix, Walking Barrier Mantle, Ten-Thousand Plate Domain, Calamity-Sheltering Shell, Voidless Sanctuary Armor, One Armor Bears Ten Thousand Calamities, World-Sheltering Immortal Battle Dress |
| Qiweaving | Qi-Conductive Lacing, Meridian-Clear Underlayer, Formation-Circuit Armor, Elemental Conversion Shell |
| Radiance | Rank-Bearing Mirror Plates, Spirit-Guarding Hood, Heaven-Veil Imperial Robe |
| Retribution | Thorn-Retaliation Plates, Mirror-Heaven Counter, Heaven-Turning Shield Face |
| Sealing | Cold-Iron Spirit Cage, Voidless Sanctuary Armor |
| Sect Stewardship | Pilgrim's Pocket Lining |
| Shadow | Silent Lacing, Hidden Plates Glamour, Sound-Dampening Felt, Beast-Scent Masking, Void-Step Escape Lining, Concealing Mist Mantle, Space-Folded Evasion |
| Shield | Iron Rain Deflection, Shield-Link Inscription, Deflecting Shield Face, Ninefold Dragon Guard, Heaven-Turning Shield Face |
| Smoke | Concealing Mist Mantle |
| Sound | Sound-Dampening Felt |
| Space | Quick-Release Clasps, Pilgrim's Pocket Lining, Void-Step Escape Lining, Second-Skin Transformation, Space-Folded Evasion, Voidless Sanctuary Armor |
| Spirit | Spirit-Guarding Hood, Cold-Iron Spirit Cage |
| Spirit Companions | Ancestral Battle-Dress Spirit |
| Suppression | Immovable Mountain Grand Shell |
| Talismans | Talisman Socket, Law-Resisting Seal Plates |
| The Hidden Eye | Dark-Sight Visor |
| Thread | Silent Lacing |
| Tribulation | Calamity-Sheltering Shell, One Armor Bears Ten Thousand Calamities |
| Verdant Growth | Regenerative Lacquer, Thorn-Retaliation Plates |
| Warleader | Rank-Bearing Mirror Plates, Ancestral Battle-Dress Spirit |
| Water | Water-Sealed Weave, Concealing Mist Mantle |
| World | World-Sheltering Immortal Battle Dress |
| Wrestling | Sure-Strap Inscription, Grasp-Breaking Plates |

---

# Final Armor Presentation

Every finished armor or shield must state:

- legal profile from Chapter 3A;
- Primary Material from Chapter 3B;
- base Armor Class or shield bonus;
- Refinement Bonus;
- final Armor Class formula;
- every enhancement and Equivalent Bonus;
- Total Enhancement Value;
- Total Effective Bonus;
- Attunement slots;
- Fitted Armor eligibility;
- every action, trigger, target, range, saving throw, cost, duration, charge, dormancy, and recovery rule.

## Required Format

> **Mountain-Root Silent Fortress Half Armor +2**  
> *Armor (Mountain-Pattern Half Armor), Saint Treasure, Requires Attunement*  
> **Base AC:** 15 + Dexterity modifier, maximum +2  
> **Refinement Bonus:** +2 AC  
> **Final AC:** 17 + Dexterity modifier, maximum +2  
> **Enhancements:** Silent Lacing (+1), Stone-Root Stabilizers (+2)  
> **Total Enhancement Value:** +3  
> **Total Effective Bonus:** +5  
> **Attunement Slots:** 1


# Chapter 4: Wondrous Treasures — Complete 200-Item Catalog
*Final Production Compilation v0.1*

## Catalog Distribution

| Grade | Items |
|---|---:|
| Spiritual Treasure | 80 |
| Saint Treasure | 55 |
| Sovereign Treasure | 35 |
| Imperial Treasure | 20 |
| Immortal Artifact | 10 |
| **Total** | **200** |

This compilation presents all four production chunks in numerical order.


## Chapter 4A: Wondrous Treasures — Production Chunk 1
### Spiritual Treasures 1–50 v0.1

This chapter provides the first 50 entries in the 200-item Wondrous Treasure catalog.

## Catalog Doctrine

- Each treasure has one primary mechanical purpose.
- Passive and utility functions are preferred at Spiritual grade.
- Ordinary persistent properties function whenever their conditions are met.
- Charges and per-rest limits are used for discrete activations.
- Sphere Influences are compatibility and inspiration tags; they do not grant Spheres.
- A treasure requires Attunement only when its continuous benefit, emergency reaction, or personal bond justifies occupying one of the character's four slots.
- Storage treasures define capacity, retrieval, creature restrictions, and extradimensional interaction.
- No treasure grants a Sphere, Talent, Foundation, Method, or prerequisite unless it explicitly says so.

## Chunk Summary

| Category | Items |
|---|---:|
| Storage and Preservation | 10 |
| Travel and Movement | 8 |
| Communication and Information | 8 |
| Cultivation and Recovery | 8 |
| Crafting and Appraisal | 8 |
| Protection, Social, Spirit, and Exploration | 8 |
| **Total** | **50** |

---

## 1. Cultivator's Storage Ring
*Ring, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Spatial Storage  
**Sphere Influences:** Space, Equipment, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Void crystal set in spirit silver

The ring contains an extradimensional space holding up to **500 pounds or 32 cubic feet**, whichever limit is reached first.

**Store.** As an Action, touch one unattended object that fits through a 3-foot-wide opening and place it in the ring.

**Retrieve.** As a Bonus Action, retrieve one hand-held object whose location in the ring you know. Retrieving a larger object requires an Action.

The interior has no air and cannot hold living creatures. A living creature forced inside is immediately expelled into the nearest unoccupied space and takes `2d6` force damage.

Placing the ring inside another extradimensional space destroys both containers and scatters their contents into random unoccupied spaces within 100 feet.

---

## 2. Hundred-Herb Preservation Gourd
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Preservation Vessel  
**Sphere Influences:** Alchemy, Harvesting Gathering, Verdant Growth  
**Attunement Slots:** None  
**Primary Construction:** Living gourd lined with frost jade

The gourd holds up to **100 pounds or 8 cubic feet** of herbs, flowers, fungi, seeds, medicinal roots, and other plant ingredients.

Contents do not rot, dry out, germinate, or lose alchemical potency while stored. Time spent in the gourd does not count against a harvested ingredient's normal freshness limit.

Storing or retrieving one handful, bundle, vial, or Harvest Lot requires a Bonus Action. Larger quantities require an Action.

---

## 3. Folded-Sleeve Satchel
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Spatial Storage  
**Sphere Influences:** Space, Thread, Equipment  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloud silk sewn around a void-crystal clasp

The satchel holds up to **250 pounds or 16 cubic feet**. Its opening expands to accommodate an unattended object no wider than 1 foot.

**Store.** Storing an object requires an Action.

**Retrieve.** Retrieving a hand-held object requires a Bonus Action; retrieving anything larger requires an Action.

The satchel cannot contain creatures, active flames, or an object already containing extradimensional space. Attempting the last of these causes the inserted object to rebound harmlessly from the opening.

---

## 4. Beast-Feed Preservation Jar
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Beast Care  
**Sphere Influences:** Beastmastery, Spirit Companions, Harvesting Gathering  
**Attunement Slots:** None  
**Primary Construction:** Lacquered clay and spirit-beast bone

The jar holds up to **50 pounds** of feed, meat, grain, medicinal mash, or similar food intended for beasts or companions.

Food stored inside remains fresh and free of ordinary vermin. As an Action, you can cause one meal removed from the jar to become comfortably warm or cool.

A Beast or bonded companion that eats a full meal from the jar has Advantage on the next saving throw it makes against ordinary environmental heat, cold, hunger, or thirst before its next Long Rest.

---

## 5. Talisman-Flat Jade Case
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Talisman Storage  
**Sphere Influences:** Talismans, Ink, Equipment  
**Attunement Slots:** None  
**Primary Construction:** White jade, silk dividers, and sealing wax

The case protects up to **20 paper talismans, command slips, or similarly flat inscriptions** from water, ordinary fire, tearing, and accidental activation.

You can draw one identified talisman from the case as part of the action used to activate it.

As an Action, touch a talisman in the case to learn its name, grade, activation type, and whether it has been damaged. This property does not reveal hidden curses or intentionally concealed functions.

---

## 6. Scholar's Thousand-Page Box
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Document Storage  
**Sphere Influences:** Ink, Sect Stewardship, Space  
**Attunement Slots:** None  
**Primary Construction:** Scholar jade and folded paperwood

The box holds up to **1,000 pages**, 20 scrolls, or 10 ordinary books without increasing its 3-pound weight.

Contents are protected from ordinary moisture, insects, dust, and fading.

When you speak the title, author, first line, or a unique description of a stored text, the box presents it at the top as an Object Interaction. If no stored text matches, the lid remains closed.

---

## 7. Spirit-Stone Counting Abacus
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Trade and Appraisal  
**Sphere Influences:** Sect Stewardship, Source, Metal  
**Attunement Slots:** None  
**Primary Construction:** Spirit bamboo rods and source-jade beads

As an Action, place the abacus beside a visible pile or open container holding coins, spirit shards, or spirit stones. It displays the exact number and total rules value of those objects, up to **10,000 individual pieces**.

The abacus identifies cracked, exhausted, or visibly counterfeit spirit stones but does not reveal a sophisticated magical forgery.

You have Advantage on Intelligence (Investigation) checks made to audit a merchant ledger involving counted currency.

---

## 8. Cold-Moon Medicine Chest
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Medicine Storage  
**Sphere Influences:** Medicine, Ice, Alchemy  
**Attunement Slots:** None  
**Primary Construction:** Moon silver and frost jade

The chest holds up to **20 medicine doses, healer's-kit uses, pills, or small biological samples**.

Contents remain cool, sterile, and preserved. Ordinary disease cannot spread between samples stored in separate compartments.

When you use a healer's kit or medicinal treasure taken directly from the chest, you can reroll one die that rolls a 1. You must use the new result. This benefit can be used once, and it refreshes when you complete a Long Rest.

---

## 9. Dustless Workshop Chest
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Crafting Storage  
**Sphere Influences:** Blacksmith, Alchemy, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Ironwood, spirit bronze, and cleaning sigils

The chest stores one complete set of artisan's tools and up to **50 pounds** of related mundane supplies.

As a 1-minute procedure, it unfolds into a stable 5-foot-square workbench. Tools placed on the bench remain clean, sorted, and within reach.

During a Short Rest, the chest can clean and perform routine maintenance on one tool set. It cannot repair a Broken treasure or replace consumed materials.

---

## 10. Merchant's Weightless Ledger Pouch
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Trade Storage  
**Sphere Influences:** Space, Sect Stewardship, Ink  
**Attunement Slots:** None  
**Primary Construction:** Cloud silk and merchant-house jade

The pouch holds up to **50 pounds** of coins, trade bars, receipts, contracts, seals, and nonmagical documents while always weighing 1 pound.

The pouch refuses weapons, creatures, food, raw crafting materials, and unidentified supernatural treasures.

As an Action, you can command it to arrange stored coins and documents into labeled internal compartments. This changes organization only and does not verify authenticity.

---

## 11. Cloudstep Jade Anklets
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Movement  
**Sphere Influences:** Air, Athletics, Equipment  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloud jade and wind-thread lacing

Your Speed increases by **5 feet**.

You ignore the first 10 feet of nonmagical Difficult Terrain you move through during each of your turns.

The anklets have 3 charges and regain `1d3` expended charges when you complete a Long Rest. As a Bonus Action, expend 1 charge to increase your jump distance by 15 feet and jump height by 5 feet until the end of the turn.

---

## 12. River-Crossing Reed Sandals
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Movement  
**Sphere Influences:** Water, Flowing River, Athletics  
**Attunement Slots:** 1 slot  
**Primary Construction:** Spirit reeds, river jade, and water silk

During your turn, you can move across calm or flowing liquid as though it were solid ground. Liquid is Difficult Terrain for you unless you possess a Swim Speed.

If you end your turn standing on liquid without another feature supporting you, you descend harmlessly into it.

You have Advantage on checks made to keep your footing on wet stone, ice, a ship's deck, or a narrow river crossing.

---

## 13. Cliff-Clinging Gecko Gloves
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Climbing  
**Sphere Influences:** Athletics, Beastmastery, Earth  
**Attunement Slots:** 1 slot  
**Primary Construction:** Gecko-beast hide and earth-thread stitching

You gain a **Climb Speed of 20 feet** while both hands are free.

You can remain attached to a vertical surface without making an ability check. You cannot cling to a ceiling unless another feature permits it.

When you fall within reach of a solid surface, you can use your Reaction to make a DC 13 Dexterity saving throw. On a success, you catch the surface and stop falling.

---

## 14. Wind-Reading Travel Fan
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Travel and Weather  
**Sphere Influences:** Air, Weather, Survival  
**Attunement Slots:** None  
**Primary Construction:** Storm bamboo and crane feathers

You have Advantage on Wisdom (Survival) checks made to predict weather or identify a safe direction of travel using wind, smoke, clouds, or scent.

The fan has 3 charges and regains all expended charges at dawn.

**Clear the Air.** As an Action, expend 1 charge to disperse nonmagical smoke, fog, dust, or harmless gas in a 10-foot cube within 30 feet.

**Weather Reading.** As a 1-minute procedure, expend 1 charge to learn the natural weather expected within 1 mile during the next 6 hours.

---

## 15. Homeward Compass Disc
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Navigation  
**Sphere Influences:** Space, Source, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Magnetized spirit iron and home-soil jade

During an 8-hour ritual performed at one fixed location, designate that place as the disc's home.

While you are on the same plane and within **100 miles** of home, the disc points toward it and displays the straight-line distance to the nearest mile.

A new ritual replaces the previous home. A dimensional barrier, sealed domain, or effect that blocks divination can cause the disc to spin without providing false information.

---

## 16. Thousand-Li Trail Marker
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Navigation Pair  
**Sphere Influences:** Space, Source, Talismans  
**Attunement Slots:** None  
**Primary Construction:** Two matched jade tiles

The treasure consists of two matched tiles.

While both tiles are on the same plane and within **10 miles**, each points toward the other and displays their straight-line distance.

As an Action, a creature holding one tile can cause both to emit the same visible symbol for 1 minute. This function can be used once and refreshes at dawn.

---

## 17. Mist-Sheltering Travel Cloak
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Travel Shelter  
**Sphere Influences:** Weather, Water, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Waterproof cloud wool and mist jade

The cloak keeps you and ordinary clothing beneath it dry in rain, snow, and mist. You have Advantage on saving throws against Exhaustion caused solely by ordinary extreme heat, extreme cold, or wet exposure.

Once per Long Rest, as a 1-minute procedure, spread the cloak on the ground to create a dry 10-foot-radius shelter for up to 8 hours. The shelter blocks ordinary rain, snow, wind, and insects but provides no Cover.

---

## 18. Floating Burden Pole
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Transport  
**Sphere Influences:** Force, Gravity, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Spirit bamboo and gravity jade

When activated as an Action, the pole floats 3 feet above the ground and can support up to **250 pounds** of secured cargo.

It follows the activating creature at a Speed of 30 feet, remaining within 5 feet whenever possible. It cannot climb, fly, cross a gap wider than 10 feet, or enter a space too small for its load.

If overloaded, it settles gently to the ground and becomes inactive.

---

## 19. Paired Whispering Jade
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Communication Pair  
**Sphere Influences:** Sound, Air, Spirit  
**Attunement Slots:** None  
**Primary Construction:** Two matched whisper jades

Each jade has 3 charges and regains all expended charges at dawn.

As an Action, expend 1 charge and speak a message of no more than **25 words**. The paired jade reproduces the message in your voice if it is on the same plane and within **1 mile**.

A creature holding the receiving jade can answer immediately with up to 25 words without expending a charge. Total silence, planar separation, or a sealed communication barrier prevents delivery.

---

## 20. Sect-Signal Lantern
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Long-Range Signaling  
**Sphere Influences:** Light, Warleader, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Colored spirit glass and bronze

As a Bonus Action, choose the lantern's color and whether its light is visible normally or only to creatures carrying a matching sect token.

In clear conditions, the signal is visible from **5 miles** away.

As an Action, cause the lantern to display one of twelve symbols chosen when it is created. The symbols carry no automatic meaning; a group must agree on its own code.

---

## 21. Truth-Resonance Court Bell
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Testimony and Inquiry  
**Sphere Influences:** Sound, Fate, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Court bronze and clear-heart jade

The bell has 3 charges and regains `1d3` expended charges when you complete a Long Rest.

After a creature within 10 feet makes a factual statement of no more than 25 words, you can use your Reaction and expend 1 charge. An unwilling speaker makes a DC 13 Charisma saving throw.

On a failed save, the bell produces a clear tone if the speaker believes the statement is true and a discordant tone if the speaker believes it is false. On a successful save, the bell remains silent.

The bell does not determine objective truth, expose omissions, or interpret predictions.

---

## 22. Memory-Impression Jade Slip
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Memory Recording  
**Sphere Influences:** Ink, Dreams, Spirit  
**Attunement Slots:** None  
**Primary Construction:** Dream jade and memory ink

The slip stores up to **three recordings**, each containing up to 10 minutes of your sight and hearing.

As an Action, begin or end a recording. Starting a fourth recording erases the oldest.

A creature touching the slip can replay one recording during an equal amount of real time. The viewer knows it is experiencing a recording and remains aware of its surroundings, though it has Disadvantage on Wisdom (Perception) checks during playback.

---

## 23. Hidden-Writing Revealing Lens
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Inspection  
**Sphere Influences:** The Hidden Eye, Ink, Talismans  
**Attunement Slots:** None  
**Primary Construction:** Clear jade and moon silver

While looking through the lens, you can see invisible ink, erased writing, concealed talisman strokes, and nonphysical formation lines within 10 feet.

The lens reveals the location and shape of such writing but does not translate it, identify its function, or reveal invisible creatures.

You have Advantage on Intelligence (Investigation) checks made to determine whether a document has been altered.

---

## 24. Grave-Quiet Listening Bell
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Spirit Detection  
**Sphere Influences:** Death, Spirit Companions, Sound  
**Attunement Slots:** None  
**Primary Construction:** Funeral bronze and ghost iron

The bell has 1 charge and regains it at midnight.

As an Action, expend the charge and ring the bell. For 1 minute, it vibrates whenever an Undead creature, incorporeal spirit, or possessing entity is within 60 feet and not behind Total Cover.

The direction of the vibration indicates the nearest qualifying presence. The bell does not identify the creature or reveal an exact location.

---

## 25. Source-Vein Appraisal Needle
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Geomantic Survey  
**Sphere Influences:** Source, Earth, Harvesting Gathering  
**Attunement Slots:** None  
**Primary Construction:** Source jade and magnetized silver

Plant the needle in soil or exposed stone and spend 10 minutes observing it.

You learn whether a natural mineral deposit, spirit-stone vein, buried source material, or major underground hollow lies within **300 feet**.

If one exists, the needle indicates its general direction and whether its apparent concentration is trace, minor, substantial, or exceptional. It does not reveal hazards, ownership, exact depth, or sealed contents.

---

## 26. Dream-Recording Pillow
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Dream and Rest  
**Sphere Influences:** Dreams, Spirit, Ink  
**Attunement Slots:** None  
**Primary Construction:** Dream silk and moon cotton

A creature that completes a Long Rest using the pillow remembers its dreams clearly for 24 hours.

At waking, the dreamer can cause one page placed beneath the pillow to display a symbolic illustration and a summary of no more than 100 words describing the dream. The page records the dreamer's honest memory, not hidden prophecy or objective truth.

The dreamer has Advantage on checks made during that day to recall or interpret its own recorded dream.

---

## 27. Clear-Mind Bronze Bell
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Mental Defense  
**Sphere Influences:** Sound, Radiance, Protection  
**Attunement Slots:** 1 slot  
**Primary Construction:** Clear-heart bronze and sun jade

The bell has 3 charges and regains `1d3` expended charges when you complete a Long Rest.

As an Action, expend 1 charge and ring the bell. You and allies of your choice within 10 feet gain Advantage on the next saving throw made against the Charmed or Frightened condition before the end of your next turn.

A creature currently affected by either condition can immediately repeat one saving throw against it if the effect normally allows repeated saves.

---

## 28. Still-Breath Cultivation Mat
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Meditation  
**Sphere Influences:** Qiweaving, Life, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Spirit grass, cloud cotton, and grounding thread

While seated on the mat, you can meditate comfortably despite ordinary noise, weather, hard ground, or minor physical discomfort.

When you finish a Short Rest on the mat and spend one or more Hit Dice, reroll one Hit Die and use either result. This benefit can be granted to only one creature per Short Rest.

The mat does not shorten cultivation training or permit resting in immediate danger.

---

## 29. Meridian-Warming Hand Furnace
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Travel Recovery  
**Sphere Influences:** Fire, Medicine, Qiweaving  
**Attunement Slots:** None  
**Primary Construction:** Sun copper and medicine jade

The furnace produces safe, smokeless warmth without fuel.

A creature holding it has Advantage on saving throws against ordinary extreme cold and can warm one meal or 1 gallon of liquid during a Short Rest.

Once per Long Rest, a creature completing a Short Rest beside the furnace can end one instance of numbness, chilled limbs, or reduced Speed caused solely by ordinary cold exposure.

---

## 30. Spirit-Gathering Incense Burner
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Cultivation Support  
**Sphere Influences:** Qiweaving, Alchemy, Spirit  
**Attunement Slots:** None  
**Primary Construction:** Spirit bronze and incense jade

During a Short or Long Rest, burn incense worth 1 Spirit Shard.

Choose one creature that remains within 10 feet of the burner for at least 10 minutes. Before its next Long Rest, that creature has Advantage on one ability check made to meditate, interpret qi circulation, perform cultivation training, or stabilize an ordinary cultivation disturbance.

The burner does not grant CP, AP, a Sphere, a Talent, or an automatic breakthrough.

---

## 31. Twelve-Breath Recovery Beads
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Recovery  
**Sphere Influences:** Life, Medicine, Qiweaving  
**Attunement Slots:** 1 slot  
**Primary Construction:** Twelve medicine-jade beads

When you spend Hit Dice during a Short Rest, you can reroll one Hit Die and must use the new result.

The beads have 3 charges and regain all expended charges when you complete a Long Rest.

As a Bonus Action, expend 1 charge to gain Temporary Hit Points equal to your Proficiency Bonus. These Temporary Hit Points last for 10 minutes.

---

## 32. Heart-Demon Warning Mirror
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Mental Warning  
**Sphere Influences:** Dreams, Dark, The Hidden Eye  
**Attunement Slots:** 1 slot  
**Primary Construction:** Black mirror glass and clear-heart silver

The mirror clouds when you are affected by an illusion, possession attempt, dream intrusion, or effect that would impose the Charmed or Frightened condition. The warning does not reveal the source or prove that the effect is hostile.

Once per Long Rest, when you fail a saving throw against one of those effects, you can reroll the saving throw and must use the new result.

---

## 33. Fasting Jade Cup
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Survival  
**Sphere Influences:** Life, Water, Alchemy  
**Attunement Slots:** None  
**Primary Construction:** White jade and spirit-grain glaze

At dawn, the cup can transform ordinary potable water placed inside it into one serving of sustaining water.

A creature that drinks the serving requires no food and only half as much water for the next 24 hours.

The cup can create only one serving per dawn. The effect prevents hunger and thirst but does not remove existing Exhaustion or provide nourishment for growth, pregnancy, or intensive long-term training.

---

## 34. Moon-Dew Collection Bowl
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Ingredient Collection  
**Sphere Influences:** Water, Moon, Alchemy  
**Attunement Slots:** None  
**Primary Construction:** Moon jade and silver leaf

If left outdoors beneath the night sky for at least 6 hours, the bowl contains 1 pint of pure moon dew at dawn.

Moon dew functions as clean water and counts as an appropriate minor Water-, Yin-, Moon-, or purification-aligned ingredient worth **1 Spirit Shard**.

The bowl cannot produce dew underground, beneath an opaque roof, or during a night when the sky is completely sealed by a supernatural effect.

---

## 35. Alchemist's Steady-Flame Tripod
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Crafting Tool  
**Sphere Influences:** Alchemy, Fire, Qiweaving  
**Attunement Slots:** None  
**Primary Construction:** Sun copper and three fire-jade feet

The tripod supplies stable low or medium heat without mundane fuel and supports vessels up to 100 pounds.

While using it with Alchemist's Supplies, you ignore penalties caused solely by wind, ordinary rain, unstable ground, or an inconsistent mundane heat source.

Once per Long Rest, when you fail an Alchemy check for a Common or Spiritual-grade product, reroll the check and use the new result.

---

## 36. Blacksmith's Temper-Reading Hammer
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Crafting Tool  
**Sphere Influences:** Blacksmith, Metal, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Spirit iron and resonant bronze

After tapping a metal object for 1 minute, you learn:

- its primary metal or alloy;
- whether it is cracked, warped, improperly tempered, or structurally sound;
- whether it is Mortal or a supernatural treasure;
- its approximate treasure grade, if any.

You have Advantage on the next check made within 1 hour to repair or appraise that object. The hammer does not reveal hidden enchantment functions.

---

## 37. Formation-Line Measuring Cord
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Survey Tool  
**Sphere Influences:** Formations, Earth, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Spirit thread marked with geometric jade beads

The cord can extend from 1 foot to **300 feet** without changing weight.

When stretched between two visible points, it displays exact distance, slope, elevation difference, and cardinal direction.

You have Advantage on checks made to survey, copy, or repair a Common or Spiritual-grade formation layout using the cord. It does not locate hidden Formation Anchors by itself.

---

## 38. Talisman Inkstone of Even Flow
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Crafting Tool  
**Sphere Influences:** Talismans, Ink, Imbuement  
**Attunement Slots:** None  
**Primary Construction:** Black scholar jade and spirit-water channels

At dawn, the inkstone produces enough ordinary black or red ink to write 20 pages.

Ink mixed in the stone does not dry for 8 hours and flows evenly despite ordinary heat, cold, or humidity.

Once per Long Rest, when you fail a check to inscribe a Mortal or Spiritual-grade talisman, reroll the check and use the new result.

---

## 39. Harvester's Clean-Cut Shears
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Harvesting Tool  
**Sphere Influences:** Harvesting Gathering, Verdant Growth, Medicine  
**Attunement Slots:** None  
**Primary Construction:** Spirit steel and living wood handles

You have Advantage on checks made to harvest herbs, flowers, vines, fungi, bark, fruit, or other nonhostile plant ingredients.

Harvesting time is halved when the shears are appropriate to the task.

A harvested plant ingredient remains at full freshness for 1 additional hour after cutting. The shears do not increase yield or permit harvesting a material above the creature's or site's available grade.

---

## 40. Beast-Core Stabilizing Cage
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Ingredient Storage  
**Sphere Influences:** Beastmastery, Alchemy, Spirit Companions  
**Attunement Slots:** None  
**Primary Construction:** Spirit-beast bone, silver wire, and sealing jade

The cage holds one beast core, monster organ, spiritual gland, or similarly dangerous harvested component weighing up to 20 pounds.

While closed, the component cannot leak ordinary poison, disease, elemental heat, cold, or hostile spiritual pressure beyond the cage.

You have Advantage on the first check made to stabilize, appraise, or begin refining the stored component after opening the cage.

---

## 41. Spirit-Thread Weaver's Shuttle
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Crafting Tool  
**Sphere Influences:** Thread, Equipment, Imbuement  
**Attunement Slots:** None  
**Primary Construction:** Cloudwood and a spirit-silver eye

The shuttle can produce up to 30 feet of strong mundane thread each dawn.

When used with Weaver's Tools, it halves the time required to mend ordinary clothing, robes, tents, banners, or cloth armor.

Once per Long Rest, it can repair one tear or severed strap in a Spiritual Treasure made primarily from cloth, leather, or thread. This restores function but not expended charges or destroyed enchantments.

---

## 42. Source-Stone Sorting Tray
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Appraisal Tool  
**Sphere Influences:** Source, Earth, Harvesting Gathering  
**Attunement Slots:** None  
**Primary Construction:** Source jade set into dark wood

Place up to 10 pounds of stones, ore, crystals, or mineral fragments on the tray and spend 10 minutes sorting them.

The tray separates the contents into mundane waste, useful mundane material, spiritually active material, and sealed or unreadable material.

You have Advantage on Intelligence (Investigation) checks made to appraise the sorted materials. The tray does not safely open sealed stones or identify a concealed creature.

---

## 43. Clear-Water Purification Pearl
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Purification  
**Sphere Influences:** Water, Life, Alchemy  
**Attunement Slots:** None  
**Primary Construction:** River pearl and cleansing jade

Place the pearl in a container holding up to **10 gallons** of water. After 1 minute, the water becomes clean and potable.

The pearl removes ordinary dirt, salt, rot, and nonmagical disease. It does not remove a magical poison, curse, alchemical reagent, or supernatural contamination.

The pearl can purify up to 30 gallons, after which it becomes inert until dawn.

---

## 44. Smoke-Breath Rescue Mask
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Hazard Protection  
**Sphere Influences:** Air, Smoke, Medicine  
**Attunement Slots:** None  
**Primary Construction:** Cloud silk, charcoal jade, and spirit filters

While wearing the mask, you can breathe normally in nonmagical smoke, dust, ash, and ordinary irritating gas.

You have Advantage on saving throws against inhaled poison.

The mask contains 10 minutes of clean air for an airless or fully submerged environment. All wearers share this daily capacity, which refreshes at dawn.

---

## 45. One-Step Escape Talisman Box
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Emergency Movement  
**Sphere Influences:** Talismans, Space, Athletics  
**Attunement Slots:** 1 slot  
**Primary Construction:** White jade, folded talisman paper, and cloudwood

The box has 3 charges and regains `1d3` expended charges when you complete a Long Rest.

When a creature you can see hits you with an attack, you can use your Reaction and expend 1 charge. After the attack resolves, move up to **10 feet** without provoking Opportunity Attacks from the attacker.

This movement cannot pass through occupied spaces, Total Cover, or terrain you could not normally enter. It is movement, not teleportation.

---

## 46. Guest-Right Tea Service
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Hospitality and Negotiation  
**Sphere Influences:** Beauty, Sect Stewardship, Spirit  
**Attunement Slots:** None  
**Primary Construction:** Porcelain, hospitality jade, and spirit-silver trim

The service prepares up to six cups of properly heated tea from supplied water and leaves.

Creatures that willingly share the tea during a 10-minute conversation can clearly understand one another's names, titles, and declared terms of hospitality despite an ordinary language barrier.

For 1 hour afterward, each participant has Advantage on Wisdom (Insight) checks made to judge another participant's immediate emotional state. The service does not compel honesty or peace.

---

## 47. Oath-Witness Red Cord
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Oath Recording  
**Sphere Influences:** Karma, Thread, Ink  
**Attunement Slots:** None  
**Primary Construction:** Red spirit thread and a blank jade bead

During a 10-minute ritual, up to two willing creatures hold the cord and speak an agreement of no more than 250 words.

The jade bead records the exact words, identities presented, date, and location. Any creature touching the bead can hear the recorded agreement.

If one participant knowingly performs an act directly prohibited by the recorded words, the bead darkens permanently. The cord does not prevent the act, determine ambiguous intent, or impose a curse.

---

## 48. Spirit-Calming Offering Bowl
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Spirit Diplomacy  
**Sphere Influences:** Spirit Companions, Death, Beauty  
**Attunement Slots:** None  
**Primary Construction:** Funeral jade and incense bronze

Place food, incense, paper offerings, blood, flowers, or another culturally appropriate offering worth at least 1 Spirit Shard in the bowl.

For 1 hour, you have Advantage on Charisma checks made to communicate peacefully with a spirit, ghost, ancestor, or incorporeal Undead that willingly accepts or acknowledges the offering.

The bowl does not summon a spirit, bind it, force it to negotiate, or protect you from hostility.

---

## 49. Hidden-Door Knocking Seal
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Exploration  
**Sphere Influences:** The Hidden Eye, Earth, Source  
**Attunement Slots:** None  
**Primary Construction:** Hollow jade and resonant bronze

The seal has 3 charges and regains all expended charges at dawn.

Press it against a solid surface and expend 1 charge as an Action. For 1 minute, it vibrates if a concealed door, hollow space, movable wall section, or artificial passage lies within 30 feet and is connected to the same structure.

The strength of the vibration indicates direction but not exact distance, opening method, traps, or contents.

---

## 50. Night-Watch Alarm Crickets
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Camp Security  
**Sphere Influences:** Trap, Sound, Spirit Companions  
**Attunement Slots:** None  
**Primary Construction:** Four jade crickets in a bamboo box

The set contains four crickets. As a 1-minute procedure, place them to define a perimeter no larger than a 30-foot-radius area.

For up to 8 hours, a cricket chirps loudly when a Tiny or larger creature crosses the perimeter without speaking a password chosen during setup. A creature can notice a cricket with a successful DC 13 Wisdom (Perception) check.

The crickets do not detect teleportation, incorporeal movement through the ground, or a creature already inside the perimeter when activated.

---

# Chunk 1 Audit

All 50 entries were checked for:

- explicit item type and grade;
- Attunement status;
- Sphere Influence tags;
- complete action and recovery language;
- defined storage capacity where relevant;
- no undefined combat conditions;
- no blanket once-per-turn restriction;
- no automatic Sphere or Talent ownership;
- one coherent principle per treasure;
- no duplication with weapon or armor enhancement slots.


## Chapter 4B: Wondrous Treasures — Production Chunk 2
### Treasures 51–100 v0.1

This chapter completes the Spiritual Treasure portion of the 200-item catalog and begins the Saint Treasure portion.

## Grade Breakdown

| Grade | Items |
|---|---:|
| Spiritual Treasure | 30 |
| Saint Treasure | 20 |
| **Total** | **50** |

## Design Doctrine

- Spiritual Treasures emphasize travel, survival, study, logistics, minor recovery, social utility, and narrow protection.
- Saint Treasures introduce major storage, creature residence, long-range communication, advanced appraisal, stronger defensive reactions, and limited supernatural installations.
- Passive properties function whenever their conditions are met.
- Discrete attacks, escapes, reflections, suppression effects, and rituals use explicit charges, Actions, Reactions, or rest recovery.
- Sphere Influences are design tags and do not grant Spheres or prerequisites.
- Storage and residence items define capacity, retrieval, creature consent, destruction, and extradimensional interaction.
- Each treasure has one coherent primary principle.

---

# Spiritual Treasures 51–80

## 51. Lantern of Emberless Heat
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Light and Shelter  
**Sphere Influences:** Fire, Light, Equipment  
**Attunement Slots:** None  
**Primary Construction:** Sun copper, warm jade, and spirit glass

The lantern sheds Bright Light in a 20-foot radius and Dim Light for an additional 20 feet. It produces warmth but no flame, smoke, or fuel consumption.

As an Action, you can change the light to one of three settings: full light, dim ember-light, or heat only.

While the heat setting is active, creatures within 10 feet have Advantage on saving throws against ordinary extreme cold. The lantern cannot ignite objects or deal damage.

---

## 52. Rain-Calling Travel Tile
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Weather Utility  
**Sphere Influences:** Weather, Water, Talismans  
**Attunement Slots:** None  
**Primary Construction:** Blue roof tile, river jade, and cloud ink

The tile has 1 charge and regains it at dawn.

As a 10-minute ritual outdoors, expend the charge to gather a light natural rain over a 100-foot-radius area for 10 minutes. The effect fails beneath a sealed roof, underground without a natural opening, or in an environment where liquid water cannot exist.

The rain extinguishes ordinary Tiny flames, fills open containers with clean rainwater, and grants Advantage on checks made to conceal tracks by washing away dust or loose soil. It does not create a storm or overcome magical fire.

---

## 53. Quiet-Camp Boundary Stakes
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Camp Security  
**Sphere Influences:** Trap, Sound, Protection  
**Attunement Slots:** None  
**Primary Construction:** Eight spirit-bamboo stakes with hush-thread

The set contains eight stakes. As a 10-minute procedure, place them to define a perimeter no larger than a 30-foot-radius area.

For up to 8 hours, ordinary sound originating inside the perimeter is muffled beyond its edge. A creature outside has Disadvantage on Wisdom (Perception) checks relying on hearing to notice activity inside.

The stakes do not block sound entering the area, magical sound, thunder damage, or deliberate shouting from outside the boundary.

---

## 54. Beast-Scent Trail Powder Box
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Tracking  
**Sphere Influences:** Predator, Beastmastery, Harvesting Gathering  
**Attunement Slots:** None  
**Primary Construction:** Lacquered horn box and spirit-beast musk crystals

The box produces three doses of tracking powder at dawn.

As an Action, scatter one dose over a footprint, hair, bloodstain, shed scale, or similar physical trace left within the previous 24 hours.

For 1 hour, the powder glows faintly whenever placed within 10 feet of a newer trace left by the same creature. A creature using the powder has Advantage on Wisdom (Survival) checks made to follow that trail.

The powder cannot track a creature that leaves no physical traces or has crossed to another plane.

---

## 55. Shared-Meal Warming Pot
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Hospitality and Recovery  
**Sphere Influences:** Fire, Life, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Spirit bronze and hearth jade

The pot can prepare or warm enough ordinary food for up to eight creatures without fuel.

A creature that eats a full meal from the pot during a Short Rest can reroll one Hit Die spent during that rest and must use the new result.

Only three creatures can gain this reroll from the pot between Long Rests. The pot does not create ingredients or make spoiled food safe.

---

## 56. Footprint-Erasing Brush
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Concealment and Travel  
**Sphere Influences:** Shadow, Sand, Water  
**Attunement Slots:** None  
**Primary Construction:** Black bamboo and wind-horse hair

As an Action, sweep the brush over a 5-foot square of ground.

The brush removes ordinary footprints, drag marks, wheel ruts, blood drops, ash trails, and similar mundane traces in that square. It cannot erase structural damage, magical marks, scent, memories, or evidence protected by a stronger supernatural effect.

During overland travel, one creature using the brush can conceal the tracks of up to six travelers moving at a slow pace.

---

## 57. Spirit-Moth Message Cage
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Communication  
**Sphere Influences:** Spirit Companions, Air, Light  
**Attunement Slots:** None  
**Primary Construction:** Moon bamboo and pale spirit silk

The cage houses one harmless spirit moth. At dawn, it reforms inside the cage if it was previously released.

As an Action, speak a message of no more than 50 words and name a creature you know within 5 miles on the same plane. The moth flies toward that creature at a Speed of 60 feet.

If it reaches the creature within 1 hour, it delivers the message in your voice and then returns to the cage. Total Cover does not block its route, but sealed barriers, dimensional wards, and hostile capture can stop it.

---

## 58. Borrowed-Voice Reed Flute
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Voice and Performance  
**Sphere Influences:** Sound, Illusion, Beauty  
**Attunement Slots:** 1 slot  
**Primary Construction:** Spirit reed and moon-silver keys

During a 1-minute listening ritual, choose one willing creature that speaks or sings within 10 feet. The flute stores that creature's voice until you store another.

While playing the flute, you can speak or sing using the stored voice. A creature that hears you can discern the imitation with a successful Wisdom (Insight) check against your item save DC.

The flute reproduces voice only. It does not grant languages, memories, command authority, or identity-based supernatural access.

---

## 59. Minor Formation Anchor Nails
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Formation Support  
**Sphere Influences:** Formations, Metal, Earth  
**Attunement Slots:** None  
**Primary Construction:** Twelve spirit-iron nails marked with geometric grooves

The set contains twelve nails.

When used during a Formation project, the nails can stabilize one Common or Spiritual-grade Formation Anchor placed in ordinary soil, wood, or masonry.

A formation using at least four nails gains Advantage on one check made to resist ordinary wind, flooding, shaking ground, accidental movement, or structural vibration.

The nails do not create a formation, increase its save DC, or stabilize Saint-grade or stronger effects.

---

## 60. Sun-Dial of Honest Hours
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Timekeeping  
**Sphere Influences:** Light, Stars, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Sun jade and engraved bronze

The dial always displays the local solar time while exposed to natural daylight or moonlight. Underground or beneath a sealed roof, it continues to track time for 7 days before losing accuracy.

As a 1-minute procedure, you can learn how much time has passed since the dial last saw natural sky.

The dial cannot predict the future, measure altered planar time, or function inside an effect that completely suspends time.

---

## 61. Salt-Warding Sailor's Knot
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Maritime Protection  
**Sphere Influences:** Water, Weather, Thread  
**Attunement Slots:** None  
**Primary Construction:** Blue cord, shell beads, and river jade

When tied to a boat, raft, pack, or carried cargo bundle, the knot protects that object and its secured contents from ordinary salt corrosion, mildew, and waterlogging.

A vessel carrying the knot has Advantage on checks made to resist ordinary waves, currents, or storms that would swamp it.

The knot does not protect against magical water, siege damage, capsizing caused by creatures, or a storm created by a cultivation technique.

---

## 62. Poison-Tasting Silver Cicada
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Poison Detection  
**Sphere Influences:** Poison, Medicine, Metal  
**Attunement Slots:** None  
**Primary Construction:** Purified silver and medicine jade

Place the cicada beside one serving of food, drink, medicine, incense, or alchemical powder and wait 1 minute.

The cicada chirps if the sample contains a poison, disease, spoiled ingredient, or harmful alchemical contaminant detectable at Spiritual grade or lower.

It reveals the presence and broad category of the danger, not its exact identity, save DC, dose, or magical origin. A deliberately concealed Saint-grade or stronger poison can evade the cicada.

---

## 63. Moonlit Map Cloth
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Mapping  
**Sphere Influences:** Moon, Ink, Space  
**Attunement Slots:** None  
**Primary Construction:** Moon silk and silver ink

Spread the cloth beneath moonlight or starlight for 1 minute.

It displays a map of terrain you have personally traveled through within the previous 7 days, covering an area up to 10 miles across. The map includes major roads, rivers, buildings, elevations, and named landmarks you consciously noticed.

It does not reveal hidden locations, interiors you did not enter, creatures, traps, or changes that occurred after you left.

---

## 64. Sect-Rank Recognition Token
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Identity and Authority  
**Sphere Influences:** Sect Stewardship, Ink, Spirit  
**Attunement Slots:** 1 slot  
**Primary Construction:** Sect jade and identity-thread inscription

When attuned by an authorized member, the token displays the bearer's registered name, sect, office, and rank.

A matching sect formation or official reader can verify whether the token is genuine and whether its bearer is the attuned member.

The token does not grant rank or access by itself. If the Attunement ends, the displayed identity fades until the token is properly reassigned by the issuing authority.

---

## 65. Spirit-Companion Grooming Comb
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Companion Care  
**Sphere Influences:** Spirit Companions, Beastmastery, Beauty  
**Attunement Slots:** None  
**Primary Construction:** Spirit wood, moon silver, and soft beast bristles

During a Short Rest, use the comb on one willing Beast, spirit companion, or bonded creature.

The creature can immediately repeat one saving throw against the Charmed or Frightened condition if the effect normally permits repeated saves.

It also has Advantage on the next Wisdom (Perception) or Charisma check it makes before its next Long Rest.

A creature can benefit from the comb only once per Long Rest.

---

## 66. Empty-Bowl Beggar's Cup
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Hospitality and Survival  
**Sphere Influences:** Life, Karma, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Plain clay glazed with clear spirit lacquer

At dawn, the cup can produce one simple serving of rice porridge and clean water if it was freely given to a hungry creature during the previous day.

A creature that consumes the serving gains enough nourishment for 24 hours and has Advantage on the next saving throw it makes against Exhaustion caused by starvation or thirst.

The cup cannot produce food through sale, coercion, theft, or self-serving exchange.

---

## 67. Frost-Locking Food Seal
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Preservation  
**Sphere Influences:** Ice, Talismans, Alchemy  
**Attunement Slots:** None  
**Primary Construction:** Frost jade stamp and blue sealing wax

As an Action, press the seal onto a closed container holding no more than 50 pounds of nonliving food or drink.

For 30 days, the contents remain fresh, cool, and protected from ordinary spoilage, insects, and mold. Opening the container ends the effect.

The seal can maintain three containers at a time. Sealing a fourth ends the oldest seal.

---

## 68. Incense of Calm Negotiation
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Social Utility  
**Sphere Influences:** Beauty, Spirit, Air  
**Attunement Slots:** None  
**Primary Construction:** A reusable jade incense stick and sandalwood core

As an Action, light the incense. It burns for 10 minutes and fills a 10-foot-radius area with a mild scent.

Creatures that willingly remain in the area for at least 1 minute have Advantage on Wisdom (Insight) checks and Charisma (Persuasion) checks made during that conversation.

The incense does not affect a hostile creature that refuses to negotiate, does not suppress combat, and cannot force honesty or agreement. It can be used once and refreshes at dawn.

---

## 69. Hidden-Pocket Jade Belt
*Wondrous Item, Spiritual Treasure, Requires Attunement*

**Treasure Family:** Concealed Storage  
**Sphere Influences:** Space, Equipment, Scoundrel  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dark jade links and folded-space silk

The belt contains six extradimensional pockets. Each pocket holds up to 5 pounds or one hand-held object.

A creature searching you has Disadvantage on checks made to find stored objects unless it knows the belt's command word.

You can retrieve one stored object as part of the same object interaction used to draw it. The pockets cannot hold creatures, active flames, or extradimensional containers.

---

## 70. Rainproof Scripture Wrap
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Document Protection  
**Sphere Influences:** Ink, Water, Talismans  
**Attunement Slots:** None  
**Primary Construction:** Waxed cloud silk and sealing thread

The wrap holds one book, scroll bundle, jade-slip case, or document stack no larger than 10 pounds.

Contents are protected from ordinary water, rain, snow, smoke, dust, and accidental ink smearing.

If the wrapped object is exposed to magical water, fire, acid, or a destructive talisman effect, it has Resistance to that damage while the wrap remains intact.

---

## 71. Wound-Cleansing Copper Basin
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Medicine and Purification  
**Sphere Influences:** Medicine, Water, Life  
**Attunement Slots:** None  
**Primary Construction:** Purified copper and cleansing jade

Fill the basin with 1 gallon of clean water and spend 10 minutes washing one willing creature's wounds.

The creature can immediately repeat one saving throw against a nonmagical poison or disease if the effect normally allows repeated saves.

It also gains Advantage on the next Constitution saving throw it makes before its next Long Rest against infection, poison, or disease caused by an open wound.

The basin can be used once and refreshes at dawn.

---

## 72. Lantern of Safe Burial
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Funerary Protection  
**Sphere Influences:** Death, Radiance, Spirit Companions  
**Attunement Slots:** None  
**Primary Construction:** Funeral bronze and pale spirit glass

When placed beside a corpse and lit for 10 minutes, the lantern protects that corpse for 24 hours.

During that time, ordinary decay is halted, the corpse cannot rise as an ordinary Undead, and hostile spirits have Disadvantage on checks made to possess or animate it.

The lantern does not imprison the soul, prevent resurrection, or stop a Saint-grade or stronger necromantic effect without an opposed check set by the GM.

---

## 73. Echo-Finding Cavern Pebble
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Exploration  
**Sphere Influences:** Sound, Earth, The Hidden Eye  
**Attunement Slots:** None  
**Primary Construction:** Resonant cavern stone and silver wire

As an Action, strike the pebble against a solid surface.

For 1 minute, it vibrates in the direction of the nearest open passage, chamber, shaft, or hollow space within 60 feet that is connected through stone, earth, or masonry.

It cannot distinguish a natural cave from a constructed room and does not reveal contents, hazards, or sealed extradimensional spaces.

---

## 74. Windless Candle of Study
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Study and Concentration  
**Sphere Influences:** Light, Ink, Air  
**Attunement Slots:** None  
**Primary Construction:** White wax, scholar jade, and a smokeless wick

The candle burns without smoke and cannot be extinguished by ordinary wind or rain.

A creature studying, copying, translating, or analyzing text within 10 feet of the candle has Advantage on checks made solely to maintain concentration despite ordinary noise, weather, or discomfort.

The candle burns for 8 hours and regains all expended duration at dawn.

---

## 75. Ten-Thousand Knot Repair Cord
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Repair and Utility  
**Sphere Influences:** Thread, Equipment, Blacksmith  
**Attunement Slots:** None  
**Primary Construction:** Endless spirit cord and knot jade

The cord can extend to 100 feet and retract to 1 foot as an Object Interaction.

During a Short Rest, it can repair one nonmagical rope, strap, harness, net, tent, sail, pack, or cloth object whose missing material totals no more than 10 feet.

As an Action, it can bind a closed container or door. Breaking the cord requires a DC 15 Strength check. Once broken, it reforms at dawn.

---

## 76. Sleep-Guarding Door Charm
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Rest Security  
**Sphere Influences:** Protection, Dreams, Talismans  
**Attunement Slots:** None  
**Primary Construction:** Peachwood plaque and red sealing cord

Hang the charm on a door, tent flap, window, or other entrance no wider than 10 feet.

For up to 8 hours, the charm emits a clear tone if the entrance is opened or crossed by a creature that did not speak the password chosen during setup.

Creatures completing a Long Rest within 30 feet have Advantage on saving throws against ordinary nightmares and dream intrusion of Spiritual grade or lower.

---

## 77. Spirit-Beast Calming Chime
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Beast and Spirit Care  
**Sphere Influences:** Beastmastery, Spirit Companions, Sound  
**Attunement Slots:** None  
**Primary Construction:** Spirit bronze and beast-bone clappers

As an Action, ring the chime. Each Beast, Monstrosity with Intelligence 5 or lower, or willing spirit companion within 20 feet that can hear it becomes calm until the start of your next turn.

A hostile creature must succeed on a DC 13 Wisdom saving throw or cannot take Reactions and has Disadvantage on its next attack roll before the effect ends.

After a creature succeeds on this save, it is immune to the chime until dawn.

---

## 78. River-Current Measuring Float
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Travel Survey  
**Sphere Influences:** Water, Flowing River, Source  
**Attunement Slots:** None  
**Primary Construction:** River jade and weighted spirit wood

Place the float on a liquid surface and observe it for 1 minute.

You learn the current's direction, approximate speed, depth category, whether it is naturally or supernaturally disturbed, and whether a strong undertow or hidden drop lies within 100 feet downstream.

The float does not detect creatures, poison, portals, or hazards that do not alter the water's movement.

---

## 79. False-Gold Revealing Scale
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Trade and Appraisal  
**Sphere Influences:** Metal, Source, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Balanced spirit bronze and source-jade weights

Place up to 10 pounds of coins, metal, ore, jewelry, or trade bars on the scale and spend 1 minute weighing them.

The scale reveals approximate purity, total ordinary market weight, and whether the sample contains mundane plating, filler, or counterfeit alloy.

It does not identify supernatural enchantments, ownership, historical value, or a sophisticated Saint-grade forgery.

---

## 80. Breath-Counting Meditation Bell
*Wondrous Item, Spiritual Treasure*

**Treasure Family:** Meditation and Training  
**Sphere Influences:** Air, Qiweaving, Sound  
**Attunement Slots:** None  
**Primary Construction:** Clear bronze and breath jade

The bell sounds softly at intervals matching the user's breathing while held during meditation.

A creature using it for at least 10 minutes has Advantage on the next ability check made before its next Long Rest to control breathing, resist suffocation, steady qi circulation, or maintain a mantra under stress.

A creature can gain this benefit only once per Long Rest.

---

# Saint Treasures 81–100

## 81. Mountain-Root Suppression Seal
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Suppression and Control  
**Sphere Influences:** Earth, Gravity, Sealing  
**Attunement Slots:** 1 slot  
**Primary Construction:** Mountain-root jade engraved with weight inscriptions

The seal has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

**Suppress.** As an Action, expend 1 charge and choose one creature or unattended object you can see within 60 feet. A creature makes a Strength saving throw against your item save DC.

On a failed save, its Speed becomes 0 and it cannot be moved by its own teleportation until the start of your next turn. On a successful save, its Speed is reduced by 10 feet until then.

An unattended object weighing no more than 5,000 pounds becomes fixed in place until the start of your next turn.

---

## 82. Five-Feather Calamity Fan
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Elemental Utility  
**Sphere Influences:** Weather, Fire, Ice, Lightning, Air  
**Attunement Slots:** 1 slot  
**Primary Construction:** Five spirit-beast feathers mounted in storm bamboo

The fan has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

As an Action, expend 1 charge and choose one effect:

- **Cinder Wind:** 30-foot cone; Dexterity save; `4d6` fire damage, half on success.
- **Frost Gust:** 30-foot cone; Constitution save; `3d6` cold damage and Speed reduced by 10 feet until your next turn, half damage only on success.
- **Thunder Feather:** One creature within 60 feet; ranged item attack; `4d8` lightning damage on a hit.
- **Clearing Wind:** Disperse non-Imperial smoke, fog, gas, or airborne debris in a 30-foot-radius sphere within 60 feet.
- **Sky Lift:** Move one willing creature within 30 feet up to 30 feet through the air to an unoccupied space.

---

## 83. God-Striking Heartwood Rod
*Rod, Saint Treasure, Requires Attunement*

**Treasure Family:** Spirit and Construct Disruption  
**Sphere Influences:** Spirit, Force, Wood  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ancient heartwood, soul jade, and force inscriptions

The rod has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

As an Action, expend 1 charge and make a melee item attack against a creature within your reach. On a hit, the target takes `4d8` force damage.

If the target is a Construct, Undead, incorporeal spirit, summoned creature, or possessing entity, it takes an additional `2d8` psychic damage and must succeed on a Charisma saving throw against your item save DC or be unable to take Reactions until the start of your next turn.

---

## 84. Moon-Mirror Stillwater Mantle
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Reflection and Concealment  
**Sphere Influences:** Moon, Mirror, Water, Illusion  
**Attunement Slots:** 1 slot  
**Primary Construction:** Moon silk woven with mirror-sea silver thread

You have Advantage on saving throws against visual illusions and gaze effects.

The mantle has 3 charges and regains `1d3` expended charges when you complete a Long Rest.

**Stillwater Reflection.** When a creature you can see targets you with an attack, you can use your Reaction and expend 1 charge to impose Disadvantage on that attack. If the attack misses, you become Invisible until the start of your next turn or until you make an attack, deal damage, or force a saving throw.

---

## 85. Thunder-Script Escape Talisman
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Emergency Teleportation  
**Sphere Influences:** Lightning, Talismans, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Thunder jade, gold talisman ink, and folded space paper

The talisman has 3 charges and regains 1 expended charge when you complete a Long Rest.

When you take damage, you can use your Reaction and expend 1 charge to teleport up to 60 feet to an unoccupied space you can see after the damage resolves.

Creatures within 5 feet of the space you left must succeed on a Dexterity saving throw against your item save DC or take `2d8` lightning damage.

The talisman cannot cross a sealed dimensional boundary.

---

## 86. Nine-Lock Storage Ring
*Ring, Saint Treasure, Requires Attunement*

**Treasure Family:** Advanced Spatial Storage  
**Sphere Influences:** Space, Sealing, Equipment  
**Attunement Slots:** 1 slot  
**Primary Construction:** Nine-fold void crystal set in spirit gold

The ring contains nine separate extradimensional chambers. Each chamber holds up to **500 pounds or 32 cubic feet**.

As an Action, store one unattended object that fits through a 5-foot-wide opening. As a Bonus Action, retrieve one hand-held object from a known chamber; larger objects require an Action.

Each chamber can be individually locked. Opening a locked chamber without Attunement requires a successful DC 20 Intelligence (Arcana) check made during a 10-minute ritual.

Living creatures are immediately expelled and take `4d6` force damage. Nesting extradimensional spaces destroys the inserted container and scatters its contents within 300 feet.

---

## 87. Hundred-Beast Holding Bag
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Creature Residence  
**Sphere Influences:** Beastmastery, Spirit Companions, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Beast-hide bag lined with verdant space silk

The bag contains a stable extradimensional meadow suitable for up to **ten willing Beasts or bonded companions**, each Large or smaller.

A creature enters or leaves as an Action while touching the open bag. An unwilling creature cannot be placed inside.

Creatures inside have breathable air, water, and ordinary forage but do not complete Short or Long Rests there unless the bag remains stationary and open for the full rest.

If the bag is destroyed, occupants appear Prone in the nearest unoccupied spaces and take `4d6` force damage.

---

## 88. Cloud Palace Travel Pavilion
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Mobile Shelter  
**Sphere Influences:** Air, Space, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloudwood model pavilion and sky jade

As a 10-minute ritual, place the model on open ground. It expands into a furnished pavilion occupying a 30-foot square and standing 20 feet high.

The pavilion contains sleeping space for twelve creatures, a kitchen, a meeting room, and protected storage for 2,000 pounds of ordinary cargo.

It lasts until dismissed with a 10-minute ritual. While expanded, it cannot move and is an object with AC 17 and 150 Hit Points.

If destroyed, creatures are expelled safely, and stored objects spill into adjacent spaces. The pavilion reforms after 7 days.

---

## 89. Spirit-Spring Bathing Basin
*Wondrous Item, Saint Treasure*

**Treasure Family:** Recovery Installation  
**Sphere Influences:** Life, Water, Medicine  
**Attunement Slots:** None  
**Primary Construction:** River jade basin and spirit-spring core

When filled with at least 20 gallons of clean water, the basin creates a warm medicinal bath lasting 1 hour.

Up to four creatures can benefit during that hour. A creature that bathes for at least 30 minutes can spend Hit Dice as though completing a Short Rest and can immediately repeat one saving throw against a poison, disease, or Exhaustion effect that permits repeated saves.

The basin can be activated once and refreshes at dawn.

---

## 90. Pill-Refining Jade Gourd
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Alchemy and Storage  
**Sphere Influences:** Alchemy, Fire, Qiweaving  
**Attunement Slots:** 1 slot  
**Primary Construction:** Jade gourd, furnace-gold veins, and medicine seals

The gourd functions as a portable Saint-grade alchemical furnace and can hold up to 50 completed pills without loss of potency.

When used to refine a Mortal, Spiritual, or Saint-grade pill, you gain a +2 bonus to the Alchemy check.

Once per Long Rest, when such a check fails by 5 or less, you can convert the result into a Broken product instead of losing all ingredients.

The gourd does not create ingredients or bypass recipe access.

---

## 91. Source-Heaven Compass
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Geomantic Appraisal  
**Sphere Influences:** Source, Earth, The Hidden Eye  
**Attunement Slots:** 1 slot  
**Primary Construction:** Source jade, star iron, and a suspended silver needle

As a 10-minute ritual, place the compass on natural stone or soil.

You learn the direction, approximate depth, and broad grade of the strongest mineral deposit, spirit-stone vein, sealed stone, buried chamber, or major geomantic disturbance within 1 mile.

The compass distinguishes natural, constructed, sealed, and living sources but does not identify contents or safely open them.

A Sovereign or stronger concealment effect can produce no reading rather than a false one.

---

## 92. Thousand-Li Communication Mirror
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Long-Range Communication  
**Sphere Influences:** Mirror, Sound, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Mirror-sea silver and paired space jade

The treasure consists of two matched mirrors.

Once per Long Rest, a bearer can use an Action to call the paired mirror while both are on the same plane and within 1,000 miles.

If the other bearer accepts as a Reaction, the mirrors transmit sight and sound between them for up to 10 minutes. Each mirror shows only what lies directly before the other.

Sealed communication barriers, planar separation, or a stronger Space effect can prevent the connection.

---

## 93. Dream-Path Lantern
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Dream Travel and Defense  
**Sphere Influences:** Dreams, Spirit, Light  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dream crystal, moon bronze, and pale flame

While the lantern burns within 10 feet of you, you have Advantage on saving throws against dream intrusion, magical sleep, and nightmare effects.

Once per Long Rest, two willing creatures that complete a Long Rest within 10 feet of the lantern can enter a shared symbolic dream for up to 1 hour of subjective time.

They can converse and exchange remembered images but cannot carry objects, suffer physical damage, or learn information neither participant knows.

---

## 94. Ancestor-Questioning Incense Burner
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Ancestor Communion  
**Sphere Influences:** Spirit Companions, Death, Ink  
**Attunement Slots:** 1 slot  
**Primary Construction:** Funeral jade, ancestor bronze, and name-tablet slots

Once per Long Rest, burn incense worth 1 Low-Grade Spirit Stone while presenting a true name, blood relation, personal relic, or funerary tablet connected to a deceased ancestor.

After 10 minutes, ask up to three questions aloud. If the ancestor's spirit remains reachable and willing, the burner produces brief answers through smoke, sound, or written ash.

The answers reflect the ancestor's knowledge and perspective. The burner cannot compel a spirit, contact a destroyed soul, or guarantee objective truth.

---

## 95. Formation-Breaking Surveyor's Compass
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Formation Analysis  
**Sphere Influences:** Formations, Source, Force  
**Attunement Slots:** 1 slot  
**Primary Construction:** Rotating jade rings and spirit-bronze sighting arms

While holding the compass, you can perceive visible Formation Anchors and active formation lines within 60 feet as faint geometric light.

As an Action, choose one non-Imperial Formation Anchor you can see within range and make an Intelligence (Arcana) check against the formation's save DC.

On a success, you learn one of the following: its function, power source, linked anchors, current weakness, or the safest method to suppress it.

On a success by 5 or more, the next check or attack made against that anchor before the end of your next turn has Advantage.

---

## 96. Star-Position Astrolabe
*Wondrous Item, Saint Treasure*

**Treasure Family:** Navigation and Omens  
**Sphere Influences:** Stars, Fate, Space  
**Attunement Slots:** None  
**Primary Construction:** Star silver, night jade, and rotating celestial rings

The astrolabe functions under open sky, through ordinary clouds, and during daylight.

It always reveals your latitude-equivalent position, cardinal direction, local time, and whether you are on the same plane where it was created.

Once per Long Rest, spend 10 minutes observing the astrolabe to gain Advantage on one Wisdom (Survival), Intelligence (History), or Intelligence (Arcana) check made within 24 hours to navigate, interpret a celestial omen, or identify planar displacement.

---

## 97. Karma-Weight Measuring Scale
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Karmic Appraisal  
**Sphere Influences:** Karma, Fate, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Red-gold balance arms and black-white jade pans

As a 10-minute ritual, place a personal object, written oath, payment, gift, or symbolic offering on one pan while a willing creature touches the other.

You learn whether the creature currently believes accepting or fulfilling the represented exchange would create a minor, significant, or severe personal obligation.

The scale reads the creature's sincere sense of debt and consequence, not objective cosmic law. A creature can conceal its reading with a successful Charisma saving throw against your item save DC.

---

## 98. Oath-Binding Court Seal
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Oath and Authority  
**Sphere Influences:** Karma, Ink, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Court jade, red-gold ink channels, and witness bronze

During a 10-minute ritual, up to six willing creatures sign or mark a written agreement of no more than 1,000 words.

For 30 days, each signer knows when it knowingly violates a direct, unambiguous prohibition in the agreement and takes `3d6` psychic damage immediately after the violation.

A signer can suffer this damage only once per day. The seal does not compel obedience, interpret ambiguous wording, or punish an act the signer sincerely believed was permitted.

A remove-curse-equivalent effect or stronger Karma technique can end a creature's bond.

---

## 99. Bloodline Recognition Mirror
*Wondrous Item, Saint Treasure*

**Treasure Family:** Lineage Appraisal  
**Sphere Influences:** Blood, Spirit, The Hidden Eye  
**Attunement Slots:** None  
**Primary Construction:** Blood jade, mirror silver, and ancestral ink

A creature places one drop of blood on the mirror and waits 1 minute.

The mirror reveals whether the sample shares a direct bloodline connection with another stored sample, one known lineage entered into the mirror, or a willing creature touching the frame.

It reports no relation, distant relation, close relation, or direct parent-child relation. It does not reveal identity, legitimacy, inheritance rights, race, or exact genealogy.

The mirror can store twelve reference samples at a time.

---

## 100. Soul-Wound Mending Needle Case
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Spiritual Medicine  
**Sphere Influences:** Medicine, Spirit, Thread  
**Attunement Slots:** 1 slot  
**Primary Construction:** Soul jade case with nine moon-silver needles

The case has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

As an Action, touch one willing creature and expend 1 charge. The target regains `3d8 + your Proficiency Bonus` Hit Points and can immediately repeat one saving throw against possession, Charmed, Frightened, or a spirit-inflicted condition that permits repeated saves.

Alternatively, expend 2 charges during a 10-minute procedure to end one minor spiritual injury, nightmare residue, possession aftereffect, or soul scar of Saint grade or lower, subject to GM adjudication.

---

# Chunk 2 Audit

All entries were checked for:

- exact master-index name and number;
- correct grade allocation;
- explicit item type and Attunement status;
- complete action, range, duration, save, charge, and recovery language;
- creature-consent and storage restrictions where relevant;
- no automatic Sphere, Talent, Method, Foundation, or lineage ownership;
- no blanket once-per-turn restriction;
- no duplication with weapon or armor enhancement slots;
- clear Saint-grade escalation without replacing Imperial or Immortal authority.


## Chapter 4C: Wondrous Treasures — Production Chunk 3
### Treasures 101–150 v0.1

This chapter completes the Saint Treasure portion of the 200-item catalog and begins the Sovereign Treasure portion.

## Grade Breakdown

| Grade | Items |
|---|---:|
| Saint Treasure | 35 |
| Sovereign Treasure | 15 |
| **Total** | **50** |

## Escalation Doctrine

- Saint Treasures support advanced cultivators, professional crafting, estates, lineages, sect operations, long-range travel, and serious spiritual medicine.
- Sovereign Treasures can affect regions, preserve souls for long periods, move great distances, establish major domains, or protect entire sect sites.
- A treasure's grade measures scale and authority, not merely damage.
- Infrastructure entries state installation time, protected area, durability, and failure behavior.
- Residence and transport entries state occupants, cargo, travel rate, destruction results, and planar limits.
- Soul-related treasures require willingness unless a hostile binding effect is explicitly printed.
- Sphere Influences do not grant Spheres, Talents, Foundations, Methods, or prerequisites.

---

# Saint Treasures 101–135

## 101. Phoenix-Feather Rescue Fan
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Emergency Rescue  
**Sphere Influences:** Fire, Life, Air  
**Attunement Slots:** 1 slot  
**Primary Construction:** Phoenix feather, sun copper, and renewal jade

The fan has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

**Rescue Wind.** When a creature you can see within 60 feet would drop to 0 Hit Points but not die outright, you can use your Reaction and expend 2 charges. The creature drops to 1 Hit Point instead and can move up to 20 feet without provoking Opportunity Attacks.

**Rekindling Gust.** As an Action, expend 1 charge. One willing creature within 30 feet regains `3d8 + your Proficiency Bonus` Hit Points.

A creature can benefit from Rescue Wind only once per Long Rest.

---

## 102. Deep-Sea Breathing Pearl
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Aquatic Survival  
**Sphere Influences:** Water, Pressure, Life  
**Attunement Slots:** 1 slot  
**Primary Construction:** Abyssal pearl, deepsea cold iron, and river jade

While the pearl is on your person, you can breathe air and water, gain a Swim Speed equal to your Speed, and suffer no harm from ordinary deep-water pressure.

You can speak normally underwater, though only creatures able to hear through water understand you.

The pearl has 3 charges and regains all expended charges at dawn. As an Action, expend 1 charge to grant these benefits to up to six willing creatures within 10 feet for 1 hour.

---

## 103. Mountain-Bearing Travel Pagoda
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Cargo and Shelter  
**Sphere Influences:** Earth, Space, Equipment  
**Attunement Slots:** 1 slot  
**Primary Construction:** Mountain jade, folded-space stone, and black iron

The palm-sized pagoda contains an extradimensional cargo hall holding up to **20,000 pounds or 2,000 cubic feet** of nonliving material.

An unattended object no larger than a 10-foot cube can be stored or retrieved as an Action while touching the pagoda. A creature cannot enter the hall.

As a 10-minute ritual, expand the pagoda into a 20-foot-square stone shelter. While expanded, stored cargo can be accessed through its doors, and up to twelve creatures can shelter inside the ordinary room. The extradimensional cargo hall remains inaccessible to creatures.

If destroyed, stored cargo appears in the nearest unoccupied spaces without taking damage.

---

## 104. Cloud-Riding Crane Carving
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Flying Mount  
**Sphere Influences:** Air, Spirit Companions, Wood  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloudwood carved around a wind-crystal heart

As an Action, place the carving in an unoccupied space within 10 feet. It becomes a Large cloud crane with AC 17, 60 Hit Points, a walking Speed of 20 feet, and a Fly Speed of 80 feet.

The crane can carry up to four Medium creatures and 500 pounds of cargo. It understands your languages and obeys your spoken directions but cannot attack.

The crane remains for up to 8 hours, until reduced to 0 Hit Points, or until dismissed as a Bonus Action. It then returns to carving form. If reduced to 0 Hit Points, it cannot transform again until 7 days have passed.

---

## 105. Wind-Gate Folding Screen
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Linked Passage  
**Sphere Influences:** Air, Space, Formations  
**Attunement Slots:** 1 slot  
**Primary Construction:** Two matched cloudwood screens painted with wind paths

The treasure consists of two folding screens.

After each screen has remained open and stationary for 10 minutes, they form a linked passage while on the same plane and within 10 miles.

A willing creature can use an Action to step through one screen and emerge from the other in the nearest unoccupied space. A creature larger than Large cannot pass through.

The passage transports up to twenty creatures or 5,000 pounds of unattended objects between Long Rests. Moving, closing, damaging, or separating either screen ends the link.

---

## 106. Hidden-City Map Case
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Settlement Navigation  
**Sphere Influences:** Space, Ink, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Black jade, city-map silk, and concealed-path inscriptions

The case can store up to one hundred maps without increasing its 3-pound weight.

During a Long Rest in a settlement, the case records public roads, gates, bridges, major districts, government buildings, markets, inns, temples, and other locations you personally visit or can see from a public place.

As an Action, name one recorded destination in the current settlement. The case displays the shortest publicly accessible route and estimates ordinary travel time.

The case does not reveal secret passages, hidden organizations, private interiors, patrol schedules, or changes made after the map was recorded.

---

## 107. Spirit-Beast Evolution Cauldron
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Companion Advancement  
**Sphere Influences:** Beastmastery, Spirit Companions, Alchemy  
**Attunement Slots:** 1 slot  
**Primary Construction:** Beast-core bronze, verdant jade, and bloodline seals

The cauldron can perform a 24-hour refinement ritual for one willing Beast or bonded companion. The ritual consumes appropriate harvested materials worth at least 5 Mid-Grade Spirit Stones.

At the ritual's end, choose one adaptation lasting until the creature completes its next Long Rest:

- gain Resistance to acid, cold, fire, lightning, or poison;
- increase one movement Speed by 20 feet;
- gain a Climb or Swim Speed equal to its Speed;
- gain Temporary Hit Points equal to five times your Proficiency Bonus;
- treat its natural attacks as magical and add `1d6` damage of an appropriate elemental type.

A creature can receive one adaptation at a time. Permanent evolution requires its own progression rule, ingredients, and story procedure.

---

## 108. Verdant Garden Seed Box
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Portable Garden  
**Sphere Influences:** Verdant Growth, Space, Harvesting Gathering  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-seed wood, river jade, and fertile spirit soil

The box contains a stable 60-foot-square garden with twelve cultivation plots.

A willing creature can enter or leave as an Action while touching the open box. The garden has breathable air, clean water, and ordinary daylight, but it cannot support a Long Rest unless the box remains stationary and open for the full rest.

Plants grow at **four times** their normal rate. The garden can safely cultivate Mortal, Spiritual, and Saint-grade plants when proper seeds, soil, and care are supplied.

It cannot hold animals larger than Tiny, create ingredients, or grow Sovereign-grade plants.

---

## 109. Corpse-Preservation Black Jade Coffin
*Wondrous Item, Saint Treasure*

**Treasure Family:** Funerary Preservation  
**Sphere Influences:** Death, Ice, Sealing  
**Attunement Slots:** None  
**Primary Construction:** Black jade, ghost iron, and preservation seals

The coffin holds one Medium or smaller corpse, or the equivalent remains of a larger creature.

A corpse sealed inside does not decay for **one year**, cannot rise as an Undead of Saint grade or lower, and cannot be possessed through the coffin.

A creature attempting to locate, animate, or communicate with the corpse through a supernatural effect must succeed on an ability check against DC 17.

Opening the coffin suspends these protections until it is closed and sealed again during a 10-minute ritual.

---

## 110. Soul-Sheltering Funeral Lamp
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Soul Preservation  
**Sphere Influences:** Death, Spirit, Radiance  
**Attunement Slots:** 1 slot  
**Primary Construction:** Funeral bronze, soul jade, and a white flame

When a willing creature dies within 30 feet, you can use your Reaction to invite its departing soul into the lamp. An unwilling soul cannot be captured.

The soul can remain for up to 7 days. During that time, the corpse cannot rise as an Undead unless the soul consents, and effects that restore the creature to life treat the soul as present.

Once per day, the soul can speak through the flame for up to 10 minutes. It retains its knowledge and personality but cannot perceive beyond the lamp's space unless shown something directly.

The soul can leave at any time and departs automatically when restored to life.

---

## 111. Thousand-Voice Music Box
*Wondrous Item, Saint Treasure*

**Treasure Family:** Sound Archive  
**Sphere Influences:** Sound, Beauty, Ink  
**Attunement Slots:** None  
**Primary Construction:** Resonant wood, silver cylinders, and memory crystal

The box stores up to one thousand recordings, each lasting no more than 1 hour.

As an Action, begin or end a recording of audible sound within 60 feet. As an Action, replay one recording at its original volume or any quieter volume.

The box can reproduce layered performances, spoken testimony, animal calls, environmental sound, and command phrases, but it does not reproduce supernatural effects carried by a voice.

You have Advantage on checks made to compare a current voice or sound to a stored recording.

---

## 112. Memory-Sealing Jade Archive
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Memory Archive  
**Sphere Influences:** Spirit, Dreams, Ink  
**Attunement Slots:** 1 slot  
**Primary Construction:** One hundred linked jade slips and a soul-silver frame

A willing creature can spend 10 minutes touching the archive to copy one memory lasting no more than 1 hour. Copying does not remove or alter the original memory.

The archive stores up to one hundred memories. A creature touching it can replay one memory during an equal amount of real time, experiencing the contributor's recorded senses and emotions.

A contributor can seal its memory behind a command phrase or named list of permitted viewers. Opening a sealed memory without permission requires a successful DC 18 Intelligence (Arcana) check during a 1-hour ritual.

The archive records subjective memory, not objective truth.

---

## 113. Truth-and-Falsehood Dividing Mirror
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Testimony Appraisal  
**Sphere Influences:** Mirror, Fate, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Black-white mirror glass and court jade

The mirror has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

After a creature visible in the mirror makes a factual statement of no more than 100 words, you can expend 1 charge as a Reaction. An unwilling speaker makes a Charisma saving throw against your item save DC.

On a failed save, the mirror displays:

- **white** if the speaker sincerely believes the statement is substantially true;
- **black** if the speaker knowingly makes a substantially false statement;
- **divided** if the speaker mixes believed truth with deliberate falsehood.

On a successful save, the mirror clouds. It does not identify omissions, objective truth, prophecy, or magically altered beliefs.

---

## 114. Poison-Absorbing Medicine Jar
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Poison Treatment and Storage  
**Sphere Influences:** Poison, Medicine, Alchemy  
**Attunement Slots:** 1 slot  
**Primary Construction:** Medicine jade, purified silver, and black-glass seals

The jar has 7 charges and regains `1d6 + 1` expended charges when you complete a Long Rest.

**Purify Substance.** As an Action, expend 1 charge to remove one poison of Saint grade or lower from up to 1 gallon of food, drink, or medicine placed inside.

**Draw Poison.** During a 1-minute procedure, expend 2 charges while touching a willing creature. End the Poisoned condition caused by one poison of Saint grade or lower.

The removed poison is condensed into a sealed dose inside the jar. The jar can hold three doses. Removing a dose safely requires Alchemist's Supplies and a successful DC 15 Intelligence check.

---

## 115. Five-Flavor Banquet Cauldron
*Wondrous Item, Saint Treasure*

**Treasure Family:** Hospitality and Recovery  
**Sphere Influences:** Life, Alchemy, Sect Stewardship  
**Attunement Slots:** None  
**Primary Construction:** Five-phase bronze, spirit ceramic, and hearth jade

Given ordinary ingredients for at least twenty meals, the cauldron prepares a complete banquet during a 1-hour ritual.

Choose one banquet effect. A creature that eats for at least 10 minutes gains the chosen benefit until its next Long Rest:

- **Bitter:** Advantage on saving throws against poison and disease.
- **Sweet:** Temporary Hit Points equal to twice its Proficiency Bonus.
- **Sour:** Advantage on initiative rolls.
- **Spicy:** Speed increases by 5 feet.
- **Savory:** It can reroll one Hit Die spent during a Short Rest.

A creature can benefit from only one Five-Flavor banquet per Long Rest.

---

## 116. Clean-Meridian Tea Kettle
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Cultivation Recovery  
**Sphere Influences:** Qiweaving, Medicine, Water  
**Attunement Slots:** 1 slot  
**Primary Construction:** Medicine jade, river silver, and meridian inscriptions

The kettle prepares six servings of meridian-clearing tea during a Short or Long Rest using herbs worth 1 Mid-Grade Spirit Stone.

A creature can drink one serving during that rest to regain expended CP, Stamina, or Resonance equal to its Proficiency Bonus.

A creature can benefit from the kettle only once per Long Rest.

For 1 hour after drinking, the creature has Advantage on saving throws against effects that would prevent it from spending its Path resource or that would corrupt its circulation.

---

## 117. Formation-Linked Camp Banner
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Camp Formation  
**Sphere Influences:** Formations, Warleader, Protection  
**Attunement Slots:** 1 slot  
**Primary Construction:** Formation silk, spirit-iron pole, and source-jade finial

As a 10-minute procedure, plant the banner to create a 60-foot-radius camp formation for up to 8 hours.

While inside the formation:

- allied creatures cannot be surprised while conscious;
- ordinary weather does not extinguish fires or damage shelters;
- the attuned bearer knows when a Tiny or larger creature crosses the boundary;
- allies have Advantage on saving throws against magical sleep and dream intrusion.

The formation ends if the banner is moved, knocked down, or reduced to 0 Hit Points. The banner has AC 17 and 40 Hit Points.

---

## 118. Lightning-Rod Sect Spire
*Wondrous Item, Saint Treasure*

**Treasure Family:** Sect Infrastructure  
**Sphere Influences:** Lightning, Formations, Earth  
**Attunement Slots:** None  
**Primary Construction:** Storm iron, grounding jade, and a 30-foot bronze mast

The spire requires 1 hour to install and protects a 300-foot-radius area.

Natural lightning and uncontrolled Spiritual- or Saint-grade lightning effects striking the protected area are drawn to the spire when possible. Creatures and structures in the area have Resistance to lightning damage.

The spire stores up to 5 Lightning charges. Whenever it prevents or reduces at least 20 lightning damage, it gains 1 charge.

An adjacent formation or crafting installation can expend 1 stored charge to replace 1 Mid-Grade Spirit Stone of lightning-aligned power. Unused charges dissipate after 7 days.

---

## 119. Ghost-Warding Gate Lions
*Wondrous Item, Saint Treasure*

**Treasure Family:** Boundary Guardians  
**Sphere Influences:** Spirit, Protection, Formations  
**Attunement Slots:** None  
**Primary Construction:** A matched pair of ghost-iron and white-jade lion statues

Place the two lions on opposite sides of an entrance no wider than 30 feet. After 1 hour, they create a ward extending through that entrance.

An Undead, incorporeal spirit, or possessing entity attempting to cross must make a Charisma saving throw against DC 17.

On a failed save, it cannot cross for 1 hour and takes `4d8` radiant damage. On a successful save, it crosses but causes both lions to roar audibly out to 300 feet.

The ward does not affect a creature openly invited by the owner during setup.

---

## 120. Illusion-Piercing Third-Eye Circlet
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Perception and Revelation  
**Sphere Influences:** The Hidden Eye, Illusion, Spirit  
**Attunement Slots:** 1 slot  
**Primary Construction:** Moon silver, clear jade, and a central eye crystal

You have Advantage on saving throws against illusions and on Intelligence (Investigation) checks made to discern them.

The circlet has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

As a Bonus Action, expend 1 charge to gain the following benefits for 1 minute:

- see Invisible creatures and objects within 30 feet;
- perceive visual illusions as translucent;
- see active talisman lines, Formation Anchors, and possession marks within 30 feet.

Total Cover blocks this sight.

---

## 121. Hidden-Step Shadow Boots
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Stealth and Teleportation  
**Sphere Influences:** Shadow, Space, Athletics  
**Attunement Slots:** 1 slot  
**Primary Construction:** Shadow hide, moon-silver buckles, and void-thread soles

Your Speed increases by 10 feet while you are in Dim Light or Darkness.

The boots have 5 charges and regain `1d4 + 1` expended charges when you complete a Long Rest.

As a Bonus Action while in Dim Light or Darkness, expend 1 charge to teleport up to 40 feet to an unoccupied space you can see that is also in Dim Light or Darkness.

After teleporting, you have Advantage on the next Dexterity (Stealth) check you make before the end of the turn.

---

## 122. Gravity-Training Iron Rings
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Training and Physical Release  
**Sphere Influences:** Gravity, Athletics, Equipment  
**Attunement Slots:** 1 slot  
**Primary Construction:** Eight black-iron rings engraved with adjustable weight seals

The set contains eight rings worn on the wrists, ankles, waist, and shoulders.

As an Action, set the rings to one of three training loads: light, heavy, or crushing.

- **Light:** No penalty; you have Advantage on checks made during structured physical training.
- **Heavy:** Speed is reduced by 10 feet, but you count as one size larger for carrying capacity.
- **Crushing:** Speed is halved, and you have Disadvantage on Dexterity checks, but one hour of successful training counts as two hours.

Once per Long Rest, after wearing Heavy or Crushing load for at least 1 hour, you can release all weight as a Bonus Action. For 10 minutes, your Speed increases by 15 feet and your jump distances triple.

---

## 123. River-Dragon Ferry Token
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Water Transport  
**Sphere Influences:** Water, Spirit Companions, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dragon-scale jade carved as a ferry coin

As a 10-minute ritual performed beside a body of water at least 20 feet across, summon a spectral river-dragon ferry.

The ferry can carry twenty Medium creatures and 10,000 pounds of cargo. It has a Swim Speed of 100 feet and can travel continuously for 8 hours.

It ignores ordinary currents, rapids, waves, and shallows but cannot leave the water, cross a sealed boundary, or enter a space narrower than 20 feet.

Once dismissed or after 8 hours, the ferry cannot be summoned again until dawn.

---

## 124. Moonwell Reflection Basin
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Remote Viewing  
**Sphere Influences:** Moon, Mirror, Water  
**Attunement Slots:** 1 slot  
**Primary Construction:** Moon jade basin lined with mirror-sea silver

Fill the basin with clean water and expose it to natural moonlight for 10 minutes.

Once per Long Rest, name a location you have personally visited on the same plane. The basin shows and transmits sound from a 20-foot-radius area centered on that location for up to 10 minutes, requiring Concentration.

A location protected by a stronger concealment effect causes the water to cloud. Creatures at the viewed location can notice the observation with a successful Wisdom (Perception) check against your item save DC, perceiving a faint moonlit reflection.

---

## 125. Starfall Message Arrow Case
*Wondrous Item, Saint Treasure*

**Treasure Family:** Long-Range Delivery  
**Sphere Influences:** Stars, Air, Ink  
**Attunement Slots:** None  
**Primary Construction:** Star-silver case containing twelve returning message arrows

The case holds twelve magical arrows. Each reforms in the case at dawn if lost or destroyed.

As an Action, attach a written message or object weighing no more than 1 pound to an arrow and name a creature or fixed location you know within 100 miles on the same plane.

When fired into open air, the arrow becomes a streak of starlight and travels toward the destination at 1 mile per minute. It lands harmlessly in the nearest open space.

A sealed boundary, stronger interception effect, or an inaccurate destination can prevent delivery. An undelivered arrow returns to the case after 1 hour.

---

## 126. Spirit-Companion Residence Orb
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Companion Residence  
**Sphere Influences:** Spirit Companions, Space, Life  
**Attunement Slots:** 1 slot  
**Primary Construction:** Soul jade orb containing a verdant miniature sanctuary

The orb contains a 100-foot-radius sanctuary suitable for up to six willing spirit companions or bonded creatures, each Huge or smaller.

A companion touching the orb enters or leaves as an Action. Occupants have breathable air, clean water, appropriate ordinary shelter, and can complete Short and Long Rests if the orb remains stationary for the full rest.

A companion completing a Long Rest inside regains additional Hit Points equal to five times your Proficiency Bonus.

If the orb is destroyed, occupants appear Prone in the nearest unoccupied spaces and take `6d6` force damage.

---

## 127. Sect Steward's Endless Ledger
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Administration and Inventory  
**Sphere Influences:** Sect Stewardship, Ink, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Living paper, jade covers, and identity seals

The ledger stores up to one million written records without increasing in size.

It can automatically record authorized deposits, withdrawals, assignments, dues, loans, permissions, and inventory changes occurring within a linked storehouse or treasury no larger than a 300-foot-radius area.

As an Action, state a query concerning its records. The ledger presents a complete answer organized by date, person, category, or value.

It records transactions, not truth. A concealed theft or false declaration appears only if detected or entered by an authorized witness.

---

## 128. Harvest-Moon Storage Barn Token
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Agricultural Storage  
**Sphere Influences:** Harvesting Gathering, Space, Moon  
**Attunement Slots:** 1 slot  
**Primary Construction:** Moonwood token carved as a barn

As a 10-minute ritual, expand the token into a 40-foot-by-80-foot barn with a 20-foot interior height.

The barn stores up to 100,000 pounds of grain, herbs, fruit, fodder, lumber, hides, and other harvested nonliving materials.

Contents do not rot, mold, sprout, or attract ordinary vermin. The interior remains cool and dry.

The barn can be collapsed during a 10-minute ritual only while no creature is inside. Stored goods remain within the token and can be accessed only while expanded.

---

## 129. Blacksmith's Nine-Heat Furnace
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Smithing Installation  
**Sphere Influences:** Blacksmith, Fire, Metal  
**Attunement Slots:** 1 slot  
**Primary Construction:** Nine-chamber spirit furnace, sun copper, and temper jade

The furnace supports crafting and repairing treasures up to Saint grade.

When beginning a project, choose one of nine heat patterns: softening, purification, alloying, tempering, quenching, inscription bonding, spirit-stone smelting, corruption burning, or repair.

You gain a +2 bonus to Blacksmith checks appropriate to the chosen pattern.

Once per Long Rest, when such a check fails by 5 or less, you can preserve all rare materials and convert the result into a delayed project requiring 25 percent additional time instead of suffering the normal failure consequence.

---

## 130. Alchemist's Seven-Petal Cauldron
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Alchemy Installation  
**Sphere Influences:** Alchemy, Medicine, Fire  
**Attunement Slots:** 1 slot  
**Primary Construction:** Seven-layer medicine jade and phoenix-ash bronze

The cauldron supports alchemical products up to Saint grade and can maintain seven separately sealed ingredient chambers.

You gain a +2 bonus to Alchemy checks made with it.

At the start of a project, choose one petal principle: purification, concentration, preservation, poison separation, temperature balance, qi circulation, or pill shaping. The project gains Advantage on one check directly governed by that principle.

Once per Long Rest, a failed project can produce one-half of its intended yield as Broken or weakened products instead of losing the entire batch.

---

## 131. Calligrapher's Living-Ink Brush
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Writing and Inscription  
**Sphere Influences:** Ink, Talismans, Imbuement  
**Attunement Slots:** 1 slot  
**Primary Construction:** Enlightenment wood, living inkstone hair, and moon-silver ferrule

The brush creates ordinary black, red, gold, or silver ink without consuming supplies.

As an Action, it can copy one visible page of nonmagical writing onto a blank page. It preserves layout and handwriting but not supernatural properties.

You gain a +2 bonus to checks made to create or repair written talismans, seals, manuals, contracts, or formation diagrams up to Saint grade.

Once per Long Rest, when such a check fails by 5 or less, the brush prevents activation and preserves all rare ink and paper for another attempt.

---

## 132. Formation Master's Rotating Array Board
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Formation Design  
**Sphere Influences:** Formations, Strategy, Source  
**Attunement Slots:** 1 slot  
**Primary Construction:** Rotating jade discs, star-silver pins, and source-stone channels

The board stores up to twelve formation layouts.

During a Short Rest, you can construct a moving three-dimensional simulation of one stored or observed Formation. You gain a +2 bonus to checks made to analyze, teach, modify, or repair that layout.

Once per Long Rest, the board can project a harmless 30-foot-radius training simulation for 10 minutes. The simulation displays lines, zones, trigger order, and predicted movement but deals no damage and creates no real conditions.

---

## 133. Source-Reader's Earth Pulse Drum
*Wondrous Item, Saint Treasure*

**Treasure Family:** Regional Survey  
**Sphere Influences:** Source, Earth, Sound  
**Attunement Slots:** None  
**Primary Construction:** Earthwood drum, source-jade frame, and dragon-hide head

Install the drum on natural ground and perform a 1-hour rhythm.

You learn the direction and broad distance of major mineral deposits, spirit-stone veins, underground rivers, caverns, artificial tunnels, and geomantic disruptions within 10 miles.

The drum classifies each reading as trace, minor, substantial, great, or sealed.

It does not identify specific treasure contents, creatures, traps, or a Sovereign-grade concealment. The drum can perform one regional survey per dawn.

---

## 134. Wandering Healer's Hundred-Medicine Cabinet
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Portable Clinic  
**Sphere Influences:** Medicine, Alchemy, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Medicine wood, folded-space drawers, and cleansing copper

The cabinet weighs 20 pounds and holds up to one hundred medicine doses, healer's-kit uses, pills, tools, or biological samples without spoilage.

It has 10 Medicine charges and regains `1d6 + 4` expended charges when restocked during a Long Rest with supplies worth 1 Mid-Grade Spirit Stone.

As an Action, expend:

- **1 charge:** restore `2d8 + your Proficiency Bonus` Hit Points to a touched creature;
- **2 charges:** end one nonmagical poison or disease;
- **3 charges:** allow a touched creature to repeat one saving throw against a Saint-grade or lower poison, disease, or curse that permits repeated saves.

The cabinet cannot restore a dead creature to life.

---

## 135. Guardian Ancestor Statue
*Wondrous Item, Saint Treasure, Requires Attunement*

**Treasure Family:** Ancestral Guardian  
**Sphere Influences:** Spirit Companions, Guardian, Warleader  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ancestor jade, spirit bronze, and a true-name inscription

While the statue is on your person, you cannot be surprised while conscious.

The statue has 5 charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

**Ancestral Intercession.** When you or an ally within 30 feet takes damage, use your Reaction and expend 1 charge to reduce that damage by `3d8 + your Proficiency Bonus`.

**Guardian Manifestation.** As an Action, expend 3 charges to manifest a Large spectral guardian in an unoccupied space within 30 feet for 1 minute, requiring Concentration. Allies within 10 feet of it have Half Cover. The guardian cannot move or attack.

---

# Sovereign Treasures 136–150

## 136. Nine-Dragon Binding Seal
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Greater Binding  
**Sphere Influences:** Chains, Dragon, Sealing  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dragon-patterned abyssal gold, mountain jade, and nine seal faces

The seal has 7 charges and regains `1d6 + 1` expended charges when you complete a Long Rest.

As an Action, expend 2 charges and choose one Gargantuan or smaller creature within 120 feet. It makes a Strength saving throw against your item save DC.

On a failed save, nine spectral dragons bind it for up to 1 minute, requiring Concentration. While bound, it is Restrained, cannot teleport or travel between planes, and cannot willingly move from its space.

At the end of each of its turns, it repeats the save, ending the effect on a success. On the initial successful save, its Speed is halved until the end of its next turn.

A creature that escapes is immune to the seal until the start of your next turn.

---

## 137. Source-Heaven Grand Compass
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Grand Geomantic Survey  
**Sphere Influences:** Source, Earth, Stars  
**Attunement Slots:** 1 slot  
**Primary Construction:** Sovereign source jade, star iron, and a floating heaven needle

The compass can survey a region during a 1-hour ritual performed on natural ground.

Choose a radius up to 100 miles. The compass reveals:

- major spirit-stone and mineral veins;
- Sovereign-grade or stronger geomantic disturbances;
- large sealed domains, artificial caverns, and buried complexes;
- the direction of the strongest natural Source concentration;
- whether the region's qi flow is stable, exhausted, corrupted, diverted, or concealed.

The compass provides a layered map but not exact treasure contents, passwords, creatures, or safe routes. An Imperial concealment can block a portion of the reading without creating false information.

The compass can perform one grand survey per Long Rest.

---

## 138. Li-Fire Restoring Furnace
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Treasure Restoration  
**Sphere Influences:** Fire, Blacksmith, Imbuement  
**Attunement Slots:** 1 slot  
**Primary Construction:** Li-fire crystal, phoenix-blood metal, and restoration inscriptions

The furnace repairs and purifies treasures up to Sovereign grade.

**Major Repair.** A 24-hour ritual consuming materials worth 10 High-Grade Spirit Stones restores a broken but substantially complete Sovereign-grade or lower treasure to full function.

**Reforge Fragment.** A 7-day ritual can reconstruct a destroyed treasure when at least half of its original Primary Material and its defining core, spirit, or inscription survives. The ritual consumes materials worth half the treasure's normal crafting cost.

**Burn Corruption.** A 1-hour ritual allows an ability check using appropriate crafting tools against the corruption's save DC. On a success, one curse, hostile possession, or foreign refinement is suppressed for 30 days.

The furnace cannot restore an expended consumable, recreate an absent item spirit, or repair an Immortal Artifact.

---

## 139. Star-Road Crossing Chariot
*Vehicle, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Long-Range Transport  
**Sphere Influences:** Stars, Space, Vehicles  
**Attunement Slots:** 1 slot  
**Primary Construction:** Star silver, cloud-void crystal, and celestial beastwood

The chariot can carry twelve Medium creatures and 5,000 pounds of cargo. It has AC 20, 250 Hit Points, a ground Speed of 80 feet, and a Fly Speed of 150 feet.

While under open sky, it can enter **Star-Road Travel** after 10 minutes of uninterrupted movement. During Star-Road Travel, it covers up to 500 miles per hour and appears as a streak of light. It cannot attack, enter enclosed structures, or cross a planar boundary in this state.

Star-Road Travel can be maintained for 8 hours between Long Rests. If forced to end over unsafe terrain, the chariot descends to the nearest unoccupied ground space.

---

## 140. Thousand-Mile Cloud Palace
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Mobile Estate  
**Sphere Influences:** Air, Space, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloud palace seed, sovereign sky jade, and formation pillars

As a 1-hour ritual beneath open sky, the treasure expands into a flying palace occupying a 200-foot-square area.

The palace contains private rooms for fifty creatures, kitchens, meeting halls, training courts, protected storage for 100,000 pounds, and a central Formation chamber.

It has AC 20, 1,000 Hit Points, a Fly Speed of 100 feet, and can travel up to 1,000 miles per day. It cannot Dash, enter a space narrower than 250 feet, or travel between planes.

While stationary, the palace can hover. If reduced to 0 Hit Points, it descends safely for 1 minute before collapsing into dormant seed form. It reforms after 30 days and repairs worth 10 Perfect Spirit Stones.

---

## 141. Soul-Reincarnation Waiting Lamp
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Soul Preservation  
**Sphere Influences:** Death, Spirit, Karma  
**Attunement Slots:** 1 slot  
**Primary Construction:** Reincarnation bronze, soul jade, and karma-red flame

When a willing creature dies within 120 feet, you can use your Reaction to invite its soul into the lamp.

The soul can remain for up to **one year**. While sheltered:

- it can speak through the flame;
- it remembers its identity and life;
- it cannot be transformed into an Undead or consumed by a Sovereign-grade or weaker effect;
- effects restoring it to life treat the soul as present and willing;
- once per month, it can enter the dream of one willing creature sleeping within 1 mile and converse for up to 1 hour.

The soul can depart at any time. The lamp cannot capture an unwilling soul, force reincarnation, or determine the soul's next life.

---

## 142. Dream-Mirror Hall Seed
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Dream Estate  
**Sphere Influences:** Dreams, Mirror, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dream crystal seed, mirror-sea silver, and moonwood

As a 1-hour ritual, expand the seed into a 100-foot-square hall containing sleeping chambers for twenty creatures and a central dream mirror.

Creatures completing a Long Rest inside have Advantage on saving throws against dream intrusion and magical sleep.

Once per Long Rest, up to twenty willing sleeping creatures can enter a shared dream hall for up to 8 subjective hours while only 1 real hour passes. They can converse, rehearse known techniques, review memories they voluntarily present, and create harmless symbolic environments.

The dream hall cannot grant training time, new knowledge, healing, AP, Sphere ownership, or physical items.

---

## 143. Five-Phase Refinement Cauldron
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Grand Refinement  
**Sphere Influences:** Five-Phase, Alchemy, Blacksmith  
**Attunement Slots:** 1 slot  
**Primary Construction:** Five-phase alloy, sovereign furnace jade, and rotating elemental chambers

The cauldron supports crafting and refinement up to Sovereign grade.

At the start of a project, assign each of its five chambers to Fire, Water, Earth, Metal, or Wood. The cauldron can simultaneously purify, temper, preserve, combine, and circulate compatible materials.

You gain a +3 bonus to relevant Alchemy, Blacksmith, Medicine, or material-refinement checks.

Once per Long Rest, choose one benefit for a project:

- reduce required crafting time by 25 percent;
- preserve all rare materials after a failed check;
- substitute one compatible material of the same grade for a missing phase component;
- produce 25 percent additional consumable yield.

The cauldron cannot bypass formulas, access requirements, or an Immortal ingredient.

---

## 144. Mountain-and-River Suppression Map
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Regional Suppression  
**Sphere Influences:** Earth, Water, Formations  
**Attunement Slots:** 1 slot  
**Primary Construction:** Living landscape silk, mountain-root jade, and river-dragon ink

The map has 7 charges and regains `1d6 + 1` expended charges when you complete a Long Rest.

As an Action, expend 3 charges to unfold the map and create a 300-foot-radius suppression domain centered on a point you can see within 300 feet for up to 10 minutes, requiring Concentration.

Choose Mountain or River:

- **Mountain:** Hostile creatures treat the area as Difficult Terrain, cannot fly higher than 20 feet above the ground, and must succeed on a Strength saving throw when entering or starting their turn there or have Speed 0 until the start of their next turn.
- **River:** Hostile creatures are moved 20 feet in a direction you choose when they enter or start their turn there unless they succeed on a Strength saving throw. Allies can move across liquids and vertical surfaces in the area without falling during their turn.

The domain does not permanently alter terrain.

---

## 145. Sky-Watching Imperial Astrolabe
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Celestial Prediction  
**Sphere Influences:** Stars, Fate, Weather  
**Attunement Slots:** 1 slot  
**Primary Construction:** Star silver, heaven crystal, and nine rotating sky rings

The astrolabe precisely tracks celestial bodies, planar alignment, natural weather, eclipses, meteor activity, and large atmospheric disturbances.

Once per Long Rest, perform a 1-hour observation and choose one region within 1,000 miles that you can identify.

You learn the natural weather, major celestial events, and probable supernatural atmospheric disturbances expected there during the next 7 days.

You also receive one **Favorable Alignment die**, a `d12`, lasting until your next Long Rest. After you or an ally within 30 feet makes an attack roll, saving throw, or ability check, you can use your Reaction to add the die to the roll.

The astrolabe reports probability and signs, not guaranteed prophecy.

---

## 146. Ten-Thousand Beast Command Bell
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Beast Authority  
**Sphere Influences:** Beastmastery, Spirit Companions, Sound  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dragon bronze, beast-sovereign bone, and command inscriptions

The bell has 7 charges and regains `1d6 + 1` expended charges when you complete a Long Rest.

**Command the Host.** As an Action, expend 2 charges. Beasts and Monstrosities with Intelligence 7 or lower of your choice within 120 feet that can hear the bell make a Wisdom saving throw against your item save DC.

On a failed save, a hostile creature is Charmed by you for 1 minute, requiring Concentration. While Charmed, it will not harm you or your allies and obeys simple non-suicidal commands. It repeats the save whenever it takes damage.

Willing allied beasts within range instead gain Temporary Hit Points equal to four times your Proficiency Bonus and Advantage on attack rolls until the start of your next turn.

A creature that succeeds is immune until your next Long Rest.

---

## 147. Ancestor Court Tablet
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Ancestral Council  
**Sphere Influences:** Spirit Companions, Ink, Warleader  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ancestral jade, court wood, and nine true-name recesses

The tablet can hold the willingly recorded names and memories of up to nine deceased ancestors or lineage teachers.

Once per Long Rest, perform a 10-minute rite to manifest their spectral court for 1 hour. The court can answer up to nine questions using its members' knowledge and perspectives.

During the manifestation, choose one blessing:

- **War:** allies within 30 feet gain +2 to initiative;
- **Wisdom:** allies have Advantage on Intelligence and Wisdom ability checks;
- **Guardianship:** allies gain Temporary Hit Points equal to three times your Proficiency Bonus;
- **Discipline:** allies have Advantage on saving throws against Charmed and Frightened.

A blessing lasts 1 hour. The court cannot reveal information its members never knew.

---

## 148. Karma-Reversal Red Ledger
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Karmic Intervention  
**Sphere Influences:** Karma, Fate, Ink  
**Attunement Slots:** 1 slot  
**Primary Construction:** Living red paper, black-gold script, and a blood-jade clasp

The ledger has 5 Karma charges and regains `1d4 + 1` expended charges when you complete a Long Rest.

During a Long Rest, record the true names of up to six willing creatures.

When a recorded creature within 120 feet fails an attack roll, saving throw, or ability check, you can use your Reaction and expend 1 charge to let it reroll the d20 and use either result.

If the reroll changes failure to success, the ledger records a karmic debt. Before that creature completes its next Long Rest, the first time it succeeds on another d20 Test, it must roll a `d6` and subtract the result.

A creature can hold only one karmic debt at a time.

---

## 149. Void-Nail Boundary Pagoda
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Spatial Lockdown  
**Sphere Influences:** Space, Sealing, Formations  
**Attunement Slots:** 1 slot  
**Primary Construction:** Voidglass pagoda, origin-copper nails, and boundary jade

As a 10-minute ritual, place the pagoda on a stable surface to create a 300-foot-radius boundary for up to 8 hours.

Within the boundary:

- creatures cannot teleport or travel between planes against their will;
- hostile teleportation into or out of the area requires a Charisma saving throw against your item save DC;
- on a failed save, the teleportation is wasted and the creature takes `6d8` force damage;
- portals and extradimensional entrances of Sovereign grade or lower remain closed unless authorized during setup.

The boundary ends if the pagoda is moved or destroyed. It has AC 20 and 200 Hit Points.

---

## 150. Heaven-Sound Warning Bell
*Wondrous Item, Sovereign Treasure*

**Treasure Family:** Regional Alarm and Defense  
**Sphere Influences:** Sound, Formations, Warleader  
**Attunement Slots:** None  
**Primary Construction:** Heaven bronze, storm jade, and a suspended cloudwood beam

The bell requires 8 hours to install and protects a 1-mile-radius area.

During setup, designate authorized creatures, tokens, roads, and entry conditions. The bell sounds when:

- a hostile force of ten or more creatures enters the area;
- a Sovereign-grade or stronger supernatural effect is activated;
- a creature crosses a designated boundary without authorization;
- a linked Formation Anchor is destroyed.

The bell identifies the triggering category and direction to authorized listeners.

Once per Long Rest, an authorized creature adjacent to the bell can use an Action to release a defensive peal. Hostile creatures of its choice within 300 feet make a Constitution saving throw against DC 19. On a failed save, a creature takes `10d8` thunder damage and is Stunned until the end of its next turn. On a successful save, it takes half damage and is not Stunned.

---

# Chunk 3 Audit

All entries were checked for:

- exact master-index numbering and names;
- correct Saint and Sovereign grade allocation;
- explicit item type and Attunement status;
- complete action, reaction, range, duration, save, Concentration, charge, and recovery rules;
- explicit creature willingness for residence and soul storage;
- explicit installation, durability, and boundary rules for infrastructure;
- no blanket once-per-turn restriction;
- no automatic Sphere, Talent, Foundation, Method, or lineage ownership;
- no undefined extradimensional or regional effect;
- clear Sovereign escalation without consuming Imperial or Immortal design space.


## Chapter 4D: Wondrous Treasures — Final Production Chunk
### Treasures 151–200 v0.1

This chapter completes the 200-item Wondrous Treasure catalog.

## Grade Breakdown

| Grade | Items |
|---|---:|
| Sovereign Treasure | 20 |
| Imperial Treasure | 20 |
| Immortal Artifact | 10 |
| **Total** | **50** |

## Final Escalation Doctrine

- Sovereign Treasures can govern cities, regions, spirit veins, major formations, sect infrastructure, and long-term soul preservation.
- Imperial Treasures can define nations, great sects, continental routes, world-crossing vehicles, and major resurrection or calamity procedures.
- Immortal Artifacts are campaign-defining. Each has explicit limits, prerequisites, protected scope, and equal-rank counterplay.
- Scale does not erase procedure. Every regional, planar, soul, time, or world effect states installation, activation, duration, capacity, cost, and failure behavior.
- Immortal authority is not permission for undefined wishes, infinite resources, automatic cultivation advancement, free training time, or unrestricted world creation.
- Sphere Influences remain design and compatibility tags and do not grant Spheres, Talents, Methods, Foundations, Insights, or prerequisites.

---

# Sovereign Treasures 151–170

## 151. Ocean-Stilling Pearl
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Regional Water Control  
**Sphere Influences:** Water, Force, Weather  
**Attunement Slots:** 1 slot  
**Primary Construction:** Abyssal pearl, deepsea cold iron, and ocean-dragon jade

The pearl has 7 charges and regains `1d6 + 1` expended charges when you complete a Long Rest.

**Still the Waters.** As an Action, expend 3 charges and choose a point on a body of water within 300 feet. For up to 10 minutes, requiring Concentration, natural waves, currents, whirlpools, and undertows are suppressed in a 1-mile-radius area centered on that point.

Within the affected area:

- ordinary water becomes calm;
- vessels have Advantage on checks made to remain upright or navigate;
- creatures cannot be moved by natural currents;
- a hostile magical water effect of Sovereign grade or lower is suppressed if its creator fails an ability check against your item save DC.

The pearl cannot drain a sea, create land, or suppress an Imperial or Immortal ocean effect.

---

## 152. Storm-Gathering Banner
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Regional Weather  
**Sphere Influences:** Weather, Lightning, Air  
**Attunement Slots:** 1 slot  
**Primary Construction:** Tribulation silk, storm iron, and cloud-jade streamers

The banner requires 10 minutes to plant and has 7 charges, regaining `1d6 + 1` after a Long Rest.

**Gather Storm.** Expend 3 charges to create a storm in a 1-mile-radius area centered on the banner for up to 1 hour. Choose rain, snow, wind, or thunderstorm when activated.

The chosen weather is severe but natural in behavior. During a thunderstorm, once on each of your turns you can use a Bonus Action to expend 1 additional charge and call lightning at a point you can see within 300 feet. Creatures in a 10-foot-radius sphere make a Dexterity saving throw against your item save DC, taking `8d8` lightning damage on a failure or half on a success.

Moving or destroying the banner ends the storm. It cannot create weather impossible for the plane.

---

## 153. City-Veil Formation Core
*Wondrous Item, Sovereign Treasure*

**Treasure Family:** Settlement Concealment  
**Sphere Influences:** Formations, Illusion, Space  
**Attunement Slots:** None  
**Primary Construction:** Cloud-void crystal, mirror-sea silver, and formation jade

The core requires 7 days to install in a settlement no larger than 1 mile across.

While active, creatures outside the boundary cannot perceive the settlement from more than 300 feet away unless they know its location or succeed on a DC 17 Wisdom (Perception) or Intelligence (Investigation) check. Roads appear to continue around it, distant lights vanish, and ordinary maps fail to update automatically.

The veil does not make creatures inside Invisible, prevent physical entry, or conceal activity occurring outside the boundary.

Authorized tokens permit normal perception. A Sovereign or stronger divination effect can contest the veil using its normal check against DC 17. The core consumes 1 High-Grade Spirit Stone each month.

---

## 154. Sect-Guardian Stone Lion Pair
*Wondrous Item, Sovereign Treasure*

**Treasure Family:** Construct Guardians  
**Sphere Influences:** Guardian, Spirit Companions, Earth  
**Attunement Slots:** None  
**Primary Construction:** Mountain-root jade, sovereign stone, and soul-silver eyes

The matched lions require 8 hours to install within 60 feet of one another.

While dormant, each statue has AC 20, 250 Hit Points, and Immunity to poison and psychic damage. When an unauthorized hostile creature enters the protected 300-foot-radius area, both awaken for up to 10 minutes.

Each lion is a Huge Construct with Speed 50 feet. On the installation's initiative count, each can move and make one melee item attack using `+11` to hit, Reach 10 feet, dealing `4d10 + 6` bludgeoning damage.

A creature hit must succeed on a DC 17 Strength saving throw or be knocked Prone.

The lions cannot leave the protected area. If destroyed, a lion requires materials worth 5 High-Grade Spirit Stones and 7 days to rebuild.

---

## 155. Thousand-Script Jade Library
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Knowledge Archive  
**Sphere Influences:** Ink, Sect Stewardship, Spirit  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ten thousand linked jade slips and a sovereign memory core

The library stores up to ten thousand books, manuals, maps, recordings, memories, or inscription patterns without changing size.

As an Action, state a query. The library presents every stored passage relevant to that query and identifies contradictions among stored sources without deciding which is correct.

A creature studying within 30 feet for at least 1 hour gains Advantage on one Intelligence check made before its next Long Rest concerning a subject represented in the archive.

Once per Long Rest, the attuned bearer can create a perfect nonmagical copy of one stored text of up to 1,000 pages.

The library does not grant a Sphere, Talent, Recorded Art, language, or prerequisite. Learning still uses the normal training rules.

---

## 156. Spirit-Vein Relocation Spade
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Geomantic Engineering  
**Sphere Influences:** Source, Earth, Formations  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dragon-pulse iron, source jade, and world-root wood

The spade can redirect a natural spirit vein during a 30-day project.

The project requires:

- a source and destination within 10 miles;
- a viable geomantic route;
- materials worth 20 High-Grade Spirit Stones;
- daily work by a creature proficient with an appropriate crafting or formation tool.

At completion, make an Intelligence check using the relevant tool against DC 20. On a success, the vein's primary flow is redirected to the destination without changing its total output. On a failure, the vein remains in place, half the materials are lost, and the region suffers unstable qi for 30 days.

The spade cannot create a vein, move an Imperial or world-root vein, or steal a vein through a stronger active formation.

---

## 157. World-Tree Sapling Urn
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Sacred Cultivation Garden  
**Sphere Influences:** Verdant Growth, Life, World  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-tree rootwood, living jade, and sovereign spirit soil

The urn grows a sapling that creates a 300-foot-radius fertile sanctuary while planted in natural soil.

Within the sanctuary:

- ordinary plants grow at eight times their normal rate;
- Spiritual and Saint-grade plants grow at four times their normal rate;
- Sovereign-grade plants can survive when supplied with appropriate conditions;
- creatures completing a Long Rest gain Temporary Hit Points equal to twice their Proficiency Bonus;
- ordinary blight, drought, frost, and vermin do not harm cultivated plants.

The sapling can be uprooted during an 8-hour ritual and returns to urn form. If destroyed, it becomes dormant for one year unless restored by an Imperial life effect.

---

## 158. Phoenix-Nest Rebirth Brazier
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Death Prevention and Recovery  
**Sphere Influences:** Fire, Life, Renewal  
**Attunement Slots:** 1 slot  
**Primary Construction:** Phoenix-blood metal, rebirth ash, and sun-gold inscriptions

The brazier must remain lit with incense and fuel worth 1 High-Grade Spirit Stone per week.

When a willing creature registered to the brazier dies within 1 mile, its body and carried non-artifact equipment are transported into the brazier's chamber if dimensional travel is not blocked.

For the next 24 hours, the creature can be restored to life by an 8-hour ritual consuming materials worth 10 High-Grade Spirit Stones. The creature returns with 1 Hit Point and 3 levels of Exhaustion.

The brazier can register up to twelve creatures and restore one creature per month. It cannot restore a soul that is unwilling, destroyed, imprisoned elsewhere, or already reincarnated.

---

## 159. Bloodline-Ancestral Gate Mirror
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Lineage Gate  
**Sphere Influences:** Blood, Mirror, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Blood jade, mirror-sea silver, and ancestral gate inscriptions

The mirror can store the verified blood signatures of up to one hundred willing creatures.

During a 1-hour ritual, link it to one fixed mirror or ancestral gate on the same plane within 1,000 miles. A registered creature can use an Action to pass through and emerge from the linked gate.

The gate transports up to twenty creatures or 5,000 pounds of unattended cargo between Long Rests.

An unregistered creature can pass only while holding the hand of a registered creature that willingly escorts it. A sealed boundary or stronger Space effect can block transit.

The mirror verifies blood relationship but does not determine legitimacy, inheritance rights, or moral worth.

---

## 160. Ninefold Tribulation Shelter
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Calamity Protection  
**Sphere Influences:** Tribulation, Protection, Formations  
**Attunement Slots:** 1 slot  
**Primary Construction:** Tribulation steel, nine-layer formation jade, and stormglass

As a 1-hour ritual, expand the shelter into a 60-foot-radius domed pavilion lasting up to 24 hours.

The shelter has AC 21, 500 Hit Points, and Resistance to all damage. Creatures and objects inside have Total Cover from effects originating outside.

Whenever the shelter takes acid, cold, fire, force, lightning, radiant, necrotic, or thunder damage, it adapts. After taking a damage type, it gains Immunity to that type until the end of the next round.

The shelter can withstand one breakthrough or natural tribulation at a time. It does not weaken the tribulation's requirements, grant success, or protect a creature that leaves the dome.

Once collapsed or destroyed, it cannot be used again for 30 days.

---

## 161. Starfall Ore Refinement Crucible
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Ore Refinement  
**Sphere Influences:** Metal, Stars, Blacksmith  
**Attunement Slots:** 1 slot  
**Primary Construction:** Star iron, sovereign furnace jade, and gravity inscriptions

The crucible refines up to 1,000 pounds of ore during a 24-hour process.

Choose one operation:

- remove mundane impurities;
- separate mixed metals;
- condense trace spiritual metal;
- stabilize meteorite or star-metal;
- reduce raw ore to one-quarter its weight without losing useful material.

You gain a +3 bonus to Blacksmith or material-refinement checks made with the crucible.

Once per Long Rest, the crucible can convert materials worth 10 High-Grade Spirit Stones into one compatible Sovereign-grade metal component worth the same amount, provided at least one genuine sample of that metal is included.

It cannot create Imperial or Immortal material.

---

## 162. Ghost-Court Judgment Seal
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Spirit Adjudication  
**Sphere Influences:** Death, Karma, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ghost-court jade, black-gold law script, and funeral bronze

The seal has 7 charges and regains `1d6 + 1` after a Long Rest.

As an Action, expend 2 charges and choose one visible Undead, spirit, possessing entity, or soul-bound creature within 60 feet. It makes a Charisma saving throw against your item save DC.

On a failed save, spectral court chains bind it for 1 minute, requiring Concentration. While bound, it cannot become Invisible, possess a creature, travel between planes, or knowingly speak a lie.

At the end of each of its turns, it repeats the save.

During the binding, you can ask up to three questions. The seal compels audible answers but does not compel completeness or knowledge the creature lacks.

A creature that succeeds on the initial save is immune until your next Long Rest.

---

## 163. Thousand-Li Pursuit Compass
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Long-Range Tracking  
**Sphere Influences:** Predator, Blood, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Blood jade, star silver, and a void-pointing needle

During a 10-minute ritual, place a physical trace from a creature on the compass. The trace must be no more than 30 days old.

For 7 days, while the creature remains on the same plane and within 1,000 miles, the compass displays its direction, straight-line distance, and whether it is moving.

A willing creature can instead register itself by touching the compass, requiring no physical trace.

A Sovereign or stronger concealment effect can block the reading. The compass cannot cross planar boundaries, identify disguises, or track a creature whose body and soul have both been fundamentally transformed.

The compass can track one creature at a time.

---

## 164. Forgotten-Age Ash Urn
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Historical Memory  
**Sphere Influences:** Ash, Time, Spirit  
**Attunement Slots:** 1 slot  
**Primary Construction:** Ancient ash, memory jade, and sealed bronze

The urn contains ash that records traces left by destruction.

Once per Long Rest, scatter a pinch over a ruined object, burned structure, battlefield, grave, or destroyed Formation Anchor and spend 10 minutes observing.

You witness a silent, translucent reconstruction of one significant event that occurred at that location within the previous 1,000 years, lasting no more than 10 minutes.

The urn selects the event most strongly associated with destruction, death, betrayal, or final use. The vision is a residual impression, not time travel, and can omit concealed details or subjective information.

An Imperial concealment or deliberate historical erasure can block the vision.

---

## 165. Heaven-Thread Fate Loom
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Fate Preparation  
**Sphere Influences:** Fate, Thread, Ink  
**Attunement Slots:** 1 slot  
**Primary Construction:** Heaven silk, karma-red thread, and starwood frame

During a Long Rest, up to six willing creatures can each contribute one personal thread, hair, signature, or drop of blood.

The loom creates three **Fate Threads**, each represented by a `d12`. The threads last until the next Long Rest.

When a contributing creature within 120 feet makes an attack roll, saving throw, or ability check, the attuned bearer can use a Reaction and expend one Fate Thread to add its die after the roll but before the outcome is declared.

Alternatively, when such a creature is hit, expend one Fate Thread to subtract its die from the attack roll.

Unused Fate Threads vanish. The loom cannot guarantee prophecy, restore a spent thread, or affect an Immortal decree.

---

## 166. Voidfold Merchant Pavilion
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Portable Market  
**Sphere Influences:** Space, Sect Stewardship, Protection  
**Attunement Slots:** 1 slot  
**Primary Construction:** Voidfold wood, merchant jade, and city-silk awnings

As a 1-hour ritual, expand the token into a 100-foot-square market pavilion.

It contains twenty secure stalls, six private negotiation rooms, storage for 100,000 pounds of goods, and a central ledger chamber.

Goods stored in a locked stall cannot be removed without its assigned token unless a creature succeeds on a DC 20 Intelligence (Arcana) check during a 10-minute procedure.

The pavilion records every declared sale, deposit, withdrawal, and transfer but cannot detect unreported deception.

It can remain expanded indefinitely while supplied with 1 High-Grade Spirit Stone per month. It collapses only while empty of creatures, retaining stored goods in extradimensional storage.

---

## 167. Sun-and-Moon Timekeeping Wheel
*Wondrous Item, Sovereign Treasure*

**Treasure Family:** Time and Calendar  
**Sphere Influences:** Sun, Moon, Stars  
**Attunement Slots:** None  
**Primary Construction:** Sun gold, moon silver, and a sovereign star crystal

The wheel displays exact local time, date, season, lunar phase, solar position, and the rate at which time is passing relative to the plane where it was created.

Within 300 feet, it prevents ordinary clocks, calendars, and natural cycles from being falsified by a Sovereign-grade or weaker illusion.

Once per Long Rest, perform a 10-minute reading to learn whether a creature, object, or location within 30 feet is currently affected by accelerated, slowed, suspended, repeated, or displaced time.

The wheel does not alter time, reveal the future, or measure an Immortal time effect precisely.

---

## 168. Dragon-Pulse Surveying Pillar
*Wondrous Item, Sovereign Treasure*

**Treasure Family:** Regional Geomancy  
**Sphere Influences:** Source, Earth, Dragon  
**Attunement Slots:** None  
**Primary Construction:** Dragon-pattern stone, source jade, and sovereign bronze

The pillar requires 24 hours to install and surveys a 100-mile-radius region.

It continuously maps major spirit veins, dragon pulses, groundwater, mineral concentrations, seismic stress, corrupted zones, Formation Anchors, and artificial diversions.

Authorized creatures can study the map for 10 minutes to gain Advantage on one check made within 24 hours to navigate, build, cultivate, place a Formation, locate a vein, or predict a natural disaster in the surveyed region.

The pillar cannot reveal a deliberately concealed Imperial site, living creature, exact treasure, or safe path through a ward.

---

## 169. Nascent Soul Preservation Casket
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Soul and Body Preservation  
**Sphere Influences:** Soul, Death, Ice  
**Attunement Slots:** 1 slot  
**Primary Construction:** Soul jade, deepsea cold iron, and nine preservation seals

The casket can hold one willing creature, corpse, disembodied soul, or Nascent Soul-equivalent entity.

While sealed:

- the occupant does not age, breathe, eat, drink, or decay;
- poisons, diseases, curses, and ongoing conditions are suspended;
- the occupant is Unconscious but can choose to communicate telepathically with the attuned bearer within 30 feet;
- Sovereign-grade or weaker effects cannot locate, possess, consume, or transform the occupant.

Time passes normally outside, and the occupant gains no rest or recovery.

The casket can remain sealed indefinitely. Opening it requires an Action by the bearer or a DC 21 Intelligence (Arcana) check during a 1-hour ritual.

---

## 170. Emperor's Mandate Relay Seal
*Wondrous Item, Sovereign Treasure, Requires Attunement*

**Treasure Family:** Authority Transmission  
**Sphere Influences:** Warleader, Ink, Sect Stewardship  
**Attunement Slots:** 1 slot  
**Primary Construction:** Imperial-style jade, sovereign gold, and voice-memory crystal

During an 8-hour rite, one recognized ruler, sect master, or authorized office records a mandate of no more than 1,000 words and names up to one hundred relay seals.

A bearer can use an Action to transmit the mandate to every linked seal on the same plane within 10,000 miles. Each seal reproduces the issuer's image, voice, date, and authentication mark for up to 10 minutes.

A linked seal can return one response of no more than 250 words within 1 hour.

The seal verifies that the message came from the recorded office. It does not compel obedience, prove the mandate is lawful, or grant authority to an unauthorized bearer.

---

# Imperial Treasures 171–190

## 171. Cauldron of Ten Thousand Burdens
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Mass Refinement and Gravity  
**Sphere Influences:** Gravity, Alchemy, Blacksmith  
**Attunement Slots:** 1 slot  
**Primary Construction:** Dragon-patterned abyssal gold, mother-weight essence, and furnace jade

The cauldron can refine up to 100,000 pounds of material during a 7-day process.

Within its chamber, effective weight can be set from one-hundredth to one hundred times normal. This permits pressure forging, density separation, compression, stabilization, and controlled burden training.

You gain a +4 bonus to Alchemy, Blacksmith, and material-refinement checks made with the cauldron.

Once per month, it can condense compatible Sovereign-grade materials worth 10 Perfect Spirit Stones into one Imperial-grade component of equal value, provided the correct Imperial catalyst and formula are supplied.

The cauldron cannot create Immortal matter, grant a cultivation Realm, or safely refine a living creature without a specific procedure.

---

## 172. Heaven-Veil Imperial Mantle
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Imperial Concealment and Defense  
**Sphere Influences:** Space, Illusion, Protection  
**Attunement Slots:** 1 slot  
**Primary Construction:** Cloud-void silk, heaven-mark violet gold, and mirror mist

While wearing the mantle, you have Resistance to force and psychic damage.

You can become Invisible as a Bonus Action. The invisibility lasts until you dismiss it, attack, deal damage, force a saving throw, or spend CP. You can use this property repeatedly.

The mantle has 5 Veil charges and regains `1d4 + 1` after a Long Rest.

When you are targeted by an attack or hostile effect, use your Reaction and expend 1 charge to teleport up to 60 feet to an unoccupied space you can see. If the new position is no longer a legal target, the triggering effect fails against you.

An Imperial or Immortal effect that seals space can prevent the teleportation.

---

## 173. Sect-Guardian Heaven Bell
*Wondrous Item, Imperial Treasure*

**Treasure Family:** Sect-Scale Guardian  
**Sphere Influences:** Sound, Formations, Protection  
**Attunement Slots:** None  
**Primary Construction:** Heaven bronze, Imperial storm jade, and a spirit-vein clapper

The bell requires 30 days to install and protects a 10-mile-radius sect domain.

It detects hostile armies, Imperial-grade power activations, planar breaches, major Formation damage, and registered members reduced to 0 Hit Points within the domain.

The bell can maintain three continuous domain blessings chosen during installation:

- Advantage on saving throws against Charmed and Frightened;
- resistance to ordinary extreme weather;
- authorized creatures cannot be surprised while conscious;
- hostile teleportation requires a DC 19 Charisma saving throw;
- linked Formation Anchors gain 100 Temporary Hit Points at dawn.

Once per month, the bell can release a Heaven Peal. Hostile creatures chosen by the bell's authorized keeper within 1 mile make a DC 19 Constitution saving throw, taking `20d8` thunder damage and becoming Stunned for 1 minute on a failure, repeating the save at the end of each turn. On success, they take half damage.

---

## 174. Nine-Heavens Star-Road Altar
*Wondrous Item, Imperial Treasure*

**Treasure Family:** Intercontinental Transit  
**Sphere Influences:** Stars, Space, Formations  
**Attunement Slots:** None  
**Primary Construction:** Nine star-stone rings, Imperial silver, and celestial coordinates

The altar requires 30 days to install and can link to up to eight other attuned Star-Road Altars on the same plane.

Once per day, after a 10-minute activation, it opens a stable gate between two linked altars for 1 hour.

The gate can transport creatures, vehicles, and cargo through an opening 30 feet wide and 30 feet high. Up to 10,000 creatures or 1,000,000 pounds of cargo can pass during one activation.

The gate cannot cross planes, open into a moving altar, or function while either destination is under an Imperial spatial seal.

Activating the altar consumes 1 Perfect Spirit Stone.

---

## 175. Five-Emperors World-Refining Furnace
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Imperial Refinement  
**Sphere Influences:** Five-Phase, Alchemy, Blacksmith  
**Attunement Slots:** 1 slot  
**Primary Construction:** Five Imperial divine metals and a world-furnace core

The furnace can craft, repair, combine, or purify treasures up to Imperial grade.

It maintains five independent phase chambers—Fire, Water, Earth, Metal, and Wood—and can process five linked projects simultaneously.

You gain a +4 bonus to relevant crafting checks.

Once per month, choose one Imperial refinement privilege:

- reduce one project's time by 50 percent;
- preserve all materials after a failed check;
- remove one Sovereign-grade curse or corruption automatically;
- merge two compatible Sovereign Treasures into one Imperial Treasure using a legal formula;
- raise one Sovereign material's normal ceiling to Imperial for that project.

It cannot craft an Immortal Artifact without an Immortal formula, material, facility, and story condition.

---

## 176. Dragon-Vein Mountain Gate Seal
*Wondrous Item, Imperial Treasure*

**Treasure Family:** Domain Boundary  
**Sphere Influences:** Earth, Source, Sealing  
**Attunement Slots:** None  
**Primary Construction:** Dragon-vein jade, Imperial mountain stone, and gate gold

The seal requires 30 days to integrate with a mountain, city wall, sect valley, or fortress boundary no larger than 20 miles across.

While active:

- hostile teleportation and planar travel across the boundary fail unless the creature succeeds on a DC 19 Charisma saving throw;
- unauthorized underground movement is slowed to one-quarter normal speed;
- tunneling and earth-shaping effects of Sovereign grade or lower fail;
- the keeper knows when a Gargantuan creature, army, or Imperial effect crosses the boundary;
- linked gates can open or close as an Action by authorized seals.

The seal consumes the output of one major spirit vein or 1 Perfect Spirit Stone per month.

---

## 177. Phoenix Rebirth Palace Seed
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Restoration Palace  
**Sphere Influences:** Fire, Life, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Phoenix-blood scarlet gold, palace seedwood, and rebirth flame

As a 24-hour ritual, expand the seed into a 500-foot-square palace containing recovery chambers for one hundred creatures.

A creature completing a Long Rest inside removes two additional levels of Exhaustion and can repeat one saving throw against every poison, disease, curse, or spiritual injury that permits repeated saves.

Once per month, the palace can restore one willing creature that died within the previous 30 days. The rite requires its body or at least half its remains, its willing soul, 24 hours, and materials worth 10 Perfect Spirit Stones.

The creature returns with full Hit Points, 4 levels of Exhaustion, and no expended Path resources.

The palace cannot restore a destroyed soul, an Immortal being, or a creature whose death is enforced by a stronger mandate.

---

## 178. Ocean-Subduing Sovereign Pearl
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Ocean Dominion  
**Sphere Influences:** Water, Gravity, Authority  
**Attunement Slots:** 1 slot  
**Primary Construction:** Sea-sovereign pearl, abyssal gold, and dragon-pressure crystal

While carrying the pearl, you can breathe water, gain a Swim Speed of 120 feet, and are immune to ordinary water pressure and forced movement caused by water.

The pearl has 9 charges and regains `1d8 + 1` after a Long Rest.

**Subdue the Ocean.** As an Action, expend 5 charges to control water in a 10-mile-radius area for up to 1 hour, requiring Concentration. You can calm or raise waves, redirect currents, open a dry passage up to 300 feet wide, lower or raise local water level by up to 100 feet, or restrain one water-based Imperial effect using an opposed ability check.

The effect cannot drain an ocean, flood an entire continent, or override an Immortal water law.

---

## 179. Ten-Thousand Spirit Bestiary Pavilion
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Creature Sanctuary and Archive  
**Sphere Influences:** Spirit Companions, Beastmastery, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-beast jade, pavilion seedwood, and soul-safe enclosures

The pavilion contains ten thousand adaptive habitats within a stable extradimensional domain.

It can house up to:

- 1,000 willing Tiny or Small creatures;
- 500 Medium creatures;
- 200 Large creatures;
- 50 Huge creatures;
- 10 Gargantuan creatures.

Occupants receive breathable air, water, ordinary food, climate, shelter, and space appropriate to their nature. They can complete rests normally.

The pavilion records each occupant's observed traits, diet, behavior, injuries, lineage, and known abilities.

It cannot imprison an unwilling creature, manufacture rare ingredients, force reproduction, grant permanent evolution, or contain an Immortal creature without its consent.

---

## 180. Imperial Ancestor Court
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Ancestral Domain  
**Sphere Influences:** Spirit Companions, Warleader, Karma  
**Attunement Slots:** 1 slot  
**Primary Construction:** Imperial ancestor jade, court gold, and a hundred true-name tablets

The court can preserve the willing memory-presences of up to one hundred deceased ancestors, teachers, rulers, or lineage guardians.

Once per Long Rest, manifest the court in a 120-foot-radius area for 1 hour. The court can answer questions from its collective knowledge and grants all authorized allies in the area:

- Advantage on Intelligence and Wisdom saving throws;
- +2 to attack rolls and saving throws;
- immunity to being Frightened;
- Temporary Hit Points equal to five times their Proficiency Bonus when the court appears.

Once during the manifestation, the bearer can request **Ancestral Intercession**, causing every authorized ally in the area to regain `8d8` Hit Points.

The court cannot reveal knowledge none of its members possessed or bind an unwilling soul.

---

## 181. Heaven-Observing Mirror Tower
*Wondrous Item, Imperial Treasure*

**Treasure Family:** Regional Observation  
**Sphere Influences:** Mirror, Stars, The Hidden Eye  
**Attunement Slots:** None  
**Primary Construction:** Imperial mirror glass, heaven crystal, and a 300-foot tower

The tower surveys a 1,000-mile-radius region on the same plane.

Authorized observers can use its central mirror to view a known outdoor location within range for up to 1 hour, requiring Concentration. The view includes sight, sound, weather, and visible supernatural effects.

The tower continuously detects:

- Imperial power activations;
- planar breaches;
- armies larger than 1,000 creatures;
- major storms, earthquakes, eruptions, and celestial events;
- destruction of linked Formation Anchors.

Imperial concealment can contest observation with an ability check against DC 19. Immortal concealment blocks it automatically unless the effect says otherwise.

---

## 182. Karma-Judgment Golden Scale
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Karmic Judgment  
**Sphere Influences:** Karma, Fate, Authority  
**Attunement Slots:** 1 slot  
**Primary Construction:** Karma gold, black-white jade, and judgment inscriptions

The scale has 9 charges and regains `1d8 + 1` after a Long Rest.

During a 10-minute hearing, place a willing creature's token, name, or blood on the scale and state one specific act, debt, oath, or harm.

The scale reveals:

- whether the creature sincerely accepts responsibility;
- whether the represented obligation remains materially unresolved;
- the broad magnitude of the unresolved consequence;
- whether another named party knowingly falsified the claim.

An unwilling creature can resist with a Charisma saving throw against your item save DC.

**Judgment.** Expend 5 charges to impose a 30-day karmic mark on a creature that failed the save. Whenever it knowingly repeats the judged act, it takes `10d10` psychic damage and the mark becomes visible. The scale cannot define morality, punish ambiguous conduct, or override an Immortal mandate.

---

## 183. World-Root Transplantation Spade
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Ecological and Geomantic Transplantation  
**Sphere Influences:** Verdant Growth, Source, Earth  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-root wood, Imperial earth gold, and living source jade

The spade can relocate one major tree, sacred grove, spirit spring, mineral garden, or regional plant ecosystem during a 30-day project.

The source and destination must be on the same plane and within 1,000 miles. The project requires:

- a viable destination;
- materials worth 20 Perfect Spirit Stones;
- daily work by at least ten trained assistants;
- an Intelligence check using appropriate tools against DC 22.

On a success, the transplanted site retains its health, ordinary inhabitants, spiritual output, and local properties. On a failure, no relocation occurs, half the materials are lost, and both sites require 30 days to stabilize.

The spade cannot move a world tree, continental vein, city, or unwilling intelligent ecosystem.

---

## 184. Void-Crossing Jade Ark
*Vehicle, Imperial Treasure, Requires Attunement*

**Treasure Family:** Planar Transport  
**Sphere Influences:** Space, Vehicles, Protection  
**Attunement Slots:** 1 slot  
**Primary Construction:** Origin-void copper, Imperial jade, and a world-sail

The ark can carry 1,000 Medium creatures and 1,000,000 pounds of cargo. It has AC 23, 2,000 Hit Points, a Fly Speed of 200 feet, and environmental protection for all occupants.

After a 1-hour navigation ritual, it can cross to another known plane or demiplane. The crossing takes 1d6 hours and consumes 1 Perfect Spirit Stone.

During transit, the ark exists in a protected void corridor. Occupants cannot leave, attack outside, or complete a Long Rest unless the journey lasts at least 8 hours.

A sealed plane, inaccurate destination, or Immortal boundary can prevent arrival. On failure, the ark returns to its point of departure without consuming the stone.

If destroyed in transit, it automatically attempts an emergency return before breaking apart.

---

## 185. Thousand-Dream Palace Lantern
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Dream Domain  
**Sphere Influences:** Dreams, Spirit, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Imperial dream crystal, moon gold, and a palace flame

The lantern can create a shared dream palace for up to one thousand willing sleeping creatures within 10 miles.

One real hour equals up to eight subjective hours in the palace. Participants can converse, exchange voluntarily presented memories, rehearse known techniques, conduct councils, and create harmless symbolic environments.

Participants cannot gain training days, AP, permanent abilities, physical items, Hit Points, or Path resources from subjective time.

The bearer can exclude or awaken any participant as an Action.

Once per Long Rest, the palace can trap one hostile dream intruder that fails a Charisma saving throw against your item save DC. The intruder is expelled and cannot enter the dreams of registered participants for 30 days.

---

## 186. Celestial Formation Command Board
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Formation Network Control  
**Sphere Influences:** Formations, Strategy, Stars  
**Attunement Slots:** 1 slot  
**Primary Construction:** Heaven-mark violet gold, star jade, and ten thousand command pins

The board can link to up to one hundred Formation Anchors within 100 miles.

The attuned bearer knows each linked anchor's location, condition, power reserve, active mode, and current breach status.

As an Action, the bearer can activate, deactivate, redirect, or change one authorized linked formation mode from any distance within the network.

The board has 9 Command charges and regains `1d8 + 1` after a Long Rest. Expend:

- **1 charge:** transfer up to 5 charges or equivalent power between linked anchors;
- **2 charges:** grant one linked anchor 200 Temporary Hit Points;
- **3 charges:** cause one formation effect to originate from a different linked anchor for 1 round;
- **5 charges:** maintain one linked formation for 1 minute without its normal Concentration requirement.

The board cannot seize an unauthorized formation or override an Immortal core.

---

## 187. Nine-Sun Calamity Shelter
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Imperial Calamity Defense  
**Sphere Influences:** Sun, Protection, Tribulation  
**Attunement Slots:** 1 slot  
**Primary Construction:** Nine sun-gold layers, calamity crystal, and phoenix-blood metal

As a 1-hour ritual, expand the shelter into a 300-foot-radius dome lasting 24 hours.

The dome has AC 23, 2,000 Hit Points, Resistance to all damage, and nine Sun Layers. When the dome would be reduced to 0 Hit Points, one Sun Layer is destroyed and the dome returns to 500 Hit Points.

Creatures inside have Total Cover from outside effects and Resistance to all damage caused by a breakthrough, tribulation, natural disaster, or siege effect.

Each destroyed Sun Layer reforms after 30 days and materials worth 1 Perfect Spirit Stone.

The shelter does not reduce a breakthrough's difficulty, grant success, or protect creatures outside the dome.

---

## 188. Moon-Palace Preservation Coffin
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Perfect Preservation  
**Sphere Influences:** Moon, Ice, Soul  
**Attunement Slots:** 1 slot  
**Primary Construction:** Moon-palace jade, Imperial cold silver, and soul-preservation crystal

The coffin can hold one willing creature, corpse, soul, Nascent Soul, or comparable spiritual body.

While sealed:

- time does not pass for the occupant;
- aging, decay, conditions, curses, poison, disease, and resource loss are suspended;
- the occupant cannot be located, possessed, transformed, consumed, or contacted by an Imperial-grade or weaker effect;
- the body and soul remain mutually anchored;
- resurrection or restoration effects treat all preserved components as present.

The occupant gains no rest, healing, training, or subjective experience.

Opening the coffin requires the attuned bearer, the occupant's consent if conscious, or a successful DC 25 Intelligence (Arcana) check during an 8-hour ritual.

---

## 189. Imperial Medicine King's Cabinet
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Grand Medicine Archive and Clinic  
**Sphere Influences:** Medicine, Alchemy, Life  
**Attunement Slots:** 1 slot  
**Primary Construction:** Immortal-tear verdant gold, medicine king wood, and one thousand jade drawers

The cabinet stores up to one thousand medicine doses, pills, ingredients, samples, and healer's tools without spoilage.

It has 20 Medicine charges and regains `2d8 + 4` when restocked during a Long Rest with supplies worth 1 Perfect Spirit Stone.

As an Action, expend:

- **1 charge:** restore `5d8 + 10` Hit Points;
- **2 charges:** end one poison or disease of Imperial grade or lower;
- **3 charges:** end one Charmed, Frightened, Paralyzed, or Stunned condition;
- **5 charges:** remove one level of Exhaustion;
- **10 charges:** restore one creature dead for no more than 1 minute to life with 1 Hit Point, provided its soul is willing and present.

A creature can lose only one level of Exhaustion to the cabinet per Long Rest. It cannot restore a destroyed soul or reverse an Immortal affliction.

---

## 190. Heaven-Mandate Transmission Seal
*Wondrous Item, Imperial Treasure, Requires Attunement*

**Treasure Family:** Imperial Authority Network  
**Sphere Influences:** Authority, Ink, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** Heaven-mark gold, mandate jade, and world-spanning voice crystal

The seal can link to up to ten thousand authorized relay seals on the same plane.

As an Action, transmit a message of up to 10,000 words, a visible image, a map, an authenticated order, or a 10-minute speech to every linked seal. Delivery is immediate anywhere on the plane unless blocked by an Immortal boundary.

The seal verifies the sender's identity, office, date, and unaltered content.

Once per Long Rest, the bearer can open a 1-hour council link among up to one hundred linked seals, allowing simultaneous sight and sound.

The seal does not compel obedience, create legitimate authority, alter law, or authenticate a bearer not recognized by the network's installation rite.

---

# Immortal Artifacts 191–200

## 191. World-Seed Ring
*Ring, Immortal Artifact, Requires Attunement*

**Treasure Family:** Evolving Cultivation World  
**Sphere Influences:** World, Verdant Growth, Space  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-heart crystal, origin soil, and an Immortal seed

The ring contains an evolving plant-cultivation world. Its size and safe cultivation ceiling depend on the attuned bearer's Cultivation Level.

| Cultivation Level | Interior | Cultivation Plots | Plant Growth | Safe Plant Grade |
|---|---|---:|---:|---|
| 1–4 | 20-foot square | 4 | ×2 | Spiritual |
| 5–9 | 60-foot square | 8 | ×4 | Spiritual |
| 10–14 | 300-foot diameter | 16 | ×8 | Saint |
| 15–19 | 1-mile diameter | 32 | ×16 | Sovereign |
| 20+ | 5-mile diameter | 64 | ×32 | Imperial |

The bearer and willing assistants can enter during a 10-minute ritual performed outside initiative and immediate danger. Time passes normally.

The interior provides soil, water, climate control, and ordinary sunlight. It does not create seeds, rare nutrients, labor, or harvested materials.

No creature can complete a Short or Long Rest inside, use it as combat refuge, or gain training time from its growth rate. If danger begins outside, entrants are expelled safely at the end of the current round.

Immortal plants require a unique seed, procedure, catalyst, environment, and story awakening.

---

## 192. Celestial Crossing Bronze Ark
*Vehicle, Immortal Artifact, Requires Attunement*

**Treasure Family:** World and Planar Travel  
**Sphere Influences:** Space, Stars, Vehicles  
**Attunement Slots:** 2 slots  
**Primary Construction:** Origin-void bronze, world-sail silk, and celestial crossing runes

The ark can carry 10,000 creatures and 100,000,000 pounds of cargo. It has AC 25, 10,000 Hit Points, Immunity to non-Immortal damage while in transit, and self-contained air, food-production gardens, water, climate, and gravity.

It can travel through ordinary space at 10,000 miles per hour or cross between known planes, demiplanes, moons, and worlds.

A planar or world crossing requires a 1-hour navigation rite and consumes one unique destination coordinate, beacon, or verified path. Travel takes from 1 hour to 30 days depending on distance and cosmology.

The ark cannot enter a world sealed by an equal or stronger Immortal authority, cross an unknown void safely without exploration, or guarantee arrival through a destroyed route.

If reduced to 0 Hit Points, it performs an emergency return to the nearest previously visited safe harbor before becoming dormant for one year.

---

## 193. Heaven-Sealing Mandate Fragment
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Law Sealing  
**Sphere Influences:** Dao, Sealing, Authority  
**Attunement Slots:** 2 slots  
**Primary Construction:** A fragment of an Immortal heavenly mandate inscribed on origin jade

The fragment can seal one defined supernatural principle within a 1-mile-radius area.

As a 1-hour rite, choose one of the following categories:

- teleportation and planar travel;
- resurrection and soul recall;
- weather manipulation;
- summoned creatures;
- divination;
- dream travel;
- one named Sphere family;
- one named treasure or Formation network.

For 24 hours, non-Immortal effects in the area belonging to the chosen category fail automatically. Immortal effects require their creator to succeed on an opposed ability check against your item save DC.

The seal does not remove permanent abilities, destroy existing creatures, suppress mundane actions, erase a Sphere from a character, or alter the laws of an entire plane.

After use, the fragment becomes dormant for 30 days.

---

## 194. Primordial Mother Qi Cauldron
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Origin Refinement and Creation  
**Sphere Influences:** Origin, Alchemy, Blacksmith  
**Attunement Slots:** 2 slots  
**Primary Construction:** Primordial mother qi, Immortal divine metal, and a self-born furnace spirit

The cauldron can refine matter, energy, spirit essence, and compatible Dao marks without ordinary heat.

It supports crafting and repairing Immortal Artifacts when supplied with:

- an Immortal formula;
- required Immortal materials;
- a compatible facility or domain;
- all story conditions;
- the artifact's intended Dao principle.

The cauldron grants a +5 bonus to relevant crafting checks and preserves all materials when a check fails.

Once per year, it can perform one **Origin Reversion**: reduce a destroyed or corrupted non-Immortal treasure to purified recoverable materials worth its full original special-component cost.

Once per century, it can awaken one compatible Sovereign or Imperial treasure as an Immortal Artifact candidate. The candidate gains no automatic powers; its final properties require a complete design, awakening trial, and audit.

The cauldron cannot create life, souls, cultivation Realms, or Immortal material from nothing.

---

## 195. Ten-Thousand Worlds Compass
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Cosmic Navigation  
**Sphere Influences:** World, Space, Stars  
**Attunement Slots:** 1 slot  
**Primary Construction:** World-heart crystal, celestial gold, and a needle made from void direction

The compass can record an unlimited number of verified worlds, planes, demiplanes, celestial bodies, and stable routes.

As an Action, name a recorded destination. The compass displays:

- its direction through the current cosmology;
- the safest known route;
- expected travel time by available method;
- active seals, storms, collapsed passages, and major hazards;
- whether the destination still exists;
- the nearest known alternate route.

Once per Long Rest, the compass can open a 20-foot-wide gate to a recorded destination for 1 minute, provided no equal or stronger boundary blocks it. The gate transports up to one hundred creatures and 100,000 pounds.

The compass cannot locate an unknown world by name alone, override an Immortal seal, or guarantee safety beyond its last verified information.

---

## 196. Eternal Reincarnation Lamp
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Soul Continuity  
**Sphere Influences:** Death, Karma, Life  
**Attunement Slots:** 2 slots  
**Primary Construction:** Reincarnation flame, soul-origin jade, and an eternal name wick

Up to twelve willing creatures can register their true soul signatures with the lamp during an 8-hour rite.

When a registered creature dies anywhere on the same plane, its willing soul can enter the lamp unless blocked by an equal or stronger effect.

The lamp preserves the soul indefinitely and protects it from consumption, possession, transformation, and involuntary reincarnation.

Once per year, the lamp can restore one preserved creature to life by growing a compatible body during a 30-day rite consuming unique materials chosen by the GM. The creature returns at full Hit Points with all permanent identity, memories, and character choices intact, but with 5 levels of Exhaustion and no expended resources restored.

The lamp cannot restore a soul that chose to depart, was annihilated by an equal or stronger Immortal effect, or has already entered a new life willingly.

---

## 197. Dao-Source Enlightenment Tree Seed
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Comprehension Sanctuary  
**Sphere Influences:** Dao, Verdant Growth, Mind  
**Attunement Slots:** 1 slot  
**Primary Construction:** A seed from an Enlightenment Tree watered by origin source

Planting the seed during a 30-day rite creates an Enlightenment Tree and a 1-mile-radius sanctuary.

Within the sanctuary:

- creatures have Advantage on Intelligence and Wisdom saving throws;
- meditation, interpretation, and comprehension checks gain a +5 bonus;
- hostile dream intrusion and mind control of non-Immortal grade fail;
- a creature can accurately recall any text, lesson, or technique it studies beneath the tree during that day.

Once per year, the tree produces one Enlightenment Fruit. A creature eating it can immediately attempt one legal training, comprehension, or breakthrough-related check with Advantage and a `d12` bonus.

The fruit does not grant a Sphere, Talent, Insight, Recorded Art, Realm, or automatic breakthrough. All prerequisites, costs, teachers, manuals, time requirements, and failure consequences still apply.

---

## 198. Coffin of the Nine Heavens
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Transcendent Preservation and Passage  
**Sphere Influences:** Death, Space, Stars  
**Attunement Slots:** 2 slots  
**Primary Construction:** Nine-heavens divine wood, origin-void copper, and eternal preservation seals

The coffin can preserve one willing creature, corpse, soul, clone, Nascent Soul, or comparable spiritual existence.

While sealed:

- time does not pass for the occupant;
- no non-Immortal effect can locate, contact, alter, age, damage, possess, consume, resurrect, or reincarnate it;
- body, soul, memories, cultivation, equipment, and identity remain exactly as sealed;
- the coffin can survive vacuum, stellar fire, planar collapse, and world destruction.

Once per year, the coffin can travel to a recorded world, plane, or celestial location during a 9-day passage. The occupant remains preserved during transit.

The coffin is not a combat refuge. Entering or sealing it requires a 1-hour rite outside immediate danger.

An equal or stronger Immortal effect can contest its preservation or route.

---

## 199. Immortal Court Bell of Returning Names
*Wondrous Item, Immortal Artifact, Requires Attunement*

**Treasure Family:** Identity and Soul Restoration  
**Sphere Influences:** Sound, Spirit, Karma  
**Attunement Slots:** 2 slots  
**Primary Construction:** Immortal court bronze, true-name gold, and a soul-returning clapper

The bell can record the true names and willing soul signatures of any number of creatures during an 8-hour court rite.

Once per month, ring the bell and speak one recorded name. If that creature exists anywhere in the same cosmology, the bell reveals whether it is alive, dead, reincarnated, imprisoned, erased from ordinary records, or concealed by an equal or stronger authority.

Once per year, the bell can perform **Return the Name** on one willing creature within 120 feet. It restores memories, identity, language, personality, lineage recognition, and true-name integrity removed or corrupted by any non-Immortal effect.

If the creature is a preserved disembodied soul, the bell can call it into a compatible prepared body.

The bell cannot compel a soul to return, reverse voluntary reincarnation, or restore a soul annihilated by an equal or stronger Immortal effect.

---

## 200. World-Heart Formation Core
*Wondrous Item, Immortal Artifact*

**Treasure Family:** World Infrastructure  
**Sphere Influences:** World, Formations, Source  
**Attunement Slots:** None  
**Primary Construction:** World-heart crystal, origin-vein metal, and a self-sustaining formation spirit

The core can anchor one world-scale Formation network.

Installation requires one year, an appropriate planetary or planar site, unique Immortal materials, and a complete Formation design.

Once installed, choose up to five world functions appropriate to the campaign, such as:

- stabilize seasons, climate, or tides;
- distribute spirit-vein output;
- maintain a planetary teleportation network;
- protect against planar invasion;
- sustain breathable air, gravity, or temperature;
- seal one world-scale corruption;
- support continent-spanning communication;
- preserve the world's boundary during catastrophe.

Every function must have a defined area, activation rule, power source, authorized controller, counterplay, failure state, and maintenance procedure.

The core cannot create a world from nothing, grant universal immortality, erase free will, produce infinite resources, or override an equal or stronger world law.

If destroyed, the Formation enters a 30-day collapse sequence rather than failing instantly, allowing repair, evacuation, or controlled shutdown.

---

# Final Chunk Audit

All entries were checked for:

- exact master-index numbering and names;
- correct Sovereign, Imperial, and Immortal grade allocation;
- explicit item type and Attunement-slot use;
- defined installation, activation, area, duration, capacity, cost, Concentration, dormancy, and recovery rules;
- explicit consent for soul storage, reincarnation, residence, and identity restoration;
- explicit planar, world, and equal-rank limitations;
- no blanket once-per-turn restriction;
- no automatic Sphere, Talent, Method, Foundation, Insight, Realm, or breakthrough;
- no undefined infinite storage, resources, time acceleration, resurrection, or world creation;
- campaign-scale power without abandoning D&D 5.5e execution.


# Chapter 5: Consumable Treasures
*Core Rules and 90-Item Production Catalog v0.1*

Consumable Treasures are supernatural objects whose primary effect expends, destroys, empties, burns, dissolves, or permanently exhausts the object.

They remain separate from permanent Wondrous Treasures, weapons, armor, shields, and growth treasures.

This chapter covers:

- pills and elixirs;
- combat pellets;
- talismans and seals;
- incense;
- spirit wines and medicinal foods;
- poisons;
- formation consumables;
- single-use escape treasures;
- disposable ammunition and weapon coatings.

---

# Sphere Boundaries

## Alchemy

Alchemy refines existing ingredients into pills, elixirs, pellets, medicinal vapors, incense, spirit foods, poisons, antidotes, and related preparations.

Alchemy does not grow herbs, harvest beast cores, create ingredients from nothing, inscribe talismans, or construct true place-based formations.

## Talismans

Talismans store a defined written command in paper, silk, jade, bone, metal, cloth, skin-safe patches, or another inscribed medium.

A talisman can be affixed, thrown, torn, burned, activated by a Reaction, or installed as a seal when its formula says so.

Talismans do not replace open-ended Sphere use, general permanent item crafting, or Formation Pattern control.

## Formations

Formation Consumables command a place through a fixed Eye, Nodes, boundaries, or gates.

They are breakable spatial diagrams. Each entry defines setup, area, duration, Eye and Node statistics, collapse conditions, and whether it is a Combat or Prepared Array.

A Formation Consumable contains one fixed pattern. It does not grant the Formations sphere or allow its activator to redesign the array.

## Other Relevant Spheres

- **Poison** governs poison use, delivery, resistance, and specialized toxins.
- **Ink** supports written formulae, copying, analysis, and inscription.
- **Imbuement** supports stored energy and compatible item integration.
- **Harvesting Gathering** supplies ingredients but does not refine them.
- **Blacksmith, Weapons, and Piercing Needle** support ammunition, coatings, and delivery media.
- **Life and Medicine** support healing, antidotes, and recovery.
- **Space** supports escape treasures and transport formulae.

---

# Consumable Grades

| Tianxia Grade | D&D Compatibility | Minimum CL to Craft | Formula DC | Standard Time | Batch Material Cost | Suggested Batch Market Price | Fixed Save DC | Fixed Attack |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Spiritual Treasure | Uncommon | 1 | 15 | 4 hours | 1 Low-Grade Spirit Stone | 2 Low-Grade Spirit Stones | 13 | +5 |
| Saint Treasure | Rare | 5 | 18 | 1 workday | 5 Low-Grade Spirit Stones | 1 Mid-Grade Spirit Stone | 15 | +7 |
| Sovereign Treasure | Very Rare | 10 | 22 | 7 workdays | 5 Mid-Grade Spirit Stones | 1 High-Grade Spirit Stone | 17 | +9 |
| Imperial Treasure | Legendary | 15 | 26 | 30 workdays | 5 High-Grade Spirit Stones | 1 Perfect Spirit Stone | 19 | +11 |
| Immortal Artifact | Artifact | 20 and a special gate | 30+ | Special | Unique | No standard market | 21+ | +13 or bespoke |

The listed market prices are defaults for a lawful, adequately supplied market. Restricted formulas, monopolies, war, remote regions, superior quality, and rare ingredients can change price substantially.

## Mortal Preparations

Mundane medicines, food, ordinary incense, common poison, lamp oil, smoke pots, and nonmagical ammunition remain Mortal Items. They use ordinary equipment prices and do not use this chapter's supernatural grade table unless a formula says otherwise.

---

# Formula Access

A Formula grants permission to create one specific consumable.

Every Formula states:

- consumable family;
- grade;
- required tools;
- required Sphere or access permission, if restricted;
- material cost;
- batch yield;
- crafting time;
- activation;
- targets and area;
- attack or saving throw;
- duration;
- Saturating or Toxic tags;
- special facility or medium.

Owning a Formula does not create ingredients, grant tool proficiency, or waive a restricted sect, lineage, legal, or Realm requirement.

---

# Crafting Consumables

## Standard Production

When you know the Formula, meet its minimum CL, have the required tools, use the full standard time, pay all materials, and work in an appropriate facility, you create one Standard batch without a check.

This follows the general Tianxia crafting rule that complete routine production succeeds when every required element is present.

## Refinement Check

Make a Refinement Check when:

- rushing production;
- substituting an ingredient;
- working without the proper facility;
- crafting above the normal grade of your tools or Realm;
- attempting Refined quality;
- scaling beyond ordinary batch production;
- producing a forbidden, unstable, corrupted, or experimental Formula;
- repairing a Broken batch.

Use the Formula DC from the grade table.

A Refinement Check is normally:

> `d20 + Proficiency Bonus + relevant key ability modifier`

Use Intelligence for Alchemy, Talismans, Formations, and most technical formulae unless a Sphere, Path feature, Insight, or Formula explicitly changes the ability.

Before an Alchemy, Talisman, or Formation Refinement Check, a creator with the relevant Sphere can spend CP up to its Proficiency Bonus, adding +1 per CP.

## Refinement Results

| Result | Outcome |
|---|---|
| Success | Create the intended batch at Standard quality. |
| Success by 5+ | Create a Refined batch and choose one Refined Benefit. |
| Failure by 5 or less | Create a Broken batch with one flaw. |
| Failure by more than 5 | The batch fails and the materials are lost. |
| Natural 1 | The materials are lost, and the creator suffers formula backlash. |

### Refined Benefits

Choose one:

- increase the Formula's fixed save DC by 1;
- increase a fixed attack modifier by 1;
- add one die to one healing or damage roll;
- increase a duration by 50 percent;
- remove the Saturating tag from one dose in the batch;
- create one additional unit;
- remove one printed minor side effect.

A Refined Benefit cannot increase an Immortal effect, create a permanent duration, or remove a defining drawback.

### Broken Batch Flaws

Choose or roll:

1. Healing or damage is halved.
2. Duration is halved.
3. Save DC and attack modifier are reduced by 2.
4. The dose gains the Saturating tag or adds 1 extra Essence Impurity.
5. Activation requires an Action if it normally uses a Bonus Action or Reaction.
6. The consumer or activator takes `1d6` force, fire, poison, or psychic damage per grade step after activation.

A Broken batch is visibly flawed to a successful appraisal but need not appear obviously dangerous.

### Formula Backlash

On a natural 1, take:

| Grade | Backlash |
|---|---:|
| Spiritual | `1d6` |
| Saint | `2d6` |
| Sovereign | `4d6` |
| Imperial | `8d6` |
| Immortal | Special |

Choose fire, force, poison, psychic, radiant, or necrotic according to the Formula.

---

# Batch Production

## Standard Batch Yield

| Family | Standard Batch |
|---|---:|
| Pills and Elixirs | 4 doses |
| Combat Pellets | 4 pellets |
| Talismans and Seals | 4 talismans |
| Incense | 2 sticks or bundles |
| Spirit Wines and Medicinal Foods | 6 servings |
| Poisons | 3 doses |
| Formation Consumables | 1 complete kit |
| Single-Use Escape Treasures | 1 treasure |
| Disposable Ammunition | 5 pieces |
| Weapon Coatings | 3 applications |

An entry can override this yield.

## Expanded Batch

A creator with the relevant Sphere or a dedicated production facility can produce additional batches of one Formula simultaneously.

- Maximum batches: Proficiency Bonus.
- Pay materials for every batch.
- Increase total production time by 50 percent.
- Spend 1 CP per additional batch, or supply equivalent workshop power.
- Use one Refinement Check for the entire production run if a check is required.
- A failure affects every batch in the run.

This preserves the Alchemy and Talisman production identity without requiring a separate roll for every pill or slip.

---

# Activation and Readiness

## Activation

Use the Action, Bonus Action, Reaction, attack, setup rite, or longer procedure stated in the entry.

Activating a supernatural consumable is not automatically spellcasting. It is a treasure activation using the listed action type.

## Stored Statistics

A market consumable uses the fixed save DC and attack modifier for its grade.

A creator can store its own item save DC or item attack modifier only when the Formula permits it. A stored statistic cannot exceed the grade's fixed value by more than 2 unless the consumable is deliberately crafted at a higher grade.

## Readied Reaction Consumables

A Reaction consumable must be accessible and readied.

After a Short or Long Rest, a creature can ready a number of Reaction consumables equal to its Proficiency Bonus. Unreadied consumables cannot activate as Reactions.

Consuming a readied treasure frees that readied slot.

## Concentration

A consumable requiring Concentration states who concentrates. Unless specified otherwise, the activator concentrates.

## Attunement

Consumable Treasures normally do not require Attunement and do not occupy Attunement slots.

A rare Formula can require Attunement before activation, but consuming it ends that Attunement immediately.

---

# Essence Saturation and Impurity

Only consumables carrying the **Saturating** tag use these rules.

## Safe Consumption

A creature can safely benefit from one Saturating consumable between Long Rests.

Each additional Saturating consumable requires a Constitution saving throw:

> **Saturation DC = 10 + 2 × the number of Saturating consumables already consumed since the last Long Rest**

### Successful Save

- The consumable functions.
- Gain 1 Essence Impurity.

### Failed Save

- The beneficial effect fails.
- Gain 1 Essence Impurity.
- Become Poisoned until the end of the next Long Rest.

### Failure by 5 or More

You also gain 1 level of Exhaustion.

## Essence Impurity

Each point of Essence Impurity imposes:

- −1 to breakthrough checks;
- −1 to later Saturation saving throws.

At the end of a Long Rest during which you consumed no Saturating consumable, remove 1 Essence Impurity.

A cleansing Formula can remove additional Impurity if it explicitly says so.

## Stacking

Benefits from multiple copies of the same named consumable do not stack unless its entry says otherwise.

Use the strongest remaining duration or value. Temporary Hit Points follow their normal nonstacking rule.

---

# Poison Rules

## Poison Delivery

A poison entry states whether it is injury, contact, inhaled, ingested, or spirit poison.

Applying a prepared poison to a weapon, ammunition, object, or surface uses a Bonus Action unless its entry says otherwise.

A creature proficient with Poisoner's Kit or trained in the Poison Sphere applies a dose safely. Another creature must succeed on a DC 10 Dexterity check using an appropriate tool. On a failure, the dose is wasted and the creature is exposed to the poison.

## Coated Weapons

Unless an entry says otherwise, one dose coats:

- one weapon; or
- three pieces of ammunition.

The coating remains potent for 1 minute or until it successfully delivers its effect.

## Poison Immunity

A poison does not bypass Poison Immunity unless its entry explicitly says so.

Spirit poisons can affect souls, Undead, or incorporeal creatures only when their entries explicitly permit it.

---

# Formation Consumable Rules

Formation Consumables use fixed Eyes and Nodes.

## Control Limit

A creature can control one active Formation Consumable at a time. Deploying another causes the previous one to collapse unless an entry says it is self-sustaining or controlled by a site.

## Breaking the Array

A Formation Consumable collapses when:

- its Eye is destroyed, removed, or suppressed;
- the required number of Nodes is destroyed or moved;
- its duration expires;
- its controller deploys another active Formation Consumable;
- a formation-breaking effect ends it.

## Default Object Statistics

| Grade | Node AC / HP | Eye AC / HP |
|---|---:|---:|
| Spiritual | 13 / 10 | 13 / 15 |
| Saint | 15 / 25 | 15 / 40 |
| Sovereign | 17 / 50 | 17 / 75 |
| Imperial | 19 / 100 | 19 / 150 |
| Immortal | 21 / 200 | 21 / 300 |

Nodes and Eyes are immune to poison and psychic damage unless their entry says otherwise.

---

# Ammunition and Coating Rules

Disposable magical ammunition is consumed after the attack whether it hits or misses.

A weapon can carry only one consumable coating at a time. Applying a new coating removes the old one.

Unless stated otherwise, one coating application lasts 1 minute and ends after three qualifying hits.

A permanent weapon enchantment and a consumable coating can function together when their effects are compatible. Identical named effects do not stack.

---

# Catalog Distribution

| Grade | Items |
|---|---:|
| Spiritual Treasure | 45 |
| Saint Treasure | 27 |
| Sovereign Treasure | 9 |
| Imperial Treasure | 6 |
| Immortal Artifact | 3 |
| **Total** | **90** |

Each of the nine families contains ten entries.

---

# Consumable Catalog Summary

| No. | Consumable | Family | Grade | Activation | Batch |
|---:|---|---|---|---|---:|
| 1 | Nine-Breath Recovery Pill | Pills and Elixirs | Spiritual Treasure | Bonus Action | 4 pills |
| 2 | Clear-Venom Antidote Pill | Pills and Elixirs | Spiritual Treasure | Bonus Action | 4 pills |
| 3 | Fasting Meridian Pill | Pills and Elixirs | Spiritual Treasure | Action | 4 pills |
| 4 | Calming Heart Elixir | Pills and Elixirs | Spiritual Treasure | Bonus Action | 4 vials |
| 5 | Minor Qi-Returning Pill | Pills and Elixirs | Spiritual Treasure | Bonus Action | 4 pills |
| 6 | Bone-Knitting Jade Paste | Pills and Elixirs | Saint Treasure | Action | 4 jars |
| 7 | Meridian-Cleansing Elixir | Pills and Elixirs | Saint Treasure | Bonus Action | 4 vials |
| 8 | Furnace-Body Tempering Pill | Pills and Elixirs | Saint Treasure | Bonus Action | 4 pills |
| 9 | Nine-Revolution Restoration Pill | Pills and Elixirs | Sovereign Treasure | Action | 4 pills |
| 10 | Heaven-Defying Rebirth Pill | Pills and Elixirs | Immortal Artifact | 1-hour Rite | 1 pill |
| 11 | Dragon-Furnace Explosive Pellet | Combat Pellets | Spiritual Treasure | Action; throw to 60 feet | 4 pellets |
| 12 | Frost-Bloom Pellet | Combat Pellets | Spiritual Treasure | Action; throw to 60 feet | 4 pellets |
| 13 | Black-Dregs Smoke Pellet | Combat Pellets | Spiritual Treasure | Action; throw to 60 feet | 4 pellets |
| 14 | Thunderclap Pellet | Combat Pellets | Spiritual Treasure | Action; throw to 60 feet | 4 pellets |
| 15 | Bone-Melting Corrosive Pellet | Combat Pellets | Spiritual Treasure | Action; throw to 60 feet | 4 pellets |
| 16 | Five-Poison Cloud Pellet | Combat Pellets | Saint Treasure | Action; throw to 90 feet | 4 pellets |
| 17 | Soul-Shock Pellet | Combat Pellets | Saint Treasure | Action; throw to 90 feet | 4 pellets |
| 18 | Gravity-Well Pellet | Combat Pellets | Saint Treasure | Action; throw to 90 feet | 4 pellets |
| 19 | Calamity-Star Pellet | Combat Pellets | Sovereign Treasure | Action; throw to 120 feet | 4 pellets |
| 20 | Imperial Sunfire Annihilation Pellet | Combat Pellets | Imperial Treasure | Action; throw to 150 feet | 1 pellet |
| 21 | Swift-Step Talisman | Talismans and Seals | Spiritual Treasure | Bonus Action | 4 talismans |
| 22 | Body-Guarding Talisman | Talismans and Seals | Spiritual Treasure | Reaction when you take damage | 4 talismans |
| 23 | Firebolt Talisman | Talismans and Seals | Spiritual Treasure | Action | 4 talismans |
| 24 | Ghost-Warding Door Seal | Talismans and Seals | Spiritual Treasure | Action; affix to an entrance | 4 seals |
| 25 | Water-Breathing Talisman | Talismans and Seals | Spiritual Treasure | Action; affix to a creature | 4 talismans |
| 26 | Thunder-Escape Talisman | Talismans and Seals | Saint Treasure | Reaction when you take damage | 4 talismans |
| 27 | Meridian-Sealing Talisman | Talismans and Seals | Saint Treasure | Action | 4 talismans |
| 28 | Mirror-Reversal Talisman | Talismans and Seals | Saint Treasure | Reaction when a visible creature hits you with an attack | 4 talismans |
| 29 | Nine-Lock Demon Suppression Seal | Talismans and Seals | Sovereign Treasure | Action | 1 seal |
| 30 | Heaven-Law Command Talisman | Talismans and Seals | Immortal Artifact | Action | 1 talisman |
| 31 | Clear-Mind Study Incense | Incense | Spiritual Treasure | Action; burns for 1 hour | 2 sticks |
| 32 | Soul-Scent Appraisal Incense | Incense | Spiritual Treasure | Action; burns for 10 minutes | 2 sticks |
| 33 | Nine-Herb Healing Incense | Incense | Spiritual Treasure | Light during a Short Rest | 2 bundles |
| 34 | Beast-Calming Cedar Incense | Incense | Spiritual Treasure | Action; burns for 10 minutes | 2 bundles |
| 35 | Dreamless-Sleep Incense | Incense | Spiritual Treasure | Light at the start of a Long Rest | 2 bundles |
| 36 | Meridian-Recovery Incense | Incense | Saint Treasure | Light during a Short Rest | 2 bundles |
| 37 | Ghost-Banishing Incense | Incense | Saint Treasure | Action; burns for 10 minutes | 2 bundles |
| 38 | Incense of Truthful Counsel | Incense | Saint Treasure | Action; burns for 1 hour | 2 bundles |
| 39 | Ancestor-Calling Temple Incense | Incense | Sovereign Treasure | 10-minute Rite | 1 bundle |
| 40 | Imperial Heaven-Cleansing Incense | Incense | Imperial Treasure | Action; burns for 10 minutes | 1 bundle |
| 41 | Spirit-Grain Recovery Wine | Spirit Wines and Medicinal Foods | Spiritual Treasure | Bonus Action | 6 servings |
| 42 | Iron-Bone Broth | Spirit Wines and Medicinal Foods | Spiritual Treasure | Consume during a Short Rest | 6 servings |
| 43 | Cloudstep Plum Wine | Spirit Wines and Medicinal Foods | Spiritual Treasure | Bonus Action | 6 servings |
| 44 | Moon-Dew Clarity Tea | Spirit Wines and Medicinal Foods | Spiritual Treasure | Action | 6 servings |
| 45 | Seven-Day Fasting Cake | Spirit Wines and Medicinal Foods | Spiritual Treasure | Action | 6 servings |
| 46 | Five-Flavor Warrior Feast | Spirit Wines and Medicinal Foods | Saint Treasure | Consume during a Short or Long Rest | 6 servings |
| 47 | Dragon-Marrow Strength Wine | Spirit Wines and Medicinal Foods | Saint Treasure | Bonus Action | 6 servings |
| 48 | Phoenix-Heart Restoration Soup | Spirit Wines and Medicinal Foods | Saint Treasure | Consume during a Short Rest | 6 servings |
| 49 | Nine-Course Sovereign Dao Banquet | Spirit Wines and Medicinal Foods | Sovereign Treasure | Consume during a Long Rest | 6 servings |
| 50 | Imperial Feast of Returning Spring | Spirit Wines and Medicinal Foods | Imperial Treasure | Consume during a Long Rest | 6 servings |
| 51 | Numbing Needle Venom | Poisons | Spiritual Treasure | Bonus Action to apply | 3 doses |
| 52 | Sleep-Lotus Extract | Poisons | Spiritual Treasure | Bonus Action to apply or Action to administer | 3 doses |
| 53 | Meridian-Stiffening Oil | Poisons | Spiritual Treasure | Bonus Action to apply | 3 doses |
| 54 | Spirit-Beast Hunter Toxin | Poisons | Spiritual Treasure | Bonus Action to apply | 3 doses |
| 55 | Truth-Loosening Draught | Poisons | Spiritual Treasure | Action to administer | 3 doses |
| 56 | Ghost-Scorch Resin | Poisons | Saint Treasure | Bonus Action to apply | 3 doses |
| 57 | Qi-Draining Black Venom | Poisons | Saint Treasure | Bonus Action to apply | 3 doses |
| 58 | Hundred-Ache Contact Poison | Poisons | Saint Treasure | Action to spread over a 5-foot square or object | 3 doses |
| 59 | Sovereign Soul-Corrosion Poison | Poisons | Sovereign Treasure | Bonus Action to apply | 1 dose |
| 60 | Imperial Emperor-Killing Venom | Poisons | Imperial Treasure | Bonus Action to apply | 1 dose |
| 61 | Alert Boundary Stake Kit | Formation Consumables | Spiritual Treasure | 10-minute Setup | 1 kit |
| 62 | Mist-Hiding Array Plates | Formation Consumables | Spiritual Treasure | 10-minute Setup | 1 kit |
| 63 | Spirit-Gathering Rest Array Mat | Formation Consumables | Spiritual Treasure | 10-minute Setup | 1 kit |
| 64 | Firebreak Array Tiles | Formation Consumables | Spiritual Treasure | Action | 1 kit |
| 65 | Minor Binding Array Flags | Formation Consumables | Spiritual Treasure | Action | 1 kit |
| 66 | Five-Phase Shelter Array | Formation Consumables | Saint Treasure | 10-minute Setup | 1 kit |
| 67 | Twin-Gate Transit Array Plates | Formation Consumables | Saint Treasure | 10-minute Setup at each end | 1 paired kit |
| 68 | Formation-Breaking Spike Set | Formation Consumables | Saint Treasure | Action | 1 set of 3 spikes |
| 69 | Nine-Palace Battlefield Disk | Formation Consumables | Sovereign Treasure | Action | 1 disk |
| 70 | Heaven-Earth Rewriting Array Core | Formation Consumables | Immortal Artifact | 1-hour Setup | 1 core |
| 71 | Smoke-Step Escape Bead | Single-Use Escape Treasures | Spiritual Treasure | Bonus Action | 1 bead |
| 72 | Earth-Passing Jade Shard | Single-Use Escape Treasures | Spiritual Treasure | Action | 1 shard |
| 73 | River-Current Escape Token | Single-Use Escape Treasures | Spiritual Treasure | Bonus Action | 1 token |
| 74 | Featherfall Escape Charm | Single-Use Escape Treasures | Spiritual Treasure | Reaction when you fall | 1 charm |
| 75 | Beast-Decoy Skin Doll | Single-Use Escape Treasures | Spiritual Treasure | Reaction when a creature targets you with an attack | 1 doll |
| 76 | Void-Step Jade Shard | Single-Use Escape Treasures | Saint Treasure | Bonus Action | 1 shard |
| 77 | Thousand-Li Return Seal | Single-Use Escape Treasures | Saint Treasure | 1-minute Rite | 1 seal |
| 78 | Thunder-Shell Substitution Doll | Single-Use Escape Treasures | Saint Treasure | Reaction when you are hit by an attack | 1 doll |
| 79 | Life-Saving Golden Cicada | Single-Use Escape Treasures | Sovereign Treasure | No action when you would drop to 0 Hit Points | 1 cicada |
| 80 | Imperial Boundary-Breaking Escape Order | Single-Use Escape Treasures | Imperial Treasure | Action | 1 order |
| 81 | Flame-Tongue Weapon Oil | Disposable Ammunition and Weapon Coatings | Spiritual Treasure | Bonus Action to apply | 3 applications |
| 82 | Frostbite Edge Oil | Disposable Ammunition and Weapon Coatings | Spiritual Treasure | Bonus Action to apply | 3 applications |
| 83 | Thunderburst Ammunition | Disposable Ammunition and Weapon Coatings | Spiritual Treasure | Used as ammunition | 5 pieces |
| 84 | Ghost-Touch Lacquer | Disposable Ammunition and Weapon Coatings | Spiritual Treasure | Bonus Action to apply | 3 applications |
| 85 | Armor-Eating Acid Varnish | Disposable Ammunition and Weapon Coatings | Spiritual Treasure | Bonus Action to apply | 3 applications |
| 86 | Soul-Piercing Needle Set | Disposable Ammunition and Weapon Coatings | Saint Treasure | Used as thrown ammunition | 5 needles |
| 87 | Formation-Breaking Arrowheads | Disposable Ammunition and Weapon Coatings | Saint Treasure | Used as ammunition | 5 pieces |
| 88 | Void-Nail Weapon Coating | Disposable Ammunition and Weapon Coatings | Saint Treasure | Bonus Action to apply | 3 applications |
| 89 | Calamity-Fletched Ammunition | Disposable Ammunition and Weapon Coatings | Sovereign Treasure | Used as ammunition | 5 pieces |
| 90 | Imperial Heaven-Splitting Weapon Oil | Disposable Ammunition and Weapon Coatings | Imperial Treasure | Bonus Action to apply | 1 application |

---

# Detailed Consumable Catalog

# Pills and Elixirs

## 1. Nine-Breath Recovery Pill
*Pills and Elixirs, Spiritual Treasure*

**Sphere Influences:** Alchemy, Life, Medicine  
**Activation:** Bonus Action  
**Tags:** Restorative  
**Standard Batch Yield:** 4 pills

You regain `2d8 + 2` Hit Points.

If you are at 0 Hit Points, another creature can administer the pill to you as an Action. This pill does not count against Essence Saturation.

---

## 2. Clear-Venom Antidote Pill
*Pills and Elixirs, Spiritual Treasure*

**Sphere Influences:** Alchemy, Medicine, Poison  
**Activation:** Bonus Action  
**Tags:** Restorative  
**Standard Batch Yield:** 4 pills

You can immediately repeat one saving throw against the Poisoned condition or a poison currently affecting you, if that effect normally permits repeated saving throws. You make the save with Advantage.

If you are not currently affected by a poison, you instead have Advantage on the next saving throw you make against poison before the end of your next Short Rest. This pill does not count against Essence Saturation.

---

## 3. Fasting Meridian Pill
*Pills and Elixirs, Spiritual Treasure*

**Sphere Influences:** Alchemy, Life, Qiweaving  
**Activation:** Action  
**Tags:** Saturating, Sustaining  
**Standard Batch Yield:** 4 pills

For 7 days, you require no food and only half as much water.

The pill prevents hunger and ordinary malnutrition during that period, but it does not remove existing Exhaustion, replace special nutrients required by a species or cultivation method, or support accelerated growth.

---

## 4. Calming Heart Elixir
*Pills and Elixirs, Spiritual Treasure*

**Sphere Influences:** Alchemy, Spirit, Dreams  
**Activation:** Bonus Action  
**Tags:** Saturating, Enhancement  
**Standard Batch Yield:** 4 vials

For 1 hour, you have Advantage on saving throws against the Charmed and Frightened conditions and against hostile dream intrusion.

When you drink the elixir, you can immediately repeat one saving throw against one of those effects if it normally permits repeated saving throws.

---

## 5. Minor Qi-Returning Pill
*Pills and Elixirs, Spiritual Treasure*

**Sphere Influences:** Alchemy, Qiweaving, Life  
**Activation:** Bonus Action  
**Tags:** Saturating, Resource Recovery  
**Standard Batch Yield:** 4 pills

Regain expended CP, Stamina, or Resonance equal to your Proficiency Bonus.

A creature can regain a Path resource from this pill only once per Short Rest, even if it consumes additional copies.

---

## 6. Bone-Knitting Jade Paste
*Pills and Elixirs, Saint Treasure*

**Sphere Influences:** Alchemy, Medicine, Body Refining  
**Activation:** Action  
**Tags:** Restorative, External  
**Standard Batch Yield:** 4 jars

Apply the paste to yourself or a creature within reach. The target regains `5d8 + 10` Hit Points.

The paste also ends one effect reducing the target's Speed because of a physical injury, closes ordinary open wounds, and repairs one broken mundane bone. It does not regrow a missing body part or end a supernatural curse.

---

## 7. Meridian-Cleansing Elixir
*Pills and Elixirs, Saint Treasure*

**Sphere Influences:** Alchemy, Qiweaving, Medicine  
**Activation:** Bonus Action  
**Tags:** Saturating, Resource Recovery  
**Standard Batch Yield:** 4 vials

Regain expended CP, Stamina, or Resonance equal to twice your Proficiency Bonus.

You can also immediately repeat one saving throw against an effect that prevents you from spending that resource, corrupts your circulation, or imposes a cultivation-related condition that normally permits repeated saves.

A creature can benefit from this elixir only once per Long Rest.

---

## 8. Furnace-Body Tempering Pill
*Pills and Elixirs, Saint Treasure*

**Sphere Influences:** Alchemy, Body Refining, Fire  
**Activation:** Bonus Action  
**Tags:** Saturating, Enhancement  
**Standard Batch Yield:** 4 pills

For 1 hour, you gain Resistance to bludgeoning, piercing, and slashing damage from nonmagical attacks.

Whenever you take fire damage during the duration, reduce that damage by your Proficiency Bonus after applying Resistance.

When the effect ends, you cannot Dash until the end of your next turn.

---

## 9. Nine-Revolution Restoration Pill
*Pills and Elixirs, Sovereign Treasure*

**Sphere Influences:** Alchemy, Life, Medicine  
**Activation:** Action  
**Tags:** Saturating, Restoration  
**Standard Batch Yield:** 4 pills

You regain `10d8 + 30` Hit Points and end any combination of three of the following affecting you:

- Blinded;
- Charmed;
- Deafened;
- Frightened;
- Paralyzed;
- Poisoned;
- Stunned;
- one disease;
- one poison;
- one level of Exhaustion.

A creature can benefit from this pill only once per Long Rest.

---

## 10. Heaven-Defying Rebirth Pill
*Pills and Elixirs, Immortal Artifact*

**Sphere Influences:** Alchemy, Life, Death, Soul  
**Activation:** 1-hour Rite  
**Tags:** Saturating, Resurrection, Immortal  
**Standard Batch Yield:** 1 pill

Administer the pill to a creature that died within the previous 30 days and whose body or at least half of its remains are present.

If the soul is willing and not imprisoned, destroyed, or already reincarnated, the creature returns to life with full Hit Points, 5 levels of Exhaustion, and no expended Path resources restored.

The pill recreates missing ordinary organs and limbs but does not restore an Immortal body, reverse willing reincarnation, or overcome an equal or stronger soul mandate.

A creature restored by this pill cannot benefit from another Heaven-Defying Rebirth Pill for one year.

---

# Combat Pellets

## 11. Dragon-Furnace Explosive Pellet
*Combat Pellets, Spiritual Treasure*

**Sphere Influences:** Alchemy, Fire, Destruction  
**Activation:** Action; throw to 60 feet  
**Tags:** Pellet, Burst  
**Standard Batch Yield:** 4 pellets

The pellet detonates in a 10-foot-radius sphere centered on a point within range.

Creatures in the area make a DC 13 Dexterity saving throw, taking `4d6` fire damage on a failed save or half as much on a successful save.

Unattended flammable objects in the area ignite.

---

## 12. Frost-Bloom Pellet
*Combat Pellets, Spiritual Treasure*

**Sphere Influences:** Alchemy, Ice, Water  
**Activation:** Action; throw to 60 feet  
**Tags:** Pellet, Zone  
**Standard Batch Yield:** 4 pellets

The pellet creates a 10-foot-radius patch of supernatural frost for 1 minute.

Creatures in the area when it appears make a DC 13 Constitution saving throw, taking `3d6` cold damage on a failed save or half as much on a successful save.

The area is Difficult Terrain. A creature entering the area for the first time on a turn or starting its turn there takes `1d6` cold damage.

---

## 13. Black-Dregs Smoke Pellet
*Combat Pellets, Spiritual Treasure*

**Sphere Influences:** Alchemy, Smoke, Dark  
**Activation:** Action; throw to 60 feet  
**Tags:** Pellet, Obscurement  
**Standard Batch Yield:** 4 pellets

The pellet creates a 15-foot-radius sphere of Heavy Obscurement for 1 minute.

A moderate or stronger wind disperses the smoke. A creature that enters the smoke for the first time on a turn or starts its turn there must succeed on a DC 13 Constitution saving throw or be unable to take Reactions until the start of its next turn.

Creatures that do not breathe are immune to the saving throw effect.

---

## 14. Thunderclap Pellet
*Combat Pellets, Spiritual Treasure*

**Sphere Influences:** Alchemy, Sound, Lightning  
**Activation:** Action; throw to 60 feet  
**Tags:** Pellet, Burst  
**Standard Batch Yield:** 4 pellets

The pellet detonates in a 10-foot-radius sphere.

Creatures in the area make a DC 13 Constitution saving throw. On a failed save, a creature takes `3d8` thunder damage, is Deafened until the end of its next turn, and cannot take Reactions until then. On a successful save, it takes half damage and suffers no other effect.

---

## 15. Bone-Melting Corrosive Pellet
*Combat Pellets, Spiritual Treasure*

**Sphere Influences:** Alchemy, Acid, Destruction  
**Activation:** Action; throw to 60 feet  
**Tags:** Pellet, Corrosion  
**Standard Batch Yield:** 4 pellets

Make a ranged consumable attack with a +5 modifier against one creature, unattended object, or Formation component within range.

On a hit, the target takes `4d6` acid damage. An unattended object, structure, Array Eye, or Node takes maximum damage.

A nonmagical object reduced to 0 Hit Points by the pellet is dissolved rather than merely broken.

---

## 16. Five-Poison Cloud Pellet
*Combat Pellets, Saint Treasure*

**Sphere Influences:** Alchemy, Poison, Smoke  
**Activation:** Action; throw to 90 feet  
**Tags:** Pellet, Poison Cloud  
**Standard Batch Yield:** 4 pellets

The pellet creates a 20-foot-radius sphere of poisonous smoke for 1 minute.

Creatures in the area when it appears make a DC 15 Constitution saving throw. On a failed save, a creature takes `6d6` poison damage and is Poisoned until the end of its next turn. On a successful save, it takes half damage.

A creature entering the cloud for the first time on a turn or starting its turn there repeats the save against `3d6` poison damage. A strong wind disperses the cloud.

---

## 17. Soul-Shock Pellet
*Combat Pellets, Saint Treasure*

**Sphere Influences:** Alchemy, Spirit, Sound  
**Activation:** Action; throw to 90 feet  
**Tags:** Pellet, Spirit Burst  
**Standard Batch Yield:** 4 pellets

The pellet detonates in a 15-foot-radius sphere.

Creatures in the area make a DC 15 Wisdom saving throw. On a failed save, a creature takes `5d8` psychic damage and is Frightened of the detonation point until the end of its next turn. On a successful save, it takes half damage.

Undead, possessing entities, and incorporeal spirits make the saving throw with Disadvantage.

---

## 18. Gravity-Well Pellet
*Combat Pellets, Saint Treasure*

**Sphere Influences:** Alchemy, Gravity, Force  
**Activation:** Action; throw to 90 feet  
**Tags:** Pellet, Control Zone  
**Standard Batch Yield:** 4 pellets

The pellet creates a 15-foot-radius gravity well centered on a point within range until the end of your next turn.

Creatures in the area when it appears make a DC 15 Strength saving throw. On a failed save, a creature takes `4d8` force damage, is pulled to the nearest unoccupied space adjacent to the center, and falls Prone. On a successful save, it takes half damage and is not moved.

The area is Difficult Terrain until the effect ends.

---

## 19. Calamity-Star Pellet
*Combat Pellets, Sovereign Treasure*

**Sphere Influences:** Alchemy, Lightning, Force, Stars  
**Activation:** Action; throw to 120 feet  
**Tags:** Pellet, Greater Burst  
**Standard Batch Yield:** 4 pellets

The pellet descends as a violent star in a 20-foot-radius sphere.

Creatures in the area make a DC 17 Dexterity saving throw. On a failed save, a creature takes `6d8` lightning damage and `6d8` force damage and falls Prone. On a successful save, it takes half damage and remains standing.

Unattended objects and Formation components take maximum force damage.

---

## 20. Imperial Sunfire Annihilation Pellet
*Combat Pellets, Imperial Treasure*

**Sphere Influences:** Alchemy, Fire, Radiance, Destruction  
**Activation:** Action; throw to 150 feet  
**Tags:** Pellet, Imperial Burst  
**Standard Batch Yield:** 1 pellet

The pellet creates a 30-foot-radius sphere of white-gold fire.

Creatures in the area make a DC 19 Dexterity saving throw. On a failed save, a creature takes `10d8` fire damage and `10d8` radiant damage. On a successful save, it takes half damage.

A creature reduced to 0 Hit Points by this damage cannot regain Hit Points until the start of your next turn.

Imperial or stronger barriers take normal damage; all weaker unattended barriers and Formation components take maximum damage.

---

# Talismans and Seals

## 21. Swift-Step Talisman
*Talismans and Seals, Spiritual Treasure*

**Sphere Influences:** Talismans, Athletics, Air  
**Activation:** Bonus Action  
**Tags:** Talisman, Movement  
**Standard Batch Yield:** 4 talismans

Affix or tear the talisman to move up to 20 feet without provoking Opportunity Attacks.

You cannot move through occupied spaces or terrain you could not normally enter. This is movement, not teleportation.

---

## 22. Body-Guarding Talisman
*Talismans and Seals, Spiritual Treasure*

**Sphere Influences:** Talismans, Protection, Equipment  
**Activation:** Reaction when you take damage  
**Tags:** Talisman, Reaction  
**Standard Batch Yield:** 4 talismans

Reduce the triggering damage by `2d8 + 3`.

If this reduces the damage to 0, you can move 5 feet without provoking Opportunity Attacks from the source of the damage.

---

## 23. Firebolt Talisman
*Talismans and Seals, Spiritual Treasure*

**Sphere Influences:** Talismans, Fire, Destruction  
**Activation:** Action  
**Tags:** Talisman, Attack  
**Standard Batch Yield:** 4 talismans

Make a ranged consumable attack with a +5 modifier against one creature or object within 90 feet.

On a hit, the target takes `4d8` fire damage.

---

## 24. Ghost-Warding Door Seal
*Talismans and Seals, Spiritual Treasure*

**Sphere Influences:** Talismans, Spirit, Protection  
**Activation:** Action; affix to an entrance  
**Tags:** Talisman, Ward  
**Standard Batch Yield:** 4 seals

The seal protects one door, window, gate, coffin lid, or similar opening no wider than 10 feet for 8 hours.

An Undead, incorporeal spirit, or possessing entity attempting to cross must succeed on a DC 13 Charisma saving throw. On a failed save, it cannot cross for 1 hour and takes `3d8` radiant damage. On a successful save, it crosses and destroys the seal.

The seal has AC 13 and 5 Hit Points.

---

## 25. Water-Breathing Talisman
*Talismans and Seals, Spiritual Treasure*

**Sphere Influences:** Talismans, Water, Air  
**Activation:** Action; affix to a creature  
**Tags:** Talisman, Utility  
**Standard Batch Yield:** 4 talismans

For 1 hour, the target can breathe air and water and can speak normally underwater.

The target does not gain a Swim Speed or protection from deep-water pressure.

---

## 26. Thunder-Escape Talisman
*Talismans and Seals, Saint Treasure*

**Sphere Influences:** Talismans, Lightning, Space  
**Activation:** Reaction when you take damage  
**Tags:** Talisman, Escape, Reaction  
**Standard Batch Yield:** 4 talismans

After the triggering damage resolves, teleport up to 40 feet to an unoccupied space you can see.

Creatures within 5 feet of the space you left make a DC 15 Dexterity saving throw, taking `3d8` lightning damage on a failed save or half as much on a successful save.

A sealed spatial boundary can prevent the teleportation.

---

## 27. Meridian-Sealing Talisman
*Talismans and Seals, Saint Treasure*

**Sphere Influences:** Talismans, Pressure Points, Sealing  
**Activation:** Action  
**Tags:** Talisman, Control  
**Standard Batch Yield:** 4 talismans

Make a ranged consumable attack with a +7 modifier against one creature within 30 feet.

On a hit, the talisman affixes to the target. The target makes a DC 15 Constitution saving throw.

On a failed save, until the end of your next turn it cannot take Reactions or spend CP, Stamina, Resonance, or another Path resource. On a successful save, it cannot take Reactions until the end of the current turn.

The talisman is destroyed after resolving.

---

## 28. Mirror-Reversal Talisman
*Talismans and Seals, Saint Treasure*

**Sphere Influences:** Talismans, Mirror, Retribution  
**Activation:** Reaction when a visible creature hits you with an attack  
**Tags:** Talisman, Reflection, Reaction  
**Standard Batch Yield:** 4 talismans

Reduce the triggering damage by `4d8 + 5`.

If this reduces the damage to 0, make a ranged consumable attack with a +7 modifier against the attacker if it is within 120 feet. On a hit, it takes `4d8` force damage.

The reflected attack does not carry the attacker's original effects.

---

## 29. Nine-Lock Demon Suppression Seal
*Talismans and Seals, Sovereign Treasure*

**Sphere Influences:** Talismans, Chains, Spirit, Sealing  
**Activation:** Action  
**Tags:** Talisman, Greater Binding  
**Standard Batch Yield:** 1 seal

Choose one Gargantuan or smaller creature within 60 feet. It makes a DC 17 Charisma saving throw.

On a failed save, spectral chains bind it for up to 1 minute. While bound, it is Restrained, cannot become Invisible, cannot possess another creature, and cannot teleport or travel between planes.

At the end of each of its turns, it repeats the saving throw, ending the effect on a success.

On the initial successful save, its Speed is halved until the end of its next turn.

---

## 30. Heaven-Law Command Talisman
*Talismans and Seals, Immortal Artifact*

**Sphere Influences:** Talismans, Dao, Sealing, Authority  
**Activation:** Action  
**Tags:** Talisman, Immortal Law  
**Standard Batch Yield:** 1 talisman

Choose one point within 120 feet and one category: teleportation, summoned creatures, divination, dream travel, healing, or one named Sphere family.

For 1 minute, a 30-foot-radius sphere centered on that point suppresses non-Immortal activations belonging to the chosen category.

An Immortal activation can function only if its creator succeeds on an ability check against DC 21.

The talisman does not remove permanent character features, erase Sphere ownership, destroy existing creatures, or end effects created before activation unless those effects require continued activation within the area.

---

# Incense

## 31. Clear-Mind Study Incense
*Incense, Spiritual Treasure*

**Sphere Influences:** Alchemy, Ink, Spirit  
**Activation:** Action; burns for 1 hour  
**Tags:** Incense, Study  
**Standard Batch Yield:** 2 sticks

Creatures within 10 feet have Advantage on checks made to maintain concentration during study, copying, translation, meditation, or analysis despite ordinary noise and discomfort.

The incense does not grant Concentration on a supernatural effect or prevent interruption by combat.

---

## 32. Soul-Scent Appraisal Incense
*Incense, Spiritual Treasure*

**Sphere Influences:** Alchemy, Spirit, The Hidden Eye  
**Activation:** Action; burns for 10 minutes  
**Tags:** Incense, Appraisal  
**Standard Batch Yield:** 2 sticks

While the incense burns, visible smoke bends toward the nearest corpse, spirit, possessed creature, soul-bound treasure, or object carrying strong spiritual residue within 30 feet.

The smoke identifies the broad category but not the creature's identity, allegiance, grade, or exact effect. Total Cover blocks the reading.

---

## 33. Nine-Herb Healing Incense
*Incense, Spiritual Treasure*

**Sphere Influences:** Alchemy, Life, Medicine  
**Activation:** Light during a Short Rest  
**Tags:** Incense, Restorative  
**Standard Batch Yield:** 2 bundles

Up to six creatures that remain within 10 feet for the full Short Rest regain an additional `1d8 + 2` Hit Points if they spend at least one Hit Die.

A creature can benefit from only one Nine-Herb Healing Incense during a Short Rest.

---

## 34. Beast-Calming Cedar Incense
*Incense, Spiritual Treasure*

**Sphere Influences:** Alchemy, Beastmastery, Spirit Companions  
**Activation:** Action; burns for 10 minutes  
**Tags:** Incense, Beast  
**Standard Batch Yield:** 2 bundles

Beasts, willing spirit companions, and Monstrosities with Intelligence 5 or lower within 20 feet have Advantage on saving throws against the Frightened condition.

A hostile qualifying creature entering the area must succeed on a DC 13 Wisdom saving throw or be unable to take Reactions while it remains in the smoke.

After a creature succeeds on the save, it is immune to this incense for 24 hours.

---

## 35. Dreamless-Sleep Incense
*Incense, Spiritual Treasure*

**Sphere Influences:** Alchemy, Dreams, Protection  
**Activation:** Light at the start of a Long Rest  
**Tags:** Incense, Rest  
**Standard Batch Yield:** 2 bundles

Up to six willing creatures within 10 feet have Advantage on saving throws against magical sleep, nightmare effects, and hostile dream intrusion during the Long Rest.

A creature that completes the rest remembers no ordinary dreams and has Advantage on the first saving throw it makes against Frightened before its next Long Rest.

---

## 36. Meridian-Recovery Incense
*Incense, Saint Treasure*

**Sphere Influences:** Alchemy, Qiweaving, Life  
**Activation:** Light during a Short Rest  
**Tags:** Incense, Saturating, Resource Recovery  
**Standard Batch Yield:** 2 bundles

Up to six creatures that remain within 15 feet for the full Short Rest regain expended CP, Stamina, or Resonance equal to their Proficiency Bonus.

Each affected creature counts as having consumed one Saturating consumable.

A creature can benefit from this incense only once per Long Rest.

---

## 37. Ghost-Banishing Incense
*Incense, Saint Treasure*

**Sphere Influences:** Alchemy, Spirit, Radiance  
**Activation:** Action; burns for 10 minutes  
**Tags:** Incense, Spirit Ward  
**Standard Batch Yield:** 2 bundles

The incense fills a 20-foot-radius area.

An Undead, incorporeal spirit, or possessing entity entering the area for the first time on a turn or starting its turn there makes a DC 15 Charisma saving throw.

On a failed save, it takes `4d8` radiant damage and cannot enter the area again until the start of its next turn. On a successful save, it takes half damage.

A strong wind disperses the incense.

---

## 38. Incense of Truthful Counsel
*Incense, Saint Treasure*

**Sphere Influences:** Alchemy, Beauty, Karma  
**Activation:** Action; burns for 1 hour  
**Tags:** Incense, Social  
**Standard Batch Yield:** 2 bundles

Creatures willingly conversing within 15 feet have Advantage on Wisdom (Insight) and Charisma (Persuasion) checks made toward one another.

When a creature knowingly speaks a direct factual lie, it must succeed on a DC 15 Charisma saving throw or the smoke briefly turns black around its mouth.

The incense does not expose omissions, compel speech, or determine objective truth.

---

## 39. Ancestor-Calling Temple Incense
*Incense, Sovereign Treasure*

**Sphere Influences:** Alchemy, Spirit Companions, Death  
**Activation:** 10-minute Rite  
**Tags:** Incense, Ancestor Communion  
**Standard Batch Yield:** 1 bundle

Present a true name, blood relation, funerary tablet, or personal relic connected to a deceased ancestor.

If the spirit remains reachable and willing, it manifests within the smoke for up to 1 hour. It can see and hear within 30 feet, speak, and answer questions using its own knowledge.

During the manifestation, allied descendants within 30 feet have Advantage on Intelligence and Wisdom saving throws.

The incense cannot compel, bind, reconstruct, or contact a destroyed or reincarnated soul.

---

## 40. Imperial Heaven-Cleansing Incense
*Incense, Imperial Treasure*

**Sphere Influences:** Alchemy, Life, Radiance, Purification  
**Activation:** Action; burns for 10 minutes  
**Tags:** Incense, Imperial Purification  
**Standard Batch Yield:** 1 bundle

The incense fills a 60-foot-radius area for 10 minutes. Hostile smoke, gas, poison clouds, disease-bearing vapors, and non-Imperial airborne effects are immediately dispersed.

Creatures of your choice entering the area or starting their turn there can end one poison, disease, Charmed, Frightened, or possession effect of Imperial grade or lower.

Each creature can receive this cleansing only once from the incense.

An Imperial effect can resist with an opposed ability check against DC 19. Immortal effects are unaffected.

---

# Spirit Wines and Medicinal Foods

## 41. Spirit-Grain Recovery Wine
*Spirit Wines and Medicinal Foods, Spiritual Treasure*

**Sphere Influences:** Alchemy, Life, Drunken Style  
**Activation:** Bonus Action  
**Tags:** Restorative, Wine  
**Standard Batch Yield:** 6 servings

You regain `2d6 + 3` Hit Points.

For 10 minutes, you have Advantage on saving throws against ordinary environmental cold. This wine does not count against Essence Saturation.

---

## 42. Iron-Bone Broth
*Spirit Wines and Medicinal Foods, Spiritual Treasure*

**Sphere Influences:** Alchemy, Body Refining, Life  
**Activation:** Consume during a Short Rest  
**Tags:** Saturating, Food, Enhancement  
**Standard Batch Yield:** 6 servings

You gain Temporary Hit Points equal to twice your Proficiency Bonus. They last until your next Long Rest.

You also have Advantage on the next Strength saving throw you make before your next Long Rest.

---

## 43. Cloudstep Plum Wine
*Spirit Wines and Medicinal Foods, Spiritual Treasure*

**Sphere Influences:** Alchemy, Air, Athletics  
**Activation:** Bonus Action  
**Tags:** Saturating, Wine, Enhancement  
**Standard Batch Yield:** 6 servings

For 1 hour, your Speed increases by 5 feet, and you add 10 feet to your long jump distance and 5 feet to your high jump height.

When the effect ends, you cannot benefit from another Cloudstep Plum Wine until you complete a Short Rest.

---

## 44. Moon-Dew Clarity Tea
*Spirit Wines and Medicinal Foods, Spiritual Treasure*

**Sphere Influences:** Alchemy, Moon, Spirit  
**Activation:** Action  
**Tags:** Saturating, Tea, Enhancement  
**Standard Batch Yield:** 6 servings

For 1 hour, you gain Darkvision out to 60 feet. If you already have Darkvision, its range increases by 30 feet.

You also have Advantage on Wisdom (Perception) checks made to notice illusions, spirits, or reflected light during the duration.

---

## 45. Seven-Day Fasting Cake
*Spirit Wines and Medicinal Foods, Spiritual Treasure*

**Sphere Influences:** Alchemy, Life, Sect Stewardship  
**Activation:** Action  
**Tags:** Food, Sustaining  
**Standard Batch Yield:** 6 servings

One serving provides sufficient food for 7 days.

The cake does not spoil and weighs 1 ounce. It does not provide water, remove existing starvation, or satisfy a special cultivation diet.

This food is not Saturating.

---

## 46. Five-Flavor Warrior Feast
*Spirit Wines and Medicinal Foods, Saint Treasure*

**Sphere Influences:** Alchemy, Life, Warleader  
**Activation:** Consume during a Short or Long Rest  
**Tags:** Saturating, Feast, Enhancement  
**Standard Batch Yield:** 6 servings

Choose one flavor when the feast is prepared. A creature eating one serving gains the associated benefit until its next Long Rest:

- **Bitter:** Advantage on saving throws against poison and disease.
- **Sweet:** Temporary Hit Points equal to three times Proficiency Bonus.
- **Sour:** Advantage on initiative rolls.
- **Spicy:** Speed increases by 10 feet.
- **Savory:** Add `1d4` to the first saving throw made in each scene.

A creature can benefit from only one flavor at a time.

---

## 47. Dragon-Marrow Strength Wine
*Spirit Wines and Medicinal Foods, Saint Treasure*

**Sphere Influences:** Alchemy, Dragon, Athletics  
**Activation:** Bonus Action  
**Tags:** Saturating, Wine, Enhancement  
**Standard Batch Yield:** 6 servings

For 1 hour, you have Advantage on Strength checks and Strength saving throws, and you count as one size larger for carrying capacity and determining what you can Grapple or Shove.

Once during each of your turns when you hit with a melee weapon attack, add `1d6` damage of the weapon's type.

When the effect ends, you cannot Dash until the end of your next turn.

---

## 48. Phoenix-Heart Restoration Soup
*Spirit Wines and Medicinal Foods, Saint Treasure*

**Sphere Influences:** Alchemy, Fire, Life  
**Activation:** Consume during a Short Rest  
**Tags:** Saturating, Food, Restoration  
**Standard Batch Yield:** 6 servings

You regain `6d8 + 15` Hit Points and can remove one level of Exhaustion.

A creature can remove only one level of Exhaustion from this soup between Long Rests.

For 1 hour after the meal, you have Resistance to fire damage.

---

## 49. Nine-Course Sovereign Dao Banquet
*Spirit Wines and Medicinal Foods, Sovereign Treasure*

**Sphere Influences:** Alchemy, Five-Phase, Sect Stewardship  
**Activation:** Consume during a Long Rest  
**Tags:** Saturating, Feast, Sovereign  
**Standard Batch Yield:** 6 servings

A creature eating the full banquet gains all the following benefits until its next Long Rest:

- +1 to saving throws;
- Temporary Hit Points equal to five times its Proficiency Bonus;
- Resistance to one damage type chosen from acid, cold, fire, lightning, poison, radiant, or necrotic;
- Advantage on one skill chosen when the banquet is served.

A creature can benefit from only one Sovereign Dao Banquet at a time.

---

## 50. Imperial Feast of Returning Spring
*Spirit Wines and Medicinal Foods, Imperial Treasure*

**Sphere Influences:** Alchemy, Life, Verdant Growth, Medicine  
**Activation:** Consume during a Long Rest  
**Tags:** Saturating, Feast, Imperial Restoration  
**Standard Batch Yield:** 6 servings

A creature eating the feast regains all Hit Points and Hit Dice, removes two levels of Exhaustion, and ends all poisons, diseases, and non-Immortal effects imposing Blinded, Charmed, Deafened, Frightened, Paralyzed, or Stunned.

For the next 24 hours, its Hit Point maximum increases by five times its Proficiency Bonus.

A creature can benefit from this feast only once per month.

---

# Poisons

## 51. Numbing Needle Venom
*Poisons, Spiritual Treasure*

**Sphere Influences:** Poison, Pressure Points, Alchemy  
**Activation:** Bonus Action to apply  
**Tags:** Injury Poison  
**Standard Batch Yield:** 3 doses

Apply one dose to one weapon or up to three pieces of ammunition. The poison remains potent for 1 minute or until it damages a creature.

The first creature damaged makes a DC 13 Constitution saving throw. On a failed save, it takes `3d6` poison damage and cannot take Reactions until the end of its next turn. On a successful save, it takes half damage.

---

## 52. Sleep-Lotus Extract
*Poisons, Spiritual Treasure*

**Sphere Influences:** Poison, Dreams, Alchemy  
**Activation:** Bonus Action to apply or Action to administer  
**Tags:** Injury or Ingested Poison  
**Standard Batch Yield:** 3 doses

A creature exposed to the poison makes a DC 13 Constitution saving throw.

On a failed save, it is Poisoned for 1 minute. While Poisoned this way, its Speed is halved. If it fails the save by 5 or more, it is also Unconscious until it takes damage or another creature uses an Action to wake it.

On a successful save, its Speed is reduced by 10 feet until the end of its next turn.

---

## 53. Meridian-Stiffening Oil
*Poisons, Spiritual Treasure*

**Sphere Influences:** Poison, Pressure Points, Ice  
**Activation:** Bonus Action to apply  
**Tags:** Contact or Injury Poison  
**Standard Batch Yield:** 3 doses

A creature exposed to the oil makes a DC 13 Constitution saving throw.

On a failed save, its Speed is reduced by 15 feet and it cannot Dash for 1 minute. At the end of each of its turns, it repeats the save, ending the effect on a success.

On a successful initial save, its Speed is reduced by 5 feet until the end of its next turn.

---

## 54. Spirit-Beast Hunter Toxin
*Poisons, Spiritual Treasure*

**Sphere Influences:** Poison, Predator, Beastmastery  
**Activation:** Bonus Action to apply  
**Tags:** Injury Poison  
**Standard Batch Yield:** 3 doses

Apply one dose to one weapon or up to three pieces of ammunition for 1 minute.

A Beast or Monstrosity damaged by the coated attack takes an additional `4d6` poison damage and makes a DC 13 Constitution saving throw. On a failed save, it cannot regain Hit Points until the start of the attacker's next turn.

Other creature types take `2d6` poison damage and make no saving throw.

---

## 55. Truth-Loosening Draught
*Poisons, Spiritual Treasure*

**Sphere Influences:** Poison, Karma, Beauty  
**Activation:** Action to administer  
**Tags:** Ingested Poison  
**Standard Batch Yield:** 3 doses

A creature ingesting the draught makes a DC 13 Constitution saving throw.

On a failed save, it is Poisoned for 1 hour. While Poisoned this way, it has Disadvantage on Charisma (Deception) checks and must succeed on a DC 13 Charisma saving throw to knowingly speak a direct factual lie.

The draught does not compel speech, expose omissions, or reveal objective truth.

---

## 56. Ghost-Scorch Resin
*Poisons, Saint Treasure*

**Sphere Influences:** Poison, Spirit, Radiance  
**Activation:** Bonus Action to apply  
**Tags:** Spirit Injury Coating  
**Standard Batch Yield:** 3 doses

Apply one dose to one weapon or up to three pieces of ammunition for 1 minute.

When the coated weapon damages an Undead, possessing entity, summoned spirit, or incorporeal creature, it deals an additional `5d8` radiant damage.

The target makes a DC 15 Charisma saving throw. On a failed save, it cannot become Invisible, possess a creature, or move through solid objects until the end of its next turn.

Against other targets, the resin has no effect.

---

## 57. Qi-Draining Black Venom
*Poisons, Saint Treasure*

**Sphere Influences:** Poison, Drain, Qiweaving  
**Activation:** Bonus Action to apply  
**Tags:** Injury Poison  
**Standard Batch Yield:** 3 doses

A creature damaged by the coated weapon makes a DC 15 Constitution saving throw.

On a failed save, it takes `4d8` poison damage, loses expended or available CP, Stamina, or Resonance equal to its Proficiency Bonus, and cannot regain that resource until the end of its next turn.

On a successful save, it takes half damage and loses no resource.

This poison cannot reduce a resource below 0.

---

## 58. Hundred-Ache Contact Poison
*Poisons, Saint Treasure*

**Sphere Influences:** Poison, Disease, Pressure Points  
**Activation:** Action to spread over a 5-foot square or object  
**Tags:** Contact Poison  
**Standard Batch Yield:** 3 doses

The poison remains active for 1 hour.

A creature touching the treated surface with bare skin makes a DC 15 Constitution saving throw.

On a failed save, it takes `5d6` poison damage and is Poisoned for 1 minute. While Poisoned this way, it has Disadvantage on Strength and Dexterity ability checks. At the end of each of its turns, it repeats the save, ending the condition on a success.

A successful save halves the damage.

---

## 59. Sovereign Soul-Corrosion Poison
*Poisons, Sovereign Treasure*

**Sphere Influences:** Poison, Soul, Death  
**Activation:** Bonus Action to apply  
**Tags:** Injury or Spirit Poison  
**Standard Batch Yield:** 1 dose

The first creature damaged by the treated weapon makes a DC 17 Charisma saving throw.

On a failed save, it takes `8d8` psychic damage, is Stunned until the end of its next turn, and cannot regain Hit Points until then.

On a successful save, it takes half damage and is not Stunned.

Undead, possessing entities, and incorporeal spirits make the saving throw with Disadvantage. A creature without a soul or animating spirit is immune.

---

## 60. Imperial Emperor-Killing Venom
*Poisons, Imperial Treasure*

**Sphere Influences:** Poison, Death, Blood  
**Activation:** Bonus Action to apply  
**Tags:** Imperial Injury Poison  
**Standard Batch Yield:** 1 dose

The first creature damaged by the treated weapon makes a DC 19 Constitution saving throw.

On a failed save, it takes `10d10` poison damage and `10d10` necrotic damage. Its Hit Point maximum is reduced by the necrotic damage taken until it completes three Long Rests or receives an Imperial restoration.

On a successful save, it takes half damage and its maximum is not reduced.

If the target is immune to poison, it treats that Immunity as Resistance against this dose. Immortal creatures use their normal Immunity.

---

# Formation Consumables

## 61. Alert Boundary Stake Kit
*Formation Consumables, Spiritual Treasure*

**Sphere Influences:** Formations, Trap, Sound  
**Activation:** 10-minute Setup  
**Tags:** Formation Kit, Prepared Array  
**Standard Batch Yield:** 1 kit

Place three Nodes and one Eye to define a 20-foot-radius area for 8 hours.

When a Tiny or larger creature crosses the boundary without speaking the chosen password, the Eye emits a clear tone audible within 300 feet.

The Nodes have AC 13 and 10 Hit Points. The Eye has AC 13 and 15 Hit Points. Destroying two Nodes or the Eye collapses the array.

---

## 62. Mist-Hiding Array Plates
*Formation Consumables, Spiritual Treasure*

**Sphere Influences:** Formations, Illusion, Water  
**Activation:** 10-minute Setup  
**Tags:** Formation Kit, Concealment  
**Standard Batch Yield:** 1 kit

Place three plates and one Eye around a 20-foot-radius area for 8 hours.

From outside the area, creatures and objects within appear obscured by ordinary mist, granting Three-Quarters Cover against visual observation and ranged attacks passing through the boundary.

The mist does not obscure vision from inside and does not block sound.

The Nodes have AC 13 and 10 Hit Points. The Eye has AC 13 and 15 Hit Points.

---

## 63. Spirit-Gathering Rest Array Mat
*Formation Consumables, Spiritual Treasure*

**Sphere Influences:** Formations, Qiweaving, Life  
**Activation:** 10-minute Setup  
**Tags:** Formation Kit, Rest  
**Standard Batch Yield:** 1 kit

Unfold the mat and place three jade Nodes around a 15-foot-radius area for one Short Rest.

Up to six creatures completing the rest inside can reroll one Hit Die spent during the rest and must use the new result.

A creature meditating instead of spending Hit Dice has Advantage on one cultivation or circulation check made during the rest.

The array does not restore CP, grant training time, or function during a Long Rest.

---

## 64. Firebreak Array Tiles
*Formation Consumables, Spiritual Treasure*

**Sphere Influences:** Formations, Water, Protection  
**Activation:** Action  
**Tags:** Formation Kit, Combat Array  
**Standard Batch Yield:** 1 kit

Throw the Eye to a point within 30 feet, creating a 10-foot-radius array for 1 minute. The Eye has AC 13 and 15 Hit Points.

Creatures in the area have Resistance to fire damage. Ordinary flames entering the area are extinguished.

A magical fire effect entering or appearing in the area is suppressed until the start of its creator's next turn if its creator fails an ability check against DC 13.

---

## 65. Minor Binding Array Flags
*Formation Consumables, Spiritual Treasure*

**Sphere Influences:** Formations, Chains, Earth  
**Activation:** Action  
**Tags:** Formation Kit, Combat Array  
**Standard Batch Yield:** 1 kit

Throw three flags and an Eye to create a 10-foot-radius array centered on a point within 30 feet for 1 minute. The Eye has AC 13 and 15 Hit Points.

A hostile creature entering the area for the first time on a turn or starting its turn there makes a DC 13 Strength saving throw.

On a failed save, its Speed becomes 0 until the start of its next turn. On a successful save, the area is Difficult Terrain for it until then.

---

## 66. Five-Phase Shelter Array
*Formation Consumables, Saint Treasure*

**Sphere Influences:** Formations, Five-Phase, Protection  
**Activation:** 10-minute Setup  
**Tags:** Formation Kit, Prepared Array  
**Standard Batch Yield:** 1 kit

Choose acid, cold, fire, lightning, or poison during setup. Place three Nodes and one Eye to protect a 30-foot-radius area for 8 hours.

Creatures and objects inside have Resistance to the chosen damage type.

The Nodes have AC 15 and 25 Hit Points. The Eye has AC 15 and 40 Hit Points. Destroying two Nodes or the Eye collapses the array.

---

## 67. Twin-Gate Transit Array Plates
*Formation Consumables, Saint Treasure*

**Sphere Influences:** Formations, Space, Gates  
**Activation:** 10-minute Setup at each end  
**Tags:** Formation Kit, Gate Pair  
**Standard Batch Yield:** 1 paired kit

Place one plate at each of two fixed locations on the same plane within 10 miles.

For 8 hours, a willing creature adjacent to one plate can use an Action to teleport to the nearest unoccupied space adjacent to the other.

The pair transports up to twenty creatures or 5,000 pounds of unattended cargo before collapsing.

Each plate has AC 15 and 40 Hit Points. A sealed spatial boundary prevents transit.

---

## 68. Formation-Breaking Spike Set
*Formation Consumables, Saint Treasure*

**Sphere Influences:** Formations, Force, Qiweaving  
**Activation:** Action  
**Tags:** Formation Kit, Disruption  
**Standard Batch Yield:** 1 set of 3 spikes

Drive or throw one spike into the space of a visible Formation Node, Eye, or Anchor within 30 feet.

Make a formation-breaking check with a +7 modifier against the formation's save DC.

On a success, the component is suppressed until the end of your next turn. On a success by 5 or more, it is suppressed for 1 minute.

A spike is consumed after the check. Suppressing an Eye suspends the formation without destroying it.

---

## 69. Nine-Palace Battlefield Disk
*Formation Consumables, Sovereign Treasure*

**Sphere Influences:** Formations, Space, Strategy  
**Activation:** Action  
**Tags:** Formation Kit, Greater Combat Array  
**Standard Batch Yield:** 1 disk

Place the disk at a point within 60 feet to create a 40-foot-radius array for 1 minute. The Eye has AC 17 and 75 Hit Points.

The array divides its area into nine equal symbolic palaces.

When a hostile creature moves from one palace into another, it must succeed on a DC 17 Wisdom saving throw. On a failed save, it returns to the last unoccupied space it occupied in the previous palace, and its Speed becomes 0 until the end of the turn.

Allies can move between palaces normally and gain Half Cover while adjacent to a palace boundary.

---

## 70. Heaven-Earth Rewriting Array Core
*Formation Consumables, Immortal Artifact*

**Sphere Influences:** Formations, Dao, World  
**Activation:** 1-hour Setup  
**Tags:** Formation Kit, Immortal Grand Array  
**Standard Batch Yield:** 1 core

Install the Core, eight Nodes, and one Eye to create a 1-mile-radius array for 24 hours.

Choose one temporary law:

- creatures cannot teleport or cross planes;
- natural weather remains calm;
- hostile summoned creatures are suppressed;
- all creatures can breathe;
- gravity becomes normal and stable;
- one non-Immortal environmental corruption is suppressed.

The Eye has AC 21 and 300 Hit Points. Each Node has AC 21 and 200 Hit Points. Destroying four Nodes or the Eye collapses the array.

An Immortal effect can resist the temporary law with an opposed ability check against DC 21. The array cannot create permanent world laws.

---

# Single-Use Escape Treasures

## 71. Smoke-Step Escape Bead
*Single-Use Escape Treasures, Spiritual Treasure*

**Sphere Influences:** Smoke, Athletics, Shadow  
**Activation:** Bonus Action  
**Tags:** Escape, Obscurement  
**Standard Batch Yield:** 1 bead

Crush the bead to create a 10-foot-radius sphere of Heavy Obscurement centered on you until the start of your next turn.

You can immediately move up to half your Speed without provoking Opportunity Attacks.

A strong wind disperses the smoke.

---

## 72. Earth-Passing Jade Shard
*Single-Use Escape Treasures, Spiritual Treasure*

**Sphere Influences:** Earth, Space, Equipment  
**Activation:** Action  
**Tags:** Escape, Earth Passage  
**Standard Batch Yield:** 1 shard

Touch a nonmagical stone, earth, or brick barrier no more than 5 feet thick.

You teleport to the nearest unoccupied space directly on the opposite side. If no such space exists within 10 feet, the shard fails but is not consumed.

The shard cannot cross metal, magical barriers, Formation boundaries, or worked material reinforced by a supernatural effect.

---

## 73. River-Current Escape Token
*Single-Use Escape Treasures, Spiritual Treasure*

**Sphere Influences:** Water, Flowing River, Space  
**Activation:** Bonus Action  
**Tags:** Escape, Water  
**Standard Batch Yield:** 1 token

While touching a body of liquid at least 5 feet across, crush the token to teleport to an unoccupied space touching the same connected body of liquid within 60 feet.

You need not see the destination, but you must know its direction. If no legal space exists, the token fails but is not consumed.

---

## 74. Featherfall Escape Charm
*Single-Use Escape Treasures, Spiritual Treasure*

**Sphere Influences:** Air, Athletics, Talismans  
**Activation:** Reaction when you fall  
**Tags:** Escape, Reaction  
**Standard Batch Yield:** 1 charm

You and up to five falling creatures within 30 feet descend at 60 feet per round until landing.

Affected creatures take no falling damage and land on their feet if not Incapacitated.

The charm ends for a creature when it lands.

---

## 75. Beast-Decoy Skin Doll
*Single-Use Escape Treasures, Spiritual Treasure*

**Sphere Influences:** Illusion, Beastmastery, Shadow  
**Activation:** Reaction when a creature targets you with an attack  
**Tags:** Escape, Decoy, Reaction  
**Standard Batch Yield:** 1 doll

Create an illusory duplicate in your space and move up to 10 feet without provoking Opportunity Attacks from the attacker.

The triggering attack targets the duplicate instead and automatically misses you unless the attacker can perceive through illusions.

The duplicate disappears after the attack resolves.

---

## 76. Void-Step Jade Shard
*Single-Use Escape Treasures, Saint Treasure*

**Sphere Influences:** Space, Shadow, Talismans  
**Activation:** Bonus Action  
**Tags:** Escape, Teleportation  
**Standard Batch Yield:** 1 shard

Teleport up to 90 feet to an unoccupied space you can see.

Until the start of your next turn, attacks made against you from more than 30 feet away have Disadvantage.

A sealed spatial boundary can prevent the teleportation.

---

## 77. Thousand-Li Return Seal
*Single-Use Escape Treasures, Saint Treasure*

**Sphere Influences:** Space, Talismans, Source  
**Activation:** 1-minute Rite  
**Tags:** Escape, Long-Range Return  
**Standard Batch Yield:** 1 seal

During a prior 10-minute rite, register one fixed return point.

Activate the seal to teleport yourself and up to five willing creatures within 10 feet to unoccupied spaces within 30 feet of the registered point, provided it is on the same plane and within 100 miles.

A sealed spatial boundary, moving destination, or occupied arrival area causes the seal to fail without being consumed.

---

## 78. Thunder-Shell Substitution Doll
*Single-Use Escape Treasures, Saint Treasure*

**Sphere Influences:** Lightning, Talismans, Puppetry  
**Activation:** Reaction when you are hit by an attack  
**Tags:** Escape, Substitution, Reaction  
**Standard Batch Yield:** 1 doll

Reduce the triggering damage to 0 and teleport up to 30 feet to an unoccupied space you can see.

The doll appears in your former space and explodes. Creatures within 5 feet make a DC 15 Dexterity saving throw, taking `4d8` lightning damage on a failed save or half as much on a successful save.

The doll cannot negate damage from an Immortal effect.

---

## 79. Life-Saving Golden Cicada
*Single-Use Escape Treasures, Sovereign Treasure*

**Sphere Influences:** Life, Space, Fate  
**Activation:** No action when you would drop to 0 Hit Points  
**Tags:** Escape, Death Prevention  
**Standard Batch Yield:** 1 cicada

You drop to 1 Hit Point instead.

You then teleport, with all worn and carried equipment, to an unoccupied space within 1 mile that you designated when you last completed a Long Rest.

You become Invisible and Incapacitated until the end of your next turn. The invisibility ends early if you take damage.

The cicada cannot function across a sealed spatial boundary or against an effect that kills without reducing Hit Points.

---

## 80. Imperial Boundary-Breaking Escape Order
*Single-Use Escape Treasures, Imperial Treasure*

**Sphere Influences:** Space, Authority, Sealing  
**Activation:** Action  
**Tags:** Escape, Imperial Transit  
**Standard Batch Yield:** 1 order

Choose one location on the same plane that you have personally visited.

You and up to twenty willing creatures within 30 feet teleport to unoccupied spaces within 100 feet of that location.

The order ignores non-Imperial teleportation barriers. Against an Imperial barrier, make an ability check with a +11 modifier against its save DC. On a failure, the order is not consumed.

The order cannot cross planes, enter a location sealed by an Immortal effect, or arrive inside solid matter.

---

# Disposable Ammunition and Weapon Coatings

## 81. Flame-Tongue Weapon Oil
*Disposable Ammunition and Weapon Coatings, Spiritual Treasure*

**Sphere Influences:** Alchemy, Fire, Weapons  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating  
**Standard Batch Yield:** 3 applications

One application coats one weapon or up to three pieces of ammunition for 1 minute.

Each qualifying hit deals an additional `1d6` fire damage.

The coating ends after three hits or when the duration expires.

---

## 82. Frostbite Edge Oil
*Disposable Ammunition and Weapon Coatings, Spiritual Treasure*

**Sphere Influences:** Alchemy, Ice, Weapons  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating  
**Standard Batch Yield:** 3 applications

One application coats one weapon or up to three pieces of ammunition for 1 minute.

Each qualifying hit deals an additional `1d4` cold damage and reduces the target's Speed by 5 feet until the start of the attacker's next turn. This Speed reduction stacks to a maximum of 10 feet.

The coating ends after three hits or when the duration expires.

---

## 83. Thunderburst Ammunition
*Disposable Ammunition and Weapon Coatings, Spiritual Treasure*

**Sphere Influences:** Lightning, Weapons, Alchemy  
**Activation:** Used as ammunition  
**Tags:** Disposable Ammunition  
**Standard Batch Yield:** 5 pieces

When this ammunition hits, the target takes an additional `2d6` lightning damage.

If the target is wearing metal armor or made primarily of metal, the additional damage becomes `3d6`.

The ammunition is destroyed after the attack, whether it hits or misses.

---

## 84. Ghost-Touch Lacquer
*Disposable Ammunition and Weapon Coatings, Spiritual Treasure*

**Sphere Influences:** Spirit, Weapons, Alchemy  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating  
**Standard Batch Yield:** 3 applications

One application coats one weapon or up to three pieces of ammunition for 1 minute.

Attacks made with the coated weapon count as magical, can damage incorporeal creatures normally, and deal an additional `1d6` force damage to Undead, possessing entities, and incorporeal spirits.

The coating ends after three hits or when the duration expires.

---

## 85. Armor-Eating Acid Varnish
*Disposable Ammunition and Weapon Coatings, Spiritual Treasure*

**Sphere Influences:** Acid, Weapons, Destruction  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating  
**Standard Batch Yield:** 3 applications

One application coats one weapon or up to three pieces of ammunition for 1 minute.

Hits deal an additional `1d6` acid damage. Against Constructs, unattended objects, structures, armor treasures, Formation Nodes, and Array Eyes, the acid damage is maximized.

The coating ends after three hits or when the duration expires.

---

## 86. Soul-Piercing Needle Set
*Disposable Ammunition and Weapon Coatings, Saint Treasure*

**Sphere Influences:** Spirit, Piercing Needle, Weapons  
**Activation:** Used as thrown ammunition  
**Tags:** Disposable Ammunition, Needles  
**Standard Batch Yield:** 5 needles

A needle has a normal range of 30 feet and a long range of 90 feet. Make a ranged consumable attack with a +7 modifier.

On a hit, the target takes `3d8` piercing damage and `3d8` psychic damage.

An Undead, possessing entity, or incorporeal spirit must also succeed on a DC 15 Charisma saving throw or be unable to become Invisible or move through solid objects until the end of its next turn.

The needle is destroyed after the attack.

---

## 87. Formation-Breaking Arrowheads
*Disposable Ammunition and Weapon Coatings, Saint Treasure*

**Sphere Influences:** Formations, Force, Weapons  
**Activation:** Used as ammunition  
**Tags:** Disposable Ammunition, Anti-Formation  
**Standard Batch Yield:** 5 pieces

When the ammunition hits a Formation Node, Eye, Anchor, magical barrier, or object created by a supernatural effect, it deals an additional `5d6` force damage.

The attack ignores Resistance possessed by that object, but not Immunity.

If the object is reduced to 0 Hit Points, its linked effect ends immediately unless its own rules state otherwise.

The ammunition is destroyed after the attack.

---

## 88. Void-Nail Weapon Coating
*Disposable Ammunition and Weapon Coatings, Saint Treasure*

**Sphere Influences:** Space, Sealing, Weapons  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating, Anti-Teleportation  
**Standard Batch Yield:** 3 applications

One application coats one weapon or up to three pieces of ammunition for 1 minute.

A creature hit by the coated weapon takes an additional `2d8` force damage and cannot teleport or travel between planes until the start of the attacker's next turn.

The coating ends after three hits or when the duration expires.

---

## 89. Calamity-Fletched Ammunition
*Disposable Ammunition and Weapon Coatings, Sovereign Treasure*

**Sphere Influences:** Lightning, Tribulation, Weapons  
**Activation:** Used as ammunition  
**Tags:** Disposable Ammunition, Calamity  
**Standard Batch Yield:** 5 pieces

When the ammunition hits, the target takes an additional `6d8` lightning damage and `2d8` thunder damage.

The target must succeed on a DC 17 Constitution saving throw or be unable to take Reactions and have Disadvantage on the next saving throw it makes before the end of its next turn.

The ammunition is destroyed after the attack.

---

## 90. Imperial Heaven-Splitting Weapon Oil
*Disposable Ammunition and Weapon Coatings, Imperial Treasure*

**Sphere Influences:** Force, Metal, Weapons, Dao  
**Activation:** Bonus Action to apply  
**Tags:** Weapon Coating, Imperial  
**Standard Batch Yield:** 1 application

Coat one weapon for 1 minute.

Each hit deals an additional `4d8` force damage and ignores Resistance to bludgeoning, piercing, slashing, and force damage.

Against an unattended object, structure, Formation component, or magical barrier, the additional force damage becomes `8d8` and is maximized.

The oil ends after three hits or when the duration expires.

---

# Final Consumable Record

Every new consumable must state:

- name;
- family;
- grade;
- Sphere Influences;
- Formula access;
- tools and facility;
- material cost;
- batch yield;
- crafting time;
- activation;
- target, range, and area;
- attack or save;
- successful-save result;
- duration;
- Concentration;
- Saturating, Toxic, Formation, Reaction, or Coating tags;
- whether the object is consumed on attempted use or successful use;
- interaction with Attunement, storage, permanent treasures, and other consumables.

# Final Audit Checklist

A consumable is incomplete if it lacks any mechanic needed at the table.

Check that:

- Alchemy does not create ingredients;
- Talismans remain formula-bound written commands;
- Formations use Eyes, Nodes, and breakable place-based geometry;
- reaction consumables require readiness;
- internal enhancement consumables use Saturation when appropriate;
- poisons state delivery and successful-save results;
- storage, time, resurrection, planar travel, and Immortal effects have explicit limits;
- no consumable grants a Sphere, Talent, Method, Foundation, Insight, Realm, or automatic breakthrough;
- no consumable bypasses Tribulations or normal training;
- market prices, batch yield, crafting time, and activation are recorded;
- identical effects do not stack without explicit permission.


# Chapter 6: Growth Treasures and Item Spirits
*Compact Advancement, Awakening, Bond, and Restoration Rules v0.1*

Some treasures are finished objects. Others are vessels with room to become more.

A **Growth Treasure** can advance through compatible materials, spirit stones, refinement milestones, bearer achievements, tribulations, and spiritual awakening. Its history becomes part of its construction.

An **Item Spirit** is a spirit whose vessel is a treasure. It has a Spirit Nature, desires, offerings, taboos, memories, and increasing degrees of will. Awakening does not automatically turn the treasure into a second player character or a free combat companion.

This chapter applies to weapons, armor, shields, Wondrous Treasures, Dao vessels, sect treasures, vehicles, and infrastructure explicitly designated as Growth Treasures.

---

# Core Boundaries

## Growth Is Not Automatic Level Scaling

A Growth Treasure does not advance merely because its bearer gains Cultivation Levels.

Advancement requires:

- sufficient refinement materials;
- a compatible vessel;
- the required bearer or sponsor CL;
- one or more completed milestones;
- a refinement rite;
- enough open enchantment capacity;
- the treasure spirit's consent once it has become self-aware.

A Growth Treasure can remain at a lower grade indefinitely.

## A Spirit Nature Does Not Grant Spheres

An item spirit can possess a Nature aligned with Fire, Sword, Spirit, Dreams, Water, Formations, or another legal Sphere.

That Nature permits the spirit's printed expressions. It does not grant the bearer ownership of that Sphere, its Talents, its prerequisites, or unrestricted access to its effects.

Every Nature Expression must be written as a complete item property, action, reaction, ritual, or companion ability.

## Item Spirits and Spirit Companions

Item spirits follow the relationship principles of the Spirit Companions Sphere:

- the spirit has its own Nature;
- offerings and taboos matter;
- the bond can suffer strain;
- a spirit can be hosted or bound in a vessel;
- self-aware spirits can consent, negotiate, or refuse;
- binding does not erase personhood.

An item spirit is not automatically a full combat-capable bonded companion.

Unless a rule explicitly upgrades it:

- it has no separate creature stat block;
- it occupies no space apart from its vessel;
- it does not roll Initiative;
- it takes no independent turn;
- it makes no ordinary attacks;
- it uses only the item's printed Instincts and properties.

A spirit that becomes an **Independent Spirit-Life** uses the campaign's bonded-companion or creature rules for its body, command economy, attacks, Realm Evolutions, damage, death, and restoration.

---

# The Growth Treasure Record

Every Growth Treasure records the following fields.

| Field | Required Information |
|---|---|
| **Treasure Identity** | Name, item type, current grade, and Attunement slots |
| **Core Principle** | The single coherent Dao, function, or concept defining its growth |
| **Primary Material** | Material property, affinity, ceiling, and repair profile |
| **Core Expression** | The existing property most central to the treasure |
| **Current Capacity** | Enchantment capacity and occupied Equivalent Bonus |
| **Growth Reserve** | Compatible value already fed toward the next grade |
| **Milestones** | Completed deeds, insights, catalysts, tribulations, and recognitions |
| **Awakening Tier** | Dormant, Instinct, Weapon Soul, Item Spirit, or Independent Spirit-Life |
| **Spirit Nature** | Name, affinities, desire, offering, taboo, authority, and expressions |
| **Recognition State** | Hostile, Unrecognized, Accepted, Loyal, or United |
| **Bond Strain** | 0–3 |
| **Damage State** | Intact, Broken, Destroyed with Core, or Core Lost |
| **Bonded Bearer** | Current bearer and any lineage, sect, oath, or Path requirement |

A treasure without a conscious spirit can omit the Spirit Nature, Recognition, and Bond Strain fields.

---

# Growth Reserve and Feeding

## Feeding Rite

A Growth Treasure absorbs materials through an **8-hour Feeding Rite** performed outside immediate danger.

The rite requires:

- the treasure;
- compatible special materials or spirit stones;
- appropriate tools or a refinement facility;
- one creature overseeing the process.

The consumed value becomes the treasure's **Growth Reserve**.

A treasure can undergo one Feeding Rite per day. It cannot store more Growth Reserve than required for its next grade. Excess material is not consumed.

## Compatible Materials

A material is compatible when it shares an affinity with the treasure's Core Principle, Primary Material, Core Expression, or Spirit Nature.

Compatible special materials contribute their full rules value.

Generic spirit stones also contribute their full rules value, but at least half of the Growth Reserve required for a grade advancement must come from compatible special materials, named catalysts, or milestone rewards rather than generic currency.

## Neutral and Opposed Materials

A neutral special material contributes half its rules value.

An opposed material contributes nothing unless a formula explicitly reconciles the conflict through a stabilizing Secondary Material.

Feeding an opposed material to a self-aware spirit without its consent adds 1 Bond Strain and leaves the material unconsumed.

## Devouring Growth

A treasure with a printed Devouring, Calamity-Hungry, Blood-Drinking, Furnace, or similar property can gain Growth Reserve through its stated method.

Such a property must define:

- eligible sources;
- value conversion;
- maximum reserve gained per scene, day, or project;
- forbidden sources;
- whether creatures, souls, treasures, or materials are destroyed;
- consequences for corruption or overfeeding.

No treasure gains unlimited value merely by dealing damage or destroying trivial objects.

---

# Grade Advancement

## Advancement Requirements

| Advancement | Minimum Sponsor CL | Growth Reserve | Required Milestones | Minimum Facility |
|---|---:|---:|---:|---|
| Mortal → Spiritual | 1 | 2 Low-Grade Spirit Stones | 1 | Suitable mundane workshop |
| Spiritual → Saint | 5 | 2 Mid-Grade Spirit Stones | 1 | Spiritual-grade facility |
| Saint → Sovereign | 10 | 2 High-Grade Spirit Stones | 2 | Saint-grade facility |
| Sovereign → Imperial | 15 | 1 Perfect Spirit Stone | 3 | Sovereign-grade facility |
| Imperial → Immortal | 20+ | Unique; no standard value | 4+ and a campaign gate | Unique Immortal site or procedure |

The sponsor is normally the bearer, crafter, sect, lineage, or spirit responsible for the advancement.

The treasure's material ceiling must support the target grade. Exceeding that ceiling requires a special formula, compatible ceiling-raising material, item-spirit evolution, tribulation refinement, or campaign exception.

## Refinement Milestones

A milestone is a meaningful change in the treasure's history.

Common milestone families include:

### Deed

The treasure accomplishes a significant act expressing its Core Principle.

Examples:

- a guardian treasure protects a settlement;
- a sword defeats a stronger foe through its defining technique;
- a healing vessel saves a lineage during a plague;
- a formation core holds during a siege.

### Insight

The bearer, crafter, or spirit gains a relevant Dao Insight, completes a comprehension trial, or resolves a contradiction in the Core Principle.

### Catalyst

The treasure integrates a named material, ancestral fragment, spirit core, tribulation remnant, broken treasure, or unique component.

### Tribulation

The treasure survives and meaningfully participates in a breakthrough, calamity, heavenly punishment, world event, or refinement disaster appropriate to the intended grade.

### Recognition

A spirit accepts a bearer, a lineage recognizes an heir, an ancestral oath is fulfilled, or an existing Item Spirit willingly chooses a new stage of being.

## Milestone Scale

A trivial, repeated, or deliberately staged event is not a milestone.

The event should be important enough that the treasure's future description would mention it.

The same deed cannot satisfy more than one required milestone unless a campaign rule explicitly designates it as a singular world-level event.

## Refinement Rite

After the Growth Reserve and milestones are complete, perform the target grade's normal crafting time as a refinement rite.

When every required component is present, the rite succeeds without a check.

Make a refinement check only when:

- the rite is rushed;
- materials are substituted;
- the facility is insufficient;
- the material ceiling is exceeded;
- an unwilling spirit is forced;
- opposed principles are combined;
- the advancement is forbidden, unstable, or experimental.

Use the crafting and failure-forward rules from Chapter 1.

## Advancement Results

On a successful grade advancement:

1. Increase the treasure to the target grade.
2. Apply the target grade's Refinement Bonus, Armor Refinement Bonus, or other grade statistic.
3. Increase its enchantment capacity to the target grade.
4. Empty its Growth Reserve.
5. Record the completed milestones in its permanent history.
6. Choose one **Growth Reward** authorized by the formula or GM.
7. Recalculate Attunement and awakening requirements.

Grade advancement does not automatically fill new enchantment capacity.

---

# Growth Rewards

Choose one reward appropriate to the milestone and treasure.

## New Expression

Integrate one compatible enhancement or item property.

- It must be legal for the treasure's type and grade.
- Its Equivalent Bonus counts against capacity.
- The required formula and catalyst must be supplied unless the milestone itself explicitly grants them.
- A story-granted expression still receives an Equivalent Bonus for capacity and audit purposes.

## Deepen the Core Expression

Improve the treasure's designated Core Expression in one explicit way.

Common improvements include:

- add one damage or healing die;
- increase forced movement by 10 feet;
- increase range by 30 feet;
- increase an area by 5 feet;
- add 2 charges to a charge pool;
- improve recharge by one die step;
- reduce one printed CP cost by 1, minimum 0;
- raise a fixed save DC or attack modifier by 1, to no more than 2 above the grade's normal value;
- add one thematically compatible target or use condition;
- improve one storage, travel, construction, or cultivation capacity by 50 percent.

The improvement must remain connected to the Core Principle. It cannot convert the treasure into a collection of unrelated abilities.

## Awaken the Next Spirit Tier

Advance the treasure one Awakening Tier when it meets that tier's requirements.

## Refine the Bond

Choose one:

- establish a lineage, sect, oath, Path, or named-bearer recognition requirement;
- remove one obsolete recognition requirement with the spirit's consent;
- reduce a two-slot housed Item Spirit to one Attunement slot after reaching United recognition;
- allow an Accepted bearer to attune during a 10-minute rite;
- allow the spirit to remain in telepathic contact with its bearer while on the same plane.

## Reinforce the Vessel

Choose one:

- increase the treasure's Hit Point maximum by 50 percent;
- grant Resistance to one damage type dealt to objects;
- grant Advantage on saving throws against breaking, corrosion, suppression, or deformation;
- allow the treasure to remain functional at 1 Hit Point once per Long Rest;
- protect the spirit core from one destruction event, leaving the treasure Broken instead.

---

# Awakening Tiers

Awakening measures personhood and autonomy, not raw numerical power.

A treasure can be extremely powerful without being conscious.

| Tier | Typical Minimum Grade | Personhood | Communication | Independent Turn |
|---|---|---|---|---|
| Dormant Vessel | Any | None | None | No |
| Instinct | Sovereign | Reactive pattern | Omens and sensations | No |
| Weapon Soul or Treasure Soul | Imperial | Emerging self | Telepathy with bearer | No |
| Item Spirit | Imperial, usually after a second awakening | Fully self-aware | Speech, telepathy, manifestation | No, unless separately upgraded |
| Independent Spirit-Life | Immortal or unique story advancement | Separate person | Normal | Uses companion or creature rules |

A specific treasure can awaken earlier or later through a unique formula.

## Dormant Vessel

The treasure has no conscious spirit.

It can still have:

- charges;
- passive effects;
- command words;
- recognition inscriptions;
- a growth path;
- stored memories;
- an inherited Dao.

It cannot consent, refuse, negotiate, or form opinions.

## Instinct

An Instinct is a spiritual reflex, not a full person.

Choose one printed Instinct or design one equivalent expression.

### Guard

Once per Long Rest, when the bearer is hit by an attack, subtract `1d6` from the attack roll, potentially causing it to miss.

### Pursue

Once per Long Rest, when the bearer misses with an attack made through the treasure, reroll the attack and use the new result.

### Warn

The bearer cannot be surprised while conscious and in contact with or carrying the treasure.

### Suppress

Once per Long Rest, when the bearer fails a saving throw against Charmed, Frightened, possession, or direct control, reroll it and use the new result.

### Preserve

Once per Long Rest, when the treasure would be reduced to 0 Hit Points, it drops to 1 Hit Point instead.

An Instinct:

- cannot speak;
- cannot make decisions beyond its trigger;
- cannot violate its own printed condition;
- cannot take an independent turn;
- is lost if its spirit core is annihilated.

## Weapon Soul or Treasure Soul

A **Weapon Soul** is the weapon-specific name for an emerging Treasure Soul.

The soul:

- is self-aware;
- communicates telepathically with its attuned bearer while on the same plane;
- remembers significant events involving the treasure;
- possesses a basic personality, desire, offering, and taboo;
- can use up to two printed Instincts;
- can use one unused defensive Instinct when the bearer is Incapacitated but not dead;
- remains an item and takes no independent turn.

At this tier, the treasure always requires Attunement.

A Weapon Soul can advise, warn, object, negotiate, and refuse commands that violate its Nature or Taboo.

## Item Spirit

An Item Spirit is a fully developed person housed in a treasure.

Its Spirit Nature must be fully recorded.

The spirit can:

- speak and communicate telepathically;
- perceive through the treasure's printed senses;
- remember its history;
- form relationships;
- accept offerings;
- maintain taboos;
- recognize or reject bearers;
- activate printed Instincts and autonomous item reactions;
- manifest a harmless visible or audible avatar within 10 feet of the vessel.

A manifested avatar:

- has no separate Hit Points;
- occupies no space;
- cannot attack, manipulate objects, provide Cover, flank, or take actions;
- vanishes if more than 10 feet from the vessel;
- is a presentation of the spirit, not a combat creature.

An Item Spirit still takes no independent combat turn.

A combat-capable manifested body requires a separate property and must use the bonded-companion or creature rules.

A housed Item Spirit normally makes the treasure require **two Attunement slots**. United recognition can reduce this to one slot as a Growth Reward. A treasure cannot require fewer than one slot while housing a self-aware Item Spirit.

## Independent Spirit-Life

An Independent Spirit-Life is no longer merely a property of the object.

It is a separate person capable of existing outside the treasure.

The advancement must decide whether:

### The Treasure Is Its Body

The spirit remains a living treasure. It uses a bespoke creature or vehicle stat block, and its item properties become creature traits.

### The Treasure Is Its Residence

The spirit can enter and leave the object. While housed, the object functions as printed. While manifested, use the spirit's creature or bonded-companion rules.

### The Spirit Separates Permanently

The spirit becomes an independent being. The former treasure becomes dormant, retains reduced properties, or becomes the spirit's bonded relic as stated by the advancement.

A combat-capable Independent Spirit-Life:

- counts against the campaign's normal full bonded-companion limit when bonded to a character;
- uses the bonded-companion command economy;
- has its own durability and restoration rules;
- does not provide a free extra combat turn;
- cannot be owned as property merely because it was once an item.

An Independent Spirit-Life normally requires two Attunement slots while fully housed and granting its complete item powers. A United bond can reduce this to one. A permanently separated spirit uses the companion bond rather than an item Attunement slot unless its relic says otherwise.

---

# Spirit Nature

Every Weapon Soul, Item Spirit, or Independent Spirit-Life records a Spirit Nature.

## Required Spirit Nature Fields

### Nature Name

A concise identity such as:

- Thunder-Eating Sword Soul;
- Ancestor-General Bell;
- River-Mirror Spirit;
- Hungry Bronze Furnace;
- Ashen Funeral Moth;
- World-Seed Gardener.

### Core Concepts

Choose two to four connected concepts defining the spirit.

Examples:

- Fire, Renewal, Pride;
- Sword, Pursuit, Severance;
- Mountain, Duty, Shelter;
- Medicine, Mercy, Purification;
- Mirror, Memory, Moonlight.

### Sphere Influences

List legal Spheres informing the spirit's expressions.

These are influence tags, not bearer-granted Spheres.

### Desire

State what the spirit seeks.

Examples:

- worthy opponents;
- preservation of a lineage;
- beautiful craftsmanship;
- protection of pilgrims;
- collection of forgotten songs;
- restoration of a ruined homeland.

### Offering

State what strengthens or pleases the spirit.

Offerings can be:

- compatible materials;
- incense;
- battle trophies;
- repaired ancestral records;
- songs;
- fulfilled vows;
- service to a shrine;
- time spent teaching;
- respectful maintenance.

An Offering is not automatically consumed for Growth Reserve unless a rule says so.

### Taboo

State one or two actions the spirit will not willingly support.

Examples:

- harming surrendered foes;
- abandoning a sworn ward;
- using poison;
- destroying books;
- serving a rival lineage;
- consuming souls;
- refusing a proper burial.

### Authority

State what the spirit can recognize or judge.

Examples:

- one lineage;
- one sect office;
- one oath;
- one battlefield role;
- one craft tradition;
- one type of spirit or material.

Authority is informational unless a printed property gives it mechanics.

### Nature Expressions

List every ability the spirit can express.

Every expression requires complete mechanics and consumes item capacity when appropriate.

---

# Recognition and Loyalty

Recognition changes only after a significant event, not after every conversation or ordinary use.

| State | Effect |
|---|---|
| **Hostile** | The spirit refuses Attunement and voluntary activation. It can oppose repair, transfer, or feeding. |
| **Unrecognized** | Attunement can occur only if the treasure's non-spirit rules permit it. Spirit properties, autonomous reactions, and growth are dormant. |
| **Accepted** | The bearer can use the treasure normally. The spirit obeys requests consistent with its Nature and bond. |
| **Loyal** | The spirit can use its printed defensive Instincts without a command and cooperates with repair, transfer, and advancement. |
| **United** | Bearer and spirit act as trusted partners. United recognition can satisfy an advancement milestone and can qualify for reduced Attunement through a Growth Reward. |

## Gaining Recognition

Recognition can increase through:

- fulfilling a stated recognition condition;
- honoring offerings and taboos;
- completing a shared milestone;
- protecting the spirit or vessel;
- restoring its history;
- freeing it from coercion;
- carrying out its accepted purpose;
- a major roleplaying decision.

Recognition cannot be bought solely with spirit stones unless material offering is central to the spirit's Nature.

## Refusal

A self-aware spirit can refuse:

- a command violating its Taboo;
- use against a protected lineage, oath, place, or person;
- deliberate self-destruction without an agreed purpose;
- forced feeding with opposed materials;
- transfer into an incompatible vessel;
- use by an unrecognized bearer;
- an act that would corrupt or erase its Nature.

The spirit does not make routine refusal checks when the command is normal and consistent with the bond.

## Bond Appeal

When a bearer asks a spirit to act against a serious preference but not a fundamental Taboo, the GM can call for a Charisma check using Persuasion or another appropriate skill.

Use the spirit's grade DC:

| Grade | Bond DC |
|---|---:|
| Spiritual | 13 |
| Saint | 15 |
| Sovereign | 17 |
| Imperial | 19 |
| Immortal | 21 |

On a success, the spirit agrees for that act.

On a failure, it refuses.

Intimidation can force compliance only when the spirit is physically bound and the effect allows coercion. Forced compliance adds 1 Bond Strain after the act and cannot compel an act that would annihilate the spirit's identity.

---

# Bond Strain

Bond Strain records serious damage to the relationship.

## Gaining Strain

Add 1 Strain when the bearer:

- violates a known Taboo;
- forces a refused activation;
- feeds opposed material without consent;
- attempts involuntary transfer;
- deliberately allows preventable desecration of the vessel;
- breaks a central recognition oath;
- treats a self-aware spirit as expendable property after accepting its personhood.

## Strain Effects

| Strain | Effect |
|---:|---|
| 0 | Stable bond |
| 1 | Growth Reserve cannot be converted into advancement; the spirit can refuse optional autonomous effects |
| 2 | Spirit expressions and autonomous reactions become dormant; ordinary non-spirit item properties remain |
| 3 | Attunement ends at the next dawn; the spirit becomes Hostile, departs if able, or seals itself dormant |

## Removing Strain

Removing 1 Strain requires:

- restitution acceptable to the spirit;
- a meaningful Offering;
- repair of the violated bond;
- fulfillment of a requested task;
- release from coercive binding;
- another significant reconciliation agreed by the GM.

A simple Long Rest, gold payment, or Persuasion check does not remove Strain by itself.

---

# Attunement During Growth

## Dormant and Instinctive Treasures

Growth status alone does not add an Attunement requirement.

An Instinct uses the treasure's existing Attunement rule.

## Weapon Souls

A treasure awakening a Weapon Soul or Treasure Soul always requires Attunement and uses at least one slot.

## Item Spirits

A housed Item Spirit normally uses two Attunement slots because the bearer bonds both the treasure's power and a self-aware spirit.

United recognition can reduce this to one slot through a Growth Reward.

## Independent Spirit-Lives

A spirit fully housed in the treasure normally uses two slots.

A separately manifested full companion uses the bonded-companion rules. The treasure can continue to use an Attunement slot only if it still grants separate relic powers.

## Changing Bearers

A self-aware treasure can end Attunement voluntarily during a Short or Long Rest.

A new bearer must meet all requirements and obtain at least Accepted recognition before spirit properties awaken.

Memories, loyalties, and Strain do not reset when ownership changes.

---

# Transferring Enchantments and Expressions

## Transfer Requirements

Transferring an enchantment requires:

- a donor treasure;
- a recipient treasure;
- a transfer formula;
- appropriate tools and facility;
- recipient grade equal to or higher than the enhancement's minimum grade;
- compatible item type and chassis;
- enough open Equivalent Bonus capacity;
- compatible material affinities or a stabilizer;
- consent from a self-aware donor spirit when the expression forms part of its Nature.

## Transfer Cost and Time

A standard transfer requires:

- materials worth 25 percent of the recipient grade's normal crafting cost;
- work equal to 25 percent of the recipient grade's normal crafting time.

At completion:

- the donor loses the enchantment;
- the recipient gains it;
- the transferred Equivalent Bonus counts normally;
- charges and expended uses reset only after the recipient completes a Long Rest.

## Nontransferable Properties

The following do not transfer through ordinary procedures:

- Refinement Bonus;
- Armor Refinement Bonus;
- Primary Material properties;
- a material's refinement ceiling;
- inherent curses;
- lineage identity;
- accumulated Growth Reserve;
- completed milestones;
- a true Item Spirit;
- an Independent Spirit-Life;
- Immortal authority;
- world-scale or site-bound functions.

A specific formula can create an exception.

## Core Expressions

Removing a treasure's Core Expression:

- prevents further grade advancement;
- makes all dependent expressions dormant;
- adds 1 Bond Strain to a self-aware spirit unless it consents;
- can reduce Recognition by one state.

A new Core Expression must be integrated before growth resumes.

## Moving a Spirit Core

Moving a Weapon Soul or Item Spirit is not an enchantment transfer.

It requires:

- the spirit's consent, unless a hostile binding procedure explicitly permits force;
- a compatible recipient vessel;
- a spirit-transfer formula;
- a soul-safe facility;
- materials equal to 50 percent of the recipient's normal crafting cost;
- half the recipient's normal crafting time.

On success, the spirit retains its Nature, memories, Recognition, Strain, and awakening tier.

It does not automatically retain incompatible item expressions.

Forced transfer adds 2 Bond Strain and can never create Accepted recognition.

---

# Treasure Durability

A treasure uses its printed object statistics when available.

Otherwise, use these defaults for a portable treasure.

| Grade | AC | Hit Points |
|---|---:|---:|
| Spiritual Treasure | 15 | 20 |
| Saint Treasure | 17 | 40 |
| Sovereign Treasure | 19 | 75 |
| Imperial Treasure | 21 | 150 |
| Immortal Artifact | 23 | 300 or bespoke |

Treasures are immune to poison and psychic damage as objects. A manifested spirit can still be affected according to its own rules.

A treasure normally has Resistance to nonmagical bludgeoning, piercing, and slashing damage.

## Broken

A treasure reduced to 0 Hit Points becomes **Broken** unless the effect explicitly destroys or disintegrates it.

While Broken:

- all supernatural properties are dormant;
- it provides no Refinement Bonus or Armor Refinement Bonus;
- an Instinct cannot function;
- a Weapon Soul or Item Spirit becomes dormant but remains anchored;
- Attunement is suspended but not automatically ended.

Repairing a Broken treasure requires:

- 10 percent of its normal crafting cost;
- 10 percent of its normal crafting time;
- suitable tools and facility.

The spirit returns when repair is complete.

## Destroyed with Core

A treasure is **Destroyed with Core** when it is shattered, melted, or otherwise rendered nonrepairable but its defining core, largest principal fragment, spirit seed, or world-heart remains.

Reconstruction requires:

- 50 percent of its normal crafting cost;
- half its normal crafting time;
- the original core;
- a compatible vessel formula;
- all required permissions.

The reconstructed treasure retains its grade, milestones, and spirit unless the destruction effect specifically damaged them.

## Core Lost

The core is lost when it is disintegrated, consumed, soul-destroyed, erased, or damaged by an effect explicitly capable of destroying it.

Consequences depend on awakening tier.

### Dormant Vessel

The treasure is destroyed. Recreating it produces a new treasure without its history or milestones unless a backup record or special restoration exists.

### Instinct

The Instinct is lost. It was a spiritual pattern rather than an independent person.

### Weapon Soul or Treasure Soul

The soul persists for 30 days within the largest surviving compatible fragment.

During that time, it can communicate telepathically with an Accepted or better bearer within 30 feet but cannot activate properties.

A spirit-transfer rite or reconstruction can preserve it.

After 30 days without a vessel or spirit shelter, it disperses unless another rule preserves it.

### Item Spirit

The spirit persists disembodied for one year.

It can faintly manifest and communicate within 30 feet of its remains, shrine, recognized bearer, or spirit shelter but has no combat abilities.

It can enter a compatible spirit residence or new vessel through a spirit-transfer rite.

### Independent Spirit-Life

Destroying the vessel does not automatically destroy the spirit.

Use its creature or bonded-companion rules for damage, death, and restoration. The former vessel's destruction can remove powers tied to that vessel until it is rebuilt.

---

# Corruption, Possession, and Replacement

An outside spirit cannot simply overwrite an existing Item Spirit.

A hostile possession or spirit-merger procedure must state:

- the opposed checks or saving throws;
- what happens to each identity;
- whether memories merge;
- whether one spirit is suppressed;
- how the effect ends;
- what happens to Recognition and Strain;
- whether the result is a new Spirit Nature.

A failed hostile merger can damage the vessel, add Strain, create a curse, or release one or both spirits.

A spirit's personhood cannot be erased merely to create a cheaper enhancement unless the procedure is explicitly presented as forbidden destruction.

---

# Compact Growth Procedure

Use this sequence whenever a Growth Treasure advances.

1. **Confirm the Core Principle.**
2. **Confirm the target grade and material ceiling.**
3. **Complete the required milestones.**
4. **Feed the required Growth Reserve.**
5. **Obtain spirit consent, if self-aware.**
6. **Perform the refinement rite.**
7. **Apply the target grade statistics.**
8. **Choose one Growth Reward.**
9. **Update capacity, Attunement, Recognition, and Spirit Nature.**
10. **Write every new expression in full.**

---

# Worked Example: Storm-Iron Flying Thunder Jian

The Storm-Iron Flying Thunder Jian begins as a Saint Treasure with:

- Jian weapon chassis;
- Storm Iron Primary Material;
- +2 Refinement Bonus;
- +3 enchantment capacity;
- Thunder-Conducting Inscription +1;
- Flying Sword Command +2;
- no spirit.

## Growth Goal

Advance it to a Sovereign Treasure and awaken an Instinct.

## Requirements

- Sponsor CL 10 or higher.
- Growth Reserve worth 2 High-Grade Spirit Stones.
- At least 1 High-Grade Spirit Stone of value from compatible Storm Iron, lightning material, thunder material, star metal, or a tribulation remnant.
- Two milestones.
- Saint-grade forge or refinement hall.
- Material ceiling support through a Sovereign stabilizer because Storm Iron normally supports only Saint grade.

## Completed Milestones

### Deed: Thunder Pursues the Fleeing Tyrant

The jian defeats a powerful enemy by striking through Flying Sword Command after the enemy attempts to escape.

### Tribulation: Holds the First Heavenly Bolt

The jian remains present and functional during its bearer's breakthrough tribulation and conducts a lightning strike without breaking.

## Advancement

After the refinement rite:

- grade becomes Sovereign Treasure;
- Refinement Bonus becomes +4;
- enchantment capacity becomes +6;
- occupied Equivalent Bonus remains +3;
- Growth Reserve returns to 0;
- the treasure chooses **Awaken the Next Spirit Tier** as its Growth Reward.

## New Instinct

**Pursue.** Once per Long Rest, when the bearer misses with an attack made using the jian, the jian rerolls the attack and uses the new result.

The sword now has an Instinct but still cannot speak, refuse, negotiate, or take turns.

A later Imperial advancement could awaken a Weapon Soul, at which point it would receive a Spirit Nature and always require Attunement.

---

# Growth Treasure Audit Checklist

A Growth Treasure is incomplete unless the record answers all of the following:

- What is its Core Principle?
- What is its Core Expression?
- What materials can it consume?
- How is Growth Reserve measured?
- What is its material ceiling?
- What milestones are required?
- What changes at each grade?
- What capacity does it have?
- Which properties count against capacity?
- What Awakening Tier has it reached?
- Does it have a complete Spirit Nature?
- What offering and taboo apply?
- What Recognition State does each bearer hold?
- How is refusal resolved?
- How much Bond Strain exists?
- How many Attunement slots does it require?
- Does it take an independent turn?
- Does it count as a full bonded companion?
- Can its expressions transfer?
- What survives if it is Broken or Destroyed?
- How is the spirit repaired, rehoused, or restored?
- Are all actions, reactions, ranges, saves, costs, durations, charges, and recovery rules explicit?

# Final Doctrine

Growth preserves identity.

A treasure becomes more powerful by deepening its material, history, bond, spirit, and Core Principle. Advancement should not erase what the treasure was, grant unrelated abilities, create free companion turns, or reduce a self-aware spirit to an unexamined equipment bonus.


# Chapter 7: Treasure Sets and Set Resonances
*Compact Rules and Example Set Catalog v0.1*

A **Treasure Set** is a group of individually usable treasures created, inherited, or refined to function together.

Each component remains a complete item. When the required pieces are attuned, equipped, deployed, and used in the stated way, they awaken one or more **Set Resonances**.

Treasure Sets support:

- coordinated regalia;
- inherited collections;
- armor panoplies;
- sword arrays;
- needle constellations;
- traveling clinics;
- scholarly tools;
- formation networks;
- sect and court insignia.

A Set Resonance does not automatically combine several items into one treasure and does not bypass the four-slot Attunement limit.

---

# Core Set Rules

## Set Identity

Every component belonging to a Treasure Set records:

- Set Name;
- Component Name;
- component grade;
- component item type;
- individual Attunement requirement;
- Set Mark or shared refinement signature;
- Set Resonances for which it qualifies;
- proper-use requirement;
- whether it is a Resonance Anchor;
- whether it can function when separated from the set.

An item can function normally when its Set Resonance is inactive unless its entry says otherwise.

## Required Pieces

Each Set Resonance lists the exact pieces or categories required.

A resonance can require:

- any two pieces;
- named pieces;
- a minimum number of different components;
- one Resonance Anchor plus supporting pieces;
- pieces carried by one bearer;
- pieces distributed among several bearers;
- deployed Nodes, gates, seals, or instruments.

Duplicate copies of one component do not satisfy a requirement for different components unless the set explicitly permits duplicates.

## Proper Use

A component counts toward a resonance only while it is properly used.

Examples include:

- armor worn;
- shield wielded;
- weapon held or legally hovering;
- ring or clothing worn;
- needle case accessible;
- seal displayed;
- instrument carried and able to sound;
- formation component deployed and intact;
- book, brush, or tool present at the worksite;
- vehicle component installed.

A stored, dropped, suppressed, Broken, or inaccessible component does not qualify.

## Attunement

If a required component needs Attunement, the creature benefiting from the resonance must be attuned to it unless the resonance explicitly distributes the requirement among several bearers.

Each item occupies its printed number of Attunement slots.

A personal set requiring four one-slot treasures occupies all four normal slots.

A fifth Attunement item cannot be added merely because the items share a set.

## Unified Attunement

Only a set explicitly carrying **Unified Attunement** can alter the ordinary slot count.

Unified Attunement must state:

- every included component;
- the total slots used;
- who can establish the unified bond;
- the rite required;
- whether partial use is allowed;
- what happens when a component is missing or Broken.

Unified Attunement never increases a character's four-slot capacity. It only defines how that specifically designed set occupies those existing slots.

Unified Attunement cannot be added to an existing collection through ordinary reforging. It requires an Imperial, Immortal, lineage-defining, or similarly exceptional formula.

## Distributed Sets

A Distributed Set assigns components to different creatures.

Each bearer must:

- be attuned to its own required component;
- meet that component's requirements;
- remain within the resonance's stated range;
- be conscious unless the resonance says otherwise;
- willingly participate.

A Distributed Set does not let one bearer use another creature's item properties.

If a required participant leaves range, becomes Incapacitated, ends Attunement, or stops properly using the component, the corresponding resonance ends immediately.

## Set Grade

A Set Resonance has a **Resonance Grade**.

Unless explicitly stated otherwise, the Resonance Grade cannot exceed the lowest grade among its required components.

Upgrading one piece does not raise the resonance. Every required component and the shared Set Mark must support the new grade.

## Resonance Thresholds

A set can have several thresholds.

Example:

- two-piece resonance;
- three-piece resonance;
- complete-set resonance.

Meeting a higher threshold also activates lower thresholds unless the set says the resonances are mutually exclusive.

## Resonance Anchors

A resonance can name one component as its **Resonance Anchor**.

If that Anchor is:

- Broken;
- destroyed;
- suppressed;
- removed;
- no longer properly used;

the resonance ends even if all other pieces remain.

Destroying a non-Anchor piece can reduce the active threshold without ending every lower resonance.

## Shared Charges

A set can possess one shared charge pool.

Shared charges belong to the set, not to an individual component.

- Removing and re-equipping a piece does not refresh charges.
- Replacing the bearer does not refresh charges.
- Duplicate pieces do not create extra pools.
- The pool recharges only through the set's printed rule.
- If the Anchor is Broken, unspent charges remain recorded but cannot be used.

## Concentration and Actions

A Set Resonance uses the action type printed in its entry.

If it requires Concentration, the creature activating the resonance concentrates unless another controller is named.

A set does not gain an independent turn.

Weapons, spirits, constructs, or formation components in a set act only through their printed action, reaction, companion, vehicle, or formation rules.

## Suppression and Missing Pieces

When a required piece becomes unavailable:

- complete-set resonance ends immediately;
- lower thresholds remain if their requirements are still met;
- ongoing effects end unless their entries say they persist;
- expended charges are not restored;
- cooldowns and dormancy continue.

Restoring the piece can reactivate passive resonances immediately. An ended activated effect must be activated again and pay its normal cost.

---

# Creating and Refining Treasure Sets

## New Sets

Each component is crafted and priced normally.

Add **Set Refinement** for every resonance threshold.

| Resonance Grade | Added Set-Refinement Cost per Threshold | Added Work Time per Threshold |
|---|---:|---:|
| Spiritual Treasure | 50 GT | 2 workdays |
| Saint Treasure | 500 GT | 10 workdays |
| Sovereign Treasure | 5,000 GT | 25 workdays |
| Imperial Treasure | 25,000 GT | 50 workdays |
| Immortal Artifact | Unique | Special |

This cost is paid once for the entire set, not once per component.

Set Refinement creates the shared signature, balance, communication pathways, compatibility, and Resonance Anchor.

## Retrofitting Existing Treasures

Existing treasures can be converted into a set when:

- each component is compatible;
- every self-aware Item Spirit consents;
- all components are present throughout the work;
- the creator possesses the Set Formula;
- the full Set-Refinement cost and time are paid;
- the lowest component grade supports the resonance.

A failed risky retrofit can damage the Set Mark without destroying the individual treasures.

## Weapon and Armor Capacity

A Set Resonance is not a free weapon or armor enchantment.

When a resonance directly adds damage, Armor Class, attack bonuses, Resistance, suppression, a major reaction, or another combat property to a weapon, armor, or shield, the Set Formula assigns a **Resonance Burden** to one or more components.

Each point of Resonance Burden occupies 1 point of Equivalent Bonus capacity on the assigned component.

Utility, identification, communication, travel coordination, and similar noncombat resonances can instead be paid entirely through Set-Refinement cost when the formula permits.

Every set entry must identify where any Resonance Burden is carried.

## Replacement Pieces

A lost component can be replaced.

Creating and integrating a replacement requires:

- a legal replacement item of the required grade and type;
- 25 percent of that component's normal crafting cost and time;
- the Resonance Anchor or at least half of the surviving set;
- the Set Formula;
- spirit consent when applicable.

A replacement does not restore expended shared charges.

An inherited set can require a deed, bloodline recognition, or milestone before accepting a replacement.

## Growth Sets

A Treasure Set can be a Growth Treasure.

To raise a resonance by one grade:

- every required component must reach the target grade;
- the Set Mark must receive Growth Reserve equal to one normal treasure of that target grade;
- the set must complete one additional shared milestone;
- all self-aware component spirits must consent;
- the Resonance Anchor must survive the refinement rite.

Individual components can advance separately without increasing the resonance.

## Item Spirits in Sets

A set can include several Item Spirits.

Each remains a separate person unless the set explicitly has a collective spirit.

A Set Resonance cannot:

- force spirits to merge;
- erase their taboos;
- let one spirit command another automatically;
- remove Bond Strain;
- create free combat turns.

A collective decision requiring several spirits functions only when all required spirits are at least Accepted toward the participating bearer.

A set can awaken a **Set Spirit** only through the Growth Treasure rules. The Set Spirit must have its own Nature, desire, offering, taboo, recognition, and Attunement requirements.

---

# Set Presentation Format

Use the following structure.

> **Set Name**  
> *Set Grade and Set Type*  
> **Components:** List every item  
> **Attunement:** Individual or Unified Attunement rule  
> **Proper Use:** Required equipment, deployment, participants, and range  
> **Resonance Anchor:** Named item, if any  
> **Resonance Burden:** Assigned Equivalent Bonus capacity, if any  
> **Two-Piece Resonance:** Complete mechanics  
> **Three-Piece Resonance:** Complete mechanics  
> **Complete-Set Resonance:** Complete mechanics  
> **Failure State:** Missing, Broken, or suppressed component behavior

---

# Example Treasure Sets

# 1. Cloud-Walking Pilgrim Set
*Spiritual Treasure Travel Set*

This set uses set-marked editions of three existing Wondrous Treasures.

## Components

1. **Cloudstep Jade Anklets** — Requires Attunement.
2. **Mist-Sheltering Travel Cloak** — No Attunement.
3. **Homeward Compass Disc** — No Attunement.

**Attunement:** 1 slot.  
**Proper Use:** The anklets must be worn, the cloak worn, and the compass carried openly or in an accessible pocket.  
**Resonance Anchor:** Cloudstep Jade Anklets.  
**Resonance Burden:** None; utility Set Refinement.

## Two-Piece Resonance: Road Beneath the Clouds

While wearing the anklets and either other component:

- you ignore nonmagical Difficult Terrain during overland travel;
- you have Advantage on saving throws against Exhaustion caused by forced march or ordinary weather;
- you can stand from Prone by spending 5 feet of movement.

## Complete-Set Resonance: Home Beneath Every Sky

While all three pieces qualify:

- you cannot become lost by nonmagical means;
- your overland travel pace increases by 50 percent;
- moving at a fast pace does not impose the normal penalty on passive Wisdom (Perception);
- willing traveling companions equal to your Proficiency Bonus gain these travel benefits while remaining within 30 feet of you.

Once per Long Rest, you can perform a 10-minute setup using the cloak and compass to create a dry, wind-sheltered 20-foot-radius campsite for 8 hours. The shelter provides no Cover and does not block creatures.

## Failure State

Losing the anklets ends all resonances. Losing the cloak or compass ends only the complete-set resonance.

---

# 2. Hidden Moon Infiltrator Set
*Saint Treasure Personal Regalia*

This set uses coordinated versions of four existing Wondrous Treasures.

## Components

1. **Moon-Mirror Stillwater Mantle** — Requires Attunement.
2. **Hidden-Step Shadow Boots** — Requires Attunement.
3. **Hidden-Pocket Jade Belt** — Requires Attunement.
4. **Borrowed-Voice Reed Flute** — Requires Attunement.

**Attunement:** 4 slots.  
**Proper Use:** Mantle, boots, and belt worn; flute carried and accessible.  
**Resonance Anchor:** Moon-Mirror Stillwater Mantle.  
**Resonance Burden:** +1 assigned to the mantle and +1 assigned to the boots.

## Two-Piece Resonance: Borrowed Silhouette

While at least two components qualify:

- you have Advantage on Dexterity (Stealth) checks made in Dim Light or Darkness;
- you have Advantage on Charisma (Deception) checks made to maintain a visual or vocal disguise;
- a creature studying your disguise with sight or hearing alone cannot gain Advantage merely from magical enhancement below Saint grade.

## Three-Piece Resonance: Moonless Passage

While at least three components qualify, whenever you teleport using the Hidden-Step Shadow Boots or become Invisible through the Moon-Mirror Stillwater Mantle, you can bring one willing creature within 5 feet.

The creature appears in an unoccupied space within 5 feet of your destination and shares your invisibility duration, ending under the same conditions.

You can use this resonance a number of times equal to your Proficiency Bonus and regain all uses after a Long Rest.

## Complete-Set Resonance: Perfect Infiltration

Once per Long Rest, as an Action, activate the complete set for 10 minutes.

During the duration:

- you and one willing creature touching you are Invisible;
- you produce no sound from movement, clothing, or carried equipment;
- divination and tracking effects of Spiritual or Saint grade cannot locate you;
- you can speak using the voice stored in the flute without revealing your location by sound.

The effect ends for both creatures if either makes an attack, deals damage, forces a saving throw, or activates a treasure producing an obvious hostile effect.

## Failure State

If the mantle becomes unavailable, all set-granted invisibility ends. Losing any other piece reduces the active threshold normally.

---

# 3. Nine-Meridian Needle Constellation
*Saint Treasure Needle and Medicine Set*

## Components

1. **Heaven Meridian Needle Case** — Requires Attunement.
2. **Earth Meridian Needle Case** — Requires Attunement.
3. **Human Meridian Needle Case** — Requires Attunement.
4. **Pulse-Reading Jade Dial** — Requires Attunement.

**Attunement:** 4 slots.  
**Proper Use:** All cases and the dial must be worn or carried accessibly.  
**Resonance Anchor:** Pulse-Reading Jade Dial.  
**Resonance Burden:** +1 assigned to each needle case.

## Individual Components

### Heaven Meridian Needle Case

The case has 3 charges and regains all charges after a Long Rest.

As an Action, expend 1 charge and touch a willing creature. It regains `2d8 + your Proficiency Bonus` Hit Points.

### Earth Meridian Needle Case

The case has 3 charges and regains all charges after a Long Rest.

As an Action, expend 1 charge and make a ranged item attack against one creature within 60 feet. On a hit, it takes `2d8` piercing damage and makes a DC 15 Constitution saving throw. On a failed save, its Speed is reduced by 15 feet until the end of your next turn.

### Human Meridian Needle Case

The case has 3 charges and regains all charges after a Long Rest.

As an Action, expend 1 charge and touch a willing creature. It can immediately repeat one saving throw against Poisoned, Charmed, Frightened, possession, or a circulation effect that permits repeated saving throws.

### Pulse-Reading Jade Dial

As a Bonus Action, choose one visible creature within 30 feet.

Until the end of your next turn, you know:

- whether it is above or below half its Hit Points;
- whether it is Poisoned;
- whether it is affected by a disease;
- whether one of its Path resources is at 0;
- whether a spirit is possessing it.

The dial does not reveal exact Hit Points, diagnoses, hidden immunities, or an effect's source.

## Two-Piece Resonance: Meridian Cross-Reading

While the dial and at least one needle case qualify:

- your needle attacks ignore Half Cover;
- you have Advantage on Wisdom (Medicine) checks involving a creature read by the dial;
- a willing target treated by a needle case gains Temporary Hit Points equal to your Proficiency Bonus.

## Three-Piece Resonance: Linked Needle Procedure

When the dial and at least two needle cases qualify, you can use an Action to expend 1 charge from each of two different cases and apply both effects to one legal target.

If one effect requires an attack and the attack misses, neither charge is refunded.

## Complete-Set Resonance: Nine-Needle Constellation

Once per Long Rest, use an Action and choose one creature within 30 feet.

Choose Restoration or Suppression.

### Restoration

A willing creature regains `8d8 + 15` Hit Points and ends one poison, disease, Charmed, Frightened, possession, or circulation effect of Saint grade or lower.

### Suppression

A hostile creature makes a DC 15 Constitution saving throw.

On a failed save, it takes `6d8` piercing damage and `6d8` psychic damage and is Paralyzed until the end of your next turn.

On a successful save, it takes half damage and is not Paralyzed.

## Failure State

If the dial is unavailable, all Set Resonances end, but each needle case retains its individual properties.

---

# 4. Three-Star Flying Sword Array
*Sovereign Treasure Weapon Set*

## Components

1. **Red Thunder Jian +2** — Saint Treasure weapon, Requires Attunement.
2. **White Frost Jian +2** — Saint Treasure weapon, Requires Attunement.
3. **Black Void Jian +2** — Saint Treasure weapon, Requires Attunement.
4. **Three-Star Command Ring** — Sovereign Treasure, Requires Attunement.

**Attunement:** 4 slots.  
**Proper Use:** The ring must be worn. Each required jian must be drawn or hovering within 60 feet under Flying Sword Command.  
**Resonance Anchor:** Three-Star Command Ring.  
**Resonance Burden:** +1 on each jian and +3 on the ring.

## Individual Swords

Each jian:

- uses the Jian weapon profile;
- has a +2 Refinement Bonus;
- has Flying Sword Command;
- deals an additional `1d6` damage on every hit.

The Red Thunder Jian deals lightning damage.  
The White Frost Jian deals cold damage.  
The Black Void Jian deals force damage.

## Two-Sword Resonance: Paired Orbit

While the ring and at least two swords qualify:

- you gain +1 AC against ranged attacks while both swords hover within 10 feet;
- when a ranged attack misses you, you can move one hovering sword up to 15 feet without an action;
- the qualifying swords can share the same Flying Sword Command tether.

## Complete-Set Shared Charges

The complete set has 5 Array charges and regains `1d4 + 1` after a Long Rest.

Removing and reattuning a sword does not restore charges.

## Complete-Set Resonance: Three-Star Assault

As an Action, expend 2 Array charges.

Make one weapon attack with each jian against creatures within their legal range. The attacks can target the same or different creatures.

This is one Action and does not grant the swords independent turns.

## Complete-Set Resonance: Three-Star Severing Line

As an Action, expend 3 Array charges.

The three swords trace a 120-foot-long, 10-foot-wide line originating from a point within 30 feet of you.

Creatures in the line make a DC 17 Dexterity saving throw.

On a failed save, a creature takes:

- `6d8` force damage;
- `2d8` lightning damage;
- `2d8` cold damage.

On a successful save, it takes half damage.

Unattended objects, structures, Formation components, and magical barriers take maximum force damage.

## Failure State

If the ring is unavailable, all set functions end. Individual swords remain usable as ordinary attuned weapons.

---

# 5. Hundred-Medicine Traveling Clinic
*Saint Treasure Medical Collection*

This set coordinates four existing medicinal treasures.

## Components

1. **Wandering Healer's Hundred-Medicine Cabinet** — Requires Attunement.
2. **Soul-Wound Mending Needle Case** — Requires Attunement.
3. **Clean-Meridian Tea Kettle** — Requires Attunement.
4. **Wound-Cleansing Copper Basin** — No Attunement.

**Attunement:** 3 slots.  
**Proper Use:** All required components must be within 10 feet and accessible. The basin must contain clean water for complete-set procedures.  
**Resonance Anchor:** Hundred-Medicine Cabinet.  
**Resonance Burden:** None; medical Set Refinement.

## Two-Piece Resonance: Coordinated Treatment

Whenever one qualifying component restores Hit Points to a creature, that creature regains additional Hit Points equal to your Proficiency Bonus.

A creature can receive this additional healing only once during each Action, Bonus Action, or procedure, even when several components are used together.

## Three-Piece Resonance: Pure Circulation

Whenever a qualifying component restores Hit Points or Path resources to a willing creature, the target can immediately repeat one saving throw against:

- poison;
- disease;
- Charmed;
- Frightened;
- possession;
- a circulation effect;

provided that effect permits repeated saving throws.

A creature can receive this extra saving throw once per Short Rest.

## Complete-Set Resonance: Traveling Clinic Procedure

Once per Long Rest, perform a 10-minute procedure on a number of willing creatures up to your Proficiency Bonus.

Each target:

- regains `6d8 + 15` Hit Points;
- can end one poison or disease of Saint grade or lower;
- can remove 1 Essence Impurity;
- can regain expended CP, Stamina, or Resonance equal to its Proficiency Bonus.

A creature cannot gain Path-resource recovery from this procedure more than once per Long Rest.

## Failure State

If the cabinet is unavailable, all resonances end. The individual medical treasures continue to function normally.

---

# 6. Black Tortoise Fortress Panoply
*Sovereign Treasure Armor Set*

## Components

1. **Mountain-Pattern Grand Shell +3** — Heavy Armor, Requires Attunement.
2. **World-Turtle Shield +3** — Shield, Requires Attunement.
3. **Black Tortoise Helm** — Wondrous Item, Requires Attunement.
4. **Earth-Sealing Belt** — Wondrous Item, Requires Attunement.

**Attunement:** 4 slots.  
**Proper Use:** Armor and helm worn, shield wielded, belt fastened.  
**Resonance Anchor:** Mountain-Pattern Grand Shell.  
**Resonance Burden:** +2 on the armor, +2 on the shield, +1 on the helm, and +1 on the belt.

## Individual Components

### Mountain-Pattern Grand Shell +3

The armor uses the Mountain-Pattern Grand Shell heavy-armor profile and adds +3 AC from its Refinement Bonus.

Forced movement affecting the wearer is reduced by 10 feet.

### World-Turtle Shield +3

The shield grants its normal +2 AC and an additional +3 AC from its Refinement Bonus.

While wielding it, you have Advantage on saving throws against being knocked Prone.

### Black Tortoise Helm

You have Advantage on saving throws against Charmed, Frightened, and possession.

### Earth-Sealing Belt

You count as one size larger for carrying capacity and for determining which creatures you can Grapple or Shove.

## Two-Piece Resonance: Shell and Root

While at least two components qualify:

- forced movement affecting you is reduced by an additional 10 feet;
- you have Resistance to cold damage;
- standing from Prone costs 5 feet of movement.

## Three-Piece Resonance: Unbroken Fortress

While at least three components qualify, reduce all damage you take by your Proficiency Bonus after applying Resistance.

This reduction cannot reduce damage below 1.

## Complete-Set Shared Charges

The complete set has 3 Fortress charges and regains 1 expended charge after a Long Rest.

## Complete-Set Resonance: Black Tortoise Domain

As an Action, expend 1 Fortress charge to create a 15-foot Emanation lasting 1 minute, requiring Concentration.

While in the Emanation:

- you and allies of your choice have Half Cover;
- those allies cannot be moved against their will or knocked Prone;
- hostile creatures treat the area as Difficult Terrain.

When an ally in the Emanation takes damage, you can use your Reaction to reduce the damage by `4d8 + your Proficiency Bonus`.

Using the Reaction does not expend another Fortress charge.

## Failure State

Losing the armor ends the complete-set resonance. Lower thresholds remain if enough other pieces qualify.

---

# 7. Four Treasures of the Living Scripture
*Saint Treasure Scholarly Set*

## Components

1. **Calligrapher's Living-Ink Brush** — Requires Attunement.
2. **Talisman Inkstone of Even Flow** — No Attunement.
3. **Memory-Sealing Jade Archive** — Requires Attunement.
4. **Thousand-Script Jade Library** — Requires Attunement.

**Attunement:** 3 slots.  
**Proper Use:** All required pieces must be within 10 feet and accessible during study, teaching, copying, or inscription.  
**Resonance Anchor:** Thousand-Script Jade Library.  
**Resonance Burden:** None; scholarly Set Refinement.

## Two-Piece Resonance: Perfect Concordance

While at least two components qualify:

- you have Advantage on checks made to compare, copy, annotate, index, or translate stored texts;
- copied diagrams preserve exact measurements, stroke order, and notation;
- you can locate every stored passage discussing the same named subject after 1 minute of study.

The resonance copies information but does not copy supernatural power.

## Three-Piece Resonance: Cross-Referenced Doctrine

After studying with three qualifying components for 1 hour, choose one Intelligence- or Wisdom-based skill, one known Sphere, or one known crafting tool represented in the archive.

Until your next Long Rest, add `1d4` to one ability check using that skill, Sphere, or tool.

You can hold one such doctrinal benefit at a time.

## Complete-Set Resonance: Living Lecture Hall

Once per Long Rest, conduct a 1-hour lesson for a number of willing students up to twice your Proficiency Bonus.

Choose one legal training subject for which the set contains a complete source.

Each student:

- has Advantage on the next training check made for that subject;
- reduces that training period by 1 day, minimum 2 days;
- can perfectly recall the lesson until the training attempt is resolved.

This resonance does not grant a Sphere, Talent, Formula, Recorded Art, language, prerequisite, or automatic success.

## Failure State

If the library is unavailable, all resonances end. Stored records remain in their respective components.

---

# 8. Eight-Trigram Boundary Formation Set
*Sovereign Treasure Distributed Formation Set*

## Components

1. Heaven Gate.
2. Earth Gate.
3. Fire Gate.
4. Water Gate.
5. Thunder Gate.
6. Wind Gate.
7. Mountain Gate.
8. Lake Gate.
9. Rotating Trigram Command Board — Requires Attunement.

**Attunement:** 1 slot for the Command Board. The gates are deployed infrastructure and do not require personal Attunement.  
**Proper Use:** Gates must be placed upright within 120 feet of the board. The attuned controller must remain within 300 feet.  
**Resonance Anchor:** Rotating Trigram Command Board.  
**Resonance Burden:** None; Formation Set Refinement.

Each gate has AC 17, 75 Hit Points, and Immunity to poison and psychic damage.

The board has AC 17 and 50 Hit Points.

Deployment requires 10 minutes per gate. The formation lasts for 8 hours after the board is activated.

## Two-Gate Resonance: Trigram Boundary

Choose two active gates within 120 feet of each other.

The line between them becomes a visible supernatural boundary.

Choose one Trigram Law associated with either gate. The law affects creatures crossing the line.

## Four-Gate Resonance: Trigram Court

When four gates surround an area, they create a 60-foot-radius court.

Choose one active Trigram Law. It applies throughout the area.

## Complete-Set Resonance: Eight-Trigram Grand Boundary

When all eight gates qualify, they create a 120-foot-radius grand array.

Choose two Trigram Laws. Both apply throughout the area.

The controller can replace one active law with another as an Action.

## Trigram Laws

### Heaven

Hostile teleportation and planar travel into, out of, or within the area require a DC 17 Charisma saving throw. On a failure, the activation is wasted.

### Earth

The area is Difficult Terrain for hostile creatures. Forced movement affecting allies is reduced by 20 feet.

### Fire

A hostile creature entering the area for the first time on a turn or starting its turn there makes a DC 17 Dexterity saving throw, taking `4d8` fire damage on a failure or half on a success.

### Water

Allies gain a Swim Speed equal to their Speed and can move through hostile spaces as Difficult Terrain without provoking Opportunity Attacks from the creature whose space they cross.

### Thunder

When a hostile creature activates a treasure, spends a Path resource, or begins Concentration in the area, it takes thunder damage equal to twice the controller's Proficiency Bonus.

### Wind

Ranged attacks made by hostile creatures through the area have Disadvantage. Ordinary smoke, fog, and gas cannot remain in the area.

### Mountain

Gates and allied Formation components gain Resistance to all damage. Allies have Advantage on saving throws against being knocked Prone.

### Lake

At the start of each allied creature's turn, if it has at least 1 Hit Point, it gains Temporary Hit Points equal to the controller's Proficiency Bonus. These Temporary Hit Points do not stack.

## Damage and Downgrading

- With six or seven intact gates, the array retains only one Grand Boundary law.
- With four or five intact gates, it becomes a Trigram Court.
- With two or three intact gates, it can maintain one Trigram Boundary.
- With fewer than two gates or if the board is Broken, the formation collapses.

## Failure State

Destroyed gates can be replaced through the Set replacement rules. Changing the controller does not restore duration or charges.

---

# 9. Five-Regalia of the Azure Mandate
*Imperial Treasure Inherited Regalia*

This set demonstrates an explicit Unified Attunement exception.

## Components

1. **Azure Crown of Office**.
2. **Heaven-Veil Court Robe**.
3. **Jade Seal of Decrees**.
4. **Thousand-Li Audience Mirror**.
5. **Bell of Loyal Names**.

Each component is an Imperial Treasure that normally requires 1 Attunement slot.

## Unified Attunement

A creature recognized by the regalia's issuing court, sect, dynasty, or inheritance can perform an 8-hour coronation rite with all five components.

After the rite:

- the five components collectively occupy **4 Attunement slots**;
- all five must remain on the bearer or properly installed within 30 feet;
- losing or breaking one component suspends Unified Attunement and all complete-set resonance;
- the remaining components continue to occupy 4 slots until the bearer completes a Short Rest and ends the unified bond;
- a partial collection can be attuned normally at 1 slot per piece.

This exception does not increase the bearer's Attunement capacity.

**Proper Use:** Crown and robe worn, seal carried, mirror open or carried, bell accessible.  
**Resonance Anchor:** Jade Seal of Decrees.  
**Resonance Burden:** Incorporated into the Imperial Unified Attunement formula.

## Individual Components

### Azure Crown of Office

You have Advantage on Wisdom and Charisma saving throws.

You can accurately identify recognized ranks, offices, and official seals belonging to the issuing authority.

### Heaven-Veil Court Robe

You have Resistance to force and psychic damage.

Ordinary weather, dust, smoke, and environmental heat or cold do not soil or damage the robe.

### Jade Seal of Decrees

The seal has 5 charges and regains `1d4 + 1` after a Long Rest.

As an Action, expend 1 charge to transmit an authenticated message of up to 1,000 words to a recognized relay seal within 1,000 miles on the same plane.

### Thousand-Li Audience Mirror

Once per Long Rest, the mirror can establish sight and sound communication for 1 hour with a recognized matching mirror on the same plane.

### Bell of Loyal Names

The bell stores the names and offices of up to one thousand willing recognized servants, officials, disciples, or officers.

The bearer knows when one registered creature within 10 miles is reduced to 0 Hit Points, renounces recognition, or activates an emergency signal.

## Two-Piece Resonance: Visible Mandate

While at least two components qualify:

- you have Advantage on Charisma checks made to exercise authority you genuinely possess;
- recognized members can verify your identity and office by sight;
- magical disguises of Imperial grade or lower cannot impersonate your registered office without an opposed ability check against DC 19.

The resonance does not create authority where none exists.

## Three-Piece Resonance: Court of One Voice

While at least three components qualify, recognized allies within 30 feet gain:

- +1 to saving throws;
- Advantage on saving throws against Charmed and Frightened;
- the ability to understand your spoken instructions despite ordinary language barriers.

A creature gains no benefit if it has knowingly rejected the issuing authority.

## Complete-Set Shared Charges

The complete set has 3 Mandate charges and regains 1 expended charge after a Long Rest.

## Complete-Set Resonance: Azure Mandate Domain

As an Action, expend 1 Mandate charge to create a 60-foot Emanation for 1 minute, requiring Concentration.

Recognized allies of your choice in the area gain:

- +2 AC;
- +2 to saving throws;
- immunity to Frightened;
- the ability to take the Help action as a Bonus Action.

A hostile creature entering the area for the first time on a turn or starting its turn there makes a DC 19 Charisma saving throw.

On a failed save, until the start of its next turn it:

- cannot teleport or become Invisible;
- cannot take Reactions;
- cannot falsely claim a registered identity or office.

On a successful save, it is immune to this saving throw until the start of its next turn.

## Failure State

If the seal is unavailable, all Set Resonances end. If any component is unavailable, the complete-set resonance and Unified Attunement benefits are suspended as described above.

---

# Set Design Checklist

Before approving a Treasure Set, answer all of the following.

## Components

- Is every component a complete item?
- Does each have a legal type, grade, and Attunement rule?
- Can each function separately?
- Are duplicate components allowed?
- Which piece is the Resonance Anchor?

## Activation

- What counts as proper use?
- Must one bearer hold every piece?
- Is the set Distributed?
- What range connects participants?
- Which thresholds exist?
- What action or Concentration is required?

## Attunement

- How many total slots are occupied?
- Does every required attuned item have the correct bearer?
- Is a Unified Attunement exception explicitly printed?
- Does the set remain within the four-slot capacity?

## Power and Cost

- What is the Resonance Grade?
- Does the lowest required component support it?
- What Set-Refinement cost and time were paid?
- Which combat resonances impose Resonance Burden?
- Are charges shared and protected against refresh exploits?

## Failure

- What happens when a piece is dropped, suppressed, Broken, or destroyed?
- Do lower thresholds remain?
- Does an ongoing effect end?
- Can the piece be replaced?
- What happens to Item Spirits and Growth milestones?

## Identity

- Does the set deepen one coherent inheritance or purpose?
- Are its resonances more than unrelated item bonuses?
- Do recognition, lineage, oath, sect, or spirit requirements matter?
- Does the set avoid granting free companion turns, extra Attunement capacity, or undefined authority?

# Final Doctrine

A Treasure Set rewards commitment, coordination, and inherited design.

Its power comes from requiring several specific treasures to work together—not from pretending several items occupy one slot, creating free enchantment capacity, or granting unrelated bonuses for collecting objects with the same name.


# Chapter 8: Identification, Appraisal, Repair, Reforging, and Salvage
*General Treasure Procedures v0.1*

Treasures are discovered in ruins, inherited without manuals, sold under false names, damaged in battle, sealed by dead sects, occupied by spirits, or assembled from principles no living crafter fully understands.

This chapter establishes the general procedures for:

- identifying grade and basic function;
- completing a full appraisal;
- discovering concealed properties;
- recognizing curses, contamination, and forbidden refinement;
- repairing damaged or Broken treasures;
- reconstructing treasures whose cores survive;
- reforging an item into a compatible form;
- salvaging materials and enchantment imprints;
- transferring compatible enchantments;
- sealing or destroying dangerous artifacts;
- restoring Dormant treasures.

These procedures supplement the crafting, Growth Treasure, Item Spirit, weapon, armor, formation, talisman, and consumable rules. A specific treasure can override a general rule when its entry states the exception explicitly.

---

# Sphere and Skill Boundaries

No single Sphere automatically reveals every truth about a treasure.

## Blacksmith

Blacksmith is the primary authority for:

- structural flaws;
- workmanship;
- temper;
- material failure;
- repair;
- reforging;
- weapon and armor construction;
- whether an object can physically bear another refinement;
- whether an Item Spirit is beginning to awaken through its vessel.

Blacksmith does not automatically reveal secret command words, hidden curses, a spirit's intentions, or the complete function of a Formation.

## The Hidden Eye

The Hidden Eye is the primary authority for:

- concealed properties;
- false surfaces;
- disguised activation conditions;
- hidden inscriptions;
- inconsistencies between appearance and behavior;
- evidence that a treasure is withholding or falsifying information.

The Hidden Eye reveals decision-relevant facts. It does not automatically provide a complete stat block or identify an effect behind Total Cover.

## Source

Source is the primary authority for:

- stone, ore, jade, crystal, and mineral construction;
- material grade;
- geomantic stress;
- mineral seals;
- whether a sealed stone or source object is natural, worked, unstable, preserving, warning, hiding, locking, or punishing;
- the direction and condition of power moving through mineral components.

Source does not automatically determine exact market value, bearer identity, secret command words, or a spirit's full nature.

## Ink and Talismans

Ink and Talismans are the primary authorities for:

- written formulae;
- command syntax;
- stored activation;
- talisman media;
- seal families;
- trigger language;
- hidden script;
- whether a written pattern is incomplete, copied, altered, or deliberately trapped.

They do not automatically explain permanent material properties or the complete geometry of a Formation.

## Formations

Formations is the primary authority for:

- Array Eyes;
- Nodes;
- boundaries;
- gates;
- linked anchors;
- formation flow;
- suppression points;
- collapse conditions;
- place-based infrastructure.

Formations does not automatically reveal a portable treasure's unrelated enchantments.

## Imbuement

Imbuement is the primary authority for:

- stored energy;
- charge pathways;
- compatible enhancement layers;
- unstable overloading;
- whether an effect was added after original construction;
- whether several enchantments are cooperating or interfering.

Imbuement does not grant permission to transfer an effect into an incompatible chassis.

## Harvesting and Gathering

Harvesting and Gathering is the primary authority for:

- recovering usable ingredients;
- preserving harvested essence;
- judging spoilage;
- separating material from waste;
- determining whether a component can survive removal.

It does not refine salvaged material into a finished treasure.

## Spirit Companions and Spirit Awakening

Spirit-facing abilities are the primary authority for:

- whether a spirit is present;
- whether it is willing, dormant, bound, injured, hostile, or displaced;
- offerings and taboos;
- possession;
- whether a treasure contains an Instinct, Weapon Soul, Item Spirit, or Independent Spirit-Life.

A spirit's presence does not automatically reveal every property of its vessel, and the spirit can refuse to disclose information.

---

# Appraisal Statistics

## Appraisal DC by Grade

| Treasure Grade | Base Appraisal DC |
|---|---:|
| Mortal Item | 10 |
| Spiritual Treasure | 13 |
| Saint Treasure | 15 |
| Sovereign Treasure | 17 |
| Imperial Treasure | 19 |
| Immortal Artifact | 21 or bespoke |

The DC represents a treasure whose grade, culture, material tradition, and general family are not already documented by the appraiser.

## Appropriate Checks

The default appraisal check is:

> `d20 + Proficiency Bonus + Intelligence modifier`

Use Arcana by default.

A different skill or tool can replace or supplement Arcana when it directly matches the question.

| Question | Typical Skill or Tool |
|---|---|
| Structural integrity, repair, forging | Blacksmith or Smith's Tools |
| Hidden mechanism or false construction | Investigation or The Hidden Eye |
| Historical origin and lineage | History |
| Religious, ancestral, or funerary relic | Religion |
| Spirit, possession, soul, or taboo | Spirit-facing ability or Religion |
| Poison, medicine, pill, biological material | Medicine, Alchemist's Supplies, Poisoner's Kit |
| Script, manual, talisman, seal | Ink, Talismans, Calligrapher's Supplies |
| Array, gate, Node, boundary | Formations and an appropriate design tool |
| Mineral, jade, source stone, sealed ore | Source, Mason's Tools, Jeweler's Tools |
| Weapon or armor chassis | Weapons, Equipment, Blacksmith, Smith's Tools |
| Market value, legal trade, authenticity | Investigation, History, or Sect Stewardship |

Do not add several full proficiency bonuses to one check. Choose the most appropriate check. Relevant secondary knowledge normally grants Advantage, reveals a clue before the roll, or lowers the DC.

## DC Modifiers

Apply only the modifiers that materially affect the appraisal.

| Condition | DC Modifier |
|---|---:|
| Complete formula, maker's record, or authenticated registry | −5 |
| Exact matching Sphere or crafting tradition | −2 |
| Known command word and lawful bearer | −2 |
| Familiar culture, sect, lineage, or workshop | −2 |
| Broken or partially destroyed | +2 |
| Foreign or extinct construction tradition | +2 |
| Deliberately concealed property | +2 |
| Curse, hostile spirit, or false-face refinement | +2 |
| Forbidden refinement | +4 |
| Imperial or Immortal authority concealing information | Bespoke |

The total ordinary modifier should normally remain between −5 and +5.

---

# Appraisal Information Levels

A treasure's information is divided into five levels.

## Level 0: Unexamined

The observer knows only what ordinary senses reveal.

Examples:

- visible item type;
- approximate size and material;
- obvious damage;
- active light, heat, sound, or spiritual pressure;
- inscriptions readable without special knowledge.

## Level 1: Classification

The appraiser learns:

- treasure grade;
- item family;
- whether it is magical or cultivation-active;
- Primary Material or broad material family;
- whether it requires Attunement;
- whether it is Intact, operationally Damaged, Broken, Destroyed with Core, or Core Lost;
- whether it contains obvious charges, a Formation Eye, a spirit core, or a sealed compartment.

Level 1 does not reveal exact powers.

## Level 2: Basic Function

The appraiser learns:

- the treasure's primary purpose;
- its obvious passive properties;
- ordinary activation method;
- command word or legal trigger when not concealed;
- charge maximum and normal recharge;
- base Refinement Bonus or Armor Refinement Bonus;
- ordinary restrictions and required bearer category;
- whether a consumable is Saturating, poisonous, formation-based, or single use.

This is the minimum information needed to use a normal treasure responsibly.

## Level 3: Complete Function

The appraiser learns:

- all normal properties;
- exact actions and reactions;
- ranges and areas;
- saving throws and attack modifiers;
- durations and Concentration;
- Equivalent Bonus values and occupied capacity;
- material ceiling;
- Growth Treasure status;
- ordinary Item Spirit expressions;
- every printed drawback that is not deliberately concealed;
- repair requirements;
- transfer compatibility;
- dormant and recharge conditions.

## Level 4: Concealed Truth

The appraiser learns one concealed truth for each successful deep-appraisal result.

Examples include:

- hidden curse;
- false command word;
- forbidden refining method;
- suppressed Item Spirit;
- secret recognition requirement;
- dormant extra property;
- concealed lineage mark;
- destructive overload;
- soul cost;
- corruption pathway;
- hidden tracking or communication function;
- counterfeit grade;
- falsified maker's mark;
- condition that awakens or destroys the treasure.

A treasure can contain several concealed truths.

## Level 5: Provenance and Dao Record

The appraiser reconstructs the treasure's deeper history.

Possible information includes:

- original maker or school;
- major reforging events;
- destroyed or removed enchantments;
- significant Growth milestones;
- prior recognized bearers;
- spirit trauma;
- historical use;
- why the Core Principle took its current form;
- what is required for the next awakening or grade advancement;
- the safest lawful method to destroy, seal, or restore it.

Level 5 is not automatically available for every treasure. Some information requires witnesses, archives, an Item Spirit's cooperation, a related relic, or a campaign discovery.

---

# Standard Identification Procedures

## Quick Inspection

**Time:** 1 minute  
**Range:** Within reach  
**Check:** None for visible information

A Quick Inspection provides Level 0 and reveals whether the object is obviously active, damaged, poisonous, burning, unstable, occupied by a manifest spirit, or currently sustaining an open Formation.

A creature trained in a directly relevant Sphere or tool also learns whether handling the treasure is obviously unsafe.

Quick Inspection never reveals concealed properties.

## Careful Examination

**Time:** 10 minutes  
**Check:** Appraisal check against the treasure's Base Appraisal DC

On a success, learn Level 1 and Level 2 information.

On a success by 5 or more, also learn Level 3 information or one immediately relevant Level 4 warning.

On a failure, learn only Level 1 information that is not concealed.

Failure does not create false information unless the treasure has a property explicitly capable of deception.

## Bond Examination

**Time:** One Short Rest  
**Requirement:** The treasure is not obviously hostile, forbidden, or unsafe to bond  
**Check:** Appraisal check or lawful Attunement procedure

A creature can study how the treasure responds to its qi, Stamina, Resonance, spirit, bloodline, or intent.

On a success:

- learn Level 1 through Level 3;
- learn whether the treasure accepts or rejects the examiner;
- learn one recognition requirement the examiner could reasonably satisfy;
- learn whether Attunement would activate an obvious curse.

Bond Examination does not require completing Attunement.

A concealed curse can still remain hidden if its rules explicitly state that it defeats ordinary bond examination.

## Deep Appraisal

**Time:** 8 hours  
**Requirements:** Suitable workspace, relevant tools, and uninterrupted access  
**Check:** Appraisal check against the modified DC

On a success:

- learn Level 1 through Level 3;
- discover one Level 4 concealed truth;
- learn one Level 5 fact when evidence supports it.

On a success by 5 or more:

- discover all concealed truths whose grade does not exceed the treasure's grade;
- learn every available Level 5 fact supported by the object and present records;
- identify the safest repair, sealing, transfer, or destruction procedure currently possible.

An Imperial or Immortal artifact can require multiple Deep Appraisals, different specialists, or unique evidence.

## Collaborative Appraisal

Up to three qualified creatures can contribute.

One creature leads the check. Each assistant must contribute a distinct relevant Sphere, skill, tool, archive, witness, or laboratory function.

One qualified assistant grants Advantage.

A second qualified assistant can reduce the DC by 2.

More assistants do not further improve the roll unless a special facility or procedure says otherwise.

## Repeated Attempts

A failed appraisal cannot be repeated with the same method and evidence.

A new attempt requires at least one meaningful change:

- new formula;
- new tool or facility;
- new specialist;
- repaired component;
- command word;
- historical record;
- related item;
- spirit cooperation;
- completed milestone;
- removal of a seal or curse.

This prevents repeated rolling from replacing investigation.

---

# Concealed Properties

A concealed property must state why ordinary appraisal does not reveal it.

Common concealment methods include:

- hidden inscription;
- false surface;
- dormant trigger;
- spirit refusal;
- sealed memory;
- alternate command word;
- lineage-only recognition;
- corruption masked as a benefit;
- a property residing in a missing component;
- an Imperial or Immortal authority.

## Clues

Every concealed property should have at least one discoverable clue.

Examples:

- mismatched material resonance;
- missing capacity;
- unfamiliar repair;
- asymmetric wear;
- aura inconsistent with grade;
- altered maker's mark;
- false recharge behavior;
- spirit fear;
- blood or soul residue;
- a command script with erased strokes;
- a Formation line that terminates nowhere;
- a market price far below probable value.

Concealment should create investigation, not arbitrary punishment.

---

# Curses, Corruption, and Forbidden Refinement

## Curse Categories

### Binding Curse

Restricts removal, Attunement, travel, speech, ownership, or use.

### Backlash Curse

Deals damage, drains resources, adds Exhaustion, or imposes a condition after use.

### Hunger Curse

Requires blood, souls, treasures, memories, pain, or another cost to remain active.

### Command Curse

Compels, influences, records, reports, or punishes specified behavior.

### Corruption Curse

Accumulates stain, mutation, possession, hostile Dao influence, or identity loss.

### False-Face Curse

Displays a harmless or beneficial function while hiding the real effect.

### Spirit Occupation

A hostile, coerced, wounded, or deceptive spirit inhabits the vessel.

### Destructive Awakening

A dormant property activates when the treasure reaches a bearer, grade, location, milestone, or resource threshold.

## Forbidden Refinement Signs

A treasure is likely to contain forbidden refinement when appraisal reveals one or more of the following:

- unwilling souls used as components;
- erased Item Spirit identity;
- permanent life or memory consumption;
- cultivation-base theft;
- repeated human sacrifice;
- living Formation Nodes;
- self-replicating corruption;
- unbounded Devouring growth;
- false recognition imposed through coercion;
- a safety seal designed only to hide evidence;
- an effect that makes consent mechanically impossible.

Forbidden does not mean unusable by definition. It means the construction method or ongoing operation violates the campaign's moral, legal, spiritual, or cosmic boundaries and must be recorded explicitly.

## Curse Appraisal

Discovering a curse normally requires Deep Appraisal against the modified DC.

A curse can instead reveal itself when:

- its trigger occurs;
- the treasure attempts to refuse;
- an appropriate ward reacts;
- a victim displays symptoms;
- a related archive identifies the construction;
- a spirit gives testimony.

A successful curse appraisal reveals:

- trigger;
- effect;
- whether Attunement is involved;
- whether removal is possible;
- whether suppression is safer than removal;
- whether destroying the vessel harms a spirit, victim, region, or seal;
- grade and method required for treatment.

## Safe Handling

When a treasure is suspected of being cursed, forbidden, possessed, unstable, or falsely identified:

1. Do not Attune.
2. Do not speak unknown command words.
3. Do not feed it materials or Path resources.
4. Do not place it near compatible vessels, souls, spirit stones, or Formation Anchors.
5. Place it behind an appropriate ward or inside a sealed container.
6. Record who handled it and what changed.
7. Complete Deep Appraisal before transport, transfer, or destruction.

---

# Commercial Appraisal and Value

A commercial appraisal estimates lawful exchange value. It does not guarantee a buyer, seller, formula, legal permission, or market availability.

## Base Crafting Value

| Grade | Base Permanent-Treasure Value |
|---|---:|
| Mortal Item | 50 GT |
| Spiritual Treasure | 200 GT |
| Saint Treasure | 2,000 GT |
| Sovereign Treasure | 20,000 GT |
| Imperial Treasure | 100,000 GT |
| Immortal Artifact | No standard market |

Consumables use their own Chapter 5 batch pricing.

## Market Factors

Apply the factors that materially affect the transaction.

| Factor | Typical Effect |
|---|---:|
| Complete formula and lawful provenance | ×1.0 to ×1.25 |
| Desired material or Sphere principle | ×1.1 to ×1.5 |
| Rare but legal lineage or sect item | ×1.25 to ×2 |
| Damaged but functional | ×0.75 |
| Broken | ×0.25 to ×0.5 |
| Missing command word or incomplete appraisal | ×0.5 to ×0.75 |
| Cursed but treatable | ×0.1 to ×0.5 |
| Forbidden, stolen, or politically dangerous | No lawful standard |
| Item Spirit refusing sale | No ordinary lawful sale |
| Imperial or Immortal historical significance | Story valuation |

Commercial value never increases salvage yield beyond the treasure's actual recoverable material.

---

# Damage and Operational Condition

Use the damage states from Chapter 6.

## Intact

The treasure is at full or substantially full structural function.

Cosmetic wear does not change its state.

## Operationally Damaged

The treasure has more than 0 Hit Points but less than half its Hit Point maximum, or has a specific damaged component.

Operational Damage is not a separate destruction state.

Unless the effect that caused the damage says otherwise:

- the treasure still functions;
- it retains Refinement Bonuses and properties;
- it can be appraised and Attuned normally;
- obvious damage can create disadvantage on checks requiring physical precision;
- continued dangerous use can justify a breakage check.

## Broken

At 0 Hit Points, a treasure becomes Broken unless an effect explicitly destroys, disintegrates, consumes, or erases it.

While Broken:

- supernatural properties are dormant;
- Refinement Bonuses are inactive;
- Attunement is suspended;
- Instincts cannot function;
- a housed Weapon Soul or Item Spirit becomes dormant but remains anchored.

## Destroyed with Core

The ordinary vessel is beyond repair, but its defining core, largest principal fragment, spirit seed, world-heart, or equivalent survives.

## Core Lost

The defining core is annihilated, consumed, erased, or otherwise unavailable.

A Core Lost treasure cannot be repaired. Creating a similar object normally creates a new treasure without the old history, milestones, identity, or spirit.

---

# Repair Procedures

## Routine Maintenance

**Time:** One Short Rest  
**Cost:** Negligible ordinary supplies  
**Requirement:** Appropriate tool

Routine Maintenance removes:

- dirt;
- corrosion not caused by a supernatural effect;
- loose fittings;
- ordinary blade dulling;
- damaged straps;
- minor cloth tears;
- cosmetic dents;
- ordinary residue.

It does not restore lost Hit Points unless a tool, Sphere feature, or treasure property says otherwise.

## Field Stabilization

**Time:** 10 minutes  
**Cost:** Supplies worth 1 percent of base crafting value  
**Requirement:** Appropriate tool

Field Stabilization can be performed on an Operationally Damaged or Broken treasure.

Choose one:

- prevent further structural deterioration for 24 hours;
- preserve a spirit core for 7 additional days;
- allow safe transport;
- prevent leakage, poison, fire, or unstable qi;
- keep a Formation Eye or Node dormant rather than collapsing destructively;
- allow one final appraisal with Advantage.

Field Stabilization does not restore item properties or make a Broken treasure usable.

## Repair Operational Damage

**Cost:** 5 percent of normal crafting cost  
**Time:** 5 percent of normal crafting time, minimum 4 hours  
**Result:** Restore the treasure to full Hit Points

No check is required with a known formula, suitable tools, compatible materials, and an appropriate facility.

## Repair a Broken Treasure

**Cost:** 10 percent of normal crafting cost  
**Time:** 10 percent of normal crafting time  
**Result:** Restore the treasure to full function

The repair requires:

- suitable tools;
- an appropriate facility;
- compatible repair material;
- the majority of the original vessel;
- preservation of the defining core.

A self-aware spirit returns when repair is complete.

## Reconstruct a Treasure Destroyed with Core

**Cost:** 50 percent of normal crafting cost  
**Time:** 50 percent of normal crafting time  
**Result:** Rebuild the treasure around its surviving core

Reconstruction also requires:

- the original core;
- a compatible vessel formula;
- legal chassis and material;
- all recognition, spirit, and lineage permissions;
- enough capacity for retained enchantments.

The reconstructed treasure retains:

- grade;
- history;
- milestones;
- spirit;
- recognition;
- Bond Strain;
- compatible enchantments.

Incompatible properties become dormant until transferred, redesigned, or supplied with a compatible vessel.

## When Repair Requires a Check

Make a repair check when:

- the formula is missing;
- the construction tradition is extinct;
- the Primary Material is unavailable;
- the treasure is ancient;
- a curse is integrated into the structure;
- the spirit resists;
- the repair changes chassis;
- the material ceiling was previously exceeded;
- the treasure is Imperial or Immortal and lacks its original facility;
- the repair attempts to preserve an unstable overload.

Use the normal appraisal or crafting DC for the treasure's grade.

### Repair Outcomes

| Result | Outcome |
|---|---|
| Success | Repair or reconstruction succeeds. |
| Success by 5+ | Recover 10 percent of repair materials or remove one minor flaw. |
| Failure by 5 or less | No repair; half the materials remain usable. |
| Failure by more than 5 | No repair; materials are lost, and one compatible property becomes dormant until separately restored. |
| Natural 1 | The treasure remains unrepaired and suffers one listed complication. |

### Repair Complications

Choose or roll:

1. A hidden curse or foreign inscription activates.
2. The treasure gains 1 Bond Strain.
3. The spirit core becomes unstable and requires Field Stabilization.
4. One enhancement imprint separates and must be transferred back.
5. The material ceiling drops by one grade until reinforced.
6. The treasure becomes Dormant rather than Broken.

A repair complication should create work, danger, or story—not erase the treasure without warning.

---

# Reforging

Reforging deliberately changes a treasure's form while preserving some or all of its identity.

## Cosmetic Reforging

Changes appearance, ornament, balance, cultural style, inscription language, scabbard, fittings, color, or ceremonial presentation.

**Cost:** 5 percent of normal crafting cost  
**Time:** 5 percent of normal crafting time  
**Effect:** No mechanical change

Cosmetic reforging cannot falsify a registered identity without creating a concealed property or counterfeit record.

## Profile Reforging

Changes a treasure into another compatible legal profile.

Examples:

- one Jian profile into another sword-family form;
- one light armor profile into another light armor profile;
- one shield shape into another shield shape;
- one ring, belt, cloak, or tool vessel into a compatible vessel of the same family.

**Cost:** 25 percent of normal crafting cost  
**Time:** 25 percent of normal crafting time

All retained enhancements must remain legal for the new profile.

A profile reforge does not increase grade, Refinement Bonus, capacity, or Attunement efficiency.

## Chassis Reforging

Changes the treasure into a substantially different item type or category.

Examples:

- sword into spear;
- medium armor into heavy armor;
- portable seal into installed Formation Anchor;
- ring into staff;
- vehicle core into palace core.

**Cost:** 50 percent of normal crafting cost  
**Time:** 50 percent of normal crafting time

Chassis reforging requires:

- a new legal profile;
- compatible Primary Material;
- enough capacity;
- a complete reforge formula;
- appraisal of every retained property;
- Item Spirit consent.

The GM determines which properties remain compatible.

## Primary-Material Reforging

Replacing the Primary Material is equivalent to reconstructing the vessel.

**Cost:** At least 50 percent of normal crafting cost, plus the new Primary Material  
**Time:** At least 50 percent of normal crafting time

The treasure loses the old material property and ceiling.

The new material property applies only after a successful appraisal and refinement rite.

A self-aware spirit can refuse a material that contradicts its Nature.

## Core Reforging

Core Reforging changes the treasure's Core Principle or Core Expression.

This is not an ordinary workshop modification.

It requires:

- Growth Treasure procedure;
- a new Core Expression;
- spirit consent;
- milestone;
- compatible material;
- full Deep Appraisal;
- at least 50 percent of normal crafting cost and time;
- GM approval.

Core Reforging can alter identity, recognition, and future growth. It cannot be used to combine unrelated powers without capacity and thematic coherence.

---

# Salvage

Salvage converts a treasure into recoverable materials, components, records, and enchantment imprints.

Salvage is not a sale and does not produce currency automatically.

## Controlled Dismantling

Controlled Dismantling intentionally destroys the treasure.

Requirements:

- Deep Appraisal;
- appropriate tools and facility;
- time equal to 10 percent of normal crafting time;
- consent from a housed self-aware spirit, or a lawful spirit-transfer procedure;
- a decision concerning curses and dangerous components.

## Salvage Yield

Percentages are based on the treasure's original base material value, not inflated market value.

| Treasure Condition | Ordinary Materials | Compatible Special Materials | Growth Reserve | Enchantment Imprints |
|---|---:|---:|---:|---|
| Intact controlled dismantling | 75% | 50% | 50% | Eligible |
| Operationally Damaged | 60% | 40% | 40% | Eligible |
| Broken | 50% | 25% | 25% | Eligible with check |
| Destroyed with Core | 25% | 10% | 0% | One possible |
| Core Lost | 10% or less | Usually 0% | 0% | None |

The GM can reduce yield when:

- the treasure was consumed;
- material was transformed into energy;
- acid, disintegration, void, Devouring, or soul destruction caused the damage;
- the item was already stripped;
- contamination makes recovery unsafe.

## Ordinary and Special Materials

Ordinary Materials can pay ordinary portions of a future crafting project when physically compatible.

Special Materials retain their original principle only if harvested, stored, and stabilized correctly.

Recovered material does not automatically satisfy:

- formula access;
- lineage requirements;
- material grade;
- unique catalysts;
- legal permission;
- spirit consent;
- story conditions.

## Growth Reserve

Recovered Growth Reserve is not currency.

It can be applied only to a compatible Growth Treasure and retains the original treasure's principle tags.

A treasure cannot be dismantled and rebuilt repeatedly to duplicate reserve.

## Enchantment Imprints

An enchantment imprint is a stabilized record and essence fragment of one enchantment.

It is not a functioning treasure.

An imprint can:

- serve as the donor requirement for enchantment transfer;
- replace the need to keep the original donor intact;
- support formula research;
- identify a removed enchantment;
- reduce the special-component cost of recreating that exact enchantment by 25 percent.

An imprint cannot:

- activate;
- grant its property;
- be sold as a complete treasure;
- duplicate itself;
- preserve a true Item Spirit;
- carry Refinement Bonus or material property.

Recovering an imprint from an Intact or Operationally Damaged treasure succeeds automatically during controlled dismantling when the formula is known.

Recovering an imprint from a Broken treasure requires a check against the grade's Appraisal DC.

A Destroyed-with-Core treasure can yield at most one imprint, chosen from a surviving compatible property.

## Item Spirits and Salvage

A self-aware Item Spirit is not salvage material.

Before dismantling its vessel, choose one:

- transfer it to a compatible vessel;
- house it in a lawful spirit residence;
- allow it to depart if able;
- obtain informed consent for dormant preservation;
- use an explicitly forbidden procedure and record the moral and mechanical consequences.

Destroying a spirit merely to recover value is a forbidden act unless the setting explicitly establishes otherwise.

---

# Enchantment Transfer

The following procedure is the general transfer rule. Chapter 6 remains authoritative for Spirit Cores and Growth identity.

## Requirements

Transfer requires:

- donor treasure or compatible enchantment imprint;
- recipient treasure;
- transfer formula;
- appropriate tools and facility;
- recipient grade equal to or higher than the enhancement's minimum grade;
- legal recipient item type and chassis;
- enough open Equivalent Bonus capacity;
- compatible material affinities or stabilizer;
- consent from a self-aware donor spirit when the expression forms part of its Nature.

## Cost and Time

**Cost:** 25 percent of the recipient grade's normal crafting cost  
**Time:** 25 percent of the recipient grade's normal crafting time

Using an imprint instead of an intact donor adds 25 percent to the transfer material cost unless the imprint came from a controlled dismantling performed by the same workshop as part of the same project.

## Standard Result

On success:

- the donor loses the enchantment, or the imprint is consumed;
- the recipient gains it;
- Equivalent Bonus counts normally;
- charges and expended uses do not refresh until the recipient completes a Long Rest;
- the recipient's grade, Refinement Bonus, material, and history do not change.

## Nontransferable Properties

The following do not transfer through ordinary enchantment transfer:

- Refinement Bonus;
- Armor Refinement Bonus;
- Primary Material property;
- material ceiling;
- inherent curse;
- lineage identity;
- Growth Reserve;
- milestone;
- recognition history;
- true Item Spirit;
- Independent Spirit-Life;
- Immortal authority;
- site-bound or world-scale function.

A specific formula can create an exception.

## Risky Transfer

Make a check when:

- the formula is incomplete;
- donor and recipient use opposed materials;
- the donor is Broken;
- the recipient lacks an exact legal chassis;
- the effect was concealed;
- a curse is entangled with the enchantment;
- the donor spirit resists;
- the transfer would remove a Core Expression.

On failure by 5 or less, the enchantment remains with the donor or imprint and half the transfer materials remain usable.

On failure by more than 5, the enchantment becomes Dormant in both donor and recipient until repaired, and the materials are lost.

A natural 1 can activate the enchantment, curse, or backlash during the procedure.

---

# Sealing Dangerous Treasures

Sealing contains a treasure without necessarily repairing, purifying, or destroying it.

## Threat Classes

| Threat Class | Description |
|---|---|
| **Restricted** | Dangerous mainly through misuse, theft, or unauthorized activation |
| **Hazardous** | Can injure handlers, leak energy, possess, corrupt, or activate accidentally |
| **Forbidden** | Uses unlawful souls, coercive identity loss, self-replicating corruption, or similar prohibited principles |
| **Calamity** | Threatens a settlement, region, spirit vein, Formation network, or large population |
| **Immortal Hazard** | Affects planes, worlds, laws, reincarnation, or Immortal authorities |

Threat Class is separate from grade. A Spiritual curse can be Forbidden, while an Imperial transport treasure can be merely Restricted.

## Temporary Quarantine

**Time:** 1 hour  
**Cost:** 1 percent of normal crafting value  
**Duration:** 7 days  
**Requirement:** Container or room appropriate to the threat

Temporary Quarantine:

- prevents ordinary activation;
- suppresses unattended leakage;
- blocks mundane handling;
- preserves evidence;
- grants Advantage on the next Deep Appraisal.

It does not suppress a property exceeding the quarantine's grade.

## Long-Term Seal

**Time:** 10 percent of normal crafting time  
**Cost:** 10 percent of normal crafting value  
**Duration:** Indefinite while maintained

The seal requires a formula, suitable facility, and components equal to the treasure's grade.

A Long-Term Seal must define:

- protected area or container;
- who can open it;
- command or key;
- maintenance interval;
- whether the Item Spirit can communicate;
- what happens if the seal is damaged;
- what power source sustains it;
- how warning and inspection occur.

A seal does not erase a curse or make a Forbidden treasure lawful.

## Calamity Containment

A Calamity or Immortal Hazard normally requires:

- several specialists;
- a site-bound Formation;
- redundant seals;
- a remote or defended location;
- a documented failure plan;
- spirit and soul protections;
- campaign-scale materials;
- periodic inspection.

A single portable box should not safely contain a world-threatening artifact unless that box is itself an equal-grade treasure.

---

# Destroying Dangerous Treasures

Destruction is not always the safest solution.

Before destruction, determine whether the treasure:

- contains an innocent spirit;
- seals another danger;
- anchors a Formation;
- supports a spirit vein;
- preserves a soul;
- contains unstable space;
- carries a curse that transfers to the destroyer;
- releases stored energy;
- has a specific destruction condition.

## Ordinary Destruction

A normal treasure can be destroyed through object damage when an effect reduces it to 0 Hit Points and explicitly destroys rather than Breaks it.

Destroying the vessel does not automatically destroy a surviving core or Item Spirit.

## Controlled Unmaking

**Time:** 50 percent of normal crafting time  
**Cost:** 25 percent of normal crafting value  
**Requirement:** Deep Appraisal, appropriate formula, facility, and safety plan

Controlled Unmaking:

- dismantles the treasure;
- neutralizes known charges;
- separates curses where possible;
- releases or rehouses spirits lawfully;
- recovers salvage according to Destroyed-with-Core or a better condition if the formula allows;
- prevents ordinary backlash.

A Forbidden or Calamity treasure can require additional conditions.

## Specific Destruction Conditions

Imperial and Immortal treasures often require one or more unique conditions:

- destroyed in the furnace that created it;
- struck by an equal Dao principle;
- willingly released by its spirit;
- unmade at a named location;
- deprived of every linked Anchor;
- subjected to a tribulation;
- returned to original materials;
- judged by a court or mandate;
- destroyed simultaneously across several bodies;
- sealed until a cosmic alignment.

If the condition is not met, reducing the artifact to 0 Hit Points normally leaves it Broken, Dormant, dispersed, or temporarily suppressed.

## Failed Destruction

A failed attempt can:

- activate the treasure;
- release a bound spirit;
- transfer a curse;
- open a gate;
- collapse a Formation;
- corrupt the facility;
- destroy evidence;
- scatter fragments;
- increase the treasure's hostility;
- convert the treasure into a Growth milestone for itself.

The procedure should state the likely failure before characters commit when appraisal has revealed it.

---

# Dormant Treasures

A Dormant treasure exists and may be structurally intact, but some or all supernatural properties are inactive.

Dormancy is not the same as Broken.

## Common Dormancy Causes

- all charges expended and no valid recharge source;
- missing bearer recognition;
- violated oath or taboo;
- Item Spirit refusal;
- Bond Strain;
- missing set component;
- sealed command word;
- absent linked location;
- depleted spirit stone or power source;
- incomplete awakening;
- interrupted Growth refinement;
- environmental requirement not met;
- curse suppression;
- voluntary self-sealing;
- Imperial or Immortal cycle;
- missing soul, core, or Formation Anchor.

## Appraising Dormancy

Careful Examination can determine that the treasure is Dormant.

Deep Appraisal identifies:

- which properties are inactive;
- why they are inactive;
- whether dormancy is protective, hostile, damaged, cyclical, or voluntary;
- whether awakening is safe;
- required bearer, resource, location, milestone, repair, or consent;
- what happens if awakening fails.

## Reactivation Categories

### Recharge

Supply the normal Long Rest, dawn, CP, spirit stone, incense, weather, celestial event, or facility stated by the treasure.

### Recognition

Complete an oath, lineage test, sect appointment, deed, offering, or Item Spirit negotiation.

### Repair

Restore damaged pathways, material, inscriptions, Nodes, core, or vessel.

### Reconnection

Return the treasure to a linked site, set, spirit vein, mirror, gate, command network, or Formation.

### Refinement

Complete an interrupted Growth advancement, reforge, transfer, or purification.

### Unsealing

Open or remove a deliberate seal using the correct key, command, authority, formula, or opposed check.

### Campaign Awakening

Fulfill an Imperial or Immortal story condition.

## Forced Awakening

A Dormant self-aware treasure can be forced only when a specific binding, command, or forbidden procedure permits it.

Forced awakening:

- does not create Accepted recognition;
- adds at least 1 Bond Strain;
- can activate curses or backlash;
- cannot compel an Item Spirit to erase itself;
- cannot bypass an Immortal story condition unless an equal authority says so.

---

# Worked Example: The Ash-Sealed Pilgrim Bell

The party discovers a cracked Saint Treasure bell inside a collapsed shrine.

## Quick Inspection

The bell is:

- Saint grade;
- made from funeral bronze and ghost iron;
- Operationally Damaged;
- spiritually active;
- marked with a damaged door-seal script.

## Careful Examination

A successful DC 15 appraisal reveals:

- the bell warns of hostile spirits;
- it requires Attunement;
- its 3 charges recharge at midnight;
- one charge can create a 20-foot-radius spirit ward for 1 minute;
- the bell currently has no charges.

The appraisal also reveals that the bell's occupied enchantment capacity is larger than its visible properties explain.

## Deep Appraisal

The bell is foreign, damaged, and deliberately concealed.

The final DC is 19:

- Base Saint DC 15;
- damaged +2;
- concealed +2.

On success, the appraiser discovers:

- the bell contains a suppressed Weapon Soul-equivalent spirit named Last Pilgrim;
- the spirit sealed itself after its previous bearer used it to imprison innocent ghosts;
- the bell is Dormant by voluntary refusal, not merely depleted;
- forcing activation would add Bond Strain and awaken a backlash curse;
- lawful reactivation requires repairing the crack, opening the shrine's burial ledger, and giving Last Pilgrim an acceptable funerary offering.

## Repair

Operational Damage costs 5 percent of Saint crafting value:

> 100 GT and 2.5 workdays

With the formula and a suitable workshop, repair requires no check.

## Reactivation

After repair and the offering, Last Pilgrim grants Accepted recognition.

The bell regains charges at the next midnight and its concealed spirit ward becomes available.

The treasure was not solved by Attuning blindly, striking it until it worked, or treating the spirit as salvage.

---

# Treasure Procedure Summary

## Identify

1. Quick Inspection.
2. Careful Examination.
3. Bond Examination when safe.
4. Deep Appraisal for concealed or dangerous treasures.
5. Record information level and unresolved questions.

## Repair

1. Determine damage state.
2. Stabilize if transport is unsafe.
3. Appraise core, material, curse, and spirit.
4. Pay condition-based cost and time.
5. Make a check only when the repair is genuinely risky.
6. Record retained and Dormant properties.

## Reforge

1. Define intended profile or chassis.
2. Confirm material and capacity.
3. Appraise every property.
4. Obtain spirit consent.
5. Pay reforge cost and time.
6. Transfer, redesign, or dormancy-lock incompatible expressions.

## Salvage

1. Deep Appraise.
2. Rehouse or release spirits.
3. Neutralize curses and charges.
4. Dismantle.
5. Calculate bounded material yield.
6. Record recovered imprints and Growth Reserve.
7. Do not treat market value as recoverable cash.

## Seal or Destroy

1. Assign Threat Class.
2. Determine what the treasure supports or contains.
3. Establish quarantine.
4. Discover special conditions.
5. Choose sealing, purification, controlled unmaking, or destruction.
6. Prepare for known failure consequences.

---

# Final Treasure Audit Record

Every treasure under formal inspection should produce a record containing:

- item name and identifier;
- apparent and confirmed grade;
- item family and legal chassis;
- Primary Material;
- current Hit Points and damage state;
- Attunement requirement;
- Refinement Bonus or Armor Refinement Bonus;
- enchantment capacity and occupied Equivalent Bonus;
- normal properties;
- concealed properties;
- charges and recharge;
- curse and Forbidden-refinement findings;
- Item Spirit or spirit-core status;
- Recognition and Bond Strain;
- Growth status and reserve;
- repair procedure;
- transfer compatibility;
- salvage yield;
- dormant conditions;
- sealing requirements;
- destruction conditions;
- lawful ownership or provenance;
- unresolved questions;
- appraiser, date, tools, evidence, and information level reached.

# Final Doctrine

Appraisal creates informed decisions.

Repair preserves identity.

Reforging changes form without granting free power.

Salvage recovers bounded material rather than duplicating value.

Sealing and destruction require understanding what the treasure contains, supports, remembers, and threatens.


# Chapter 9: Treasure Availability and Distribution
*GM Guidance for Markets, Rewards, Realms, and Attunement v0.1*

Treasure distribution determines more than wealth.

A treasure can establish:

- combat accuracy and defense;
- movement and exploration capabilities;
- access to storage, travel, communication, and recovery;
- sect rank and political authority;
- inheritance and lineage identity;
- the importance of crafting and material acquisition;
- what kinds of threats remain meaningful.

The GM should therefore distribute treasures deliberately rather than treating every listed price as guaranteed retail availability.

This chapter provides a standard campaign profile. Individual campaigns can be poorer, richer, more institutional, more auction-driven, or centered on a single inherited artifact.

---

# Core Distribution Principles

## Price Is Not Availability

The price of a treasure supports:

- crafting calculations;
- salvage and repair;
- auctions;
- requisition budgets;
- campaign accounting;
- negotiation.

It does not guarantee that the item is stocked, legal, transferable, correctly appraised, willing to accept the purchaser, or available without institutional approval.

## Grade Is Social Authority

Higher-grade treasures are not merely more expensive versions of lower-grade objects.

A higher grade often implies:

- restricted formulas;
- rare materials;
- superior facilities;
- recognized crafters;
- lineage permission;
- sect or state ownership;
- Item Spirit consent;
- military interest;
- political consequences;
- dangerous provenance.

## Access Is Broader Than Ownership

A character can have access to a treasure through:

- personal ownership;
- inheritance;
- sect requisition;
- temporary loan;
- office or rank;
- shared party custody;
- a recognized Item Spirit bond;
- a vehicle or site assignment;
- a mission-specific seal;
- Growth Treasure advancement.

The GM should record who owns the treasure, who can use it, who maintains it, and what happens when the relationship ends.

## Personal Treasures and Institutional Treasures Are Different

A personal treasure:

- normally travels with one bearer;
- can require Attunement;
- contributes directly to that character's combat and utility profile;
- can grow with the bearer.

An institutional treasure:

- belongs to a sect, clan, court, city, lineage, or organization;
- is often installed, loaned, or controlled by office;
- may serve many creatures;
- does not normally occupy personal Attunement slots unless its rules say otherwise;
- should not be counted as ordinary personal wealth.

## Same-Grade Access Is a Milestone

The grade associated with a character's current Realm should normally appear as a significant reward, commission, inheritance, or refinement achievement.

Lower-grade treasures can be frequent.

Same-grade signature treasures should remain memorable.

Higher-than-expected treasures should normally be:

- Dormant;
- sealed;
- incomplete;
- loaned;
- limited to one property;
- controlled by an institution;
- awaiting recognition;
- functioning as a Growth Treasure;
- usable only for a specific mission;
- a campaign objective rather than ordinary equipment.

---

# Grade Availability

| Grade | Typical Availability |
|---|---|
| **Spiritual Treasure** | Sect stores, cultivation markets, competent independent crafters, established cultivators, ordinary commissions, disciple rewards |
| **Saint Treasure** | Auctions, inheritances, inner-sect requisitions, dangerous commissions, lineage workshops, elite merchants, major adventure rewards |
| **Sovereign Treasure** | Great clans, ancient ruins, Realm powers, sect elders, state treasuries, protected auctions, military or diplomatic assignments |
| **Imperial Treasure** | National or sect-defining treasures, great inheritances, treasury assets, lineage cores, war-changing loans, ruler or ancestor recognition |
| **Immortal Artifact** | Campaign-defining and effectively priceless; unique inheritances, world ruins, Immortal authorities, cosmic events, final-growth awakenings |

## Availability by Acquisition Method

| Grade | Open Purchase | Commission | Auction | Requisition or Loan | Adventure or Inheritance |
|---|---|---|---|---|---|
| Spiritual | Common in cultivator society | Common | Common | Routine | Routine |
| Saint | Limited | Common with access | Common at major events | Rank-gated | Common |
| Sovereign | Rarely open | Restricted | Protected and uncommon | Council or state approval | Typical |
| Imperial | Normally unavailable | Institutional only | Extraordinary event | Normally a loan | Primary method |
| Immortal | Never ordinary | Unique campaign project | Not a normal market | Cosmic authority only | Primary method |

## Formula Availability

| Grade | Typical Formula Access |
|---|---|
| Spiritual | Sold, taught, licensed, or copied within ordinary cultivation institutions |
| Saint | Restricted by profession, sect, lineage, or guild; commissions are common |
| Sovereign | Protected strategic knowledge; formulas are rewards, inheritances, or state secrets |
| Imperial | Institutional identity; normally one workshop, lineage, court, or awakened spirit controls the method |
| Immortal | Unique Dao expression, lost inheritance, world procedure, or artifact-specific awakening |

## Material Availability

| Grade | Typical Material Source |
|---|---|
| Spiritual | Cultivator markets, regional harvesting, ordinary spirit mines |
| Saint | Dangerous sites, specialized farms, controlled mines, powerful beasts, auction houses |
| Sovereign | Ancient regions, Realm creatures, sect reserves, protected spirit veins, calamity remnants |
| Imperial | National treasuries, lineage hoards, world events, tribulations, unique sovereign beasts or materials |
| Immortal | Singular world sources, cosmic travel, Immortal remains, origin materials, campaign-specific procedures |

---

# Realm and Treasure Grade

The standard Tianxia relationship is:

| Cultivation Band | Cultivation Levels | Expected Signature Grade |
|---|---:|---|
| **Mortal Realm** | CL 1–4 | Spiritual Treasure |
| **Foundation Realm** | CL 5–9 | Saint Treasure |
| **Core Formation Realm** | CL 10–14 | Sovereign Treasure |
| **Nascent Realm** | CL 15–19 | Imperial Treasure |
| **Immortal Realm** | CL 20+ | Immortal Artifact |

This is a distribution guideline, not an automatic entitlement.

A character normally reaches the Realm before gaining unrestricted access to that Realm's signature grade.

---

# Expected Personal Treasure Access

The following table describes a standard campaign.

“Access” includes owned, inherited, bonded, or long-term issued treasures that the character can use consistently.

| Realm | Early-Realm Profile | Late-Realm Profile |
|---|---|---|
| Mortal | 0–1 Spiritual Treasure | 1–2 Spiritual Treasures |
| Foundation | 2 Spiritual; first Saint appears during the Realm | 1–2 Saint and 1–2 Spiritual |
| Core Formation | 2 Saint and 1 lower-grade utility treasure | 1 Sovereign, 2 Saint, and 1 Spiritual; a second Sovereign can appear as a capstone |
| Nascent | 1 Sovereign, 2 Saint, and 1 lower-grade treasure | 1 Imperial, 2 Sovereign, and 1 Saint; a second Imperial can appear as a capstone |
| Immortal | 1 Imperial and 2–3 Sovereign or lower treasures | Access to 1 Immortal Artifact plus Imperial or Sovereign support; the Artifact can occupy multiple slots |

A character does not need four attuned treasures at every level.

Empty Attunement slots are normal in lower-Realm, austere, exploration-focused, or crafting-focused campaigns.

## Standard Attuned Loadouts

These are examples, not mandatory packages.

### Late Mortal

- one Spiritual weapon, armor, shield, or signature Wondrous Treasure;
- one Spiritual utility or defensive treasure;
- two empty slots.

### Late Foundation

- one Saint signature treasure;
- one Saint or Spiritual defensive treasure;
- one or two Spiritual utility treasures.

### Late Core Formation

- one Sovereign signature treasure;
- two Saint treasures;
- one Spiritual utility treasure.

### Late Nascent

- one Imperial signature treasure;
- two Sovereign treasures;
- one Saint treasure.

### Established Immortal

- one Immortal Artifact occupying one or two slots;
- one or two Imperial treasures;
- remaining slots filled by Sovereign, Growth, Set, or Item-Spirit treasures as permitted.

---

# Attunement Economy

Every character normally has four Attunement slots.

Treasure distribution should make those four choices meaningful.

## Signature Slot

The highest-grade attuned treasure is normally the character's **Signature Treasure**.

A Signature Treasure commonly represents:

- primary weapon;
- main armor;
- shield;
- Item Spirit;
- inheritance;
- cultivation vessel;
- movement treasure;
- defining Wondrous Treasure.

A standard campaign normally gives each character one current-Realm Signature Treasure before routinely giving several.

## Supporting Slots

Supporting slots are normally filled with treasures one or more grades lower than the Signature Treasure.

Supporting treasures should:

- reinforce the character's style;
- solve a different problem;
- create a meaningful tradeoff;
- avoid repeating the same direct attack or Armor Class increase.

## Two-Slot Treasures

Item Spirits, Immortal Artifacts, Unified Set bonds, vehicles, and exceptional relics can occupy two slots.

A two-slot treasure should provide enough identity and utility to justify reducing the number of other choices.

## Non-Attunement Utility

Non-Attunement treasures can be more common than attuned combat treasures.

Examples include:

- storage;
- preservation;
- maps;
- measurement tools;
- ordinary communication;
- camp equipment;
- crafting aids;
- social and funerary items;
- sect records.

The GM should still consider logistics and setting availability, but these objects do not directly compress the four-slot combat economy.

## Treasure Sets

Treasure Sets pay the normal Attunement cost of every component unless the set explicitly has Unified Attunement.

A four-piece set occupying four slots is an intentional full build.

It should not be distributed accidentally one piece at a time without considering the final resonance.

---

# Combat Refinement Expectations

## Maximum Expected Grade-Derived Bonuses

| Realm | Typical Maximum Weapon Refinement | Typical Maximum Armor or Shield Refinement |
|---|---:|---:|
| Mortal | +1 attack and damage | +1 AC |
| Foundation | +2 attack and damage | +2 AC |
| Core Formation | +4 attack and damage | +3 AC |
| Nascent | +6 attack and damage | +4 AC |
| Immortal | +8 baseline or bespoke | +5 baseline or bespoke |

These are the maximum values associated with the Realm's signature grade.

They are not expected on every item.

## One Same-Grade Combat Piece

In a standard campaign, a character normally has one current-Realm combat treasure at full grade.

Examples:

- Sovereign weapon with Saint armor;
- Sovereign armor with Saint weapon;
- Sovereign shield with Saint armor and weapon;
- Sovereign Wondrous combat treasure with Saint weapon and armor.

A second same-grade combat treasure can appear:

- late in the Realm;
- as a major inheritance;
- after a dangerous commission;
- as a deliberate treasure-rich campaign choice;
- when the character sacrifices utility or set flexibility to support it.

## Weapon, Armor, and Shield Together

Weapon, armor, and shield Refinement Bonuses all affect core combat math.

Giving all three at the current signature grade creates a substantial increase in accuracy, damage, and Armor Class.

Treat that package as:

- a treasure-rich campaign;
- a late-Realm capstone;
- a defender or champion identity;
- a temporary institutional loan;
- an intentional high-power exception.

Do not distribute it accidentally because each item appears individually reasonable.

## Armor and Shield Stacking

Armor and shield Refinement Bonuses stack when both are legally used.

A character with same-grade armor and shield can have exceptionally high Armor Class.

Before awarding both at the highest expected grade, consider whether:

- the character is deliberately specializing in defense;
- the build spends two Attunement slots;
- the campaign includes saving throws, zones, movement, social pressure, environmental challenges, and objectives rather than only attack rolls;
- the rest of the party has comparable narrative and mechanical rewards.

Do not respond by making every enemy's attack bonus arbitrarily higher. Let the defensive investment matter while presenting varied challenges.

## Attack and Damage Bonuses

A same-grade weapon can materially change attack accuracy.

Before awarding a second highest-grade weapon or another direct attack bonus, check:

- whether the character already has a signature weapon;
- whether a flying or array weapon adds extra attacks;
- whether permanent damage enchantments apply every hit;
- whether consumable coatings stack;
- whether a Set Resonance adds attacks or attack bonuses;
- whether the item requires one or more Attunement slots.

---

# Early Higher-Grade Treasures

A campaign can introduce a higher-grade treasure before characters can safely use its full power.

Use one or more of the following models.

## Dormant Inheritance

The treasure functions at a lower grade until the bearer completes milestones, recognition, repair, or Growth refinement.

Recommended approach:

- retain the item's identity;
- cap grade-derived bonuses at the character's expected access grade;
- keep higher-grade expressions Dormant;
- reveal future abilities through appraisal and story.

## Sealed Loan

A sect, state, or elder loans the item with an authority seal.

The seal can limit:

- Refinement Bonus;
- active properties;
- charges;
- permitted targets;
- mission duration;
- geographic area;
- bearer;
- ability to reforge or transfer the treasure.

## Institutional Activation

The character carries or operates the treasure, but a site, elder, formation, office, or remote controller supplies its highest functions.

The treasure is not fully personal property.

## Single-Purpose Authorization

The bearer can activate one high-grade function for a named mission, target, gate, calamity, or ritual.

Afterward, the treasure becomes Dormant, returns to its owner, or requires institutional recharge.

## Growth Treasure

The object begins at a lower functional grade and advances with the party.

This is often the cleanest model for a legendary inheritance introduced early.

## Shared Party Asset

A high-grade vehicle, palace, formation core, or communication network can support the party without giving one character its full personal combat bonuses.

---

# Campaign Treasure Profiles

Choose a profile before distributing permanent treasures.

## Austere Cultivation

Use when the campaign emphasizes:

- survival;
- scarce materials;
- self-refinement;
- dangerous crafting;
- ruins;
- long-term Growth Treasures.

Guidance:

- characters often have only two or three attuned treasures;
- same-Realm signature treasures appear late;
- commissions and repair matter;
- consumables and temporary items are important;
- higher-grade items are usually Dormant or incomplete.

## Standard Cultivation

Use the expected-access tables in this chapter.

Guidance:

- three to four attuned treasures by Foundation or Core;
- one same-Realm Signature Treasure during each Realm;
- second same-Realm treasure near the Realm's end;
- consumables and lower-grade utility rewards remain frequent;
- institutional loans appear for exceptional missions.

## Treasure-Rich Cultivation

Use when the campaign emphasizes:

- auctions;
- great clans;
- item combinations;
- regalia;
- Treasure Sets;
- frequent crafting;
- sect warfare.

Guidance:

- four attuned slots are usually filled;
- current-Realm treasure appears early;
- two current-Realm treasures are common by mid-Realm;
- characters possess many non-Attunement utility treasures;
- the GM should audit combined attack, damage, AC, reaction, and movement effects.

Treasure-rich does not increase Attunement capacity by itself.

## Inheritance or Artifact Campaign

The campaign centers on one major treasure introduced early.

Guidance:

- the central treasure begins Dormant, sealed, Broken, divided, or functioning at a lower grade;
- its awakening replaces some ordinary permanent-treasure rewards;
- milestones, spirits, materials, and repair drive the campaign;
- other items remain mostly supporting treasures;
- the Artifact should not provide full Immortal authority at low Realm.

---

# Reward Pacing

## Frequent Rewards

These can appear in most adventures:

- consumables;
- spirit stones;
- special materials;
- repair supplies;
- appraisal records;
- formulas;
- Growth catalysts;
- temporary seals;
- lower-grade ammunition and coatings;
- contribution points;
- access to a workshop or specialist.

## Regular Rewards

These can appear every few meaningful adventures:

- lower-grade permanent utility treasures;
- new formulas;
- replacement set pieces;
- Growth milestones;
- Attunement-compatible support items;
- long-term sect loans;
- materials toward a same-grade commission.

## Major Rewards

These normally conclude an arc, dangerous commission, major ruin, tournament, war objective, sect advancement, or Realm transition:

- same-Realm Signature Treasure;
- major Growth advancement;
- awakened Weapon Soul or Item Spirit;
- Sovereign or Imperial infrastructure;
- complete Treasure Set threshold;
- protected formula;
- inheritance recognition;
- permanent ownership of a former loan.

## Realm-Capstone Rewards

A Realm-capstone reward can be:

- a second same-grade combat treasure;
- advancement of a Signature Treasure;
- a complete high-grade Set;
- an institutional title carrying treasure access;
- a major vehicle or residence;
- preparation for the next Realm's treasure grade;
- a higher-grade Dormant inheritance.

---

# Suggested Reward Packages by Realm

## Mortal Adventure Package

A typical meaningful reward can contain:

- 1–4 Spiritual consumables or batches;
- 1–3 Spirit Shards or part of a Low-Grade Spirit Stone;
- one useful material;
- one formula or appraisal clue;
- occasional party-shared Spiritual utility treasure.

A permanent Spiritual combat treasure should feel significant.

## Foundation Adventure Package

A typical meaningful reward can contain:

- several Spiritual or Saint consumables;
- Low-Grade Spirit Stones;
- Saint-grade material fragments;
- a Spiritual permanent treasure;
- progress toward a Saint commission;
- SCP or authorization.

A complete Saint Treasure is normally a major reward.

## Core Formation Adventure Package

A typical meaningful reward can contain:

- Saint permanent treasure;
- Mid-Grade Spirit Stones;
- Sovereign catalyst or formula fragment;
- protected auction access;
- major Growth milestone;
- temporary Sovereign loan.

A complete Sovereign Treasure is normally an arc reward.

## Nascent Adventure Package

A typical meaningful reward can contain:

- Sovereign permanent treasure;
- High-Grade Spirit Stones;
- Imperial material fragment;
- office or treasury access;
- national commission;
- Imperial loan;
- repair or awakening of a lineage treasure.

A complete Imperial Treasure is normally a major campaign reward.

## Immortal Adventure Package

A typical meaningful reward can contain:

- Imperial treasures;
- Perfect Spirit Stones;
- world coordinates;
- Immortal materials;
- artifact repair;
- world-scale Formation authority;
- an Artifact milestone;
- access to a unique Immortal procedure.

An Immortal Artifact is never routine treasure.

---

# Markets and Institutions

## Market Tiers

| Market Tier | Example | Typical Stock |
|---|---|---|
| 0 | Mortal village or ordinary town | Mundane gear, ordinary medicine, no routine permanent cultivation treasures |
| 1 | Cultivator outpost or minor sect market | Spiritual consumables; 1–4 rotating Spiritual permanent treasures; Saint commissions may be known |
| 2 | Major sect town or auction city | Broad Spiritual stock; 1–4 Saint treasures through auction, commission, or restricted sale |
| 3 | Regional capital or great-clan market | Broad Saint access for qualified buyers; 0–1 Sovereign treasure under restriction; Imperial items are known but not stocked |
| 4 | Great sect, state treasury, ancestral capital | Sovereign requisitions and loans; several institutional Sovereign assets; 1 or more Imperial lineage or state treasures |
| 5 | Immortal domain, world ruin, celestial court | Unique Imperial and Immortal access governed entirely by story, authority, and recognition |

The listed stock is a campaign starting point. It does not refresh automatically every day.

## Stock Refresh

A market's stock changes after:

- a season;
- a major caravan;
- an auction;
- a sect expedition;
- a war;
- a spirit-vein harvest;
- a new crafter arrives;
- a ruin is opened;
- a political shift;
- a major commission completes.

Repeatedly leaving and reentering a market does not generate new treasures.

## Auctions

Auctions are appropriate for:

- Saint treasures;
- occasional Sovereign treasures;
- formulas;
- rare materials;
- damaged or Dormant items;
- unclaimed inheritances;
- legal but politically sensitive objects.

Before an auction, determine:

- appraisal reliability;
- legal ownership;
- reserve price;
- interested factions;
- whether bidding uses money, SCP, favors, or service;
- whether the treasure recognizes the buyer;
- concealed risks;
- transport and security.

Imperial treasures are auctioned only during extraordinary events and often represent political transfers rather than ordinary commerce.

## Commissions

A commission requires more than payment.

Determine:

- formula access;
- material source;
- facility;
- crafter;
- waiting time;
- political permission;
- bearer compatibility;
- risk of rival interference;
- whether the commission creates a public obligation.

A commission is an excellent method for turning treasure acquisition into several adventures rather than one shopping scene.

---

# Sect Requisition and Loans

## Requisition Access

The Chapter 1 SCP values remain the standard budget reference.

| Requisition | Typical SCP | Typical Approval |
|---|---:|---|
| Spiritual Treasure | 20 SCP | Appropriate standing |
| Saint Treasure | 200 SCP | Inner disciple, officer, or sponsor |
| Sovereign Treasure | 2,000 SCP | Core disciple, elder sponsor, or council |
| Imperial Treasure | 10,000 SCP | Sect council; normally a loan |
| Immortal Artifact | Not purchasable | Campaign-level authority |

Stock, mission need, office, and political trust still apply.

## Loan Terms

An institutional loan should record:

- owner;
- bearer;
- allowed mission;
- permitted properties;
- return date or condition;
- maintenance responsibility;
- loss or destruction consequences;
- reforge and transfer prohibition;
- whether Growth milestones remain with the item;
- whether the bearer can earn permanent recognition.

A loaned treasure occupies Attunement slots normally.

## Mission Seals

A mission seal can restrict a loaned treasure to:

- one target;
- one region;
- one duration;
- one charge pool;
- one bearer;
- one formation network;
- one authority chain.

This permits higher-grade participation without granting unrestricted ownership.

## Lost or Destroyed Loans

Consequences should reflect circumstances.

Possible consequences include:

- debt;
- SCP loss;
- investigation;
- replacement mission;
- political damage;
- loss of office;
- obligation to recover the spirit core;
- no penalty when destruction fulfilled the authorized mission.

Do not punish characters merely because a properly used treasure was destroyed by a threat the lender knowingly assigned.

---

# Party-Shared Treasures

Some treasures belong to the group rather than one character.

Examples include:

- transport vehicles;
- camp formations;
- communication mirrors;
- libraries;
- workshops;
- medicine cabinets;
- portable pavilions;
- sect seals;
- residence or garden treasures;
- Treasure Set infrastructure.

## Shared-Asset Guidance

A shared asset should state:

- custodian;
- storage location;
- who can activate it;
- whether anyone must Attune;
- maintenance;
- operating costs;
- travel limits;
- what happens if the party divides;
- whether the asset can be sold;
- whether the owner can recall it.

Shared assets do not normally count against each character's personal expected treasure profile.

A personally attuned shared asset does count against that bearer's Attunement slots.

---

# Treasure Scarcity and Replacement

## Destruction Should Matter Without Ending a Character

When a signature treasure is Broken or Destroyed:

- use Chapter 8 repair and reconstruction;
- provide access to salvage, specialists, and replacement materials;
- preserve Item Spirits where the rules allow;
- turn recovery into an adventure;
- avoid replacing the treasure instantly unless the campaign treats items as disposable.

## Replacement Timing

A supporting lower-grade treasure can usually be replaced through:

- purchase;
- requisition;
- commission;
- salvage;
- party reserves.

A same-Realm Signature Treasure should normally require:

- major payment;
- a new arc;
- recovery of the core;
- inheritance;
- Growth refinement;
- institutional authorization.

## Character Build Dependence

If a character's core concept depends on one treasure, establish one of the following:

- recoverable core;
- Growth Treasure protection;
- Item Spirit survival;
- institutional replacement;
- alternate lower-grade function while Broken;
- explicit repair access.

The GM should not casually remove a concept-defining treasure with no path to recovery.

---

# Treasure Distribution Audit

Review each character at major level and Realm milestones.

## Personal Profile

Record:

- number of Attunement slots filled;
- highest treasure grade;
- Signature Treasure;
- weapon Refinement Bonus;
- armor Refinement Bonus;
- shield Refinement Bonus;
- direct attack bonuses;
- permanent damage riders;
- defensive reactions;
- teleportation and flight;
- Resistance and Immunity;
- resource recovery;
- Item Spirits;
- Set Resonances;
- current-grade treasures;
- institutional loans.

## Party Profile

Record:

- total permanent treasures by grade;
- consumable stock;
- party storage;
- long-range transport;
- communication;
- healing and resurrection;
- crafting facilities;
- formation infrastructure;
- shared vehicles and residences;
- access to appraisal and repair;
- political ownership and debt.

## Warning Signs

Review distribution when:

- one character has three current-Realm combat treasures and another has none;
- same-grade armor and shield make ordinary attack rolls irrelevant;
- permanent damage riders multiply across every hit without an intended power increase;
- reaction treasures eliminate most incoming damage;
- repeated resource-restoration treasures erase Path-resource pressure;
- an early Artifact grants unrestricted high-grade functions;
- Treasure Sets bypass Attunement;
- institutional assets are treated as free personal property;
- market prices are treated as guaranteed stock;
- every reward is a stronger combat item and utility or story treasures disappear.

## Corrections

Prefer:

- utility rewards;
- Growth milestones;
- formulas;
- materials;
- temporary loans;
- support treasures;
- new applications for existing items;
- repair and awakening;
- set completion;
- institutional access;
- rewards for under-equipped characters.

Do not routinely correct over-distribution by stealing, destroying, or arbitrarily suppressing treasures without story support.

---

# Quick GM Tables

## Grade Source

| d8 | Source |
|---:|---|
| 1 | Sect reward or requisition |
| 2 | Commissioned from a specialist |
| 3 | Auction or private sale |
| 4 | Inheritance or recognized lineage |
| 5 | Ruin, tomb, or abandoned workshop |
| 6 | Defeated rival or recovered battlefield relic |
| 7 | Growth advancement of an existing treasure |
| 8 | State, clan, spirit, or world authority loan |

## Treasure Condition

| d8 | Condition |
|---:|---|
| 1 | Intact and fully appraised |
| 2 | Intact but missing command or formula |
| 3 | Operationally Damaged |
| 4 | Broken with core intact |
| 5 | Dormant pending recognition |
| 6 | Part of an incomplete Treasure Set |
| 7 | Contains a concealed property or curse |
| 8 | Housed Item Spirit has its own demand |

## Ownership Complication

| d8 | Complication |
|---:|---|
| 1 | Legitimate prior owner survives |
| 2 | Sect or state claims the treasure |
| 3 | Item Spirit rejects sale |
| 4 | Treasure was pledged as collateral |
| 5 | Formula belongs to another lineage |
| 6 | Current bearer has only temporary authority |
| 7 | Rival inheritance recognizes a different heir |
| 8 | Ownership is lawful, but use triggers political consequences |

---

# Standard Campaign Summary

For a standard Tianxia campaign:

1. Spiritual treasures become available in cultivator society.
2. Saint treasures are major personal rewards.
3. Sovereign treasures are arc rewards and institutional assets.
4. Imperial treasures define nations, lineages, and great sects.
5. Immortal Artifacts define campaigns.
6. A character normally has one current-Realm Signature Treasure.
7. Supporting attuned treasures are usually lower grade.
8. A second current-Realm combat treasure appears late or by deliberate campaign choice.
9. Weapon, armor, and shield grade bonuses are audited together.
10. Non-Attunement utility treasures and consumables can be more frequent.
11. Higher-grade treasures introduced early are Dormant, sealed, loaned, incomplete, or Growth-based.
12. Prices support budgeting but do not guarantee market availability.

# Final Doctrine

Treasure access should make advancement visible without turning every level into equipment replacement.

The best distribution gives each character:

- one recognizable signature;
- meaningful Attunement choices;
- lower-grade tools that remain useful;
- access to crafting, repair, and growth;
- occasional institutional power;
- reasons to explore, negotiate, inherit, refine, and protect what they already possess.


# Chapter 10: Random and Curated Treasure Tables
*Completed-Entry GM Tables v0.1*

These tables generate treasure finds without inventing unreviewed mechanics.

Every mechanical result points to an existing entry in:

- Chapter 2B, Primary Weapon Materials;
- Chapter 3B, Armor Materials;
- Chapter 4, Wondrous Treasures;
- Chapter 5, Consumable Treasures;
- Chapter 7, Treasure Sets;
- Chapter 8, appraisal, damage, dormancy, repair, sealing, and salvage procedures;
- Chapter 9, availability, ownership, loan, and distribution guidance.

Descriptive details such as ownership, damage, installation, missing pieces, or Dormancy use the existing procedures. They do not add unprinted powers.

---

# Using These Tables

## 1. Choose the Campaign Profile

Use Chapter 9 to determine whether the campaign is:

- Austere;
- Standard;
- Treasure-Rich;
- centered on an Inheritance or Artifact.

## 2. Establish the Maximum Grade

Use the party's Realm, the location, and the importance of the reward.

A roll producing a treasure above the intended grade should normally become:

- a temporary loan;
- a Dormant inheritance;
- a Broken or incomplete treasure;
- an institutional asset;
- a mission-sealed treasure;
- a campaign objective.

Do not silently grant unrestricted ownership of a higher-grade treasure.

## 3. Choose or Roll a Table

The GM can:

- roll openly;
- roll privately;
- choose a fitting row;
- roll twice and select one;
- combine a treasure result with one condition result;
- replace a result already owned by the party.

## 4. Use the Printed Entry

The table result does not summarize or replace the item.

Open the referenced chapter and use the complete entry.

## 5. Record Custody and Condition

For permanent treasures, record:

- owner;
- bearer;
- Attunement;
- appraisal level;
- condition;
- charges;
- Item Spirit or recognition;
- loan or return terms;
- whether the object is part of a set.

---

# Source Key

| Reference | Meaning |
|---|---|
| **Chapter 4 #N** | Named permanent Wondrous Treasure |
| **Chapter 5 #N** | Named Consumable Treasure and its printed batch |
| **Chapter 7 Set #N** | Complete Treasure Set rules and components |
| **Chapter 2B — Name** | Completed weapon material entry |
| **Chapter 3B — Name** | Completed armor material entry |
| **Chapter 8** | Condition, appraisal, repair, Dormancy, sealing, or salvage procedure |
| **Chapter 9** | Availability, ownership, requisition, loan, and grade pacing |

---

# Treasure by Grade

## Spiritual Treasure — d20

| Roll | Result |
|---:|---|
| 1 | **Cultivator's Storage Ring** (Chapter 4 #1) |
| 2 | **Hundred-Herb Preservation Gourd** (Chapter 4 #2) |
| 3 | **Spirit-Stone Counting Abacus** (Chapter 4 #7) |
| 4 | **Cloudstep Jade Anklets** (Chapter 4 #11) |
| 5 | **Homeward Compass Disc** (Chapter 4 #15) |
| 6 | **Paired Whispering Jade** (Chapter 4 #19) |
| 7 | **Truth-Resonance Court Bell** (Chapter 4 #21) |
| 8 | **Source-Vein Appraisal Needle** (Chapter 4 #25) |
| 9 | **Still-Breath Cultivation Mat** (Chapter 4 #28) |
| 10 | **Twelve-Breath Recovery Beads** (Chapter 4 #31) |
| 11 | **Alchemist's Steady-Flame Tripod** (Chapter 4 #35) |
| 12 | **Talisman Inkstone of Even Flow** (Chapter 4 #38) |
| 13 | **Clear-Water Purification Pearl** (Chapter 4 #43) |
| 14 | **One-Step Escape Talisman Box** (Chapter 4 #45) |
| 15 | **Quiet-Camp Boundary Stakes** (Chapter 4 #53) |
| 16 | **Moonlit Map Cloth** (Chapter 4 #63) |
| 17 | **Nine-Breath Recovery Pill** (Chapter 5 #1) — one standard batch |
| 18 | **Dragon-Furnace Explosive Pellet** (Chapter 5 #11) — one standard batch |
| 19 | **Swift-Step Talisman** (Chapter 5 #21) — one standard batch |
| 20 | **Alert Boundary Stake Kit** (Chapter 5 #61) — one complete kit |

## Saint Treasure — d20

| Roll | Result |
|---:|---|
| 1 | **Mountain-Root Suppression Seal** (Chapter 4 #81) |
| 2 | **Moon-Mirror Stillwater Mantle** (Chapter 4 #84) |
| 3 | **Nine-Lock Storage Ring** (Chapter 4 #86) |
| 4 | **Cloud Palace Travel Pavilion** (Chapter 4 #88) |
| 5 | **Source-Heaven Compass** (Chapter 4 #91) |
| 6 | **Thousand-Li Communication Mirror** (Chapter 4 #92) |
| 7 | **Ancestor-Questioning Incense Burner** (Chapter 4 #94) |
| 8 | **Oath-Binding Court Seal** (Chapter 4 #98) |
| 9 | **Soul-Wound Mending Needle Case** (Chapter 4 #100) |
| 10 | **Cloud-Riding Crane Carving** (Chapter 4 #104) |
| 11 | **Verdant Garden Seed Box** (Chapter 4 #108) |
| 12 | **Formation-Linked Camp Banner** (Chapter 4 #117) |
| 13 | **Hidden-Step Shadow Boots** (Chapter 4 #121) |
| 14 | **Wandering Healer's Hundred-Medicine Cabinet** (Chapter 4 #134) |
| 15 | **Meridian-Cleansing Elixir** (Chapter 5 #7) — one standard batch |
| 16 | **Five-Poison Cloud Pellet** (Chapter 5 #16) — one standard batch |
| 17 | **Thunder-Escape Talisman** (Chapter 5 #26) — one standard batch |
| 18 | **Meridian-Recovery Incense** (Chapter 5 #36) — one standard batch |
| 19 | **Twin-Gate Transit Array Plates** (Chapter 5 #67) — one paired kit |
| 20 | **Hundred-Medicine Traveling Clinic** (Chapter 7 Set #5) |

## Sovereign Treasure — d20

| Roll | Result |
|---:|---|
| 1 | **Nine-Dragon Binding Seal** (Chapter 4 #136) |
| 2 | **Source-Heaven Grand Compass** (Chapter 4 #137) |
| 3 | **Li-Fire Restoring Furnace** (Chapter 4 #138) |
| 4 | **Star-Road Crossing Chariot** (Chapter 4 #139) |
| 5 | **Thousand-Mile Cloud Palace** (Chapter 4 #140) |
| 6 | **Soul-Reincarnation Waiting Lamp** (Chapter 4 #141) |
| 7 | **Five-Phase Refinement Cauldron** (Chapter 4 #143) |
| 8 | **Mountain-and-River Suppression Map** (Chapter 4 #144) |
| 9 | **Void-Nail Boundary Pagoda** (Chapter 4 #149) |
| 10 | **Ocean-Stilling Pearl** (Chapter 4 #151) |
| 11 | **Thousand-Script Jade Library** (Chapter 4 #155) |
| 12 | **World-Tree Sapling Urn** (Chapter 4 #157) |
| 13 | **Heaven-Thread Fate Loom** (Chapter 4 #165) |
| 14 | **Nine-Revolution Restoration Pill** (Chapter 5 #9) — one standard batch |
| 15 | **Calamity-Star Pellet** (Chapter 5 #19) — one standard batch |
| 16 | **Nine-Lock Demon Suppression Seal** (Chapter 5 #29) — one seal |
| 17 | **Nine-Palace Battlefield Disk** (Chapter 5 #69) — one disk |
| 18 | **Three-Star Flying Sword Array** (Chapter 7 Set #4) |
| 19 | **Black Tortoise Fortress Panoply** (Chapter 7 Set #6) |
| 20 | **Eight-Trigram Boundary Formation Set** (Chapter 7 Set #8) |

## Imperial Treasure — d20

| Roll | Result |
|---:|---|
| 1 | **Cauldron of Ten Thousand Burdens** (Chapter 4 #171) |
| 2 | **Heaven-Veil Imperial Mantle** (Chapter 4 #172) |
| 3 | **Sect-Guardian Heaven Bell** (Chapter 4 #173) |
| 4 | **Nine-Heavens Star-Road Altar** (Chapter 4 #174) |
| 5 | **Five-Emperors World-Refining Furnace** (Chapter 4 #175) |
| 6 | **Phoenix Rebirth Palace Seed** (Chapter 4 #177) |
| 7 | **Ocean-Subduing Sovereign Pearl** (Chapter 4 #178) |
| 8 | **Imperial Ancestor Court** (Chapter 4 #180) |
| 9 | **Heaven-Observing Mirror Tower** (Chapter 4 #181) |
| 10 | **Void-Crossing Jade Ark** (Chapter 4 #184) |
| 11 | **Celestial Formation Command Board** (Chapter 4 #186) |
| 12 | **Moon-Palace Preservation Coffin** (Chapter 4 #188) |
| 13 | **Imperial Medicine King's Cabinet** (Chapter 4 #189) |
| 14 | **Imperial Sunfire Annihilation Pellet** (Chapter 5 #20) — one pellet |
| 15 | **Imperial Heaven-Cleansing Incense** (Chapter 5 #40) — one bundle |
| 16 | **Imperial Feast of Returning Spring** (Chapter 5 #50) — one six-serving feast |
| 17 | **Imperial Emperor-Killing Venom** (Chapter 5 #60) — one dose |
| 18 | **Imperial Boundary-Breaking Escape Order** (Chapter 5 #80) — one order |
| 19 | **Imperial Heaven-Splitting Weapon Oil** (Chapter 5 #90) — one application |
| 20 | **Five-Regalia of the Azure Mandate** (Chapter 7 Set #9) |

## Immortal Artifact — d20

| Roll | Result |
|---:|---|
| 1 | **World-Seed Ring** (Chapter 4 #191) |
| 2 | **Celestial Crossing Bronze Ark** (Chapter 4 #192) |
| 3 | **Heaven-Sealing Mandate Fragment** (Chapter 4 #193) |
| 4 | **Primordial Mother Qi Cauldron** (Chapter 4 #194) |
| 5 | **Ten-Thousand Worlds Compass** (Chapter 4 #195) |
| 6 | **Eternal Reincarnation Lamp** (Chapter 4 #196) |
| 7 | **Dao-Source Enlightenment Tree Seed** (Chapter 4 #197) |
| 8 | **Coffin of the Nine Heavens** (Chapter 4 #198) |
| 9 | **Immortal Court Bell of Returning Names** (Chapter 4 #199) |
| 10 | **World-Heart Formation Core** (Chapter 4 #200) |
| 11 | **Heaven-Defying Rebirth Pill** (Chapter 5 #10) — one pill |
| 12 | **Heaven-Law Command Talisman** (Chapter 5 #30) — one talisman |
| 13 | **Heaven-Earth Rewriting Array Core** (Chapter 5 #70) — one grand-array core |
| 14 | **World-Seed Ring** (Chapter 4 #191) — Dormant; use Chapter 8 to determine reactivation |
| 15 | **Heaven-Sealing Mandate Fragment** (Chapter 4 #193) — sealed as an Immortal Hazard under Chapter 8 |
| 16 | **Eternal Reincarnation Lamp** (Chapter 4 #196) — preserving a willing soul; custody is institutional |
| 17 | **Coffin of the Nine Heavens** (Chapter 4 #198) — closed and inaccessible until a campaign condition is met |
| 18 | **Immortal Court Bell of Returning Names** (Chapter 4 #199) — missing its recorded-name archive but otherwise intact |
| 19 | **World-Heart Formation Core** (Chapter 4 #200) — only the surviving core; installation remains a campaign project |
| 20 | **Celestial Crossing Bronze Ark** (Chapter 4 #192) — loaned for one world-crossing mission under Chapter 9 |

# Treasure by Sphere Influence

Use this index when a reward should reinforce a known Sphere, sect tradition, enemy style, environment, or character concept.

The index includes every Sphere Influence tag used by the completed Chapter 4 and Chapter 5 catalogs.

A blank column means that the current catalog contains no entry of that type using the exact tag.

| Sphere Influence | Permanent Treasure Examples | Consumable Examples |
|---|---|---|
| Acid | — | **Bone-Melting Corrosive Pellet** (Ch. 5 #15)<br>**Armor-Eating Acid Varnish** (Ch. 5 #85) |
| Air | **Cloudstep Jade Anklets** (Ch. 4 #11)<br>**Five-Feather Calamity Fan** (Ch. 4 #82)<br>**Thousand-Mile Cloud Palace** (Ch. 4 #140)<br>**Wind-Reading Travel Fan** (Ch. 4 #14) | **Swift-Step Talisman** (Ch. 5 #21)<br>**Water-Breathing Talisman** (Ch. 5 #25)<br>**Cloudstep Plum Wine** (Ch. 5 #43) |
| Alchemy | **Hundred-Herb Preservation Gourd** (Ch. 4 #2)<br>**Pill-Refining Jade Gourd** (Ch. 4 #90)<br>**Five-Phase Refinement Cauldron** (Ch. 4 #143)<br>**Cauldron of Ten Thousand Burdens** (Ch. 4 #171) | **Nine-Breath Recovery Pill** (Ch. 5 #1)<br>**Bone-Knitting Jade Paste** (Ch. 5 #6)<br>**Nine-Revolution Restoration Pill** (Ch. 5 #9) |
| Ash | **Forgotten-Age Ash Urn** (Ch. 4 #164) | — |
| Athletics | **Cloudstep Jade Anklets** (Ch. 4 #11)<br>**Hidden-Step Shadow Boots** (Ch. 4 #121)<br>**River-Crossing Reed Sandals** (Ch. 4 #12)<br>**Cliff-Clinging Gecko Gloves** (Ch. 4 #13) | **Swift-Step Talisman** (Ch. 5 #21)<br>**Dragon-Marrow Strength Wine** (Ch. 5 #47)<br>**Cloudstep Plum Wine** (Ch. 5 #43) |
| Authority | **Ocean-Subduing Sovereign Pearl** (Ch. 4 #178)<br>**Heaven-Sealing Mandate Fragment** (Ch. 4 #193)<br>**Karma-Judgment Golden Scale** (Ch. 4 #182)<br>**Heaven-Mandate Transmission Seal** (Ch. 4 #190) | **Imperial Boundary-Breaking Escape Order** (Ch. 5 #80)<br>**Heaven-Law Command Talisman** (Ch. 5 #30) |
| Beastmastery | **Beast-Feed Preservation Jar** (Ch. 4 #4)<br>**Hundred-Beast Holding Bag** (Ch. 4 #87)<br>**Ten-Thousand Beast Command Bell** (Ch. 4 #146)<br>**Ten-Thousand Spirit Bestiary Pavilion** (Ch. 4 #179) | **Beast-Calming Cedar Incense** (Ch. 5 #34)<br>**Spirit-Beast Hunter Toxin** (Ch. 5 #54)<br>**Beast-Decoy Skin Doll** (Ch. 5 #75) |
| Beauty | **Guest-Right Tea Service** (Ch. 4 #46)<br>**Thousand-Voice Music Box** (Ch. 4 #111)<br>**Spirit-Calming Offering Bowl** (Ch. 4 #48)<br>**Borrowed-Voice Reed Flute** (Ch. 4 #58) | **Truth-Loosening Draught** (Ch. 5 #55)<br>**Incense of Truthful Counsel** (Ch. 5 #38) |
| Blacksmith | **Dustless Workshop Chest** (Ch. 4 #9)<br>**Blacksmith's Nine-Heat Furnace** (Ch. 4 #129)<br>**Li-Fire Restoring Furnace** (Ch. 4 #138)<br>**Cauldron of Ten Thousand Burdens** (Ch. 4 #171) | — |
| Blood | **Bloodline Recognition Mirror** (Ch. 4 #99)<br>**Bloodline-Ancestral Gate Mirror** (Ch. 4 #159)<br>**Thousand-Li Pursuit Compass** (Ch. 4 #163) | **Imperial Emperor-Killing Venom** (Ch. 5 #60) |
| Body Refining | — | **Iron-Bone Broth** (Ch. 5 #42)<br>**Bone-Knitting Jade Paste** (Ch. 5 #6)<br>**Furnace-Body Tempering Pill** (Ch. 5 #8) |
| Chains | **Nine-Dragon Binding Seal** (Ch. 4 #136) | **Minor Binding Array Flags** (Ch. 5 #65)<br>**Nine-Lock Demon Suppression Seal** (Ch. 5 #29) |
| Dao | **Heaven-Sealing Mandate Fragment** (Ch. 4 #193)<br>**Dao-Source Enlightenment Tree Seed** (Ch. 4 #197) | **Imperial Heaven-Splitting Weapon Oil** (Ch. 5 #90)<br>**Heaven-Law Command Talisman** (Ch. 5 #30)<br>**Heaven-Earth Rewriting Array Core** (Ch. 5 #70) |
| Dark | **Heart-Demon Warning Mirror** (Ch. 4 #32) | **Black-Dregs Smoke Pellet** (Ch. 5 #13) |
| Death | **Grave-Quiet Listening Bell** (Ch. 4 #24)<br>**Ancestor-Questioning Incense Burner** (Ch. 4 #94)<br>**Soul-Reincarnation Waiting Lamp** (Ch. 4 #141)<br>**Eternal Reincarnation Lamp** (Ch. 4 #196) | **Ancestor-Calling Temple Incense** (Ch. 5 #39)<br>**Imperial Emperor-Killing Venom** (Ch. 5 #60)<br>**Heaven-Defying Rebirth Pill** (Ch. 5 #10) |
| Destruction | — | **Dragon-Furnace Explosive Pellet** (Ch. 5 #11)<br>**Imperial Sunfire Annihilation Pellet** (Ch. 5 #20)<br>**Bone-Melting Corrosive Pellet** (Ch. 5 #15) |
| Disease | — | **Hundred-Ache Contact Poison** (Ch. 5 #58) |
| Dragon | **Nine-Dragon Binding Seal** (Ch. 4 #136)<br>**Dragon-Pulse Surveying Pillar** (Ch. 4 #168) | **Dragon-Marrow Strength Wine** (Ch. 5 #47) |
| Drain | — | **Qi-Draining Black Venom** (Ch. 5 #57) |
| Dreams | **Memory-Impression Jade Slip** (Ch. 4 #22)<br>**Dream-Path Lantern** (Ch. 4 #93)<br>**Dream-Mirror Hall Seed** (Ch. 4 #142)<br>**Thousand-Dream Palace Lantern** (Ch. 4 #185) | **Calming Heart Elixir** (Ch. 5 #4)<br>**Dreamless-Sleep Incense** (Ch. 5 #35)<br>**Sleep-Lotus Extract** (Ch. 5 #52) |
| Drunken Style | — | **Spirit-Grain Recovery Wine** (Ch. 5 #41) |
| Earth | **Cliff-Clinging Gecko Gloves** (Ch. 4 #13)<br>**Mountain-Root Suppression Seal** (Ch. 4 #81)<br>**Source-Heaven Grand Compass** (Ch. 4 #137)<br>**Dragon-Vein Mountain Gate Seal** (Ch. 4 #176) | **Minor Binding Array Flags** (Ch. 5 #65)<br>**Earth-Passing Jade Shard** (Ch. 5 #72) |
| Equipment | **Cultivator's Storage Ring** (Ch. 4 #1)<br>**Nine-Lock Storage Ring** (Ch. 4 #86)<br>**Folded-Sleeve Satchel** (Ch. 4 #3)<br>**Talisman-Flat Jade Case** (Ch. 4 #5) | **Body-Guarding Talisman** (Ch. 5 #22)<br>**Earth-Passing Jade Shard** (Ch. 5 #72) |
| Fate | **Truth-Resonance Court Bell** (Ch. 4 #21)<br>**Star-Position Astrolabe** (Ch. 4 #96)<br>**Sky-Watching Imperial Astrolabe** (Ch. 4 #145)<br>**Karma-Judgment Golden Scale** (Ch. 4 #182) | **Life-Saving Golden Cicada** (Ch. 5 #79) |
| Fire | **Meridian-Warming Hand Furnace** (Ch. 4 #29)<br>**Five-Feather Calamity Fan** (Ch. 4 #82)<br>**Li-Fire Restoring Furnace** (Ch. 4 #138)<br>**Phoenix Rebirth Palace Seed** (Ch. 4 #177) | **Dragon-Furnace Explosive Pellet** (Ch. 5 #11)<br>**Furnace-Body Tempering Pill** (Ch. 5 #8)<br>**Imperial Sunfire Annihilation Pellet** (Ch. 5 #20) |
| Five-Phase | **Five-Phase Refinement Cauldron** (Ch. 4 #143)<br>**Five-Emperors World-Refining Furnace** (Ch. 4 #175) | **Five-Phase Shelter Array** (Ch. 5 #66)<br>**Nine-Course Sovereign Dao Banquet** (Ch. 5 #49) |
| Flowing River | **River-Crossing Reed Sandals** (Ch. 4 #12)<br>**River-Current Measuring Float** (Ch. 4 #78) | **River-Current Escape Token** (Ch. 5 #73) |
| Force | **Floating Burden Pole** (Ch. 4 #18)<br>**God-Striking Heartwood Rod** (Ch. 4 #83)<br>**Ocean-Stilling Pearl** (Ch. 4 #151)<br>**Formation-Breaking Surveyor's Compass** (Ch. 4 #95) | **Gravity-Well Pellet** (Ch. 5 #18)<br>**Calamity-Star Pellet** (Ch. 5 #19)<br>**Imperial Heaven-Splitting Weapon Oil** (Ch. 5 #90) |
| Formations | **Formation-Line Measuring Cord** (Ch. 4 #37)<br>**Formation-Breaking Surveyor's Compass** (Ch. 4 #95)<br>**Mountain-and-River Suppression Map** (Ch. 4 #144)<br>**Sect-Guardian Heaven Bell** (Ch. 4 #173) | **Alert Boundary Stake Kit** (Ch. 5 #61)<br>**Five-Phase Shelter Array** (Ch. 5 #66)<br>**Nine-Palace Battlefield Disk** (Ch. 5 #69) |
| Gates | — | **Twin-Gate Transit Array Plates** (Ch. 5 #67) |
| Gravity | **Floating Burden Pole** (Ch. 4 #18)<br>**Mountain-Root Suppression Seal** (Ch. 4 #81)<br>**Cauldron of Ten Thousand Burdens** (Ch. 4 #171)<br>**Gravity-Training Iron Rings** (Ch. 4 #122) | **Gravity-Well Pellet** (Ch. 5 #18) |
| Guardian | **Guardian Ancestor Statue** (Ch. 4 #135)<br>**Sect-Guardian Stone Lion Pair** (Ch. 4 #154) | — |
| Harvesting Gathering | **Hundred-Herb Preservation Gourd** (Ch. 4 #2)<br>**Verdant Garden Seed Box** (Ch. 4 #108)<br>**Beast-Feed Preservation Jar** (Ch. 4 #4)<br>**Source-Vein Appraisal Needle** (Ch. 4 #25) | — |
| Ice | **Cold-Moon Medicine Chest** (Ch. 4 #8)<br>**Five-Feather Calamity Fan** (Ch. 4 #82)<br>**Nascent Soul Preservation Casket** (Ch. 4 #169)<br>**Moon-Palace Preservation Coffin** (Ch. 4 #188) | **Frost-Bloom Pellet** (Ch. 5 #12)<br>**Meridian-Stiffening Oil** (Ch. 5 #53)<br>**Frostbite Edge Oil** (Ch. 5 #82) |
| Illusion | **Borrowed-Voice Reed Flute** (Ch. 4 #58)<br>**Moon-Mirror Stillwater Mantle** (Ch. 4 #84)<br>**City-Veil Formation Core** (Ch. 4 #153)<br>**Heaven-Veil Imperial Mantle** (Ch. 4 #172) | **Mist-Hiding Array Plates** (Ch. 5 #62)<br>**Beast-Decoy Skin Doll** (Ch. 5 #75) |
| Imbuement | **Talisman Inkstone of Even Flow** (Ch. 4 #38)<br>**Calligrapher's Living-Ink Brush** (Ch. 4 #131)<br>**Li-Fire Restoring Furnace** (Ch. 4 #138)<br>**Spirit-Thread Weaver's Shuttle** (Ch. 4 #41) | — |
| Ink | **Talisman-Flat Jade Case** (Ch. 4 #5)<br>**Ancestor-Questioning Incense Burner** (Ch. 4 #94)<br>**Ancestor Court Tablet** (Ch. 4 #147)<br>**Heaven-Mandate Transmission Seal** (Ch. 4 #190) | **Clear-Mind Study Incense** (Ch. 5 #31) |
| Karma | **Oath-Witness Red Cord** (Ch. 4 #47)<br>**Karma-Weight Measuring Scale** (Ch. 4 #97)<br>**Soul-Reincarnation Waiting Lamp** (Ch. 4 #141)<br>**Imperial Ancestor Court** (Ch. 4 #180) | **Truth-Loosening Draught** (Ch. 5 #55)<br>**Incense of Truthful Counsel** (Ch. 5 #38) |
| Life | **Still-Breath Cultivation Mat** (Ch. 4 #28)<br>**Spirit-Spring Bathing Basin** (Ch. 4 #89)<br>**World-Tree Sapling Urn** (Ch. 4 #157)<br>**Phoenix Rebirth Palace Seed** (Ch. 4 #177) | **Nine-Breath Recovery Pill** (Ch. 5 #1)<br>**Meridian-Recovery Incense** (Ch. 5 #36)<br>**Nine-Revolution Restoration Pill** (Ch. 5 #9) |
| Light | **Sect-Signal Lantern** (Ch. 4 #20)<br>**Dream-Path Lantern** (Ch. 4 #93)<br>**Lantern of Emberless Heat** (Ch. 4 #51)<br>**Spirit-Moth Message Cage** (Ch. 4 #57) | — |
| Lightning | **Five-Feather Calamity Fan** (Ch. 4 #82)<br>**Storm-Gathering Banner** (Ch. 4 #152)<br>**Thunder-Script Escape Talisman** (Ch. 4 #85)<br>**Lightning-Rod Sect Spire** (Ch. 4 #118) | **Thunderclap Pellet** (Ch. 5 #14)<br>**Thunder-Escape Talisman** (Ch. 5 #26)<br>**Calamity-Star Pellet** (Ch. 5 #19) |
| Medicine | **Cold-Moon Medicine Chest** (Ch. 4 #8)<br>**Spirit-Spring Bathing Basin** (Ch. 4 #89)<br>**Imperial Medicine King's Cabinet** (Ch. 4 #189)<br>**Meridian-Warming Hand Furnace** (Ch. 4 #29) | **Nine-Breath Recovery Pill** (Ch. 5 #1)<br>**Bone-Knitting Jade Paste** (Ch. 5 #6)<br>**Nine-Revolution Restoration Pill** (Ch. 5 #9) |
| Metal | **Spirit-Stone Counting Abacus** (Ch. 4 #7)<br>**Blacksmith's Nine-Heat Furnace** (Ch. 4 #129)<br>**Starfall Ore Refinement Crucible** (Ch. 4 #161)<br>**Blacksmith's Temper-Reading Hammer** (Ch. 4 #36) | **Imperial Heaven-Splitting Weapon Oil** (Ch. 5 #90) |
| Mind | **Dao-Source Enlightenment Tree Seed** (Ch. 4 #197) | — |
| Mirror | **Moon-Mirror Stillwater Mantle** (Ch. 4 #84)<br>**Dream-Mirror Hall Seed** (Ch. 4 #142)<br>**Heaven-Observing Mirror Tower** (Ch. 4 #181)<br>**Thousand-Li Communication Mirror** (Ch. 4 #92) | **Mirror-Reversal Talisman** (Ch. 5 #28) |
| Moon | **Moon-Dew Collection Bowl** (Ch. 4 #34)<br>**Moon-Mirror Stillwater Mantle** (Ch. 4 #84)<br>**Sun-and-Moon Timekeeping Wheel** (Ch. 4 #167)<br>**Moon-Palace Preservation Coffin** (Ch. 4 #188) | **Moon-Dew Clarity Tea** (Ch. 5 #44) |
| Origin | **Primordial Mother Qi Cauldron** (Ch. 4 #194) | — |
| Piercing Needle | — | **Soul-Piercing Needle Set** (Ch. 5 #86) |
| Poison | **Poison-Tasting Silver Cicada** (Ch. 4 #62)<br>**Poison-Absorbing Medicine Jar** (Ch. 4 #114) | **Clear-Venom Antidote Pill** (Ch. 5 #2)<br>**Five-Poison Cloud Pellet** (Ch. 5 #16)<br>**Sovereign Soul-Corrosion Poison** (Ch. 5 #59) |
| Predator | **Beast-Scent Trail Powder Box** (Ch. 4 #54)<br>**Thousand-Li Pursuit Compass** (Ch. 4 #163) | **Spirit-Beast Hunter Toxin** (Ch. 5 #54) |
| Pressure | **Deep-Sea Breathing Pearl** (Ch. 4 #102) | — |
| Pressure Points | — | **Numbing Needle Venom** (Ch. 5 #51)<br>**Meridian-Sealing Talisman** (Ch. 5 #27)<br>**Meridian-Stiffening Oil** (Ch. 5 #53) |
| Protection | **Clear-Mind Bronze Bell** (Ch. 4 #27)<br>**Formation-Linked Camp Banner** (Ch. 4 #117)<br>**Ninefold Tribulation Shelter** (Ch. 4 #160)<br>**Heaven-Veil Imperial Mantle** (Ch. 4 #172) | **Body-Guarding Talisman** (Ch. 5 #22)<br>**Five-Phase Shelter Array** (Ch. 5 #66)<br>**Ghost-Warding Door Seal** (Ch. 5 #24) |
| Puppetry | — | **Thunder-Shell Substitution Doll** (Ch. 5 #78) |
| Purification | — | **Imperial Heaven-Cleansing Incense** (Ch. 5 #40) |
| Qiweaving | **Still-Breath Cultivation Mat** (Ch. 4 #28)<br>**Pill-Refining Jade Gourd** (Ch. 4 #90)<br>**Meridian-Warming Hand Furnace** (Ch. 4 #29)<br>**Spirit-Gathering Incense Burner** (Ch. 4 #30) | **Fasting Meridian Pill** (Ch. 5 #3)<br>**Meridian-Cleansing Elixir** (Ch. 5 #7)<br>**Minor Qi-Returning Pill** (Ch. 5 #5) |
| Radiance | **Clear-Mind Bronze Bell** (Ch. 4 #27)<br>**Soul-Sheltering Funeral Lamp** (Ch. 4 #110)<br>**Lantern of Safe Burial** (Ch. 4 #72) | **Ghost-Banishing Incense** (Ch. 5 #37)<br>**Imperial Sunfire Annihilation Pellet** (Ch. 5 #20)<br>**Ghost-Scorch Resin** (Ch. 5 #56) |
| Renewal | **Phoenix-Nest Rebirth Brazier** (Ch. 4 #158) | — |
| Retribution | — | **Mirror-Reversal Talisman** (Ch. 5 #28) |
| Sand | **Footprint-Erasing Brush** (Ch. 4 #56) | — |
| Scoundrel | **Hidden-Pocket Jade Belt** (Ch. 4 #69) | — |
| Sealing | **Mountain-Root Suppression Seal** (Ch. 4 #81)<br>**Nine-Dragon Binding Seal** (Ch. 4 #136)<br>**Dragon-Vein Mountain Gate Seal** (Ch. 4 #176)<br>**Heaven-Sealing Mandate Fragment** (Ch. 4 #193) | **Meridian-Sealing Talisman** (Ch. 5 #27)<br>**Nine-Lock Demon Suppression Seal** (Ch. 5 #29)<br>**Imperial Boundary-Breaking Escape Order** (Ch. 5 #80) |
| Sect Stewardship | **Cultivator's Storage Ring** (Ch. 4 #1)<br>**Cloud Palace Travel Pavilion** (Ch. 4 #88)<br>**Thousand-Mile Cloud Palace** (Ch. 4 #140)<br>**Scholar's Thousand-Page Box** (Ch. 4 #6) | **Seven-Day Fasting Cake** (Ch. 5 #45)<br>**Nine-Course Sovereign Dao Banquet** (Ch. 5 #49) |
| Shadow | **Footprint-Erasing Brush** (Ch. 4 #56)<br>**Hidden-Step Shadow Boots** (Ch. 4 #121) | **Smoke-Step Escape Bead** (Ch. 5 #71)<br>**Void-Step Jade Shard** (Ch. 5 #76)<br>**Beast-Decoy Skin Doll** (Ch. 5 #75) |
| Smoke | **Smoke-Breath Rescue Mask** (Ch. 4 #44) | **Black-Dregs Smoke Pellet** (Ch. 5 #13)<br>**Five-Poison Cloud Pellet** (Ch. 5 #16)<br>**Smoke-Step Escape Bead** (Ch. 5 #71) |
| Soul | **Nascent Soul Preservation Casket** (Ch. 4 #169)<br>**Moon-Palace Preservation Coffin** (Ch. 4 #188) | **Sovereign Soul-Corrosion Poison** (Ch. 5 #59)<br>**Heaven-Defying Rebirth Pill** (Ch. 5 #10) |
| Sound | **Paired Whispering Jade** (Ch. 4 #19)<br>**Thousand-Li Communication Mirror** (Ch. 4 #92)<br>**Ten-Thousand Beast Command Bell** (Ch. 4 #146)<br>**Sect-Guardian Heaven Bell** (Ch. 4 #173) | **Thunderclap Pellet** (Ch. 5 #14)<br>**Soul-Shock Pellet** (Ch. 5 #17)<br>**Alert Boundary Stake Kit** (Ch. 5 #61) |
| Source | **Spirit-Stone Counting Abacus** (Ch. 4 #7)<br>**Source-Heaven Compass** (Ch. 4 #91)<br>**Source-Heaven Grand Compass** (Ch. 4 #137)<br>**Dragon-Vein Mountain Gate Seal** (Ch. 4 #176) | **Thousand-Li Return Seal** (Ch. 5 #77) |
| Space | **Cultivator's Storage Ring** (Ch. 4 #1)<br>**Thunder-Script Escape Talisman** (Ch. 4 #85)<br>**Star-Road Crossing Chariot** (Ch. 4 #139)<br>**Heaven-Veil Imperial Mantle** (Ch. 4 #172) | **Earth-Passing Jade Shard** (Ch. 5 #72)<br>**Thunder-Escape Talisman** (Ch. 5 #26)<br>**Nine-Palace Battlefield Disk** (Ch. 5 #69) |
| Spirit | **Paired Whispering Jade** (Ch. 4 #19)<br>**God-Striking Heartwood Rod** (Ch. 4 #83)<br>**Soul-Reincarnation Waiting Lamp** (Ch. 4 #141)<br>**Thousand-Dream Palace Lantern** (Ch. 4 #185) | **Calming Heart Elixir** (Ch. 5 #4)<br>**Soul-Shock Pellet** (Ch. 5 #17)<br>**Nine-Lock Demon Suppression Seal** (Ch. 5 #29) |
| Spirit Companions | **Beast-Feed Preservation Jar** (Ch. 4 #4)<br>**Hundred-Beast Holding Bag** (Ch. 4 #87)<br>**Ten-Thousand Beast Command Bell** (Ch. 4 #146)<br>**Ten-Thousand Spirit Bestiary Pavilion** (Ch. 4 #179) | **Beast-Calming Cedar Incense** (Ch. 5 #34)<br>**Ancestor-Calling Temple Incense** (Ch. 5 #39) |
| Stars | **Sun-Dial of Honest Hours** (Ch. 4 #60)<br>**Star-Position Astrolabe** (Ch. 4 #96)<br>**Source-Heaven Grand Compass** (Ch. 4 #137)<br>**Nine-Heavens Star-Road Altar** (Ch. 4 #174) | **Calamity-Star Pellet** (Ch. 5 #19) |
| Strategy | **Formation Master's Rotating Array Board** (Ch. 4 #132)<br>**Celestial Formation Command Board** (Ch. 4 #186) | **Nine-Palace Battlefield Disk** (Ch. 5 #69) |
| Sun | **Sun-and-Moon Timekeeping Wheel** (Ch. 4 #167)<br>**Nine-Sun Calamity Shelter** (Ch. 4 #187) | — |
| Survival | **Wind-Reading Travel Fan** (Ch. 4 #14) | — |
| Talismans | **Talisman-Flat Jade Case** (Ch. 4 #5)<br>**Thunder-Script Escape Talisman** (Ch. 4 #85)<br>**Thousand-Li Trail Marker** (Ch. 4 #16)<br>**Hidden-Writing Revealing Lens** (Ch. 4 #23) | **Swift-Step Talisman** (Ch. 5 #21)<br>**Thunder-Escape Talisman** (Ch. 5 #26)<br>**Nine-Lock Demon Suppression Seal** (Ch. 5 #29) |
| The Hidden Eye | **Hidden-Writing Revealing Lens** (Ch. 4 #23)<br>**Source-Heaven Compass** (Ch. 4 #91)<br>**Heaven-Observing Mirror Tower** (Ch. 4 #181)<br>**Heart-Demon Warning Mirror** (Ch. 4 #32) | **Soul-Scent Appraisal Incense** (Ch. 5 #32) |
| Thread | **Folded-Sleeve Satchel** (Ch. 4 #3)<br>**Soul-Wound Mending Needle Case** (Ch. 4 #100)<br>**Heaven-Thread Fate Loom** (Ch. 4 #165)<br>**Spirit-Thread Weaver's Shuttle** (Ch. 4 #41) | — |
| Time | **Forgotten-Age Ash Urn** (Ch. 4 #164) | — |
| Trap | **Night-Watch Alarm Crickets** (Ch. 4 #50)<br>**Quiet-Camp Boundary Stakes** (Ch. 4 #53) | **Alert Boundary Stake Kit** (Ch. 5 #61) |
| Tribulation | **Ninefold Tribulation Shelter** (Ch. 4 #160)<br>**Nine-Sun Calamity Shelter** (Ch. 4 #187) | **Calamity-Fletched Ammunition** (Ch. 5 #89) |
| Vehicles | **Star-Road Crossing Chariot** (Ch. 4 #139)<br>**Void-Crossing Jade Ark** (Ch. 4 #184)<br>**Celestial Crossing Bronze Ark** (Ch. 4 #192) | — |
| Verdant Growth | **Hundred-Herb Preservation Gourd** (Ch. 4 #2)<br>**Verdant Garden Seed Box** (Ch. 4 #108)<br>**World-Tree Sapling Urn** (Ch. 4 #157)<br>**World-Root Transplantation Spade** (Ch. 4 #183) | **Imperial Feast of Returning Spring** (Ch. 5 #50) |
| Warleader | **Sect-Signal Lantern** (Ch. 4 #20)<br>**Formation-Linked Camp Banner** (Ch. 4 #117)<br>**Ancestor Court Tablet** (Ch. 4 #147)<br>**Imperial Ancestor Court** (Ch. 4 #180) | **Five-Flavor Warrior Feast** (Ch. 5 #46) |
| Water | **River-Crossing Reed Sandals** (Ch. 4 #12)<br>**Moon-Mirror Stillwater Mantle** (Ch. 4 #84)<br>**Mountain-and-River Suppression Map** (Ch. 4 #144)<br>**Ocean-Subduing Sovereign Pearl** (Ch. 4 #178) | **Frost-Bloom Pellet** (Ch. 5 #12)<br>**Water-Breathing Talisman** (Ch. 5 #25)<br>**Mist-Hiding Array Plates** (Ch. 5 #62) |
| Weapons | — | **Flame-Tongue Weapon Oil** (Ch. 5 #81)<br>**Soul-Piercing Needle Set** (Ch. 5 #86)<br>**Calamity-Fletched Ammunition** (Ch. 5 #89) |
| Weather | **Wind-Reading Travel Fan** (Ch. 4 #14)<br>**Five-Feather Calamity Fan** (Ch. 4 #82)<br>**Sky-Watching Imperial Astrolabe** (Ch. 4 #145)<br>**Mist-Sheltering Travel Cloak** (Ch. 4 #17) | — |
| Wood | **God-Striking Heartwood Rod** (Ch. 4 #83)<br>**Cloud-Riding Crane Carving** (Ch. 4 #104) | — |
| World | **World-Tree Sapling Urn** (Ch. 4 #157)<br>**World-Seed Ring** (Ch. 4 #191)<br>**Ten-Thousand Worlds Compass** (Ch. 4 #195)<br>**World-Heart Formation Core** (Ch. 4 #200) | **Heaven-Earth Rewriting Array Core** (Ch. 5 #70) |

# Treasure by Location

Each location table uses **d6**. Apply Chapter 8 appraisal and condition rules before allowing unrestricted use.

## Minor Sect Store — d6

| Roll | Find |
|---:|---|
| 1 | **Talisman-Flat Jade Case** (Chapter 4 #5) — kept behind the scribe's counter |
| 2 | **Spirit-Stone Counting Abacus** (Chapter 4 #7) — sold with a stamped merchant warranty |
| 3 | **Cloudstep Jade Anklets** (Chapter 4 #11) — sized for a disciple |
| 4 | **Meridian-Warming Hand Furnace** (Chapter 4 #29) — displayed beside cold-weather gear |
| 5 | **Nine-Breath Recovery Pill** (Chapter 5 #1) — one standard batch |
| 6 | **Swift-Step Talisman** (Chapter 5 #21) — one standard batch |

## Inner-Sect Treasury — d6

| Roll | Find |
|---:|---|
| 1 | **Mountain-Root Suppression Seal** (Chapter 4 #81) — issued only against mission authorization |
| 2 | **Nine-Lock Storage Ring** (Chapter 4 #86) — every chamber is inventoried |
| 3 | **Pill-Refining Jade Gourd** (Chapter 4 #90) — reserved for licensed alchemists |
| 4 | **Source-Heaven Compass** (Chapter 4 #91) — released for vein-survey expeditions |
| 5 | **Oath-Binding Court Seal** (Chapter 4 #98) — requires a court witness |
| 6 | **Soul-Wound Mending Needle Case** (Chapter 4 #100) — issued to a recognized healer |

## Auction City — d6

| Roll | Find |
|---:|---|
| 1 | **Moon-Mirror Stillwater Mantle** (Chapter 4 #84) — fully appraised and displayed under mirror wards |
| 2 | **Thousand-Li Communication Mirror** (Chapter 4 #92) — both matched mirrors are present |
| 3 | **Bloodline Recognition Mirror** (Chapter 4 #99) — sold with twelve verified reference samples |
| 4 | **Thousand-Voice Music Box** (Chapter 4 #111) — contains a catalogued historical performance archive |
| 5 | **Illusion-Piercing Third-Eye Circlet** (Chapter 4 #120) — bidding requires an anti-illusion license |
| 6 | **Wandering Healer's Hundred-Medicine Cabinet** (Chapter 4 #134) — stocked but missing several mundane medical supplies |

## Ancient Ruin — d6

| Roll | Find |
|---:|---|
| 1 | **Nine-Dragon Binding Seal** (Chapter 4 #136) — embedded in a collapsed suppression chamber |
| 2 | **Li-Fire Restoring Furnace** (Chapter 4 #138) — cold but structurally intact |
| 3 | **Dream-Mirror Hall Seed** (Chapter 4 #142) — found as an unopened seed |
| 4 | **Void-Nail Boundary Pagoda** (Chapter 4 #149) — still pinning shut a failed spatial breach |
| 5 | **Forgotten-Age Ash Urn** (Chapter 4 #164) — filled with ash from the ruin's destruction |
| 6 | **Nascent Soul Preservation Casket** (Chapter 4 #169) — sealed around a preserved occupant |

## Ancestral Tomb — d6

| Roll | Find |
|---:|---|
| 1 | **Corpse-Preservation Black Jade Coffin** (Chapter 4 #109) — the coffin is sealed and unappraised |
| 2 | **Soul-Sheltering Funeral Lamp** (Chapter 4 #110) — the flame still answers one family name |
| 3 | **Ancestor Court Tablet** (Chapter 4 #147) — only six of nine ancestral recesses are occupied |
| 4 | **Bloodline-Ancestral Gate Mirror** (Chapter 4 #159) — linked gate unknown |
| 5 | **Imperial Ancestor Court** (Chapter 4 #180) — the court remains Dormant pending recognition |
| 6 | **Moon-Palace Preservation Coffin** (Chapter 4 #188) — sealed behind a funerary prohibition |

## Battlefield or War Camp — d6

| Roll | Find |
|---:|---|
| 1 | **Five-Feather Calamity Fan** (Chapter 4 #82) — carried by a fallen elemental officer |
| 2 | **Phoenix-Feather Rescue Fan** (Chapter 4 #101) — with two charges expended |
| 3 | **Formation-Linked Camp Banner** (Chapter 4 #117) — still marking the abandoned command camp |
| 4 | **Star-Road Crossing Chariot** (Chapter 4 #139) — Operationally Damaged under Chapter 8 |
| 5 | **Heaven-Sound Warning Bell** (Chapter 4 #150) — installed but disconnected from its protected region |
| 6 | **Nine-Sun Calamity Shelter** (Chapter 4 #187) — several Sun Layers are destroyed |

## Spirit Vein or Sacred Wilderness — d6

| Roll | Find |
|---:|---|
| 1 | **Source-Vein Appraisal Needle** (Chapter 4 #25) — pointing toward a sealed source deposit |
| 2 | **Moon-Dew Collection Bowl** (Chapter 4 #34) — collecting dew under an exposed moon |
| 3 | **Verdant Garden Seed Box** (Chapter 4 #108) — containing a neglected cultivation garden |
| 4 | **Source-Reader's Earth Pulse Drum** (Chapter 4 #133) — set on a natural pulse node |
| 5 | **World-Tree Sapling Urn** (Chapter 4 #157) — planted and already producing a sanctuary |
| 6 | **Dragon-Pulse Surveying Pillar** (Chapter 4 #168) — installed as a regional surveying marker |

## Artisan Workshop — d6

| Roll | Find |
|---:|---|
| 1 | **Alchemist's Steady-Flame Tripod** (Chapter 4 #35) — still warm from the final batch |
| 2 | **Blacksmith's Temper-Reading Hammer** (Chapter 4 #36) — maker's marks remain legible |
| 3 | **Blacksmith's Nine-Heat Furnace** (Chapter 4 #129) — configured for tempering |
| 4 | **Alchemist's Seven-Petal Cauldron** (Chapter 4 #130) — three ingredient chambers remain sealed |
| 5 | **Calligrapher's Living-Ink Brush** (Chapter 4 #131) — stored beside a complete inscription archive |
| 6 | **Five-Phase Refinement Cauldron** (Chapter 4 #143) — one phase chamber is Dormant pending repair |

## River, Lake, or Sea — d6

| Roll | Find |
|---:|---|
| 1 | **River-Crossing Reed Sandals** (Chapter 4 #12) — left in a ferry shrine |
| 2 | **Clear-Water Purification Pearl** (Chapter 4 #43) — recovered from a sunken purification station |
| 3 | **River-Current Measuring Float** (Chapter 4 #78) — still measuring a dangerous undertow |
| 4 | **Deep-Sea Breathing Pearl** (Chapter 4 #102) — contained in a deep-water reliquary |
| 5 | **River-Dragon Ferry Token** (Chapter 4 #123) — recognized by an old ferry clan |
| 6 | **Ocean-Stilling Pearl** (Chapter 4 #151) — guarded by a regional water authority |

## Haunted Site or Ghost Court — d6

| Roll | Find |
|---:|---|
| 1 | **Grave-Quiet Listening Bell** (Chapter 4 #24) — ringing without a visible hand |
| 2 | **Lantern of Safe Burial** (Chapter 4 #72) — protecting an unidentified corpse |
| 3 | **Ancestor-Questioning Incense Burner** (Chapter 4 #94) — filled with unburned ancestor incense |
| 4 | **Soul-Sheltering Funeral Lamp** (Chapter 4 #110) — sheltering a willing soul |
| 5 | **Ghost-Warding Gate Lions** (Chapter 4 #119) — one lion has been Broken |
| 6 | **Ghost-Court Judgment Seal** (Chapter 4 #162) — still bearing an unresolved judgment |

## Palace, State Treasury, or Great Sect — d6

| Roll | Find |
|---:|---|
| 1 | **Sect Steward's Endless Ledger** (Chapter 4 #127) — recording current treasury traffic |
| 2 | **Sky-Watching Imperial Astrolabe** (Chapter 4 #145) — awaiting the next regional observation |
| 3 | **Emperor's Mandate Relay Seal** (Chapter 4 #170) — linked to a national relay network |
| 4 | **Sect-Guardian Heaven Bell** (Chapter 4 #173) — installed as a sect-defining defense |
| 5 | **Heaven-Observing Mirror Tower** (Chapter 4 #181) — operated by a licensed observation court |
| 6 | **Heaven-Mandate Transmission Seal** (Chapter 4 #190) — sealed to a recognized office |

## World Ruin or Immortal Site — d6

| Roll | Find |
|---:|---|
| 1 | **World-Seed Ring** (Chapter 4 #191) — Dormant and functioning only at its lowest safe tier |
| 2 | **Celestial Crossing Bronze Ark** (Chapter 4 #192) — immobile until a route coordinate is restored |
| 3 | **Heaven-Sealing Mandate Fragment** (Chapter 4 #193) — contained behind an equal-grade seal |
| 4 | **Primordial Mother Qi Cauldron** (Chapter 4 #194) — its furnace spirit is silent |
| 5 | **Coffin of the Nine Heavens** (Chapter 4 #198) — the coffin is intact but its destination record is missing |
| 6 | **World-Heart Formation Core** (Chapter 4 #200) — only the central core survives |

# Treasure by Owner — d20

Use this table when the treasure is found on a person, in an office, in a residence, or among the effects of a defeated faction.

The listed objects are likely possessions, not guaranteed personal property. Chapter 9 ownership and loan rules still apply.

| Roll | Owner | Likely Completed Entries |
|---:|---|---|
| 1 | Outer disciple | **Cloudstep Jade Anklets** (Chapter 4 #11)<br>**Nine-Breath Recovery Pill** (Chapter 5 #1) |
| 2 | Inner disciple | **One-Step Escape Talisman Box** (Chapter 4 #45)<br>**Breath-Counting Meditation Bell** (Chapter 4 #80) |
| 3 | Formation master | **Formation-Breaking Surveyor's Compass** (Chapter 4 #95)<br>**Formation Master's Rotating Array Board** (Chapter 4 #132)<br>**Eight-Trigram Boundary Formation Set** (Chapter 7 Set #8) |
| 4 | Alchemist | **Alchemist's Steady-Flame Tripod** (Chapter 4 #35)<br>**Pill-Refining Jade Gourd** (Chapter 4 #90)<br>**Alchemist's Seven-Petal Cauldron** (Chapter 4 #130) |
| 5 | Wandering healer | **Cold-Moon Medicine Chest** (Chapter 4 #8)<br>**Soul-Wound Mending Needle Case** (Chapter 4 #100)<br>**Hundred-Medicine Traveling Clinic** (Chapter 7 Set #5) |
| 6 | Talisman scribe | **Talisman-Flat Jade Case** (Chapter 4 #5)<br>**Talisman Inkstone of Even Flow** (Chapter 4 #38)<br>**Thunder-Escape Talisman** (Chapter 5 #26) |
| 7 | Beastmaster | **Spirit-Companion Grooming Comb** (Chapter 4 #65)<br>**Hundred-Beast Holding Bag** (Chapter 4 #87)<br>**Spirit-Companion Residence Orb** (Chapter 4 #126) |
| 8 | Merchant or caravan master | **Spirit-Stone Counting Abacus** (Chapter 4 #7)<br>**Merchant's Weightless Ledger Pouch** (Chapter 4 #10)<br>**Voidfold Merchant Pavilion** (Chapter 4 #166) |
| 9 | Sect steward | **Sect-Rank Recognition Token** (Chapter 4 #64)<br>**Sect Steward's Endless Ledger** (Chapter 4 #127)<br>**Emperor's Mandate Relay Seal** (Chapter 4 #170) |
| 10 | Court magistrate | **Truth-Resonance Court Bell** (Chapter 4 #21)<br>**Oath-Binding Court Seal** (Chapter 4 #98)<br>**Ghost-Court Judgment Seal** (Chapter 4 #162) |
| 11 | Wandering cultivator | **Homeward Compass Disc** (Chapter 4 #15)<br>**Mist-Sheltering Travel Cloak** (Chapter 4 #17)<br>**Moonlit Map Cloth** (Chapter 4 #63) |
| 12 | Infiltrator or spy | **Borrowed-Voice Reed Flute** (Chapter 4 #58)<br>**Hidden-Pocket Jade Belt** (Chapter 4 #69)<br>**Hidden Moon Infiltrator Set** (Chapter 7 Set #2) |
| 13 | Clan heir | **Bloodline Recognition Mirror** (Chapter 4 #99)<br>**Ancestor Court Tablet** (Chapter 4 #147)<br>**Bloodline-Ancestral Gate Mirror** (Chapter 4 #159) |
| 14 | General or war leader | **Formation-Linked Camp Banner** (Chapter 4 #117)<br>**Heaven-Sound Warning Bell** (Chapter 4 #150)<br>**Sect-Guardian Heaven Bell** (Chapter 4 #173) |
| 15 | Master blacksmith | **Blacksmith's Temper-Reading Hammer** (Chapter 4 #36)<br>**Blacksmith's Nine-Heat Furnace** (Chapter 4 #129)<br>**Li-Fire Restoring Furnace** (Chapter 4 #138) |
| 16 | Scholar or archivist | **Scholar's Thousand-Page Box** (Chapter 4 #6)<br>**Memory-Sealing Jade Archive** (Chapter 4 #112)<br>**Thousand-Script Jade Library** (Chapter 4 #155) |
| 17 | Spirit medium | **Spirit-Calming Offering Bowl** (Chapter 4 #48)<br>**Ancestor-Questioning Incense Burner** (Chapter 4 #94)<br>**Soul-Sheltering Funeral Lamp** (Chapter 4 #110) |
| 18 | Ruler or sect master | **Sky-Watching Imperial Astrolabe** (Chapter 4 #145)<br>**Imperial Ancestor Court** (Chapter 4 #180)<br>**Five-Regalia of the Azure Mandate** (Chapter 7 Set #9) |
| 19 | World traveler | **Star-Road Crossing Chariot** (Chapter 4 #139)<br>**Void-Crossing Jade Ark** (Chapter 4 #184)<br>**Ten-Thousand Worlds Compass** (Chapter 4 #195) |
| 20 | Ancient Item Spirit | **World-Seed Ring** (Chapter 4 #191)<br>**Eternal Reincarnation Lamp** (Chapter 4 #196)<br>**Immortal Court Bell of Returning Names** (Chapter 4 #199) |

# Damaged, Dormant, and Incomplete Treasures — d20

These are specific usable discoveries, not generic new effects.

Resolve their condition using Chapter 8. Repairing or completing the treasure restores only its printed entry and any printed Set Resonances.

| Roll | Treasure | Current State |
|---:|---|---|
| 1 | **Paired Whispering Jade** (Chapter 4 #19) | One jade is missing; the surviving half is Intact but cannot transmit. |
| 2 | **Thousand-Li Trail Marker** (Chapter 4 #16) | One trail tile is Broken; Chapter 8 replacement rules apply. |
| 3 | **Nine-Lock Storage Ring** (Chapter 4 #86) | Several chambers are locked and the lawful command is missing. |
| 4 | **Cloud Palace Travel Pavilion** (Chapter 4 #88) | Operationally Damaged; it can shelter occupants but cannot expand to full size. |
| 5 | **Thousand-Li Communication Mirror** (Chapter 4 #92) | Only one matched mirror remains. |
| 6 | **Cloud-Riding Crane Carving** (Chapter 4 #104) | Broken with the wind-crystal core intact. |
| 7 | **Wind-Gate Folding Screen** (Chapter 4 #105) | One folding screen is missing. |
| 8 | **Corpse-Preservation Black Jade Coffin** (Chapter 4 #109) | Intact but the coffin seal has not been appraised. |
| 9 | **Formation-Linked Camp Banner** (Chapter 4 #117) | The banner is Intact; two required camp stakes are missing. |
| 10 | **Ghost-Warding Gate Lions** (Chapter 4 #119) | One gate lion is Destroyed with Core; the other remains active. |
| 11 | **Hidden Moon Infiltrator Set** (Chapter 7 Set #2) | The Borrowed-Voice Reed Flute is missing; complete-set resonance is inactive. |
| 12 | **Nine-Meridian Needle Constellation** (Chapter 7 Set #3) | The Pulse-Reading Jade Dial is Broken; all Set Resonances are inactive. |
| 13 | **Three-Star Flying Sword Array** (Chapter 7 Set #4) | The Black Void Jian is missing; only the two-sword threshold remains. |
| 14 | **Eight-Trigram Boundary Formation Set** (Chapter 7 Set #8) | Only four Trigram Gates survive; the set functions as a Trigram Court. |
| 15 | **Li-Fire Restoring Furnace** (Chapter 4 #138) | The furnace is Dormant because its restoration inscriptions are incomplete. |
| 16 | **City-Veil Formation Core** (Chapter 4 #153) | Removed from its city; the core is Dormant until installed. |
| 17 | **Phoenix-Nest Rebirth Brazier** (Chapter 4 #158) | The brazier is Intact but lacks its weekly fuel and registered names. |
| 18 | **Nascent Soul Preservation Casket** (Chapter 4 #169) | Destroyed with Core; the preserved occupant remains inaccessible. |
| 19 | **Nine-Sun Calamity Shelter** (Chapter 4 #187) | Three Sun Layers have been destroyed and require restoration. |
| 20 | **World-Heart Formation Core** (Chapter 4 #200) | Only the World-Heart Formation Core survives; every world function must be rebuilt. |

# Strange Materials — d36

These results are recoverable special materials, not finished treasures.

Use the complete material entry for its grade, affinity, property, ceiling, compatible profiles, and opposed refinements.

| Roll | Material | Grade and Ceiling | Typical Find |
|---:|---|---|---|
| 1 | **Storm Iron** (Chapter 2B — Storm Iron) | Spiritual; ceiling Saint Treasure | forked ingots that ring during dry weather |
| 2 | **Moon Silver** (Chapter 2B — Moon Silver) | Spiritual; ceiling Saint Treasure | a mirror-bright coil that reflects moonlight underground |
| 3 | **River Jade** (Chapter 2B — River Jade) | Spiritual; ceiling Saint Treasure | smooth blue-green bars that remain wet without water |
| 4 | **Thunderwood** (Chapter 2B — Thunderwood) | Spiritual; ceiling Saint Treasure | a blackened branch that vibrates near active lightning |
| 5 | **Frost Jade** (Chapter 2B — Frost Jade) | Spiritual; ceiling Saint Treasure | cold translucent shards wrapped in insulating silk |
| 6 | **Mountain-Root Jade** (Chapter 2B — Mountain-Root Jade) | Saint; ceiling Sovereign Treasure | one dense block recovered from beneath a sacred peak |
| 7 | **Star Silver** (Chapter 2B — Star Silver) | Saint; ceiling Sovereign Treasure | a meteor-silver ribbon stored under darkness |
| 8 | **Ghost Iron** (Chapter 2B — Ghost Iron) | Saint; ceiling Sovereign Treasure | gray ingots that cast no clear reflection |
| 9 | **Phoenix-Ash Steel** (Chapter 2B — Phoenix-Ash Steel) | Saint; ceiling Sovereign Treasure | red-black billets mixed with still-warm ash |
| 10 | **Voidglass Alloy** (Chapter 2B — Voidglass Alloy) | Saint; ceiling Sovereign Treasure | weightless black glass scales in a sealed case |
| 11 | **Blood Jade** (Chapter 2B — Blood Jade) | Saint; ceiling Sovereign Treasure | veined red stones registered to a lineage archive |
| 12 | **Deepsea Cold Iron** (Chapter 2B — Deepsea Cold Iron) | Saint; ceiling Sovereign Treasure | pressure-forged bars raised from an ocean trench |
| 13 | **Tribulation Steel** (Chapter 2B — Tribulation Steel) | Sovereign; ceiling Imperial Treasure | cracked metal collected from a breakthrough site |
| 14 | **Five-Phase Alloy** (Chapter 2B — Five-Phase Alloy) | Sovereign; ceiling Imperial Treasure | five separated ingots that must remain in balance |
| 15 | **Soul Jade** (Chapter 2B — Soul Jade) | Sovereign; ceiling Imperial Treasure | pale jade containing harmless memory echoes |
| 16 | **Heaven-Splitting Stone** (Chapter 2B — Heaven-Splitting Stone) | Sovereign; ceiling Imperial Treasure | a narrow wedge that scratches ordinary steel |
| 17 | **Cloud-Void Crystal** (Chapter 2B — Cloud-Void Crystal) | Sovereign; ceiling Imperial Treasure | a crystal cluster that drifts within its crate |
| 18 | **Demon-Heart Iron** (Chapter 2B — Demon-Heart Iron) | Sovereign; ceiling Imperial Treasure | a sealed black ingot with a warning ledger |
| 19 | **Mirror-Sea Silver** (Chapter 2B — Mirror-Sea Silver) | Sovereign; ceiling Imperial Treasure | liquid-bright silver sheets kept between mirrors |
| 20 | **Phoenix-Blood Scarlet Gold** (Chapter 2B — Phoenix-Blood Scarlet Gold) | Imperial; ceiling Immortal Artifact | a single warm feather-shaped ingot |
| 21 | **Heaven-Mark Violet Gold** (Chapter 2B — Heaven-Mark Violet Gold) | Imperial; ceiling Immortal Artifact | violet metal covered in self-forming script |
| 22 | **Calamity-Tempered Imperial Gold** (Chapter 2B — Calamity-Tempered Imperial Gold) | Imperial; ceiling Immortal Artifact | a lightning-scarred ceremonial plate |
| 23 | **Immortal-Tear Verdant Gold** (Chapter 2B — Immortal-Tear Verdant Gold) | Imperial; ceiling Immortal Artifact | green-gold droplets sealed in living wood |
| 24 | **Dragon-Patterned Abyssal Gold** (Chapter 2B — Dragon-Patterned Abyssal Gold) | Imperial; ceiling Immortal Artifact | a dense scale-like ingot requiring a crane |
| 25 | **Feathered Celestial Green Gold** (Chapter 2B — Feathered Celestial Green Gold) | Imperial; ceiling Immortal Artifact | thin green-gold feathers in a void case |
| 26 | **Primordial Mother-Weight Essence** (Chapter 2B — Primordial Mother-Weight Essence) | Immortal; ceiling Bespoke | a grain-sized fragment that burdens its pedestal |
| 27 | **Origin-Void Copper** (Chapter 2B — Origin-Void Copper) | Immortal; ceiling Bespoke | a copper ring surrounding an apparently empty center |
| 28 | **Enlightenment Tree Heartwood** (Chapter 2B — Enlightenment Tree Heartwood) | Immortal; ceiling Bespoke | one preserved branch with living grain |
| 29 | **World-Heart Crystal** (Chapter 2B — World-Heart Crystal) | Immortal; ceiling Bespoke | a map-like shard showing unfamiliar terrain |
| 30 | **Cloud Silk** (Chapter 3B — Cloud Silk) | Spiritual; ceiling Saint Treasure | a spool lighter than its own wooden bobbin |
| 31 | **Dragon Scale Lamellae** (Chapter 3B — Dragon Scale Lamellae) | Saint; ceiling Sovereign Treasure | six matched scales from one recognized dragon |
| 32 | **World-Turtle Shell** (Chapter 3B — World-Turtle Shell) | Sovereign; ceiling Imperial Treasure | a repaired shell plate carrying old settlement marks |
| 33 | **Soul Jade Plates** (Chapter 3B — Soul Jade Plates) | Sovereign; ceiling Imperial Treasure | flat jade plates that echo the wearer's breathing |
| 34 | **Heaven-Bearing Stone** (Chapter 3B — Heaven-Bearing Stone) | Sovereign; ceiling Imperial Treasure | interlocking plates that resist being lifted |
| 35 | **Phoenix-Ash Silk** (Chapter 3B — Phoenix-Ash Silk) | Saint; ceiling Sovereign Treasure | fire-scented cloth woven from gray-red fibers |
| 36 | **Paper-Lamellar Scripture Sheets** (Chapter 3B — Paper-Lamellar Scripture Sheets) | Mortal; ceiling Spiritual Treasure | a sealed bundle of armored scripture pages |

# Auction Lots — d20

An auction lot can be purchased, disputed, stolen, requisitioned, or withdrawn.

The lot does not waive:

- lawful ownership;
- Attunement;
- appraisal;
- recognition;
- Item Spirit consent;
- installation;
- transport;
- grade availability.

| Roll | Lot | Completed Contents | Status |
|---:|---|---|---|
| 1 | Pilgrim's Road Lot | **Cloudstep Jade Anklets** (Chapter 4 #11)<br>**Homeward Compass Disc** (Chapter 4 #15)<br>**Mist-Sheltering Travel Cloak** (Chapter 4 #17) | All three are Intact and fully appraised. |
| 2 | Field Healer's Lot | **Cold-Moon Medicine Chest** (Chapter 4 #8)<br>**Twelve-Breath Recovery Beads** (Chapter 4 #31)<br>**Wound-Cleansing Copper Basin** (Chapter 4 #71)<br>**Nine-Breath Recovery Pill** (Chapter 5 #1) | Includes one recovery-pill batch. |
| 3 | Talisman Apprentice Lot | **Talisman-Flat Jade Case** (Chapter 4 #5)<br>**Talisman Inkstone of Even Flow** (Chapter 4 #38)<br>**Swift-Step Talisman** (Chapter 5 #21)<br>**Body-Guarding Talisman** (Chapter 5 #22) | Two standard talisman batches. |
| 4 | Minor Formation Lot | **Formation-Line Measuring Cord** (Chapter 4 #37)<br>**Minor Formation Anchor Nails** (Chapter 4 #59)<br>**Alert Boundary Stake Kit** (Chapter 5 #61) | The kit is unopened. |
| 5 | Spirit Medium's Lot | **Grave-Quiet Listening Bell** (Chapter 4 #24)<br>**Spirit-Calming Offering Bowl** (Chapter 4 #48)<br>**Lantern of Safe Burial** (Chapter 4 #72) | The burial lantern has one prior funerary record. |
| 6 | Merchant House Lot | **Spirit-Stone Counting Abacus** (Chapter 4 #7)<br>**Merchant's Weightless Ledger Pouch** (Chapter 4 #10)<br>**False-Gold Revealing Scale** (Chapter 4 #79) | Sold with verified trade ledgers. |
| 7 | Beast Keeper's Lot | **Beast-Feed Preservation Jar** (Chapter 4 #4)<br>**Spirit-Companion Grooming Comb** (Chapter 4 #65)<br>**Hundred-Beast Holding Bag** (Chapter 4 #87) | The holding bag currently contains no creatures. |
| 8 | Hidden-Moon Fragment Lot | **Borrowed-Voice Reed Flute** (Chapter 4 #58)<br>**Hidden-Pocket Jade Belt** (Chapter 4 #69)<br>**Hidden-Step Shadow Boots** (Chapter 4 #121) | Three components associated with Chapter 7 Set #2. |
| 9 | Scholar's Archive Lot | **Scholar's Thousand-Page Box** (Chapter 4 #6)<br>**Memory-Impression Jade Slip** (Chapter 4 #22)<br>**Windless Candle of Study** (Chapter 4 #74) | The jade slip contains one legal historical recording. |
| 10 | Sect Camp Lot | **Quiet-Camp Boundary Stakes** (Chapter 4 #53)<br>**Shared-Meal Warming Pot** (Chapter 4 #55)<br>**Formation-Linked Camp Banner** (Chapter 4 #117) | The banner is a temporary institutional loan. |
| 11 | Mirror and Testimony Lot | **Moon-Mirror Stillwater Mantle** (Chapter 4 #84)<br>**Thousand-Li Communication Mirror** (Chapter 4 #92)<br>**Truth-and-Falsehood Dividing Mirror** (Chapter 4 #113) | Bidders must submit to anti-fraud appraisal. |
| 12 | Three Masters' Workshop Lot | **Blacksmith's Nine-Heat Furnace** (Chapter 4 #129)<br>**Alchemist's Seven-Petal Cauldron** (Chapter 4 #130)<br>**Calligrapher's Living-Ink Brush** (Chapter 4 #131) | Facilities must be transported separately. |
| 13 | Sovereign Refinement Lot | **Source-Heaven Grand Compass** (Chapter 4 #137)<br>**Five-Phase Refinement Cauldron** (Chapter 4 #143)<br>**Starfall Ore Refinement Crucible** (Chapter 4 #161) | State approval required. |
| 14 | Funerary Preservation Lot | **Corpse-Preservation Black Jade Coffin** (Chapter 4 #109)<br>**Soul-Sheltering Funeral Lamp** (Chapter 4 #110)<br>**Soul-Reincarnation Waiting Lamp** (Chapter 4 #141) | Soul and corpse custody laws apply. |
| 15 | Ancestral Lineage Lot | **Bloodline Recognition Mirror** (Chapter 4 #99)<br>**Ancestor Court Tablet** (Chapter 4 #147)<br>**Bloodline-Ancestral Gate Mirror** (Chapter 4 #159) | Sale is invalid without lineage recognition. |
| 16 | Military Command Lot | **Guardian Ancestor Statue** (Chapter 4 #135)<br>**Heaven-Sound Warning Bell** (Chapter 4 #150)<br>**Emperor's Mandate Relay Seal** (Chapter 4 #170) | The warning bell is installed and cannot be removed quickly. |
| 17 | Sovereign Estate Lot | **Thousand-Mile Cloud Palace** (Chapter 4 #140)<br>**Thousand-Script Jade Library** (Chapter 4 #155)<br>**Voidfold Merchant Pavilion** (Chapter 4 #166) | The palace requires an approved mooring site. |
| 18 | Imperial Court Lot | **Sect-Guardian Heaven Bell** (Chapter 4 #173)<br>**Heaven-Observing Mirror Tower** (Chapter 4 #181)<br>**Heaven-Mandate Transmission Seal** (Chapter 4 #190) | This is a political transfer, not an ordinary sale. |
| 19 | Incomplete Flying Sword Array | **Three-Star Flying Sword Array** (Chapter 7 Set #4) | The Black Void Jian is missing; use Chapter 8 replacement rules. |
| 20 | Sealed Immortal Mandate Lot | **Heaven-Sealing Mandate Fragment** (Chapter 4 #193) | The fragment remains inside an Immortal-Hazard seal. |

# Sect Rewards

Use the table matching the recipient's actual standing and the campaign's treasure profile. A result above ordinary personal access should be a loan, office asset, commission, or major reward.

## Outer Disciple or Field Agent — d8

Permanent items are normally owned or issued under ordinary sect policy.

| Roll | Reward |
|---:|---|
| 1 | **Hundred-Herb Preservation Gourd** (Chapter 4 #2) |
| 2 | **Cloudstep Jade Anklets** (Chapter 4 #11) |
| 3 | **Paired Whispering Jade** (Chapter 4 #19) |
| 4 | **Meridian-Warming Hand Furnace** (Chapter 4 #29) |
| 5 | **Nine-Breath Recovery Pill** (Chapter 5 #1)<br>**Swift-Step Talisman** (Chapter 5 #21) |
| 6 | **Dragon-Furnace Explosive Pellet** (Chapter 5 #11)<br>**Alert Boundary Stake Kit** (Chapter 5 #61) |
| 7 | **Clear-Water Purification Pearl** (Chapter 4 #43) |
| 8 | **Quiet-Camp Boundary Stakes** (Chapter 4 #53) |

## Inner Disciple or Specialist — d8

Saint items can be personal rewards, restricted commissions, or long-term requisitions.

| Roll | Reward |
|---:|---|
| 1 | **Mountain-Root Suppression Seal** (Chapter 4 #81) |
| 2 | **Pill-Refining Jade Gourd** (Chapter 4 #90) |
| 3 | **Formation-Breaking Surveyor's Compass** (Chapter 4 #95) |
| 4 | **Soul-Wound Mending Needle Case** (Chapter 4 #100) |
| 5 | **Meridian-Cleansing Elixir** (Chapter 5 #7)<br>**Thunder-Escape Talisman** (Chapter 5 #26) |
| 6 | **Meridian-Recovery Incense** (Chapter 5 #36)<br>**Twin-Gate Transit Array Plates** (Chapter 5 #67) |
| 7 | **Formation-Linked Camp Banner** (Chapter 4 #117) |
| 8 | **Hundred-Medicine Traveling Clinic** (Chapter 7 Set #5) |

## Core Disciple, Elder's Heir, or Major Officer — d8

Sovereign results are major rewards or institutional loans.

| Roll | Reward |
|---:|---|
| 1 | **Nine-Dragon Binding Seal** (Chapter 4 #136) |
| 2 | **Source-Heaven Grand Compass** (Chapter 4 #137) |
| 3 | **Star-Road Crossing Chariot** (Chapter 4 #139) |
| 4 | **Five-Phase Refinement Cauldron** (Chapter 4 #143) |
| 5 | **Void-Nail Boundary Pagoda** (Chapter 4 #149) |
| 6 | **Nine-Revolution Restoration Pill** (Chapter 5 #9)<br>**Nine-Lock Demon Suppression Seal** (Chapter 5 #29) |
| 7 | **Three-Star Flying Sword Array** (Chapter 7 Set #4) |
| 8 | **Eight-Trigram Boundary Formation Set** (Chapter 7 Set #8) |

## Sect Master, State Office, or National Mission — d8

Imperial results are normally office-bound, mission-sealed, or institution-owned.

| Roll | Reward |
|---:|---|
| 1 | **Cauldron of Ten Thousand Burdens** (Chapter 4 #171) |
| 2 | **Sect-Guardian Heaven Bell** (Chapter 4 #173) |
| 3 | **Nine-Heavens Star-Road Altar** (Chapter 4 #174) |
| 4 | **Heaven-Observing Mirror Tower** (Chapter 4 #181) |
| 5 | **Void-Crossing Jade Ark** (Chapter 4 #184) |
| 6 | **Imperial Heaven-Cleansing Incense** (Chapter 5 #40)<br>**Imperial Boundary-Breaking Escape Order** (Chapter 5 #80) |
| 7 | **Five-Regalia of the Azure Mandate** (Chapter 7 Set #9) |
| 8 | **Heaven-Mandate Transmission Seal** (Chapter 4 #190) |

# Inheritance Vaults — d12

An inheritance vault is a curated campaign reward.

A vault can require:

- lineage recognition;
- a sect office;
- an oath;
- appraisal;
- repair;
- completion of a Treasure Set;
- release of an Item Spirit;
- payment of a historical debt;
- a Realm milestone.

The contents below use only completed entries.

| Roll | Vault | Completed Contents | Present Condition |
|---:|---|---|---|
| 1 | Pilgrim-Founder Vault | **Cloud-Walking Pilgrim Set** (Chapter 7 Set #1)<br>**Moonlit Map Cloth** (Chapter 4 #63)<br>**Sleep-Guarding Door Charm** (Chapter 4 #76) | The set is complete; the door charm still recognizes the founder's travel oath. |
| 2 | Hidden Moon Cellar | **Hidden Moon Infiltrator Set** (Chapter 7 Set #2)<br>**Void-Step Jade Shard** (Chapter 5 #76)<br>**Thunder-Shell Substitution Doll** (Chapter 5 #78) | The complete set is present but remains Dormant pending recognition. |
| 3 | Nine-Meridian Physician's Vault | **Nine-Meridian Needle Constellation** (Chapter 7 Set #3)<br>**Soul-Wound Mending Needle Case** (Chapter 4 #100)<br>**Wandering Healer's Hundred-Medicine Cabinet** (Chapter 4 #134) | The Pulse-Reading Jade Dial is Broken. |
| 4 | Three-Star Sword Hall | **Three-Star Flying Sword Array** (Chapter 7 Set #4)<br>**Calamity-Fletched Ammunition** (Chapter 5 #89) | One sword is missing; five Calamity-Fletched Ammunition pieces remain. |
| 5 | Hundred-Medicine Refuge | **Hundred-Medicine Traveling Clinic** (Chapter 7 Set #5)<br>**Spirit-Spring Bathing Basin** (Chapter 4 #89)<br>**Phoenix-Heart Restoration Soup** (Chapter 5 #48) | The clinic is intact and stocked for one major restoration. |
| 6 | Black Tortoise Armory | **Black Tortoise Fortress Panoply** (Chapter 7 Set #6)<br>**Ninefold Tribulation Shelter** (Chapter 4 #160) | The panoply is complete; the shelter is a separate sect asset. |
| 7 | Living Scripture Archive | **Four Treasures of the Living Scripture** (Chapter 7 Set #7)<br>**Memory-Sealing Jade Archive** (Chapter 4 #112)<br>**Thousand-Script Jade Library** (Chapter 4 #155) | The library contains the Set Formula and replacement records. |
| 8 | Eight-Trigram Gate Vault | **Eight-Trigram Boundary Formation Set** (Chapter 7 Set #8)<br>**Nine-Palace Battlefield Disk** (Chapter 5 #69) | Only six gates survive; the battlefield disk is intact. |
| 9 | Azure Mandate Treasury | **Five-Regalia of the Azure Mandate** (Chapter 7 Set #9)<br>**Emperor's Mandate Relay Seal** (Chapter 4 #170)<br>**Heaven-Mandate Transmission Seal** (Chapter 4 #190) | Unified Attunement requires lawful succession. |
| 10 | Phoenix Rebirth Vault | **Phoenix-Nest Rebirth Brazier** (Chapter 4 #158)<br>**Phoenix Rebirth Palace Seed** (Chapter 4 #177)<br>**Heaven-Defying Rebirth Pill** (Chapter 5 #10) | The Immortal pill is sealed separately as a final contingency. |
| 11 | World Traveler's Reliquary | **Star-Road Crossing Chariot** (Chapter 4 #139)<br>**Void-Crossing Jade Ark** (Chapter 4 #184)<br>**Ten-Thousand Worlds Compass** (Chapter 4 #195) | The chariot and ark contain old but usable route records. |
| 12 | Last World-Heart Vault | **World-Seed Ring** (Chapter 4 #191)<br>**Dao-Source Enlightenment Tree Seed** (Chapter 4 #197)<br>**World-Heart Formation Core** (Chapter 4 #200) | All three are Dormant and require distinct campaign-scale restoration. |

# Curated Reward Packages

These packages help the GM choose rather than roll.

## Travel Package

Choose one permanent travel treasure, one communication treasure, and one consumable escape treasure.

Recommended completed entries:

- **Cloudstep Jade Anklets** (Chapter 4 #11);
- **Homeward Compass Disc** (Chapter 4 #15);
- **Paired Whispering Jade** (Chapter 4 #19);
- **Moonlit Map Cloth** (Chapter 4 #63);
- **Void-Step Jade Shard** (Chapter 5 #76).

## Cultivation Package

Choose one rest or cultivation support treasure, one resource consumable, and one material or Formula reward.

Recommended entries:

- **Still-Breath Cultivation Mat** (Chapter 4 #28);
- **Spirit-Gathering Incense Burner** (Chapter 4 #30);
- **Clean-Meridian Tea Kettle** (Chapter 4 #116);
- **Minor Qi-Returning Pill** (Chapter 5 #5);
- **Meridian-Recovery Incense** (Chapter 5 #36).

## Investigation Package

Choose one inspection treasure, one records treasure, and one social or testimony treasure.

Recommended entries:

- **Hidden-Writing Revealing Lens** (Chapter 4 #23);
- **Memory-Impression Jade Slip** (Chapter 4 #22);
- **Truth-Resonance Court Bell** (Chapter 4 #21);
- **Truth-and-Falsehood Dividing Mirror** (Chapter 4 #113);
- **Four Treasures of the Living Scripture** (Chapter 7 Set #7).

## Formation Package

Choose one design or survey treasure, one consumable array, and one formation-breaking option.

Recommended entries:

- **Formation-Line Measuring Cord** (Chapter 4 #37);
- **Formation Master's Rotating Array Board** (Chapter 4 #132);
- **Alert Boundary Stake Kit** (Chapter 5 #61);
- **Formation-Breaking Spike Set** (Chapter 5 #68);
- **Formation-Breaking Arrowheads** (Chapter 5 #87).

## Spirit Package

Choose one spirit-detection or diplomacy treasure, one funerary treasure, and one spirit-facing consumable.

Recommended entries:

- **Grave-Quiet Listening Bell** (Chapter 4 #24);
- **Spirit-Calming Offering Bowl** (Chapter 4 #48);
- **Soul-Sheltering Funeral Lamp** (Chapter 4 #110);
- **Ghost-Banishing Incense** (Chapter 5 #37);
- **Ancestor-Calling Temple Incense** (Chapter 5 #39).

## Crafting Package

Choose one workshop treasure, one appraisal treasure, and one special material.

Recommended entries:

- **Alchemist's Steady-Flame Tripod** (Chapter 4 #35);
- **Blacksmith's Temper-Reading Hammer** (Chapter 4 #36);
- **Source-Stone Sorting Tray** (Chapter 4 #42);
- **Blacksmith's Nine-Heat Furnace** (Chapter 4 #129);
- **Alchemist's Seven-Petal Cauldron** (Chapter 4 #130).

## Sect Command Package

Choose one communication or authority treasure, one defensive infrastructure treasure, and one institutional consumable.

Recommended entries:

- **Sect-Signal Lantern** (Chapter 4 #20);
- **Emperor's Mandate Relay Seal** (Chapter 4 #170);
- **Heaven-Sound Warning Bell** (Chapter 4 #150);
- **Sect-Guardian Heaven Bell** (Chapter 4 #173);
- **Imperial Boundary-Breaking Escape Order** (Chapter 5 #80).

---

# Table-Building Procedure

The GM can add new tables after completing more catalog entries.

Every row should contain:

1. exact treasure name;
2. chapter and entry reference;
3. grade;
4. ownership or custody;
5. condition;
6. appraisal status;
7. whether all pieces are present;
8. whether the item is installed;
9. whether an Item Spirit consents;
10. whether the result is personal, shared, loaned, or institutional.

Do not create table results such as:

- “a sword that controls storms”;
- “a random healing pill”;
- “a mysterious formation”;
- “an artifact with unknown powers.”

Instead, point to a completed entry and use Chapter 8 to make its condition or history mysterious.

# Final Doctrine

Random tables should create discovery, not unreviewed mechanics.

The treasure's uncertainty comes from:

- where it was found;
- who owns it;
- whether it is complete;
- what it remembers;
- whether it is Dormant;
- whether it is cursed;
- whether it recognizes the bearer;
- what must be repaired or returned.

Its actual powers remain the completed, auditable entry.


# Chapter 11: Factory and GM Screen Item Schema
*Final Audited Contract R2*

The final item data model separates immutable definitions, mutable physical instances, character equipment ledgers, Treasure Set definitions, and read-only GM Screen projections.

## Compiled Coverage

| Surface | Count |
|---|---:|
| Chapter 4 Wondrous Treasures | 200 |
| Chapter 5 Consumable Treasures | 90 |
| Completed Chapter 2/3 worked items | 2 |
| Named Treasure Set components | 27 |
| **Item definitions** | **318** |
| Treasure Sets | 9 |
| GM Screen cards | 318 |

Every named set component now has an `item_id`. The Eight-Trigram Boundary Formation Set has nine compiled components: eight gates and the Rotating Trigram Command Board.

## Required Item Fields

- `item_id`;
- `name`;
- type, subtype, and family;
- grade, rank, fixed save DC, fixed attack bonus, default object AC, and default object Hit Points;
- Attunement requirement and slots;
- Primary Material status and value;
- Refinement Bonus;
- Equivalent Bonus, enhancement capacity, and occupied capacity;
- passive properties;
- Actions, Bonus Actions, Reactions, procedures, and triggered effects;
- charge pools and recovery;
- canonical Sphere influences and non-Sphere design influences;
- storage capacity and creature policy;
- default Item Spirit and Growth state;
- durability;
- Set membership;
- provenance.

Mutable state remains in `Tianxia_Item_Instance_v1_1`: equipped state, current charges, quantity, storage contents, current damage, Item Spirit recognition, Bond Strain, Growth Reserve, milestones, owner, and bearer.

## Schema Files

- `ItemSchema_R2.json`;
- `ItemDefinition_R2.schema.json`;
- `ItemInstance_R2.schema.json`;
- `EquipmentLedger_R2.schema.json`;
- `ItemGMProjection_R2.schema.json`;
- `TreasureSetDefinition_R2.schema.json`.

## Normalized Data

- `ItemCatalog_R2.json`;
- `TreasureSetCatalog_R2.json`;
- `ItemGMProjection_R2.json`;
- `EquipmentLedger_R2.example.json`.

## Gate Enforcement

The R2 validator enforces:

1. unique catalog and instance IDs;
2. exact catalog coverage;
3. all Set components resolving to item definitions;
4. Attunement definition consistency;
5. four-slot capacity;
6. active items requiring legal Attunement;
7. Broken and Core-Lost items not contributing;
8. charge values not exceeding maximum;
9. storage weight and volume limits where numeric capacity exists;
10. consumed items not remaining active;
11. active action and reaction IDs resolving;
12. armor and shield AC contributions resolving;
13. weapon attack contributions resolving;
14. custom items carrying definition snapshots;
15. snapshot IDs matching instance IDs;
16. Item Spirits receiving no independent turn before Independent Spirit-Life;
17. active Set Resonances possessing enough active, properly Attuned components;
18. visible projection text remaining free of placeholders and rendering artifacts.

Twelve bad fixtures prove the gates fail correctly.

## Claim Boundary

R2 is statically validated and Factory-ready. No live GM Screen browser render is claimed.
