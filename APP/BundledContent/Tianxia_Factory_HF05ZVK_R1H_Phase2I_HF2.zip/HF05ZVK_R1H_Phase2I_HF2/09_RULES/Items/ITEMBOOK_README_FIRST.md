# Tianxia Item Book R1

This is the complete audited Item Book release and Factory installation package.

## Human-Readable Documents

- `Tianxia_ItemBook_R1.docx` — formatted for direct upload to Google Docs.
- `Tianxia_ItemBook_R1.md` — complete Markdown source and canonical reading copy.

## Factory Installation

Send this entire ZIP to the character factory.

The factory should begin with:

- `Factory/Factory_Install.md`
- `Factory/Factory_Install.json`

The installation contract identifies the R2 schema, item catalog, Treasure Set catalog, projection contract, Equipment Ledger schema, validator, required gates, and post-install proof requirements.

## Validation Baseline

- Final Item Book audit: `PASS_FINAL_ITEM_BOOK_AUDIT_R1`
- Schema validation: `PASS_ITEM_SCHEMA_R2`
- Bad-fixture regression: `PASS_BAD_FIXTURE_REGRESSION`
- Item definitions: 318
- Treasure Sets: 9
- GM Screen projection cards: 318
- Google Docs document: 401 rendered pages
- DOCX accessibility findings: 0

## Claim Boundary

The package is ready for Factory installation.

It does not by itself prove a live GM Screen browser import or render. The Factory installation report should identify any remaining GM Screen integration dependency.
