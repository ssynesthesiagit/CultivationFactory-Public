# Tianxia Item Book R1 — Factory Installation Contract

## Installation Authority

Install this package as the current canonical Item Book source for **Tianxia: Cultivation — The Immortal’s Path**.

- Human-readable rules authority: `../Tianxia_ItemBook_R1.md`
- Machine-readable item authority: `ItemCatalog_R2.json`
- Machine-readable schema authority: `ItemSchema_R2.json`
- Treasure Set authority: `TreasureSetCatalog_R2.json`
- GM Screen projection contract: `ItemGMProjection_R2.json`
- Character equipment export contract: `EquipmentLedger_R2.schema.json`
- Validator: `validate_item_schema_r2.py`

The package supersedes earlier Item Schema v1 catalogs, projections, and validators. Do not merge older v1 records into R2 unless they are explicitly migrated and pass the R2 validator.

## Canonical Coverage

| Surface | Canonical Count |
|---|---:|
| Wondrous Treasures | 200 |
| Consumable Treasures | 90 |
| Constructed weapon and armor examples | 2 |
| Standalone Treasure Set components | 26 |
| Total item definitions | 318 |
| Treasure Sets | 9 |
| GM Screen cards | 318 |
| Canonical Spheres | 85 |

## Required Factory Behavior

The factory must:

1. use `item_id` as the stable identity for every standard item;
2. preserve the separation between immutable Item Definitions and mutable character Item Instances;
3. export character equipment through an `Equipment_Ledger.json` conforming to `Tianxia_Equipment_Ledger_R2`;
4. include a complete definition snapshot for every custom, reforged, Growth, or otherwise noncatalog item;
5. validate Attunement against the normal four-slot limit;
6. export current equipped state, charges, storage contents, durability, Item Spirit state, and Growth state;
7. resolve item actions and reactions to stable action IDs;
8. record weapon, armor, shield, Speed, Resistance, and resource contributions explicitly;
9. keep canonical Sphere names in `sphere_influences[]` and broader design concepts in `design_influences[]`;
10. prevent Broken, Core-Lost, consumed, inactive, or improperly Attuned items from contributing mechanics;
11. enforce Treasure Set component and resonance requirements;
12. retain complete source mechanics and provenance.

## Generation Doctrine

When creating or assigning items:

- use the complete Item Book rules, not an isolated catalog row;
- respect Realm-based availability and the four-slot Attunement economy;
- treat one current-Realm treasure as the normal Signature Treasure;
- use lower-grade support treasures unless the build is intentionally treasure-rich;
- do not grant Sphere ownership through Sphere Influence tags;
- do not create free Item Spirit turns;
- use Growth Treasure, appraisal, repair, salvage, Set, and consumable rules where applicable;
- use explicit mechanics for action economy, range, target, save, duration, charges, recovery, storage, and destruction.

## Installation Sequence

1. Ingest `../Tianxia_ItemBook_R1.md` as the complete rules and content source.
2. Register `ItemSchema_R2.json` and its standalone schemas.
3. Register `ItemCatalog_R2.json` as the standard item catalog.
4. Register `TreasureSetCatalog_R2.json` as the Set catalog.
5. Register `ItemGMProjection_R2.json` as the static projection contract.
6. Adopt `EquipmentLedger_R2.schema.json` for character exports.
7. Run the validator against the supplied example and validation artifacts.
8. Add factory gates for all required checks listed below.
9. Produce an installation report identifying target files changed and validation results.

## Required Gates

The installed factory must reject:

- missing or duplicate item and instance IDs;
- Attunement overflow;
- active unattuned items;
- Broken or Core-Lost items contributing mechanics;
- charges above maximum;
- consumed items remaining active;
- unresolved active item action or reaction IDs;
- definition snapshot identity mismatches;
- custom items without complete snapshots;
- storage overflow when numeric capacity exists;
- armor or shield AC effects without contribution records;
- weapon attack or damage effects without contribution records;
- unauthorized Item Spirit independent turns;
- active Set Resonances without every required component;
- visible placeholders or rendering artifacts.

## Validation Baseline

Expected supplied reports:

- `../Validation/Schema_Validation.json`: `PASS_ITEM_SCHEMA_R2`
- `../Validation/Schema_Regression.json`: `PASS_BAD_FIXTURE_REGRESSION`
- `../Validation/Final_Audit.json`: `PASS_FINAL_ITEM_BOOK_AUDIT_R1`

Expected positive validation counts:

- JSON Schema errors: 0
- Semantic errors: 0
- Warnings: 0

The regression suite contains twelve invalid fixtures that must continue to fail for their expected reasons.

## GM Screen Claim Boundary

This is a Factory installation package, not evidence of a live GM Screen browser round trip.

Do not claim live GM Screen readiness until a real character package is exported, imported into the current GM Screen, rendered in a browser, and audited across the Equipment / Source surface and dependent statistics.

## Required Installation Report

After installation, return:

- factory version and source baseline;
- files created or changed;
- catalog and Set counts;
- schema-validation result;
- bad-fixture regression result;
- one generated character-package equipment smoke test;
- any unresolved live GM Screen integration dependency;
- package checksum and final readiness claim.
