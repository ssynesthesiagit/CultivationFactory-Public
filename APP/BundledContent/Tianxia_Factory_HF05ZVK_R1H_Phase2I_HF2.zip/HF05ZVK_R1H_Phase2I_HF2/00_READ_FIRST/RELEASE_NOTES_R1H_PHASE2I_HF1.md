# HF05ZVK-R1H Phase 2I HF1 — Embedded Builder Talent Catalog Hotfix

This packaging hotfix replaces the embedded `10_GM_SCREEN_TARGET/GM_Screen_HF05ZUI_R2K/` assets with HF05ZUI-R2K.3-HF1.

Factory compilation, schemas, command gates, candidate output, semantic hashes, and the HF05ZN-R2G combat boundary are unchanged.

The embedded Character Builder now:

- shows a source-derived short effect description for all 3,721 canonical 85-Sphere talent rows;
- exposes complete authored canonical talent text on mouse hover;
- excludes 509 Cultivation Insights from the talent selector;
- excludes 218 Sphere variants/drawback scriptures from the talent selector;
- prevents stale drafts from exporting those dedicated rows as talents.

The 40 Chakra-extension rows retain explicit source-reference text because the complete authored Chakra talent packet is not present in the Phase 2I corpus.
