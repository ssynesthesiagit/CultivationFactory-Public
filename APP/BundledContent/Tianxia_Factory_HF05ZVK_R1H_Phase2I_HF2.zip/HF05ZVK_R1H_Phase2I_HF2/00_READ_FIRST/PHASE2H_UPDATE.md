# HF05ZVK-R1G Phase 2H Update

This release responds to two independent fresh-chat CL5 productions. It fixes defects that were reproducible across authoring sessions rather than character-specific judgment calls.

## Blocking repairs

- Foundation lifecycle schema and semantic validator now use the same 13 categories.
- Command 1 accepts structured current packets, requires the 18-tab R2K.2 target, includes planned ASIs, and enforces the depth-based Recorded Art floor.
- Command 2 and the compiler reconstruct ability scores at each CL for resource, HP, and training arithmetic.
- Command 3 requires legacy Sphere/Talent projection rows to exactly match the universal selected-rule graph.
- Command 5 re-runs schema and Commands 1–4 before compile/seal.

The candidate Build remains deterministic and may not be manually repaired.
