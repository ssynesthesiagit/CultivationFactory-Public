# HF05ZVK-R1F Release Notes

- Adds mandatory Recorded Art expression classification.
- Blocks custom multi-Sphere Recorded Arts unless represented as complete preserved Forged expressions.
- Requires every Immortal Art action to link back to its parent art.
- Compiler embeds complete Immortal action packets in all consumer surfaces.
- Targets HF05ZUI-R2K, whose Immortal Arts tab displays full mechanics and whose acceptance test checks field-level parity.
- Retains six base commands, optional Command 4B, R1D Recorded Art floors, full talent execution coverage, and normal Method–Foundation stacking.
