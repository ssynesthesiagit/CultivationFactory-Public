# HF05ZVK-R1F Phase 2C Release Note

Phase 2C replaces separate authoring-time Sphere/Talent coverage with one universal selected-rule execution-coverage authority. The compiler still emits legacy coverage files for the current GM Screen. Use `selected_rule_execution_coverage` plus the modifier, procedure, passive-statistic, and permission ledgers for all new builds.
