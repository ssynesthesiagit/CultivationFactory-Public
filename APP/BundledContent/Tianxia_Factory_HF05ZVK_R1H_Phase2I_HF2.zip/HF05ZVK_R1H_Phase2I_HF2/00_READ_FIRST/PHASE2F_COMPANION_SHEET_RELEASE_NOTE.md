# Phase 2F — Companion, Spirit, and Beast Character Sheets

Adds a generalized persistent-companion schema and GM Screen contract for bonded spirits, Beastmaster beasts, mounts, Item Spirits, constructs, and other persistent entities. Existing execution coverage remains authoritative; this phase adds complete descriptive and character-sheet records and anti-shortcut validation.
