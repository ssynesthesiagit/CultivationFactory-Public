# HF05ZVK-R1G Phase 2H — Cross-Command Assurance

This producer release was triggered by two independent CL5 productions from fresh chat windows. Both exposed the same contract defect and related assurance gaps. Candidate output schemas remain HF05ZVK-R1F for compatibility.

## Mandatory corrections

- Reconciles Foundation lifecycle schema and semantic validation around the 13 authoritative split categories.
- Normalizes structured Command 1 objects and reads the 18-tab HF05ZUI-R2K.2 target correctly.
- Computes HP, Path resources, and training modifiers from the ability state at each historical CL.
- Enforces Recorded Art depth floors during Command 1.
- Makes Command 5 replay and require Commands 1–4 before compilation and sealing.
- Regenerates legacy sphere/talent projections from the canonical universal execution ledger and compares exact normalized rows.
- Keeps the exact 26-sidecar GM Screen contract.

## Coordinated releases

- GM Screen: HF05ZUI-R2K.2
- Combat Bootstrap: HF05ZN-R2F

## Nonblocking future work

Source-evidence digests, richer semantic requirement matrices, prepared-talisman instance counts, self-contained delegated strike bindings, quick cards, and cross-roster balance simulations remain quality improvements rather than release blockers.
