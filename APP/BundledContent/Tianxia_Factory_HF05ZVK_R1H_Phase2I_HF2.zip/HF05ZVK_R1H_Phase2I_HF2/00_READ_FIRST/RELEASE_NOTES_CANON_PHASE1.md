# HF05ZVK-R1F Canon Corpus Integration — Phase 1

## Scope

This is an applied corpus and authority update over the HF05ZVK-R1F structural factory. It does not change the Character Master Ledger schema, six-command workflow, compiler output contract, or GM Screen target.

## Installed canon

- PHB v0.7
- Qi Cultivation R19
- Body Refining R8
- Spirit Awakening R7
- Central Cultivation Insights R4 / Compendium R1
- Spirit Awakening Rules Reference R3
- Bonded Companions Universal Combat Chassis R2

## Authority hardening

- Retires `Needed.zip` and PHB v0.3 from active production authority.
- Requires exact active `source_path` values from the canonical corpus manifest.
- Adds subject-specific precedence and conflict resolution.
- Retains current Foundations, Methods, Backgrounds, Origin Insights, manuals, GM Guide, and Sphere Compendium as support sources.

## Deferred

Machine indexes for all Path/Subpath features, universal selected-rule execution coverage, command/schema revisions, and GM Screen changes remain Phase 2 and later work.
