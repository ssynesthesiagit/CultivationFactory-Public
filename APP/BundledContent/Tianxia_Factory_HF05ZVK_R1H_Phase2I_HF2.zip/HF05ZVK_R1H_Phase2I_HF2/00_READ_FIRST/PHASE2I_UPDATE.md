# HF05ZVK-R1H — Phase 2I Production Feedback Assurance

This patch is derived from independent An Eui and Bai Meizhen CL5 productions under Phase 2H. It preserves the HF05ZVK-R1F candidate schema while tightening the producer.

## Confirmed repairs
- Talent coverage validation resolves canonical `source_id`; no obsolete mirror field is required.
- Action-card semantic lint blocks displaced Effect/Failure/Duration/Limit/Counterplay text.
- Variable resource spends require typed minimum, maximum, and selection semantics.
- Compiled states expose every creating action in `created_by_ids` while retaining a primary `created_by`.
- Item action timing is normalized from action economy and validated.
- Command 1 replays Sphere diversity at each acquisition CL and requires early exception authority.
- Producer release, candidate schema, consumer family, consumer patch, and compiler version are separately identified.
- Matching consumer is HF05ZUI-R2K.3 and matching combat admission is HF05ZN-R2G.

Historical arithmetic, allocation legality, lifecycle closure, and Command 5 replay remain inherited from Phase 2H.
- Level-selected Ability Score Improvements and Cultivation Insights are projected explicitly into every affected `Leveling_Ledger` row. The R2K.3 Leveling Ledger and Paths & Subpaths tabs surface the resolved selection rather than only the generic Path feature.
