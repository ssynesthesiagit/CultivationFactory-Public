# HF05ZVK-R1F Release Notes

R1F adds candidate-bound semantic completeness validation learned from the failed Qin Yao and Ienaga Yumi CL18 builds. Production candidates must define a complete semantic requirement contract, pass prerequisite and mandatory-choice checks, reproduce selected rule engines and riders, synchronize resources/states, enforce Forged Drawbacks, use mechanically authorized equipment, reconcile against the 30 authoritative Foundations, invalidate stale evidence, and export a 10–14 action Signature Loadout.

Generated candidates include `Semantic_Validation_Report.json` and `Signature_Loadout.json`. Command 5 cannot seal a production candidate with Critical or High semantic findings. Command 6 targets HF05ZUI-R2K.1 and still requires real user-exported acceptance for final release.

The 32 theoretical Chakra Foundations are excluded until their executable mechanics are authored.
