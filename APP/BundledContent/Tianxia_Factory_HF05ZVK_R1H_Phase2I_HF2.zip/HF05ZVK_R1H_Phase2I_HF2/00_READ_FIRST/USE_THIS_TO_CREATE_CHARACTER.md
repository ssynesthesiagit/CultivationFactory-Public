# Use This Factory to Create a Character

Upload this ZIP by itself in a new chat. Ask the AI to ingest the complete factory and report the six commands. Then provide the character request and run one command per message.

Do not upload an older HF05ZVD or HF05ZVJ factory in the same new chat. Those packages are historical evidence, not active baselines.

Recommended first message:

> Ingest this entire HF05ZVK-R1F factory. Treat it as the sole authoritative Tianxia character factory. Verify the six-command workflow, optional Immortal Arts command, source rules, schemas, compiler, validators, fixtures, and HF05ZUI-R2K.3 consumer contract. Report the command sequence and wait for my character request.
