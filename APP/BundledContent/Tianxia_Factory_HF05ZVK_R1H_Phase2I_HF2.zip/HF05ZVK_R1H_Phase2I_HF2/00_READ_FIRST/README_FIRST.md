# HF05ZVK-R1H — Authoritative Six-Command Tianxia Character Factory

> **Applied corpus profile:** Canon Integration Phase 2A. The active rules bundle is `09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip`; see `RELEASE_NOTES_CANON_PHASE1.md`.

HF05ZVK-R1H is the standalone producer release for the character-generation system for Tianxia. It creates one fully accounted, executable character package from a prompt and targets the matching **HF05ZUI-R2K.3** GM Screen.

## Authoritative pipeline

```text
request and permitted inspiration evidence
→ Command 1: source evidence and blueprint lock
→ Command 2: canonical CL-by-CL advancement and arithmetic
→ Command 3: complete ordinary chassis and source-feature mapping
→ Command 4: executable combat, Recorded Arts, Forged Techniques, composites, and behavior
→ Optional Command 4B: Immortal Arts, only when legally applicable
→ Command 5: deterministic compilation and immutable candidate sealing
→ Command 6: consumer simulation or real-screen acceptance classification
```

`Character_Master_Ledger.json` is the sole authored mechanical source of truth. `Build/` is compiler output and must never be manually repaired.

## Why six commands

The old mechanical-assembly prompt carried too many different reasoning burdens. It had to finish advancement, map Background/Origin/Method/Foundation, convert every talent into executable form, write Recorded Arts and Forged Techniques, build composites, and author AI behavior at once. That produced attractive packages with missing ordinary rules.

The revised split protects quality:

1. **Command 1** decides what the character is.
2. **Command 2** proves how the character legally reached the current CL.
3. **Command 3** proves that every ordinary subsystem and printed feature is fully represented.
4. **Command 4** converts the completed chassis into actions the combat AI can actually select.
5. **Command 5** compiles without new design.
6. **Command 6** verifies the exact immutable ZIP against the consumer.

An Immortal Art adds one optional prompt because it is a separate high-complexity subsystem. Ordinary characters do not pay that attention cost.

## Non-negotiable mechanical doctrine

- AI-generated characters begin with a chosen Path. They do not run the player-facing Level 0 or sect-trial procedure.
- Background grants and the separate CL1 free Sphere/talent are independently accounted.
- A Background Sphere may intentionally match the CL1 free Sphere, but the two grants remain separate and cannot duplicate the same talent.
- Every learned talent and every relevant Sphere base expression must have a complete execution destination. The combat AI is never expected to reconstruct an action from prose.
- Method, Foundation, and item modifiers **stack** whenever their printed rules modify the same statistic or resource, unless a specific printed rule says otherwise. The one-Primary-Method restriction does not suppress Foundation benefits.
- Foundation stage benefits and the complete lifecycle—burdens, injuries, strains, deviations, integration, repair, treatment, temptations, and failure consequences—must be mapped.
- Recorded Art depth scales with CL and character importance. A standard CL10–14 combatant defaults to at least eight; significant characters require ten, powerful characters twelve, and rivals or bosses sixteen.
- Learned Forged Techniques, preserved forged expressions, and Emergency Technique Seeds remain distinct.
- Immortal Arts use a permanent GM Screen tab and a separate optional authoring command.

## Six user prompts

1. `Run Command 1 for: <request>`
2. `Run Command 2 from the locked blueprint.`
3. `Run Command 3 and fully map the ordinary character chassis.`
4. `Run Command 4 and build every executable combat surface.`
5. When applicable: `Run Optional Command 4B for Immortal Arts.`
6. `Run Command 5 and compile the immutable GM Screen candidate.`
7. `Run Command 6 and perform consumer verification.`

Commands 1–4 must remain separate unless the user knowingly accepts reduced depth.

## Matching consumer

`10_GM_SCREEN_TARGET/GM_Screen_HF05ZUI_R2K/` contains eighteen permanent tabs:

1. Overview / Core Stats
2. Leveling Ledger
3. Background & Origin
4. Spheres & Talents
5. Actions
6. Composite Playbooks
7. Forged Techniques
8. Martial Manuals / Recorded Arts
9. Immortal Arts
10. Foundation
11. Method
12. Dao & I Ching
13. Equipment / Resources / States
14. Diagnostics

The GM Screen acceptance test checks counts, save/reload retention, and field-level projection fidelity. It specifically rejects silent array truncation and missing execution-coverage or Foundation-lifecycle data.

## Release classifications

- `COMMAND_1_BLUEPRINT_LOCKED`
- `COMMAND_2_ADVANCEMENT_LEDGER_SEALED`
- `COMMAND_3_CHASSIS_COMPLETE`
- `COMMAND_4_EXECUTABLE_CHARACTER_COMPLETE`
- `OPTIONAL_COMMAND_4B_IMMORTAL_ARTS_COMPLETE`
- `COMMAND_5_GM_SCREEN_CANDIDATE_READY`
- `SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED`
- `FINAL_RELEASE_READY`

Sandbox browser evidence cannot independently authorize `FINAL_RELEASE_READY`. That status requires a passing `HF05ZUI-R2K.RealAcceptanceReport.v1` exported by the user-opened GM Screen and bound to the exact candidate SHA-256.

## R1E classification hardening

R1E rejects custom multi-Sphere Recorded Arts that bypass Technique Forging and requires Immortal Arts to project their complete linked action packets into the consumer.

## R1F semantic completeness and tournament boundary

R1F adds candidate-bound semantic validation learned from the Qin Yao and Ienaga Yumi CL18 failures. Production builds must reproduce selected-rule prerequisites, mandatory Sphere choices, scalars, base engines, riders, resources, states, Forged Drawbacks, legal equipment authority, Foundation runtime requirements, composite dependencies, and current evidence bindings.

Every sealed candidate exports:

- `Semantic_Validation_Report.json`
- `Signature_Loadout.json` containing 10–14 resolved actions

Only the 30 authoritative Foundations are playable. The 32 theoretical Chakra Foundation drafts are archived and excluded until their executable mechanics are authored. The matching consumer patch is HF05ZUI-R2K.3 and the matching tournament admission runtime is HF05ZN-R2G.

> **Machine Path indexes:** `09_RULES/Indexes/Paths/Tianxia_Path_Index_Master_P2A.json`; see `RELEASE_NOTES_PATH_INDEX_PHASE2A.md`.


## Phase 2C universal selected-rule execution coverage

The single authoring authority is `selected_rule_execution_coverage`. It covers Actions, modifiers, states, resources, procedures, passive statistics, and permission/record-only rules across every selected content family. Legacy Sphere/Talent coverage arrays are deprecated compatibility projections.


## Phase 2D enforcement

Use `feature_coverage_manifest`, `companions`, and `source_cl_realm_suppression_export`. Command 5 rejects indexed features that are missing, aggregated, prose-only, or incompletely exported.

## Phase 2E Item Book integration

Item Book R1 and Item Schema R2 are installed as canonical Factory authority. Production characters use `Equipment_Ledger.json` R2. Legacy equipment projection remains only for the current GM Screen compatibility period. See `02_CONTRACTS/ITEM_BOOK_R1_FACTORY_INTEGRATION_CONTRACT_P2E.md`.


## Phase 2F companion-sheet overlay

The current Factory includes generalized persistent companion records for spirits, Beastmaster beasts, awakened beasts, mounts, constructs, Item Spirits, and future companion categories. Command 3 must author a readable descriptive profile and complete stat block; Command 4 must map turn control, Actions, bond or training, care or offerings, injury/recovery, and execution coverage. The embedded consumer remains the HF05ZUI-R2K base contract with the **HF05ZUI-R2K** companion-sheet patch and 18 permanent tabs.

## Phase 2I HF1 embedded GM Screen

The embedded GM Screen target includes the R2K.3-HF1 Character Builder talent readability/classification hotfix. This is a UI/catalog packaging change only; factory character mechanics and candidate schemas are unchanged.
## Phase 2I HF2 embedded GM Screen

The embedded GM Screen target includes the R2K.3-HF2 Training Source and Recorded Art composer. The selectors are planning conveniences, not legality gates. Character Builder Factory Handoff ZIPs intentionally remain compact and non-production: the AI factory fills missing unlocked content during Commands 1–4, authors the canonical master ledger, and emits the complete compiled JSON surface only at Command 5.

