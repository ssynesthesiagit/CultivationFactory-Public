# Phase 2E — Item Book R1 Factory Integration

- Installs 318 canonical item definitions, 9 Treasure Sets, 318 GM projection cards, 85 canonical Sphere tags, and Item Schema R2.
- Adds authoritative Equipment Ledger R2 export and item execution coverage.
- Preserves the legacy equipment projection as a nonauthoritative compatibility file.
- Adds item catalog, instance, Attunement, charge, storage, durability, Growth, Item Spirit, Set, contribution, Source CL, Realm Suppression, and anti-shortcut validation.
- Does not modify or certify the live GM Screen item UI.

## Event-sourced acquisition

Permanent item instances are now advancement grants. Each instance must be acquired through an `item` allocation and reconcile with its R2 Equipment Ledger record, execution coverage, Source CL export, and source packet.
