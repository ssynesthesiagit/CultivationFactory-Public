# Release Notes — Machine-Readable Subpath and Tradition Indexes Phase 2B

Phase 2B adds canonical machine-readable indexes for all 156 orthodox Path specializations:

- 80 Qi Cultivation Subpaths
- 42 Body Refining Subpaths
- 34 Spirit Awakening traditions

Each entry includes stable IDs, owning Path, access class, prerequisites, CL3/6/10/14/18 progression, Source CL basis, Realm Suppression behavior, parent/variant relationships, linked procedure modules, exact source line ranges, and source hashes.

This phase changes no character ledger, compiler output, GM Screen schema, or specialization mechanics. The indexes are reference authorities and lookup accelerators. Exact rules remain in the cited canonical source text.
