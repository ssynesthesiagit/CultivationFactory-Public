# New-Chat Acceptance Protocol

1. Upload only `HF05ZVK_R1F_Factory.zip`.
2. Confirm that the new chat reports six base commands and optional Command 4B.
3. Run Commands 1–4 as separate prompts.
4. Run Command 5 and retain the immutable candidate SHA-256.
5. Run Command 6 and retain `Command_6_Audit.json` plus `render_proof.json`.
6. Import the exact candidate into the standalone HF05ZUI-R2K.3 GM Screen when available.
7. Export the real acceptance JSON.
8. Return the full workspace, candidate ZIP, simulated attestation, and real acceptance report for audit.

The audit should compare source claims, advancement events, talent coverage, Foundation lifecycle, Recorded Arts, Forged arrays, all eighteen tabs, and the exact candidate hash.
