# Operator Quickstart — HF05ZVK-R1F

## Initialize

```bash
python 07_TOOLS/init_character_workspace.py \
  --factory-root . \
  --workspace Workspace/My_Character \
  --character-id my_character \
  --request "Create a CL13 Core Formation character from the supplied prompt."
```

The initializer copies templates only. Do not build from a regression fixture.

## Use one prompt per reasoning command

1. **Command 1 — Source and Blueprint**  
   Read `01_COMMANDS/COMMAND_1_SOURCE_AND_BLUEPRINT_LOCK.md` and seal the concept, source evidence, selections, quality profile, and surface targets.

2. **Command 2 — Advancement and Accounting**  
   Read `01_COMMANDS/COMMAND_2_ADVANCEMENT_AND_RULES_LEDGER.md` and construct every CL row, source packet, permanent grant, training record, statistic, and checkpoint hash.

3. **Command 3 — Complete Chassis Mapping**  
   Read `01_COMMANDS/COMMAND_3_CHASSIS_AND_FULL_FEATURE_MAPPING.md` and complete Background, Origin, Method, Foundation lifecycle, Sphere/talent execution planning, Recorded Art roster, and blueprint reconciliation.

4. **Command 4 — Executable Combat**  
   Read `01_COMMANDS/COMMAND_4_EXECUTABLE_COMBAT_AND_TECHNIQUE_BUILD.md` and author every required action, modifier attachment, state, procedure, Recorded Art, Forged Technique, composite, and behavior record.

5. **Optional Command 4B — Immortal Arts**  
   Run only when the character legally possesses an Immortal Art.

6. **Command 5 — Compile and Seal**

```bash
python 07_TOOLS/run_command5.py \
  --factory-root . \
  --workspace Workspace/My_Character \
  --candidate Workspace/My_Character/My_Character_GM_Candidate.zip
```

7. **Command 6 — Consumer Verification**

```bash
python 07_TOOLS/run_command6.py \
  --factory-root . \
  --workspace Workspace/My_Character \
  --candidate Workspace/My_Character/My_Character_GM_Candidate.zip \
  --output Workspace/My_Character/My_Character_GM_Checked.zip
```

The checked ZIP must be byte-identical to the Command 5 candidate. Evidence remains beside it as a hash-bound sidecar.

## Real GM Screen acceptance

1. Extract `10_GM_SCREEN_TARGET/GM_Screen_HF05ZUI_R2K/`.
2. Open `index.html` in the target browser.
3. Import the exact Command 5 candidate.
4. Open **Character Viewer**.
5. Select **Run Acceptance Test**.
6. Export the acceptance JSON.
7. Keep that JSON beside the unchanged candidate ZIP.

Validate and issue the final classification:

```bash
python 07_TOOLS/run_command6.py \
  --factory-root . \
  --workspace Workspace/My_Character \
  --candidate Workspace/My_Character/My_Character_GM_Candidate.zip \
  --real-acceptance-report Workspace/My_Character/<Character>_HF05ZUI_R2H_Real_Acceptance.json \
  --output Workspace/My_Character/My_Character_GM_Final_Checked.zip
```

## Full self-audit

```bash
python 07_TOOLS/run_full_factory_audit.py \
  --factory-root . \
  --output Full_Factory_Audit.json
```

The static audit verifies the rules corpus, rules authority, all three fixtures, deterministic compilation, checksum integrity, and adversarial gates. Consumer lanes may be run separately when browser execution is constrained.


## Phase 2D enforcement

Use `feature_coverage_manifest`, `companions`, and `source_cl_realm_suppression_export`. Command 5 rejects indexed features that are missing, aggregated, prose-only, or incompletely exported.
