# Phase 2G — Factory / GM Screen Compatibility Seal

This release migrates the production consumer contract to **HF05ZUI-R2K.1** and seals the complete Factory-to-screen pipeline.

- Command 5 emits the exact 18-tab expectation manifest used by the installed screen.
- Command 6 validates the native R2K acceptance schema and the exact candidate ZIP hash.
- Paths, Subpaths, Insights, companions, equipment, resources, suppression, and diagnostics are first-class tab sources.
- The exact compiled ZIP is imported through native and pako paths, rendered, compact-saved, and rehydrated.
- Python and Chromium semantic hashes normalize integral decimals such as `20.0` and `20` to the same JSON value.
- Six representative lanes pass: standard, no personal Forged Technique, Immortal Art, Item Book, bonded spirit, and Beastmaster beast.
- No character mechanics changed.

See `11_AUDIT/PHASE2G_FACTORY_GMSCREEN_COMPATIBILITY_AUDIT.md`.
