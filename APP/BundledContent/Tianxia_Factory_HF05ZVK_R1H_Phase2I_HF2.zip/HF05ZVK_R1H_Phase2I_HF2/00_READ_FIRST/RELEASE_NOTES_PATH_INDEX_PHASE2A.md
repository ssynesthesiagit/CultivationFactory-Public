# Release Notes — Path Indexes Phase 2A

Phase 2A adds machine-readable indexes for Body Refining R8, Qi Cultivation R19, and Spirit Awakening R7.

## Added

- stable canonical Path, resource, feature, and feature-component IDs;
- complete CL1–20 progression maps;
- structured key ability and cultivation math;
- structured resource maximum, recovery, and 0-resource consequences;
- Source CL records;
- structured Realm Suppression profiles;
- exact source hashes and line-bounded excerpts;
- JSON Schema, validator, master lookup, and query tool.

## Not changed

- no Path mechanics;
- no Character Master Ledger schema;
- no Rules Selection Packet schema;
- no compiler output schema;
- no GM Screen schema;
- no Subpath, Insight, Foundation, Method, Sphere, or item mechanics.
