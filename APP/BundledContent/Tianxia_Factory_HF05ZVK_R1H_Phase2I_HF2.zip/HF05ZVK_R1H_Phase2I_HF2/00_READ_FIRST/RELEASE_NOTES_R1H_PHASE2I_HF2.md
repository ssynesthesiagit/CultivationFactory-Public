# HF05ZVK-R1H Phase 2I HF2 — Embedded Training Source and Recorded Art Composer

This packaging hotfix replaces the embedded GM Screen assets with HF05ZUI-R2K.3-HF2.

- Training Sources can be planned as `Manual / Source → Sphere → Talent + Talent`.
- Recorded Arts can be planned as `Art Name → Sphere → Talent + Talent`.
- Custom/source-specific expressions remain available.
- The composer performs no legality decision. The factory validates source, prerequisites, Realm, acquisition, and final execution coverage.
- Factory Handoff exports remain compact planning inputs. The factory creates `Character_Master_Ledger.json` and does not generate the complete `Build/` surface until Command 5.

Factory mechanics, candidate schemas, GM Screen acceptance schema, and HF05ZN-R2G combat behavior are unchanged.
