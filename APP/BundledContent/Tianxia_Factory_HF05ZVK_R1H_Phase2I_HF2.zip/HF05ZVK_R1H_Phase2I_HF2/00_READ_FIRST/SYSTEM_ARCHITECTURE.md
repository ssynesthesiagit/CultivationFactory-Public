# System Architecture — HF05ZVK-R1F

## Producer layers

1. **Evidence layer** — user request, source restrictions, direct evidence, and bounded inference.
2. **Blueprint layer** — intended character identity and subsystem selections.
3. **Event ledger** — CL-by-CL acquisitions, arithmetic, training records, and checkpoint hashes.
4. **Chassis map** — complete source-feature representation, Foundation lifecycle, execution-routing plan, and Recorded Art roster.
5. **Executable layer** — actions, passives, procedures, modifiers, states, resources, Recorded Arts, Forged Techniques, composites, Dao/I Ching, and optional Immortal Arts.
6. **Compiler layer** — deterministic consumer files generated from the master ledger.
7. **Consumer layer** — HF05ZUI-R2K normalization, eighteen-tab rendering, compact save, rehydration, and acceptance reporting.

## Source of truth

Only `Character_Master_Ledger.json` is authored after Command 2. Derived files are discarded and regenerated whenever a defect is found.

## Completeness invariant

Every selected source rule must resolve through this chain:

```text
source packet
→ permanent grant / subsystem record
→ advancement or acquisition event
→ execution coverage classification
→ action, modifier, state, procedure, or derived statistic
→ compiled consumer surface
→ rendered field-level acceptance check
```

No stage may substitute prose assurance for a missing record.

## Method and Foundation

A character may have one active Primary Method. That exclusivity applies only to competing Primary Methods. Printed Method, Foundation, and item effects otherwise stack normally. Every nonzero resource or statistic delta names its source grant.

## Consumer contract

Top-level record counts are necessary but insufficient. HF05ZUI-R2K also compares canonical and normalized arrays and subsystem fields so a screen cannot pass after flattening a multi-value record to its first element.

## R1E classification hardening

R1E rejects custom multi-Sphere Recorded Arts that bypass Technique Forging and requires Immortal Arts to project their complete linked action packets into the consumer.
