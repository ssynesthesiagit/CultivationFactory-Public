#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json
from pathlib import Path

def load_compiler(path:Path):
    spec=importlib.util.spec_from_file_location("hf05zvk_rules_authority",path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--factory-root",type=Path,required=True);ap.add_argument("--output",type=Path,required=True);a=ap.parse_args()
    C=load_compiler(a.factory_root/"05_COMPILER/compile_character.py");corpus=a.factory_root/"09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip";source=C.all_zip_text(corpus)
    path="Canonical/PHB/Tianxia_PHB_Chapter_03_Paths_and_Shared_Path_Rules_R2.md";body=source[path];excerpt=body[:min(900,len(body))]
    def packet(authority="tianxia_rules",name="Tianxia Shared Path Rules",source_path=path,source_text=excerpt,extra=None):
        row={"packet_id":"PKT_TEST","name":name,"authority":authority,"source_path":source_path,"source_section":"Opening source text","source_text":source_text,"source_text_sha256":hashlib.sha256(source_text.encode()).hexdigest(),"mechanical_interpretation":"Test packet."}
        if extra:row.update(extra)
        return {"schema_version":"HF05ZVK-R1F","packets":[row]}
    cases=[]
    def run(name,expect_pass,expected,fn):
        try: fn();passed=expect_pass;actual="PASS"
        except Exception as e: actual=str(e);passed=(not expect_pass and expected in actual)
        cases.append({"name":name,"expected":"PASS" if expect_pass else expected,"actual":actual,"passed":passed})
    run("exact_tianxia_packet_passes",True,"",lambda:C.verify_packets(packet(),corpus))
    item_path="Canonical/Items/Tianxia_ItemBook_R1.md";item_body=source[item_path];item_start=item_body.index("## 1. Cultivator's Storage Ring");item_excerpt=item_body[item_start:item_start+1200]
    run("exact_itembook_packet_passes",True,"",lambda:C.verify_packets(packet(name="Cultivator's Storage Ring — Item Book R1",source_path=item_path,source_text=item_excerpt),corpus))
    def bad_hash():
        r=packet();r["packets"][0]["source_text_sha256"]="0"*64;C.verify_packets(r,corpus)
    run("hash_mismatch_rejected",False,"RULES_PACKET_HASH_MISMATCH",bad_hash)
    run("missing_source_path_rejected",False,"RULES_PACKET_SOURCE_NOT_ACTIVE",lambda:C.verify_packets(packet(source_path="Canonical/Missing.md"),corpus))
    run("deprecated_source_rejected",False,"RULES_PACKET_SOURCE_NOT_ACTIVE",lambda:C.verify_packets(packet(source_path="Needed/Tianxia_PHB_Manuscript_v0_3.md"),corpus))
    run("excerpt_not_in_source_rejected",False,"RULES_PACKET_EXCERPT_NOT_FOUND",lambda:C.verify_packets(packet(source_text="This sentence is not in the authoritative rules corpus."),corpus))
    run("invalid_authority_rejected",False,"RULES_PACKET_AUTHORITY_INVALID",lambda:C.verify_packets(packet(authority="wiki_summary"),corpus))
    def inspiration_canonical():
        verified=C.verify_packets(packet(authority="inspiration_source"),corpus);C.require_canonical_authority({"name":"Imagined Sphere","source_packet_ids":["PKT_TEST"]},verified,"sphere.imagined","production")
    run("inspiration_cannot_authorize_mechanics",False,"CANONICAL_RULE_AUTHORITY_REQUIRED",inspiration_canonical)
    def broad_named():
        verified=C.verify_packets(packet(name="General PHB Rule"),corpus);C.require_named_canonical_selection({"name":"Unprinted Celestial Spoon Sphere","source_packet_ids":["PKT_TEST"]},verified,"sphere.spoon","production")
    run("broad_excerpt_cannot_authorize_invented_name",False,"CANONICAL_SELECTION_NAME_NOT_IN_SOURCE_PACKET",broad_named)
    def user_without_flag():
        verified=C.verify_packets(packet(authority="user_directive",name="Custom Technique"),corpus);C.require_named_canonical_selection({"name":"Custom Technique","source_packet_ids":["PKT_TEST"]},verified,"custom","production")
    run("user_directive_requires_custom_design_flag",False,"USER_DIRECTIVE_CUSTOM_DESIGN_FLAG_REQUIRED",user_without_flag)
    def user_with_flag():
        verified=C.verify_packets(packet(authority="user_directive",name="Custom Technique"),corpus);C.require_named_canonical_selection({"name":"Custom Technique","custom_design":True,"source_packet_ids":["PKT_TEST"]},verified,"custom","production")
    run("explicit_user_directive_custom_design_passes",True,"",user_with_flag)
    def fixture_original():
        verified=C.verify_packets(packet(authority="original_design",name="Fixture Mechanic"),corpus);C.require_canonical_authority({"name":"Fixture Mechanic","source_packet_ids":["PKT_TEST"]},verified,"fixture","acceptance_fixture")
    run("acceptance_fixture_original_design_passes",True,"",fixture_original)
    passed=all(x["passed"] for x in cases);result={"verdict":"PASS_HF05ZVK_R1F_CANON_P2A_RULES_AUTHORITY_SUITE" if passed else "FAIL_HF05ZVK_R1F_CANON_P2A_RULES_AUTHORITY_SUITE","case_count":len(cases),"passed_count":sum(x["passed"] for x in cases),"cases":cases}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result,indent=2));return 0 if passed else 2
if __name__=="__main__":raise SystemExit(main())
