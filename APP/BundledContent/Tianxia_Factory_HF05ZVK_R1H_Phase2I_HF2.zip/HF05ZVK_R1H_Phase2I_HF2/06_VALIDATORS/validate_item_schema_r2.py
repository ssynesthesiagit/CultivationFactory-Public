#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
from jsonschema import Draft202012Validator
BANNED=("[object object]","not recorded","unnamed","tbd","placeholder")

def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def verr(schema,obj,defn):
 s=dict(schema); s["$ref"]=f"#/$defs/{defn}"; return sorted(Draft202012Validator(s).iter_errors(obj),key=lambda e:list(e.path))
def visible(v,path=""):
 out=[]
 if isinstance(v,dict):
  for k,x in v.items(): out+=visible(x,f"{path}/{k}")
 elif isinstance(v,list):
  for n,x in enumerate(v): out+=visible(x,f"{path}/{n}")
 elif isinstance(v,str):
  for b in BANNED:
   if b in v.lower(): out.append(f"BANNED_VISIBLE_TEXT:{b}:{path}")
 return out

def semantic(cat,sets,proj,ledger):
 E=[]; W=[]
 cmap={i["item_id"]:i for i in cat["items"]}; smap={s["set_id"]:s for s in sets["sets"]}
 ids=list(cmap); names=[i["name"] for i in cat["items"]]
 if len(ids)!=len(set(ids)): E.append("DUPLICATE_ITEM_ID")
 if len(names)!=len(set(names)): E.append("DUPLICATE_ITEM_NAME")
 if sum(x.startswith("tianxia.item.ch4.") for x in ids)!=200: E.append("CH4_COUNT")
 if sum(x.startswith("tianxia.item.ch5.") for x in ids)!=90: E.append("CH5_COUNT")
 if len(cat["items"])!=318: E.append(f"CATALOG_COUNT:{len(cat['items'])}:EXPECTED_318")
 if len(sets["sets"])!=9: E.append("SET_COUNT")
 for s in sets["sets"]:
  for c in s["components"]:
   if c["item_id"] not in cmap: E.append(f"SET_COMPONENT_UNRESOLVED:{s['set_id']}:{c['item_id']}")
 for i in cat["items"]:
  if i["attunement"]["required"] != (i["attunement"]["slots"]>0): E.append(f"ATTUNEMENT_DEFINITION_MISMATCH:{i['item_id']}")
  if i["item_spirit_defaults"]["independent_turn"] and i["item_spirit_defaults"]["awakening_tier"]!="independent_spirit_life": E.append(f"FREE_ITEM_SPIRIT_TURN:{i['item_id']}")
  if i["type"]["category"]=="consumable" and (i["attunement"]["slots"]!=0 or not i["consumable_profile"]["is_consumable"]): E.append(f"CONSUMABLE_CONTRACT:{i['item_id']}")
  allm=[]
  for k in ("passive_properties","actions","bonus_actions","reactions","procedures","triggered_effects","object_interactions"): allm+=i["mechanics"][k]
  if not allm: E.append(f"NO_MECHANICS:{i['item_id']}")
  for m in allm:
   if not m["effect_text"].strip(): E.append(f"EMPTY_EFFECT:{m['action_id']}")
  if i["storage_profile"]["max_weight_lb"] is not None and i["storage_profile"]["max_weight_lb"]<0: E.append(f"BAD_STORAGE_MAX:{i['item_id']}")
 if [x["item_id"] for x in proj["items"]]!=ids: E.append("PROJECTION_ID_ORDER_MISMATCH")
 instmap={i["instance_id"]:i for i in ledger["item_instances"]}
 if len(instmap)!=len(ledger["item_instances"]): E.append("DUPLICATE_INSTANCE_ID")
 slots=0; known_actions=set(); known_reacts=set()
 for ii in ledger["item_instances"]:
  iid=ii["instance_id"]; item_id=ii["item_id"]; d=ii["definition_snapshot"]
  if item_id not in cmap and d is None: E.append(f"CUSTOM_ITEM_MISSING_SNAPSHOT:{iid}")
  if item_id in cmap and d is not None and d["item_id"]!=item_id: E.append(f"SNAPSHOT_ITEM_ID_MISMATCH:{iid}")
  definition=d or cmap.get(item_id)
  if not definition: continue
  att=ii["attunement_state"]
  if att["is_attuned"]: slots+=att["slots_used"]
  if ii["equipped_state"]["active"] and definition["attunement"]["required"] and not att["is_attuned"]: E.append(f"ACTIVE_UNATTUNED_ITEM:{iid}")
  if att["is_attuned"] and att["slots_used"]!=definition["attunement"]["slots"]: E.append(f"ATTUNEMENT_SLOT_MISMATCH:{iid}")
  if ii["durability"]["condition"] in ("broken","core_lost") and ii["equipped_state"]["active"]: E.append(f"BROKEN_ITEM_ACTIVE:{iid}")
  if ii["equipped_state"]["state"]=="consumed" and ii["equipped_state"]["active"]: E.append(f"CONSUMED_ITEM_ACTIVE:{iid}")
  for p in ii["runtime_charge_pools"]:
   if p["current"] is not None and p["maximum"] is not None and p["current"]>p["maximum"]: E.append(f"CHARGE_OVER_MAX:{iid}:{p['pool_id']}")
  st=ii["storage_contents"]
  if st["applicable"]:
   mw=definition["storage_profile"]["max_weight_lb"]; mv=definition["storage_profile"]["max_volume_cuft"]
   if mw is not None and st["current_weight_lb"] is not None and st["current_weight_lb"]>mw: E.append(f"STORAGE_WEIGHT_EXCEEDED:{iid}")
   if mv is not None and st["current_volume_cuft"] is not None and st["current_volume_cuft"]>mv: E.append(f"STORAGE_VOLUME_EXCEEDED:{iid}")
  isp=ii["item_spirit_state"]
  if isp["independent_turn"] and isp["awakening_tier"]!="independent_spirit_life": E.append(f"UNLICENSED_ITEM_SPIRIT_TURN:{iid}")
  if ii["equipped_state"]["active"]:
   for k in ("actions","bonus_actions","procedures","triggered_effects","object_interactions"): known_actions.update(x["action_id"] for x in definition["mechanics"][k])
   known_reacts.update(x["action_id"] for x in definition["mechanics"]["reactions"])
 if slots!=ledger["derived_equipment_summary"]["attunement_slots_used"]: E.append("ATTUNEMENT_SUMMARY_MISMATCH")
 if slots>ledger["derived_equipment_summary"]["attunement_slots_max"]: E.append("ATTUNEMENT_CAPACITY_EXCEEDED")
 if not set(ledger["derived_equipment_summary"]["active_item_action_ids"]).issubset(known_actions): E.append("LEDGER_UNKNOWN_ACTIVE_ACTION_ID")
 if not set(ledger["derived_equipment_summary"]["active_item_reaction_ids"]).issubset(known_reacts): E.append("LEDGER_UNKNOWN_ACTIVE_REACTION_ID")
 # armor/shield/weapon contributions
 ac_sources={x["source_instance_id"] for x in ledger["derived_equipment_summary"]["ac_contributions"] if x["active"]}
 atk_sources={x["source_instance_id"] for x in ledger["derived_equipment_summary"]["attack_contributions"] if x["active"]}
 for iid,ii in instmap.items():
  d=ii["definition_snapshot"] or cmap.get(ii["item_id"])
  if not d or not ii["equipped_state"]["active"]: continue
  if d["type"]["category"] in ("armor","shield") and iid not in ac_sources: E.append(f"MISSING_AC_CONTRIBUTION:{iid}")
  if d["type"]["category"]=="weapon" and iid not in atk_sources: E.append(f"MISSING_ATTACK_CONTRIBUTION:{iid}")
 # active set resonances
 for ar in ledger["derived_equipment_summary"]["active_set_resonances"]:
  if not ar["active"]: continue
  s=smap.get(ar["set_id"])
  if not s: E.append(f"UNKNOWN_ACTIVE_SET:{ar['set_id']}"); continue
  th=next((x for x in s["thresholds"] if x["threshold_id"]==ar["threshold_id"]),None)
  if not th: E.append(f"UNKNOWN_SET_THRESHOLD:{ar['threshold_id']}"); continue
  ci=[instmap.get(x) for x in ar["component_instance_ids"]]
  if any(x is None for x in ci): E.append(f"SET_COMPONENT_INSTANCE_MISSING:{ar['threshold_id']}"); continue
  itemids={x["item_id"] for x in ci}
  if th["required_component_item_ids"] and not set(th["required_component_item_ids"]).issubset(itemids): E.append(f"SET_REQUIRED_COMPONENT_MISSING:{ar['threshold_id']}")
  if th["required_component_count"] is not None and len(itemids)<th["required_component_count"]: E.append(f"SET_COMPONENT_COUNT_LOW:{ar['threshold_id']}")
  for x in ci:
   if not x["equipped_state"]["active"]: E.append(f"SET_COMPONENT_INACTIVE:{x['instance_id']}")
   d=x["definition_snapshot"] or cmap.get(x["item_id"])
   if d and d["attunement"]["required"] and not x["attunement_state"]["is_attuned"]: E.append(f"SET_COMPONENT_UNATTUNED:{x['instance_id']}")
 E+=visible(proj)
 return sorted(set(E)),W

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--schema',default='ItemSchema_R2.json'); ap.add_argument('--catalog',default='ItemCatalog_R2.json'); ap.add_argument('--sets',default='TreasureSetCatalog_R2.json'); ap.add_argument('--projection',default='ItemGMProjection_R2.json'); ap.add_argument('--ledger',default='EquipmentLedger_R2.example.json'); ap.add_argument('--output'); a=ap.parse_args()
 schema,cat,sets,proj,ledger=[load(getattr(a,x)) for x in ('schema','catalog','sets','projection','ledger')]
 errs=[]
 for label,obj,defn in [('catalog',cat,'Catalog'),('sets',sets,'SetCatalog'),('projection',proj,'GMProjection'),('ledger',ledger,'EquipmentLedger')]:
  for e in verr(schema,obj,defn): errs.append({'surface':label,'path':'/'+ '/'.join(str(x) for x in e.path),'message':e.message})
 sem,warn=semantic(cat,sets,proj,ledger)
 report={'schema':'Tianxia.ItemSchemaValidation.R2','verdict':'PASS_ITEM_SCHEMA_R2' if not errs and not sem else 'FAIL_ITEM_SCHEMA_R2','json_schema_error_count':len(errs),'semantic_error_count':len(sem),'warning_count':len(warn),'json_schema_errors':errs,'semantic_errors':sem,'warnings':warn,'counts':{'catalog_items':len(cat['items']),'sets':len(sets['sets']),'projection_cards':len(proj['items']),'instances':len(ledger['item_instances'])}}
 out=json.dumps(report,indent=2,ensure_ascii=False)
 if a.output: Path(a.output).write_text(out,encoding='utf-8')
 print(out); return 0 if report['verdict'].startswith('PASS') else 1
if __name__=='__main__': raise SystemExit(main())
