#!/usr/bin/env python3
from pathlib import Path
import json,copy,importlib.util
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('v',ROOT/'06_VALIDATORS/validate_selected_rule_execution_coverage.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
spirit=json.loads((ROOT/'08_FIXTURES/GOOD_COMPANION_COVERAGE/Character_Master_Ledger.json').read_text())
beast=json.loads((ROOT/'08_FIXTURES/GOOD_BEASTMASTER_BEAST_COVERAGE/Character_Master_Ledger.json').read_text())
cases=[]
def run(base,name,mut,expected):
 d=copy.deepcopy(base);mut(d);issues=v.validate_ledger(d);cases.append({'name':name,'pass':expected in issues,'expected':expected,'issues':issues})
run(spirit,'missing_description',lambda d:d['companions'][0]['descriptive_profile'].pop('appearance'), 'COMPANION_DESCRIPTION_FIELD_INCOMPLETE:COMP_EMBER_ARCHIVIST:appearance')
run(spirit,'missing_stat',lambda d:d['companions'][0]['stat_block'].pop('ac'), 'COMPANION_STAT_BLOCK_FIELD_MISSING:COMP_EMBER_ARCHIVIST:ac')
run(spirit,'turn_list_mismatch',lambda d:d['companions'][0]['turn_control_model'].__setitem__('independent_actions',[]), 'COMPANION_TURN_ACTION_LIST_MISMATCH:COMP_EMBER_ARCHIVIST')
run(spirit,'missing_spirit_sustenance',lambda d:(d['companions'][0]['care_and_sustenance'].__setitem__('offerings',[]),d['companions'][0]['care_and_sustenance'].__setitem__('special_needs',[])), 'SPIRIT_SUSTENANCE_OR_OFFERING_MISSING:COMP_EMBER_ARCHIVIST')
run(beast,'missing_beast_commands',lambda d:d['companions'][0]['training_and_commands'].__setitem__('trained_commands',[]), 'BEAST_TRAINED_COMMANDS_MISSING:COMP_STORMHORN_COURSER')
run(beast,'missing_beast_autonomy',lambda d:d['companions'][0]['training_and_commands'].__setitem__('autonomous_behavior',''), 'BEAST_AUTONOMOUS_BEHAVIOR_MISSING:COMP_STORMHORN_COURSER')
run(beast,'missing_beast_care',lambda d:(d['companions'][0]['care_and_sustenance'].__setitem__('diet',''),d['companions'][0]['care_and_sustenance'].__setitem__('ordinary_needs',[])), 'BEAST_CARE_PROFILE_MISSING:COMP_STORMHORN_COURSER')
run(beast,'missing_base_creature',lambda d:d['companions'][0]['creature_origin'].__setitem__('base_creature',''), 'BEAST_BASE_CREATURE_MISSING:COMP_STORMHORN_COURSER')
out={'schema':'HF05ZVK-R1F.CompanionSheetAntiShortcut.P2F.v1','pass':all(x['pass'] for x in cases),'cases':cases,'summary':{'total':len(cases),'passed':sum(1 for x in cases if x['pass']),'spirit_cases':4,'beast_cases':4}}
(ROOT/'11_AUDIT/PHASE2F_COMPANION_SHEET_ANTI_SHORTCUT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2));raise SystemExit(0 if out['pass'] else 1)
