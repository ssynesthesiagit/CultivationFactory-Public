#!/usr/bin/env python3
from __future__ import annotations
import copy,importlib.util,json,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def mod():
 p=ROOT/'06_VALIDATORS'/'validate_item_integration_p2e.py';s=importlib.util.spec_from_file_location('iv',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
BASE=load(ROOT/'08_FIXTURES'/'GOOD_ITEMBOOK_R1_STORAGE_RING'/'Character_Master_Ledger.json')
def mutate(case,L):
 if case=='missing_item_allocation':
  for lv in L['advancement']['levels']:
   lv['allocations']=[a for a in lv.get('allocations',[]) if a.get('allocation_id')!='AL_CL13_ITEM_STORAGE_RING']
 elif case=='missing_ledger':L.pop('equipment_ledger_r2',None)
 elif case=='attunement_overflow':L['equipment_ledger_r2']['derived_equipment_summary']['attunement_slots_max']=0
 elif case=='active_unattuned':L['equipment_ledger_r2']['item_instances'][0]['attunement_state']['is_attuned']=False
 elif case=='broken_active':L['equipment_ledger_r2']['item_instances'][0]['durability']['condition']='broken'
 elif case=='unknown_action':L['equipment_ledger_r2']['derived_equipment_summary']['active_item_action_ids']=['ACT_UNKNOWN']
 elif case=='missing_mechanic_mapping':L['item_execution_coverage']['items'][0]['mechanic_mappings'].pop()
 elif case=='action_as_permission':L['item_execution_coverage']['items'][0]['mechanic_mappings'][3]['mode']='permission_or_record_only';L['item_execution_coverage']['items'][0]['mechanic_mappings'][3]['runtime_target_ids']=['PERM_ITEM_STORAGE_RING_NO_LIVING_CREATURES']
 elif case=='missing_universal':L['selected_rule_execution_coverage']=[x for x in L['selected_rule_execution_coverage'] if x.get('source_rule_id')!='tianxia.item.ch4.001.cultivators_storage_ring']
 elif case=='missing_source_cl':L['source_cl_realm_suppression_export']['rule_exports']=[x for x in L['source_cl_realm_suppression_export']['rule_exports'] if x.get('source_rule_id')!='tianxia.item.ch4.001.cultivators_storage_ring']
 elif case=='false_manifest':L['feature_coverage_manifest']['item_coverage']=[]
 elif case=='storage_overflow':L['equipment_ledger_r2']['item_instances'][0]['storage_contents']['current_weight_lb']=501
 elif case=='unlicensed_item_spirit':
  s=L['equipment_ledger_r2']['item_instances'][0]['item_spirit_state'];s['awakening_tier']='item_spirit';s['independent_turn']=True;s['companion_profile_ref']=None
 return L
CASES=['missing_item_allocation','missing_ledger','attunement_overflow','active_unattuned','broken_active','unknown_action','missing_mechanic_mapping','action_as_permission','missing_universal','missing_source_cl','false_manifest','storage_overflow','unlicensed_item_spirit']
def main():
 m=mod();rows=[]
 positive=m.validate_ledger(copy.deepcopy(BASE),'complete');rows.append({'case':'positive','expected':'PASS','actual':'PASS' if not positive else 'FAIL','issues':positive})
 for c in CASES:
  issues=m.validate_ledger(mutate(c,copy.deepcopy(BASE)),'complete');rows.append({'case':c,'expected':'FAIL','actual':'FAIL' if issues else 'PASS','issues':issues})
 ok=all(x['expected']==x['actual'] for x in rows);out={'schema':'HF05ZVK-R1F.ItemAntiShortcutSuite.P2E.v1','verdict':'PASS_ITEM_ANTI_SHORTCUT_P2E' if ok else 'FAIL_ITEM_ANTI_SHORTCUT_P2E','cases':rows}
 p=ROOT/'11_AUDIT'/'PHASE2E_ITEM_ANTI_SHORTCUT_SUITE.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out,indent=2));return 0 if ok else 1
if __name__=='__main__':raise SystemExit(main())
