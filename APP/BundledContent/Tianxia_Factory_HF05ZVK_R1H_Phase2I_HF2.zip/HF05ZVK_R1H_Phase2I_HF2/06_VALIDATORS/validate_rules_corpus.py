#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path

def hfile(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(131072),b""):h.update(chunk)
    return h.hexdigest()

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--rules-root",type=Path,required=True);ap.add_argument("--output",type=Path);a=ap.parse_args();issues=[];checked=[]
    mp=a.rules_root/"RULES_SOURCE_MANIFEST.json"
    try: manifest=json.loads(mp.read_text(encoding="utf-8"))
    except Exception as e: manifest={};issues.append(f"MANIFEST_INVALID:{e}")
    if manifest.get("schema_version")!="HF05ZVK-R1F.CanonCorpusP2A.v1":issues.append(f"MANIFEST_SCHEMA_INVALID:{manifest.get('schema_version')}")
    rows=manifest.get("files")
    if not isinstance(rows,list) or not rows:issues.append("MANIFEST_FILES_EMPTY");rows=[]
    seen=set()
    for row in rows:
        rel=row.get("path") if isinstance(row,dict) else None
        if not rel or rel in seen:issues.append(f"MANIFEST_PATH_INVALID_OR_DUPLICATE:{rel}");continue
        seen.add(rel);p=a.rules_root/rel
        if not p.is_file():issues.append(f"RULES_FILE_MISSING:{rel}");continue
        got_sha=hfile(p);got_bytes=p.stat().st_size
        if row.get("sha256")!=got_sha:issues.append(f"RULES_HASH_MISMATCH:{rel}")
        if row.get("bytes")!=got_bytes:issues.append(f"RULES_SIZE_MISMATCH:{rel}:{row.get('bytes')}!={got_bytes}")
        zip_status=None
        if p.suffix.lower()==".zip":
            try:
                with zipfile.ZipFile(p) as z:zip_status=z.testzip()
                if zip_status is not None:issues.append(f"ZIP_MEMBER_CORRUPT:{rel}:{zip_status}")
            except Exception as e:issues.append(f"ZIP_INVALID:{rel}:{e}");zip_status="invalid"
        checked.append({"path":rel,"sha256":got_sha,"bytes":got_bytes,"zip_test":zip_status})
    required={"Tianxia_Canonical_Rules_Corpus_P2A.zip","CANON_AUTHORITY_MANIFEST_P2A.json","Source_Text/PHB/Tianxia_PHB_Manuscript_v0_7_Subpaths_Inserted.md","Source_Text/Paths/Qi/Tianxia_Qi_Cultivation_Player_Path_Chapter_R19.md","Source_Text/Paths/Body/Tianxia_Body_Refining_Player_Path_Chapter_R8.md","Source_Text/Paths/Spirit/Tianxia_Spirit_Awakening_Player_Path_Chapter_R7.md","Source_Text/Insights/Tianxia_Cultivation_Insights_Compendium_R1.md","Source_Text/Tianxia_Sphere_Compendium_Latest_R0I_85Spheres.md","Indexes/Paths/Tianxia_Path_Index_Master_P2A.json","Indexes/Paths/body_refining.path_index.p2a.json","Indexes/Paths/qi_cultivation.path_index.p2a.json","Indexes/Paths/spirit_awakening.path_index.p2a.json","Items/Tianxia_ItemBook_R1.md","Items/ItemCatalog_R2.json","Items/TreasureSetCatalog_R2.json","Items/ItemGMProjection_R2.json","Items/ItemSchema_R2.json","Items/EquipmentLedger_R2.schema.json","Items/validate_item_schema_r2.py"}
    for rel in sorted(required-seen):issues.append(f"REQUIRED_AUTHORITY_MISSING_FROM_MANIFEST:{rel}")
    corpus=a.rules_root/"Tianxia_Canonical_Rules_Corpus_P2A.zip"
    if corpus.is_file():
        try:
            with zipfile.ZipFile(corpus) as z:
                if "_CANON_AUTHORITY_MANIFEST.json" not in z.namelist():issues.append("CORPUS_AUTHORITY_MANIFEST_MISSING")
                else:
                    auth=json.loads(z.read("_CANON_AUTHORITY_MANIFEST.json").decode("utf-8"));active=auth.get("active_packet_sources") or []
                    if auth.get("schema_version")!="HF05ZVK-R1F.CanonAuthorityManifest.P2A.v1":issues.append("CORPUS_AUTHORITY_SCHEMA_INVALID")
                    if not active:issues.append("CORPUS_ACTIVE_PACKET_SOURCES_EMPTY")
                    names=set(z.namelist())
                    if "Needed/Tianxia_PHB_Manuscript_v0_3.md" in names:issues.append("DEPRECATED_PHB_PRESENT_IN_ACTIVE_CORPUS")
                    for rel in ["Canonical/PHB/Tianxia_PHB_Manuscript_v0_7_Subpaths_Inserted.md","Canonical/Paths/Qi/Tianxia_Qi_Cultivation_Player_Path_Chapter_R19.md","Canonical/Paths/Body/Tianxia_Body_Refining_Player_Path_Chapter_R8.md","Canonical/Paths/Spirit/Tianxia_Spirit_Awakening_Player_Path_Chapter_R7.md","Canonical/Insights/Tianxia_Cultivation_Insights_Compendium_R1.md","Canonical/Items/Tianxia_ItemBook_R1.md"]:
                        if rel not in active:issues.append(f"CANONICAL_PACKET_SOURCE_NOT_ACTIVE:{rel}")
        except Exception as e:issues.append(f"CORPUS_AUTHORITY_VALIDATION_FAILED:{e}")
    result={"verdict":"PASS_HF05ZVK_R1F_CANON_P2A_RULES_CORPUS" if not issues else "FAIL_HF05ZVK_R1F_CANON_P2A_RULES_CORPUS","issues":issues,"checked_count":len(checked),"checked":checked}
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2));return 0 if not issues else 2
if __name__=="__main__":raise SystemExit(main())
