#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from referencing import Registry, Resource
from jsonschema import Draft202012Validator


def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--schemas',type=Path,required=True)
    ap.add_argument('--ledger',type=Path,required=True)
    ap.add_argument('--packets',type=Path,required=True)
    ap.add_argument('--view-model',type=Path)
    args=ap.parse_args()
    registry=Registry()
    schemas={}
    for p in args.schemas.glob('*.schema.json'):
        schema=load(p); schemas[p.name]=schema
        registry=registry.with_resource(schema.get('$id',p.name),Resource.from_contents(schema))
    checks=[('character_master_ledger.schema.json',args.ledger),('rules_selection_packets.schema.json',args.packets)]
    if args.view_model: checks.append(('gm_character_view_model.schema.json',args.view_model))
    errors=[]
    for schema_name,path in checks:
        validator=Draft202012Validator(schemas[schema_name],registry=registry)
        for err in sorted(validator.iter_errors(load(path)),key=lambda e:list(e.absolute_path)):
            where='.'.join(map(str,err.absolute_path)) or 'root'
            errors.append(f'{path.name}:{where}:{err.message}')
    result={'verdict':'PASS_HF05ZVK_R1F_JSON_SCHEMAS' if not errors else 'FAIL_HF05ZVK_R1F_JSON_SCHEMAS','errors':errors}
    print(json.dumps(result,indent=2))
    return 0 if not errors else 2
if __name__=='__main__': raise SystemExit(main())
