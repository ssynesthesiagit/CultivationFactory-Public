#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, importlib.util
from pathlib import Path

def load(p): return json.loads(p.read_text(encoding='utf-8'))
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--factory-root',type=Path,required=True); ap.add_argument('--output',type=Path,required=True); a=ap.parse_args(); root=a.factory_root
 vp=root/'06_VALIDATORS'/'validate_semantic_requirements.py'; spec=importlib.util.spec_from_file_location('sem',vp); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
 results=[]
 expected={'QinYao':{'AUTO_PRINTED_PREREQUISITE_NOT_MET','AUTO_FORGED_PREPARATION_NOT_ENFORCED','RULE_PACKET_COUNT_MISMATCH'},'IenagaYumi':{'FOUNDATION_STARTING_RESOURCE_CONTRADICTION'}}
 for label in ('QinYao','IenagaYumi'):
  d=root/'08_FIXTURES'/'NEGATIVE_SEMANTIC_CL18'/label; r=mod.run(load(d/'Character_Master_Ledger.json'),load(d/'Rules_Selection_Packets.json'))
  codes={x['code'] for x in r['issues']}; missing=sorted(expected[label]-codes)
  results.append({'fixture':label,'verdict':r['verdict'],'release_ready':r['release_ready'],'counts':r['counts'],'expected_codes':sorted(expected[label]),'missing_expected_codes':missing,'sample_codes':sorted(codes)[:40]})
 passed=all(not x['release_ready'] and not x['missing_expected_codes'] for x in results)
 out={'schema':'HF05ZVK-R1F.SemanticRegression.v1','verdict':'PASS_HF05ZVK_R1F_SEMANTIC_REGRESSION' if passed else 'FAIL_HF05ZVK_R1F_SEMANTIC_REGRESSION','results':results}
 a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,indent=2)); return 0 if passed else 2
if __name__=='__main__': raise SystemExit(main())
