#!/usr/bin/env python3
"""Phase 2D indexed feature coverage, Source CL export, and anti-shortcut validation."""
from __future__ import annotations
import argparse, importlib.util, json
from pathlib import Path
from typing import Any
ROOT=Path(__file__).resolve().parents[1]
VERSION='HF05ZVK-R1F.FeatureCoverageEnforcement.P2D.v1'
EXPORT_VERSION='HF05ZVK-R1F.SourceCLRealmSuppressionExport.P2D.v1'

def arr(v): return v if isinstance(v,list) else []
def obj(v): return v if isinstance(v,dict) else {}
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def item_module():
 p=ROOT/'06_VALIDATORS'/'validate_item_integration_p2e.py';spec=importlib.util.spec_from_file_location('p2e_item',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def old_module():
 p=ROOT/'06_VALIDATORS'/'validate_selected_rule_execution_coverage_p2c.py';spec=importlib.util.spec_from_file_location('p2c_cov',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def collect_selected_rules(L):
 return old_module().collect_selected_rules(L)

def project_legacy(L,category):
 return old_module().project_legacy(L,category)

def indexes():
 pm=load(ROOT/'09_RULES/Indexes/Paths/Tianxia_Path_Index_Master_P2A.json'); sm=load(ROOT/'09_RULES/Indexes/Subpaths/Tianxia_Subpath_Tradition_Index_Master_P2B.json'); ir=load(ROOT/'09_RULES/Source_Text/Insights/Tianxia_Central_Cultivation_Insights_AI_Reference_R4.json')
 path_detail={}
 for p in pm['paths']:
  d=load(ROOT/'09_RULES/Indexes/Paths'/p['index_file']);path_detail[p['canonical_id']]=d
 return pm,path_detail,{x['canonical_id']:x for x in sm['entries']},{x['canonical_id']:x for x in ir['records'] if x.get('selectable')}

def expected_path_features(index,cl):
 out=[]
 for row in index['progression']:
  if row['cl']<=cl:
   for f in row['features']:
    if f['canonical_id'] not in out:out.append(f['canonical_id'])
 return out

def validate_ledger(L:dict[str,Any],phase='complete'):
 issues=[]
 old=old_module();issues.extend(old.validate_ledger(L,phase))
 if L.get('coverage_enforcement_version')!=VERSION:issues.append('FEATURE_COVERAGE_ENFORCEMENT_VERSION_MISSING')
 pm,pdetails,subidx,insidx=indexes()
 features=arr(L.get('features')); by_feature={r.get('feature_id'):r for r in features if isinstance(r,dict)}
 covs=arr(L.get('selected_rule_execution_coverage')); by_rule={r.get('source_rule_id'):r for r in covs if isinstance(r,dict)}; by_covid={r.get('coverage_id'):r for r in covs if isinstance(r,dict)}
 paths=arr(L.get('path_selections'))
 if not paths:issues.append('PATH_SELECTIONS_REQUIRED')
 expected_path_groups=[]
 for ps in paths:
  pid=ps.get('path_id');cl=ps.get('effective_cl');idx=pdetails.get(pid)
  if not idx:issues.append(f'PATH_INDEX_UNKNOWN:{pid}');continue
  if not isinstance(cl,int) or not 1<=cl<=L.get('character',{}).get('cl',20):issues.append(f'PATH_EFFECTIVE_CL_INVALID:{pid}:{cl}');continue
  expected=expected_path_features(idx,cl);expected_path_groups.append((pid,cl,expected))
  actual=[r.get('feature_id') for r in features if r.get('category')=='path_feature' and (r.get('owning_path_id',pid)==pid)]
  if set(actual)!=set(expected):issues.append(f'PATH_FEATURE_SET_MISMATCH:{pid}:missing={sorted(set(expected)-set(actual))}:extra={sorted(set(actual)-set(expected))}')
  for fid in expected:
   row=by_feature.get(fid); ref=next((x for x in idx['features'] if x['canonical_id']==fid),None)
   if not row:continue
   if row.get('name')!=ref.get('display_name'):issues.append(f'PATH_FEATURE_NAME_MISMATCH:{fid}')
   if row.get('gained_at_cl')!=ref.get('minimum_cl'):issues.append(f'PATH_FEATURE_CL_MISMATCH:{fid}')
   c=by_rule.get(fid)
   if not c:issues.append(f'PATH_FEATURE_COVERAGE_MISSING:{fid}')
   elif c.get('source_rule_category')!='path_feature':issues.append(f'PATH_FEATURE_CATEGORY_MISMATCH:{fid}')
 # Subpath root and tier features.
 expected_sub_groups=[]
 for sp in arr(L.get('subpaths')):
  sid=sp.get('subpath_id');idx=subidx.get(sid)
  if not idx:issues.append(f'SUBPATH_INDEX_UNKNOWN:{sid}');continue
  owning=sp.get('owning_path_id');ps=next((x for x in paths if x.get('path_id')==owning),None)
  if not ps:issues.append(f'SUBPATH_OWNING_PATH_NOT_SELECTED:{sid}:{owning}');continue
  cl=ps['effective_cl'];expected=[f['canonical_id'] for f in idx['feature_progression'] if f['granted_at_cl']<=cl];expected_sub_groups.append((sid,cl,expected))
  if set(sp.get('feature_ids_expected',[]))!=set(expected):issues.append(f'SUBPATH_EXPECTED_FEATURE_LIST_MISMATCH:{sid}')
  actual=[r.get('feature_id') for r in features if r.get('category')=='subpath_feature' and r.get('owning_subpath_id')==sid]
  if set(actual)!=set(expected):issues.append(f'SUBPATH_FEATURE_SET_MISMATCH:{sid}:missing={sorted(set(expected)-set(actual))}:extra={sorted(set(actual)-set(expected))}')
  if sid not in by_rule:issues.append(f'SUBPATH_SELECTION_COVERAGE_MISSING:{sid}')
  for fid in expected:
   row=by_feature.get(fid);ref=next(x for x in idx['feature_progression'] if x['canonical_id']==fid)
   if not row:continue
   if row.get('name')!=ref['display_name']:issues.append(f'SUBPATH_FEATURE_NAME_MISMATCH:{fid}')
   if row.get('gained_at_cl')!=ref['granted_at_cl']:issues.append(f'SUBPATH_FEATURE_CL_MISMATCH:{fid}')
   c=by_rule.get(fid)
   if not c:issues.append(f'SUBPATH_FEATURE_COVERAGE_MISSING:{fid}')
   elif c.get('source_rule_category')!='subpath_feature':issues.append(f'SUBPATH_FEATURE_CATEGORY_MISMATCH:{fid}')
 # Insights.
 for ins in arr(L.get('cultivation_insights')):
  iid=ins.get('insight_id');ref=insidx.get(iid)
  if not ref:issues.append(f'INSIGHT_INDEX_UNKNOWN_OR_NONSELECTABLE:{iid}');continue
  if ins.get('name')!=ref.get('display_name'):issues.append(f'INSIGHT_NAME_MISMATCH:{iid}')
  if int(ins.get('gained_at_cl') or 0)<int(ref.get('minimum_cl') or 1):issues.append(f'INSIGHT_GAINED_BEFORE_MINIMUM_CL:{iid}')
  c=by_rule.get(iid)
  if not c:issues.append(f'INSIGHT_COVERAGE_MISSING:{iid}')
  elif c.get('source_rule_category')!='cultivation_insight':issues.append(f'INSIGHT_CATEGORY_MISMATCH:{iid}')
 # Companions and their features.
 for comp in arr(L.get('companions')):
  cid=comp.get('companion_id');expected=arr(comp.get('feature_ids_expected'))
  actual=[r.get('feature_id') for r in features if r.get('category')=='companion_feature' and r.get('owning_companion_id')==cid]
  if set(actual)!=set(expected):issues.append(f'COMPANION_FEATURE_SET_MISMATCH:{cid}:missing={sorted(set(expected)-set(actual))}:extra={sorted(set(actual)-set(expected))}')
  independent=set(obj(comp.get('action_economy')).get('independent_actions',[]))
  action_ids={r.get('action_id') for r in arr(L.get('actions'))}
  if not independent.issubset(action_ids):issues.append(f'COMPANION_ACTION_UNRESOLVED:{cid}:{sorted(independent-action_ids)}')
  for fid in expected:
   if fid not in by_rule:issues.append(f'COMPANION_FEATURE_COVERAGE_MISSING:{cid}:{fid}')
   elif by_rule[fid].get('source_rule_category')!='companion_feature':issues.append(f'COMPANION_FEATURE_CATEGORY_MISMATCH:{fid}')
 # Companion character-sheet completeness and Beastmaster support.
 if arr(L.get('companions')) and L.get('companion_sheet_version')!='HF05ZVK-R1F.CompanionSheet.P2F.v1':issues.append('COMPANION_SHEET_VERSION_MISSING')
 beast_categories={'beast_companion','beastmaster_beast','tame_beast','awakened_beast','mount'}
 for comp in arr(L.get('companions')):
  cid=comp.get('companion_id');cat=comp.get('companion_category');desc=obj(comp.get('descriptive_profile'));stat=obj(comp.get('stat_block'));turn=obj(comp.get('turn_control_model'))
  if not cat:issues.append(f'COMPANION_CATEGORY_MISSING:{cid}')
  for k in ('short_description','species_or_nature','appearance','personality','relationship_summary'):
   if len(str(desc.get(k) or '').strip())<20:issues.append(f'COMPANION_DESCRIPTION_FIELD_INCOMPLETE:{cid}:{k}')
  for k in ('size','creature_type','ac','hp_current','hp_max','speed','ability_scores','proficiency_bonus','companion_cl','effective_cl'):
   if stat.get(k) in (None,'',{}):issues.append(f'COMPANION_STAT_BLOCK_FIELD_MISSING:{cid}:{k}')
  legacy=set(obj(comp.get('action_economy')).get('independent_actions',[])); modern=set(turn.get('independent_actions',[]))
  if legacy!=modern:issues.append(f'COMPANION_TURN_ACTION_LIST_MISMATCH:{cid}')
  if bool(modern)!=bool(turn.get('independent_turn')):issues.append(f'COMPANION_INDEPENDENT_TURN_FLAG_MISMATCH:{cid}')
  if cat in beast_categories:
   tr=obj(comp.get('training_and_commands')); care=obj(comp.get('care_and_sustenance')); origin=obj(comp.get('creature_origin'))
   if not arr(tr.get('trained_commands')):issues.append(f'BEAST_TRAINED_COMMANDS_MISSING:{cid}')
   if not str(tr.get('autonomous_behavior') or '').strip():issues.append(f'BEAST_AUTONOMOUS_BEHAVIOR_MISSING:{cid}')
   if not (str(care.get('diet') or '').strip() or arr(care.get('ordinary_needs'))):issues.append(f'BEAST_CARE_PROFILE_MISSING:{cid}')
   if not str(origin.get('base_creature') or '').strip():issues.append(f'BEAST_BASE_CREATURE_MISSING:{cid}')
  if cat in {'bonded_spirit','spirit_companion','ancestral_companion','item_spirit'}:
   care=obj(comp.get('care_and_sustenance'))
   if not (arr(care.get('offerings')) or arr(care.get('special_needs'))):issues.append(f'SPIRIT_SUSTENANCE_OR_OFFERING_MISSING:{cid}')
 # Manifest must be a faithful, recalculable mirror, not a self-asserted shortcut.
 mf=obj(L.get('feature_coverage_manifest'))
 if mf.get('schema_version')!=VERSION:issues.append('FEATURE_COVERAGE_MANIFEST_VERSION_MISSING')
 pg={r.get('owner_id'):r for r in arr(mf.get('path_feature_coverage'))}
 for pid,cl,expected in expected_path_groups:
  g=pg.get(pid)
  if not g:issues.append(f'PATH_FEATURE_MANIFEST_MISSING:{pid}');continue
  actual=[r.get('feature_id') for r in features if r.get('category')=='path_feature' and r.get('feature_id') in expected]
  covids=[by_rule[f].get('coverage_id') for f in expected if f in by_rule]
  if set(g.get('expected_feature_ids',[]))!=set(expected) or set(g.get('ledger_feature_ids',[]))!=set(actual) or set(g.get('coverage_ids',[]))!=set(covids):issues.append(f'PATH_FEATURE_MANIFEST_FALSE_ASSERTION:{pid}')
 sg={r.get('owner_id'):r for r in arr(mf.get('subpath_feature_coverage'))}
 for sid,cl,expected in expected_sub_groups:
  g=sg.get(sid)
  if not g:issues.append(f'SUBPATH_FEATURE_MANIFEST_MISSING:{sid}');continue
  actual=[r.get('feature_id') for r in features if r.get('category')=='subpath_feature' and r.get('feature_id') in expected];covids=[by_rule[f].get('coverage_id') for f in expected if f in by_rule]
  if set(g.get('expected_feature_ids',[]))!=set(expected) or set(g.get('ledger_feature_ids',[]))!=set(actual) or set(g.get('coverage_ids',[]))!=set(covids):issues.append(f'SUBPATH_FEATURE_MANIFEST_FALSE_ASSERTION:{sid}')
 im={r.get('source_rule_id'):r for r in arr(mf.get('insight_coverage'))}
 for ins in arr(L.get('cultivation_insights')):
  iid=ins.get('insight_id');c=by_rule.get(iid);m=im.get(iid)
  if not m or not c or m.get('coverage_id')!=c.get('coverage_id'):issues.append(f'INSIGHT_MANIFEST_MISMATCH:{iid}')
 cm={r.get('owner_id'):r for r in arr(mf.get('companion_coverage'))}
 for comp in arr(L.get('companions')):
  cid=comp.get('companion_id');m=cm.get(cid);expected=arr(comp.get('feature_ids_expected'));covids=[by_rule[f].get('coverage_id') for f in expected if f in by_rule]
  if not m or set(m.get('expected_feature_ids',[]))!=set(expected) or set(m.get('coverage_ids',[]))!=set(covids):issues.append(f'COMPANION_MANIFEST_MISMATCH:{cid}')
 # Structured Source CL and suppression must exist on every selected rule and exact export set must match.
 export=obj(L.get('source_cl_realm_suppression_export'))
 if export.get('schema_version')!=EXPORT_VERSION:issues.append('SOURCE_CL_EXPORT_VERSION_MISSING')
 exrows=arr(export.get('rule_exports')); exby={r.get('source_rule_id'):r for r in exrows}
 selected=old.collect_selected_rules(L)
 if set(exby)!=set(selected):issues.append(f'SOURCE_CL_EXPORT_SET_MISMATCH:missing={sorted(set(selected)-set(exby))}:extra={sorted(set(exby)-set(selected))}')
 for sid,sr in selected.items():
  c=by_rule.get(sid);e=exby.get(sid)
  if not c:continue
  scl=obj(c.get('source_cl'));rs=obj(c.get('realm_suppression'))
  for k in ('basis_code','expression','minimum_effective_cl','runtime_export_id'):
   if scl.get(k) in (None,''):issues.append(f'SOURCE_CL_STRUCTURED_FIELD_MISSING:{sid}:{k}')
  for k in ('behavior_code','minimum_effective_cl','identity_persists','active_effect_policy','text'):
   if rs.get(k) is None or rs.get(k)=='':issues.append(f'REALM_SUPPRESSION_STRUCTURED_FIELD_MISSING:{sid}:{k}')
  if c.get('source_rule_category')=='item':
   # An item may be acquired after its minimum operating Realm. Acquisition CL is provenance, not its Source CL floor.
   if scl.get('minimum_effective_cl')!=rs.get('minimum_effective_cl'):issues.append(f'ITEM_SOURCE_CL_SUPPRESSION_MINIMUM_MISMATCH:{sid}')
  else:
   if scl.get('minimum_effective_cl')!=int(sr.get('gained_at_cl') or 1):issues.append(f'SOURCE_CL_MINIMUM_CL_MISMATCH:{sid}')
   if rs.get('minimum_effective_cl')!=int(sr.get('gained_at_cl') or 1):issues.append(f'REALM_SUPPRESSION_MINIMUM_CL_MISMATCH:{sid}')
  if e:
   targets=sorted({t for m in arr(c.get('mappings')) for t in arr(m.get('target_ids'))})
   if e.get('source_cl')!=scl or e.get('realm_suppression')!=rs or sorted(e.get('runtime_target_ids',[]))!=targets:issues.append(f'SOURCE_CL_EXPORT_ROW_MISMATCH:{sid}')
 # Anti-shortcut: no aggregate canonical feature stand-ins; no mechanical feature may be permission-only.
 canonical=set()
 for _,_,xs in expected_path_groups+expected_sub_groups:canonical.update(xs)
 canonical.update(x.get('insight_id') for x in arr(L.get('cultivation_insights')))
 canonical.update(fid for c in arr(L.get('companions')) for fid in arr(c.get('feature_ids_expected')))
 for fid in canonical:
  c=by_rule.get(fid)
  if not c:continue
  modes={m.get('mode') for m in arr(c.get('mappings'))}
  if c.get('mechanical_effects_present') is True and modes=={'permission_or_record_only'}:issues.append(f'ANTI_SHORTCUT_MECHANIC_PERMISSION_ONLY:{fid}')
  if len(arr(c.get('mappings')))==1:
   m=arr(c.get('mappings'))[0]
   if len(arr(m.get('target_ids')))>12 and c.get('source_rule_category') in {'path_feature','subpath_feature','cultivation_insight','companion_feature'}:issues.append(f'ANTI_SHORTCUT_BULK_TARGET_DUMP:{fid}')
 # Every expected canonical feature must have a one-to-one feature row, not an aggregate row.
 for r in features:
  if r.get('category') in {'path_feature','subpath_feature','companion_feature'} and r.get('feature_id') not in canonical:issues.append(f'ANTI_SHORTCUT_NONCANONICAL_FEATURE_STANDIN:{r.get("feature_id")}')
 issues.extend(item_module().validate_ledger(L,phase))
 return sorted(set(issues))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--ledger',type=Path,required=True);ap.add_argument('--phase',choices=['planned','complete'],default='complete');ap.add_argument('--output',type=Path);a=ap.parse_args();L=load(a.ledger);issues=validate_ledger(L,a.phase);out={'schema':'HF05ZVK-R1F.FeatureCoverageValidation.P2D.v1','phase':a.phase,'pass':not issues,'issue_count':len(issues),'issues':issues}
 if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out,indent=2));return 0 if not issues else 1
if __name__=='__main__':raise SystemExit(main())
