#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
from jsonschema import Draft202012Validator


def sha(path:Path)->str:
    h=hashlib.sha256();
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--factory-root',type=Path,default=Path(__file__).resolve().parents[1]); ap.add_argument('--output',type=Path)
    a=ap.parse_args(); root=a.factory_root.resolve(); idxdir=root/'09_RULES/Indexes/Paths'; schema=load(root/'04_SCHEMAS/path_index.schema.json')
    files=sorted(idxdir.glob('*.path_index.p2a.json')); issues=[]; results=[]; allids=set()
    if len(files)!=3: issues.append(f'PATH_INDEX_FILE_COUNT:{len(files)}')
    for p in files:
        obj=load(p); errs=sorted(Draft202012Validator(schema).iter_errors(obj),key=lambda e:list(e.path))
        for e in errs: issues.append(f'SCHEMA:{p.name}:{"/".join(map(str,e.path))}:{e.message}')
        src=root/obj['source']['factory_path']
        if not src.is_file(): issues.append(f'SOURCE_MISSING:{p.name}:{src}')
        else:
            if sha(src)!=obj['source']['sha256']: issues.append(f'SOURCE_HASH:{p.name}')
            lines=src.read_text(encoding='utf-8').splitlines()
            if len(lines)!=obj['source']['line_count']: issues.append(f'SOURCE_LINE_COUNT:{p.name}')
        cls=[r.get('cl') for r in obj.get('progression',[])]
        if cls!=list(range(1,21)): issues.append(f'PROGRESSION:{p.name}:{cls}')
        feature_ids={f['canonical_id'] for f in obj.get('features',[])}
        if len(feature_ids)!=len(obj.get('features',[])): issues.append(f'DUP_FEATURE_ID:{p.name}')
        for fid in feature_ids:
            if fid in allids: issues.append(f'CROSS_PATH_DUP_FEATURE_ID:{fid}')
            allids.add(fid)
        for row in obj.get('progression',[]):
            for ref in row.get('features',[]):
                if ref['canonical_id'] not in feature_ids: issues.append(f'UNRESOLVED_FEATURE_REF:{p.name}:CL{row["cl"]}:{ref["canonical_id"]}')
        for f in obj.get('features',[]):
            if f['minimum_cl']!=min(f['granted_at_cl']): issues.append(f'MIN_CL:{f["canonical_id"]}')
            for sec in f['source_sections']:
                if sec['source_line_start']>sec['source_line_end']: issues.append(f'LINE_RANGE:{f["canonical_id"]}')
                if src.is_file():
                    actual='\n'.join(lines[sec['source_line_start']-1:sec['source_line_end']]).rstrip()+'\n'
                    if actual!=sec['source_markdown']: issues.append(f'SOURCE_EXCERPT_MISMATCH:{f["canonical_id"]}:{sec["source_heading"]}')
        rec=obj['resource_rules']
        for m in ('short_rest','long_rest','full_cultivation_session'):
            if not rec.get(m,{}).get('amount') or not rec.get(m,{}).get('limit'): issues.append(f'RECOVERY_INCOMPLETE:{p.name}:{m}')
        if not obj['source_cl_rules']['default_source_cl']: issues.append(f'SOURCE_CL_EMPTY:{p.name}')
        if not obj['realm_suppression']['source_section']['source_markdown']: issues.append(f'REALM_SUPPRESSION_EMPTY:{p.name}')
        results.append({'file':p.name,'path_id':obj.get('canonical_id'),'features':len(obj.get('features',[])),'components':sum(len(f.get('components',[])) for f in obj.get('features',[])),'schema_errors':len(errs)})
    master=load(idxdir/'Tianxia_Path_Index_Master_P2A.json')
    if master.get('canonical_path_count')!=3: issues.append('MASTER_PATH_COUNT')
    if master.get('canonical_feature_count')!=len(allids): issues.append('MASTER_FEATURE_COUNT')
    if set(master.get('feature_lookup',{}))!=allids: issues.append('MASTER_FEATURE_LOOKUP')
    report={'schema_version':'HF05ZVK-R1F.PathIndexValidation.P2A.v1','status':'PASS' if not issues else 'FAIL','issue_count':len(issues),'issues':issues,'results':results,'master_counts':{'paths':master.get('canonical_path_count'),'features':master.get('canonical_feature_count'),'components':master.get('canonical_component_count')}}
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2)); return 0 if not issues else 1
if __name__=='__main__': raise SystemExit(main())
