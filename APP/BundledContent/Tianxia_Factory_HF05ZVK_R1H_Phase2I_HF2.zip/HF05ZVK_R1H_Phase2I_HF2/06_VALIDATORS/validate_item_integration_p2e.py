#!/usr/bin/env python3
"""HF05ZVK-R1F Phase 2E Item Book R1 installation and character-ledger validator."""
from __future__ import annotations
import argparse, importlib.util, json
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
ITEMS=ROOT/'09_RULES'/'Items'
VERSION='Tianxia_ItemBook_R1.ItemSchemaR2.P2E.v1'
COVERAGE_VERSION='HF05ZVK-R1F.ItemExecutionCoverage.P2E.v1'

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def arr(v): return v if isinstance(v,list) else []
def obj(v): return v if isinstance(v,dict) else {}
def item_module():
 p=ROOT/'06_VALIDATORS'/'validate_item_schema_r2.py';spec=importlib.util.spec_from_file_location('item_r2',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def catalogs():
 return load(ITEMS/'ItemSchema_R2.json'),load(ITEMS/'ItemCatalog_R2.json'),load(ITEMS/'TreasureSetCatalog_R2.json'),load(ITEMS/'ItemGMProjection_R2.json')

def definition_for(instance,cmap): return instance.get('definition_snapshot') or cmap.get(instance.get('item_id'))
def mechanics(defn):
 out=[]
 keymap={'passive_properties':'passive_property','actions':'action','bonus_actions':'bonus_action','reactions':'reaction','procedures':'procedure','triggered_effects':'triggered_effect','object_interactions':'object_interaction'}
 for key,kind in keymap.items():
  for row in arr(obj(defn.get('mechanics')).get(key)): out.append((row.get('action_id'),kind,row))
 for row in arr(obj(defn.get('mechanics')).get('charge_pools')): out.append((row.get('pool_id'),'charge_pool',row))
 for row in arr(obj(defn.get('mechanics')).get('derived_modifiers')): out.append((row.get('modifier_id'),'derived_modifier',row))
 return [(a,b,c) for a,b,c in out if a]

def validate_ledger(L:dict[str,Any],phase='complete'):
 issues=[]; required=L.get('build_mode')=='production' or L.get('item_module_version') is not None
 if not required and not L.get('equipment_ledger_r2'): return issues
 if L.get('item_module_version')!=VERSION: issues.append('ITEM_MODULE_VERSION_MISSING')
 ledger=obj(L.get('equipment_ledger_r2')); cov=obj(L.get('item_execution_coverage'))
 if not ledger: issues.append('EQUIPMENT_LEDGER_R2_REQUIRED'); return sorted(set(issues))
 schema,cat,sets,proj=catalogs(); mod=item_module()
 # Direct action-economy rows may not carry a contradictory timing label.
 canonical_timing={'action':'Action','bonus_action':'Bonus Action','reaction':'Reaction'}
 for source_name,rows in [('catalog',arr(cat.get('items'))),('projection',arr(proj.get('items')))]:
  for item in rows:
   action_rows=[]
   if source_name=='catalog':
    mechanics_obj=obj(item.get('mechanics'))
    for key in ('actions','bonus_actions','reactions'):
     action_rows.extend(arr(mechanics_obj.get(key)))
   else:
    action_rows.extend(arr(item.get('action_rows'))); action_rows.extend(arr(item.get('reaction_rows')))
   for action in action_rows:
    typ=action.get('action_type') or action.get('bucket')
    timing=action.get('timing_text') or action.get('timing')
    if typ in canonical_timing and timing and timing!=canonical_timing[typ]:
     issues.append(f'ITEM_ACTION_TIMING_MISMATCH:{source_name}:{item.get("item_id")}:{action.get("action_id")}:{typ}:{timing}')
 # Schema and canonical semantic validation.
 for e in mod.verr(schema,ledger,'EquipmentLedger'):
  issues.append('ITEM_LEDGER_SCHEMA:'+('/'.join(map(str,e.path)) or 'root')+':'+e.message)
 sem,_=mod.semantic(cat,sets,proj,ledger); issues += ['ITEM_R2:'+x for x in sem]
 charid=obj(L.get('character')).get('character_id')
 if ledger.get('character_id')!=charid: issues.append(f'ITEM_CHARACTER_ID_MISMATCH:{ledger.get("character_id")}!={charid}')
 if ledger.get('catalog_version')!=cat.get('catalog_id'): issues.append('ITEM_CATALOG_VERSION_MISMATCH')
 if cov.get('schema_version')!=COVERAGE_VERSION: issues.append('ITEM_EXECUTION_COVERAGE_VERSION_MISSING')
 if cov.get('character_id')!=charid or cov.get('catalog_version')!=cat.get('catalog_id'): issues.append('ITEM_EXECUTION_COVERAGE_HEADER_MISMATCH')
 cmap={x['item_id']:x for x in cat['items']}; covrows={x.get('instance_id'):x for x in arr(cov.get('items')) if isinstance(x,dict)}
 universe={
  'action':{x.get('action_id') for x in arr(L.get('actions'))},
  'modifier':{x.get('modifier_id') for x in arr(L.get('modifiers'))},
  'state':{x.get('state_id') for x in arr(L.get('states'))},
  'resource':{x.get('resource_id') for x in arr(L.get('resources'))},
  'procedure':{x.get('procedure_id') for x in arr(L.get('procedures'))},
  'passive_statistic':{x.get('passive_statistic_id') for x in arr(L.get('passive_statistics'))},
  'permission_or_record_only':{x.get('permission_record_id') for x in arr(L.get('permission_records'))},
 }
 universal={x.get('source_rule_id'):x for x in arr(L.get('selected_rule_execution_coverage')) if isinstance(x,dict)}
 exports={x.get('source_rule_id'):x for x in arr(obj(L.get('source_cl_realm_suppression_export')).get('rule_exports')) if isinstance(x,dict)}
 for inst in arr(ledger.get('item_instances')):
  iid=inst.get('instance_id'); item_id=inst.get('item_id'); d=definition_for(inst,cmap)
  if not d: continue
  active=obj(inst.get('equipped_state')).get('active') is True
  expected=[mid for mid,_,_ in mechanics(d)] if active else []
  row=covrows.get(iid)
  if not row: issues.append(f'ITEM_COVERAGE_ROW_MISSING:{iid}'); continue
  if row.get('item_id')!=item_id or row.get('active')!=active: issues.append(f'ITEM_COVERAGE_IDENTITY_MISMATCH:{iid}')
  if not isinstance(row.get('gained_at_cl'),int): issues.append(f'ITEM_GAINED_AT_CL_REQUIRED:{iid}')
  if not isinstance(row.get('allocation_id'),str) or not row.get('allocation_id'): issues.append(f'ITEM_ALLOCATION_ID_REQUIRED:{iid}')
  if not arr(row.get('source_packet_ids')): issues.append(f'ITEM_SOURCE_PACKET_IDS_REQUIRED:{iid}')
  # Item acquisition is a permanent event-sourced grant, not an unattached equipment note.
  allocation_rows=[a for level in arr(obj(L.get('advancement')).get('levels')) for a in arr(obj(level).get('allocations'))]
  allocation=next((a for a in allocation_rows if a.get('allocation_id')==row.get('allocation_id')),None)
  item_name=obj(d).get('name')
  if not allocation: issues.append(f'ITEM_ALLOCATION_MISSING:{iid}')
  else:
   if allocation.get('channel')!='item' or allocation.get('grant_type')!='item' or allocation.get('grant_id')!=iid: issues.append(f'ITEM_ALLOCATION_IDENTITY_MISMATCH:{iid}')
   if allocation.get('name')!=item_name or allocation.get('slot_cost')!=0: issues.append(f'ITEM_ALLOCATION_CONTENT_MISMATCH:{iid}')
   if allocation.get('source_packet_ids')!=row.get('source_packet_ids'): issues.append(f'ITEM_ALLOCATION_SOURCE_MISMATCH:{iid}')
   level_cl=next((level.get('cl') for level in arr(obj(L.get('advancement')).get('levels')) if allocation in arr(obj(level).get('allocations'))),None)
   if level_cl!=row.get('gained_at_cl'): issues.append(f'ITEM_ALLOCATION_CL_MISMATCH:{iid}:{level_cl}!={row.get("gained_at_cl")}')
  if set(row.get('expected_catalog_mechanic_ids',[]))!=set(expected): issues.append(f'ITEM_EXPECTED_MECHANICS_MISMATCH:{iid}')
  mapped={m.get('catalog_mechanic_id'):m for m in arr(row.get('mechanic_mappings'))}
  if set(mapped)!=set(expected): issues.append(f'ITEM_MECHANIC_MAPPING_SET_MISMATCH:{iid}:missing={sorted(set(expected)-set(mapped))}:extra={sorted(set(mapped)-set(expected))}')
  for mid,kind,_ in mechanics(d):
   if mid not in expected: continue
   m=mapped.get(mid)
   if not m: continue
   mode=m.get('mode'); tids=arr(m.get('runtime_target_ids'))
   if m.get('mechanic_kind')!=kind: issues.append(f'ITEM_MECHANIC_KIND_MISMATCH:{iid}:{mid}')
   if mode not in universe: issues.append(f'ITEM_MODE_INVALID:{iid}:{mid}:{mode}'); continue
   unresolved=[x for x in tids if x not in universe[mode]]
   if unresolved: issues.append(f'ITEM_RUNTIME_TARGET_UNRESOLVED:{iid}:{mid}:{unresolved}')
  u=universal.get(item_id)
  if active and not u: issues.append(f'ITEM_UNIVERSAL_COVERAGE_MISSING:{iid}:{item_id}')
  elif u and u.get('source_rule_category')!='item': issues.append(f'ITEM_UNIVERSAL_CATEGORY_MISMATCH:{item_id}')
  if active and item_id not in exports: issues.append(f'ITEM_SOURCE_CL_EXPORT_MISSING:{item_id}')
  if row.get('coverage_id')!=(u or {}).get('coverage_id'): issues.append(f'ITEM_COVERAGE_LINK_MISMATCH:{iid}')
  if row.get('source_cl_export_id')!=obj((u or {}).get('source_cl')).get('runtime_export_id'): issues.append(f'ITEM_SOURCE_CL_LINK_MISMATCH:{iid}')
  # Anti-shortcuts: active actions/reactions must be executable records, not prose projections.
  for mid,kind,_ in mechanics(d):
   if mid not in expected: continue
   m=mapped.get(mid,{})
   if kind in {'action','bonus_action','reaction'} and m.get('mode')!='action': issues.append(f'ITEM_ACTION_NOT_EXECUTABLE:{iid}:{mid}')
   if kind=='procedure' and m.get('mode')!='procedure': issues.append(f'ITEM_PROCEDURE_NOT_EXECUTABLE:{iid}:{mid}')
  # Item Spirit independent turns require a linked companion profile.
  isp=obj(inst.get('item_spirit_state'))
  if isp.get('independent_turn') and not isp.get('companion_profile_ref'): issues.append(f'ITEM_SPIRIT_COMPANION_PROFILE_REQUIRED:{iid}')
 # Coverage cannot assert unknown instances.
 instids={x.get('instance_id') for x in arr(ledger.get('item_instances'))}
 extra=set(covrows)-instids
 if extra: issues.append(f'ITEM_COVERAGE_UNKNOWN_INSTANCES:{sorted(extra)}')
 # Manifest mirror.
 mf=obj(L.get('feature_coverage_manifest')); mirror={x.get('instance_id'):x for x in arr(mf.get('item_coverage')) if isinstance(x,dict)}
 if required and set(mirror)!=set(covrows): issues.append('ITEM_FEATURE_MANIFEST_SET_MISMATCH')
 for iid,row in covrows.items():
  if mirror.get(iid)!=row: issues.append(f'ITEM_FEATURE_MANIFEST_FALSE_ASSERTION:{iid}')
 return sorted(set(issues))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--ledger',type=Path,required=True);ap.add_argument('--phase',default='complete');ap.add_argument('--output',type=Path);a=ap.parse_args();L=load(a.ledger);issues=validate_ledger(L,a.phase);out={'schema':'HF05ZVK-R1F.ItemIntegrationValidation.P2E.v1','pass':not issues,'issue_count':len(issues),'issues':issues,'item_count':len(arr(obj(L.get('equipment_ledger_r2')).get('item_instances')))}
 if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out,indent=2));return 0 if not issues else 1
if __name__=='__main__':raise SystemExit(main())
