#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, importlib.util, json, subprocess, tempfile
from pathlib import Path


def load_compiler(path:Path):
    spec=importlib.util.spec_from_file_location("hf05zvk_compiler_negative",path)
    if not spec or not spec.loader: raise RuntimeError(f"COMPILER_IMPORT_FAILED:{path}")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def run_compile(C, ledger:dict, verified_packets:dict)->dict:
    try:
        C.validate_ledger(ledger, verified_packets)
        return {"verdict":"PASS_HF05ZVK_R1F_COMPILE"}
    except C.BuildError as exc:
        return {"verdict":"FAIL_HF05ZVK_R1F_COMPILE","blocker":str(exc)}


def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--factory-root',type=Path,required=True)
    ap.add_argument('--fixture',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args(); compiler=a.factory_root/'05_COMPILER'/'compile_character.py'; C=load_compiler(compiler)
    needed=a.factory_root/'09_RULES'/'Tianxia_Canonical_Rules_Corpus_P2A.zip'; packets=a.fixture/'Command_2'/'Rules_Selection_Packets.json'; registry=json.loads(packets.read_text()); verified_packets=C.verify_packets(registry,needed); good=json.loads((a.fixture/'Character_Master_Ledger.json').read_text())
    cases=[]

    def rehash(ledger):
        levels=ledger['advancement']['levels']
        for idx,row in enumerate(levels,1): row['state_after_hash']=C.checkpoint_hash(levels,idx)

    def add(name,expected,mutator):
        ledger=copy.deepcopy(good); mutator(ledger); result=run_compile(C,ledger,verified_packets); blocker=result.get('blocker','')
        passed=result.get('verdict')=='FAIL_HF05ZVK_R1F_COMPILE' and expected in blocker
        cases.append({'name':name,'expected_blocker':expected,'actual_verdict':result.get('verdict'),'actual_blocker':blocker,'passed':passed})

    def add_pass(name,mutator):
        ledger=copy.deepcopy(good); mutator(ledger); result=run_compile(C,ledger,verified_packets); blocker=result.get('blocker','')
        passed=result.get('verdict')=='PASS_HF05ZVK_R1F_COMPILE'
        cases.append({'name':name,'expected_verdict':'PASS_HF05ZVK_R1F_COMPILE','actual_verdict':result.get('verdict'),'actual_blocker':blocker,'passed':passed})

    add('level_gap','LEVEL_ROWS_MUST_COVER_CL1_TO_CURRENT',lambda x:x['advancement']['levels'].pop(5))
    add('foundation_depth','FOUNDATION_BENEFITS_INCOMPLETE',lambda x:x['foundation'].__setitem__('benefits',x['foundation']['benefits'][:2]))
    add('unresolved_composite','COMPOSITE_UNRESOLVED_ACTION',lambda x:x['composites'][0]['sequence'][0].__setitem__('action_id','ACT_MISSING'))
    add('missing_action_packet','SOURCE_PACKET_REF_REQUIRED',lambda x:x['actions'][0].__setitem__('source_packet_ids',[]))

    def over_pb(x):
        base=copy.deepcopy(x['forged_techniques'][0]); x['forged_techniques']=[dict(copy.deepcopy(base),forged_id=f'FGT_OVER_{i}',allocation_id=f'AL_OVER_{i}') for i in range(6)]
    add('forged_pb_limit','FORGED_TECHNIQUE_PB_LIMIT_EXCEEDED',over_pb)

    def no_none(x): x.__setitem__('forged_techniques',[]); x.__setitem__('forged_techniques_none_state',None)
    add('forged_empty_without_state','FORGED_EMPTY_REQUIRES_NONE_STATE',no_none)
    add('placeholder_rejection','BANNED_PLACEHOLDER',lambda x:x['method'].__setitem__('benefits',['TBD']))

    def unresolved_allocation(x):
        a=x['advancement']['levels'][0]['allocations'][0]; a['grant_id']='BG_DOES_NOT_EXIST'; rehash(x)
    add('allocation_grant_unresolved','ALLOCATION_GRANT_UNRESOLVED',unresolved_allocation)

    def unallocated_character_grant(x):
        row=x['advancement']['levels'][3]
        row['allocations']=[a for a in row['allocations'] if a['allocation_id']!='AL_CL04_TRAINED_EDGE']; rehash(x)
    add('unallocated_character_grant','UNALLOCATED_CHARACTER_GRANTS',unallocated_character_grant)

    def missing_free_level(x):
        a=next(a for a in x['advancement']['levels'][3]['allocations'] if a['channel']=='free_level')
        a['channel']='trained_choice'; a['slot_cost']=1
        t=next(t for t in x['talents'] if t['talent_id']==a['grant_id']); t['acquisition_type']='trained_choice'
        rehash(x)
    add('missing_free_level_talent','FREE_LEVEL_TALENT_COUNT_INVALID',missing_free_level)

    def missing_new_sphere_bonus(x):
        a=next(a for a in x['advancement']['levels'][1]['allocations'] if a['channel']=='new_sphere_bonus')
        a['channel']='trained_choice'; a['slot_cost']=1
        t=next(t for t in x['talents'] if t['talent_id']==a['grant_id']); t['acquisition_type']='trained_choice'
        rehash(x)
    add('missing_new_sphere_bonus','NEW_SPHERE_BONUS_TALENT_COUNT_INVALID',missing_new_sphere_bonus)

    def bad_authority(x): x.__setitem__('build_mode','production')
    add('production_original_design_rejected','CANONICAL_RULE_AUTHORITY_REQUIRED',bad_authority)

    add('checkpoint_tamper','STATE_CHECKPOINT_HASH_MISMATCH',lambda x:x['advancement']['levels'][5].__setitem__('state_after_hash','0'*64))
    add('resource_math','LEVEL_RESOURCE_MATH_MISMATCH',lambda x:x['advancement']['levels'][6]['resource'].__setitem__('max_after_level',999))
    add('point_buy_math','POINT_BUY_TOTAL_MISMATCH',lambda x:x['core_stats']['ability_generation'].__setitem__('points_spent',26))
    add('hp_math','LEVEL_HP_MATH_MISMATCH',lambda x:x['advancement']['levels'][4]['hp'].__setitem__('max_after_level',999))
    add('path_feature_schedule','PATH_FEATURE_SET_MISMATCH',lambda x:x['character'].__setitem__('path_feature_ids_expected',x['character']['path_feature_ids_expected'][:-1]))

    def overbook_composite(x): x['composites'][0]['sequence'][1]['round_offset']=0
    add('composite_action_economy','COMPOSITE_ACTION_ECONOMY_OVERBOOKED',overbook_composite)

    def missing_state_setup(x):
        x['composites'][0]['sequence'][0]['requires_states']=['STATE_SEARED_LINE']
        x['composites'][0]['sequence'][0]['external_preconditions']=[]
    add('composite_state_not_established','COMPOSITE_STATE_NOT_ESTABLISHED',missing_state_setup)

    add('forged_cp_reconciliation','FORGED_CP_RECONCILIATION_FAILED',lambda x:x['forged_techniques'][0].__setitem__('final_cp_cost',99))
    def bad_forged_complexity(x):
        x['forged_techniques'][0]['final_complexity']=6
        x['forged_techniques'][0]['forging_dc']=19
        x['forged_techniques'][0]['forging_record']['check_dc']=19
    add('forged_complexity_reconciliation','FORGED_COMPLEXITY_RECONCILIATION_FAILED',bad_forged_complexity)

    add('skill_reconciliation','SKILL_RECONCILIATION_FAILED',lambda x:x['core_stats']['skills'].__setitem__('Arcana',99))
    add('ac_reconciliation','AC_RECONCILIATION_FAILED',lambda x:x['core_stats'].__setitem__('ac_active',99))
    add('speed_reconciliation','SPEED_RECONCILIATION_FAILED',lambda x:x['core_stats'].__setitem__('speed_ft',99))
    add('initiative_reconciliation','INITIATIVE_RECONCILIATION_FAILED',lambda x:x['core_stats'].__setitem__('initiative_bonus',99))
    add('resource_source_unresolved','RESOURCE_SOURCE_GRANT_UNRESOLVED',lambda x:x['resources'][1].__setitem__('source_grant_ids',['MTH_MISSING']))
    add('action_resource_cost_unknown','ACTION_RESOURCE_COST_UNKNOWN',lambda x:x['actions'][0]['resource_costs'][0].__setitem__('resource_id','RES_MISSING'))
    add('manual_execution_action_mismatch','MANUAL_EXECUTION_ACTION_MISMATCH',lambda x:next(a for a in x['actions'] if a['action_id']==x['recorded_arts'][0]['linked_action_id']).__setitem__('effect','Mismatched action effect.'))
    add('forged_action_cp_cost_mismatch','ACTION_COST_DISPLAY_MISMATCH',lambda x:next(a for a in x['actions'] if a.get('forged_id')==x['forged_techniques'][0]['forged_id'])['resource_costs'][0].__setitem__('amount',3))
    add('preserved_forged_slot_flag','PRESERVED_FORGED_PERSONAL_SLOT_FLAG_INVALID',lambda x:x['recorded_arts'][0]['preserved_forged_expression'].__setitem__('counts_against_personal_forged_limit',True))
    add('preserved_forged_execution_mismatch','PRESERVED_FORGED_MANUAL_EXECUTION_MISMATCH',lambda x:x['recorded_arts'][0]['preserved_forged_expression']['execution'].__setitem__('effect','Mismatched preserved expression.'))

    def cl1_wrong_sphere(x):
        next(t for t in x['talents'] if t['talent_id']=='TAL_BANKED_EMBER')['sphere']='Scholarship'
    add('cl1_level_talent_wrong_sphere','CL1_LEVEL_TALENT_NOT_FROM_LEVEL_1_SPHERE',cl1_wrong_sphere)

    def missing_new_sphere_training(x):
        a=next(a for a in x['advancement']['levels'][1]['allocations'] if a['channel']=='new_sphere'); a.pop('training_record',None); rehash(x)
    add('new_sphere_training_missing','OBJECT_REQUIRED:allocation.AL_CL02_NEW_SWORD.training_record',missing_new_sphere_training)

    def bad_new_sphere_dc(x):
        a=next(a for a in x['advancement']['levels'][1]['allocations'] if a['channel']=='new_sphere'); a['training_record']['dc_total']+=1; a['training_record']['check_total']+=1; rehash(x)
    add('new_sphere_training_dc','TRAINING_DC_MISMATCH:allocation.AL_CL02_NEW_SWORD.training_record',bad_new_sphere_dc)

    def bad_new_sphere_time(x):
        a=next(a for a in x['advancement']['levels'][1]['allocations'] if a['channel']=='new_sphere'); a['training_record']['training_days']+=1; rehash(x)
    add('new_sphere_training_time','TRAINING_TIME_MISMATCH:allocation.AL_CL02_NEW_SWORD.training_record',bad_new_sphere_time)

    def missing_known_talent_training(x):
        a=next(a for a in x['advancement']['levels'][3]['allocations'] if a['channel']=='trained_choice'); a.pop('training_record',None); rehash(x)
    add('known_talent_training_missing','OBJECT_REQUIRED:allocation.AL_CL04_TRAINED_EDGE.training_record',missing_known_talent_training)

    def bad_known_talent_prior_count(x):
        a=next(a for a in x['advancement']['levels'][3]['allocations'] if a['channel']=='trained_choice'); a['training_record']['prior_talents_known_in_sphere']+=1; rehash(x)
    add('known_talent_prior_count','KNOWN_SPHERE_TALENT_PRIOR_COUNT_MISMATCH',bad_known_talent_prior_count)

    def missing_manual_training(x):
        a=next(a for a in x['advancement']['levels'][6]['allocations'] if a['channel']=='manual'); a.pop('training_record',None); rehash(x)
    add('recorded_art_training_missing','OBJECT_REQUIRED:allocation.AL_CL07_MANUAL.training_record',missing_manual_training)

    def bad_manual_training_dc(x):
        a=next(a for a in x['advancement']['levels'][6]['allocations'] if a['channel']=='manual'); a['training_record']['dc_total']+=1; a['training_record']['check_total']+=1; rehash(x)
    add('recorded_art_training_dc','TRAINING_DC_MISMATCH:allocation.AL_CL07_MANUAL.training_record',bad_manual_training_dc)

    def primary_resource_foundation_missing_source(x):
        row=x['advancement']['levels'][-1]['resource']
        row['foundation_delta']=1
        row['max_after_level']+=1
        row.pop('foundation_source_grant_id',None)
        x['core_stats']['primary_resource_max']+=1
        x['core_stats']['primary_resource_current']+=1
        rehash(x)
    add('primary_resource_foundation_missing_source','PRIMARY_RESOURCE_FOUNDATION_SOURCE_MISMATCH',primary_resource_foundation_missing_source)

    add('quality_action_floor_cannot_be_lowered','QUALITY_TARGET_BELOW_FACTORY_FLOOR:meaningful_actions',lambda x:x['quality_targets'].__setitem__('minimum_meaningful_actions',7))
    add('quality_composite_floor_cannot_be_lowered','QUALITY_TARGET_BELOW_FACTORY_FLOOR:composites',lambda x:x['quality_targets'].__setitem__('minimum_composites',2))
    add('quality_recorded_art_floor_cannot_be_lowered','QUALITY_TARGET_BELOW_FACTORY_FLOOR:recorded_arts',lambda x:x['quality_targets'].__setitem__('minimum_recorded_arts',0))

    def missing_foundation(x):
        x['foundation']={'status':'none_acquired','reason':'No Foundation selected.'}
    add('cl5_plus_foundation_required','FOUNDATION_REQUIRED_FOR_COMPLETE_CL5_PLUS_BUILD',missing_foundation)

    def missing_recorded_art(x):
        x['recorded_arts']=[]; x['recorded_arts_none_state']={'none':True,'reason':'No Recorded Art.'}
    add('cl5_plus_recorded_art_required','RECORDED_ART_MINIMUM_NOT_MET',missing_recorded_art)

    def manual_slot_is_trained_choice(x):
        a=next(a for a in x['advancement']['levels'][6]['allocations'] if a['channel']=='manual'); a['slot_cost']=0; rehash(x)
    add('recorded_art_consumes_trained_choice','TRAINED_ALLOCATION_SLOT_COST_INVALID',manual_slot_is_trained_choice)

    def free_bonus_must_not_cost_slot(x):
        a=next(a for a in x['advancement']['levels'][1]['allocations'] if a['channel']=='new_sphere_bonus'); a['slot_cost']=1; rehash(x)
    add('new_sphere_bonus_is_free','FREE_ALLOCATION_SLOT_COST_INVALID',free_bonus_must_not_cost_slot)

    def training_check_must_succeed(x):
        a=next(a for a in x['advancement']['levels'][3]['allocations'] if a['channel']=='trained_choice'); a['training_record']['check_total']=0; rehash(x)
    add('training_check_failure_rejected','TRAINING_CHECK_NOT_SUCCESSFUL',training_check_must_succeed)

    def missing_training_sources(x):
        x['training_sources']=[]
    add('complete_character_requires_training_source','MANUAL_LINEAGE_SOURCE_REQUIRED_FOR_COMPLETE_CHARACTER',missing_training_sources)

    def manual_bad_training_source(x):
        x['recorded_arts'][0]['training_source_id']='SRC_MISSING'
    add('recorded_art_training_source_unresolved','MANUAL_TRAINING_SOURCE_UNRESOLVED',manual_bad_training_source)

    def source_does_not_list_art(x):
        x['training_sources'][0]['contents']['recorded_arts']=[]
    add('recorded_art_not_listed_in_source','MANUAL_NOT_LISTED_IN_TRAINING_SOURCE',source_does_not_list_art)

    def skill_source_packet_missing(x):
        x['core_stats']['skill_source_packet_ids']['Arcana']=[]
    add('skill_provenance_required','SKILL_SOURCE_PACKET_REQUIRED:Arcana',skill_source_packet_missing)

    def action_cost_display_drift(x):
        x['actions'][0]['cost']='9 Qi'
    add('action_cost_display_parity','ACTION_COST_DISPLAY_MISMATCH',action_cost_display_drift)

    def action_save_dc_drift(x):
        next(a for a in x['actions'] if 'save DC' in a['roll_save_check'])['roll_save_check']='Dexterity save DC 99'
    add('action_save_dc_display_parity','ACTION_SAVE_DC_DISPLAY_MISMATCH',action_save_dc_drift)

    def action_attack_drift(x):
        next(a for a in x['actions'] if 'Technique attack +' in a['roll_save_check'])['roll_save_check']='Technique attack +99 vs AC'
    add('action_attack_display_parity','ACTION_ATTACK_DISPLAY_MISMATCH',action_attack_drift)

    add('forged_base_cp_exact','FORGED_BASE_CP_MISMATCH',lambda x:x['forged_techniques'][0].__setitem__('base_cp_cost',2))
    add('forged_secondary_complexity_exact','FORGED_SECONDARY_COMPLEXITY_MISMATCH',lambda x:x['forged_techniques'][0].__setitem__('secondary_sphere_complexity_adjustment',1))
    add('forged_drawback_reduction_exact','FORGED_DRAWBACK_REDUCTION_MISMATCH',lambda x:x['forged_techniques'][0]['drawbacks'][0].__setitem__('cp_reduction',2))
    add('forged_learning_level_not_future','FORGED_CL_ILLEGAL',lambda x:x['forged_techniques'][0].__setitem__('cl_learned',14))
    add('forged_final_check_success_required','FORGED_FINAL_CHECK_NOT_SUCCESSFUL',lambda x:x['forged_techniques'][0]['forging_record'].__setitem__('check_total',1))

    def early_foundation_no_exception(x):
        x['foundation']['gained_at_cl']=4
    add('foundation_before_cl5_requires_source','FOUNDATION_BEFORE_CL5_REQUIRES_EXPLICIT_SOURCE',early_foundation_no_exception)

    def unsourced_save_adjustment(x):
        x['core_stats']['saving_throw_adjustments']['WIS']=1; x['core_stats']['saving_throws']['WIS']+=1
    add('save_adjustment_requires_source','SAVE_ADJUSTMENT_SOURCE_REQUIRED:WIS',unsourced_save_adjustment)

    def unsourced_technique_adjustment(x):
        x['core_stats']['technique_attack_adjustment']=1; x['core_stats']['technique_attack_bonus']+=1
        for a in x['actions']:
            if 'Technique attack +8' in a.get('roll_save_check',''): a['roll_save_check']=a['roll_save_check'].replace('+8','+9')
    add('technique_scalar_requires_source','TECHNIQUE_SCALAR_SOURCE_REQUIRED:technique_attack_adjustment',unsourced_technique_adjustment)

    def invalid_overlap_event(x):
        # Convert the fixture into a valid same-Sphere CL1 overlap except for the
        # deliberately wrong background-allocation link.
        bg=x['background_origin']['background']; bg['background_sphere']='Fire'; bg['background_talent']='Banked Ember'
        x['spheres']=[row for row in x['spheres'] if row['sphere_id']!='SPH_SCHOLARSHIP']
        fire=next(row for row in x['spheres'] if row['sphere_id']=='SPH_FIRE'); fire['allocation_id']='AL_CL01_BG_SPHERE'; fire['acquisition_type']='background_sphere'
        bank=next(row for row in x['talents'] if row['talent_id']=='TAL_BANKED_EMBER'); bank['allocation_id']='AL_CL01_BG_TALENT'; bank['acquisition_type']='background_talent'
        recall=next(row for row in x['talents'] if row['talent_id']=='TAL_ARCHIVE_RECALL'); recall['sphere']='Fire'; recall['allocation_id']='AL_CL01_FREE_TALENT'; recall['acquisition_type']='free_level'
        row=x['advancement']['levels'][0]
        bgs=next(a for a in row['allocations'] if a['channel']=='background_sphere'); bgs.update({'grant_id':'SPH_FIRE','name':'Fire','source_packet_ids':['PKT_SPHERE_FIRE']})
        bgt=next(a for a in row['allocations'] if a['channel']=='background_talent'); bgt.update({'grant_id':'TAL_BANKED_EMBER','name':'Banked Ember','source_packet_ids':['PKT_TALENT_CATALOG']})
        free=next(a for a in row['allocations'] if a['channel']=='free_level'); free.update({'grant_id':'TAL_ARCHIVE_RECALL','name':'Archive Recall','source_packet_ids':['PKT_TALENT_CATALOG']})
        entry=next(a for a in row['allocations'] if a['channel']=='level_1_sphere')
        entry.update({'grant_type':'event','grant_id':'EV_CL1_OVERLAP','name':'Fire CL1 overlap contribution','overlap_sphere_id':'SPH_FIRE','overlap_background_sphere_allocation_id':'AL_WRONG','contribution_talent_id':'TAL_ARCHIVE_RECALL','overlap_note':'Separate CL1 overlap contribution.','source_packet_ids':['PKT_SPHERE_FIRE']})
        for later in x['advancement']['levels'][1:]:
            for sphere_alloc in [a for a in later['allocations'] if a['channel']=='new_sphere']:
                sphere_alloc['training_record']['prior_different_spheres_known']-=1
                sphere_alloc['training_record']['dc_total']-=1
        rehash(x)

    def valid_method_foundation_stack(x):
        method_id=x['method']['method_id']; foundation_id=x['foundation']['foundation_id']
        for row in x['advancement']['levels']:
            rcl=row.get('cl',row.get('CL')); resource=row['resource']
            resource['method_delta']=2; resource['method_source_grant_id']=method_id
            resource['foundation_delta']=1 if rcl>=5 else 0
            if rcl>=5: resource['foundation_source_grant_id']=foundation_id
            else: resource.pop('foundation_source_grant_id',None)
            resource['max_after_level']=resource['base_after_level']+resource['method_delta']+resource['foundation_delta']+resource['item_delta']
        final_max=x['advancement']['levels'][-1]['resource']['max_after_level']
        x['core_stats']['primary_resource_max']=final_max; x['core_stats']['primary_resource_current']=final_max
        primary=next(r for r in x['resources'] if r['resource_id']=='RES_QI')
        primary['max']=final_max; primary['current']=final_max
        primary['source_grant_ids']=list(dict.fromkeys(primary['source_grant_ids']+[method_id,foundation_id]))
        x['method']['resource_modifiers']=[{'resource_name':'Qi','amount':2,'operation':'add','source_packet_ids':['PKT_METHOD'],'note':'Printed Method modifier.'}]
        x['foundation']['primary_resource_modifiers']=[{'resource_name':'Qi','amount':1,'operation':'add','applies_from_cl':5,'source_packet_ids':['PKT_FOUNDATION'],'note':'Printed Foundation modifier.'}]
        rehash(x)
    add_pass('method_and_foundation_resource_modifiers_stack',valid_method_foundation_stack)


    def missing_universal_coverage(x): x['selected_rule_execution_coverage']=x['selected_rule_execution_coverage'][1:]
    add('universal_execution_coverage_complete','UNIVERSAL_COVERAGE_MISSING',missing_universal_coverage)

    def unresolved_universal_target(x):
        row=x['selected_rule_execution_coverage'][0];row['mappings'][0]['target_ids']=['MISSING_RUNTIME_TARGET']
        ex=next(e for e in x['source_cl_realm_suppression_export']['rule_exports'] if e['source_rule_id']==row['source_rule_id']);ex['runtime_target_ids']=['MISSING_RUNTIME_TARGET']
    add('universal_execution_target_resolves','UNIVERSAL_COVERAGE_TARGET_UNRESOLVED',unresolved_universal_target)

    def missing_universal_provenance(x):
        row=x['selected_rule_execution_coverage'][0];m=row['mappings'][0];tid=m['target_ids'][0];mode=m['mode']
        key={'action':'actions','modifier':'modifiers','state':'states','resource':'resources','procedure':'procedures','passive_statistic':'passive_statistics','permission_or_record_only':'permission_records'}[mode]
        idf={'action':'action_id','modifier':'modifier_id','state':'state_id','resource':'resource_id','procedure':'procedure_id','passive_statistic':'passive_statistic_id','permission_or_record_only':'permission_record_id'}[mode]
        target=next(z for z in x[key] if z.get(idf)==tid);target['source_rule_ids']=[];target['source_grant_ids']=[]
    add('universal_execution_provenance','UNIVERSAL_COVERAGE_PROVENANCE_MISSING',missing_universal_provenance)

    def prose_only_mechanic(x):
        row=next(r for r in x['selected_rule_execution_coverage'] if r.get('mechanical_effects_present'))
        pid='PERM_BAD_RECORD_ONLY';x['permission_records'].append({'permission_record_id':pid,'name':'Bad prose-only record','record_type':'record_only','scope':'test','rule_text':'Mechanic left only in prose.','restrictions':[],'source_rule_ids':[row['source_rule_id']],'source_packet_ids':row['source_packet_ids'],'display_surfaces':['Test']})
        row['mappings']=[{'effect_component_id':'CMP_BAD','mode':'permission_or_record_only','effect_summary':'Mechanic left in prose.','target_ids':[pid],'display_surfaces':['Test'],'required_at_runtime':True}]
        ex=next(e for e in x['source_cl_realm_suppression_export']['rule_exports'] if e['source_rule_id']==row['source_rule_id']);ex['runtime_target_ids']=[pid]
    add('mechanic_not_reduced_to_record_only','UNIVERSAL_COVERAGE_MECHANIC_REDUCED_TO_RECORD_ONLY',prose_only_mechanic)



    def foundation_lifecycle_category_missing(x): x['foundation']['lifecycle_coverage'].pop('hidden_injuries')
    add('foundation_lifecycle_full_mapping','OBJECT_REQUIRED:foundation.lifecycle_coverage.hidden_injuries',foundation_lifecycle_category_missing)

    def origin_claim_not_exact(x): x['background_origin']['origin_insight']['effect_records'][0]['source_claim_text']='Invented benefit not present in the source packet.'
    add('origin_effect_claim_source_fidelity','ORIGIN_EFFECT_CLAIM_NOT_EXACT_SOURCE_TEXT',origin_claim_not_exact)

    def below_recorded_art_depth(x): x['recorded_arts']=x['recorded_arts'][:3]
    add('recorded_art_depth_floor','RECORDED_ART_MINIMUM_NOT_MET',below_recorded_art_depth)

    def add_valid_immortal_art(x):
        base_action=copy.deepcopy(next(a for a in x['actions'] if a['action_id']=='ACT_MEASURED_CUT'))
        base_action.update({'action_id':'ACT_IA_TEST_HEAVEN_EDGE','name':'Heaven-Edge Declaration','classification':'immortal_art','immortal_art_id':'IA_TEST_HEAVEN_EDGE'})
        base_action.setdefault('source_rule_ids',[]).append('IA_TEST_HEAVEN_EDGE')
        x['actions'].append(base_action)
        art={
            'immortal_art_id':'IA_TEST_HEAVEN_EDGE',
            'name':'Heaven-Edge Declaration',
            'dao_aspect':'A single disciplined stroke divides the immediate battlefield.',
            'status':'learned',
            'gained_at_cl':13,
            'allocation_id':'AL_CL13_IMMORTAL_ART_TEST',
            'source_packet_ids':['PKT_TALENT_CATALOG'],
            'action_ids':['ACT_IA_TEST_HEAVEN_EDGE'],
            'limitations':['Acceptance-fixture Immortal Art; may only use its linked action and does not alter its printed mechanics.'],
            'evolution_state':'initial',
            'acquisition_record':'Acceptance-fixture grant used to prove event-sourced Immortal Art reconciliation.',
            'behavior_hooks':['Use only when the linked action is legal.'],
            'execution_summary':'Uses ACT_IA_TEST_HEAVEN_EDGE exactly as written.'
        }
        x['immortal_arts']=[art]; x['immortal_arts_none_state']=None
        x['selected_rule_execution_coverage'].append({
            'coverage_id':'COV_IA_TEST_HEAVEN_EDGE','source_rule_id':'IA_TEST_HEAVEN_EDGE','source_rule_name':'Heaven-Edge Declaration','source_rule_category':'immortal_art','gained_at_cl':13,
            'coverage_status':'complete','mechanical_effects_present':True,'source_cl_basis':'Current Effective CL of the granting Path unless the source rule prints another basis.',
            'realm_suppression_behavior':'Unavailable when the Immortal Art is suppressed.',
            'source_cl':{'basis_code':'current_effective_owning_path_cl','expression':'Current Effective CL of the granting Path unless the Source Rule expressly states another basis.','owning_path_id':'tianxia.path.qi_cultivation','fixed_cl':None,'minimum_effective_cl':13,'runtime_export_id':'SCL_IA_TEST_HEAVEN_EDGE'},
            'realm_suppression':{'behavior_code':'unavailable_above_effective_cl','minimum_effective_cl':13,'identity_persists':True,'active_effect_policy':'suppressed','text':'The learned Immortal Art remains recorded, but its active mechanics are unavailable below CL13.'},
            'mappings':[{'effect_component_id':'CMP_IA_TEST_HEAVEN_EDGE_ACTION','mode':'action','effect_summary':'Immortal Art executable expression.','target_ids':['ACT_IA_TEST_HEAVEN_EDGE'],'display_surfaces':['Immortal Arts','Actions'],'required_at_runtime':True}],
            'display_surfaces':['Immortal Arts','Actions'],'source_packet_ids':['PKT_TALENT_CATALOG'],'source_claim_text':'Heaven-Edge Declaration uses its linked action exactly as written.',
            'coverage_note':'Acceptance-fixture universal coverage.','unmapped_effects':[],'assertions':{'all_rule_components_mapped':True,'no_prose_only_mechanics':True,'reviewed_against_source':True}
        })
        x['source_cl_realm_suppression_export']['rule_exports'].append({'export_id':'SCL_IA_TEST_HEAVEN_EDGE','source_rule_id':'IA_TEST_HEAVEN_EDGE','source_rule_name':'Heaven-Edge Declaration','source_rule_category':'immortal_art','source_cl':{'basis_code':'current_effective_owning_path_cl','expression':'Current Effective CL of the granting Path unless the Source Rule expressly states another basis.','owning_path_id':'tianxia.path.qi_cultivation','fixed_cl':None,'minimum_effective_cl':13,'runtime_export_id':'SCL_IA_TEST_HEAVEN_EDGE'},'realm_suppression':{'behavior_code':'unavailable_above_effective_cl','minimum_effective_cl':13,'identity_persists':True,'active_effect_policy':'suppressed','text':'The learned Immortal Art remains recorded, but its active mechanics are unavailable below CL13.'},'runtime_target_ids':['ACT_IA_TEST_HEAVEN_EDGE']})
        x['advancement']['levels'][-1]['allocations'].append({
            'allocation_id':'AL_CL13_IMMORTAL_ART_TEST','channel':'immortal_art','grant_type':'immortal_art',
            'grant_id':'IA_TEST_HEAVEN_EDGE','name':'Heaven-Edge Declaration','slot_cost':0,
            'source_packet_ids':['PKT_TALENT_CATALOG']
        })
        rehash(x)
    add_pass('immortal_art_event_sourced_reconciliation',add_valid_immortal_art)

    def immortal_art_unresolved_action(x):
        add_valid_immortal_art(x); x['immortal_arts'][0]['action_ids']=['ACT_DOES_NOT_EXIST']
    add('immortal_art_action_must_resolve','IMMORTAL_ART_ACTION_UNRESOLVED',immortal_art_unresolved_action)

    def immortal_none_state_missing(x): x['immortal_arts']=[]; x['immortal_arts_none_state']=None
    add('immortal_art_tab_explicit_none_state','IMMORTAL_ART_EMPTY_REQUIRES_NONE_STATE',immortal_none_state_missing)

    def custom_multisphere_recorded_art(x):
        art=next(a for a in x['recorded_arts'] if not a.get('preserved_forged_expression'))
        art['expression_kind']='single_sphere_expression'
        art['source_spheres']=['Fire','Sword']
    add('custom_multisphere_recorded_art_requires_forged_record','RECORDED_ART_SINGLE_SPHERE_REQUIRED',custom_multisphere_recorded_art)

    def immortal_wrong_classification(x):
        add_valid_immortal_art(x)
        next(a for a in x['actions'] if a['action_id']=='ACT_IA_TEST_HEAVEN_EDGE')['classification']='recorded_art'
    add('immortal_action_classification','IMMORTAL_ART_ACTION_CLASSIFICATION_INVALID',immortal_wrong_classification)

    def immortal_missing_parent_link(x):
        add_valid_immortal_art(x)
        next(a for a in x['actions'] if a['action_id']=='ACT_IA_TEST_HEAVEN_EDGE').pop('immortal_art_id',None)
    add('immortal_action_parent_link','IMMORTAL_ART_ACTION_PARENT_LINK_MISMATCH',immortal_missing_parent_link)

    def unapproved_blueprint_deviation(x):
        x['blueprint_deviations']=[{'field':'method.name','blueprint_value':'Quiet Furnace Method','final_value':'Other Method','reason':'Test','approved':False}]
    # Full ledger compilation rejects an unapproved deviation even before the phase-level blueprint comparison.
    add('blueprint_deviation_must_be_approved','BLUEPRINT_DEVIATION_NOT_APPROVED',unapproved_blueprint_deviation)

    passed=all(c['passed'] for c in cases)
    report={'verdict':'PASS_HF05ZVK_R1F_NEGATIVE_GATE_SUITE' if passed else 'FAIL_HF05ZVK_R1F_NEGATIVE_GATE_SUITE','case_count':len(cases),'passed_count':sum(c['passed'] for c in cases),'cases':cases}
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8'); print(json.dumps(report,indent=2)); return 0 if passed else 2
if __name__=='__main__': raise SystemExit(main())
