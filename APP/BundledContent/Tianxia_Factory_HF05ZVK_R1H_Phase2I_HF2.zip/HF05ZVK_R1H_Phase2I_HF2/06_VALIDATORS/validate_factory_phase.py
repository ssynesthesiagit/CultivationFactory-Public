#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re, sys
from pathlib import Path

REQUIRED_TABS=["overview-core-stats","leveling-ledger","background-origin","paths-subpaths","spheres-talents","insights","actions","composite-playbooks","forged-techniques","martial-manuals-recorded-arts","immortal-arts","foundation","method","companions-spirits","equipment","resources-states-suppression","dao-i-ching","diagnostics"]
BANNED=("TBD","TODO","unknown","Not recorded","not itemized","[object Object]")
CURRENT_GM_SCREEN_PATCH="HF05ZUI-R2K.3"


def load(p:Path): return json.loads(p.read_text(encoding="utf-8"))
def fail(code,details=None): return {"verdict":f"FAIL_{code}","issues":details or []}
def ok(code,details=None): return {"verdict":f"PASS_{code}","issues":details or []}
def exists(ws:Path,rels): return [r for r in rels if not (ws/r).is_file()]


def name_of(value):
    if isinstance(value,dict):
        return value.get("name") or value.get("display_name") or value.get("title") or value.get("canonical_id") or value.get("id")
    return value

ABILITY_ALIASES={
    "strength":"STR","str":"STR","dexterity":"DEX","dex":"DEX","constitution":"CON","con":"CON",
    "intelligence":"INT","int":"INT","wisdom":"WIS","wis":"WIS","charisma":"CHA","cha":"CHA",
}

def parse_ability_adjustments(value):
    out={a:0 for a in ("STR","DEX","CON","INT","WIS","CHA")}
    if isinstance(value,dict):
        for k,v in value.items():
            ab=ABILITY_ALIASES.get(str(k).strip().lower())
            if ab and isinstance(v,int): out[ab]+=v
        return out
    text=str(value or "")
    for amount,ability in re.findall(r"([+-]\s*\d+)\s*(Strength|Dexterity|Constitution|Intelligence|Wisdom|Charisma|STR|DEX|CON|INT|WIS|CHA)\b",text,re.I):
        out[ABILITY_ALIASES[ability.lower()]]+=int(amount.replace(" ",""))
    return out

def depth_key(value):
    text=str(name_of(value) or "").lower()
    for key in ("boss","rival","powerful","significant","standard"):
        if key in text: return key
    return text.strip()

def recorded_art_floor(cl,depth):
    table={
      "standard":(0 if cl<5 else 4 if cl<10 else 8 if cl<15 else 10),
      "significant":(0 if cl<5 else 6 if cl<10 else 10 if cl<15 else 12),
      "powerful":(2 if cl<5 else 8 if cl<10 else 12 if cl<15 else 16),
      "rival":(2 if cl<5 else 10 if cl<10 else 16 if cl<15 else 20),
      "boss":(2 if cl<5 else 10 if cl<10 else 16 if cl<15 else 20),
    }
    return table.get(depth)

def ability_timeline(L,C):
    """Return ability scores/modifiers after each CL and explicit reconciliation issues."""
    issues=[]
    stats=L.get("core_stats",{}); ag=stats.get("ability_generation",{})
    base=ag.get("base_scores",{}); bg=ag.get("background_adjustments",{}); species=ag.get("species_adjustments",{}); other=ag.get("other_adjustments",{})
    current={}
    for ab in C.ABILITIES:
        if not isinstance(base.get(ab),int):
            issues.append(f"ABILITY_TIMELINE_BASE_INVALID:{ab}"); current[ab]=0
        else:
            current[ab]=base[ab]+int(bg.get(ab,0) or 0)+int(species.get(ab,0) or 0)
    event_totals={ab:0 for ab in C.ABILITIES}; by_level={}
    for row in L.get("advancement",{}).get("levels",[]) or []:
        rcl=row.get("cl"); level_delta={ab:0 for ab in C.ABILITIES}
        for a in row.get("allocations",[]) or []:
            if not isinstance(a,dict): continue
            structured=a.get("ability_score_adjustments")
            parsed=parse_ability_adjustments(structured if isinstance(structured,dict) else a.get("name"))
            if any(parsed.values()):
                if a.get("channel")!="event": issues.append(f"ABILITY_ADJUSTMENT_MUST_USE_EVENT_CHANNEL:CL{rcl}:{a.get('allocation_id')}")
                for ab,val in parsed.items(): level_delta[ab]+=val; event_totals[ab]+=val
        for ab,val in level_delta.items(): current[ab]+=val
        by_level[rcl]={"scores":dict(current),"mods":{ab:(current[ab]-10)//2 for ab in C.ABILITIES},"deltas":level_delta}
    declared={ab:int(other.get(ab,0) or 0) for ab in C.ABILITIES}
    if event_totals!=declared:
        issues.append(f"ABILITY_TIMELINE_EVENT_TOTAL_MISMATCH:{event_totals}!={declared}")
    final=stats.get("ability_scores",{})
    if by_level:
        last=by_level[max(by_level)]["scores"]
        if any(final.get(ab)!=last.get(ab) for ab in C.ABILITIES): issues.append(f"ABILITY_TIMELINE_FINAL_MISMATCH:{last}!={final}")
    return by_level,issues
def scan(value,path="root",issues=None):
    issues=issues if issues is not None else []
    if isinstance(value,str):
        for x in BANNED:
            if x.lower() in value.lower(): issues.append(f"BANNED_TEXT:{path}:{x}")
    elif isinstance(value,list):
        for i,x in enumerate(value): scan(x,f"{path}[{i}]",issues)
    elif isinstance(value,dict):
        for k,x in value.items(): scan(x,f"{path}.{k}",issues)
    return issues


def factory_root(ws:Path)->Path:
    # Fixtures/workspaces may live anywhere; the validator itself always lives under the factory.
    return Path(__file__).resolve().parents[1]


def compiler_module():
    path=Path(__file__).resolve().parents[1]/"05_COMPILER"/"compile_character.py"
    spec=importlib.util.spec_from_file_location("hf05zvk_compiler",path)
    if not spec or not spec.loader: raise RuntimeError(f"COMPILER_IMPORT_FAILED:{path}")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def coverage_module():
    root=Path(__file__).resolve().parents[1]
    path=root/'06_VALIDATORS'/'validate_selected_rule_execution_coverage.py'
    spec=importlib.util.spec_from_file_location('hf05zvk_coverage',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod


def item_module():
    path=Path(__file__).resolve().parent/"validate_item_integration_p2e.py"
    spec=importlib.util.spec_from_file_location("hf05zvk_p2e_item",path)
    if not spec or not spec.loader: raise RuntimeError(f"ITEM_VALIDATOR_IMPORT_FAILED:{path}")
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def semantic_module():
    path=Path(__file__).resolve().parent/"validate_semantic_requirements.py"
    spec=importlib.util.spec_from_file_location("hf05zvk_r1f_semantic",path)
    if not spec or not spec.loader: raise RuntimeError(f"SEMANTIC_IMPORT_FAILED:{path}")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def packet_refs(row):
    refs=row.get("source_packet_ids") or ([row.get("source_packet_id")] if row.get("source_packet_id") else [])
    return [str(x) for x in refs if str(x).strip()]


def phase1(ws):
    req=["Command_1/Build_Request.json","Command_1/Inspiration_Source_Evidence.json","Command_1/Character_Blueprint.json","Command_1/Selection_Plan.json","Command_1/Surface_Coverage_Plan.json","Command_1/Open_Questions.json","Command_1/Command_1_Audit.md"]
    issues=[f"MISSING:{x}" for x in exists(ws,req)]
    if issues: return fail("COMMAND_1",issues)
    try:
        C=compiler_module()
        request=load(ws/"Command_1/Build_Request.json"); evidence=load(ws/"Command_1/Inspiration_Source_Evidence.json")
        bp=load(ws/"Command_1/Character_Blueprint.json")
        plan=load(ws/"Command_1/Selection_Plan.json"); coverage=load(ws/"Command_1/Surface_Coverage_Plan.json"); oq=load(ws/"Command_1/Open_Questions.json")
        if not isinstance(request.get("request"),str) or not request["request"].strip(): issues.append("BUILD_REQUEST_EMPTY")
        source_mode=evidence.get("source_mode") or request.get("source_mode")
        accepted_modes={"adaptation","external_inspiration_adaptation","original_character","synthetic_acceptance_fixture","uploaded_source","web_source"}
        if source_mode not in accepted_modes: issues.append(f"SOURCE_MODE_INVALID:{source_mode}")
        sources=evidence.get("sources")
        if not isinstance(sources,list): issues.append("INSPIRATION_SOURCES_LIST_REQUIRED")
        if source_mode in {"adaptation","external_inspiration_adaptation","uploaded_source","web_source"} and not sources: issues.append("ADAPTATION_SOURCE_EVIDENCE_EMPTY")
        if not isinstance(evidence.get("inferences",evidence.get("adaptation_inferences",[])),list): issues.append("INSPIRATION_INFERENCES_LIST_REQUIRED")

        path_name=name_of(bp.get("path")) or name_of(plan.get("path"))
        path_obj=bp.get("path") if isinstance(bp.get("path"),dict) else {}
        key_ability=bp.get("key_ability") or path_obj.get("key_ability")
        key_ability=key_ability or (plan.get("path") or {}).get("key_ability")
        background=bp.get("background") or {}; bg_grants=bp.get("background_grants") or {"sphere":background.get("sphere"),"talent":background.get("talent"),"equipment":background.get("starting_equipment") or background.get("equipment")}
        cl1_talent=name_of(bp.get("cl1_free_talent")); origin_name=name_of(bp.get("origin_insight")); method_name=name_of(bp.get("method")); foundation_name=name_of(bp.get("foundation"))
        normalized={"character_id":bp.get("character_id"),"name":bp.get("name"),"title":bp.get("title"),"concept":bp.get("concept"),"cl":bp.get("cl"),"realm":bp.get("realm"),"path":path_name,"key_ability":key_ability,"pb":bp.get("pb"),"point_buy_intent":bp.get("point_buy_intent"),"background":background,"background_grants":bg_grants,"origin_insight":origin_name,"level_1_sphere":name_of(bp.get("level_1_sphere")),"cl1_free_talent":cl1_talent,"method":method_name,"foundation":foundation_name,"primary_spheres":bp.get("primary_spheres"),"supporting_spheres":bp.get("supporting_spheres"),"action_inventory_targets":bp.get("action_inventory_targets"),"recorded_art_plan":bp.get("recorded_art_plan"),"forged_technique_plan":bp.get("forged_technique_plan"),"emergency_seed_policy":bp.get("emergency_seed_policy"),"composite_playbook_roles":bp.get("composite_playbook_roles"),"dao_phrase":bp.get("dao_phrase"),"i_ching_direction":bp.get("i_ching_direction"),"ai_combat_identity":bp.get("ai_combat_identity"),"equipment_expectations":bp.get("equipment_expectations"),"state_resource_expectations":bp.get("state_resource_expectations"),"gm_screen_target":bp.get("gm_screen_target") or request.get("gm_screen_target")}
        required=tuple(normalized)
        for f in required:
            if normalized.get(f) in (None,"",[],{}) and f not in {"forged_technique_plan"}: issues.append(f"BLUEPRINT_MISSING:{f}")
        cl=normalized.get("cl")
        if not isinstance(cl,int) or not 1<=cl<=20: issues.append("BLUEPRINT_CL_INVALID")
        else:
            if normalized.get("realm")!=C.realm_for_cl(cl): issues.append("BLUEPRINT_REALM_MISMATCH")
            if normalized.get("pb")!=C.pb_for_cl(cl): issues.append("BLUEPRINT_PB_MISMATCH")
        path=C.PATH_RULES.get(path_name)
        if not path: issues.append(f"BLUEPRINT_PATH_INVALID:{path_name}")
        elif key_ability not in path["key_abilities"]: issues.append("BLUEPRINT_PATH_KEY_ABILITY_ILLEGAL")
        if normalized.get("gm_screen_target")!=CURRENT_GM_SCREEN_PATCH: issues.append(f"BLUEPRINT_GM_SCREEN_TARGET_MISMATCH:{normalized.get('gm_screen_target')}!={CURRENT_GM_SCREEN_PATCH}")

        pbi=bp.get("point_buy_intent",{}); base=pbi.get("base_scores",{}); bg_adj=pbi.get("background_adjustment",{}); final=pbi.get("final_target",{})
        if set(base)!=set(C.ABILITIES) or any(v not in C.POINT_BUY_COST for v in base.values()): issues.append("BLUEPRINT_POINT_BUY_BASE_INVALID")
        elif sum(C.POINT_BUY_COST[v] for v in base.values())!=27: issues.append("BLUEPRINT_POINT_BUY_NOT_27")
        bg_values=[v for v in bg_adj.values() if isinstance(v,int) and v!=0]
        if sorted(bg_values)!=[2]: issues.append(f"BLUEPRINT_BACKGROUND_ABILITY_INCREASE_MUST_BE_ONE_PLUS_TWO:{bg_values}")
        planned_adjust=parse_ability_adjustments(pbi.get("advancement_adjustments") or pbi.get("cl4_choice") or "")
        if not any(planned_adjust.values()):
            for row in plan.get("path_features_expected",[]) or []:
                if isinstance(row,dict) and row.get("cl") and "ability score" in str(row.get("name","")).lower():
                    for ab,val in parse_ability_adjustments(row.get("choice")).items(): planned_adjust[ab]+=val
        if set(final)!=set(C.ABILITIES): issues.append("BLUEPRINT_FINAL_ABILITY_TARGET_INCOMPLETE")
        elif all(isinstance(base.get(a),int) for a in C.ABILITIES):
            for a in C.ABILITIES:
                expected=base[a]+int(bg_adj.get(a,0))+planned_adjust[a]
                if final.get(a)!=expected: issues.append(f"BLUEPRINT_FINAL_ABILITY_MISMATCH:{a}:{final.get(a)}!={expected}")
        for f in ("sphere","talent","equipment"):
            if bg_grants.get(f) in (None,"",[],{}): issues.append(f"BLUEPRINT_BACKGROUND_GRANT_MISSING:{f}")
        if not isinstance(cl1_talent,str) or not cl1_talent.strip(): issues.append("BLUEPRINT_CL1_FREE_TALENT_MISSING")
        if normalized.get("level_1_sphere")==bg_grants.get("sphere"):
            overlap=bp.get("level_1_sphere_overlap_reconciliation")
            if not isinstance(overlap,dict) or overlap.get("same_sphere") is not True or overlap.get("duplicate_talent_avoided") is not True or not str(overlap.get("note","")).strip(): issues.append("BLUEPRINT_CL1_SPHERE_OVERLAP_RECONCILIATION_REQUIRED")
            if cl1_talent==bg_grants.get("talent"): issues.append("BLUEPRINT_CL1_OVERLAP_DUPLICATE_TALENT")

        spheres=plan.get("spheres",[]); talents=plan.get("talents",[])
        if not isinstance(spheres,list) or not spheres: issues.append("SELECTION_PLAN_SPHERES_EMPTY")
        if not isinstance(talents,list) or not talents: issues.append("SELECTION_PLAN_TALENTS_EMPTY")
        sphere_names={x.get("name") for x in spheres if isinstance(x,dict)}
        for row in spheres:
            if not isinstance(row,dict) or not row.get("name") or not isinstance(row.get("gained_at_cl"),int) or not 1<=row["gained_at_cl"]<=(cl or 0): issues.append(f"SELECTION_SPHERE_INVALID:{row}")
        free_by_cl={i:0 for i in range(1,(cl or 0)+1)}
        for row in talents:
            if not isinstance(row,dict) or not row.get("name") or row.get("sphere") not in sphere_names or not isinstance(row.get("gained_at_cl"),int): issues.append(f"SELECTION_TALENT_INVALID:{row}"); continue
            if row.get("acquisition_type")=="free_level" and row["gained_at_cl"] in free_by_cl: free_by_cl[row["gained_at_cl"]]+=1
        for rcl,count in free_by_cl.items():
            if count!=1: issues.append(f"SELECTION_FREE_LEVEL_TALENT_COUNT:CL{rcl}:{count}")
        level1_spheres=[row for row in spheres if isinstance(row,dict) and row.get("gained_at_cl")==1 and row.get("acquisition_type")=="level_1_sphere"]
        if normalized.get("level_1_sphere")==bg_grants.get("sphere"):
            if level1_spheres: issues.append("SELECTION_OVERLAP_MUST_NOT_DUPLICATE_SPHERE_ROW")
        elif len(level1_spheres)!=1 or level1_spheres[0].get("name")!=normalized.get("level_1_sphere"): issues.append("SELECTION_LEVEL_1_SPHERE_MISMATCH")
        # Replay planned Sphere acquisition at the actual CL. A final-CL total
        # can hide an earlier diversity exception, as the Bai Meizhen build did.
        overrides=[]
        for source in (bp.get("sphere_diversity_overrides",[]),plan.get("sphere_diversity_overrides",[])):
            if isinstance(source,list): overrides.extend(x for x in source if isinstance(x,dict))
        for rcl in range(1,(cl or 0)+1):
            diversity=len({row.get("name") for row in spheres if isinstance(row,dict) and isinstance(row.get("gained_at_cl"),int) and row.get("gained_at_cl")<=rcl})
            if diversity>C.SPHERE_DIVERSITY_EXCEPTIONAL[rcl]: issues.append(f"SELECTION_SPHERE_DIVERSITY_EXCEPTIONAL_MAX_EXCEEDED:CL{rcl}:{diversity}>{C.SPHERE_DIVERSITY_EXCEPTIONAL[rcl]}")
            elif diversity>C.SPHERE_DIVERSITY_DEFAULT[rcl]:
                override=next((x for x in overrides if x.get("cl")==rcl and x.get("approved") is True),None)
                if not override or not str(override.get("reason","")).strip(): issues.append(f"SELECTION_SPHERE_DIVERSITY_OVERRIDE_REQUIRED:CL{rcl}:{diversity}>{C.SPHERE_DIVERSITY_DEFAULT[rcl]}")
        cl1_free=[row for row in talents if isinstance(row,dict) and row.get("gained_at_cl")==1 and row.get("acquisition_type")=="free_level"]
        if len(cl1_free)!=1 or cl1_free[0].get("name")!=cl1_talent or cl1_free[0].get("sphere")!=normalized.get("level_1_sphere"): issues.append("SELECTION_CL1_FREE_TALENT_MISMATCH")

        cov={"minimum_meaningful_actions":coverage.get("minimum_meaningful_actions"),"minimum_composites":coverage.get("minimum_composites"),"minimum_recorded_arts":coverage.get("minimum_recorded_arts"),"forged_techniques_planned":coverage.get("forged_techniques_planned"),"required_tabs":coverage.get("required_tabs",coverage.get("required_permanent_tabs"))}
        for field,value in cov.items():
            if not isinstance(value,int) or value<0: issues.append(f"SURFACE_COVERAGE_INTEGER_REQUIRED:{field}")
        if (cov.get("minimum_meaningful_actions") or 0)<8: issues.append("SURFACE_MEANINGFUL_ACTION_TARGET_TOO_LOW")
        if (cov.get("minimum_composites") or 0)<3: issues.append("SURFACE_COMPOSITE_TARGET_TOO_LOW")
        if cov.get("required_tabs")!=len(REQUIRED_TABS): issues.append(f"SURFACE_REQUIRED_TAB_COUNT_MISMATCH:{cov.get('required_tabs')}!={len(REQUIRED_TABS)}")
        depth=depth_key(coverage.get("character_depth_profile")); floor=recorded_art_floor(cl or 0,depth)
        if floor is None: issues.append(f"CHARACTER_DEPTH_PROFILE_INVALID:{coverage.get('character_depth_profile')}")
        elif isinstance(cov.get("minimum_recorded_arts"),int) and cov["minimum_recorded_arts"]<floor: issues.append(f"RECORDED_ART_PLAN_BELOW_DEPTH_FLOOR:{cov['minimum_recorded_arts']}<{floor}")
        art_plan=bp.get("recorded_art_plan") or []
        if not isinstance(art_plan,list): issues.append("RECORDED_ART_PLAN_LIST_REQUIRED")
        else:
            unnamed=[i for i,row in enumerate(art_plan) if not str(name_of(row) or "").strip()]
            if unnamed: issues.append(f"RECORDED_ART_PLAN_NAME_MISSING:{unnamed}")
            if isinstance(cov.get("minimum_recorded_arts"),int) and len(art_plan)<cov["minimum_recorded_arts"]: issues.append(f"RECORDED_ART_PLAN_COUNT_BELOW_DECLARED_MINIMUM:{len(art_plan)}<{cov['minimum_recorded_arts']}")
            if floor is not None and len(art_plan)<floor: issues.append(f"RECORDED_ART_PLAN_COUNT_BELOW_DEPTH_FLOOR:{len(art_plan)}<{floor}")
        econ=coverage.get("action_economy_targets",{})
        econ_values={"action":econ.get("action"),"bonus_action":econ.get("bonus_action"),"reaction":econ.get("reaction"),"passive":econ.get("passive",econ.get("passive_or_triggered"))}
        for bucket,value in econ_values.items():
            if not isinstance(value,int) or value<0: issues.append(f"SURFACE_ECONOMY_TARGET_INVALID:{bucket}")
        if cov.get("forged_techniques_planned") != len(bp.get("forged_technique_plan",[]) or []): issues.append("FORGED_PLAN_COUNT_MISMATCH")
        if not bp.get("forged_technique_plan") and not bp.get("forged_techniques_none_reason"): issues.append("FORGED_NONE_REASON_REQUIRED")
        if oq.get("blocking_questions"): issues.append("OPEN_BLOCKING_QUESTIONS")
        issues+=scan({"request":request,"evidence":evidence,"blueprint":bp,"plan":plan,"coverage":coverage})
    except Exception as e:
        issues.append(f"COMMAND_1_VALIDATOR_EXCEPTION:{type(e).__name__}:{e}")
    return fail("COMMAND_1",sorted(set(issues))) if issues else ok("COMMAND_1")


def _grant_rows(L):
    bo=L.get("background_origin",{})
    rows=[]
    def add(gt,gid,row,channel,gained):
        if isinstance(row,dict) and gid: rows.append((gt,str(gid),row,channel,gained))
    bg=bo.get("background",{}); origin=bo.get("origin_insight",{})
    add("background",bg.get("background_id"),bg,"background",1)
    add("origin_insight",origin.get("origin_insight_id"),origin,"origin",1)
    for row in L.get("spheres",[]) or []: add("sphere",row.get("sphere_id"),row,row.get("acquisition_type"),row.get("gained_at_cl"))
    for row in L.get("talents",[]) or []: add("talent",row.get("talent_id"),row,row.get("acquisition_type"),row.get("gained_at_cl"))
    for row in L.get("features",[]) or []: add("feature",row.get("feature_id"),row,"feature",row.get("gained_at_cl"))
    method=L.get("method",{}); foundation=L.get("foundation",{})
    add("method",method.get("method_id"),method,"method",method.get("gained_at_cl"))
    add("foundation",foundation.get("foundation_id"),foundation,"foundation",foundation.get("gained_at_cl"))
    for row in L.get("equipment",[]) or []: add("equipment",row.get("equipment_id"),row,"equipment",row.get("gained_at_cl"))
    # Item Book R1 instances use the item coverage row as their event-sourced
    # acquisition record while the R2 instance remains the mutable runtime state.
    item_cov={r.get("instance_id"):r for r in (L.get("item_execution_coverage",{}).get("items",[]) or []) if isinstance(r,dict)}
    for inst in L.get("equipment_ledger_r2",{}).get("item_instances",[]) or []:
        if not isinstance(inst,dict): continue
        iid=inst.get("instance_id"); cov=item_cov.get(iid,{})
        definition=inst.get("definition_snapshot") or {}
        row={**cov,"instance_id":iid,"name":definition.get("name") or cov.get("name") or inst.get("item_id")}
        add("item",iid,row,"item",cov.get("gained_at_cl"))
    for row in L.get("training_sources",[]) or []: add("training_source",row.get("source_id"),row,"training_source",row.get("gained_at_cl"))
    for row in L.get("recorded_arts",[]) or []: add("recorded_art",row.get("manual_technique_id"),row,"manual",row.get("gained_at_cl"))
    for row in L.get("forged_techniques",[]) or []: add("forged_technique",row.get("forged_id"),row,"forged",row.get("cl_learned"))
    for row in L.get("emergency_technique_seeds",[]) or []: add("emergency_seed",row.get("seed_id"),row,"emergency_seed",row.get("created_at_cl"))
    for row in L.get("immortal_arts",[]) or []: add("immortal_art",row.get("immortal_art_id"),row,"immortal_art",row.get("gained_at_cl"))
    return rows


def phase2(ws):
    req=["Command_2/Rules_Selection_Packets.json","Command_2/Canonical_Advancement_Ledger.json","Command_2/Canonical_Stats_Resource_Block.json","Command_2/Advancement_Reconciliation.json","Command_2/Command_2_Audit.md","Character_Master_Ledger.json"]
    issues=[f"MISSING:{x}" for x in exists(ws,req)]
    if issues: return fail("COMMAND_2",issues)
    try:
        C=compiler_module(); L=load(ws/"Character_Master_Ledger.json")
        packets=C.verify_packets(load(ws/"Command_2/Rules_Selection_Packets.json"),factory_root(ws)/"09_RULES"/"Tianxia_Canonical_Rules_Corpus_P2A.zip")
        if L.get("status") not in {"COMMAND_2_ADVANCEMENT_LEDGER_SEALED","COMMAND_3_CHASSIS_COMPLETE","COMMAND_4_EXECUTABLE_CHARACTER_COMPLETE"}: issues.append("LEDGER_NOT_COMMAND_2_SEALED")
        build_mode=L.get("build_mode","production")
        if build_mode not in C.BUILD_MODES: issues.append(f"BUILD_MODE_INVALID:{build_mode}")
        char=L.get("character",{}); stats=L.get("core_stats",{}); cl=char.get("cl")
        if not isinstance(cl,int) or not 1<=cl<=20: issues.append("CHARACTER_CL_INVALID")
        path_rule=C.PATH_RULES.get(char.get("path"))
        if not path_rule: issues.append(f"PATH_INVALID:{char.get('path')}")
        elif char.get("key_ability") not in path_rule["key_abilities"]: issues.append("PATH_KEY_ABILITY_ILLEGAL")
        if isinstance(cl,int):
            try:
                if char.get("realm")!=C.realm_for_cl(cl): issues.append("CHARACTER_REALM_MISMATCH")
                if char.get("pb")!=C.pb_for_cl(cl): issues.append("CHARACTER_PB_MISMATCH")
            except Exception as e: issues.append(str(e))
        bo=L.get("background_origin",{}); bg=bo.get("background",{})
        try: C.validate_point_buy(stats,stats.get("ability_scores",{}),bg,packets,build_mode)
        except Exception as e: issues.append(str(e))
        scores=stats.get("ability_scores",{}); mods=stats.get("ability_modifiers",{}); saves=stats.get("saving_throws",{}); adj=stats.get("saving_throw_adjustments",{})
        for ab in C.ABILITIES:
            if not isinstance(scores.get(ab),int): issues.append(f"ABILITY_SCORE_INTEGER_REQUIRED:{ab}"); continue
            expected=(scores[ab]-10)//2
            if mods.get(ab)!=expected: issues.append(f"ABILITY_MODIFIER_MISMATCH:{ab}")
            if saves.get(ab)!=expected+adj.get(ab,0): issues.append(f"SAVE_RECONCILIATION_FAILED:{ab}")
        skills=stats.get("skills",{}); skill_map=stats.get("skill_ability_map",{}); skill_mult=stats.get("skill_proficiency_multipliers",{}); skill_adj=stats.get("skill_adjustments",{})
        if set(skills)!=set(skill_map) or set(skills)!=set(skill_mult) or set(skills)!=set(skill_adj): issues.append("SKILL_CALCULATION_KEY_MISMATCH")
        else:
            expected_proficient={name for name,m in skill_mult.items() if m in {1,2}}
            if set(stats.get("proficient_skills",[]))!=expected_proficient: issues.append("PROFICIENT_SKILL_LIST_MISMATCH")
            skill_sources=stats.get("skill_sources",{}); skill_packets=stats.get("skill_source_packet_ids",{})
            if set(skill_sources)!=set(skills): issues.append("SKILL_DISPLAY_SOURCE_KEY_MISMATCH")
            for name,value in skills.items():
                ability=skill_map.get(name); multiplier=skill_mult.get(name); adjustment=skill_adj.get(name)
                if ability not in C.ABILITIES or multiplier not in {0,1,2} or not isinstance(adjustment,int): issues.append(f"SKILL_CALCULATION_INVALID:{name}")
                elif value!=mods[ability]+char.get("pb",0)*multiplier+adjustment: issues.append(f"SKILL_RECONCILIATION_FAILED:{name}")
                if not isinstance(skill_sources.get(name),str) or not skill_sources.get(name,'').strip(): issues.append(f"SKILL_DISPLAY_SOURCE_REQUIRED:{name}")
                if multiplier in {1,2} or adjustment:
                    refs=skill_packets.get(name,[])
                    if not isinstance(refs,list) or not refs: issues.append(f"SKILL_SOURCE_PACKET_REQUIRED:{name}")
                    else:
                        for ref in refs:
                            if ref not in packets: issues.append(f"SKILL_SOURCE_PACKET_UNKNOWN:{name}:{ref}")
        training_sources=L.get("training_sources",[]) or []
        if not training_sources: issues.append("MANUAL_LINEAGE_SOURCE_REQUIRED_FOR_COMPLETE_CHARACTER")
        source_ids={x.get("source_id") for x in training_sources if isinstance(x,dict)}
        for art in L.get("recorded_arts",[]) or []:
            if art.get("training_source_id") not in source_ids: issues.append(f"MANUAL_TRAINING_SOURCE_UNRESOLVED:{art.get('manual_technique_id')}:{art.get('training_source_id')}")
        ac=stats.get("ac_generation",{}); ac_fields=("base_ac","dexterity_modifier_applied","shield_adjustment","foundation_adjustment","method_adjustment","item_adjustment","other_adjustment")
        if not all(isinstance(ac.get(f),int) for f in ac_fields): issues.append("AC_COMPONENTS_INVALID")
        else:
            total=sum(ac[f] for f in ac_fields)
            if ac.get("total")!=total or stats.get("ac_active")!=total: issues.append("AC_RECONCILIATION_FAILED")
        speed=stats.get("speed_generation",{}); speed_fields=("base_speed","path_adjustment","sphere_adjustment","foundation_adjustment","method_adjustment","equipment_adjustment","other_adjustment")
        if not all(isinstance(speed.get(f),int) for f in speed_fields): issues.append("SPEED_COMPONENTS_INVALID")
        else:
            total=sum(speed[f] for f in speed_fields)
            if speed.get("total")!=total or stats.get("speed_ft")!=total: issues.append("SPEED_RECONCILIATION_FAILED")
        init=stats.get("initiative_generation",{}); init_ab=init.get("ability"); init_mult=init.get("proficiency_multiplier"); init_adj=init.get("adjustment")
        if init_ab not in C.ABILITIES or init_mult not in {0,1,2} or not isinstance(init_adj,int): issues.append("INITIATIVE_COMPONENTS_INVALID")
        else:
            total=mods[init_ab]+char.get("pb",0)*init_mult+init_adj
            if init.get("total")!=total or stats.get("initiative_bonus")!=total: issues.append("INITIATIVE_RECONCILIATION_FAILED")
        levels=L.get("advancement",{}).get("levels",[])
        timeline,timeline_issues=ability_timeline(L,C); issues.extend(timeline_issues)
        if not isinstance(cl,int) or [x.get("cl") for x in levels]!=list(range(1,cl+1)): issues.append("LEVEL_COVERAGE_INVALID")
        allocation_index={}; allocations_by_cl={}; last_hp=0
        key_map={"Strength":"STR","Dexterity":"DEX","Constitution":"CON","Intelligence":"INT","Wisdom":"WIS","Charisma":"CHA","STR":"STR","DEX":"DEX","CON":"CON","INT":"INT","WIS":"WIS","CHA":"CHA"}
        key_ab=key_map.get(char.get("key_ability"))
        for idx,row in enumerate(levels,1):
            rcl=row.get("cl"); allocations_by_cl[rcl]=row.get("allocations",[]) or []
            if rcl and row.get("realm")!=C.realm_for_cl(rcl): issues.append(f"LEVEL_REALM_MISMATCH:CL{rcl}")
            if rcl and row.get("pb")!=C.pb_for_cl(rcl): issues.append(f"LEVEL_PB_MISMATCH:CL{rcl}")
            hp=row.get("hp",{}); resource=row.get("resource",{})
            level_mods=(timeline.get(rcl) or {}).get("mods",mods); con_mod=level_mods.get("CON"); key_mod=level_mods.get(key_ab) if key_ab else None
            if path_rule and isinstance(con_mod,int):
                expected_base=path_rule["die_size"] if rcl==1 else path_rule["fixed_average"]
                if hp.get("base_gain")!=expected_base: issues.append(f"LEVEL_HP_BASE_MISMATCH:CL{rcl}")
                if hp.get("constitution_delta")!=con_mod: issues.append(f"LEVEL_HP_CONSTITUTION_MISMATCH:CL{rcl}")
                if all(isinstance(hp.get(k),int) for k in ("base_gain","constitution_delta","other_delta","max_after_level")):
                    expected=last_hp+hp["base_gain"]+hp["constitution_delta"]+hp["other_delta"]
                    if hp["max_after_level"]!=expected: issues.append(f"LEVEL_HP_MATH_MISMATCH:CL{rcl}")
                    last_hp=hp["max_after_level"]
                else: issues.append(f"LEVEL_HP_COMPONENTS_INVALID:CL{rcl}")
            if isinstance(key_mod,int) and rcl:
                expected_base=max(0,rcl*key_mod)
                if resource.get("base_after_level")!=expected_base: issues.append(f"LEVEL_RESOURCE_BASE_MISMATCH:CL{rcl}")
                if all(isinstance(resource.get(k),int) for k in ("base_after_level","method_delta","foundation_delta","item_delta","max_after_level")):
                    expected=resource["base_after_level"]+resource["method_delta"]+resource["foundation_delta"]+resource["item_delta"]
                    if resource["method_delta"] != 0:
                        method=L.get("method",{}) or {}
                        if method.get("status") in {"none_acquired","not_applicable","not_selected_for_this_build","unavailable_until_later_cl"}: issues.append(f"PRIMARY_RESOURCE_METHOD_DELTA_WITHOUT_METHOD:CL{rcl}")
                        elif resource.get("method_source_grant_id") != method.get("method_id"): issues.append(f"PRIMARY_RESOURCE_METHOD_SOURCE_MISMATCH:CL{rcl}")
                    if resource["foundation_delta"] != 0:
                        foundation=L.get("foundation",{}) or {}
                        if foundation.get("status") in {"none_acquired","not_applicable","not_selected_for_this_build","unavailable_until_later_cl"}: issues.append(f"PRIMARY_RESOURCE_FOUNDATION_DELTA_WITHOUT_FOUNDATION:CL{rcl}")
                        elif resource.get("foundation_source_grant_id") != foundation.get("foundation_id"): issues.append(f"PRIMARY_RESOURCE_FOUNDATION_SOURCE_MISMATCH:CL{rcl}")
                    if resource["item_delta"] != 0 and not resource.get("item_source_grant_ids"):
                        issues.append(f"PRIMARY_RESOURCE_ITEM_SOURCE_REQUIRED:CL{rcl}")
                    if resource["max_after_level"]!=expected: issues.append(f"LEVEL_RESOURCE_MATH_MISMATCH:CL{rcl}")
                else: issues.append(f"LEVEL_RESOURCE_COMPONENTS_INVALID:CL{rcl}")
            trained=0
            for a in allocations_by_cl[rcl]:
                aid=a.get("allocation_id"); ch=a.get("channel"); gt=a.get("grant_type"); gid=a.get("grant_id")
                if not aid or aid in allocation_index: issues.append(f"ALLOCATION_ID_INVALID_OR_DUPLICATE:CL{rcl}:{aid}")
                else: allocation_index[aid]={**a,"cl":rcl}
                if ch not in C.ALLOCATION_CHANNELS: issues.append(f"ALLOCATION_CHANNEL_INVALID:CL{rcl}:{ch}")
                if gt not in C.GRANT_TYPES: issues.append(f"ALLOCATION_GRANT_TYPE_INVALID:CL{rcl}:{gt}")
                if not gid: issues.append(f"ALLOCATION_GRANT_ID_MISSING:CL{rcl}:{aid}")
                cost=a.get("slot_cost")
                if ch in C.TRAINED_CHANNELS:
                    if cost!=1: issues.append(f"TRAINED_SLOT_COST_INVALID:CL{rcl}:{aid}")
                    trained += cost if isinstance(cost,int) else 99
                elif cost!=0: issues.append(f"FREE_SLOT_COST_INVALID:CL{rcl}:{aid}")
                refs=packet_refs(a)
                if not refs: issues.append(f"ALLOCATION_SOURCE_PACKET_REQUIRED:CL{rcl}:{aid}")
                for ref in refs:
                    if ref not in packets: issues.append(f"ALLOCATION_UNKNOWN_PACKET:CL{rcl}:{ref}")
            if trained>3: issues.append(f"TRAINED_BUDGET_CL{rcl}:{trained}")
            if row.get("state_after_hash")!=C.checkpoint_hash(levels,idx): issues.append(f"STATE_CHECKPOINT_HASH_MISMATCH:CL{rcl}")
        if levels and stats.get("hp_max")!=levels[-1].get("hp",{}).get("max_after_level"): issues.append("FINAL_HP_DOES_NOT_MATCH_LEVEL_LEDGER")
        if levels and stats.get("primary_resource_max")!=levels[-1].get("resource",{}).get("max_after_level"): issues.append("FINAL_RESOURCE_DOES_NOT_MATCH_LEVEL_LEDGER")
        # Permanent grant/event reconciliation.
        grants={}
        for gt,gid,row,expected_channel,gained_at_cl in _grant_rows(L):
            key=(gt,gid)
            if key in grants: issues.append(f"DUPLICATE_GRANT_ID:{gt}:{gid}")
            grants[key]=(row,expected_channel)
            aid=row.get("allocation_id")
            if not aid or aid not in allocation_index: issues.append(f"GRANT_ALLOCATION_UNRESOLVED:{gt}:{gid}")
            elif allocation_index[aid].get("grant_id")!=gid or allocation_index[aid].get("grant_type")!=gt: issues.append(f"GRANT_ALLOCATION_MISMATCH:{gt}:{gid}")
            if gained_at_cl!=allocation_index.get(aid,{}).get("cl"): issues.append(f"GRANT_LEVEL_MISMATCH:{gt}:{gid}")
        for aid,a in allocation_index.items():
            if a.get("grant_type")!="event" and (a.get("grant_type"),str(a.get("grant_id"))) not in grants:
                issues.append(f"ALLOCATION_GRANT_UNRESOLVED:{aid}:{a.get('grant_type')}:{a.get('grant_id')}")
        spheres={x.get("sphere_id"):x for x in L.get("spheres",[]) or []}; sphere_by_name={x.get("name"):x for x in spheres.values()}
        talents={x.get("talent_id"):x for x in L.get("talents",[]) or []}
        for rcl,rows in allocations_by_cl.items():
            free=[x for x in rows if x.get("channel")=="free_level" and x.get("grant_type")=="talent"]
            if len(free)!=1: issues.append(f"FREE_LEVEL_TALENT_COUNT_INVALID:CL{rcl}:{len(free)}")
            for a in [x for x in rows if x.get("channel")=="new_sphere"]:
                sphere=spheres.get(a.get("grant_id")); bonuses=[x for x in rows if x.get("channel")=="new_sphere_bonus" and talents.get(x.get("grant_id"),{}).get("sphere")== (sphere or {}).get("name")]
                if len(bonuses)!=1: issues.append(f"NEW_SPHERE_BONUS_TALENT_COUNT_INVALID:CL{rcl}:{a.get('grant_id')}:{len(bonuses)}")
            for a in [x for x in rows if x.get("channel")=="trained_choice" and x.get("grant_type")=="talent"]:
                t=talents.get(a.get("grant_id"),{}); s=sphere_by_name.get(t.get("sphere"))
                if not s or s.get("gained_at_cl",99)>rcl: issues.append(f"TRAINED_TALENT_SPHERE_NOT_KNOWN:CL{rcl}:{a.get('grant_id')}")
        # Command 2 must already prove training history; Command 3 is not the
        # first place an invalid DC, roll, or training duration should surface.
        known_sphere_ids=set(); known_talent_ids=set(); manuals={x.get("manual_technique_id"):x for x in L.get("recorded_arts",[]) or []}
        for rcl in range(1,(cl or 0)+1):
            rows=allocations_by_cl.get(rcl,[])
            prior_manual=0
            free=[x for x in rows if x.get("channel")=="free_level" and x.get("grant_type")=="talent"]
            if rcl==1:
                level1=[x for x in rows if x.get("channel")=="level_1_sphere"]
                if len(level1)!=1: issues.append(f"LEVEL_1_SPHERE_COUNT_INVALID:{len(level1)}")
                elif free:
                    t=talents.get(free[0].get("grant_id"),{}); sphere=sphere_by_name.get(t.get("sphere"),{})
                    entry=level1[0]
                    sid=entry.get("grant_id") if entry.get("grant_type")=="sphere" else entry.get("overlap_sphere_id")
                    if sid!=sphere.get("sphere_id"): issues.append("CL1_LEVEL_TALENT_NOT_FROM_LEVEL_1_SPHERE")
                    if entry.get("grant_type")=="event":
                        if entry.get("contribution_talent_id")!=free[0].get("grant_id") or not str(entry.get("overlap_note","")).strip(): issues.append("CL1_OVERLAP_RECONCILIATION_INVALID")
            for a in rows:
                try:
                    channel=a.get("channel")
                    if channel=="new_sphere":
                        rec=a.get("training_record",{}); d4=rec.get("dc_d4_roll"); prior=len(known_sphere_ids)
                        if rec.get("prior_different_spheres_known")!=prior: issues.append(f"NEW_SPHERE_PRIOR_COUNT_MISMATCH:{a.get('allocation_id')}")
                        C.validate_training_record(rec,label=f"allocation.{a.get('allocation_id')}.training_record",kind="new_sphere",current_pb=C.pb_for_cl(rcl),ability_modifiers=(timeline.get(rcl) or {}).get("mods",mods),expected_dc=10+d4+prior)
                    elif channel=="trained_choice" and a.get("grant_type")=="talent":
                        tr=talents.get(a.get("grant_id"),{}); prior=sum(1 for tid in known_talent_ids if talents.get(tid,{}).get("sphere")==tr.get("sphere")); rec=a.get("training_record",{})
                        if rec.get("prior_talents_known_in_sphere")!=prior: issues.append(f"KNOWN_SPHERE_TALENT_PRIOR_COUNT_MISMATCH:{a.get('allocation_id')}")
                        C.validate_training_record(rec,label=f"allocation.{a.get('allocation_id')}.training_record",kind="known_sphere_talent",current_pb=C.pb_for_cl(rcl),ability_modifiers=(timeline.get(rcl) or {}).get("mods",mods),expected_dc=10+prior)
                    elif channel=="manual" and a.get("grant_type")=="recorded_art":
                        mr=manuals.get(a.get("grant_id"),{}); rec=a.get("training_record",{}); expected_dc=10+mr.get("manual_difficulty",-999)+2*prior_manual
                        if rec.get("manual_difficulty")!=mr.get("manual_difficulty") or rec.get("prior_recorded_arts_learned_this_cl")!=prior_manual: issues.append(f"RECORDED_ART_TRAINING_HISTORY_MISMATCH:{a.get('allocation_id')}")
                        C.validate_training_record(rec,label=f"allocation.{a.get('allocation_id')}.training_record",kind="recorded_art",current_pb=C.pb_for_cl(rcl),ability_modifiers=(timeline.get(rcl) or {}).get("mods",mods),expected_dc=expected_dc)
                        if mr.get("training_dc")!=expected_dc: issues.append(f"RECORDED_ART_TRAINING_DC_MISMATCH:{a.get('grant_id')}")
                        prior_manual+=1
                except Exception as e: issues.append(str(e))
                if a.get("grant_type")=="sphere": known_sphere_ids.add(a.get("grant_id"))
                elif a.get("grant_type")=="talent": known_talent_ids.add(a.get("grant_id"))
            diversity=len(known_sphere_ids)
            if diversity>C.SPHERE_DIVERSITY_EXCEPTIONAL[rcl]: issues.append(f"SPHERE_DIVERSITY_EXCEPTIONAL_MAX_EXCEEDED:CL{rcl}")
            elif diversity>C.SPHERE_DIVERSITY_DEFAULT[rcl]:
                override=(levels[rcl-1] if len(levels)>=rcl else {}).get("sphere_diversity_override")
                if not isinstance(override,dict) or override.get("approved") is not True: issues.append(f"SPHERE_DIVERSITY_OVERRIDE_REQUIRED:CL{rcl}")
        expected=set(char.get("path_feature_ids_expected",[]) or []); actual={x.get("feature_id") for x in L.get("features",[]) or [] if x.get("category")=="path_feature"}
        if not expected: issues.append("PATH_FEATURE_EXPECTATION_EMPTY")
        elif expected!=actual: issues.append(f"PATH_FEATURE_SET_MISMATCH:{sorted(expected)}!={sorted(actual)}")
        issues+=scan(L)
    except Exception as e:
        issues.append(f"COMMAND_2_VALIDATOR_EXCEPTION:{type(e).__name__}:{e}")
    return fail("COMMAND_2",sorted(set(issues))) if issues else ok("COMMAND_2")


def phase3(ws):
    base=phase2(ws); issues=[] if base["verdict"].startswith("PASS") else list(base["issues"])
    req=[
      "Command_3/Subsystem_Completion_Ledger.json","Command_3/Feature_Execution_Coverage_Plan.json",
      "Command_3/Foundation_Lifecycle_Audit.json","Command_3/Background_Origin_Method_Audit.json",
      "Command_3/Recorded_Art_Roster_Plan.json","Command_3/Blueprint_Deviation_Reconciliation.json",
      "Command_3/Command_3_Audit.md"
    ]
    issues += [f"MISSING:{x}" for x in exists(ws,req)]
    if not issues:
        try:
            L=load(ws/"Character_Master_Ledger.json")
            bg=L.get("background_origin",{}).get("background",{})
            for f in ("skill_proficiencies","tool_proficiencies","languages"):
                if not isinstance(bg.get(f),list): issues.append(f"BACKGROUND_COMPLETION_LIST_REQUIRED:{f}")
            er=bg.get("equipment_reconciliation",{})
            if not isinstance(er,dict) or er.get("missing_items"): issues.append("BACKGROUND_EQUIPMENT_RECONCILIATION_INCOMPLETE")
            origin=L.get("background_origin",{}).get("origin_insight",{})
            if not isinstance(origin.get("effect_records"),list) or not origin.get("effect_records"): issues.append("ORIGIN_EFFECT_RECORDS_EMPTY")
            method=L.get("method",{})
            if isinstance(method,dict) and not method.get("none"):
                if not str(method.get("stacking_statement","")).strip(): issues.append("METHOD_STACKING_STATEMENT_REQUIRED")
                if "only method" in str(method.get("stacking_statement","")).lower(): issues.append("METHOD_FALSE_EXCLUSIVITY_STATEMENT")
            foundation=L.get("foundation",{})
            if isinstance(foundation,dict) and not foundation.get("none"):
                lc=foundation.get("lifecycle_coverage",{})
                required=("passive_chassis","resources","actions_reactions","states","burdens","hidden_injuries","strains","deviations","integration","repair","treatment","temptations","failure_consequences")
                for key in required:
                    if not isinstance(lc.get(key),dict): issues.append(f"FOUNDATION_LIFECYCLE_CATEGORY_MISSING:{key}")
            sphere_ids={x.get("sphere_id") for x in L.get("spheres",[])}
            talent_ids={x.get("talent_id") for x in L.get("talents",[])}
            sphere_cov={x.get("source_id") for x in L.get("sphere_execution_coverage",[]) if isinstance(x,dict)}
            talent_cov={x.get("source_id") for x in L.get("talent_execution_coverage",[]) if isinstance(x,dict)}
            if sphere_cov!=sphere_ids: issues.append(f"SPHERE_EXECUTION_PLAN_MISMATCH:{sorted(sphere_ids-sphere_cov)}")
            if talent_cov!=talent_ids: issues.append(f"TALENT_EXECUTION_PLAN_MISMATCH:{sorted(talent_ids-talent_cov)}")
            coverage_mod=coverage_module()
            expected_sphere_projection=coverage_mod.project_legacy(L,"sphere")
            expected_talent_projection=coverage_mod.project_legacy(L,"talent")
            if L.get("sphere_execution_coverage",[])!=expected_sphere_projection: issues.append("SPHERE_EXECUTION_PROJECTION_STALE_OR_DUPLICATED")
            if L.get("talent_execution_coverage",[])!=expected_talent_projection: issues.append("TALENT_EXECUTION_PROJECTION_STALE_OR_DUPLICATED")
            q=L.get("quality_targets",{}); cl=L.get("character",{}).get("cl",0); depth=q.get("character_depth_profile")
            floors={"standard":(0 if cl<5 else 4 if cl<10 else 8 if cl<15 else 10),"significant":(0 if cl<5 else 6 if cl<10 else 10 if cl<15 else 12),"powerful":(2 if cl<5 else 8 if cl<10 else 12 if cl<15 else 16),"rival":(2 if cl<5 else 10 if cl<10 else 16 if cl<15 else 20),"boss":(2 if cl<5 else 10 if cl<10 else 16 if cl<15 else 20)}
            if depth not in floors: issues.append(f"CHARACTER_DEPTH_PROFILE_INVALID:{depth}")
            elif q.get("minimum_recorded_arts",-1)<floors[depth]: issues.append(f"RECORDED_ART_PLAN_BELOW_DEPTH_FLOOR:{q.get('minimum_recorded_arts')}<{floors[depth]}")
            deviations=L.get("blueprint_deviations")
            if not isinstance(deviations,list):
                issues.append("BLUEPRINT_DEVIATION_LEDGER_REQUIRED")
                deviations=[]
            deviation_by_field={}
            for i,row in enumerate(deviations):
                if not isinstance(row,dict): issues.append(f"BLUEPRINT_DEVIATION_OBJECT_REQUIRED:{i}"); continue
                field=str(row.get("field","")).strip()
                if not field: issues.append(f"BLUEPRINT_DEVIATION_FIELD_REQUIRED:{i}"); continue
                if field in deviation_by_field: issues.append(f"BLUEPRINT_DEVIATION_DUPLICATE_FIELD:{field}")
                deviation_by_field[field]=row
                if row.get("approved") is not True: issues.append(f"BLUEPRINT_DEVIATION_NOT_APPROVED:{field}")
                if not str(row.get("reason","")).strip(): issues.append(f"BLUEPRINT_DEVIATION_REASON_REQUIRED:{field}")
            bp=load(ws/"Command_1/Character_Blueprint.json")
            def normalized(value):
                if isinstance(value,list): return sorted(normalized(x) for x in value)
                if isinstance(value,dict): return {k:normalized(value[k]) for k in sorted(value)}
                return value
            def require_match(field,blueprint_value,final_value):
                if normalized(blueprint_value)==normalized(final_value): return
                row=deviation_by_field.get(field)
                if not row: issues.append(f"BLUEPRINT_DEVIATION_UNRECORDED:{field}"); return
                if normalized(row.get("blueprint_value"))!=normalized(blueprint_value) or normalized(row.get("final_value"))!=normalized(final_value):
                    issues.append(f"BLUEPRINT_DEVIATION_VALUE_MISMATCH:{field}")
            char=L.get("character",{})
            for field in ("cl","path","key_ability"):
                blueprint_value=name_of(bp.get(field)) if field=="path" else bp.get(field)
                require_match(f"character.{field}",blueprint_value,char.get(field))
            bp_background_name=name_of(bp.get("background"))
            if isinstance(bp_background_name,str): bp_background_name=bp_background_name.split(" — ")[0].strip()
            require_match("background.name",bp_background_name,bg.get("name"))
            require_match("origin_insight.name",name_of(bp.get("origin_insight")),origin.get("name"))
            require_match("method.name",name_of(bp.get("method")),method.get("name"))
            require_match("foundation.name",name_of(bp.get("foundation")),foundation.get("name"))
            bg_plan=bp.get("background_grants") or bp.get("background") or {}
            planned_spheres=sorted(set((bp.get("primary_spheres") or [])+(bp.get("supporting_spheres") or [])+[bg_plan.get("sphere"),name_of(bp.get("level_1_sphere"))])-{None,""})
            final_spheres=sorted({row.get("name") for row in L.get("spheres",[]) if isinstance(row,dict) and row.get("name")})
            require_match("spheres",planned_spheres,final_spheres)
            planned_art_names=[]
            for entry in bp.get("recorded_art_plan",[]) or []:
                planned_art_names.append(name_of(entry) if isinstance(entry,dict) else str(entry).split(" — ")[-1].strip())
            final_art_names=sorted({row.get("technique_name") for row in L.get("recorded_arts",[]) if isinstance(row,dict) and row.get("technique_name")})
            require_match("recorded_arts",sorted(planned_art_names),final_art_names)
            planned_forged=sorted(name_of(x) if isinstance(x,dict) else str(x).split(" — ")[-1].strip() for x in (bp.get("forged_technique_plan") or []))
            final_forged=sorted(row.get("name") for row in L.get("forged_techniques",[]) if isinstance(row,dict) and row.get("name"))
            require_match("forged_techniques",planned_forged,final_forged)
            issues+=item_module().validate_ledger(L,"planned")
            issues+=scan(L)
        except Exception as e: issues.append(f"COMMAND_3_VALIDATOR_EXCEPTION:{type(e).__name__}:{e}")
    return fail("COMMAND_3",sorted(set(issues))) if issues else ok("COMMAND_3")


def phase4(ws):
    base=phase3(ws); issues=[] if base["verdict"].startswith("PASS") else list(base["issues"])
    req=["Command_4/Executable_Action_Audit.json","Command_4/Talent_Execution_Coverage_Audit.json","Command_4/Composite_Feasibility_Audit.json","Command_4/Recorded_Art_Audit.json","Command_4/Forged_Technique_Audit.json","Command_4/Behavior_and_Dao_Audit.json","Command_4/Command_4_Audit.md"]
    issues += [f"MISSING:{x}" for x in exists(ws,req)]
    if not issues:
        try:
            C=compiler_module(); L=load(ws/"Character_Master_Ledger.json")
            packets=C.verify_packets(load(ws/"Command_2/Rules_Selection_Packets.json"),factory_root(ws)/"09_RULES"/"Tianxia_Canonical_Rules_Corpus_P2A.zip")
            C.validate_ledger(L,packets)
            semantic=semantic_module().run(L,load(ws/"Command_2/Rules_Selection_Packets.json"),ws)
            if not semantic.get("release_ready"):
                issues.extend([f"SEMANTIC:{x.get('severity')}:{x.get('code')}:{x.get('message')}" for x in semantic.get("issues",[]) if x.get("severity") in {"critical","high"}])
            (ws/"Validation").mkdir(parents=True,exist_ok=True)
            (ws/"Validation"/"Semantic_Validation_Report.json").write_text(json.dumps(semantic,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
        except Exception as e: issues.append(f"FULL_LEDGER_GATE:{e}")
    return fail("COMMAND_4",sorted(set(issues))) if issues else ok("COMMAND_4")


def verify_sums(build:Path):
    issues=[]; sums=build/"SHA256SUMS.txt"
    if not sums.is_file(): return ["MISSING_SHA256SUMS"]
    for line in sums.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        sha,name=line.split("  ",1); p=build/name
        if not p.is_file(): issues.append(f"CHECKSUM_FILE_MISSING:{name}"); continue
        got=hashlib.sha256(p.read_bytes()).hexdigest()
        if got!=sha: issues.append(f"CHECKSUM_MISMATCH:{name}")
    return issues


def phase5(ws):
    base=phase4(ws); issues=[] if base["verdict"].startswith("PASS") else list(base["issues"])
    build=ws/"Build"; req=["Character_Master_Ledger.json","Character_Import_Surface.json","Tianxia_GM_Character_Model_v1.json","Tianxia_GM_Character_View_Model_v2.json","Canonical_Stats_Resource_Block.json","Leveling_Ledger.json","Background_Origin_Ledger.json","Origin_Insight_Ledger.json","Cultivation_Method_Profile.json","Foundation_Detail_Ledger.json","Dao_IChing_Combat_Profile.json","Selected_Spheres.json","Talent_Source_Ledger.json","Sphere_Execution_Coverage.json","Talent_Execution_Coverage.json","Equipment_Ledger.json","Equipment_Ledger_Legacy.json","Item_Execution_Coverage.json","Selected_Item_GM_Projection.json","State_Effect_Registry.json","Complete_Action_Surface.json","Composite_Playbook.json","Manual_Lineage_Record.json","Martial_Arts_and_Manuals.json","Forged_Techniques.json","Emergency_Technique_Seeds.json","Immortal_Arts.json","AI_Character_Generation_Profile.json","AI_Combat_Behavior_Profile.json","GM_Screen_Projection_Rows.json","GM_Screen_Tab_Expectation_Manifest.json","Semantic_Validation_Report.json","Signature_Loadout.json","Build_Reconciliation.json","PACKAGE_MANIFEST.json","SHA256SUMS.txt"]
    issues += [f"MISSING_BUILD:{x}" for x in req if not (build/x).is_file()]
    if not issues:
        issues+=verify_sums(build)
        m=load(build/"GM_Screen_Tab_Expectation_Manifest.json"); tabs=[x.get("tab_id") for x in m.get("required_tabs",[])]
        if tabs!=REQUIRED_TABS: issues.append(f"TAB_MANIFEST_MISMATCH:{tabs}")
        semantic=load(build/"Semantic_Validation_Report.json")
        if semantic.get("verdict")!="PASS_HF05ZVK_R1F_SEMANTIC_VALIDATION" or semantic.get("release_ready") is not True:
            issues.append(f"SEMANTIC_VALIDATION_NOT_PASS:{semantic.get('verdict')}")
        loadout=load(build/"Signature_Loadout.json").get("actions",[])
        if not 10<=len(loadout)<=14: issues.append(f"SIGNATURE_LOADOUT_SIZE_INVALID:{len(loadout)}")
        compiled_ledger=load(build/"Character_Master_Ledger.json")
        issues+=item_module().validate_ledger(compiled_ledger,"complete")
        imp=load(build/"Character_Import_Surface.json")
        for f in ("ac_active","hp_current","hp_max","technique_attack_bonus","save_dc","pb","speed_ft","primary_resource_current","primary_resource_max"):
            if not isinstance(imp.get(f),int): issues.append(f"VISIBLE_SCALAR_INVALID:{f}")
        for f in ("ability_scores","ability_modifiers","saving_throws","skills"):
            if not isinstance(imp.get(f),dict) or any(not isinstance(v,int) for v in imp.get(f,{}).values()): issues.append(f"SCALAR_MAP_INVALID:{f}")
        issues+=scan(imp)
    return fail("COMMAND_5",issues) if issues else ok("COMMAND_5")


def phase6(ws):
    """Validate local ZIP-import simulation only. This phase cannot self-certify real user acceptance."""
    base=phase5(ws); issues=[] if base["verdict"].startswith("PASS") else list(base["issues"])
    ev=ws/"GM_Render_Evidence"; req=["render_proof.json","render_scrape.json","tab_blocker_report.json","save_reload_comparison.json"]
    issues += [f"MISSING_EVIDENCE:{x}" for x in req if not (ev/x).is_file()]
    if not issues:
        proof=load(ev/"render_proof.json")
        if proof.get("verdict")!="PASS_HF05ZUI_R2K3_LOCAL_IMPORT_SIMULATION": issues.append(f"LOCAL_SIMULATION_FAILED:{proof.get('verdict')}")
        if proof.get("evidence_class")!="local_consumer_simulation": issues.append(f"EVIDENCE_CLASS_INVALID:{proof.get('evidence_class')}")
        if not proof.get("actual_zip_input_exercised"): issues.append("ACTUAL_ZIP_INPUT_NOT_EXERCISED")
        if not proof.get("save_reload_preserved"): issues.append("SAVE_RELOAD_NOT_PRESERVED")
        if proof.get("missing_tabs"): issues.append(f"MISSING_TABS:{proof['missing_tabs']}")
        if proof.get("blockers"): issues.extend([f"RENDER_BLOCKER:{x}" for x in proof["blockers"]])
        projection=(proof.get("acceptance_export_contract") or {}).get("projection_fidelity")
        if not isinstance(projection,dict) or projection.get("passed") is not True:
            issues.append(f"PROJECTION_FIDELITY_FAILED:{projection}")
        expected=load(ws/"Build"/"GM_Screen_Tab_Expectation_Manifest.json").get("expected_counts",{})
        actual=proof.get("model",{}).get("counts",{})
        mapping={"level_rows":"levels","spheres":"spheres","talents":"talents","actions":"actions","composites":"composites","training_sources":"training_sources","recorded_arts":"manuals","forged_techniques":"forged","preserved_forged_expressions":"preserved_forged","emergency_technique_seeds":"seeds","immortal_arts":"immortal_arts","equipment":"equipment","states":"states"}
        for expected_key,actual_key in mapping.items():
            if expected.get(expected_key)!=actual.get(actual_key): issues.append(f"RENDER_COUNT_MISMATCH:{expected_key}:{expected.get(expected_key)}!={actual.get(actual_key)}")
    return fail("COMMAND_6_LOCAL_SIMULATION",issues) if issues else ok("COMMAND_6_LOCAL_SIMULATION")


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--phase",type=int,choices=range(1,7),required=True); ap.add_argument("--workspace",type=Path,required=True); ap.add_argument("--output",type=Path)
    a=ap.parse_args(); fn={1:phase1,2:phase2,3:phase3,4:phase4,5:phase5,6:phase6}[a.phase]; result=fn(a.workspace)
    out=a.output or a.workspace/"Validation"/f"Command_{a.phase}.validation.json"; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2)); return 0 if result["verdict"].startswith("PASS") else 2
if __name__=="__main__": raise SystemExit(main())
