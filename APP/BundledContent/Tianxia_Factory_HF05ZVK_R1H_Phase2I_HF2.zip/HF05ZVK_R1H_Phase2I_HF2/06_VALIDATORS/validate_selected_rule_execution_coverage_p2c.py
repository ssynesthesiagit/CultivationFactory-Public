#!/usr/bin/env python3
"""Universal selected-rule execution coverage validation and legacy projections."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any

MODES=('action','modifier','state','resource','procedure','passive_statistic','permission_or_record_only')
CATEGORY_FROM_FEATURE={'path_feature':'path_feature','subpath_feature':'subpath_feature','cultivation_insight':'cultivation_insight','item_feature':'item_feature','species_feature':'species_feature','companion_feature':'companion_feature','background_feature':'other_feature','origin_feature':'other_feature','method_feature':'other_feature','foundation_feature':'other_feature','other_feature':'other_feature'}

def arr(v): return v if isinstance(v,list) else []
def obj(v): return v if isinstance(v,dict) else {}
def nonempty(v): return isinstance(v,str) and bool(v.strip())
def is_none(v): return isinstance(v,dict) and v.get('status') in {'none_acquired','not_applicable','not_selected_for_this_build','unavailable_until_later_cl'}

def collect_selected_rules(L:dict[str,Any])->dict[str,dict[str,Any]]:
    out={}
    def add(sid,name,cat,cl,packets,row):
        if not sid: return
        out[str(sid)]={'source_rule_id':str(sid),'source_rule_name':str(name or sid),'source_rule_category':cat,'gained_at_cl':int(cl or 1),'source_packet_ids':arr(obj(row).get('source_packet_ids')),'row':row}
    bo=obj(L.get('background_origin')); bg=obj(bo.get('background')); ori=obj(bo.get('origin_insight'))
    add(bg.get('background_id'),bg.get('name'),'background',1,bg.get('source_packet_ids'),bg)
    add(ori.get('origin_insight_id'),ori.get('name'),'origin_insight',1,ori.get('source_packet_ids'),ori)
    for r in arr(L.get('subpaths')): add(r.get('subpath_id'),r.get('name'),'subpath',r.get('selected_at_cl',3),r.get('source_packet_ids'),r)
    for r in arr(L.get('cultivation_insights')): add(r.get('insight_id'),r.get('name'),'cultivation_insight',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    for r in arr(L.get('spheres')): add(r.get('sphere_id'),r.get('name'),'sphere',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    for r in arr(L.get('talents')): add(r.get('talent_id'),r.get('name'),'talent',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    for r in arr(L.get('features')): add(r.get('feature_id'),r.get('name'),CATEGORY_FROM_FEATURE.get(r.get('category'),'other_feature'),r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    m=L.get('method'); f=L.get('foundation')
    if not is_none(m): m=obj(m); add(m.get('method_id'),m.get('name'),'method',m.get('gained_at_cl'),m.get('source_packet_ids'),m)
    if not is_none(f): f=obj(f); add(f.get('foundation_id'),f.get('name'),'foundation',f.get('gained_at_cl'),f.get('source_packet_ids'),f)
    for r in arr(L.get('equipment')): add(r.get('equipment_id'),r.get('name'),'item',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    item_ledger=obj(L.get('equipment_ledger_r2')); item_cov={x.get('instance_id'):x for x in arr(obj(L.get('item_execution_coverage')).get('items')) if isinstance(x,dict)}
    for r in arr(item_ledger.get('item_instances')):
        d=obj(r.get('definition_snapshot')); item_id=r.get('item_id'); name=d.get('name') or item_id; cov=item_cov.get(r.get('instance_id'),{})
        packet_ids=arr(cov.get('source_packet_ids')) or arr(L.get('item_source_packet_ids'))
        gained=int(cov.get('gained_at_cl') or 1)
        add(item_id,name,'item',gained,packet_ids,{**r,'source_packet_ids':packet_ids,'gained_at_cl':gained,'name':name})
    for r in arr(L.get('recorded_arts')): add(r.get('manual_technique_id'),r.get('technique_name'),'recorded_art',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    for r in arr(L.get('forged_techniques')): add(r.get('forged_id'),r.get('name'),'forged_technique',r.get('cl_learned'),r.get('source_packet_ids'),r)
    for r in arr(L.get('emergency_technique_seeds')): add(r.get('seed_id'),r.get('name'),'emergency_technique_seed',r.get('created_at_cl',r.get('gained_at_cl',1)),r.get('source_packet_ids'),r)
    for r in arr(L.get('immortal_arts')): add(r.get('immortal_art_id'),r.get('name'),'immortal_art',r.get('gained_at_cl'),r.get('source_packet_ids'),r)
    return out

def validate_ledger(L:dict[str,Any], phase:str='complete')->list[str]:
    issues=[]
    if L.get('execution_coverage_version')!='HF05ZVK-R1F.UniversalExecutionCoverage.P2C.v1': issues.append('UNIVERSAL_EXECUTION_COVERAGE_VERSION_MISSING')
    selected=collect_selected_rules(L)
    rows=arr(L.get('selected_rule_execution_coverage')); seen={}
    registries={
      'action':{r.get('action_id'):r for r in arr(L.get('actions')) if isinstance(r,dict)},
      'modifier':{r.get('modifier_id'):r for r in arr(L.get('modifiers')) if isinstance(r,dict)},
      'state':{r.get('state_id'):r for r in arr(L.get('states')) if isinstance(r,dict)},
      'resource':{r.get('resource_id'):r for r in arr(L.get('resources')) if isinstance(r,dict)},
      'procedure':{r.get('procedure_id'):r for r in arr(L.get('procedures')) if isinstance(r,dict)},
      'passive_statistic':{r.get('passive_statistic_id'):r for r in arr(L.get('passive_statistics')) if isinstance(r,dict)},
      'permission_or_record_only':{r.get('permission_record_id'):r for r in arr(L.get('permission_records')) if isinstance(r,dict)},
    }
    for i,row in enumerate(rows):
      if not isinstance(row,dict): issues.append(f'UNIVERSAL_COVERAGE_OBJECT_REQUIRED:{i}'); continue
      sid=row.get('source_rule_id'); cid=row.get('coverage_id')
      if not nonempty(cid): issues.append(f'UNIVERSAL_COVERAGE_ID_REQUIRED:{i}')
      if not nonempty(sid): issues.append(f'UNIVERSAL_COVERAGE_SOURCE_ID_REQUIRED:{i}'); continue
      if sid in seen: issues.append(f'UNIVERSAL_COVERAGE_DUPLICATE:{sid}')
      seen[sid]=row
      exp=selected.get(sid)
      if not exp: issues.append(f'UNIVERSAL_COVERAGE_UNKNOWN_SELECTED_RULE:{sid}'); continue
      for k in ('source_rule_name','source_rule_category','gained_at_cl'):
        if row.get(k)!=exp.get(k): issues.append(f'UNIVERSAL_COVERAGE_{k.upper()}_MISMATCH:{sid}:{row.get(k)}!={exp.get(k)}')
      if set(arr(row.get('source_packet_ids'))) != set(exp.get('source_packet_ids') or []): issues.append(f'UNIVERSAL_COVERAGE_PACKET_MISMATCH:{sid}')
      status=row.get('coverage_status')
      if phase=='planned' and status not in {'planned','complete','suppressed','not_yet_available'}: issues.append(f'UNIVERSAL_COVERAGE_STATUS_INVALID:{sid}:{status}')
      if phase=='complete' and status not in {'complete','suppressed','not_yet_available'}: issues.append(f'UNIVERSAL_COVERAGE_NOT_COMPLETE:{sid}:{status}')
      mappings=arr(row.get('mappings'))
      if not mappings: issues.append(f'UNIVERSAL_COVERAGE_MAPPING_REQUIRED:{sid}')
      modes=[]
      for j,m in enumerate(mappings):
        if not isinstance(m,dict): issues.append(f'UNIVERSAL_COVERAGE_MAPPING_OBJECT_REQUIRED:{sid}:{j}'); continue
        mode=m.get('mode'); modes.append(mode)
        if mode not in MODES: issues.append(f'UNIVERSAL_COVERAGE_MODE_INVALID:{sid}:{mode}'); continue
        tids=arr(m.get('target_ids'))
        if not tids: issues.append(f'UNIVERSAL_COVERAGE_TARGET_REQUIRED:{sid}:{mode}')
        if not nonempty(m.get('effect_summary')): issues.append(f'UNIVERSAL_COVERAGE_EFFECT_SUMMARY_REQUIRED:{sid}:{mode}')
        if not arr(m.get('display_surfaces')): issues.append(f'UNIVERSAL_COVERAGE_DISPLAY_REQUIRED:{sid}:{mode}')
        if phase=='complete' and status=='complete':
          for tid in tids:
            target=registries[mode].get(tid)
            if not target: issues.append(f'UNIVERSAL_COVERAGE_TARGET_UNRESOLVED:{sid}:{mode}:{tid}'); continue
            provenance=set(arr(target.get('source_rule_ids')))
            if mode=='resource': provenance |= set(arr(target.get('source_grant_ids')))
            if sid not in provenance: issues.append(f'UNIVERSAL_COVERAGE_PROVENANCE_MISSING:{sid}:{mode}:{tid}')
      if row.get('mechanical_effects_present') is True and status=='complete' and modes and set(modes)=={'permission_or_record_only'}:
        for m in mappings:
          for tid in arr(m.get('target_ids')):
            rec=registries['permission_or_record_only'].get(tid,{})
            if rec.get('record_type') in {'record_only','identity','relationship','ownership'}:
              issues.append(f'UNIVERSAL_COVERAGE_MECHANIC_REDUCED_TO_RECORD_ONLY:{sid}:{tid}')
      if phase=='complete' and status=='complete':
        if arr(row.get('unmapped_effects')): issues.append(f'UNIVERSAL_COVERAGE_UNMAPPED_EFFECTS:{sid}')
        assertions=obj(row.get('assertions'))
        for key in ('all_rule_components_mapped','no_prose_only_mechanics','reviewed_against_source'):
          if assertions.get(key) is not True: issues.append(f'UNIVERSAL_COVERAGE_ASSERTION_FALSE:{sid}:{key}')
    missing=sorted(set(selected)-set(seen))
    if missing: issues.append('UNIVERSAL_COVERAGE_MISSING:'+','.join(missing))
    for kind,reg in registries.items():
      ids=[x for x in reg if x]
      if len(ids)!=len(set(ids)): issues.append(f'UNIVERSAL_RUNTIME_ID_DUPLICATE:{kind}')
    return sorted(set(issues))

def project_legacy(L:dict[str,Any], category:str)->list[dict[str,Any]]:
    rows=[]
    for r in arr(L.get('selected_rule_execution_coverage')):
      if r.get('source_rule_category')!=category: continue
      ms=arr(r.get('mappings')); modes=[m.get('mode') for m in ms]
      priority=['action','modifier','state','procedure','resource','passive_statistic','permission_or_record_only']
      mode=next((x for x in priority if x in modes),'permission_or_record_only')
      cls={'action':'standalone_action','modifier':'action_modifier','state':'state_modifier','procedure':'noncombat_procedure','resource':'pure_passive_stat','passive_statistic':'pure_passive_stat','permission_or_record_only':'pure_passive_stat'}[mode]
      def ids(mo): return [tid for m in ms if m.get('mode')==mo for tid in arr(m.get('target_ids'))]
      rows.append({'source_id':r.get('source_rule_id'),'source_name':r.get('source_rule_name'),'classification':cls,'action_ids':ids('action'),'target_action_ids':ids('modifier'),'state_ids':ids('state'),'stat_targets':ids('passive_statistic')+ids('resource')+ids('permission_or_record_only'),'display_surface':'; '.join(arr(r.get('display_surfaces'))),'source_packet_ids':arr(r.get('source_packet_ids')),'coverage_note':r.get('coverage_note'),'generated_from':'selected_rule_execution_coverage'})
    return rows

def main()->int:
 ap=argparse.ArgumentParser();ap.add_argument('--ledger',type=Path,required=True);ap.add_argument('--phase',choices=['planned','complete'],default='complete');ap.add_argument('--output',type=Path)
 a=ap.parse_args();L=json.loads(a.ledger.read_text(encoding='utf-8'));issues=validate_ledger(L,a.phase);out={'schema':'HF05ZVK-R1F.UniversalExecutionCoverageValidation.P2C.v1','phase':a.phase,'pass':not issues,'issue_count':len(issues),'issues':issues,'selected_rule_count':len(collect_selected_rules(L)),'coverage_count':len(arr(L.get('selected_rule_execution_coverage')))}
 if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(out,indent=2));return 0 if not issues else 1
if __name__=='__main__':raise SystemExit(main())
