#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

EXPECTED={'tianxia.path.qi_cultivation':80,'tianxia.path.body_refining':42,'tianxia.path.spirit_awakening':34}
LEVELS=[3,6,10,14,18]

def sha(path):
 h=hashlib.sha256();
 with open(path,'rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--factory-root',default=str(Path(__file__).resolve().parents[1])); ap.add_argument('--json-out')
 args=ap.parse_args(); root=Path(args.factory_root)
 p=root/'09_RULES/Indexes/Subpaths/Tianxia_Subpath_Tradition_Index_Master_P2B.json'
 d=json.loads(p.read_text(encoding='utf-8')); issues=[]; entries=d.get('entries',[])
 ids=[e.get('canonical_id') for e in entries]
 if len(entries)!=156:issues.append(f'entry_count={len(entries)} expected=156')
 if len(set(ids))!=len(ids):issues.append('duplicate canonical IDs')
 counts={k:0 for k in EXPECTED}
 feature_ids=[]
 for e in entries:
  pid=e.get('owning_path_id'); counts[pid]=counts.get(pid,0)+1
  levels=[x.get('granted_at_cl') for x in e.get('feature_progression',[])]
  if levels!=LEVELS:issues.append(f'{e.get("canonical_id")}: levels {levels}')
  if not e.get('linked_procedure_modules'):issues.append(f'{e.get("canonical_id")}: no linked procedures')
  if e.get('prerequisites',{}).get('minimum_cl')!=3:issues.append(f'{e.get("canonical_id")}: minimum_cl not 3')
  src=e.get('source',{}); local=root/src.get('factory_source_path','')
  if not local.exists():issues.append(f'{e.get("canonical_id")}: missing source {local}')
  else:
   if sha(local)!=src.get('source_file_sha256'):issues.append(f'{e.get("canonical_id")}: source hash mismatch')
   lines=local.read_text(encoding='utf-8').splitlines()
   a=src.get('line_start',0)-1;b=src.get('line_end',0)
   sec='\n'.join(lines[a:b]).rstrip()+'\n'
   if hashlib.sha256(sec.encode()).hexdigest()!=src.get('section_sha256'):issues.append(f'{e.get("canonical_id")}: section hash mismatch')
  for f in e.get('feature_progression',[]):feature_ids.append(f.get('canonical_id'))
 for k,v in EXPECTED.items():
  if counts.get(k)!=v:issues.append(f'{k}: count={counts.get(k)} expected={v}')
 if len(set(feature_ids))!=len(feature_ids):issues.append('duplicate feature IDs')
 # Parent links must resolve.
 for e in entries:
  rel=e.get('parent_variant_relationship')
  if rel and rel.get('parent_canonical_id') not in set(ids):issues.append(f'{e["canonical_id"]}: unresolved parent {rel.get("parent_canonical_id")}')
 result={'schema':'HF05ZVK-R1F.SubpathIndexValidation.P2B.v1','pass':not issues,'entry_count':len(entries),'counts_by_path':counts,'feature_count':len(feature_ids),'issues':issues}
 if args.json_out:Path(args.json_out).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result,indent=2)); return 0 if not issues else 1
if __name__=='__main__':raise SystemExit(main())
