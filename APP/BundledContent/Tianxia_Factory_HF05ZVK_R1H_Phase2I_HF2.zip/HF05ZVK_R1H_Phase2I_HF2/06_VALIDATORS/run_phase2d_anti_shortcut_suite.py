#!/usr/bin/env python3
from __future__ import annotations
import copy, importlib.util, json, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'06_VALIDATORS/validate_selected_rule_execution_coverage.py';spec=importlib.util.spec_from_file_location('v',p);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
GOOD=json.loads((ROOT/'08_FIXTURES/GOOD_Authoritative_CL13/Character_Master_Ledger.json').read_text())

def mutate(name,fn,expect):
 d=copy.deepcopy(GOOD);fn(d);issues=v.validate_ledger(d,'complete');ok=any(expect in x for x in issues);return {'test':name,'pass':ok,'expected_issue_fragment':expect,'issues':issues[:20]}

tests=[]
tests.append(mutate('missing_path_feature',lambda d:d['features'].__setitem__(slice(None),[x for x in d['features'] if x.get('feature_id')!='tianxia.path.qi_cultivation.feature.qi_sensing']),'PATH_FEATURE_SET_MISMATCH'))
tests.append(mutate('missing_path_coverage',lambda d:d['selected_rule_execution_coverage'].__setitem__(slice(None),[x for x in d['selected_rule_execution_coverage'] if x.get('source_rule_id')!='tianxia.path.qi_cultivation.feature.qi_sensing']),'PATH_FEATURE_COVERAGE_MISSING'))
tests.append(mutate('false_path_manifest',lambda d:d['feature_coverage_manifest']['path_feature_coverage'][0]['expected_feature_ids'].pop(),'PATH_FEATURE_MANIFEST_FALSE_ASSERTION'))
tests.append(mutate('missing_subpath_feature',lambda d:d['features'].__setitem__(slice(None),[x for x in d['features'] if x.get('feature_id')!='tianxia.subpath.qi.cinder_heart_cultivator.feature.heart_of_the_forge']),'SUBPATH_FEATURE_SET_MISMATCH'))
tests.append(mutate('unknown_insight',lambda d:d['cultivation_insights'][0].__setitem__('insight_id','insight.not-real'),'INSIGHT_INDEX_UNKNOWN'))
tests.append(mutate('missing_insight_coverage',lambda d:d['selected_rule_execution_coverage'].__setitem__(slice(None),[x for x in d['selected_rule_execution_coverage'] if x.get('source_rule_id')!='insight.meridian-economy']),'INSIGHT_COVERAGE_MISSING'))
tests.append(mutate('source_cl_missing',lambda d:d['selected_rule_execution_coverage'][0].pop('source_cl',None),'SOURCE_CL_STRUCTURED_FIELD_MISSING'))
tests.append(mutate('source_cl_export_omission',lambda d:d['source_cl_realm_suppression_export']['rule_exports'].pop(),'SOURCE_CL_EXPORT_SET_MISMATCH'))
tests.append(mutate('suppression_minimum_falsified',lambda d:d['selected_rule_execution_coverage'][0]['realm_suppression'].__setitem__('minimum_effective_cl',20),'REALM_SUPPRESSION_MINIMUM_CL_MISMATCH'))
def permission_only(d):
 r=next(x for x in d['selected_rule_execution_coverage'] if x.get('source_rule_id')=='tianxia.subpath.qi.cinder_heart_cultivator.feature.heart_of_the_forge');r['mappings']=[{'effect_component_id':'FAKE','mode':'permission_or_record_only','effect_summary':'fake','target_ids':['PERM_SUBPATH_CINDER_HEART_SELECTION'],'display_surfaces':['Rules & Permissions'],'required_at_runtime':True}]
tests.append(mutate('mechanic_permission_only',permission_only,'ANTI_SHORTCUT_MECHANIC_PERMISSION_ONLY'))
# Companion checks use the companion-positive fixture.
C=json.loads((ROOT/'08_FIXTURES/GOOD_COMPANION_COVERAGE/Character_Master_Ledger.json').read_text())
def cmut(name,fn,expect):
 d=copy.deepcopy(C);fn(d);issues=v.validate_ledger(d,'complete');return {'test':name,'pass':any(expect in x for x in issues),'expected_issue_fragment':expect,'issues':issues[:20]}
tests.append(cmut('companion_feature_missing',lambda d:d['features'].__setitem__(slice(None),[x for x in d['features'] if x.get('category')!='companion_feature']),'COMPANION_FEATURE_SET_MISMATCH'))
tests.append(cmut('companion_action_missing',lambda d:d['actions'].__setitem__(slice(None),[x for x in d['actions'] if x.get('action_id')!='ACT_COMP_ARCHIVE_EMBER']),'COMPANION_ACTION_UNRESOLVED'))
out={'schema':'HF05ZVK-R1F.AntiShortcutSuite.P2D.v1','pass':all(x['pass'] for x in tests),'passed':sum(x['pass'] for x in tests),'total':len(tests),'tests':tests}
print(json.dumps(out,indent=2));(ROOT/'11_AUDIT/PHASE2D_ANTI_SHORTCUT_SUITE.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(0 if out['pass'] else 1)
