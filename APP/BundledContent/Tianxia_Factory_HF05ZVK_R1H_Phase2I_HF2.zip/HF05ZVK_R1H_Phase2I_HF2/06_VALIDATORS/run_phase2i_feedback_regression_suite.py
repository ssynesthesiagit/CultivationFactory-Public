#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, importlib.util, json, shutil, subprocess, sys, tempfile
from pathlib import Path


def load(p:Path): return json.loads(p.read_text(encoding='utf-8'))
def run_cmd(cmd,timeout=240):
 cp=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
 try: payload=json.loads(cp.stdout)
 except Exception: payload={'stdout':cp.stdout[-4000:],'stderr':cp.stderr[-2000:]}
 return cp.returncode,payload

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--factory-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();root=a.factory_root.resolve()
 compiler=root/'05_COMPILER/compile_character.py'; corpus=root/'09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip'; fixtures=root/'08_FIXTURES/PHASE2I_PRODUCTION_FEEDBACK'
 results=[]
 with tempfile.TemporaryDirectory(prefix='phase2i_feedback_') as raw:
  td=Path(raw)
  # Original An Eui must fail on the displaced action-card field.
  src=fixtures/'AnEui_Original'; out=td/'an_original'
  rc,p=run_cmd([sys.executable,str(compiler),'--ledger',str(src/'Character_Master_Ledger.json'),'--rules-packets',str(src/'Rules_Selection_Packets.json'),'--corpus',str(corpus),'--output',str(out)])
  blocker=p.get('blocker','')
  results.append({'case':'an_eui_original_field_displacement_rejected','passed':rc!=0 and blocker=='ACTION_FIELD_DISPLACEMENT_FAILURE_LOOKS_DURATION:ACT_TEMPERED_RESPONSE_FLOWING','returncode':rc,'blocker':blocker})
  # Repaired An Eui must compile and preserve typed variable cost/provenance.
  src=fixtures/'AnEui_Repaired'; out=td/'an_repaired'
  rc,p=run_cmd([sys.executable,str(compiler),'--ledger',str(src/'Character_Master_Ledger.json'),'--rules-packets',str(src/'Rules_Selection_Packets.json'),'--corpus',str(corpus),'--output',str(out)],360)
  sem=load(out/'Semantic_Validation_Report.json') if (out/'Semantic_Validation_Report.json').exists() else {}
  actions=load(out/'Complete_Action_Surface.json').get('actions',[]) if (out/'Complete_Action_Surface.json').exists() else []
  stamina=next((x for x in actions if x.get('action_id')=='ACT_STAMINA_GUARD'),{})
  typed=any(x.get('resource_id')=='RES_STAMINA' and x.get('amount')==1 and x.get('maximum_amount')==3 and x.get('selection_required') is True for x in stamina.get('resource_costs',[]))
  false_provenance=[x for x in sem.get('issues',[]) if x.get('code')=='TALENT_ACTION_PROVENANCE_MISSING']
  level_rows=load(out/'Leveling_Ledger.json').get('level_rows',[]) if (out/'Leveling_Ledger.json').exists() else []
  cl4=next((x for x in level_rows if x.get('cl')==4 or x.get('CL')==4),{})
  cl4_choice='Ability Score Improvement: +1 Dexterity, +1 Constitution'
  results.append({'case':'an_eui_repaired_compiles','passed':rc==0 and p.get('verdict')=='PASS_HF05ZVK_R1F_COMPILE','returncode':rc,'verdict':p.get('verdict')})
  results.append({'case':'an_eui_cl4_advancement_choice_projected','passed':cl4.get('asi_or_insight_choice')==cl4_choice and any(x.get('event_type')=='ability_score_improvement' and x.get('ability_score_adjustments')=={'DEX':1,'CON':1} for x in cl4.get('advancement_choices',[])),'row':cl4})
  results.append({'case':'an_eui_variable_stamina_cost_typed','passed':typed,'resource_costs':stamina.get('resource_costs')})
  results.append({'case':'an_eui_source_id_provenance_no_false_positive','passed':not false_provenance,'false_findings':false_provenance})
  # Bai Meizhen must compile; all producing actions must survive in created_by_ids.
  src=fixtures/'BaiMeizhen'; out=td/'bai'
  rc,p=run_cmd([sys.executable,str(compiler),'--ledger',str(src/'Character_Master_Ledger.json'),'--rules-packets',str(src/'Rules_Selection_Packets.json'),'--corpus',str(corpus),'--output',str(out)],360)
  states=load(out/'State_Effect_Registry.json').get('states',[]) if (out/'State_Effect_Registry.json').exists() else []
  acts=load(out/'Complete_Action_Surface.json').get('actions',[]) if (out/'Complete_Action_Surface.json').exists() else []
  producers={s.get('state_id'):sorted(a.get('action_id') for a in acts if s.get('state_id') in a.get('creates_states',[])) for s in states}
  bad=[];multi=0
  for s in states:
   expected=producers.get(s.get('state_id'),[]); actual=sorted(s.get('created_by_ids',[]))
   if len(expected)>1: multi+=1
   if expected!=actual or (expected and s.get('created_by') not in expected):bad.append({'state_id':s.get('state_id'),'expected':expected,'actual':actual,'primary':s.get('created_by')})
  results.append({'case':'bai_meizhen_compiles','passed':rc==0 and p.get('verdict')=='PASS_HF05ZVK_R1F_COMPILE','returncode':rc,'verdict':p.get('verdict')})
  results.append({'case':'bai_meizhen_multi_producer_state_provenance','passed':multi>=5 and not bad,'multi_producer_states':multi,'mismatches':bad})
  # Command 1 must replay Sphere diversity at the actual acquisition CL.
  base=root/'08_FIXTURES/GOOD_Authoritative_CL13'; ws=td/'sphere_history';ws.mkdir();shutil.copy2(base/'Character_Master_Ledger.json',ws/'Character_Master_Ledger.json')
  for n in ('Command_1','Command_2','Command_3','Command_4'):shutil.copytree(base/n,ws/n)
  (ws/'Validation').mkdir();plan=load(ws/'Command_1/Selection_Plan.json')
  next(x for x in plan['spheres'] if x['name']=='Sword')['gained_at_cl']=1
  (ws/'Command_1/Selection_Plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
  rc,p=run_cmd([sys.executable,str(root/'06_VALIDATORS/validate_factory_phase.py'),'--phase','1','--workspace',str(ws),'--output',str(ws/'Validation/Command_1.validation.json')])
  issues=p.get('issues',[]);caught=any(str(x).startswith('SELECTION_SPHERE_DIVERSITY_OVERRIDE_REQUIRED:CL1:') for x in issues)
  results.append({'case':'command1_historical_sphere_diversity_replayed','passed':rc!=0 and caught,'issues':issues})
  # Shipped Item Book catalog/projection timing must agree with action_type.
  cat=load(root/'09_RULES/Items/ItemCatalog_R2.json');proj=load(root/'09_RULES/Items/ItemGMProjection_R2.json');expected={'action':'Action','bonus_action':'Bonus Action','reaction':'Reaction'};mismatches=[]
  for source,items in [('catalog',cat.get('items',[])),('projection',proj.get('items',[]))]:
   for item in items:
    rows=[]
    if source=='catalog':
     mech=item.get('mechanics',{});rows=sum((mech.get(k,[]) for k in ('actions','bonus_actions','reactions')),[])
    else: rows=item.get('action_rows',[])+item.get('reaction_rows',[])
    for row in rows:
     typ=row.get('action_type') or row.get('bucket');timing=row.get('timing_text') or row.get('timing')
     if typ in expected and timing and timing!=expected[typ]:mismatches.append({'source':source,'item_id':item.get('item_id'),'action_id':row.get('action_id'),'action_type':typ,'timing':timing})
  results.append({'case':'item_projection_action_timing_consistent','passed':not mismatches,'mismatches':mismatches})
 passed=sum(1 for x in results if x['passed']);report={'schema':'HF05ZVK-R1H.Phase2IProductionFeedbackRegression.v1','verdict':'PASS_HF05ZVK_R1H_PHASE2I_PRODUCTION_FEEDBACK_REGRESSION' if passed==len(results) else 'FAIL_HF05ZVK_R1H_PHASE2I_PRODUCTION_FEEDBACK_REGRESSION','passed':passed,'total':len(results),'results':results}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2));return 0 if passed==len(results) else 2
if __name__=='__main__':raise SystemExit(main())
