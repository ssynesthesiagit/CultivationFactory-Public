#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
from typing import Any

SCHEMA='HF05ZVK-R1F.SemanticValidationReport.v1'
CONTRACT='HF05ZVK-R1F.SemanticContract.v1'
SEVERITY_ORDER={'critical':0,'high':1,'medium':2,'low':3,'info':4}
ROOT=Path(__file__).resolve().parents[1]
FOUNDATION_CATALOG_PATH=ROOT/'09_RULES'/'Foundation_Runtime'/'Authoritative_Foundations_v0_4B.json'

def load(p:Path): return json.loads(p.read_text(encoding='utf-8'))
def sha_bytes(b:bytes): return hashlib.sha256(b).hexdigest()
def _cross_runtime_canonical(value:Any):
    """Normalize JSON numbers so Python and JavaScript hash the same semantic value.

    JSON.parse/JSON.stringify collapses integral decimals such as 20.0 to 20.
    Factory semantic hashes must bind the value that the browser consumer reads,
    not Python's incidental float spelling.
    """
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, list):
        return [_cross_runtime_canonical(v) for v in value]
    if isinstance(value, dict):
        return {k:_cross_runtime_canonical(v) for k,v in value.items()}
    return value

def sha_json(x:Any):
    canonical=_cross_runtime_canonical(x)
    return sha_bytes(json.dumps(canonical,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def arr(v): return v if isinstance(v,list) else []
def obj(v): return v if isinstance(v,dict) else {}
def norm(v): return re.sub(r'[^a-z0-9]+',' ',str(v or '').lower()).strip()
def alltext(v):
    if isinstance(v,str): return v
    if isinstance(v,list): return ' '.join(alltext(x) for x in v)
    if isinstance(v,dict): return ' '.join(alltext(x) for x in v.values())
    return str(v or '')
def to_int(v):
    try: return int(str(v).strip())
    except Exception: return None

def path_get(root:Any,path:str):
    cur=root
    tokens=re.findall(r'[^.\[\]]+|\[(\d+)\]',path)
    for part in tokens:
        token=part[0] if isinstance(part,tuple) else part
        if token=='': continue
        if isinstance(cur,list): cur=cur[int(token)]
        elif isinstance(cur,dict): cur=cur[token]
        else: raise KeyError(path)
    return cur

def source_packet_index(registry:dict)->dict:
    return {str(x.get('packet_id')):x for x in arr(registry.get('packets')) if isinstance(x,dict) and x.get('packet_id')}

def issue(out:list,code:str,message:str,severity='high',source_id=None,requirement_id=None,paths=None):
    out.append({'severity':severity,'code':code,'message':message,'source_id':source_id,'requirement_id':requirement_id,'paths':paths or []})

def selected_sources(L:dict):
    rows=[]
    def add(t,idv,row):
        if isinstance(row,dict) and idv: rows.append((t,str(idv),row))
    for x in arr(L.get('spheres')): add('sphere',x.get('sphere_id'),x)
    for x in arr(L.get('talents')): add('talent',x.get('talent_id'),x)
    for x in arr(L.get('features')): add('feature',x.get('feature_id'),x)
    if obj(L.get('method')) and not L['method'].get('none'): add('method',L['method'].get('method_id'),L['method'])
    if obj(L.get('foundation')) and not L['foundation'].get('none'): add('foundation',L['foundation'].get('foundation_id'),L['foundation'])
    for x in arr(L.get('equipment')): add('equipment',x.get('equipment_id'),x)
    for x in arr(L.get('recorded_arts')): add('recorded_art',x.get('manual_technique_id'),x)
    for x in arr(L.get('forged_techniques')): add('forged_technique',x.get('forged_id'),x)
    for x in arr(L.get('immortal_arts')): add('immortal_art',x.get('immortal_art_id'),x)
    return rows

def id_sets(L:dict):
    return {
      'sphere':{x.get('sphere_id') for x in arr(L.get('spheres'))},
      'talent':{x.get('talent_id') for x in arr(L.get('talents'))},
      'feature':{x.get('feature_id') for x in arr(L.get('features'))},
      'equipment':{x.get('equipment_id') for x in arr(L.get('equipment'))},
      'resource':{x.get('resource_id') for x in arr(L.get('resources'))},
      'state':{x.get('state_id') for x in arr(L.get('states'))},
      'action':{x.get('action_id') for x in arr(L.get('actions'))},
      'recorded_art':{x.get('manual_technique_id') for x in arr(L.get('recorded_arts'))},
      'forged_technique':{x.get('forged_id') for x in arr(L.get('forged_techniques'))},
      'composite':{x.get('composite_id') for x in arr(L.get('composites'))},
      'immortal_art':{x.get('immortal_art_id') for x in arr(L.get('immortal_arts'))},
    }
def action_map(L): return {x.get('action_id'):x for x in arr(L.get('actions')) if isinstance(x,dict) and x.get('action_id')}
def state_map(L): return {x.get('state_id'):x for x in arr(L.get('states')) if isinstance(x,dict) and x.get('state_id')}
def resource_map(L): return {x.get('resource_id'):x for x in arr(L.get('resources')) if isinstance(x,dict) and x.get('resource_id')}

def validate_requirement(req,L,packets,issues):
    rid=str(req.get('requirement_id') or ''); kind=req.get('kind'); source_id=req.get('source_id')
    if not rid: issue(issues,'SEMANTIC_REQUIREMENT_ID_REQUIRED','Requirement is missing requirement_id','critical',source_id); return
    if not kind: issue(issues,'SEMANTIC_REQUIREMENT_KIND_REQUIRED',f'{rid} is missing kind','critical',source_id,rid); return
    refs=arr(req.get('source_packet_ids'))
    if not refs: issue(issues,'SEMANTIC_REQUIREMENT_SOURCE_REQUIRED',f'{rid} has no source packet','high',source_id,rid)
    for ref in refs:
        if ref not in packets: issue(issues,'SEMANTIC_REQUIREMENT_SOURCE_UNKNOWN',f'{rid} references unknown packet {ref}','critical',source_id,rid)
    ids=id_sets(L); amap=action_map(L); smap=state_map(L); rmap=resource_map(L)
    if kind=='prerequisite':
        minimum=req.get('minimum_cl'); actual=req.get('acquired_at_cl')
        if actual is None:
            for _,sid,row in selected_sources(L):
                if sid==source_id: actual=row.get('gained_at_cl',row.get('cl_learned'))
        if not isinstance(minimum,int) or not isinstance(actual,int) or actual<minimum:
            issue(issues,'PREREQUISITE_NOT_MET',f'{source_id} acquired at CL{actual}; minimum is CL{minimum}','critical',source_id,rid)
    elif kind=='choice':
        value=req.get('selected_value'); allowed=arr(req.get('allowed_values'))
        if value in (None,'',[],{}): issue(issues,'MANDATORY_CHOICE_UNRESOLVED',f'{rid} has no selected value','critical',source_id,rid)
        elif allowed and value not in allowed: issue(issues,'MANDATORY_CHOICE_ILLEGAL',f'{rid} selected {value!r}; allowed {allowed!r}','critical',source_id,rid)
    elif kind=='grant':
        t=req.get('grant_type'); target=req.get('grant_id')
        if target not in ids.get(t,set()): issue(issues,'MANDATORY_GRANT_MISSING',f'{rid} requires {t}:{target}','critical',source_id,rid)
    elif kind=='scalar':
        p=req.get('target_path'); expected=req.get('expected_value')
        try: actual=path_get(L,p)
        except Exception: actual=None
        if actual!=expected: issue(issues,'SEMANTIC_SCALAR_MISMATCH',f'{rid}: {p} is {actual!r}; expected {expected!r}','critical',source_id,rid,[p])
    elif kind=='execution':
        action_ids=arr(req.get('action_ids')); state_ids=arr(req.get('state_ids')); resource_ids=arr(req.get('resource_ids'))
        if not action_ids and not state_ids and not resource_ids and not arr(req.get('stat_paths')):
            issue(issues,'EXECUTION_REQUIREMENT_EMPTY',f'{rid} names no execution destination','critical',source_id,rid)
        for aid in action_ids:
            if aid not in amap: issue(issues,'EXECUTION_ACTION_MISSING',f'{rid} requires action {aid}','critical',source_id,rid)
        for sid in state_ids:
            if sid not in smap: issue(issues,'EXECUTION_STATE_MISSING',f'{rid} requires state {sid}','critical',source_id,rid)
        for xid in resource_ids:
            if xid not in rmap: issue(issues,'EXECUTION_RESOURCE_MISSING',f'{rid} requires resource {xid}','critical',source_id,rid)
        hay=' '.join(alltext(amap.get(x,{})) for x in action_ids)+' '+' '.join(alltext(smap.get(x,{})) for x in state_ids)+' '+' '.join(alltext(rmap.get(x,{})) for x in resource_ids)
        for term in arr(req.get('required_terms')):
            if norm(term) not in norm(hay): issue(issues,'EXECUTION_REQUIRED_TERM_MISSING',f'{rid} does not visibly reproduce required term: {term}','high',source_id,rid)
        for p in arr(req.get('stat_paths')):
            try: path_get(L,p)
            except Exception: issue(issues,'EXECUTION_STAT_TARGET_MISSING',f'{rid} requires statistic {p}','critical',source_id,rid,[p])
    elif kind=='resource_state':
        resource_id=req.get('resource_id'); state_id=req.get('state_id'); producers=arr(req.get('producer_action_ids')); consumers=arr(req.get('consumer_action_ids'))
        if resource_id not in rmap: issue(issues,'RESOURCE_STATE_RESOURCE_MISSING',f'{rid}: {resource_id} missing','critical',source_id,rid)
        if state_id and state_id not in smap: issue(issues,'RESOURCE_STATE_STATE_MISSING',f'{rid}: {state_id} missing','critical',source_id,rid)
        for aid in producers:
            a=amap.get(aid)
            if not a: issue(issues,'RESOURCE_STATE_PRODUCER_MISSING',f'{rid}: producer {aid} missing','critical',source_id,rid); continue
            gain_ids={x.get('resource_id') for x in arr(a.get('resource_gains')) if isinstance(x,dict)}
            if resource_id not in gain_ids: issue(issues,'RESOURCE_PRODUCER_GAIN_MISSING',f'{aid} does not gain {resource_id}','critical',source_id,rid)
            if state_id and state_id not in arr(a.get('creates_states')): issue(issues,'RESOURCE_PRODUCER_STATE_MISSING',f'{aid} does not create {state_id}','high',source_id,rid)
        for aid in consumers:
            a=amap.get(aid)
            if not a: issue(issues,'RESOURCE_STATE_CONSUMER_MISSING',f'{rid}: consumer {aid} missing','critical',source_id,rid); continue
            cost_ids={x.get('resource_id') for x in arr(a.get('resource_costs')) if isinstance(x,dict)}
            if resource_id not in cost_ids: issue(issues,'RESOURCE_CONSUMER_COST_MISSING',f'{aid} does not spend {resource_id}','critical',source_id,rid)
            if state_id and state_id not in arr(a.get('consumes_states')): issue(issues,'RESOURCE_CONSUMER_STATE_MISSING',f'{aid} does not consume {state_id}','high',source_id,rid)
    elif kind=='initial_value':
        resource_id=req.get('resource_id'); expected=req.get('expected_current'); actual=obj(rmap.get(resource_id)).get('current')
        if actual!=expected: issue(issues,'INITIAL_RESOURCE_VALUE_ILLEGAL',f'{resource_id} current {actual!r}; expected {expected!r}','critical',source_id,rid)
    elif kind=='drawback':
        aid=req.get('action_id'); a=amap.get(aid)
        if not a: issue(issues,'DRAWBACK_ACTION_MISSING',f'{rid} action {aid} missing','critical',source_id,rid)
        for sid in arr(req.get('required_state_ids')):
            if sid not in arr(obj(a).get('requires_states')): issue(issues,'DRAWBACK_REQUIRED_STATE_NOT_ENFORCED',f'{aid} does not require {sid}','critical',source_id,rid)
    elif kind=='equipment_authority':
        eid=req.get('equipment_id'); row=next((x for x in arr(L.get('equipment')) if x.get('equipment_id')==eid),None)
        if not row: issue(issues,'EQUIPMENT_REQUIRED_MISSING',f'{eid} missing','critical',source_id,rid)
        elif req.get('mechanical_profile_required') and not obj(row.get('mechanical_authority')).get('approved'):
            issue(issues,'EQUIPMENT_AUTHORITY_MISSING',f'{eid} has no approved mechanical authority','critical',source_id,rid)
    elif kind=='typed_reference':
        t=req.get('target_type'); target=req.get('target_id')
        if target not in ids.get(t,set()): issue(issues,'TYPED_REFERENCE_UNRESOLVED',f'{t}:{target} is unresolved','critical',source_id,rid)
    elif kind=='foundation_runtime':
        for xid in arr(req.get('required_resource_ids')):
            if xid not in ids['resource']: issue(issues,'FOUNDATION_RESOURCE_MISSING',f'{rid} requires {xid}','critical',source_id,rid)
        for xid in arr(req.get('required_action_ids')):
            if xid not in ids['action']: issue(issues,'FOUNDATION_ACTION_MISSING',f'{rid} requires {xid}','critical',source_id,rid)
        for xid in arr(req.get('state_ids')):
            if xid not in ids['state']: issue(issues,'FOUNDATION_STATE_MISSING',f'{rid} requires {xid}','critical',source_id,rid)
    elif kind=='composite_dependency':
        cid=req.get('composite_id'); row=next((x for x in arr(L.get('composites')) if x.get('composite_id')==cid),None)
        if not row: issue(issues,'COMPOSITE_REQUIRED_MISSING',f'{cid} missing','critical',source_id,rid)
        else:
            for aid in arr(req.get('action_ids')):
                if aid not in set(arr(row.get('component_action_ids'))+arr(row.get('action_ids'))): issue(issues,'COMPOSITE_DEPENDENCY_MISSING',f'{cid} omits {aid}','critical',source_id,rid)

def foundation_catalog_index():
    try: d=load(FOUNDATION_CATALOG_PATH)
    except Exception: return {}
    out={}
    for f in arr(d.get('foundations')):
        for key in (f.get('foundation_id'),f.get('name')):
            if key: out[norm(key)]=f
    return out

def attained_stage_keys(stage):
    n=norm(stage)
    order=['common','awakened','integrated','refined','perfected']
    idx=0
    for i,k in enumerate(order):
        if k in n: idx=i
    return set(order[:idx+1])

def foundation_checks(L,issues):
    f=obj(L.get('foundation'))
    if not f or f.get('none'): return
    index=foundation_catalog_index(); row=index.get(norm(f.get('foundation_id'))) or index.get(norm(f.get('name')))
    sid=f.get('foundation_id') or f.get('name')
    if not row:
        issue(issues,'FOUNDATION_NOT_IN_AUTHORITATIVE_RUNTIME_CATALOG',f'{f.get("name")} is not one of the 30 authoritative playable Foundations','critical',sid)
        return
    if obj(row.get('profile')).get('status')!='Stable' or obj(row.get('profile')).get('primary_path')=='Chakra':
        issue(issues,'THEORETICAL_FOUNDATION_NOT_PLAYABLE',f'{f.get("name")} is theoretical and cannot be finalized','critical',sid)
        return
    catres=obj(row.get('resource')); resource_name=catres.get('name')
    if resource_name:
        candidates=[x for x in arr(L.get('resources')) if norm(x.get('name'))==norm(resource_name)]
        embedded=obj(f.get('foundation_resource'))
        if embedded and norm(embedded.get('name'))==norm(resource_name): candidates.append(embedded)
        if not candidates:
            issue(issues,'FOUNDATION_CATALOG_RESOURCE_MISSING',f'{f.get("name")} requires resource {resource_name}','critical',sid)
        else:
            current_values={x.get('current') for x in candidates if x.get('current') is not None}
            max_values={x.get('max') for x in candidates if x.get('max') is not None}
            start=to_int(catres.get('starting')); maximum=to_int(catres.get('maximum'))
            if start is not None and any(v!=start for v in current_values):
                issue(issues,'FOUNDATION_STARTING_RESOURCE_CONTRADICTION',f'{resource_name} must start at {start}; candidate values are {sorted(current_values,key=str)}','critical',sid)
            if maximum is not None and any(v!=maximum for v in max_values):
                issue(issues,'FOUNDATION_RESOURCE_MAX_CONTRADICTION',f'{resource_name} maximum must be {maximum}; candidate values are {sorted(max_values,key=str)}','critical',sid)
    # Every catalog feature at an attained stage must map by name or visible complete text.
    attained=attained_stage_keys(f.get('stage'))
    expected=[]
    for stage,features in obj(row.get('features')).items():
        if norm(stage) in attained:
            expected += arr(features)
    runtime_hay=norm(alltext(L.get('actions'))+' '+alltext(f)+' '+alltext(L.get('states'))+' '+alltext(L.get('resources')))
    for feat in expected:
        name=feat.get('name')
        if name and norm(name) not in runtime_hay:
            issue(issues,'FOUNDATION_ATTAINED_FEATURE_NOT_IMPLEMENTED',f'{f.get("name")} attained feature {name} is absent from runtime records','critical',sid,paths=['foundation','actions'])
    lifecycle=obj(f.get('lifecycle_coverage'))
    required=['passive_chassis','resources','actions_reactions','states','burdens','hidden_injuries','strains','deviations','integration','repair','treatment','temptations','failure_consequences']
    for key in required:
        rec=lifecycle.get(key)
        if not isinstance(rec,dict) or rec.get('status') not in {'present','none_in_source','not_yet_available','suppressed_by_specific_rule'}:
            issue(issues,'FOUNDATION_LIFECYCLE_CATEGORY_UNRESOLVED',f'{f.get("name")} lifecycle category {key} is not explicitly resolved','high',sid,paths=[f'foundation.lifecycle_coverage.{key}'])

def derived_fixture_loadout(L):
    rows=[]
    role_order=['immortal_art','forged_technique','recorded_art','sphere_talent','foundation','method','basic','system']
    actions=[x for x in arr(L.get('actions')) if isinstance(x,dict) and x.get('action_id')]
    actions.sort(key=lambda a:(role_order.index(a.get('classification')) if a.get('classification') in role_order else 99,str(a.get('action_id'))))
    for i,a in enumerate(actions[:14],1):
        rows.append({'action_id':a['action_id'],'role':a.get('classification') or a.get('bucket') or 'combat','priority':i,'when_to_use':a.get('gm_use') or a.get('effect') or 'Use when legal and tactically appropriate.','fixture_generated':True})
    return rows[:14]

def evidence_hashes(L):
    advancement_keys=['character','core_stats','background_origin','advancement','spheres','talents','features','method','foundation','equipment','training_sources','recorded_arts']
    execution_keys=['resources','states','actions','forged_techniques','emergency_technique_seeds','immortal_arts','composites','dao_i_ching','ai_behavior','selected_rule_execution_coverage','modifiers','procedures','passive_statistics','permission_records','signature_loadout']
    return {'advancement_semantic_sha256':sha_json({k:L.get(k) for k in advancement_keys}), 'execution_semantic_sha256':sha_json({k:L.get(k) for k in execution_keys})}

def automatic_checks(L,registry,issues,strict=True):
    packets=arr(registry.get('packets'))
    declared=registry.get('packet_count')
    if isinstance(declared,int) and declared!=len(packets): issue(issues,'RULE_PACKET_COUNT_MISMATCH',f'packet_count says {declared}; registry contains {len(packets)}','high',paths=['Rules_Selection_Packets.json'])
    if not strict:
        return
    try:
        import importlib.util
        p=Path(__file__).resolve().parent/'validate_selected_rule_execution_coverage.py'
        spec=importlib.util.spec_from_file_location('hf05zvk_cov_sem',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
        for finding in mod.validate_ledger(L,'complete'): issue(issues,finding,finding,'critical',paths=['selected_rule_execution_coverage'])
    except Exception as e: issue(issues,'UNIVERSAL_COVERAGE_VALIDATOR_EXCEPTION',str(e),'critical')
    amap=action_map(L); smap=state_map(L); rmap=resource_map(L); ids=id_sets(L)
    # State provenance is ID-driven. Multiple producers are legitimate, but the
    # primary creator and complete producer set must be explicit after compilation.
    for sid,state in smap.items():
        producers=sorted(aid for aid,a in amap.items() if sid in arr(a.get('creates_states')))
        primary=state.get('created_by')
        if primary not in producers:
            issue(issues,'STATE_PRIMARY_CREATOR_INVALID',f'{sid} primary creator {primary} does not create the state','high',sid,paths=[primary] if primary else [])
        declared=arr(state.get('created_by_ids'))
        if declared and sorted(set(declared))!=producers:
            issue(issues,'STATE_PRODUCER_SET_MISMATCH',f'{sid} declares {sorted(set(declared))} but producers are {producers}','medium',sid,paths=producers)
    for aid,a in amap.items():
        cost_text=str(a.get('cost',''))
        match=re.search(r'\bspend\s+(\d+)\s*[–—-]\s*(\d+)\s+([A-Za-z][A-Za-z -]*?)(?:[.;,]|$)',cost_text,re.I)
        if match:
            low,high=int(match.group(1)),int(match.group(2)); typed=arr(a.get('resource_costs'))
            if not any(isinstance(x,dict) and x.get('amount')==low and x.get('maximum_amount')==high and x.get('selection_required') is True for x in typed):
                issue(issues,'VARIABLE_RESOURCE_COST_NOT_TYPED',f'{aid} advertises {low}–{high} spend without matching typed range','high',aid,paths=[aid])
    # Parse explicit CL prerequisites from selected source packets and record text.
    pindex=source_packet_index(registry)
    for typ,sid,row in selected_sources(L):
        if typ not in {'talent','recorded_art','forged_technique','immortal_art'}: continue
        acquired=row.get('gained_at_cl',row.get('cl_learned'))
        texts=[alltext(row)]
        selected_name=str(row.get('name') or row.get('technique_name') or '')
        for pid in arr(row.get('source_packet_ids')):
            packet_text=alltext(pindex.get(pid,{}))
            if selected_name:
                pos=norm(packet_text).find(norm(selected_name))
                if pos>=0:
                    # Packet can contain an entire Sphere. Inspect only the selected entry's nearby rule block.
                    packet_text=packet_text[max(0,pos-200):pos+1400]
                else:
                    packet_text=''
            texts.append(packet_text)
        minima=set()
        for txt in texts:
            for m in re.finditer(r'(?:prerequisite\s*[:\-]?\s*(?:cl|cultivation level)\s*|minimum\s+(?:cl|cultivation level)\s*|requires?\s+(?:cl|cultivation level)\s*)(\d{1,2})',txt,re.I):
                minima.add(int(m.group(1)))
        for minimum in sorted(minima):
            if isinstance(acquired,int) and acquired<minimum:
                issue(issues,'AUTO_PRINTED_PREREQUISITE_NOT_MET',f'{typ}:{sid} acquired at CL{acquired}; printed minimum CL{minimum}','critical',sid)
    # New Sphere selections must be explicitly resolved; generic empty choices are blockers.
    for sph in arr(L.get('spheres')):
        sid=sph.get('sphere_id'); acquired=sph.get('gained_at_cl')
        if acquired is None: continue
        for field in ('key_ability_expression','base_selection','base_grants','skill_selection','practice_selection'):
            if field in sph and sph.get(field) in (None,'',[],{}):
                issue(issues,'SPHERE_ACQUISITION_CHOICE_UNRESOLVED',f'{sph.get("name")} leaves {field} unresolved','critical',sid,paths=[f'spheres.{sid}.{field}'])
    # Coverage requires actual destinations and provenance.
    for cov in arr(L.get('talent_execution_coverage')):
        sid=cov.get('source_id') or cov.get('talent_id') or cov.get('source_grant_id')
        dest=arr(cov.get('destination_ids'))+arr(cov.get('action_ids'))+arr(cov.get('state_ids'))+arr(cov.get('resource_ids'))+arr(cov.get('stat_paths'))
        if cov.get('coverage_status') in {'complete','covered','pass'} and not dest:
            issue(issues,'TALENT_COVERAGE_HAS_NO_EXECUTION_DESTINATION',f'{sid} is marked complete without an execution destination','critical',sid)
        for aid in arr(cov.get('action_ids')):
            a=amap.get(aid)
            if not a: issue(issues,'TALENT_COVERAGE_ACTION_MISSING',f'{sid} references absent action {aid}','critical',sid); continue
            applied=set(arr(a.get('applied_talent_ids'))+arr(a.get('source_talent_ids'))+arr(a.get('source_grant_ids')))
            if sid not in applied and cov.get('source_name') not in applied:
                issue(issues,'TALENT_ACTION_PROVENANCE_MISSING',f'{aid} does not identify applied talent {sid}','medium',sid,paths=[aid])
    f=obj(L.get('foundation'))
    for xid in arr(f.get('reserved_destination_ids')):
        if xid not in ids['state']|ids['action']|ids['resource']:
            issue(issues,'FOUNDATION_RESERVED_DESTINATION_MISSING',f'Foundation reserves {xid}, but no runtime record exists','critical',f.get('foundation_id'),paths=['foundation.reserved_destination_ids'])
    for r in arr(L.get('resources')):
        tx=norm(alltext(r))
        if r.get('current',0)>0 and ('generated once' in tx or 'generated after' in tx or 'starts at 0' in tx) and not r.get('initial_value_authority'):
            issue(issues,'AUTO_ILLEGAL_INITIAL_RESOURCE',f'{r.get("resource_id")} begins at {r.get("current")} despite generated/empty-start language','critical',r.get('resource_id'))
    # Resource/state pairing and bidirectional creator/spender checks.
    for rid,r in rmap.items():
        matching=[sid for sid,s in smap.items() if norm(s.get('name'))==norm(r.get('name')) or norm(r.get('name')) in norm(s.get('name'))]
        if not matching: continue
        sid=matching[0]
        for aid,a in amap.items():
            gains={x.get('resource_id') for x in arr(a.get('resource_gains')) if isinstance(x,dict)}
            costs={x.get('resource_id') for x in arr(a.get('resource_costs')) if isinstance(x,dict) and x.get('amount',0)>0}
            if rid in gains and sid not in arr(a.get('creates_states')): issue(issues,'AUTO_RESOURCE_STATE_CREATE_MISSING',f'{aid} gains {rid} but does not create {sid}','high',rid,paths=[aid])
            if rid in costs and sid not in arr(a.get('consumes_states')): issue(issues,'AUTO_RESOURCE_STATE_CONSUME_MISSING',f'{aid} spends {rid} but does not consume {sid}','high',rid,paths=[aid])
    for e in arr(L.get('equipment')):
        mechanics=any((e.get(k) not in (None,0,'',False,[])) for k in ('ac_contribution','attack_bonus','damage','save_dc','resource_modifier'))
        if (e.get('custom_design') or e.get('custom')) and mechanics:
            auth=obj(e.get('mechanical_authority'))
            if auth.get('approved') is not True or not auth.get('profile_id'):
                issue(issues,'AUTO_CUSTOM_EQUIPMENT_AUTHORITY_INSUFFICIENT',f'{e.get("equipment_id")} has custom mechanics without approved mechanical_authority','critical',e.get('equipment_id'))
    for fgt in arr(L.get('forged_techniques')):
        a=amap.get(fgt.get('action_id'),{}); hay=norm(alltext(a)); execution=norm(alltext(fgt.get('execution')))
        for db in arr(fgt.get('drawbacks')):
            name=norm(obj(db).get('name')); consequence=norm(obj(db).get('consequence'))
            if 'preparation' in name or 'require' in consequence:
                required=arr(obj(db).get('required_state_ids'))
                action_required=arr(a.get('requires_states'))
                if not required and not action_required: issue(issues,'AUTO_FORGED_PREPARATION_NOT_ENFORCED',f'{fgt.get("forged_id")} claims a preparation drawback without a required state','critical',fgt.get('forged_id'))
                for sid in required:
                    if sid not in action_required: issue(issues,'AUTO_FORGED_PREPARATION_STATE_MISSING',f'{fgt.get("action_id")} does not enforce {sid}','critical',fgt.get('forged_id'))
            if 'concentration' in name and 'concentration' not in hay+execution: issue(issues,'AUTO_FORGED_CONCENTRATION_NOT_ENFORCED',f'{fgt.get("forged_id")} concentration drawback is not visible in execution','critical',fgt.get('forged_id'))
            if ('short rest' in name or 'long rest' in name) and not any(x in hay+execution for x in ('short rest','long rest')): issue(issues,'AUTO_FORGED_REST_LIMIT_NOT_ENFORCED',f'{fgt.get("forged_id")} rest limit is not visible in execution','critical',fgt.get('forged_id'))
    talent_ids=ids['talent']; foundation_id=f.get('foundation_id')
    for aid,a in amap.items():
        for tid in arr(a.get('applied_talent_ids')):
            if tid not in talent_ids: issue(issues,'ACTION_APPLIED_TALENT_UNRESOLVED',f'{aid} applied_talent_ids contains non-talent {tid}','high',tid,paths=[aid])
        for fid in arr(a.get('applied_foundation_ids')):
            if fid!=foundation_id: issue(issues,'ACTION_APPLIED_FOUNDATION_UNRESOLVED',f'{aid} references unknown Foundation {fid}','high',fid,paths=[aid])
    # Composite dependencies must resolve and be temporally feasible.
    for comp in arr(L.get('composites')):
        cid=comp.get('composite_id'); sequence=arr(comp.get('component_action_ids')) or arr(comp.get('action_ids'))
        for aid in sequence:
            if aid not in amap: issue(issues,'COMPOSITE_ACTION_UNRESOLVED',f'{cid} references missing action {aid}','critical',cid)
        if comp.get('temporal_feasibility') in (None,'',{},[]): issue(issues,'COMPOSITE_TEMPORAL_FEASIBILITY_MISSING',f'{cid} lacks temporal feasibility','high',cid)
    foundation_checks(L,issues)

def run(ledger:dict,registry:dict,workspace:Path|None=None):
    issues=[]; mode=ledger.get('build_mode','production'); contract=obj(ledger.get('semantic_contract')); packets=source_packet_index(registry)
    if mode!='acceptance_fixture':
        if contract.get('contract_version')!=CONTRACT: issue(issues,'SEMANTIC_CONTRACT_MISSING',f'Production ledger must use {CONTRACT}','critical',paths=['semantic_contract'])
        requirements=arr(contract.get('requirements')); coverage=arr(contract.get('selected_rule_coverage'))
        req_ids={x.get('requirement_id') for x in requirements if isinstance(x,dict)}
        coverage_map={(x.get('source_type'),str(x.get('source_id'))):x for x in coverage if isinstance(x,dict)}
        for typ,sid,row in selected_sources(ledger):
            cov=coverage_map.get((typ,sid))
            if not cov: issue(issues,'SELECTED_RULE_SEMANTIC_COVERAGE_MISSING',f'{typ}:{sid} has no semantic coverage record','critical',sid); continue
            listed=arr(cov.get('requirement_ids'))
            if not listed and cov.get('no_additional_requirements') is not True: issue(issues,'SELECTED_RULE_REQUIREMENT_EMPTY',f'{typ}:{sid} has neither requirements nor an explicit no-additional-requirements review','high',sid)
            if cov.get('no_additional_requirements') is True and (not cov.get('review_note') or not arr(cov.get('reviewed_source_packet_ids'))): issue(issues,'NO_REQUIREMENTS_REVIEW_INCOMPLETE',f'{typ}:{sid} no-requirements claim lacks packet review evidence','high',sid)
            for rid in listed:
                if rid not in req_ids: issue(issues,'SEMANTIC_COVERAGE_REQUIREMENT_UNRESOLVED',f'{typ}:{sid} references missing requirement {rid}','critical',sid,rid)
        for req in requirements:
            if isinstance(req,dict): validate_requirement(req,ledger,packets,issues)
        sig=arr(ledger.get('signature_loadout') or contract.get('signature_loadout'))
    else:
        requirements=[]; sig=derived_fixture_loadout(ledger)
    if not 10<=len(sig)<=14: issue(issues,'SIGNATURE_LOADOUT_SIZE_INVALID',f'Signature Loadout has {len(sig)} entries; expected 10–14','high',paths=['signature_loadout'])
    aids=id_sets(ledger)['action']; seen=set()
    for row in sig:
        aid=obj(row).get('action_id')
        if aid not in aids: issue(issues,'SIGNATURE_LOADOUT_ACTION_UNRESOLVED',f'Signature Loadout references {aid}','critical',aid)
        if aid in seen: issue(issues,'SIGNATURE_LOADOUT_DUPLICATE',f'Signature Loadout repeats {aid}','medium',aid)
        seen.add(aid)
    if mode!='acceptance_fixture':
        expected=evidence_hashes(ledger); bindings=obj(contract.get('evidence_bindings'))
        for k,v in expected.items():
            if bindings.get(k)!=v: issue(issues,'STALE_EVIDENCE_BINDING',f'{k} is stale or missing','critical',paths=['semantic_contract.evidence_bindings'])
    automatic_checks(ledger,registry,issues,strict=(mode!='acceptance_fixture'))
    counts={s:sum(1 for i in issues if i['severity']==s) for s in SEVERITY_ORDER}; blockers=[i for i in issues if i['severity'] in {'critical','high'}]
    return {'schema':SCHEMA,'factory':'HF05ZVK-R1F','semantic_contract':CONTRACT,'character_id':obj(ledger.get('character')).get('character_id'),'character_name':obj(ledger.get('character')).get('name'),'build_mode':mode,'ledger_sha256':sha_json(ledger),'rules_packets_sha256':sha_json(registry),'evidence_bindings':evidence_hashes(ledger),'signature_loadout':sig,'foundation_catalog':{'schema':'HF05ZVK-R1F.AuthoritativeFoundationRuntimeCatalog.v1','playable_count':30,'theoretical_chakra_excluded':True},'verdict':'PASS_HF05ZVK_R1F_SEMANTIC_VALIDATION' if not blockers else 'FAIL_HF05ZVK_R1F_SEMANTIC_VALIDATION','release_ready':not blockers,'counts':counts,'issues':sorted(issues,key=lambda x:(SEVERITY_ORDER.get(x['severity'],9),x['code'],str(x.get('source_id')))),'checks':{'selected_sources':len(selected_sources(ledger)),'requirements':len(requirements),'signature_loadout':len(sig),'automatic_checks_enabled':True,'foundation_runtime_catalog':30}}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--ledger',type=Path,required=True); ap.add_argument('--packets',type=Path,required=True); ap.add_argument('--workspace',type=Path); ap.add_argument('--output',type=Path)
    a=ap.parse_args(); report=run(load(a.ledger),load(a.packets),a.workspace)
    if a.output: a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False)); return 0 if report['release_ready'] else 2
if __name__=='__main__': raise SystemExit(main())
