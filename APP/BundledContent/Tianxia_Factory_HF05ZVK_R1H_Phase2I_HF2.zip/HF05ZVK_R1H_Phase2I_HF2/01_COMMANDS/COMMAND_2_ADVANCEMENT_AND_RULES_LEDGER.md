# Command 2 — Canonical Advancement and Rules Ledger

## Goal

Spend the entire prompt on rules authority and character accounting. Produce one event-sourced mechanical spine covering CL1 through the current CL. Do not dilute this pass by writing the final action library or combat prose.

## Inputs

All sealed Command 1 outputs and the authoritative rules corpus in `09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip`.

## Required work

1. Create exact, hash-sealed source packets for every selected mechanical rule. Inspiration may inform characterization, but only Tianxia rules or an explicit user directive may authorize production mechanics.
2. Reconcile the Path, legal key ability, Path hit die, Path resource, Realm, PB, and expected Path-feature schedule.
3. Build legal 27-point buy, then apply the Background adjustment only to permitted abilities. Tianxia grants no default saving-throw proficiencies.
4. Create every CL row from 1 through current CL with exact:
   - Realm and PB;
   - HP base gain, Constitution delta, other delta, and cumulative maximum;
   - base Path resource, Method/Foundation/item deltas, and cumulative maximum;
   - all acquisition events in deterministic order;
   - cumulative checkpoint hash.
5. Give every permanent grant exactly one acquisition event containing:
   - `allocation_id`;
   - `channel`;
   - `grant_type`;
   - `grant_id`;
   - exact name;
   - trained-choice `slot_cost`;
   - source packet IDs.
6. Reconcile the acquisition channels:
   - Background, Background Sphere, and Background talent are separate CL1 grants;
   - CL1 free Sphere is separate from the Background Sphere;
   - exactly one free level talent exists at every CL;
   - the CL1 free talent belongs to the CL1 free Sphere;
   - every newly trained Sphere costs one trained choice and grants exactly one free same-level talent from that Sphere;
   - trained talents belong to a Sphere already known at that level;
   - no CL spends more than three trained choices;
   - Method, Foundation, Path features, equipment, Recorded Arts, learned Forged Techniques, and Emergency Seeds each have their own event.
7. Reconcile all visible derived statistics from explicit source components:
   - every skill = linked ability modifier + PB × proficiency multiplier + explicit adjustment;
   - AC = base equipment/chassis + Dexterity applied + shield + Foundation + Method + item + other adjustments;
   - speed = base + Path + Sphere + Foundation + Method + equipment + other adjustments;
   - initiative = selected ability modifier + PB multiplier + explicit adjustment;
   - every non-primary resource names the permanent grant or equipment record that creates it.
8. Ensure the final visible HP, resource, AC, speed, initiative, saving throws, technique attack, save DC, and skill totals equal their sealed calculation records.
9. Record the complete list of expected Path feature IDs so missing chassis features cannot be hidden by a visually complete output.

## Required outputs

- `Command_2/Rules_Selection_Packets.json`
- `Command_2/Canonical_Advancement_Ledger.json`
- `Command_2/Canonical_Stats_Resource_Block.json`
- `Command_2/Advancement_Reconciliation.json`
- `Command_2/Command_2_Audit.md`
- `Character_Master_Ledger.json`
- `Validation/Command_2.validation.json`

## Hard blockers

Any source mismatch, unresolved grant, duplicate or missing allocation, missing free level talent, missing new-Sphere bonus talent, wrong trained-choice cost, incorrect point buy, HP/resource/AC/speed/initiative/skill arithmetic error, unresolved resource provenance, incorrect PB/Realm, missing Path feature, false saving-throw proficiency, absent checkpoint hash, placeholder text, or production mechanic authorized only by inspiration/original design.

## Success status

`COMMAND_2_ADVANCEMENT_LEDGER_SEALED`

## Phase 2A Path progression accounting

Use the selected Path index to populate every CL1–20 Path feature gained through the target CL. The progression table and feature canonical IDs are mandatory accounting inputs; source prose remains controlling.

## Phase 2B — Specialization Progression Accounting

For every active Path, use the selected Subpath or tradition index record to account for CL3, CL6, CL10, CL14, and CL18 feature acquisition. Variant records replace their parent progression one-for-one and cannot coexist unless an explicit later Source Rule says otherwise.

## Item Book R1 acquisition ledger

Create or update `equipment_ledger_r2`. Preserve immutable catalog definitions and mutable instances separately. Record acquisition provenance, owner, bearer, current equipped state, Attunement, charges, storage contents, durability, Item Spirit state, Growth state, and Set components. Production builds may not omit the R2 ledger. Every permanent item instance must also be entered as a zero-slot advancement allocation using `channel: item`, `grant_type: item`, the instance ID as `grant_id`, and the exact Item Book rules-packet IDs. Acquisition CL records provenance and does not replace the item's printed Source CL or Realm floor.
