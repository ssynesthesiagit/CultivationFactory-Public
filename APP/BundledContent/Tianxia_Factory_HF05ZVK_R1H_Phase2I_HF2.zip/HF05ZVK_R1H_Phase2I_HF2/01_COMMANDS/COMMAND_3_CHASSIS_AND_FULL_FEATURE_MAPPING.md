# Command 3 — Character Chassis and Full Feature Mapping

## Goal

Spend the full prompt completing every ordinary character subsystem before final combat authoring. Command 3 maps what every selected rule actually grants, where it appears, and how it will become executable. Do not yet compile the GM Screen package.

## Inputs

- sealed Command 1 blueprint;
- sealed Command 2 advancement ledger and rules packets;
- authoritative source corpus.

## Required work

1. **Background completion**
   - record all skills, tools, languages, equipment, Sphere/talent grants, ability-score options, compensation, and social hooks;
   - reconcile every printed equipment item to an equipment-ledger entry or named bundle;
   - do not silently omit tool or language proficiencies.
2. **Origin Insight fidelity**
   - decompose every printed benefit into exact source-backed effect records;
   - give each effect a trigger/condition/effect/display destination;
   - attach exact source text through a source-claim ID;
   - do not replace a printed benefit with an inferred or more convenient mechanic.
3. **Method completion**
   - record the active Primary Method, Resource Shape, Breakthrough Shape, Foundation relation, benefits, drawbacks, hooks, and exact applied math;
   - only one Primary Method applies, but all explicit Foundation and item modifiers stack with it when their Source Rules say they modify the same statistic or resource.
4. **Foundation lifecycle completion**
   - map every stage benefit available at the character's current stage;
   - map passives, resource modifiers, generated resources, actions, states, burdens, hidden injuries, strains, deviations, integration, repair, treatment, temptations, failure consequences, and excluded later-stage benefits;
   - every lifecycle category must be present or carry an explicit `none_in_source` record.
5. **Universal selected-rule execution plan**
   - create one `selected_rule_execution_coverage` row for every selected Background, Origin Insight, Path feature, Subpath feature, Cultivation Insight, Sphere, talent, Method, Foundation, item, Recorded Art, Forged Technique, Immortal Art, and other permanent rule;
   - classify each printed effect as `action`, `modifier`, `state`, `resource`, `procedure`, `passive_statistic`, or `permission_or_record_only`;
   - reserve stable action/state/procedure IDs before final action writing;
   - reserve stable IDs for every target ledger; one selected rule may use multiple coverage modes;
   - no applicable mechanic may be left for the combat AI to reconstruct from prose.
6. **Recorded Art roster**
   - select a source-backed roster appropriate to CL and character importance;
   - CL10–14 enforced floors: at least 8 for a standard complete combatant, 10 significant, 12 powerful, and 16 rival/boss unless the user explicitly directs a different roster;
   - cover at least three relevant tactical roles at CL10+;
   - identify manual/teacher/lineage source, reproduced Sphere/talent expression, acquisition CL, and intended action ID.
7. **Blueprint reconciliation**
   - compare the sealed blueprint to the developing canonical character;
   - every changed Method, Foundation, Sphere, Recorded Art, Forged Technique, equipment assumption, or combat identity must be recorded with a reason and approval status.

## Required outputs

- updated `Character_Master_Ledger.json` with complete Background, Origin, Method, Foundation, execution-coverage maps, and quality targets;
- `Command_3/Subsystem_Completion_Ledger.json`;
- `Command_3/Feature_Execution_Coverage_Plan.json`;
- `Command_3/Foundation_Lifecycle_Audit.json`;
- `Command_3/Background_Origin_Method_Audit.json`;
- `Command_3/Recorded_Art_Roster_Plan.json`;
- `Command_3/Blueprint_Deviation_Reconciliation.json`;
- `Command_3/Command_3_Audit.md`;
- `Validation/Command_3.validation.json`.

## Hard blockers

Missing printed Background grant, invented Origin mechanic, absent Method/Foundation stacking math, incomplete Foundation lifecycle category, unmapped Sphere base expression, unmapped talent, insufficient Recorded Art roster, unsourced manual, or unrecorded blueprint deviation.

## Success status

`COMMAND_3_CHASSIS_COMPLETE`

## Recorded Art expression classification

Classify every planned Recorded Art as `single_sphere_expression`, `source_authored_lineage_expression`, or `preserved_forged_expression`. Custom-generated multi-Sphere Recorded Arts are prohibited; move them into Forged Technique construction or simplify them to one Sphere.


## HF05ZVK-R1F semantic requirement

Every rule selected or changed in this command must update `semantic_contract.selected_rule_coverage`, its source-backed requirement rows, and the relevant evidence binding. A later command may not retain stale earlier evidence. Command 4 must also curate a 10–14 action `signature_loadout`. The build is blocked by any Critical or High semantic finding.

## Phase 2A complete Path feature mapping

Every Path feature through the character's CL must be represented by its Path feature canonical ID, source line range, Source CL basis, and Realm Suppression behavior from the machine-readable Path index.

## Phase 2B — Complete Specialization Mapping

Map every specialization feature using its canonical feature ID, linked procedure modules, Source CL basis, and Realm Suppression profile. The index does not convert features into Actions; classification into action, modifier, state, resource, procedure, statistic, or permission occurs during the later execution-coverage stage.



## Phase 2C — Universal execution-coverage plan

At Command 3, every selected rule must have a `planned` or already `complete` universal coverage record. A permission-only mapping is legal only when the printed rule is itself a permission, qualification, prohibition, identity, relationship, or record-only rule. Passive mechanics may not be hidden in prose.

## Item execution coverage plan

For every active Item Instance, enumerate every catalog mechanic and map it to its eventual runtime mode. Populate `item_execution_coverage` and mirror it in `feature_coverage_manifest.item_coverage`. Record all AC, attack, Speed, Resistance, resource, and Set contributions explicitly.


## Phase 2F persistent companion requirement

For every persistent spirit, Beastmaster beast, mount, construct, Item Spirit, or other companion, populate the complete `companion_record.schema.json` character sheet. Do not submit only a name, relationship sentence, or action list. Distinguish Tame creatures from full Bonded Companions and record exact command/initiative behavior.
