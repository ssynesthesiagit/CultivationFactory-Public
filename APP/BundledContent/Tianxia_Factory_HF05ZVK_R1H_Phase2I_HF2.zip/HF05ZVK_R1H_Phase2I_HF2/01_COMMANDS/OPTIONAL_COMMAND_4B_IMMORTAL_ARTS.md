# Optional Command 4B — Immortal Arts Construction

## When to use

Run this as a separate prompt only when the character legally possesses an Immortal Art, the user explicitly requests one, or an attached Immortal Arts authoring kit provides the governing rules. Ordinary characters skip this command.

## Goal

Build Dao Aspect and Immortal Art records without reducing the attention available for ordinary talent actions, Recorded Arts, Forged Techniques, composites, or Foundation mechanics.

## Required contract

- exact source authority or explicit user directive;
- Dao Aspect and prerequisites;
- acquisition and evolution state;
- complete executable action/procedure packets;
- costs, limits, counterplay, states, and behavior hooks;
- explicit separation from Recorded Arts and Forged Techniques;
- `immortal_arts_none_state` remains present when no art is known.

## Required outputs when invoked

- updated `Character_Master_Ledger.json`;
- `Command_4B/Immortal_Arts_Audit.json`;
- `Command_4B/Dao_Aspect_Audit.json`;
- `Command_4B/Command_4B_Audit.md`.

## Success status

`OPTIONAL_COMMAND_4B_IMMORTAL_ARTS_COMPLETE`

## Consumer-complete Immortal Art actions

Every linked action must be classified `immortal_art`, carry the parent `immortal_art_id`, and include the complete execution packet. The Immortal Art record must not rely on the Actions tab as the only place where the art's effect is understandable.
