# Command 1 — Source Evidence and Blueprint Lock

## Goal

Invest the full prompt in understanding the requested character, the permitted inspiration sources, and the Tianxia design space. Do not build final mechanics or a character ZIP.

## Required reading

- `00_READ_FIRST/README_FIRST.md`
- `02_CONTRACTS/RULES_AUTHORITY_AND_CONFLICT_POLICY.md`
- `09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip`
- any source restriction in the user's request

## Work sequence

1. Resolve the request: target CL, Path or desired power style, source restrictions, intended fidelity, and whether the build is an adaptation or original character.
2. Gather inspiration evidence only from permitted sources. Record chapter/page/URL evidence and distinguish direct evidence from inference.
3. Choose the combat identity, narrative identity, Path, key ability, Background, Origin Insight, Method, existing Foundation, primary Spheres, supporting Spheres, and intended combat loop.
4. Plan the number and role of meaningful actions, reactions, bonus actions, passives, Recorded Arts, composites, and Forged Techniques.
5. Plan CL1-current advancement channels without yet writing the final level ledger.
6. Identify every unresolved rules or source question. A material unresolved question blocks Command 2.

## Required outputs

- `Workspace/Command_1/Build_Request.json`
- `Workspace/Command_1/Inspiration_Source_Evidence.json`
- `Workspace/Command_1/Character_Blueprint.json`
- `Workspace/Command_1/Selection_Plan.json`
- `Workspace/Command_1/Surface_Coverage_Plan.json`
- `Workspace/Command_1/Open_Questions.json`
- `Workspace/Command_1/Command_1_Audit.md`
- `Workspace/Validation/Command_1.validation.json`

## Lock requirements

The blueprint must specify:

- stable character ID, name, title, concept, adaptation notes;
- CL, Realm, Path, key ability, PB;
- point-buy intent and final ability-score target;
- Background and its free grants;
- Origin Insight;
- separate CL1 free-Sphere grant and its CL1 free level talent; the Sphere may intentionally overlap the Background Sphere only with an explicit overlap-reconciliation record and a distinct talent;
- Method and Foundation selection or explicit legal none-state;
- primary, secondary, and utility Spheres;
- talent acquisition strategy and diversity budget;
- action inventory targets by economy;
- Recorded Art plan;
- learned Forged Technique plan and Emergency Seed policy;
- composite playbook roles;
- Dao phrase, I Ching direction, and AI combat identity;
- equipment and state/resource expectations;
- target consumer `HF05ZUI-R2K`.

## Forbidden

- no `Character_Master_Ledger.json` finalization;
- no derived GM Screen files;
- no final mechanical numbers claimed as audited;
- no silent use of disallowed inspiration sources;
- no invented Foundation when a normal build requires selecting an existing Foundation.

## Success status

`COMMAND_1_BLUEPRINT_LOCKED`

## Phase 2A Path index requirement

Record the selected Path using its canonical Path ID from `09_RULES/Indexes/Paths/Tianxia_Path_Index_Master_P2A.json`. Do not invent a Path ID or derive one from display text.

## Phase 2B — Subpath and Tradition Index Requirement

When selecting a Subpath or Spirit tradition, record its canonical ID from `09_RULES/Indexes/Subpaths/Tianxia_Subpath_Tradition_Index_Master_P2B.json`. Use the index to verify owning Path, access category, prerequisites, parent/variant relationship, and CL3 entry legality. The exact source packet must still cite the canonical compendium text.

## Item Book R1 blueprint lock

Record expected Signature Treasure, support treasures, consumables, mundane equipment, Attunement budget, intended Treasure Set participation, Item Spirit or Growth intent, and whether any item is custom or reforged. Use canonical `item_id` values from `ItemCatalog_R2.json`; Sphere Influence tags never grant Sphere ownership.


## Phase 2H inherited assurance additions

- Normalize structured Path, Background, Origin, Method, Foundation, and talent objects before comparison.
- Lock `HF05ZUI-R2K.3`, all 18 tabs, and the depth-based Recorded Art floor in Command 1.
- Include planned ability-score changes in the final target.
