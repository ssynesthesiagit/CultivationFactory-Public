# Command 6 — Consumer Verification and Release Classification

## Goal

Exercise the exact Command 5 candidate through HF05ZUI-R2K.3, identify producer or consumer defects at their owning layer, and issue an evidence-accurate, hash-bound attestation.

Command 6 **never modifies or reseals the tested candidate ZIP**. Evidence is external because adding evidence to the ZIP would create a different, untested hash.

## Local controller

```bash
python 07_TOOLS/run_command6.py \
  --factory-root . \
  --workspace Workspace \
  --candidate Workspace/<Character>_GM_Candidate.zip \
  --output Workspace/<Character>_GM_Candidate_Checked.zip
```

The output must be byte-for-byte identical to the candidate. The controller writes:

- `Command_6/Command_6_Audit.json`;
- `Command_6/Command_6_Audit.md`;
- `GM_Render_Evidence/*.json`;
- `Validation/Command_6.validation.json`.

In restricted sandboxes, direct `file://` or loopback navigation may be blocked by administrator policy. The harness therefore loads the exact unmodified app assets into a controlled browser document. This is a **local consumer simulation**, not deployed or user-environment acceptance.

## Required local proof

- exact candidate SHA-256 recorded before import;
- actual candidate ZIP bytes enter through the browser file-input/import path;
- native decompression route passes where available;
- bundled pako fallback passes with `DecompressionStream` disabled;
- all eighteen tabs exist in canonical order;
- no renderer blockers, collapsed ledgers, unresolved action components, false missing fields, or object rendering hazards;
- expected levels, Spheres, talents, actions, composites, training sources, Recorded Arts, Forged records, equipment, and states reconcile;
- compact roster serialization and rehydration preserve every normalized tab;
- the in-app acceptance generator produces its required schema and matching hash;
- released output is byte-identical to the tested candidate;
- evidence explicitly records the simulation boundary.

A passing local run receives:

`SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED`

## Real user-environment acceptance

Open the bundled GM Screen in the actual target browser, import the **exact unchanged Command 5 candidate**, run **Character Viewer → Run Acceptance Test**, and export the JSON report.

The report must contain:

- schema `HF05ZUI-R2K.RealAcceptanceReport.v1`;
- evidence class `real_gm_screen_user_acceptance`;
- verdict `PASS_REAL_GMSCREEN_ACCEPTANCE`;
- exact candidate SHA-256 and byte count;
- all eighteen tabs in canonical order;
- no blockers, missing tabs, or count mismatches;
- successful compact save/rehydration retention.

Validate it:

```bash
python 07_TOOLS/run_command6.py \
  --factory-root . \
  --workspace Workspace \
  --candidate Workspace/<Character>_GM_Candidate.zip \
  --real-acceptance-report Workspace/<Character>_HF05ZUI_R2H_Real_Acceptance.json \
  --output Workspace/<Character>_GM_Candidate_Final_Checked.zip
```

The validated report is copied to `Command_6/Validated_Real_GM_Screen_Acceptance_Report.json`. The output ZIP remains byte-identical to the accepted candidate.

## Release truth

- Static compile only: `COMMAND_5_GM_SCREEN_CANDIDATE_READY`.
- Local consumer simulation passes: `SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED`.
- Valid user-exported report matches the exact candidate: `FINAL_RELEASE_READY`.
- Screenshots, direct model injection, a simulated report, or a report for a different ZIP cannot authorize final release.


## HF05ZVK-R1F semantic requirement

Every rule selected or changed in this command must update `semantic_contract.selected_rule_coverage`, its source-backed requirement rows, and the relevant evidence binding. A later command may not retain stale earlier evidence. Command 4 must also curate a 10–14 action `signature_loadout`. The build is blocked by any Critical or High semantic finding.

## Item UI claim boundary

Do not claim live Equipment / Source readiness from static projection alone. A real current-GM-Screen ZIP import, browser render, dependent-stat verification, and save/reload check remain required after the GM Screen item surface is updated.
