# Command 4 — Executable Combat and Technique Build

## Goal

Spend the entire prompt converting the sealed advancement state and Command 3 subsystem map into a fully playable and GM-usable character. Command 4 authors the complete executable surface; it does not recalculate or silently change Commands 2–3 selections and subsystem mappings.

## Mandatory execution coverage

Before counting action quantity, resolve every row in `selected_rule_execution_coverage`. Each selected rule may map to one or more Actions, modifiers, states, resources, procedures, passive statistics, or permission/record-only records. Every target ID must exist in its canonical runtime ledger and name the selected rule in `source_rule_ids` or `source_grant_ids`. A selected rule listed only in a descriptive tab is not execution-complete. `sphere_execution_coverage` and `talent_execution_coverage` are compiler-generated compatibility projections and must not be authored independently.

## Required action packet

Every action, bonus action, reaction, activated feature, and rules-significant passive requires a stable ID and structured fields for classification, timing/trigger, cost, range, target, roll/save/check, success, failure, duration, limits, counterplay, source Spheres/talents, source packets, state creation/consumption, resource changes, and a concise GM-use instruction.

Basic/system actions do not count toward the meaningful-action minimum. A passive is not converted into a fake action merely to increase the count.

## States and resources

All referenced states and secondary resources require explicit registries. Actions may create or consume only known IDs. Resource generation, storage, spending, caps, expiration, and reset timing must be executable rather than implied. Every action must include structured `resource_costs`, `resource_gains`, and `resource_requirements` arrays, even when those arrays are intentionally empty. Each referenced resource ID must exist in the resource registry.

## Recorded Arts

Build the entire Command 3 roster; do not reduce it merely to save authoring time. Each art must describe the exact fixed Sphere/talent expression and what it does in play.
The enforced CL10–14 floors are 8 standard, 10 significant, 12 powerful, and 16 rival/boss. This larger roster remains inside Command 4 because each art is a bounded fixed expression compiled from already sealed source talents rather than a free-form Forged Technique.


Each fixed expression requires manual/technique identity, source Spheres and talents, reproduced package, linked exported action, training-DC calculation, acquisition level, source packets, complete execution, and a clear statement that the Recorded Art does not grant its source Spheres or talents. The linked action must identify the Recorded Art and match its execution packet field-for-field. When the art preserves a forged expression, record that expression separately with an explicit no-personal-slot flag and the same fixed execution.

## Forged Techniques

Keep three concepts separate:

1. personally learned Forged Techniques;
2. forged expressions preserved inside Recorded Arts;
3. Emergency Technique Seeds.

A learned technique must reconcile base and secondary Complexity, Augments, Drawbacks, final Complexity, base and adjusted CP cost, minimum CP, Realm limit, Sphere ownership at learning, PB learned-technique limit, Forging DC, research time, materials, check result, component grants/actions, acquisition event, and a complete executable packet. Drawbacks are optional. Secondary-effect CP adjustments require an explicit adjudication note and authority packet.

## Composite playbooks

Every primary sequence must contain ordered action IDs with:

- `round_offset`;
- exact action economy matching the linked action;
- required states;
- externally supplied preconditions;
- legal action/bonus/reaction use in each round;
- state establishment before consumption;
- resource budget and maximum commitment;
- success branch, conditional options, fallback, Dao hook, and I Ching hook.

“A or B” is not an executable sequence step. Put alternatives in `conditional_options`.

## Required outputs

- updated and sealed `Character_Master_Ledger.json`
- `Command_4/Executable_Action_Audit.json`
- `Command_4/Composite_Feasibility_Audit.json`
- `Command_4/Forged_Technique_Audit.json`
- `Command_4/Behavior_and_Dao_Audit.json`
- `Command_4/Command_4_Audit.md`
- `Validation/Command_4.validation.json`

## Hard blockers

Any unresolved ID, generic mechanics, unstructured action, missing source authority, invalid action economy, state used before establishment, incomplete manual, incomplete forged calculation, missing failure/counterplay, composite without fallback/resource footprint, AI reference to an unexported action, or manual alteration of Command 2 accounting.

## Success status

`COMMAND_4_EXECUTABLE_CHARACTER_COMPLETE`

## Recorded Art / Forged boundary

Before sealing each Recorded Art action, verify that its effects remain inside its declared expression kind. A custom multi-Sphere action is not an ordinary Recorded Art. It must either be simplified to a one-Sphere fixed expression or receive a complete preserved Forged Technique record.


## HF05ZVK-R1F semantic requirement

Every rule selected or changed in this command must update `semantic_contract.selected_rule_coverage`, its source-backed requirement rows, and the relevant evidence binding. A later command may not retain stale earlier evidence. Command 4 must also curate a 10–14 action `signature_loadout`. The build is blocked by any Critical or High semantic finding.


## Phase 2C — Completion assertions

Every final coverage row must be `complete`, `suppressed`, or `not_yet_available`; have no unmapped effects; and affirm that all rule components were checked against source. The compiler blocks unresolved targets, missing provenance, duplicate coverage, record-only substitution for a printed mechanic, and any selected rule without a coverage row.

## Item executable build

Compile item Actions, Bonus Actions, Reactions, procedures, charge pools, modifiers, passive statistics, permissions, and states into the universal runtime ledgers. Active item action IDs must resolve exactly. Do not leave item mechanics only inside definition prose or GM projection cards.


## Phase 2F persistent companion requirement

For every persistent spirit, Beastmaster beast, mount, construct, Item Spirit, or other companion, populate the complete `companion_record.schema.json` character sheet. Do not submit only a name, relationship sentence, or action list. Distinguish Tame creatures from full Bonded Companions and record exact command/initiative behavior.
