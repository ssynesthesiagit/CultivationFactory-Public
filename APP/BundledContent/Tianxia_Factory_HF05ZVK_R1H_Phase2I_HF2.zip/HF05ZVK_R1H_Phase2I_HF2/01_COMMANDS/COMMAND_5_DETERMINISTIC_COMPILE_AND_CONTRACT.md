# Command 5 — Deterministic Compilation and GM Contract

## Goal

Perform no new character design. Compile the sealed master ledger into all required character-package surfaces and prove static compatibility with HF05ZUI-R2K.

## Required controller

```bash
python 07_TOOLS/run_command5.py \
  --factory-root . \
  --workspace Workspace \
  --candidate Workspace/<Character>_GM_Candidate.zip
```

The controller runs the compiler, JSON Schemas, Command 5 semantic gate, checksum generation, and candidate ZIP seal.

## Required inspection

- Every compiler-only file exists.
- Every visible scalar matches `Canonical_Stats_Resource_Block.json`.
- Every source ledger row survives projection.
- Ability scores, modifiers, saves, and skills use scalar consumer maps.
- Action bucket aliases are valid.
- Composite sequences contain resolved action IDs.
- Background, Origin, Method, Foundation, Dao, I Ching, Recorded Arts, Forged Techniques, equipment, resources, states, and leveling rows are populated or carry explicit none-states.
- The expected tab manifest includes all eighteen required tabs, including the permanent Immortal Arts tab.

## Repair rule

Do not edit files in `Workspace/Build`. Repair the master ledger or compiler and rerun the entire compile.

## Required outputs

- `Workspace/Build/` compiled package directory;
- `Workspace/Command_5/Static_Contract_Audit.json`;
- `Workspace/Command_5/Command_5_Audit.md`;
- `Workspace/Validation/Command_5.validation.json`;
- candidate ZIP.

## Success status

`COMMAND_5_GM_SCREEN_CANDIDATE_READY`


## HF05ZVK-R1F semantic requirement

Every rule selected or changed in this command must update `semantic_contract.selected_rule_coverage`, its source-backed requirement rows, and the relevant evidence binding. A later command may not retain stale earlier evidence. Command 4 must also curate a 10–14 action `signature_loadout`. The build is blocked by any Critical or High semantic finding.


## Phase 2C sidecar exports

Command 5 exports `Selected_Rule_Execution_Coverage.json`, `Modifier_Ledger.json`, `Procedure_Ledger.json`, `Passive_Statistic_Ledger.json`, and `Permission_Record_Ledger.json`. Current GM Screen Sphere/Talent coverage files are generated from the universal ledger for backward compatibility.

## Item Book R1 outputs

Command 5 must export `Equipment_Ledger.json` as R2 authority, `Equipment_Ledger_Legacy.json` as temporary compatibility projection, `Item_Execution_Coverage.json`, and `Selected_Item_GM_Projection.json`. Item validation is part of the compilation gate.
