#!/usr/bin/env python3
from __future__ import annotations
import argparse, io, json, re, zipfile
from pathlib import Path

def collect(path:Path):
    out={}
    def walk(z,prefix="",depth=0):
        for info in z.infolist():
            if info.is_dir():continue
            data=z.read(info.filename);name=(prefix+info.filename).replace("\\","/")
            if info.filename.lower().endswith((".md",".txt",".json",".csv")):
                try:out[name]=data.decode("utf-8")
                except UnicodeDecodeError:pass
            elif depth<3 and info.filename.lower().endswith(".zip"):
                try:
                    with zipfile.ZipFile(io.BytesIO(data)) as nested:walk(nested,name+"::",depth+1)
                except zipfile.BadZipFile:pass
    with zipfile.ZipFile(path) as z:walk(z)
    return out

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--corpus","--needed",dest="corpus",type=Path,required=True);ap.add_argument("--query",required=True);ap.add_argument("--limit",type=int,default=20);ap.add_argument("--context",type=int,default=260);a=ap.parse_args()
    docs=collect(a.corpus);auth=json.loads(docs["_CANON_AUTHORITY_MANIFEST.json"]);allowed=set(auth.get("active_packet_sources",[]))|set(auth.get("reference_only_sources",[]));rx=re.compile(re.escape(a.query),re.I);hits=[]
    for name in sorted(allowed):
        body=docs.get(name)
        if body is None:continue
        for m in rx.finditer(body):
            start=max(0,m.start()-a.context);end=min(len(body),m.end()+a.context);hits.append({"source_path":name,"offset":m.start(),"excerpt":body[start:end].replace("\r","")})
            if len(hits)>=a.limit:break
        if len(hits)>=a.limit:break
    print(json.dumps({"corpus":str(a.corpus),"query":a.query,"hit_count":len(hits),"hits":hits},ensure_ascii=False,indent=2));return 0 if hits else 1
if __name__=="__main__":raise SystemExit(main())
