#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path

def norm(s):return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()
def main():
 ap=argparse.ArgumentParser(description='Query Tianxia Subpath/Tradition index')
 ap.add_argument('query',nargs='?'); ap.add_argument('--path',choices=['qi','body','spirit']); ap.add_argument('--access'); ap.add_argument('--cl',type=int,choices=[3,6,10,14,18]); ap.add_argument('--full',action='store_true'); ap.add_argument('--factory-root',default=str(Path(__file__).resolve().parents[1]))
 a=ap.parse_args(); root=Path(a.factory_root); d=json.loads((root/'09_RULES/Indexes/Subpaths/Tianxia_Subpath_Tradition_Index_Master_P2B.json').read_text(encoding='utf-8'))
 es=d['entries'];
 if a.path:
  pid={'qi':'tianxia.path.qi_cultivation','body':'tianxia.path.body_refining','spirit':'tianxia.path.spirit_awakening'}[a.path]; es=[e for e in es if e['owning_path_id']==pid]
 if a.access: es=[e for e in es if norm(a.access) in norm(e['access']['canonical_category']) or norm(a.access)==e['access']['tier']]
 if a.query:
  q=norm(a.query); es=[e for e in es if q in norm(e['display_name']) or any(q in norm(x) for x in e.get('aliases',[])) or q in norm(e['canonical_id']) or q in norm(json.dumps(e.get('identity',{})))]
 if a.cl:
  out=[]
  for e in es:
   f=next((x for x in e['feature_progression'] if x['granted_at_cl']==a.cl),None)
   if f: out.append({'canonical_id':e['canonical_id'],'display_name':e['display_name'],'feature':f})
  es=out
 if not a.full:
  es=[{'canonical_id':e['canonical_id'],'display_name':e['display_name'],'path':e.get('owning_path_name'),'access':e.get('access',{}).get('canonical_category'),'progression':[f'{f["granted_at_cl"]}: {f["display_name"]}' for f in e.get('feature_progression',[])]} if 'feature' not in e else e for e in es]
 print(json.dumps(es,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__':raise SystemExit(main())
