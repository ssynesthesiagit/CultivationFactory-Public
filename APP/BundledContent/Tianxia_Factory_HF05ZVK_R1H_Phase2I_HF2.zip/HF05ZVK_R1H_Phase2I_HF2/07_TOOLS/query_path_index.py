#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description='Query the Tianxia Phase 2A machine-readable Path indexes.')
    ap.add_argument('query',nargs='?',default=''); ap.add_argument('--path',choices=['body_refining','qi_cultivation','spirit_awakening']); ap.add_argument('--cl',type=int); ap.add_argument('--id'); ap.add_argument('--json',action='store_true')
    a=ap.parse_args(); root=Path(__file__).resolve().parents[1]; idxdir=root/'09_RULES/Indexes/Paths'
    files=sorted(idxdir.glob('*.path_index.p2a.json')); records=[]
    for p in files:
        obj=json.loads(p.read_text(encoding='utf-8'))
        pslug=obj['canonical_id'].split('.')[-1]
        if a.path and pslug!=a.path: continue
        if a.id:
            if obj['canonical_id']==a.id: records.append({'type':'path','record':obj})
            for f in obj['features']:
                if f['canonical_id']==a.id or any(c['canonical_id']==a.id for c in f['components']): records.append({'type':'feature','path':obj['display_name'],'record':f})
            continue
        if a.cl:
            row=next((r for r in obj['progression'] if r['cl']==a.cl),None)
            if row: records.append({'type':'progression','path':obj['display_name'],'record':row})
            continue
        q=a.query.lower().strip()
        if not q or q in obj['display_name'].lower(): records.append({'type':'path_summary','record':{'canonical_id':obj['canonical_id'],'display_name':obj['display_name'],'revision':obj['publication_revision'],'key_ability':obj['path_profile']['key_ability'],'resource':obj['resource_rules']['name']}})
        for f in obj['features']:
            hay=' '.join([f['canonical_id'],f['display_name'],f['source_rules_text']]).lower()
            if q and q in hay: records.append({'type':'feature','path':obj['display_name'],'record':f})
    if a.json: print(json.dumps(records,indent=2,ensure_ascii=False))
    else:
        for r in records:
            rec=r['record']; print(f"[{r['type']}] {r.get('path','')} {rec.get('canonical_id','')} {rec.get('display_name',rec.get('cl',''))}")
    return 0
if __name__=='__main__': raise SystemExit(main())
