#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, subprocess
from pathlib import Path


def invoke(cmd:list[str])->dict:
    cp=subprocess.run(cmd,capture_output=True,text=True)
    try: payload=json.loads(cp.stdout)
    except Exception: payload={'verdict':'TOOL_OUTPUT_PARSE_ERROR','stdout':cp.stdout,'stderr':cp.stderr,'returncode':cp.returncode}
    if cp.returncode: raise RuntimeError(json.dumps(payload,indent=2))
    return payload


def main()->int:
    ap=argparse.ArgumentParser(description='Run deterministic Command 5 compilation and candidate sealing.')
    ap.add_argument('--factory-root',type=Path,required=True)
    ap.add_argument('--workspace',type=Path,required=True)
    ap.add_argument('--candidate',type=Path,required=True)
    a=ap.parse_args(); root=a.factory_root; ws=a.workspace; audit_dir=ws/'Command_5'; audit_dir.mkdir(parents=True,exist_ok=True)
    try:
        pre_schema=invoke(['python3',str(root/'06_VALIDATORS'/'validate_json_schemas.py'),'--schemas',str(root/'04_SCHEMAS'),'--ledger',str(ws/'Character_Master_Ledger.json'),'--packets',str(ws/'Command_2'/'Rules_Selection_Packets.json')])
        prior_phases=[]
        for phase in ('1','2','3','4'):
            prior_phases.append(invoke(['python3',str(root/'06_VALIDATORS'/'validate_factory_phase.py'),'--phase',phase,'--workspace',str(ws),'--output',str(ws/'Validation'/f'Command_{phase}.validation.json')]))
        compile_result=invoke(['python3',str(root/'05_COMPILER'/'compile_character.py'),'--ledger',str(ws/'Character_Master_Ledger.json'),'--rules-packets',str(ws/'Command_2'/'Rules_Selection_Packets.json'),'--needed',str(root/'09_RULES'/'Tianxia_Canonical_Rules_Corpus_P2A.zip'),'--output',str(ws/'Build')])
        schema_result=invoke(['python3',str(root/'06_VALIDATORS'/'validate_json_schemas.py'),'--schemas',str(root/'04_SCHEMAS'),'--ledger',str(ws/'Character_Master_Ledger.json'),'--packets',str(ws/'Command_2'/'Rules_Selection_Packets.json'),'--view-model',str(ws/'Build'/'Tianxia_GM_Character_View_Model_v2.json')])
        phase_result=invoke(['python3',str(root/'06_VALIDATORS'/'validate_factory_phase.py'),'--phase','5','--workspace',str(ws),'--output',str(ws/'Validation'/'Command_5.validation.json')])
        seal_result=invoke(['python3',str(root/'07_TOOLS'/'seal_character_zip.py'),'--build',str(ws/'Build'),'--output',str(a.candidate),'--classification','COMMAND_5_GM_SCREEN_CANDIDATE_READY'])
        result={'verdict':'PASS_COMMAND_5_CONTROLLER','pre_schema':pre_schema,'prior_phases':prior_phases,'compile':compile_result,'schemas':schema_result,'phase':phase_result,'seal':seal_result}
        (audit_dir/'Static_Contract_Audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        (audit_dir/'Command_5_Audit.md').write_text(f"# Command 5 Audit\n\n- Verdict: `{result['verdict']}`\n- Candidate: `{a.candidate}`\n- Candidate SHA-256: `{seal_result.get('sha256')}`\n- Compiled files: `{compile_result.get('files')}`\n- Consumer: `HF05ZUI-R2K.3`\n\nNo derived Build file was manually edited.\n",encoding='utf-8')
        print(json.dumps(result,indent=2)); return 0
    except Exception as exc:
        result={'verdict':'FAIL_COMMAND_5_CONTROLLER','error':str(exc)}
        (audit_dir/'Static_Contract_Audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result,indent=2)); return 2
if __name__=='__main__': raise SystemExit(main())
