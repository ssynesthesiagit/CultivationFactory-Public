#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, io, json, zipfile
from pathlib import Path

def corpus(path:Path):
    out={}
    def walk(z,prefix="",depth=0):
        for info in z.infolist():
            if info.is_dir():continue
            data=z.read(info.filename);name=(prefix+info.filename).replace("\\","/")
            if info.filename.lower().endswith((".md",".txt")):
                try:out[name]=data.decode("utf-8")
                except UnicodeDecodeError:pass
            elif depth<3 and info.filename.lower().endswith(".zip"):
                try:
                    with zipfile.ZipFile(io.BytesIO(data)) as nested:walk(nested,name+"::",depth+1)
                except zipfile.BadZipFile:pass
    with zipfile.ZipFile(path) as z:
        manifest=json.loads(z.read("_CANON_AUTHORITY_MANIFEST.json").decode("utf-8"));walk(z)
    return out,set(manifest.get("active_packet_sources",[]))

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--corpus","--needed",dest="corpus",type=Path,required=True);ap.add_argument("--packet-id",required=True);ap.add_argument("--name",required=True);ap.add_argument("--source-path",required=True);ap.add_argument("--source-text-file",type=Path,required=True);ap.add_argument("--source-section",default="");ap.add_argument("--mechanical-interpretation",default="");ap.add_argument("--output",type=Path,required=True);a=ap.parse_args();excerpt=a.source_text_file.read_text(encoding="utf-8").strip();sources,active=corpus(a.corpus)
    if a.source_path not in active:raise SystemExit(f"Source path is not active packet authority: {a.source_path}")
    body=sources.get(a.source_path)
    if body is None:raise SystemExit(f"Source path not found: {a.source_path}")
    if excerpt not in body:raise SystemExit("Exact excerpt is not present in the selected source.")
    packet={"packet_id":a.packet_id,"name":a.name,"authority":"tianxia_rules","source_path":a.source_path,"source_section":a.source_section,"source_text":excerpt,"source_text_sha256":hashlib.sha256(excerpt.encode()).hexdigest(),"mechanical_interpretation":a.mechanical_interpretation}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print(json.dumps({"verdict":"PASS_RULES_PACKET_CREATED","output":str(a.output),"source_text_sha256":packet["source_text_sha256"]},indent=2));return 0
if __name__=="__main__":raise SystemExit(main())
