#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(cmd: list[str], *, expect_json: bool = True, timeout: int = 600) -> dict:
    print(f"[audit] {' '.join(cmd[:4])}", file=sys.stderr, flush=True)
    cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    payload: dict
    if expect_json:
        try:
            payload = json.loads(cp.stdout)
        except Exception:
            payload = {
                "verdict": "TOOL_OUTPUT_PARSE_ERROR",
                "stdout": cp.stdout,
                "stderr": cp.stderr,
                "returncode": cp.returncode,
            }
    else:
        payload = {
            "verdict": "PASS" if cp.returncode == 0 else "FAIL",
            "stdout": cp.stdout,
            "stderr": cp.stderr,
            "returncode": cp.returncode,
        }
    if cp.returncode:
        raise RuntimeError(json.dumps({"command": cmd, "payload": payload}, indent=2))
    return payload


def copy_fixture_source(source: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / "Character_Master_Ledger.json", target / "Character_Master_Ledger.json")
    for name in ["Command_1", "Command_2", "Command_3", "Command_4"]:
        shutil.copytree(source / name, target / name)
    if (source / "Command_4B").is_dir():
        shutil.copytree(source / "Command_4B", target / "Command_4B")
    (target / "Validation").mkdir()


def audit_lane(root: Path, fixture_name: str, work: Path, *, run_consumer: bool) -> dict:
    fixture = root / "08_FIXTURES" / fixture_name
    workspace = work / fixture_name
    copy_fixture_source(fixture, workspace)

    phases = {}
    for phase in [1, 2, 3, 4]:
        phases[str(phase)] = invoke([
            "python3", str(root / "06_VALIDATORS" / "validate_factory_phase.py"),
            "--phase", str(phase), "--workspace", str(workspace),
            "--output", str(workspace / "Validation" / f"Command_{phase}.validation.json"),
        ])

    candidate_a = work / f"{fixture_name}_candidate_a.zip"
    candidate_b = work / f"{fixture_name}_candidate_b.zip"
    command5_a = invoke([
        "python3", str(root / "07_TOOLS" / "run_command5.py"),
        "--factory-root", str(root), "--workspace", str(workspace),
        "--candidate", str(candidate_a),
    ])
    # Re-seal the same deterministic Build a second time. This isolates ZIP
    # reproducibility from the more expensive semantic compilation pass.
    command5_b = invoke([
        "python3", str(root / "07_TOOLS" / "seal_character_zip.py"),
        "--build", str(workspace / "Build"),
        "--output", str(candidate_b),
        "--classification", "COMMAND_5_GM_SCREEN_CANDIDATE_READY",
    ])
    hash_a, hash_b = sha256(candidate_a), sha256(candidate_b)
    reproducible = candidate_a.read_bytes() == candidate_b.read_bytes()
    if not reproducible:
        raise RuntimeError(f"NONDETERMINISTIC_CANDIDATE_ZIP:{fixture_name}:{hash_a}!={hash_b}")

    command6 = None
    released = None
    if run_consumer:
        released = work / f"{fixture_name}_released.zip"
        command6 = invoke([
            "python3", str(root / "07_TOOLS" / "run_command6.py"),
            "--factory-root", str(root), "--workspace", str(workspace),
            "--candidate", str(candidate_a), "--output", str(released),
        ])
        if released.read_bytes() != candidate_a.read_bytes():
            raise RuntimeError(f"COMMAND6_MUTATED_TESTED_CANDIDATE:{fixture_name}")

    return {
        "fixture": fixture_name,
        "phases": phases,
        "command5_first": command5_a,
        "command5_second": command5_b,
        "candidate_sha256": hash_a,
        "candidate_entries": command5_a.get("seal", {}).get("entries"),
        "byte_reproducible": reproducible,
        "command6": command6,
        "command6_byte_identical": None if not run_consumer else released.read_bytes() == candidate_a.read_bytes(),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the complete HF05ZVK-R1H Phase 2I static and consumer regression audit.")
    ap.add_argument("--factory-root", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--work-root", type=Path)
    ap.add_argument(
        "--consumer-lanes", choices=["none", "core", "all"], default="none",
        help="Run no browser lane, the core standard lane, or all six acceptance lanes.",
    )
    ap.add_argument("--skip-consumer", action="store_true", help="Deprecated alias for --consumer-lanes none.")
    ap.add_argument("--keep-work", action="store_true")
    args = ap.parse_args()
    root = args.factory_root.resolve()

    temp_context = None
    if args.work_root:
        work = args.work_root.resolve()
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True)
    else:
        temp_context = tempfile.TemporaryDirectory(prefix="hf05zvk_r1h_phase2i_audit_")
        work = Path(temp_context.name)

    try:
        py_compile = invoke(["python3", "-m", "compileall", "-q", str(root)], expect_json=False)
        node = shutil.which("node")
        node_check = (
            invoke([node, "--check", str(root / "10_GM_SCREEN_TARGET" / "GM_Screen_HF05ZUI_R2K" / "app.js")], expect_json=False)
            if node else {"verdict": "SKIPPED_NODE_UNAVAILABLE"}
        )
        rules_corpus = invoke([
            "python3", str(root / "06_VALIDATORS" / "validate_rules_corpus.py"),
            "--rules-root", str(root / "09_RULES"),
            "--output", str(work / "rules_corpus_validation.json"),
        ])
        rules_authority = invoke([
            "python3", str(root / "06_VALIDATORS" / "run_rules_authority_suite.py"),
            "--factory-root", str(root), "--output", str(work / "rules_authority_suite.json"),
        ])
        negative = invoke([
            "python3", str(root / "06_VALIDATORS" / "run_negative_gate_suite.py"),
            "--factory-root", str(root),
            "--fixture", str(root / "08_FIXTURES" / "GOOD_Authoritative_CL13"),
            "--output", str(work / "negative_gate_suite.json"),
        ])
        semantic_regression = invoke([
            "python3", str(root / "06_VALIDATORS" / "run_semantic_regression_suite.py"),
            "--factory-root", str(root),
            "--output", str(work / "semantic_regression_suite.json"),
        ])
        feedback_regression = invoke([
            "python3", str(root / "06_VALIDATORS" / "run_phase2i_feedback_regression_suite.py"),
            "--factory-root", str(root),
            "--output", str(work / "phase2i_feedback_regression_suite.json"),
        ], timeout=900)
        consumer_mode = "none" if args.skip_consumer else args.consumer_lanes
        lane_names = [
            "GOOD_Authoritative_CL13",
            "GOOD_CL13_No_Forged",
            "GOOD_CL13_Immortal_Art",
            "GOOD_ITEMBOOK_R1_STORAGE_RING",
            "GOOD_COMPANION_COVERAGE",
            "GOOD_BEASTMASTER_BEAST_COVERAGE",
        ]
        lanes = [
            audit_lane(root, name, work, run_consumer=(consumer_mode == "all" or (consumer_mode == "core" and name == "GOOD_Authoritative_CL13")))
            for name in lane_names
        ]
        result = {
            "schema": "HF05ZVK-R1H.FullFactoryAudit.v1",
            "verdict": "PASS_HF05ZVK_R1H_PHASE2I_FULL_FACTORY_AUDIT",
            "factory": "HF05ZVK-R1H",
            "consumer": "HF05ZUI-R2K",
            "consumer_patch": "HF05ZUI-R2K.3",
            "consumer_lanes_requested": consumer_mode,
            "consumer_simulation_exercised": consumer_mode != "none",
            "consumer_evidence_boundary": (
                "local consumer simulation only; real user-opened GM Screen acceptance still required"
                if consumer_mode != "none" else "consumer simulation skipped"
            ),
            "python_compile": py_compile,
            "javascript_check": node_check,
            "rules_corpus": rules_corpus,
            "rules_authority": rules_authority,
            "negative_gate_suite": negative,
            "semantic_regression_suite": semantic_regression,
            "phase2i_feedback_regression_suite": feedback_regression,
            "lanes": lanes,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0
    except Exception as exc:
        result = {
            "schema": "HF05ZVK-R1H.FullFactoryAudit.v1",
            "verdict": "FAIL_HF05ZVK_R1H_PHASE2I_FULL_FACTORY_AUDIT",
            "error": str(exc),
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 2
    finally:
        if temp_context is not None and not args.keep_work:
            temp_context.cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
