#!/usr/bin/env python3
"""Exercise the exact HF05ZUI-R2K.3 ZIP importer in sandboxed Chromium.

The environment may block file:// and loopback navigation, so the exact unchanged screen
assets are injected into a controlled Chromium document. The proof still exercises the
browser file input, ZIP decompression, importer, 18-tab renderer, compact save/rehydration,
and the screen's native R2K acceptance generator. It remains local consumer evidence.
"""
from __future__ import annotations
import argparse, asyncio, hashlib, json, re, shutil
from pathlib import Path
from playwright.async_api import async_playwright

TABS=["overview-core-stats","leveling-ledger","background-origin","paths-subpaths","spheres-talents","insights","actions","composite-playbooks","forged-techniques","martial-manuals-recorded-arts","immortal-arts","foundation","method","companions-spirits","equipment","resources-states-suppression","dao-i-ching","diagnostics"]
BLOCKERS=["[object Object]","Renderer Exception","LEVELING_LEDGER_SYNTHESIZED","Unresolved execution component","No linked action details recorded"]
SCRIPTS=["pako.min.js","sphere-rules.js","chakra-sphere-rules.js","foundation-catalog.js","foundation-readable-catalog.js","sphere-talent-catalog.js","background-catalog.js","insight-catalog.js","app.js","r2h-builder.js","r2h2-builder.js","r2h3-foundation-layout.js","r2h4-semantic.js","path-subpath-feature-catalog.js","r2i-phase2e.js"]
STYLES=["styles.css","r2h4-semantic.css","r2i-phase2e.css"]
SHIM="""(seed)=>{const d=new Map(Object.entries(seed||{}));const ls={getItem(k){return d.has(String(k))?d.get(String(k)):null},setItem(k,v){d.set(String(k),String(v))},removeItem(k){d.delete(String(k))},clear(){d.clear()},key(i){return [...d.keys()][i]??null},get length(){return d.size},_dump(){return Object.fromEntries(d)}};Object.defineProperty(window,'localStorage',{value:ls,configurable:true});Object.defineProperty(window,'indexedDB',{value:undefined,configurable:true})}"""

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p:Path,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
def browser_path():
    for x in ["chromium","chromium-browser","google-chrome","google-chrome-stable"]:
        y=shutil.which(x)
        if y:return y
    return None

def html(gm:Path)->str:
    s=(gm/"index.html").read_text(encoding="utf-8")
    s=re.sub(r'<script\s+src="[^"]+"[^>]*></script>','',s,flags=re.I)
    s=re.sub(r'<link\s+rel="stylesheet"[^>]*>','',s,flags=re.I)
    return s

async def boot(browser,gm:Path,force_pako=False):
    page=await browser.new_page(viewport={"width":1600,"height":1100},device_scale_factor=1)
    console=[];errors=[]
    page.on("console",lambda m:console.append({"type":m.type,"text":m.text}))
    page.on("pageerror",lambda e:errors.append(str(e)))
    await page.set_content(html(gm),wait_until="domcontentloaded")
    await page.evaluate(SHIM,{})
    for x in STYLES:await page.add_style_tag(path=str(gm/x))
    for x in SCRIPTS:await page.add_script_tag(path=str(gm/x))
    if force_pako:
        await page.evaluate("()=>{try{Object.defineProperty(window,'DecompressionStream',{value:undefined,configurable:true})}catch{window.DecompressionStream=undefined}}")
    await page.wait_for_function("typeof renderCharacterViewer==='function' && typeof state==='object' && typeof runHf05zuiR2bRealAcceptance==='function'",timeout=30000)
    return page,console,errors

async def import_zip(page,character:Path):
    await page.set_input_files("#packageFileInput",str(character))
    await page.wait_for_function("()=>state.packages?.length>0",timeout=120000)
    await page.evaluate("()=>{state.activePackageId=state.packages[0].id;setActiveTab('fight');renderCharacterViewer()}")
    await page.wait_for_function("()=>document.querySelectorAll('#activeCharacterVisualSheet [data-sheet-tab]').length===18",timeout=60000)
    return await page.evaluate("()=>state.packages[0].hf05zui_real_import")

async def collect(page,evidence:Path,screenshots:bool):
    data=await page.evaluate("""()=>{const pkg=state.packages[0],m=HF05ZUI_R2I.modelFor(pkg),root=document.getElementById('activeCharacterVisualSheet');return{identity:m.identity,counts:{levels:(m.leveling_ledger||[]).length,spheres:(m.spheres_talents?.spheres||[]).length,talents:(m.spheres_talents?.talents||[]).length,actions:(m.actions||[]).length,composites:(m.composites||[]).length,forged:(m.forged_techniques||[]).length,preserved_forged:(m.preserved_forged_expressions||[]).length,seeds:(m.emergency_technique_seeds||[]).length,immortal_arts:(m.immortal_arts||[]).length,training_sources:(m.training_sources||[]).length,manuals:(m.martial_manuals||[]).length,equipment:(m.equipment_resources_states?.equipment||[]).length,states:(m.equipment_resources_states?.states||[]).length,companions:(m.phase2e?.companions||[]).length,path_feature_groups:(m.phase2e?.manifest?.path_feature_coverage||[]).length,subpath_feature_groups:(m.phase2e?.manifest?.subpath_feature_coverage||[]).length,insight_coverage:(m.phase2e?.manifest?.insight_coverage||[]).length,item_instances:(m.phase2e?.items||[]).length,item_coverage:(m.phase2e?.manifest?.item_coverage||[]).length},sidecars:(m.phase2e?.sidecars||[]).map(x=>({name:x.name,present:x.present})),tabs:[...root.querySelectorAll('[data-sheet-tab]')].map(x=>x.dataset.sheetTab)}}""")
    tab_text={};shots=[]
    for tab in TABS:
        btn=page.locator(f'#activeCharacterVisualSheet [data-sheet-tab="{tab}"]')
        if not await btn.count():continue
        await btn.click();await page.wait_for_timeout(40)
        panel=page.locator(f'#activeCharacterVisualSheet [data-sheet-panel="{tab}"]')
        tab_text[tab]=await panel.inner_text()
        if screenshots:
            q=evidence/"screenshots"/f"{tab}.png";q.parent.mkdir(parents=True,exist_ok=True)
            await panel.screenshot(path=str(q));shots.append({"tab_id":tab,"path":f"screenshots/{q.name}","bytes":q.stat().st_size})
    alltext="\n".join(tab_text.values()).lower(); blockers=[x for x in BLOCKERS if x.lower() in alltext]
    blockers += [f"EMPTY_TAB:{t}" for t in TABS if not tab_text.get(t,"").strip()]
    return data,tab_text,sorted(set(blockers)),shots

async def run(args):
    gm=args.gm_screen.resolve();character=args.character.resolve();evidence=args.evidence.resolve();evidence.mkdir(parents=True,exist_ok=True)
    exe=browser_path()
    if not exe:
        result={"verdict":"UNAVAILABLE_HF05ZUI_R2K_LOCAL_IMPORT_SIMULATION","evidence_class":"local_consumer_simulation","reason":"No Chromium executable available","actual_zip_input_exercised":False};write(evidence/"render_proof.json",result);print(json.dumps(result,indent=2));return 3
    expected_sha=sha(character);all_console=[];all_errors=[]
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(headless=True,executable_path=exe,args=["--no-sandbox","--disable-gpu","--disable-dev-shm-usage"])
        page,console,errors=await boot(browser,gm,False);all_console+=console;all_errors+=errors
        imp=await import_zip(page,character);model,tab_text,blockers,shots=await collect(page,evidence,args.screenshots)
        acceptance=await page.evaluate("()=>runHf05zuiR2bRealAcceptance()")
        await page.close()
        p2,c2,e2=await boot(browser,gm,True);all_console+=c2;all_errors+=e2
        imp2=await import_zip(p2,character);pako_tabs=await p2.locator('#activeCharacterVisualSheet [data-sheet-tab]').count();await p2.close();await browser.close()
    console_errors=[x for x in all_console if x.get('type')=='error']
    zip1=((imp or {}).get('zip_files') or [{}])[0].get('sha256');zip2=((imp2 or {}).get('zip_files') or [{}])[0].get('sha256')
    missing=[x for x in TABS if x not in model['tabs']];extra=[x for x in model['tabs'] if x not in TABS]
    passed=(zip1==expected_sha and zip2==expected_sha and pako_tabs==18 and not missing and not extra and not blockers and acceptance.get('schema')=='HF05ZUI-R2K.RealAcceptanceReport.v1' and acceptance.get('consumer')=='HF05ZUI-R2K' and acceptance.get('consumer_patch')=='HF05ZUI-R2K.3' and acceptance.get('verdict')=='PASS_REAL_GMSCREEN_ACCEPTANCE' and acceptance.get('save_reload_preserved') is True and not console_errors and not all_errors)
    result={"schema":"HF05ZUI-R2K.LocalConsumerSimulation.v1","verdict":"PASS_HF05ZUI_R2K3_LOCAL_IMPORT_SIMULATION" if passed else "FAIL_HF05ZUI_R2K3_LOCAL_IMPORT_SIMULATION","evidence_class":"local_consumer_simulation","gm_screen":"HF05ZUI-R2K.3","candidate_filename":character.name,"candidate_sha256":expected_sha,"candidate_bytes":character.stat().st_size,"actual_zip_input_exercised":zip1==expected_sha,"native_import_sha256":zip1,"pako_import_sha256":zip2,"pako_fallback_exercised":pako_tabs==18,"tabs_present":model['tabs'],"missing_tabs":missing,"extra_tabs":extra,"blockers":blockers,"save_reload_preserved":acceptance.get('save_reload_preserved'),"model":{"identity":model['identity'],"counts":model['counts'],"sidecars":model['sidecars']},"acceptance_export_contract":acceptance,"console_errors":console_errors,"page_errors":all_errors,"screenshots":shots,"navigation_caveat":"Exact production assets were injected because file:// and loopback navigation may be blocked; normal browser ZIP input, import, render, compact save, rehydrate, and acceptance were exercised."}
    write(evidence/"render_proof.json",result)
    write(evidence/"render_scrape.json",{"tabs":model['tabs'],"tab_text":tab_text,"model":model})
    write(evidence/"tab_blocker_report.json",{"blockers":blockers,"missing_tabs":missing,"extra_tabs":extra,"console_errors":console_errors,"page_errors":all_errors})
    write(evidence/"save_reload_comparison.json",{"preserved":acceptance.get('save_reload_preserved'),"retention":acceptance.get('retention',{}),"schema":acceptance.get('schema')})
    print(json.dumps(result,indent=2));return 0 if passed else 2

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--gm-screen',type=Path,required=True);ap.add_argument('--character',type=Path,required=True);ap.add_argument('--evidence',type=Path,required=True);ap.add_argument('--screenshots',action='store_true');a=ap.parse_args();return asyncio.run(run(a))
if __name__=='__main__':raise SystemExit(main())
