#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

SIM = "SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED"
FINAL = "FINAL_RELEASE_READY"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(cmd: list[str]) -> dict:
    cp = subprocess.run(cmd, capture_output=True, text=True)
    try:
        payload = json.loads(cp.stdout)
    except Exception:
        payload = {
            "verdict": "TOOL_OUTPUT_PARSE_ERROR",
            "stdout": cp.stdout,
            "stderr": cp.stderr,
            "returncode": cp.returncode,
        }
    if cp.returncode:
        raise RuntimeError(json.dumps(payload, indent=2))
    return payload


def copy_exact(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if source.resolve() != output.resolve():
        shutil.copy2(source, output)
    if sha256(source) != sha256(output):
        raise RuntimeError("Command 6 output is not byte-for-byte identical to the tested candidate")


def main() -> int:
    ap = argparse.ArgumentParser(
        description=(
            "Exercise the exact candidate ZIP through the local consumer simulation. "
            "Command 6 never reseals or mutates the tested ZIP; release evidence is a hash-bound sidecar."
        )
    )
    ap.add_argument("--factory-root", type=Path, required=True)
    ap.add_argument("--workspace", type=Path, required=True)
    ap.add_argument("--candidate", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--gm-screen", type=Path)
    ap.add_argument("--real-acceptance-report", type=Path)
    ap.add_argument("--screenshots", action="store_true")
    a = ap.parse_args()

    root = a.factory_root
    ws = a.workspace
    gm = a.gm_screen or root / "10_GM_SCREEN_TARGET" / "GM_Screen_HF05ZUI_R2K"
    audit = ws / "Command_6"
    audit.mkdir(parents=True, exist_ok=True)
    evidence = ws / "GM_Render_Evidence"

    try:
        if not a.candidate.is_file():
            raise RuntimeError(f"Candidate ZIP missing: {a.candidate}")
        candidate_hash = sha256(a.candidate)
        proof_cmd = [
            "python3", str(root / "07_TOOLS" / "run_gm_screen_proof.py"),
            "--gm-screen", str(gm),
            "--character", str(a.candidate),
            "--evidence", str(evidence),
        ]
        if a.screenshots:
            proof_cmd.append("--screenshots")
        proof = invoke(proof_cmd)
        phase = invoke([
            "python3", str(root / "06_VALIDATORS" / "validate_factory_phase.py"),
            "--phase", "6", "--workspace", str(ws),
            "--output", str(ws / "Validation" / "Command_6.validation.json"),
        ])

        classification = SIM
        report_validation = None
        real_report_copy = None
        if a.real_acceptance_report:
            report_validation = invoke([
                "python3", str(root / "07_TOOLS" / "validate_real_gmscreen_acceptance.py"),
                "--report", str(a.real_acceptance_report),
                "--candidate", str(a.candidate),
            ])
            classification = FINAL
            real_report_copy = audit / "Validated_Real_GM_Screen_Acceptance_Report.json"
            shutil.copy2(a.real_acceptance_report, real_report_copy)

        # The tested candidate is the released character artifact. Never add evidence to it
        # after hashing, because that would create a different untested ZIP.
        copy_exact(a.candidate, a.output)
        output_hash = sha256(a.output)
        if output_hash != candidate_hash:
            raise RuntimeError("Released output hash differs from tested candidate hash")

        attestation = {
            "schema": "HF05ZVK-R1F.Command6Attestation.v1",
            "verdict": "PASS_COMMAND_6_CONTROLLER",
            "evidence_class": (
                "real_gm_screen_user_acceptance" if classification == FINAL
                else "local_consumer_simulation"
            ),
            "classification": classification,
            "candidate_zip": str(a.candidate),
            "released_zip": str(a.output),
            "candidate_sha256": candidate_hash,
            "released_sha256": output_hash,
            "byte_identical_candidate_release": True,
            "proof": proof,
            "phase": phase,
            "real_report_validation": report_validation,
            "real_report_sidecar": str(real_report_copy) if real_report_copy else None,
            "evidence_boundary": (
                "Actual user-opened GM Screen acceptance report validated against this exact ZIP hash."
                if classification == FINAL else
                "Local Chromium ZIP-input simulation passed; real user-opened GM Screen acceptance remains required."
            ),
        }
        (audit / "Command_6_Audit.json").write_text(
            json.dumps(attestation, indent=2) + "\n", encoding="utf-8"
        )
        (audit / "Command_6_Audit.md").write_text(
            "# Command 6 Consumer Verification\n\n"
            f"- Verdict: `{attestation['verdict']}`\n"
            f"- Exact candidate SHA-256: `{candidate_hash}`\n"
            f"- Released ZIP is byte-identical: `true`\n"
            f"- Local ZIP-input simulation: `{proof.get('verdict')}`\n"
            f"- Save/reload preserved: `{proof.get('save_reload_preserved')}`\n"
            f"- Required tabs: `{len(proof.get('tabs_present', []))}`\n"
            f"- Classification: `{classification}`\n"
            f"- Evidence boundary: {attestation['evidence_boundary']}\n",
            encoding="utf-8",
        )
        print(json.dumps(attestation, indent=2))
        return 0
    except Exception as exc:
        result = {"verdict": "FAIL_COMMAND_6_CONTROLLER", "error": str(exc)}
        (audit / "Command_6_Audit.json").write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8"
        )
        print(json.dumps(result, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
