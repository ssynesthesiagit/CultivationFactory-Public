#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path

DIRS=['Command_1','Command_2','Command_3','Command_4','Command_4B','Command_5','Command_6','Build','Validation','GM_Render_Evidence']

def main()->int:
    ap=argparse.ArgumentParser(description='Initialize an HF05ZVK-R1F character workspace.')
    ap.add_argument('--factory-root',type=Path,required=True)
    ap.add_argument('--workspace',type=Path,required=True)
    ap.add_argument('--request',required=True)
    ap.add_argument('--character-id',required=True)
    args=ap.parse_args()
    if args.workspace.exists() and any(args.workspace.iterdir()):
        raise SystemExit(f'Workspace is not empty: {args.workspace}')
    args.workspace.mkdir(parents=True,exist_ok=True)
    for d in DIRS: (args.workspace/d).mkdir(parents=True,exist_ok=True)
    shutil.copy2(args.factory_root/'03_TEMPLATES'/'Character_Master_Ledger.blank.json',args.workspace/'Character_Master_Ledger.template.json')
    shutil.copy2(args.factory_root/'03_TEMPLATES'/'Rules_Selection_Packets.blank.json',args.workspace/'Command_2'/'Rules_Selection_Packets.template.json')
    request={'schema_version':'HF05ZVK-R1F','character_id':args.character_id,'request':args.request,'factory':'HF05ZVK-R1F','gm_screen_target':'HF05ZUI-R2K','status':'WORKSPACE_INITIALIZED'}
    (args.workspace/'Command_1'/'Build_Request.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'verdict':'PASS_WORKSPACE_INITIALIZED','workspace':str(args.workspace),'directories':DIRS},indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
