#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

CANDIDATE = "COMMAND_5_GM_SCREEN_CANDIDATE_READY"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(
        description=(
            "Seal the deterministic Build directory as the immutable Command 5 candidate ZIP. "
            "Command 6 attestations are sidecars and never mutate this ZIP."
        )
    )
    ap.add_argument("--build", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--classification", choices=[CANDIDATE], required=True)
    a = ap.parse_args()
    if not a.build.is_dir():
        raise SystemExit("Build directory missing")

    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "Character_Package"
        shutil.copytree(a.build, root)
        # Avoid a circular checksum dependency: Release_Gate_Manifest.json is
        # included in the final SHA256SUMS.txt, while SHA256SUMS.txt itself is
        # intentionally excluded from the release manifest.
        files = [
            {
                "path": p.relative_to(root).as_posix(),
                "sha256": sha(p),
                "bytes": p.stat().st_size,
            }
            for p in sorted(root.rglob("*"))
            if p.is_file() and p.name != "SHA256SUMS.txt"
        ]
        release = {
            "classification": CANDIDATE,
            "producer_release": "HF05ZVK-R1H",
            "consumer": "HF05ZUI-R2K",
            "consumer_patch": "HF05ZUI-R2K.3",
            "evidence_boundary": "static_compile",
            "command_6_attestation_is_external_sidecar": True,
            "real_gm_screen_acceptance_required": True,
            "file_count": len(files),
            "files": files,
        }
        (root / "Release_Gate_Manifest.json").write_text(
            json.dumps(release, indent=2) + "\n", encoding="utf-8"
        )
        lines = [
            f"{sha(p)}  {p.relative_to(root).as_posix()}"
            for p in sorted(root.rglob("*"))
            if p.is_file() and p.name != "SHA256SUMS.txt"
        ]
        (root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        a.output.parent.mkdir(parents=True, exist_ok=True)
        # Reproducible ZIP: fixed entry timestamps, permissions, ordering, and compression.
        # The same canonical inputs must produce the same candidate SHA-256.
        with zipfile.ZipFile(a.output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for p in sorted(root.rglob("*")):
                if not p.is_file():
                    continue
                arcname = p.relative_to(root).as_posix()
                info = zipfile.ZipInfo(arcname, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.flag_bits |= 0x800
                z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    with zipfile.ZipFile(a.output) as z:
        bad = z.testzip()
        count = len(z.infolist())
    result = {
        "verdict": "PASS_CHARACTER_ZIP_SEAL" if bad is None else "FAIL_CHARACTER_ZIP_SEAL",
        "classification": CANDIDATE,
        "zip": str(a.output),
        "sha256": sha(a.output),
        "entries": count,
        "testzip": bad,
        "immutable_candidate": True,
    }
    print(json.dumps(result, indent=2))
    return 0 if bad is None else 2


if __name__ == "__main__":
    raise SystemExit(main())
