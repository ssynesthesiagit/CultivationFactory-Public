#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
TABS=["overview-core-stats","leveling-ledger","background-origin","paths-subpaths","spheres-talents","insights","actions","composite-playbooks","forged-techniques","martial-manuals-recorded-arts","immortal-arts","foundation","method","companions-spirits","equipment","resources-states-suppression","dao-i-ching","diagnostics"]
def sha(p:Path):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--report',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True);a=ap.parse_args();issues=[]
 try:r=json.loads(a.report.read_text(encoding='utf-8'))
 except Exception as e:r={};issues.append(f'REPORT_INVALID_JSON:{e}')
 checks=[('schema','HF05ZUI-R2K.RealAcceptanceReport.v1'),('evidence_class','real_gm_screen_user_acceptance'),('verdict','PASS_REAL_GMSCREEN_ACCEPTANCE'),('consumer','HF05ZUI-R2K'),('consumer_patch','HF05ZUI-R2K.3')]
 for k,v in checks:
  if r.get(k)!=v:issues.append(f'REPORT_{k.upper()}_INVALID:{r.get(k)}')
 if r.get('candidate_sha256')!=sha(a.candidate):issues.append('REPORT_CANDIDATE_HASH_MISMATCH')
 if r.get('candidate_bytes')!=a.candidate.stat().st_size:issues.append('REPORT_CANDIDATE_SIZE_MISMATCH')
 if r.get('candidate_filename')!=a.candidate.name:issues.append('REPORT_CANDIDATE_FILENAME_MISMATCH')
 if r.get('actual_zip_input_exercised') is not True:issues.append('REPORT_ZIP_INPUT_NOT_EXERCISED')
 if r.get('save_reload_preserved') is not True:issues.append('REPORT_SAVE_RELOAD_NOT_PRESERVED')
 if r.get('tabs_present')!=TABS:issues.append(f"REPORT_TAB_SET_MISMATCH:{r.get('tabs_present')}")
 if r.get('missing_tabs'):issues.append(f"REPORT_MISSING_TABS:{r.get('missing_tabs')}")
 if r.get('extra_tabs'):issues.append(f"REPORT_EXTRA_TABS:{r.get('extra_tabs')}")
 if r.get('blockers'):issues.append(f"REPORT_BLOCKERS:{r.get('blockers')}")
 if r.get('expected_counts_match') is not True:issues.append('REPORT_EXPECTED_COUNTS_NOT_MATCHED')
 if r.get('count_mismatches'):issues.append(f"REPORT_COUNT_MISMATCHES:{r.get('count_mismatches')}")
 if not isinstance(r.get('projection_fidelity'),dict) or r['projection_fidelity'].get('passed') is not True:issues.append('REPORT_PROJECTION_FIDELITY_FAILED')
 retention=r.get('retention');
 if not isinstance(retention,dict) or set(retention)!=set(TABS) or any(not isinstance(v,dict) or v.get('preserved') is not True for v in retention.values()):issues.append('REPORT_RETENTION_DETAIL_INVALID')
 p=r.get('phase2f') or {}
 if p.get('passed') is not True:issues.append(f'REPORT_PHASE2F_FAILED:{p}')
 if p.get('required_missing_sidecars'):issues.append(f"REPORT_REQUIRED_SIDECARS_MISSING:{p.get('required_missing_sidecars')}")
 retained=set(p.get('retained_sidecars',[])) if isinstance(p.get('retained_sidecars'),list) else set()
 required_sidecars={"Character_Master_Ledger.json","Tianxia_GM_Character_Model_v1.json","Tianxia_GM_Character_View_Model_v2.json","Equipment_Ledger.json","Equipment_Ledger_Legacy.json","Selected_Item_GM_Projection.json","Item_Execution_Coverage.json","Selected_Rule_Execution_Coverage.json","Feature_Coverage_Manifest.json","Path_Feature_Coverage.json","Subpath_Feature_Coverage.json","Insight_Execution_Coverage.json","Companion_Execution_Coverage.json","Source_CL_and_Realm_Suppression.json","Modifier_Ledger.json","Procedure_Ledger.json","Passive_Statistic_Ledger.json","Permission_Record_Ledger.json","Complete_Action_Surface.json","State_Effect_Registry.json","Leveling_Ledger.json","Rules_Selection_Packets.json","GM_Screen_Display_Rows.json","GM_Screen_Projection_Rows.json","Semantic_Validation_Report.json","Signature_Loadout.json"}
 missing_sidecars=sorted(required_sidecars-retained)
 if missing_sidecars:issues.append('REPORT_RETAINED_SIDECARS_INCOMPLETE:'+','.join(missing_sidecars))
 ev=r.get('import_evidence',{});z=(ev.get('zip_files') or []) if isinstance(ev,dict) else []
 if not z or z[0].get('sha256')!=sha(a.candidate):issues.append('REPORT_IMPORT_EVIDENCE_HASH_MISMATCH')
 result={'verdict':'PASS_REAL_GMSCREEN_ACCEPTANCE_REPORT' if not issues else 'FAIL_REAL_GMSCREEN_ACCEPTANCE_REPORT','issues':issues,'report':str(a.report),'candidate':str(a.candidate),'candidate_sha256':sha(a.candidate)}
 print(json.dumps(result,indent=2));return 0 if not issues else 2
if __name__=='__main__':raise SystemExit(main())
