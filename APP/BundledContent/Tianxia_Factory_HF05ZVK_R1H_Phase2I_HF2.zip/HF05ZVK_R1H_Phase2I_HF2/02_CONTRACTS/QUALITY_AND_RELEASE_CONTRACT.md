# Quality and Release Contract

## Advancement and arithmetic

- Legal 27-point buy plus the printed Background adjustment.
- Correct Path, key ability, hit die, Realm, PB, and Path-feature schedule.
- Generated characters use a separate CL1 free Sphere and free talent, not sect-trial accounting.
- Background and CL1 grants remain distinct, including intentional same-Sphere overlap.
- Exactly one free level talent per CL and one free bonus talent for each newly trained Sphere.
- No more than three trained choices per CL.
- Every training record has correct DC, time, roll, teacher/manual provenance, and acquisition event.
- HP, skills, AC, speed, initiative, saves, attack bonus, save DC, and every resource reconcile from source components.
- Method, Foundation, and item resource/statistic modifiers stack when printed rules apply; every nonzero delta resolves to its own source grant.
- Every cumulative level state has a valid checkpoint hash.

## Complete ordinary chassis

- Every Background skill, tool, language, item, Sphere/talent grant, and compensation is represented.
- Every Origin Insight benefit is decomposed into exact source-backed effects; convenient reinterpretations are forbidden.
- Method benefits, drawbacks, resource shape, breakthrough shape, compatibility, and applied math are complete.
- Foundation attained stages, resources, actions, passives, burdens, hidden injuries, strains, deviations, integration, repair, treatment, temptations, and failure consequences are mapped or explicitly absent in the source.
- Blueprint deviations are explicit, value-reconciled, explained, and approved.

## Talent and Sphere execution

Every relevant Sphere base expression and every learned talent must be classified as one of:

- standalone action;
- alternate attack;
- Bonus Action;
- Reaction;
- triggered passive;
- action modifier;
- state modifier;
- noncombat procedure;
- pure passive statistic;
- subsumed expression.

Active categories require complete action cards. Modifiers require exact target action IDs. State modifiers require registered state IDs. Pure passive statistics require applied stat targets. A talent listed only in the Talents tab is incomplete.

## Recorded Arts

Recorded Arts are fixed executable expressions; they do not grant their source Spheres or talents. They require source, training, acquisition, exact reproduced expression, complete execution, linked action parity, limits, and counterplay.

Default minimums by current CL and character profile are enforced. R1D doubles the prior floors so trained martial breadth is visible without consuming another mandatory prompt. For CL10–14:

- standard: 8;
- significant: 10;
- powerful: 12;
- rival/boss: 16.

## Forged and Immortal systems

Learned Forged Techniques, preserved expressions, and Emergency Seeds remain distinct. Immortal Arts use their own schema, execution packets, optional authoring command, and permanent GM Screen tab.

## Consumer surfaces

HF05ZUI-R2K exposes eighteen permanent tabs, including Immortal Arts. Acceptance requires:

- canonical order and nonempty intended surfaces;
- expected record counts;
- no blocker phrases or object-rendering artifacts;
- field-level projection fidelity for arrays and complete subsystem structures;
- save/reload retention;
- exact candidate SHA-256 evidence.

## Evidence levels

`COMMAND_5_GM_SCREEN_CANDIDATE_READY` means static compilation and sealing passed.

`SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED` means the local ZIP-input simulation passed but the actual target browser has not supplied acceptance evidence.

`FINAL_RELEASE_READY` requires a passing real GM Screen acceptance report bound to the exact unchanged candidate.

## R1E classification hardening

R1E rejects custom multi-Sphere Recorded Arts that bypass Technique Forging and requires Immortal Arts to project their complete linked action packets into the consumer.
