# Persistent Companion, Spirit, and Beast Character-Sheet Contract — Phase 2F

Every persistent companion is a character entity, not an equipment row or a loose list of actions. The Character Master Ledger must record a readable descriptive profile, complete stat block, origin, progression, training or bond rules, care or offerings, equipment, injury and recovery, forms or evolutions, owner relationship, and exact turn-control model.

## Beastmaster beasts
A Beastmaster beast must record its base creature, trained commands, autonomous behavior without a command, care and diet, harness/barding/loadout, Bonded Companion or Tame status, Companion Archetype where applicable, Beast Nature, Realm Evolutions, injury and recovery, and exact initiative/command rules. Tame creatures that are not full Bonded Companions must not receive Companion Archetype statistics or Realm Evolutions.

## Spirits
A spirit record must distinguish Nature and personhood from its combat chassis. Record appearance, personality, voice, goals, fears, offerings or sustenance, reciprocal obligations, taboos, bond crises, manifestation, destruction, and reconstruction. A spirit does not receive a full independent combat sheet unless a Source Rule grants the Bonded Companion chassis.

## Display
The GM Screen primary surface is **Companions, Spirits & Beasts**. Canonical IDs and packet provenance remain in expandable technical details.
