# Canonical Master-Ledger Contract

`Character_Master_Ledger.json` is the sole authored mechanical truth after Command 4. Commands 5–6 may compile, inspect, and attest to it, but they may not redesign or hand-repair its derived surfaces.

## Event-sourced requirements

Every permanent grant has exactly one acquisition event. The event and grant row agree on ID, name, acquisition level, channel, source packets, and allocation ID.

Required event classes include Background, Background Sphere, Background talent, Origin Insight, CL1 free Sphere, every free level talent, each newly trained Sphere and its free bonus talent, trained talents, Path features, Method, Foundation, equipment, training sources, Recorded Arts, learned Forged Techniques, Emergency Technique Seeds, and Immortal Arts when present.

Every CL row records Realm, PB, exact HP components, exact resource components, ordered allocations, and a hash of cumulative state. The final row equals the visible final HP and resource totals.

## Production authority

A production mechanical selection cites at least one packet authorized by `tianxia_rules` or `user_directive`. `inspiration_source` may establish characterization and fidelity but cannot authorize a mechanical grant. `original_design` is restricted to acceptance fixtures unless an explicit user-directive packet authorizes a custom design.

## Authored sections

The master ledger contains identity, Path chassis, point buy, scalar statistics, Background and Origin, full advancement, Spheres, talents, Path features, Method, Foundation, equipment, resources, states, complete actions, execution-coverage rows, training sources, Recorded Arts, learned Forged Techniques, preserved expressions, Emergency Technique Seeds, Immortal Arts, composite playbooks, Dao/I Ching, AI behavior, provenance, blueprint deviations, and explicit none-states.

## Compiler-only files

Command 5 creates the following; none may be hand-repaired:

- `Tianxia_GM_Character_Model_v1.json`
- `Tianxia_GM_Character_View_Model_v2.json`
- `Character_Import_Surface.json`
- `Normalized_Sheet.json`
- `Canonical_Stats_Resource_Block.json`
- `Leveling_Ledger.json`
- `Background_Origin_Ledger.json`
- `Origin_Insight_Ledger.json`
- `Cultivation_Method_Profile.json`
- `Foundation_Detail_Ledger.json`
- `Dao_IChing_Combat_Profile.json`
- `Selected_Spheres.json`
- `Sphere_Execution_Coverage.json`
- `Talent_Source_Ledger.json`
- `Talent_Execution_Coverage.json`
- `Equipment_Ledger.json`
- `State_Effect_Registry.json`
- `Complete_Action_Surface.json`
- `Composite_Playbook.json`
- `Manual_Lineage_Record.json`
- `Martial_Arts_and_Manuals.json`
- `Forged_Techniques.json`
- `Preserved_Forged_Expressions.json`
- `Emergency_Technique_Seeds.json`
- `Immortal_Arts.json`
- `AI_Character_Generation_Profile.json`
- `AI_Combat_Behavior_Profile.json`
- `GM_Screen_Display_Rows.json`
- `GM_Screen_Projection_Rows.json`
- `GM_Screen_Tab_Expectation_Manifest.json`
- `GM_Screen_Source_Map_Expectation.json`
- `Build_Reconciliation.json`
- `PACKAGE_MANIFEST.json`
- `SHA256SUMS.txt`

A projection defect is repaired in the ledger or compiler and then recompiled from zero.
