# Semantic Completeness and Tournament Admission Contract

Structural validity is not mechanical validity. Every selected Sphere, talent, feature, Method, Foundation, item, Recorded Art, Forged Technique, and Immortal Art must have an explicit semantic coverage record bound to its source packet.

A production candidate must include:

- `semantic_contract` in the master ledger;
- a source-backed requirement row for every prerequisite, mandatory choice, grant, scalar, execution rider, resource/state loop, legal initial value, drawback, equipment profile, Foundation runtime obligation, and composite dependency;
- fresh advancement and execution evidence hashes;
- a curated 10–14 action Signature Loadout;
- `Semantic_Validation_Report.json` with no Critical or High findings.

The 30 authoritative non-Chakra Foundations are the only playable Foundation catalog for R1F. The 32 theoretical Chakra concepts are excluded until complete mechanics are published.

A GM Screen render pass cannot override a failed semantic report. Combat and tournament admission must bind to the exact candidate SHA-256 and exact semantic-report hash.
