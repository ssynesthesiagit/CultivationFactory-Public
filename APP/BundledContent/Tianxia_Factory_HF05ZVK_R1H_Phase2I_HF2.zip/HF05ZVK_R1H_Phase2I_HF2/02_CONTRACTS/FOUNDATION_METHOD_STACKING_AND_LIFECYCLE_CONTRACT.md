# Foundation, Method, and Resource Stacking Contract

A character has one active Primary Method. This does not suppress or replace Foundation benefits.

When printed rules modify the same primary resource or statistic:

```text
final value = base Path value
            + active Method modifier
            + attained Foundation modifier
            + item modifier
            + other explicitly authorized modifier
```

Every nonzero delta records its source grant and the CL from which it applies. A specific printed nonstacking rule can override the default only for the effects it names.

A complete Foundation record includes attained stage benefits and every lifecycle category: passive chassis, resources, actions/reactions, states, burdens, hidden injuries, strains, deviations, integration, repair, treatment, temptations, and failure consequences. Later-stage benefits remain visible as unavailable rather than silently omitted.
