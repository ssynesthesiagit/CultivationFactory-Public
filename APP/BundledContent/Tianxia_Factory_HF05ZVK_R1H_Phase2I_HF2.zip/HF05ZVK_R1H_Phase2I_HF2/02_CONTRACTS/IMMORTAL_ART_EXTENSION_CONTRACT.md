# Immortal Art Extension Contract

Immortal Arts are not ordinary actions, Recorded Arts, or Forged Techniques. They require optional Command 4B so their Dao Aspect, prerequisites, acquisition, evolution, execution, costs, limits, counterplay, and behavior hooks receive a dedicated reasoning pass.

The Immortal Arts tab is permanent. Characters without access carry an explicit none-state.

Skipping Command 4B is legal only when `immortal_arts` is empty and `immortal_arts_none_state` is complete.

## Executable projection requirement

Every Immortal Art must link only to complete `immortal_art` action packets. Each linked action must carry the same `immortal_art_id` as the parent record. The compiler embeds the full linked action packets into `Immortal_Arts.json`, the normalized models, and the GM Screen view model.

The Immortal Arts tab must show what the art actually does: timing, action economy, cost, range, target, roll or save, success effect, failure, duration, limit, and counterplay for every linked action. Action IDs and behavior hooks alone are not a sufficient consumer surface.
