# HF05ZUI-R2K.3 Consumer Contract

The matching GM Screen accepts canonical HF05ZVK-R1F outputs directly and retains them through roster save/reload.

## Scalar aliases

The import surface exposes `ac_active`, `hp_current`, `hp_max`, `technique_attack_bonus`, `save_dc`, `pb`, `speed_ft`, `primary_resource_name`, `primary_resource_current`, `primary_resource_max`, and scalar maps for ability scores, ability modifiers, saving throws, and skills.

## Canonical block retention

The importer preserves the master ledger, complete action and composite surfaces, Selected Spheres, talent source and execution ledgers, training/manual records, Forged Techniques, preserved expressions, Emergency Seeds, Immortal Arts, Foundation, Method, Background/Origin, level rows, equipment, resources, states, rules packets, expectation manifest, and build reconciliation. Save/reload may not silently drop these blocks.

## Eighteen permanent tabs are required and remain in a fixed order.

1. Overview / Core Stats
2. Leveling Ledger
3. Background & Origin
4. Paths & Subpaths
5. Spheres & Talents
6. Insights
7. Actions
8. Composite Playbooks
9. Forged Techniques
10. Martial Manuals / Recorded Arts
11. Immortal Arts
12. Foundation
13. Method
14. Companions / Spirits
15. Equipment
16. Resources / States / Suppression
17. Dao & I Ching
18. Diagnostics

## Array and field preservation

The consumer preserves every row and every semantically meaningful array element. A list may not be flattened to its first row or reduced to names when the full object carries mechanics. This applies especially to Forged Technique components, Augments, Drawbacks, sources, talent execution routing, Foundation lifecycle structures, Background proficiencies, and Immortal Art limitations.

## Acceptance

The built-in acceptance report checks canonical tab order, top-level record counts, field-level projection fidelity, blocker phrases, exact ZIP hash, native and fallback decompression, and compact roster retention. An intentional empty state is valid; missing canonical data is not.


## Required tab order

1. `overview-core-stats`
2. `leveling-ledger`
3. `background-origin`
4. `paths-subpaths`
5. `spheres-talents`
6. `insights`
7. `actions`
8. `composite-playbooks`
9. `forged-techniques`
10. `martial-manuals-recorded-arts`
11. `immortal-arts`
12. `foundation`
13. `method`
14. `companions-spirits`
15. `equipment`
16. `resources-states-suppression`
17. `dao-i-ching`
18. `diagnostics`
