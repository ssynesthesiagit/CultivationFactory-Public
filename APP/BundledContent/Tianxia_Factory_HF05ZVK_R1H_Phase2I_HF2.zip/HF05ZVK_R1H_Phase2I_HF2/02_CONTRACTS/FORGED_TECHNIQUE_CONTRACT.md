# Forged Technique Contract

## Distinct record classes

### Learned Forged Technique

A permanent personal technique. It consumes one learned-technique slot and must have an advancement event. The number learned cannot exceed PB.

### Preserved Forged Expression

A fixed forged expression inside a Recorded Art. It remains part of that art and consumes no personal slot unless separately learned. It requires a stable expression ID, parent Recorded Art ID, linked action ID, component grants, Spheres, Complexity, CP cost, complete fixed execution, source packets, and an explicit `counts_against_personal_forged_limit: false` declaration.

### Emergency Technique Seed

The exact record of a successful emergency expression. It is not learned, consumes no slot, and may aid later research of that exact technique.

## Learned-technique calculation

The record must expose and reconcile:

- CL learned and matching Realm;
- legal Realm Complexity limit;
- Base Form and base Complexity;
- Primary Sphere;
- each Secondary Sphere and explicit Complexity adjustment;
- each Augment, its Complexity, CP addition, and minimum Realm;
- optional Drawbacks and their CP reductions;
- total Drawback reduction no greater than PB;
- base CP, Secondary-Sphere CP adjustment, Augment CP, Drawback reduction, and final CP no lower than 1;
- final Complexity as the exact sum of its components;
- Forging DC = `10 + final Complexity + number of Spheres used`;
- ownership of all component Spheres/talents/actions at the learning CL;
- source authority for any adjudicated Secondary-Sphere CP adjustment.

## Forging history

The record also requires research time, materials, Forging DC, check total, result, attempts, creator, learner, acquisition level, allocation ID, and source packets.

## Execution

The linked forged action and technique record must agree on action economy, timing/trigger, cost, range, target, roll/save/check, effect, failure, duration, limits, counterplay, states, and component action IDs.

## Consumer behavior

The GM Screen always displays the Forged Techniques tab. Learned techniques, preserved Recorded Art expressions, and Emergency Seeds have separate sections. A character with no personally learned techniques still receives an explicit intentional empty state; preserved expressions never inflate the personal learned-technique count.
