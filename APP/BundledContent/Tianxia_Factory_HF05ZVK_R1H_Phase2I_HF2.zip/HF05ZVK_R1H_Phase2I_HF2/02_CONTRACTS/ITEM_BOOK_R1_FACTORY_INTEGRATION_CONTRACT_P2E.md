# Item Book R1 Factory Integration Contract — Phase 2E

## Authority

The human rules authority is `09_RULES/Items/Tianxia_ItemBook_R1.md`. Stable item identity, definitions, Treasure Sets, and static GM projection are controlled by the R2 machine assets in `09_RULES/Items/`. Item definitions are immutable catalog records; character equipment consists of mutable Item Instances.

## Character authority

Every production character exports `Equipment_Ledger.json` conforming to `Tianxia_Equipment_Ledger_v2_1`. `Equipment_Ledger_Legacy.json` is a temporary consumer projection and is never an authoring authority.

Every active Item Instance must have: valid catalog identity or a complete custom definition snapshot; explicit ownership, bearer, Attunement, equipped state, charges, storage, Item Spirit, Growth, durability, temporary modifiers, and provenance; a complete `item_execution_coverage` row; universal selected-rule execution coverage; Source CL and Realm Suppression export; and resolved action, reaction, procedure, resource, modifier, passive-statistic, or permission targets.

## Anti-shortcut rules

The Factory must not treat a catalog summary, Sphere Influence tag, item name, GM projection card, or prose note as execution coverage. Active actions and reactions require executable Action records. Procedures require Procedure records. Derived effects require explicit contribution or modifier records. Broken, Core-Lost, consumed, inactive, or improperly Attuned items cannot contribute mechanics. Set Resonance requires every required active component. Item Spirits never receive independent turns without the appropriate independent-spirit state and linked companion profile.

## GM Screen boundary

Phase 2E exports the complete R2 ledger and a selected-card projection but does not modify the current GM Screen. A later live browser import/render audit is required before claiming full Equipment / Source UI readiness.

## Event-Sourced Item Acquisition

Every permanent item instance must have exactly one advancement allocation at the CL where the character acquired it. The allocation must use `channel: item`, `grant_type: item`, the item `instance_id` as `grant_id`, `slot_cost: 0`, and the same rules-packet IDs used by the item execution-coverage row.

Acquisition CL records provenance; it does not replace the item definition's Source CL or Realm floor. Command 5 must reconcile the acquisition allocation, R2 item instance, item execution coverage, Source CL and Realm Suppression export, and selected Item GM projection before compilation succeeds.
