# Rules authority and conflict policy — Canon Corpus Phase 1

## Precedence

1. The user's explicit current instruction.
2. The subject-specific order in `09_RULES/CANON_AUTHORITY_MANIFEST_P2A.json`.
3. Exact active source excerpts copied into `Rules_Selection_Packets.json`.
4. Machine indexes in `09_RULES/Indexes/` and the canonical corpus.
5. Templates and fixtures.
6. Deprecated sources retained only under `09_RULES/Deprecated_R1F/` for audit history.

The active production corpus is `09_RULES/Tianxia_Canonical_Rules_Corpus_P2A.zip`. A `tianxia_rules` packet must use an exact path listed in the corpus manifest's `active_packet_sources`. Suffix-only matching and deprecated paths are prohibited.

## Current publication authority

- PHB: v0.7
- Qi Cultivation: R19
- Body Refining: R8
- Spirit Awakening: R7
- Cultivation Insights: R4, published through Compendium R1

The conflict-resolution overlay in the corpus controls known retained-source conflicts, including resource recovery, central Insight authority, and Spirit Companion procedures.

## Source separation

- **Inspiration evidence** supports identity, history, personality, signature imagery, and narrative behavior.
- **Tianxia rules evidence** supports every selected Background, Origin Insight, Path, Subpath, Sphere, talent, Insight, Method, Foundation, Recorded Art, item, and forged rule.
- **Original character design** supports original names, composite playbooks, AI tactics, and legal fixed expressions assembled from selected mechanics.

Do not cite a novel or fan page as authority for Tianxia mechanics. Do not use Tianxia rules to invent facts about a source character.

## Uncertainty

A material unresolved rule question blocks the next command. Record it in `Open_Questions.json`. Do not hide uncertainty in generic prose.
