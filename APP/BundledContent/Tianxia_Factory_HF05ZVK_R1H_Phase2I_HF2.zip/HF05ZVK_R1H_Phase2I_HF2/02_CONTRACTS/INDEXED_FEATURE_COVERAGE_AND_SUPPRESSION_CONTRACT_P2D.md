# Indexed Feature Coverage and Suppression Contract — Phase 2D

## Purpose

Phase 2D makes the universal selected-rule ledger enforceable against the canonical Path, Subpath, and Insight indexes. A feature name, chassis summary, or prose paragraph is not execution coverage.

## Required families

1. **Path features:** every canonical feature granted by each active Path at its Effective CL must exist as one ledger feature and one universal coverage row.
2. **Subpath and tradition features:** every tier feature available at the owning Path's Effective CL must be present individually.
3. **Cultivation Insights:** every selected canonical Insight must resolve to the R4 machine reference and have complete runtime coverage.
4. **Companions:** each Companion declares its action economy and exact expected feature IDs; every feature must resolve to a runtime record.
5. **Source CL and Realm Suppression:** every selected rule exports structured Source CL and suppression data, including minimum Effective CL and runtime targets.

## Anti-shortcut rules

The validator rejects:

- aggregate stand-ins such as “Path Chassis” replacing several indexed features;
- a feature present in prose but absent from the execution ledger;
- a mechanical feature represented only as an identity or record-only permission;
- fabricated expected-feature lists that disagree with the indexes;
- missing Companion action-economy targets;
- an Insight unknown to or nonselectable in the R4 catalogue;
- incomplete Source CL or Realm Suppression records;
- export rows that do not exactly match the universal coverage row;
- bulk target dumps used to claim that one canonical feature covers unrelated actions.

## Compatibility

The Character Master Ledger gains new enforcement fields and Command 5 emits six new sidecars. The existing `Tianxia_GM_Character_Model_v1.json` and GM Screen consumer schema are unchanged in Phase 2D.
