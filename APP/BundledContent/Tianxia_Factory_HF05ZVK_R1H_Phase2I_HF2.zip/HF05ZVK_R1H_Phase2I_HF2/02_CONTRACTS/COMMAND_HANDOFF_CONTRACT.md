# Command Handoff Contract

Each prompt begins from sealed files, not conversational memory alone.

## Command 1 → Command 2

Command 2 begins only when `Validation/Command_1.validation.json` passes and `Open_Questions.json` contains no blocking questions. The source evidence and blueprint are locked.

## Command 2 → Command 3

Command 3 begins only when every selected mechanical element has valid source authority, every CL from 1 through current is present, training and allocation records reconcile, final scalar arithmetic reconciles, and `Validation/Command_2.validation.json` passes.

## Command 3 → Command 4

Command 4 begins only when Background, Origin, Method, Foundation lifecycle, Sphere/talent execution routing, Recorded Art roster, and blueprint deviations are completely mapped and `Validation/Command_3.validation.json` passes.

## Command 4 → Optional Command 4B or Command 5

Command 4 seals the complete ordinary executable character. Optional Command 4B is inserted only for a character that legally possesses one or more Immortal Arts. Characters without Immortal Arts must carry an explicit none-state and proceed directly to Command 5.

## Command 5 → Command 6

Command 5 creates one immutable, reproducible candidate ZIP. Command 6 consumes that exact ZIP and its expected-tab/count manifest. It does not redesign the character and does not embed evidence into or otherwise mutate the candidate.

Local simulation evidence is stored as a hash-bound sidecar and receives at most:

`SIMULATED_CONSUMER_PASS_REAL_GMSCREEN_ACCEPTANCE_REQUIRED`

## Simulation → final release

A real acceptance report must be exported by the user-opened HF05ZUI-R2K after importing the exact Command 5 candidate. The report's SHA-256 must match that candidate. A report for a rebuilt, changed, or different ZIP is invalid.

The accepted candidate remains unchanged. `FINAL_RELEASE_READY` is established by the pair:

1. the exact Command 5 candidate ZIP; and
2. its validated hash-bound real acceptance report.

## Repair protocol

Every repair records the failed gate or visible defect, owning layer, canonical input changed, validators rerun, and whether the candidate and consumer evidence were regenerated. Any canonical change invalidates later attestations and requires recompilation, resimulation, and new real acceptance evidence.
