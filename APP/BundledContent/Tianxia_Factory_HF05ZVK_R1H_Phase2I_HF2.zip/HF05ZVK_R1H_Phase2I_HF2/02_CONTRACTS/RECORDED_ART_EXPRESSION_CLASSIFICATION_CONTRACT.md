# Recorded Art Expression Classification Contract

Recorded Arts are fixed techniques learned from a teaching source. They are not a free alternative to personal Technique Forging.

Every Recorded Art must declare exactly one `expression_kind`:

- `single_sphere_expression` — a custom or source-backed fixed expression of one Sphere. It may reproduce a base ability, one talent, or a tightly linked same-Sphere talent chain. It cannot add a second Sphere effect.
- `source_authored_lineage_expression` — an exact multi-Sphere technique already printed in an authoritative manual, inheritance, or explicit user-supplied lineage source. It must not be AI-invented (`custom_design` must be false) and its source packet must contain the exact technique.
- `preserved_forged_expression` — a Forged Technique preserved in a manual and learned as a fixed Recorded Art. It must carry the complete preserved-forging record and does not consume a personal Forged Technique slot unless a rule explicitly says otherwise.

A custom-generated Recorded Art that combines multiple Spheres is illegal unless it is constructed and recorded as a preserved Forged expression. A dramatic name, scripture, lineage label, or user request for a powerful character does not waive this boundary.

The linked action must exactly match the Recorded Art execution record. The art may not silently add unrelated damage, states, riders, or resource discounts beyond its declared expression source.
