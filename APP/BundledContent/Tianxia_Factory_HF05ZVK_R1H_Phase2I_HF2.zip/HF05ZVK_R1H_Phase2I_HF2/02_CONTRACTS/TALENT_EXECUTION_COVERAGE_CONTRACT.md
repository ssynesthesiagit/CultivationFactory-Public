# Talent and Sphere Execution Coverage Contract

The combat AI may select only precompiled actions, modifiers, states, procedures, and statistics. It must never translate talent prose into a new action during combat.

Every known Sphere and learned talent has exactly one coverage row with stable source ID, classification, destination IDs, display surface, source packet IDs, and coverage note.

The compiler rejects missing rows, duplicate rows, unknown IDs, unresolved action/state IDs, active classifications without actions, modifiers without target actions, and passive statistics without stat targets.

Action modifiers must be visible on every affected action card, not merely mentioned in the Talents tab.
