# Universal Selected-Rule Execution Coverage Contract — P2C

Every selected mechanical or rules-significant record must have exactly one universal coverage row. A row may contain multiple effect-component mappings.

## Runtime destinations

- `action` → `actions[].action_id`
- `modifier` → `modifiers[].modifier_id`
- `state` → `states[].state_id`
- `resource` → `resources[].resource_id`
- `procedure` → `procedures[].procedure_id`
- `passive_statistic` → `passive_statistics[].passive_statistic_id`
- `permission_or_record_only` → `permission_records[].permission_record_id`

Every destination must identify the selected rule in `source_rule_ids`; resources may use `source_grant_ids`. One rule can occupy several destinations. Passive rules are never converted into fake Actions merely to satisfy coverage.

At Command 3, target IDs may be reserved with `planned` status. At Command 4 and compilation, all complete mappings must resolve, all source provenance must be attached, `unmapped_effects` must be empty, and all completion assertions must be true.
