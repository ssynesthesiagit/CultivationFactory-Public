window.TIANXIA_FOUNDATION_READABLE = {
  "schema": "Tianxia.FoundationUnifiedReadableProjection.v0.4B",
  "status": "62_SELECTIONS_REWRITTEN_30_AUTHORITATIVE_32_THEORETICAL",
  "counts": {
    "total": 62,
    "authoritative": 30,
    "theoretical_chakra": 32
  },
  "foundations": [
    {
      "foundation_id": "ancient_desolate_sacred_body_v0_2C",
      "name": "Ancient Desolate Sacred Body",
      "number": 1,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Spirit Awakening"
        ],
        "typical_role": "Defender / Controller",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your bones, blood, skin, and inner sea are refined into a golden pressure engine. Hostile force can still harm you, but it has trouble entering cleanly.",
        "visible_sign": "Golden heat under the skin, heavy breath, bright blood, and a sense that hostile pressure strikes a sea rather than a hollow body.",
        "warning": "Strength can become arrogance; resistance can become identity prison.",
        "dao_principle": "The body becomes a golden sea when it refuses to let heaven decide its limits."
      },
      "resource": {
        "name": "Golden Sea Pulse",
        "maximum": "1",
        "starting": "0",
        "gain": "After a real hostile pressure event resolves while you remain conscious: you take hostile damage; you make an eligible Saint-Body Frame resistance roll; you win a hostile physical contest; or you hit a hostile creature within 5 feet with a body-bound/martial Saint-Body expression after that creature damaged, moved, restrained, suppressed, cursed, possessed, poisoned, grappled, or seriously threatened you since the start of your last turn.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it. Legendary flexibility broadens eligible pressure events, not the resource cap.",
        "anti_farming": "Deny real hostile pressure, attack from outside the sacred-body range, avoid body-seizing contests, use effects outside Strength/Constitution body pressure, or wait for the Pulse to expire.",
        "spends": [
          "Golden Sea Guard",
          "Saint-Body Rebuke",
          "Refuse Heaven-Lock",
          "Refined: Golden Blood Root",
          "Refined: Pressure Becomes Method",
          "Perfected: Sacred Body Wake"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Saint-Body Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by twice your Proficiency Bonus. Once per round, when you make a Strength or Constitution ability check or saving throw against forced movement, being knocked Prone, being Grappled, being Restrained, hostile body suppression, curse-pressure, possession-pressure, poison-pressure, exhaustion-pressure, or a similar effect that tries to seize, collapse, contaminate, or command your body or meridians, add your Proficiency Bonus to the roll as a Foundation bonus. This can apply even if you are already proficient; it is not expertise and does not change your proficiency state.",
            "duration": "",
            "limit": "HP increase is always active. Resistance-roll bonus is once per round and only for eligible body/meridian pressure.",
            "counterplay": "Does not grant immunity, does not stack Proficiency twice, and does not apply to purely mental influence that does not seize the body.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Guardian",
              "Protection",
              "Metal",
              "Earth",
              "Force",
              "Blood"
            ]
          },
          {
            "name": "Golden Sea Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active; defines which methods count as natural Saint-Body expressions.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Legendary Foundation naturally supports close-range Body Refining, unarmed strikes, natural weapons, weapon-body methods, guardian interposition, body-bound Radiance, golden-blood vitality, anti-suppression stance work, and techniques from Athletics, Brute, Guardian, Iron Fist, Protection, Radiance, Metal, Earth, Force, Weather, Wrestling, Shield, Spear, Sword, and Weapons when expressed through the body. It grants no sphere access by itself and does not make all techniques Saint-Body expressions.",
            "duration": "",
            "limit": "Always active as a scope rule.",
            "counterplay": "Distant detached casting, pure social authority, ordinary ranged attacks, and unsupported external qi projection are not Saint-Body expressions unless another feature makes them so.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Guardian",
              "Iron Fist",
              "Protection",
              "Radiance",
              "Metal",
              "Earth",
              "Force",
              "Blood",
              "Qiweaving",
              "Karma"
            ]
          },
          {
            "name": "Generate Golden Sea Pulse",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a real hostile pressure event resolves while you remain conscious: you take hostile damage; you make an eligible Saint-Body Frame resistance roll; you win a hostile physical contest; or you hit a hostile creature within 5 feet with a body-bound/martial Saint-Body expression after that creature damaged, moved, restrained, suppressed, cursed, possessed, poisoned, grappled, or seriously threatened you since the start of your last turn.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the listed hostile pressure event fully resolves, if you are conscious and do not already have Golden Sea Pulse, gain Golden Sea Pulse 1/1. You can generate Golden Sea Pulse no more than once per round. Golden Sea Pulse expires at the end of your next turn. A Pulse generated by an event cannot be spent on that same event.",
            "duration": "",
            "limit": "Maximum 1; generation once per round; generated after trigger resolves; expires end of next turn.",
            "counterplay": "Deny real hostile pressure, attack from outside the sacred-body range, avoid body-seizing contests, use effects outside Strength/Constitution body pressure, or wait for the Pulse to expire.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Guardian",
              "Iron Fist",
              "Protection",
              "Radiance",
              "Metal",
              "Earth",
              "Force",
              "Blood",
              "Qiweaving",
              "Karma"
            ]
          },
          {
            "name": "Golden Sea Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take hostile damage while conscious and have Golden Sea Pulse available from an earlier event.",
            "cost": "1 Golden Sea Pulse",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Golden Sea Pulse from an earlier event. Reduce the triggering hostile damage by twice your Proficiency Bonus + your Constitution modifier. If the damage or rider comes from body suppression, curse-pressure, possession-pressure, poison-pressure, demonic pressure, necrotic corruption, hostile forced movement impact, or a similar effect trying to seize or corrupt the body, increase the reduction by your Proficiency Bonus. This does not reduce self-inflicted overchannel costs, voluntary sacrifice costs, breakthrough backlash, or hidden-injury costs unless the GM explicitly treats them as hostile external pressure.",
            "duration": "",
            "limit": "Requires Reaction and 1 Golden Sea Pulse from a prior event. Does not permit same-event spending.",
            "counterplay": "Does not reduce self-inflicted costs, voluntary overchannel damage, hidden injuries, breakthrough backlash, or the same damage event that generated the Pulse.",
            "source_spheres": [
              "Guardian",
              "Protection",
              "Radiance",
              "Metal",
              "Earth",
              "Force",
              "Blood"
            ]
          },
          {
            "name": "Saint-Body Rebuke",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature within 5 feet with an unarmed strike, natural weapon, melee weapon, Body Refining technique, Iron Fist method, Brute method, Athletics method, or other body-bound Saint-Body expression.",
            "cost": "1 Golden Sea Pulse",
            "range": "Melee / 5 ft",
            "target": "One hostile creature you hit",
            "attack_or_save": "",
            "effect": "Spend 1 Golden Sea Pulse after you hit with a qualifying close-range or body-bound Saint-Body expression. Add damage equal to your Proficiency Bonus + your Constitution modifier. Then choose one rider: push the target 5 feet if it is no more than one size larger than you; the target cannot take Reactions against you until the start of your next turn; or you gain Advantage on the next eligible Saint-Body Frame resistance roll you make against that target before the start of your next turn. This is not a second attack and does not create a new action.",
            "duration": "",
            "limit": "Once per triggering hit; requires 1 Golden Sea Pulse from a prior event; no same-event spending.",
            "counterplay": "Does not work on purely distant attacks unless the method is explicitly body-bound. Forced movement rider is not immunity.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Iron Fist",
              "Force",
              "Metal",
              "Radiance",
              "Blood"
            ]
          },
          {
            "name": "Refuse Heaven-Lock",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You would fail a Strength or Constitution saving throw or ability check against forced movement, being knocked Prone, being Grappled, being Restrained, hostile body suppression, curse-pressure, possession-pressure, poison-pressure, or a similar effect that tries to seize or collapse your body.",
            "cost": "1 Golden Sea Pulse",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Strength or Constitution roll already made",
            "effect": "Spend 1 Golden Sea Pulse from an earlier event when you would fail an eligible Strength or Constitution ability check or saving throw against forced movement, being knocked Prone, being Grappled, being Restrained, hostile body suppression, curse-pressure, possession-pressure, poison-pressure, exhaustion-pressure, or a similar effect that tries to seize or collapse your body. Add your Proficiency Bonus + your Constitution modifier to the roll. If this changes the failure into a success, you may also end one minor body-seizing rider from the same source, such as a brief speed reduction, imposed Prone rider, or minor suppression mark. This cannot end major curses, diseases, hidden injuries, deviations, Incapacitated, Stunned, Paralyzed, Petrified, or possession unless another rule allows it.",
            "duration": "",
            "limit": "Requires Reaction and 1 Golden Sea Pulse from a prior event; eligible Strength/Constitution body pressure only.",
            "counterplay": "Cannot end Stunned, Paralyzed, Incapacitated, Petrified, major possession, major curse, hidden injury, or higher-Realm binding unless another rule permits it.",
            "source_spheres": [
              "Athletics",
              "Protection",
              "Karma",
              "Force",
              "Earth",
              "Metal",
              "Blood"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Golden Blood Root",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "This rider applies when this Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Saint-Body Frame and Golden Sea Guard. It does not require an additional Reaction, does not require an additional resource spend, and does not permit same-event spending. Saint-Body Frame’s maximum Hit Point increase becomes three times your Proficiency Bonus. When Golden Sea Guard reduces damage from poison, necrotic damage, curse-pressure, possession-pressure, demonic pressure, hostile body suppression, or a comparable corruptive/suppressive source, you have Advantage on the next eligible saving throw against that same source before the start of your next turn.",
            "duration": "",
            "limit": "Rider only; modifies existing rows. No extra Reaction or resource spend.",
            "counterplay": "No extra Reaction or extra resource. Does not grant blanket immunity or cleanse major conditions.",
            "source_spheres": [
              "Protection",
              "Radiance",
              "Blood",
              "Metal",
              "Earth"
            ]
          },
          {
            "name": "Refined: Pressure Becomes Method",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "This rider applies when this Foundation is Refined and you generate Golden Sea Pulse from succeeding on an eligible Saint-Body Frame resistance roll.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you generate Golden Sea Pulse from making an eligible Saint-Body Frame resistance roll or winning a hostile physical contest, you may move up to 10 feet, stand from Prone, or end one minor speed penalty from the same source if you can do so without passing through barriers or ignoring a condition that still prevents movement. This modifies the generation event. It does not require an additional Reaction, does not require an additional resource spend, and does not permit spending the generated Pulse on the same event.",
            "duration": "",
            "limit": "Rider only; applies when the stated generation trigger occurs. No same-event spend.",
            "counterplay": "Cannot escape Grappled/Restrained/immobilizing conditions unless the triggering success already ends or avoids them.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Force",
              "Earth",
              "Metal"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Sacred Body Wake",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while this Foundation is Perfected and you have Golden Sea Pulse from an earlier event.",
            "cost": "1 Golden Sea Pulse; once per short or long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Golden Sea Pulse from an earlier event. For 1 minute or until you are Incapacitated, you gain temporary Hit Points equal to your Cultivation Level + your Constitution modifier, have Advantage on eligible Strength and Constitution ability checks and saving throws against forced movement, Prone, Grappled, Restrained, body suppression, curse-pressure, possession-pressure, poison-pressure, demonic pressure, and similar body/meridian seizure, and the first qualifying close-range or body-bound Saint-Body hit you make on each of your turns deals additional damage equal to your Proficiency Bonus. This does not create extra attacks, extra reactions, or same-event spending.",
            "duration": "",
            "limit": "Once per long rest; requires Bonus Action and 1 Golden Sea Pulse from a prior event.",
            "counterplay": "Does not make the cultivator immune, does not stack multiple free damage riders, and cannot be activated from a Pulse generated by the same triggering event.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Iron Fist",
              "Guardian",
              "Protection",
              "Radiance",
              "Metal",
              "Earth",
              "Force",
              "Blood"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Athletics",
          "Brute",
          "Guardian",
          "Iron Fist",
          "Protection",
          "Radiance",
          "Metal",
          "Earth",
          "Force",
          "Blood",
          "Qiweaving",
          "Karma"
        ],
        "expression_notes": [
          "Body Refining expression is the default. Qi/Spirit expression must be body-bound, golden-sea, anti-suppression, or scripture-supported."
        ],
        "does_not_grant": [
          "No universal immunity",
          "No free sphere access",
          "No universal ranged spell compatibility",
          "No reduction of self-inflicted costs, hidden injuries, breakthrough backlash, or voluntary overchannel damage",
          "No ability to ignore conditions without a listed spend"
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_ANCIENT_DESOLATE_SACRED_BODY_HEAVEN_WEIGHT",
            "name": "Heaven Rejects the Completed Body",
            "text": "Golden Sea Pulse cannot be generated from friendly effects, self-inflicted harm, training scenes, voluntary exposure, repeated harmless pressure, or pure ranged kiting that does not express the Saint-Body through the body. Breakthroughs for this Foundation draw elevated scrutiny because the body itself challenges suppression.",
            "effect_text": "This Legendary Foundation is not hard because its turn loop is complicated; it is hard because advancing it draws Heaven/Dao rejection, severe tribulation scrutiny, and immense material pressure. Refined and Perfected advancement should require rare body-tempering resources, repeated hostile-pressure proof, difficult teachers or forbidden-zone insight, and breakthrough scenes that test whether the cultivator can bear power without reducing all Dao to bodily dominance."
          }
        ],
        "hidden_injuries": [
          {
            "id": "INJURY_FOUNDATION_ANCIENT_DESOLATE_SACRED_BODY_SEALED_GOLDEN_SEA",
            "name": "Great Dao Scar Hidden Injury",
            "text": "The inner golden sea becomes heavy and hard to open. The GM may temporarily narrow generation triggers, suppress the Refined rider, or require repair before the Foundation can advance.",
            "effect_text": "Failed advancement, anti-Heaven backlash, or overdrawn sacred-body pressure can leave Great Dao Scars: golden blood stagnation, cracked meridians, rejection by ordinary healing, or recurring tribulation pain when the cultivator tries to force refinement without proof."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_ANCIENT_DESOLATE_SACRED_BODY_GOLDEN_BLOOD_OVERPRESSURE",
            "name": "Golden Sea Overpressure",
            "text": "Defiance, golden vitality, and pressure resistance surge too hard. Symptoms include bright blood heat, excessive heartbeat force, cracked skin-glow, and difficulty yielding when yielding is correct.",
            "effect_text": "The inner sea becomes too vast for the current realm. The cultivator may feel inexhaustible until circulation locks, joints ring like metal, or body-bound techniques flare beyond safe recovery."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_ANCIENT_DESOLATE_SACRED_BODY_SAINT_BODY_ARROGANCE",
            "name": "Sacred-Body Pride Deviation",
            "text": "The cultivator starts believing all problems should be solved by resisting harder or striking closer.",
            "effect_text": "The cultivator begins to believe all problems should be solved by stronger flesh, harsher pressure, and direct domination. This deviation turns expertise into arrogance."
          },
          {
            "id": "DEVIATION_FOUNDATION_ANCIENT_DESOLATE_SACRED_BODY_HEAVEN_CURSE_DEFIANCE",
            "name": "Heaven-Rejection Defiance Deviation",
            "text": "The cultivator defines the Dao only as opposition to suppression. Useful resistance begins to become identity prison.",
            "effect_text": "The cultivator treats Heaven/Dao rejection as proof that no law, teacher, ally, or restraint can judge them. This deviation is especially dangerous during Refined and Perfected advancement."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Golden Sea Unsealing Breath",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use breath, marrow heat, and safe body-pressure circulation to soften a Sealed Golden Sea hidden injury. Success can restore the Foundation's normal generation trigger or passive scope after medical/cultivation treatment.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Athletics",
            "Blood",
            "Radiance",
            "Qiweaving"
          ]
        },
        {
          "name": "Repair: Curse-Washing Marrow Bath",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use medicinal baths, radiant marrow heat, or teacher-guided curse washing to reduce Golden Blood Overpressure and separate real defiance from spiritual contamination.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Radiance",
            "Protection",
            "Blood"
          ]
        },
        {
          "name": "Repair: Humility Weight Stance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Train under weighted restraint, superior pressure, and ally-protection drills to repair Saint-Body Arrogance without extinguishing the Foundation's will to break suppression.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Athletics",
            "Guardian",
            "Earth",
            "Metal"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Break Heaven Pressure Without Pride",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must resist superior hostile pressure, then choose the correct tactical response instead of simply proving the body is strong.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Athletics",
            "Brute",
            "Protection",
            "Karma"
          ]
        },
        {
          "name": "Challenge: Cross the Golden Bitter Sea",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A breakthrough or refinement challenge where the body's golden sea becomes heavy, bright, and nearly sealed; success proves the cultivator can open the base without turning arrogance into Dao.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Blood",
            "Radiance",
            "Qiweaving"
          ]
        },
        {
          "name": "Challenge: Protect Without Dominating",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must guard someone weaker without using strength to silence that person's choices. Success supports Refined or Perfected advancement.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Guardian",
            "Protection",
            "Karma"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Ancient Saint-Body Record",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A lineage, scripture fragment, teacher diagnosis, or inherited body-tempering record that teaches how to refine golden blood and resist suppression. This is not a combat action unless separately written as one.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Athletics",
            "Blood",
            "Radiance",
            "Metal",
            "Earth"
          ]
        },
        {
          "name": "Lineage: Golden Sea Body Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A deeper route that connects marrow, bitter sea, breath, and body-bound Radiance. It can justify rare Qi/Spirit access to the Foundation but does not grant universal sphere access.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Radiance",
            "Qiweaving",
            "Protection",
            "Blood"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "origin_spirit_body_v0_2B",
      "name": "Origin-Spirit Body",
      "number": 2,
      "profile": {
        "grade": "Rare",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening"
        ],
        "typical_role": "Support / Defender / Recovery",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body and spirit form a clean source-vessel. You are strongest when stabilizing allies, repairing technique rhythm, and resisting drain without becoming a living battery.",
        "visible_sign": "",
        "warning": "The Foundation is strongest when support flows outward and returns cleanly.",
        "dao_principle": "A true source does not hoard itself; it returns scattered life to its own rhythm."
      },
      "resource": {
        "name": "Spirit-Source Dew",
        "maximum": "1",
        "starting": "0",
        "gain": "After an outward support event resolves while you remain conscious: you restore Hit Points to another creature; grant temporary Hit Points to another creature; reduce damage to another creature; help another creature maintain Concentration or technique rhythm; reduce or diagnose hostile drain/backlash on another creature; or a hostile drain, curse, fear, spirit-pressure, or exhaustion-pressure effect targeting you or an ally within 30 feet fails against an eligible support/protection effect you created.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it. Self-only sustain does not generate Spirit-Source Dew.",
        "anti_farming": "Attack when the cultivator has no ally-facing support target, force self-only survival, interrupt line of effect, or wait for Dew to expire.",
        "spends": [
          "Returning Source Guard",
          "Feed the Living Circuit",
          "Gentle Source Pulse",
          "Refined: Open Source Channels",
          "Perfected: Origin-Spirit Returning Field"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Origin-Spirit Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Once per round, when you use a Life, Protection, Qiweaving, Radiance, Spirit Companions, Water, Verdant Growth, Talismans, or Alchemy talent, technique, or Foundation-supported method that restores Hit Points to another creature, grants temporary Hit Points to another creature, reduces damage to another creature, helps another creature maintain Concentration or a technique rhythm, or stabilizes another creature against backlash, drain, fear, curse-pressure, or spiritual exhaustion, add your Proficiency Bonus to one roll or flat value of that effect. This does not apply to self-only sustain unless another creature is also a meaningful target of the effect.",
            "duration": "",
            "limit": "HP increase is always active. Foundation bonus is once per round and must support another creature or an ally-facing circuit.",
            "counterplay": "Self-only sustain, isolated healing with no outward target, and unrelated damage techniques do not qualify.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Origin-Spirit Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation naturally supports ambient qi reception, gentle recovery, ally stabilization, safe energy transfer, anti-drain support, technique-rhythm repair, spirit-source communion, and protective circulation. It does not grant sphere access, does not create free CP, does not heal without a qualifying effect, and does not let the cultivator replace another character’s Path resource economy. Expression phrases belong in notes; source_spheres arrays must use legal sphere names only.",
            "duration": "",
            "limit": "Scope only. Grants no sphere, talent, CP, companion, spell, or separate healing pool.",
            "counterplay": "Enemies can isolate the cultivator, attack the source-vessel directly, force self-only survival, block line of effect, or create support triage that exceeds one resource pulse.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Generate Spirit-Source Dew",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After an outward support event resolves while you remain conscious: you restore Hit Points to another creature; grant temporary Hit Points to another creature; reduce damage to another creature; help another creature maintain Concentration or technique rhythm; reduce or diagnose hostile drain/backlash on another creature; or a hostile drain, curse, fear, spirit-pressure, or exhaustion-pressure effect targeting you or an ally within 30 feet fails against an eligible support/protection effect you created.",
            "cost": "",
            "range": "Self / 30 feet trigger context",
            "target": "Self resource",
            "attack_or_save": "",
            "effect": "After the listed outward support event fully resolves, if you are conscious and do not already have Spirit-Source Dew, gain Spirit-Source Dew 1/1. You can generate Spirit-Source Dew no more than once per round. Spirit-Source Dew expires at the end of your next turn. Dew generated by an event cannot be spent on that same event. Self-only healing, self-only temporary Hit Points, and private recovery do not generate Dew unless another creature was also meaningfully supported.",
            "duration": "",
            "limit": "Maximum 1; generation once per round; generated after trigger resolves; expires end of next turn; self-only sustain does not generate.",
            "counterplay": "Attack when the cultivator has no ally-facing support target, force self-only survival, interrupt line of effect, or wait for Dew to expire.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Returning Source Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes hostile damage, suffers hostile drain/backlash damage, or would lose a maintained technique from damage or backlash.",
            "cost": "1 Spirit-Source Dew",
            "range": "30 feet",
            "target": "Self or one ally within 30 feet",
            "attack_or_save": "",
            "effect": "Spend 1 Spirit-Source Dew from an earlier event. Reduce the triggering hostile damage, hostile drain damage, or hostile backlash damage by your Proficiency Bonus + your Path key ability modifier. If the protected target is an ally other than you, that ally also has Advantage on the next Constitution saving throw, cultivation check, or other check made before the start of your next turn to maintain Concentration, maintain a technique rhythm, or resist the same source of backlash or drain. This does not restore CP and does not erase hidden injuries, deviations, major curses, or major diseases.",
            "duration": "",
            "limit": "Requires Reaction and 1 Spirit-Source Dew from a prior event. Does not permit same-event spending.",
            "counterplay": "Use burst damage, non-damage control, multiple simultaneous threats, isolation, or self-only pressure. This does not restore CP or cure major afflictions.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Feed the Living Circuit",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "An ally within 30 feet fails a saving throw or cultivation check to maintain Concentration, maintain a technique rhythm, resist hostile drain, resist curse-pressure, resist fear-pressure, or resist spiritual exhaustion.",
            "cost": "1 Spirit-Source Dew",
            "range": "30 feet",
            "target": "One ally within 30 feet",
            "attack_or_save": "",
            "effect": "Spend 1 Spirit-Source Dew from an earlier event after seeing the failed roll. Add your Proficiency Bonus + your Path key ability modifier to the ally’s triggering saving throw or cultivation check. If this changes the failure into a success, the ally gains temporary Hit Points equal to your Proficiency Bonus. This can protect Concentration, technique rhythm, or resistance against hostile drain, curse-pressure, fear-pressure, or spiritual exhaustion. It cannot be used on ordinary attack rolls, ordinary damage rolls, or unrelated skill checks.",
            "duration": "",
            "limit": "Requires Reaction and 1 Spirit-Source Dew from a prior event; ally within 30 feet; eligible maintenance/resistance roll only.",
            "counterplay": "Target the Origin-Spirit cultivator, split the party beyond 30 feet, force multiple failures in one round, or use pressure that is not a maintenance/resistance roll.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Gentle Source Pulse",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Spirit-Source Dew.",
            "cost": "1 Spirit-Source Dew",
            "range": "30 feet",
            "target": "Self or one willing creature within 30 feet",
            "attack_or_save": "",
            "effect": "Spend 1 Spirit-Source Dew. Choose yourself or one willing creature within 30 feet. The target gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. If the target is suffering a minor same-source penalty from hostile drain, fear-pressure, curse-pressure, spiritual exhaustion, or backlash, the GM may also allow the target to end that minor penalty. This cannot end Charmed, Frightened, Incapacitated, Stunned, Paralyzed, Possessed, Exhaustion, major curses, diseases, hidden injuries, deviations, or realm-scale afflictions unless another rule permits it.",
            "duration": "",
            "limit": "Bonus Action; requires 1 Spirit-Source Dew; minor penalty cleanup is GM-bounded.",
            "counterplay": "Apply major conditions, stack multiple penalties, force the cultivator to spend Dew before the key failure, or isolate targets beyond 30 feet.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Open Source Channels",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "This rider is active after the Foundation is Refined.",
            "cost": "",
            "range": "Self / 60 feet support context",
            "target": "Self and supported allies",
            "attack_or_save": "",
            "effect": "This modifies Origin-Spirit Vessel and Generate Spirit-Source Dew. It does not require an additional Reaction, does not require an additional resource spend, and does not permit same-event spending. Origin-Spirit Vessel’s maximum Hit Point increase becomes twice your Proficiency Bonus. When you use a qualifying ally-facing Origin-Spirit support effect and there is clear line of effect, the eligible support and generation range for this Foundation becomes 60 feet instead of 30 feet.",
            "duration": "",
            "limit": "Rider only; no extra action/spend; does not permit same-event resource use.",
            "counterplay": "Break line of effect, spread targets beyond 60 feet, or use effects that do not qualify as outward support.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          },
          {
            "name": "Refined: Shared Circuit Memory",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When Returning Source Guard or Feed the Living Circuit changes damage/failure for an ally.",
            "cost": "",
            "range": "30 or 60 feet if Open Source Channels applies",
            "target": "The protected ally",
            "attack_or_save": "",
            "effect": "This modifies Returning Source Guard and Feed the Living Circuit. It does not require an additional Reaction, does not require an additional resource spend, and does not permit same-event spending. When one of those spends protects an ally and either reduces damage or changes a failed eligible roll into success, the protected ally may either move 5 feet without provoking Opportunity Attacks from the source of the triggering effect, or gain Advantage on its next eligible saving throw or cultivation check against the same source before the start of your next turn.",
            "duration": "",
            "limit": "Rider only; modifies successful ally protection. No extra Reaction/resource.",
            "counterplay": "Use non-source-linked follow-up pressure, immobilize the ally, or attack with a different source.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Origin-Spirit Returning Field",
            "stage": "Perfected",
            "type": "Action",
            "trigger": "On your turn after the Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot Emanation",
            "target": "Self and chosen allies in the emanation",
            "attack_or_save": "",
            "effect": "Once per long rest, as an Action, establish an Origin-Spirit Returning Field for 1 minute. The field is a 30-foot Emanation centered on you. While it lasts, when you generate or spend Spirit-Source Dew, choose one ally in the field; that ally gains temporary Hit Points equal to your Proficiency Bonus. In addition, once per round, when an ally in the field succeeds on a saving throw or cultivation check against hostile drain, backlash, curse-pressure, fear-pressure, or spiritual exhaustion, you may treat that success as a qualifying generation trigger for Spirit-Source Dew even if your support effect did not cause the success. This still obeys maximum 1, once-per-round generation, after-trigger availability, and same-event spend lockout.",
            "duration": "",
            "limit": "Perfected Foundation only; once per long rest; 1 minute; resource cap and same-event lockout remain unchanged.",
            "counterplay": "Break concentration-like field fiction if GM permits, leave the emanation, attack the source-vessel, force multiple failures in one round, or pressure allies with effects outside the listed scope.",
            "source_spheres": [
              "Qiweaving",
              "Life",
              "Protection",
              "Radiance",
              "Spirit Companions",
              "Water",
              "Verdant Growth",
              "Talismans",
              "Alchemy"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Qiweaving",
          "Life",
          "Protection",
          "Radiance",
          "Spirit Companions",
          "Water",
          "Verdant Growth",
          "Talismans",
          "Alchemy"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "Free CP",
          "Sphere access",
          "Unlimited healing",
          "Automatic condition removal",
          "Companion ownership",
          "Detached universal casting",
          "Self-only sustain generation"
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_ORIGIN_SPIRIT_BODY_SOURCE_MUST_CIRCULATE",
            "name": "The Source Must Circulate",
            "text": "Spirit-Source Dew cannot be generated from self-only sustain, private recovery, friendly training loops, voluntary backlash, harmless repeated support, or effects created solely to feed the Foundation.",
            "effect_text": "The Foundation is strongest when support flows outward and returns cleanly. Advancement becomes difficult if the cultivator hoards vitality, treats allies as reservoirs, or makes others dependent on their source-vessel. Refined and Perfected progress should require proof of boundaries, triage, and support under real danger."
          }
        ],
        "hidden_injuries": [
          {
            "id": "INJURY_FOUNDATION_ORIGIN_SPIRIT_BODY_WITHERED_SOURCE_VESSEL",
            "name": "Withered Source Vessel Hidden Injury",
            "text": "The source-vessel becomes dry or polluted. The GM may narrow generation triggers, suppress the passive PB support bonus, or require repair before advancement.",
            "effect_text": "Failed advancement, hostile drain, or repeated overfeeding can leave the cultivator unable to distinguish self from ally. Healing feels thin, qi transfer burns, and support effects may arrive late or unevenly until treated."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_ORIGIN_SPIRIT_BODY_OVERFED_CIRCUIT",
            "name": "Overfed Circuit Strain",
            "text": "The cultivator feeds too much source into a circuit that only needed stability.",
            "effect_text": "Symptoms include ally-dependence, leaking aura, swollen meridians, emotional exhaustion after support, and a reflexive urge to fix every wound before understanding it."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_ORIGIN_SPIRIT_BODY_LIVING_BATTERY",
            "name": "Living Battery Deviation",
            "text": "The cultivator begins to experience their value only as fuel for others.",
            "effect_text": "Support expertise becomes self-erasure. The cultivator may seek harm or exhaustion to prove usefulness and may mistake depletion for compassion."
          },
          {
            "id": "DEVIATION_FOUNDATION_ORIGIN_SPIRIT_BODY_GARDEN_CAGE",
            "name": "Garden Cage Deviation",
            "text": "The cultivator preserves others so tightly that nurture becomes control.",
            "effect_text": "The cultivator begins to over-stabilize allies, prevent risk, and treat autonomy as a wound. This is the support-path mirror of domination."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Clear Stagnant Source Vessel",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use quiet circulation, clean water, breath alignment, and supervised support practice to clear source-vessel stagnation. Success can restore normal Dew generation after overdraw, drain contamination, or self-hoarding injury.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Qiweaving",
            "Life",
            "Water",
            "Alchemy"
          ]
        },
        {
          "name": "Repair: Rebuild Ally Boundary",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Relearn the line between supporting another creature and becoming a resource battery. Success can repair boundary-loss symptoms and prevent support from turning into control.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Protection",
            "Life",
            "Spirit Companions",
            "Karma"
          ]
        },
        {
          "name": "Repair: Diagnose Broken Circuit",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Identify whether an ally-facing circuit failed from drain, curse-pressure, backlash, fear, exhaustion, or the cultivator overfeeding the link. Success grants repair credit before a Refined/Perfected challenge.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Qiweaving",
            "The Hidden Eye",
            "Life",
            "Talismans"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Give Without Becoming Vessel",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must support an ally under real pressure without taking over that ally’s agency, resources, or choices. This tests generosity without self-erasure.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Protection",
            "Qiweaving",
            "Karma"
          ]
        },
        {
          "name": "Challenge: Let the Other Stand",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must stop feeding a circuit after it is stable, allowing an ally to act on their own. This tests whether nurture becomes expertise instead of dependency.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Spirit Companions",
            "Warleader",
            "Protection"
          ]
        },
        {
          "name": "Challenge: Seal the Drain Without Hatred",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must resist a drain, curse, or backlash source while preserving the difference between purging corruption and rejecting all difficult contact.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Protection",
            "Radiance",
            "Water",
            "Qiweaving"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Origin-Spirit Body Record",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A source-vessel scripture, clan diagnosis, or teacher record explaining how the body draws ambient qi without becoming a hollow battery. This is not a combat action unless separately written as one.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Qiweaving",
            "Life",
            "Spirit Companions",
            "Water"
          ]
        },
        {
          "name": "Lineage: Source-Well Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher or elder reads the cultivator’s support circuit and identifies where source, ally, and self have become confused. This supports repair and advancement scenes only by default.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "The Hidden Eye",
            "Qiweaving",
            "Protection",
            "Karma"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "red_lotus_ash_returning_v0_2B",
      "name": "Red Lotus Ash-Returning",
      "number": 3,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Body Refining",
          "Spirit Awakening"
        ],
        "typical_role": "Striker",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Attrition striker and ending-refinement Foundation that becomes strongest after the fight has been made real by wounds, loss, and pressure.",
        "visible_sign": "",
        "warning": "Advancement requires proof that the cultivator can refine endings without worshiping them.",
        "dao_principle": "I can refine endings into power without becoming only a thing of death."
      },
      "resource": {
        "name": "Funeral Ash",
        "maximum": "1",
        "starting": "0",
        "gain": "After you damage a hostile creature below its Hit Point maximum with a Foundation-aligned method; after you survive hostile fire, poison, disease, necrotic, blood-loss, or attrition damage while below your Hit Point maximum; or after a meaningful enemy defeat/mercy/cautery event resolves under real danger.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it.",
        "anti_farming": "Keep targets at full HP, heal wounded targets, deny meaningful attrition, force the cultivator into mercy choices, or let Funeral Ash expire.",
        "spends": [
          "Ash-Returning Strike",
          "Red Lotus Cautery",
          "Ash-Veil Mercy",
          "Refined: Red Lotus Heart-Ash",
          "Refined: Ash Mercy Boundary"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Ash-Returning Meridian",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Fire, Ash, Blood, Yin, Destruction, Poison, Disease, Death, Life-through-cautery, or Protection-through-sacrifice methods that damage, cauterize, preserve, or stabilize through battlefield residue may count as Foundation-aligned when they involve a hostile creature below its Hit Point maximum, your own real attrition, or a meaningful ending-refinement scene. This passive does not generate Funeral Ash by itself and does not require per-round tracking.",
            "duration": "",
            "limit": "Passive only; grants no sphere access and creates no resource by itself.",
            "counterplay": "Heal wounded enemies to full, avoid attrition, use fresh targets, or force mercy choices that test the Foundation rather than feed it.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Red Lotus Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports wounded-target pressure, ash-returning survival, cautery, battlefield grief, poison/disease attrition, blood-loss refinement, and techniques that turn real endings into disciplined power. It does not reward killing helpless creatures, does not grant Death or Blood sphere access, does not make cruelty a virtue, and does not allow friendly harm loops.",
            "duration": "",
            "limit": "Scope only; no sphere, technique, or resource access is granted by this row.",
            "counterplay": "Counter by presenting full-health foes, healing windows, constructs/undead with different attrition logic, or moral tests where harvesting power would be wrong.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Generate Funeral Ash",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you damage a hostile creature below its Hit Point maximum with a Foundation-aligned method; after you survive hostile fire, poison, disease, necrotic, blood-loss, or attrition damage while below your Hit Point maximum; or after a meaningful enemy defeat/mercy/cautery event resolves under real danger.",
            "cost": "",
            "range": "Self / trigger context",
            "target": "Self resource",
            "attack_or_save": "",
            "effect": "After the listed event fully resolves, if you are conscious and do not already have Funeral Ash, gain Funeral Ash 1/1. You can generate Funeral Ash no more than once per round. Funeral Ash expires at the end of your next turn. Funeral Ash generated by an event cannot be spent on that same event. Friendly, staged, harmless, voluntary, training, or helpless-target events do not qualify.",
            "duration": "",
            "limit": "Maximum 1; once per round; generated after trigger resolves; expires end next turn; no same-event spend.",
            "counterplay": "Keep targets at full HP, heal wounded targets, deny meaningful attrition, force the cultivator into mercy choices, or let Funeral Ash expire.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Ash-Returning Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature that is below its Hit Point maximum with a Foundation-aligned attack or technique.",
            "cost": "1 Funeral Ash",
            "range": "Attack or technique range",
            "target": "One hostile creature below its Hit Point maximum",
            "attack_or_save": "",
            "effect": "Spend 1 Funeral Ash after the triggering hit resolves. Add fire, necrotic, poison, or slashing damage equal to your Proficiency Bonus + your Path key ability modifier. If the target is below half its Hit Point maximum after this damage, it cannot regain Hit Points until the start of your next turn unless a higher-Realm feature, artifact, or explicit immunity overrides this effect.",
            "duration": "",
            "limit": "Spend only after a qualifying hit against a wounded hostile creature; cannot spend on same event that generated the Ash.",
            "counterplay": "Heal targets before the strike, keep them at full HP, use immunity/resistance, or rely on higher authority healing.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Red Lotus Cautery",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take hostile fire, necrotic, poison, disease, blood-loss, or attrition damage, or when a hostile creature below its Hit Point maximum damages you.",
            "cost": "1 Funeral Ash",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Funeral Ash as a Reaction. Reduce the triggering damage by your Proficiency Bonus + your Path key ability modifier. If you are below half your Hit Point maximum or the damage source is below half its Hit Point maximum, increase the reduction by your Proficiency Bonus.",
            "duration": "",
            "limit": "Reaction spend; cannot reduce self-inflicted, voluntary, training, or same-event generated damage.",
            "counterplay": "Attack before Funeral Ash is available, use fresh full-health sources, use non-attrition pressure, or bait the Reaction.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Ash-Veil Mercy",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Funeral Ash.",
            "cost": "1 Funeral Ash",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Funeral Ash as a Bonus Action. You gain temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Before the start of your next turn, you have Advantage on the next saving throw you make against fear, poison, disease, fire, necrotic, blood-loss, despair pressure, or corpse/battlefield contamination.",
            "duration": "",
            "limit": "Bonus Action spend; one next-save Advantage only; temp HP follows ordinary replacement rules.",
            "counterplay": "Attack after the save is spent, use unrelated control, deny Bonus Action timing, or strip temp HP with ordinary damage.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Red Lotus Heart-Ash",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Always active after the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Ash-Returning Meridian, Ash-Returning Strike, and Red Lotus Cautery. It does not require an additional action, Reaction, or Funeral Ash spend, and it does not permit same-event spending. Your maximum Hit Point increase from this Foundation becomes 2×your Proficiency Bonus. When you spend Funeral Ash on Ash-Returning Strike or Red Lotus Cautery, add your Proficiency Bonus to one numeric damage or reduction value from that spend.",
            "duration": "",
            "limit": "Refined only; rider modifies base spends; no extra action/resource.",
            "counterplay": "Suppress the Foundation, heal wounded enemies, avoid triggering Funeral Ash, or use higher-authority effects.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          },
          {
            "name": "Refined: Ash Mercy Boundary",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Funeral Ash and choose not to reduce a helpless or defeated creature to 0 HP solely for power.",
            "cost": "",
            "range": "Self or one creature within 30 feet",
            "target": "Self or one creature within 30 feet",
            "attack_or_save": "",
            "effect": "This modifies Funeral Ash spends in scenes where the cultivator uses the Foundation to preserve, cauterize, spare, or end cleanly rather than harvest cruelty. It does not require an additional action or resource and does not create Funeral Ash. After the triggering event resolves, you or one creature within 30 feet gains temporary Hit Points equal to your Proficiency Bonus.",
            "duration": "",
            "limit": "Refined rider only; requires genuine mercy/restraint/cautery context; not a combat farming tool.",
            "counterplay": "Present enemies where mercy is unsafe, use false surrenders, or separate the cultivator from the creature they could preserve.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Ninefold Red Lotus Ash Garden",
            "stage": "Perfected",
            "type": "Action",
            "trigger": "On your turn after the Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot Emanation",
            "target": "Self and chosen creatures in the emanation",
            "attack_or_save": "",
            "effect": "Once per long rest, as an Action, establish a 30-foot Emanation for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. While the garden lasts, your qualifying Foundation-aligned hits against hostile creatures below their Hit Point maximum deal additional fire, necrotic, poison, or slashing damage equal to your Proficiency Bonus. In addition, a hostile creature dropping to 0 Hit Points, being spared after defeat, or being stabilized through cautery inside the garden may count as a Funeral Ash generation trigger for you. Funeral Ash maximum remains 1 and all generation timing and same-event lockout rules still apply.",
            "duration": "",
            "limit": "Perfected only; once per long rest; 1 minute; resource cap remains 1.",
            "counterplay": "Leave the emanation, keep enemies at full HP, exploit mercy choices, use non-wounded targets, or pressure allies outside the garden.",
            "source_spheres": [
              "Fire",
              "Ash",
              "Blood",
              "Yin",
              "Destruction",
              "Poison",
              "Disease",
              "Death",
              "Life",
              "Protection"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Fire",
          "Ash",
          "Blood",
          "Yin",
          "Destruction",
          "Poison",
          "Disease",
          "Death",
          "Life",
          "Protection"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_RED_LOTUS_ASH_RETURNING_ENDINGS_MUST_BE_REAL",
            "name": "Endings Must Be Real",
            "text": "Funeral Ash cannot be generated from friendly effects, staged wounds, harmless creatures, training scenes, voluntary harm, repeated self-created damage, or killing helpless targets solely to feed the Foundation.",
            "effect_text": "Advancement requires proof that the cultivator can refine endings without worshiping them. Mercy choices, cautery, battlefield grief, and restraint matter as much as damage."
          }
        ],
        "hidden_injuries": [
          {
            "id": "INJURY_FOUNDATION_RED_LOTUS_ASH_RETURNING_ASH_LUNG_HEART",
            "name": "Ash-Lung Heart Hidden Injury",
            "text": "The lungs, blood, or heartfire hold too much funeral residue; healing feels like cautery and grief heats the meridians.",
            "effect_text": "The GM may narrow Funeral Ash generation, suppress Red Lotus spend riders, or require repair before Refined/Perfected advancement after cruelty, massacre exposure, or failed breakthrough."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_RED_LOTUS_ASH_RETURNING_CINDER_HEART_NUMBNESS",
            "name": "Cinder Heart Numbness",
            "text": "Grief and compassion burn down into efficiency.",
            "effect_text": "The cultivator becomes more reliable in attrition but worse at recognizing when an ending should be honored rather than used."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_RED_LOTUS_ASH_RETURNING_RED_LOTUS_HUNGER",
            "name": "Red Lotus Hunger",
            "text": "The cultivator feels spiritually incomplete unless enemies are wounded.",
            "effect_text": "This deviation pushes the character toward needless bloodshed and makes mercy feel like starvation."
          },
          {
            "id": "DEVIATION_FOUNDATION_RED_LOTUS_ASH_RETURNING_ASH_MERCY_CONFUSION",
            "name": "Ash-Mercy Confusion",
            "text": "The cultivator cannot distinguish killing from release.",
            "effect_text": "This deviation corrupts the proof of the Foundation and should complicate breakthroughs, healing scenes, and sect judgment."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Clean Funeral Smoke From the Lungs",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use breath training, ash washing, grief rites, and cautery discipline to clear residue from the lungs, blood, and heartfire after cruelty, massacre exposure, or failed breakthrough.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Ash",
            "Life",
            "Protection"
          ]
        },
        {
          "name": "Repair: Mercy Cautery Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Practice ending a wound cleanly without harvesting more power from it. Success can repair Ash-Mercy Confusion and restore safe Funeral Ash generation.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Fire",
            "Protection",
            "Karma"
          ]
        },
        {
          "name": "Repair: Sort Grief From Hunger",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Separate grief, wrath, and usefulness through guided meditation or battlefield rites so Red Lotus Hunger does not become the Foundation’s center.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Spirit Companions",
            "Karma",
            "Yin",
            "Radiance"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Spare the Wounded Enemy",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Prove that the Foundation can refine an ending without requiring slaughter. The cultivator must spare or preserve a defeated enemy under real pressure.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Protection",
            "Karma",
            "Fire"
          ]
        },
        {
          "name": "Challenge: Cauterize Without Cruelty",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Stabilize a terrible wound, plague, fire, poison, or battlefield injury without turning the patient into fuel.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Poison",
            "Disease",
            "Fire"
          ]
        },
        {
          "name": "Challenge: Ash That Remembers Compassion",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Survive or win a long attrition battle and then choose the correct ending: mercy, execution, retreat, burial, or release.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Ash",
            "Blood",
            "Yin",
            "Karma"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Red Lotus Funeral Flame Record",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A battlefield or cremation-fire lineage that teaches ash-returning without murder worship. This is not a combat action unless separately written as one.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Ash",
            "Yin",
            "Karma"
          ]
        },
        {
          "name": "Lineage: Cautery Mercy Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher, medic, monk, or battlefield elder diagnoses whether the cultivator refines endings or has begun to crave them.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Protection",
            "The Hidden Eye",
            "Fire"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "divine_king_body_v0_2B",
      "name": "Divine King Body",
      "number": 4,
      "profile": {
        "grade": "Rare",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening",
          "Body Refining"
        ],
        "typical_role": "Defender / Support / Striker",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body and qi can project a dignified moon-over-sea manifestation. You are strongest when your power is visible, protective, and composed under rival pressure.",
        "visible_sign": "",
        "warning": "The Foundation is strongest when the cultivator manifests openly enough for pressure, protection, and court-bearing to matter.",
        "dao_principle": "The moon rises over the sea only when depth and clarity answer each other."
      },
      "resource": {
        "name": "Moon-Sea Radiance",
        "maximum": "1",
        "starting": "0",
        "gain": "After one of these events resolves while you are conscious: you spend CP on an eligible visible manifestation, aura, barrier, pressure, Radiance, Water, Protection, Force, Stars, Qiweaving, or Spirit Companions effect; a hostile creature fails a saving throw or ability check against your eligible visible manifestation or pressure effect; or you reduce damage to yourself or an ally with an eligible visible protection, barrier, sea-moon, or court-presence effect.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it. Harmless display, self-only hidden sustain, and fake manifestation loops do not generate Moon-Sea Radiance.",
        "anti_farming": "Deny visibility, break the manifestation, avoid contesting the field, force self-only play, or make the effect harmless/rehearsed rather than hostile or meaningful.",
        "spends": [
          "Sea-Moon Interposition",
          "Moon-Disc Descent",
          "Sea-Risen Bearing",
          "Refined: Court Moon Witness",
          "Perfected: Sea-Risen Moon Court"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Divine King Sea-Moon Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Once per round, when you use a Radiance, Water, Protection, Force, Stars, Qiweaving, or Spirit Companions talent, technique, or Foundation-supported method that creates or maintains a visible manifestation, aura, pressure field, barrier, moonlight-like radiance, inner-sea pressure, or dignified court-presence effect, add your Proficiency Bonus to one roll or flat value of that effect. The effect must be perceptible or openly declared through light, water, pressure, spiritual bearing, a visible mark, or a comparable manifestation. Hidden, purely private, or self-only sustain effects do not qualify unless they also create a meaningful visible manifestation or protect another creature.",
            "duration": "",
            "limit": "Once per round for the PB Foundation bonus. Does not grant sphere access, free domains, free moon control, or free water creation.",
            "counterplay": "Suppress, obscure, counterspell, dispel, shatter, or force the manifestation to be hidden, sealed, or made imperceptible. Self-only hidden effects do not qualify.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Stars",
              "Qiweaving",
              "Spirit Companions"
            ]
          },
          {
            "name": "Fixed Scope: Moon Over the Inner Sea",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Rules reference for what this Foundation does and does not grant.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation represents a rare divine body whose inner sea can manifest as bright moonlight, pressure, and noble court-bearing. It supports visible manifestation, open pressure, barrier/protection, moonlight-like radiance, waterlike sea-pressure, and dignified command of presence. It does not grant the Radiance, Water, Protection, Force, Stars, Qiweaving, or Spirit Companions spheres; it does not create a permanent moon, free flight, free invisibility, free water, automatic domains, social rank, or universal authority. Expression phrases such as bright moon over the sea, divine king bearing, and inner-sea tide are descriptive unless a listed action supplies a mechanical effect.",
            "duration": "",
            "limit": "Always apply this scope before allowing Foundation benefits.",
            "counterplay": "If a claimed use does not involve a legal sphere, a visible manifestation, or listed Foundation row, it does not qualify.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Stars",
              "Qiweaving",
              "Spirit Companions"
            ]
          },
          {
            "name": "Generate Moon-Sea Radiance",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After one of these events resolves while you are conscious: you spend CP on an eligible visible manifestation, aura, barrier, pressure, Radiance, Water, Protection, Force, Stars, Qiweaving, or Spirit Companions effect; a hostile creature fails a saving throw or ability check against your eligible visible manifestation or pressure effect; or you reduce damage to yourself or an ally with an eligible visible protection, barrier, sea-moon, or court-presence effect.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain 1 Moon-Sea Radiance. Maximum 1. You can generate Moon-Sea Radiance only once per round. It is generated after the triggering event resolves and cannot be spent on that same event. It expires at the end of your next turn. You cannot generate Moon-Sea Radiance from self-only hidden sustain, harmless display, friendly training loops, repeated meaningless manifestation, or effects created only to feed the Foundation.",
            "duration": "",
            "limit": "Maximum 1. Once per round. Expires end of next turn. Same-event spend not allowed.",
            "counterplay": "Deny visibility, break the manifestation, avoid contesting the field, force self-only play, or make the effect harmless/rehearsed rather than hostile or meaningful.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Stars",
              "Qiweaving",
              "Spirit Companions"
            ]
          },
          {
            "name": "Sea-Moon Interposition",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes damage while you are conscious and either the target is inside your visible manifestation/court-presence or you have line of effect to interpose sea-moon pressure.",
            "cost": "1 Moon-Sea Radiance",
            "range": "30 feet",
            "target": "Self or one ally taking damage",
            "attack_or_save": "",
            "effect": "Spend 1 Moon-Sea Radiance to reduce the triggering damage by your Proficiency Bonus + your Path key ability modifier. If the damage source is inside, crossing, suppressing, or directly contesting your visible manifestation, barrier, pressure field, or court-presence, reduce the damage by an additional Proficiency Bonus. This is a Reaction. It cannot be used on the same event that generated the Moon-Sea Radiance.",
            "duration": "",
            "limit": "Requires 1 Moon-Sea Radiance and your Reaction. Cannot spend on same generation event.",
            "counterplay": "Attack from outside the manifestation, break line of effect, exhaust the reaction, or force damage before Moon-Sea Radiance is generated.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Qiweaving"
            ]
          },
          {
            "name": "Moon-Disc Descent",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature with an eligible close, ranged, or technique attack, or after a hostile creature fails a saving throw against your eligible visible manifestation, aura, pressure, Radiance, Water, Force, Protection, Stars, or Qiweaving effect.",
            "cost": "1 Moon-Sea Radiance",
            "range": "Same target as triggering effect",
            "target": "One hostile creature affected by your triggering effect",
            "attack_or_save": "",
            "effect": "Spend 1 Moon-Sea Radiance after the triggering effect resolves. Add radiant, force, or bludgeoning damage equal to your Proficiency Bonus + your Path key ability modifier to the affected hostile creature. Choose the damage type that best matches the triggering manifestation. The target's Speed is reduced by 10 feet until the start of your next turn as moon-disc pressure weighs on it. This does not knock the target Prone, restrain it, or prevent teleportation unless another effect does so.",
            "duration": "",
            "limit": "Once per spend. Requires 1 Moon-Sea Radiance. Cannot spend on the same event that generated it.",
            "counterplay": "Avoid being affected by the manifestation, resist the triggering save, break visibility, use teleportation, or force the cultivator to spend the resource defensively.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Force",
              "Stars",
              "Qiweaving",
              "Protection"
            ]
          },
          {
            "name": "Sea-Risen Bearing",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have 1 Moon-Sea Radiance.",
            "cost": "1 Moon-Sea Radiance",
            "range": "Self; 10-foot visible manifestation until start of next turn",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Moon-Sea Radiance as a Bonus Action. Gain temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, a visible sea-moon bearing surrounds you in a 10-foot Emanation. This bearing is perceptible light, pressure, waterlike shimmer, or spiritual court-presence. The first time before the start of your next turn that a hostile creature willingly enters the Emanation or starts its turn there, its Speed is reduced by 5 feet until the end of that turn. This bearing can satisfy this Foundation's visible-manifestation requirement, but spending Moon-Sea Radiance on Sea-Risen Bearing does not itself generate new Moon-Sea Radiance.",
            "duration": "",
            "limit": "Requires Bonus Action and 1 Moon-Sea Radiance. Does not generate Moon-Sea Radiance by itself.",
            "counterplay": "Wait out the short duration, attack from range, avoid entering the Emanation, remove temp HP, or force the cultivator to spend the resource elsewhere.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Moon Above the Sea",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Always active after this Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Divine King Sea-Moon Vessel and Sea-Moon Interposition. Your maximum Hit Point increase from this Foundation becomes twice your Proficiency Bonus. When the target of Sea-Moon Interposition is inside your visible manifestation, barrier, aura, sea-moon bearing, or Perfected court, the range of Sea-Moon Interposition becomes 60 feet. This rider does not require an additional Reaction. It does not require an additional resource spend. It does not permit same-event spending unless another row explicitly says so.",
            "duration": "",
            "limit": "Refined stage only. Modifies listed base effects; no extra action/resource.",
            "counterplay": "Keep allies outside the manifestation, break visibility, force long range beyond 60 ft, or exhaust the base Reaction/resource.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Stars",
              "Qiweaving",
              "Spirit Companions"
            ]
          },
          {
            "name": "Refined: Court Moon Witness",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Moon-Sea Radiance on Sea-Moon Interposition or Moon-Disc Descent after this Foundation is Refined.",
            "cost": "",
            "range": "Same target as modified spend",
            "target": "Same target as modified spend",
            "attack_or_save": "",
            "effect": "This modifies Sea-Moon Interposition and Moon-Disc Descent. When you spend Moon-Sea Radiance on Sea-Moon Interposition, the protected creature may also move 5 feet without provoking Opportunity Attacks from the triggering damage source. When you spend Moon-Sea Radiance on Moon-Disc Descent, the affected hostile creature cannot benefit from Advantage on the next Strength or Dexterity check it makes to shove, grapple, escape, or force movement before the start of your next turn. Choose only the rider attached to the base spend used. This rider does not require an additional Reaction, Bonus Action, or resource spend. It does not permit same-event spending.",
            "duration": "",
            "limit": "Refined stage only. Modifies the base spend used; no extra action/resource.",
            "counterplay": "Use non-contest effects, attack another target, force the resource defensively, or wait until the rider expires.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Qiweaving"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Sea-Risen Moon Court",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn after this Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot Emanation",
            "target": "Self and creatures in the Emanation",
            "attack_or_save": "",
            "effect": "Once per long rest, activate Sea-Risen Moon Court as a Bonus Action. For 1 minute, a 30-foot Emanation of bright moon over inner sea, dignified pressure, and court-bearing surrounds you. When you activate it, gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. While the court lasts, allied creatures in the Emanation count as inside your visible manifestation for Divine King Body effects, and once on each of your turns you may add your Proficiency Bonus to the first eligible Radiance, Water, Protection, Force, Stars, Qiweaving, Spirit Companions, manifestation, pressure, or protection roll or flat value you create through the court. The court does not create difficult terrain by itself, does not prevent teleportation, and does not grant free attacks or free Moon-Sea Radiance. Moon-Sea Radiance remains max 1, once/round, after trigger resolves, and same-event spend locked.",
            "duration": "",
            "limit": "Perfected stage only. Once per long rest. 1 minute. Does not change resource cap or same-event lockout.",
            "counterplay": "Leave the Emanation, break line of effect, suppress the manifestation, wait out the minute, force Concentration-like disruption if the GM uses a scene contest, or attack from beyond the court.",
            "source_spheres": [
              "Radiance",
              "Water",
              "Protection",
              "Force",
              "Stars",
              "Qiweaving",
              "Spirit Companions"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Radiance",
          "Water",
          "Protection",
          "Force",
          "Stars",
          "Qiweaving",
          "Spirit Companions"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "Sphere access",
          "Free moon control",
          "Free water creation",
          "Permanent domain",
          "Social rank or command authority",
          "Free flight",
          "Free invisibility",
          "Universal anti-magic",
          "Hidden self-only resource generation"
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_DIVINE_KING_BODY_MOON_MUST_BE_SEEN",
            "name": "The Moon Must Be Seen",
            "text": "Moon-Sea Radiance cannot be generated from hidden self-only sustain, harmless display, friendly training loops, purely private meditation, or effects created only to feed the Foundation.",
            "effect_text": "The Foundation is strongest when the cultivator manifests openly enough for pressure, protection, and court-bearing to matter. Advancement becomes difficult if the cultivator hides behind image, status, or theatrical display instead of using manifestation to protect or contest real pressure."
          }
        ],
        "hidden_injuries": [
          {
            "id": "INJURY_FOUNDATION_DIVINE_KING_BODY_DROWNED_MOON_SEA",
            "name": "Drowned Moon-Sea Hidden Injury",
            "text": "The inner sea swells over the moon image. The GM may narrow generation triggers, suppress the PB passive bonus, or require repair before advancement.",
            "effect_text": "Failed advancement, broken manifestation, or humiliation under rival pressure can make the court-presence heavy, waterlogged, and slow to answer. The cultivator feels pressure without clarity."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_DIVINE_KING_BODY_MOON_PRIDE_TIDE",
            "name": "Moon-Pride Tide Strain",
            "text": "The cultivator pushes manifestation pressure beyond what the scene requires.",
            "effect_text": "Symptoms include over-bright aura, needless display, pressure that makes allies tense, and refusal to fight plainly when a simple method would work."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_DIVINE_KING_BODY_LONELY_MOON_KING",
            "name": "Lonely Moon King Deviation",
            "text": "The cultivator begins to mistake isolation above others for true nobility.",
            "effect_text": "The Foundation turns court-bearing into separation. Allies become subjects, rivals become insults, and the cultivator feels diminished whenever they must stand beside others rather than above them."
          },
          {
            "id": "DEVIATION_FOUNDATION_DIVINE_KING_BODY_REFLECTED_MAJESTY",
            "name": "Reflected Majesty Deviation",
            "text": "The image of divinity becomes more important than the Dao behind it.",
            "effect_text": "The cultivator protects the appearance of power even when the practical manifestation is wrong. Illusion, status, and pressure can replace judgment."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Still the Moon-Sea",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use quiet water reflection, moonlight visualization, breath settling, and manifestation restraint to stop the inner sea from surging until it drowns perception. Success can restore normal Moon-Sea Radiance timing or remove GM-imposed narrowing from a Drowned Moon-Sea injury.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        },
        {
          "name": "Repair: Reanchor the Divine Bearing",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use posture correction, public oath, teacher critique, or court-bearing practice to separate genuine manifestation from social arrogance. Success can repair a cracked presence, prevent allies from being crushed by pressure, or prepare a Refined breakthrough.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        },
        {
          "name": "Repair: Wash Out False Reflection",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use mirror-water, witness testimony, and controlled defeat to remove false-majesty residues. Success can suppress Reflected Majesty Deviation symptoms or restore the ability to manifest without demanding recognition.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Manifest Without Crushing",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must manifest visible pressure in a scene with weaker allies or bystanders and succeed without using the court-presence to silence, dominate, or frighten those they mean to protect.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        },
        {
          "name": "Challenge: Hold the Court Under Rival Pressure",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must maintain a visible manifestation while a rival breaks anchors, attacks from outside the court, mocks their legitimacy, or forces them to choose between display and practical defense.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        },
        {
          "name": "Challenge: Let the Moon Set",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator must willingly release an impressive manifestation when continuing it would endanger allies, waste power, or turn the scene into a contest of pride.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Divine King Body Record",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A clan record, ancient physique commentary, or manifestation manual explaining how the inner sea and bright moon image become a stable body-foundation rather than a decorative phenomenon. This is not a combat action and does not grant sphere access by itself.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        },
        {
          "name": "Lineage: Sea-Moon Manifestation Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher, elder, spirit witness, or manifestation specialist diagnoses whether the cultivator’s visible pressure is balanced, hollow, oppressive, or fractured. This can support repair, breakthrough prep, or Refined/Perfected advancement but is not a GM Screen combat row.",
          "duration": "",
          "limit": "Downtime, repair, lineage, or challenge scene only; not a combat action unless separately written as a full combat row.",
          "counterplay": "Requires appropriate scene pressure, teacher diagnosis, materials, proof, or GM approval. Does not grant combat resources by itself.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "jade_furnace_meridian_v0_2B",
      "name": "Jade Furnace Meridian",
      "number": 5,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening",
          "Body Refining through body-as-cauldron methods"
        ],
        "typical_role": "Hybrid",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Controlled CP-efficiency and refinement Foundation that rewards spending power correctly while preventing free-technique loops.",
        "visible_sign": "",
        "warning": "Advancement becomes difficult if the cultivator hoards CP, refuses decisive expenditure, or spends wastefully to prove mastery.",
        "dao_principle": "Preserve power without becoming miserly; spend power without becoming wasteful."
      },
      "resource": {
        "name": "Furnace Heat",
        "maximum": "1",
        "starting": "0",
        "gain": "After you pay CP for a Foundation-aligned technique, refinement, talisman, formation, medicine, purification, or body-as-cauldron method with final CP cost 1 or higher, and that event resolves.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it.",
        "anti_farming": "Force the cultivator to stop spending CP, bait wasteful spending, suppress the furnace, or let Heat expire.",
        "spends": [
          "Banked Furnace Expenditure",
          "Furnace Vent Guard",
          "Jade Furnace Release",
          "Refined: Jade Furnace Core",
          "Refined: Clean Residue Circulation",
          "Perfected: Jade Furnace Meridian Cycle"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Jade Furnace Meridian Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Alchemy, Fire, Qiweaving, Talismans, Formations, Radiance, Protection, Poison, Life, Blacksmith, and body-as-cauldron methods that spend CP to refine, purify, ignite, seal, heal, stabilize, or transform may count as Foundation-aligned. You have Advantage on Constitution saving throws against hostile poison, contaminated qi, furnace backlash, miasma, and technique-residue sickness. This passive creates no cost reduction by itself and requires no per-round tracking.",
            "duration": "",
            "limit": "Passive only; no automatic CP reduction; no sphere access granted.",
            "counterplay": "Poison or clog the furnace, force hesitation, deny proper fuel/materials, or exploit contaminated residue.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Jade Furnace Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports controlled CP expenditure, furnace timing, alchemical refinement, talisman combustion, formation ignition, purification, poison refinement, medicine, body-as-cauldron training, and safe residue venting. It does not grant free CP, does not reduce costs without Furnace Heat, does not create materials, and does not allow final-cost-0 loops to generate Heat.",
            "duration": "",
            "limit": "Scope only; grants no sphere, talent, item, or CP pool.",
            "counterplay": "Use anti-magic/anti-qi pressure, contaminated ingredients, broken anchors, forced overchanneling, or situations where spending now is wrong.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Generate Furnace Heat",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you pay CP for a Foundation-aligned technique, refinement, talisman, formation, medicine, purification, or body-as-cauldron method with final CP cost 1 or higher, and that event resolves.",
            "cost": "",
            "range": "Self",
            "target": "Self resource",
            "attack_or_save": "",
            "effect": "After the qualifying CP expenditure fully resolves, if you are conscious and do not already have Furnace Heat, gain Furnace Heat 1/1. You can generate Furnace Heat no more than once per round. Furnace Heat expires at the end of your next turn. Furnace Heat generated by a technique cannot be spent on that same technique. Techniques with final CP cost 0, free techniques, staged expenditures, friendly loops, and effects created only to feed the Foundation do not generate Furnace Heat.",
            "duration": "",
            "limit": "Maximum 1; once per round; after trigger resolves; expires end next turn; final-cost-0/free techniques do not generate.",
            "counterplay": "Force the cultivator to stop spending CP, bait wasteful spending, suppress the furnace, or let Heat expire.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Banked Furnace Expenditure",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Before you pay CP for a Foundation-aligned technique, refinement, talisman, formation, medicine, purification, or body-as-cauldron method.",
            "cost": "1 Furnace Heat",
            "range": "Self",
            "target": "One qualifying CP expenditure",
            "attack_or_save": "",
            "effect": "Spend 1 Furnace Heat before paying CP. Reduce the CP cost of the triggering Foundation-aligned technique or method by 1, to a minimum final cost of 1. This cannot reduce a cost to 0 unless another feature explicitly says so. If another feature reduces the final cost to 0, that technique cannot generate Furnace Heat.",
            "duration": "",
            "limit": "Minimum final CP cost 1 from this spend; no same-event generation; does not apply to non-CP costs.",
            "counterplay": "Increase costs, use anti-efficiency pressure, force non-CP problems, or bait Heat into a low-value spend.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Furnace Vent Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take hostile fire, poison, acid, miasma, contaminated qi, furnace backlash, or technique-residue damage, or when such pressure would force a Constitution save.",
            "cost": "1 Furnace Heat",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Furnace Heat as a Reaction. Reduce the triggering damage by your Proficiency Bonus + your Path key ability modifier. If the source is poison, miasma, contaminated qi, furnace backlash, or technique residue, increase the reduction by your Proficiency Bonus. If the trigger is an eligible Constitution save rather than damage, add PB + key ability modifier to that save instead.",
            "duration": "",
            "limit": "Reaction spend; applies only to listed damage/backlash/residue/CON-save pressure.",
            "counterplay": "Use unrelated damage, trigger after Heat is gone, bait the Reaction, or attack the furnace with sealing effects.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Jade Furnace Release",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a Foundation-aligned CP technique you use deals damage, restores HP, grants temp HP, reduces damage, purifies, or stabilizes a target.",
            "cost": "1 Furnace Heat",
            "range": "Technique range",
            "target": "One affected target or value",
            "attack_or_save": "",
            "effect": "Spend 1 Furnace Heat after the triggering technique resolves. Add your Proficiency Bonus + your Path key ability modifier to one damage, healing, temporary Hit Point, damage reduction, purification, or stabilization value from that technique. The technique must have had a final CP cost of 1 or higher.",
            "duration": "",
            "limit": "No-action spend after qualifying final-cost-1+ CP technique; cannot spend on same event that generated Heat.",
            "counterplay": "Force low-value targets, use resistance/immunity, deny CP expenditure, or let Heat expire before a strong technique.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Jade Furnace Core",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Always active after the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Jade Furnace Meridian Frame and Banked Furnace Expenditure. It does not require an additional action, Reaction, or Furnace Heat spend, and it does not permit same-event spending. Your maximum Hit Point increase from this Foundation becomes 2×your Proficiency Bonus. When you spend Furnace Heat on Banked Furnace Expenditure, reduce the qualifying CP cost by 2 instead of 1, still to a minimum final cost of 1.",
            "duration": "",
            "limit": "Refined only; minimum final cost 1 remains; no free-technique loop.",
            "counterplay": "Raise costs, apply anti-efficiency pressure, or use effects that punish CP expenditure after the discount.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          },
          {
            "name": "Refined: Clean Residue Circulation",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Furnace Heat on any base spend.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Furnace Heat spends. It does not require an additional action, Reaction, or Furnace Heat spend. After you spend Furnace Heat, you have Advantage on the next Constitution saving throw you make before the end of your next turn against poison, miasma, furnace backlash, contaminated qi, or technique-residue sickness.",
            "duration": "",
            "limit": "Refined rider only; one next-save Advantage; no extra action/resource.",
            "counterplay": "Use unrelated saves, wait until the Advantage expires, or attack with non-residue pressure.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Jade Furnace Meridian Cycle",
            "stage": "Perfected",
            "type": "Action",
            "trigger": "On your turn after the Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Once per long rest, as an Action, establish a Jade Furnace Meridian Cycle for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. While the cycle lasts, the first Foundation-aligned technique or method you pay CP for on each of your turns costs 1 less CP, to a minimum final cost of 1. This discount does not require Furnace Heat and does not by itself generate Furnace Heat. Furnace Heat maximum remains 1, generation remains once per round after trigger resolution, and same-event spend lockout remains unchanged.",
            "duration": "",
            "limit": "Perfected only; once per long rest; 1 minute; first qualifying CP payment on your turn only; minimum cost 1.",
            "counterplay": "Interrupt the cycle, force non-CP actions, use anti-furnace pressure, or bait the discount on a low-value technique.",
            "source_spheres": [
              "Alchemy",
              "Fire",
              "Qiweaving",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Poison",
              "Life",
              "Blacksmith"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Alchemy",
          "Fire",
          "Qiweaving",
          "Talismans",
          "Formations",
          "Radiance",
          "Protection",
          "Poison",
          "Life",
          "Blacksmith"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_JADE_FURNACE_MERIDIAN_FURNACE_MUST_TRANSFORM",
            "name": "The Furnace Must Transform",
            "text": "Furnace Heat cannot be generated from free techniques, final-cost-0 techniques, staged expenditures, friendly loops, or effects created only to feed the Foundation.",
            "effect_text": "Advancement becomes difficult if the cultivator hoards CP, refuses decisive expenditure, or spends wastefully to prove mastery. Furnace refinement must transform something real."
          }
        ],
        "hidden_injuries": [
          {
            "id": "INJURY_FOUNDATION_JADE_FURNACE_MERIDIAN_COLD_FURNACE",
            "name": "Cold Furnace Hidden Injury",
            "text": "The furnace meridians hesitate before ignition; first expenditure after rest feels slow, painful, or inefficient.",
            "effect_text": "The GM may narrow Furnace Heat generation or require repair when the cultivator fails through hoarding, hesitation, contaminated residue, or unsafe forced efficiency."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_JADE_FURNACE_MERIDIAN_POISONED_RESIDUE_STAGNATION",
            "name": "Poisoned Residue Stagnation",
            "text": "Technique residue fails to refine and clings to the meridians.",
            "effect_text": "Poison, miasma, curse residue, or failed purification can make later CP cycling painful until cleaned through repair."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_JADE_FURNACE_MERIDIAN_MISERS_FLAME",
            "name": "Miser’s Flame Deviation",
            "text": "The cultivator treats every expenditure as loss.",
            "effect_text": "The character hoards power past the correct moment and may fail breakthroughs that require decisive spending."
          },
          {
            "id": "DEVIATION_FOUNDATION_JADE_FURNACE_MERIDIAN_WASTEFIRE",
            "name": "Wastefire Deviation",
            "text": "The cultivator spends power to prove mastery, confusing heat with refinement.",
            "effect_text": "The character chases display and may burn resources when patience or restraint was the Dao-correct answer."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Rekindle Cold Furnace",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use breath-fire, pill smoke, controlled CP expenditure, and teacher-supervised ignition to repair hesitation and cold furnace injury.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "Fire",
            "Qiweaving",
            "Life"
          ]
        },
        {
          "name": "Repair: Purge Poisoned Residue",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Vent contaminated qi, poison, miasma, or failed refinement residue through medicine, talisman wash, and furnace circulation.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "Poison",
            "Radiance",
            "Protection"
          ]
        },
        {
          "name": "Repair: Balance Miser and Wastefire",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Practice spending at the correct moment: neither hoarding nor wasting CP. Success supports Refined/Perfected advancement.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Qiweaving",
            "Karma",
            "Talismans",
            "Formations"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Spend When Mercy Requires It",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use scarce CP decisively to save, purify, or stabilize someone instead of hoarding for later advantage.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Life",
            "Protection",
            "Radiance",
            "Qiweaving"
          ]
        },
        {
          "name": "Challenge: Stop Before the Pill Burns",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "End a refinement sequence before greed or display ruins it. This tests efficiency as judgment, not maximum output.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "Fire",
            "Poison",
            "Blacksmith"
          ]
        },
        {
          "name": "Challenge: Vent Contaminated Residue Under Pressure",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Complete a technique chain while safely venting poison, miasma, curse residue, or backlash without harming allies.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "Protection",
            "Formations",
            "Talismans"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Jade Furnace Meridian Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A furnace-meridian scripture, pill hall manual, or talisman-forge inheritance explaining safe CP cycling and residue refinement.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "Fire",
            "Qiweaving",
            "Talismans"
          ]
        },
        {
          "name": "Lineage: Pill-Fire Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher, alchemist, or formation engineer diagnoses whether the cultivator hoards power, wastes heat, or refines cleanly.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Alchemy",
            "The Hidden Eye",
            "Formations",
            "Radiance"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "FOUNDATION_03_EMPTY_BOWL_SOUL_ANCHOR",
      "name": "Empty Bowl Soul Anchor",
      "number": 6,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened or Unstable",
        "primary_path": "Spirit Awakening",
        "secondary_path_fit": "Qi Cultivation through Hunger, Life, Karma, Alchemy, Death, Dreams, or Daemonic Cultivation",
        "typical_role": "Controller / Defender / Support",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your soul remembers hunger. You can sense need in yourself and others. Hunger may become compassion, discipline, survival, temptation, or law.",
        "visible_sign": "",
        "warning": "Severity 1 strains Empty Bowl scenes.",
        "dao_principle": "Need is not shame. Need is the first proof that the soul still reaches for life."
      },
      "resource": {
        "name": "Empty Bowl Mark",
        "maximum": "1",
        "starting": "0",
        "gain": "Qualifying need-answering event or qualifying resistance succeeds.",
        "timing": "After qualifying event resolves",
        "frequency": "Once per round; maximum 1 Empty Bowl Mark; expires at the end of your next turn.",
        "expiry": "End of your next turn.",
        "same_event": "A Mark cannot be spent on the same event that generated it.",
        "anti_farming": "Trivial scenes, artificial hunger farming, exploitative feeding, forbidden consumption, false charity, or no-risk resource cycling do not generate a Mark.",
        "spends": [
          "Anchor Answers Need — Self",
          "Anchor Answers Need — Ally",
          "Share the Bowl",
          "Famine Saint Intercession",
          "Resist the Shortcut",
          "Empty Bowl Domain",
          "Domain Shelter Intercession"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Empty Bowl Reserve",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum CP increases by your proficiency bonus. If the Foundation reaches Integrated, your maximum CP increases by an additional proficiency bonus; this stacks with the base increase. CP means Stamina, Qi, or Resonance according to Path.",
            "duration": "Permanent while Foundation is stable",
            "limit": "Always active while Foundation is stable; suppressed only by printed Strain/Hidden Injury rules.",
            "counterplay": "Foundation suppression, Hollow Anchor Strain, or story-level severance can suspend the benefit; do not recalculate mid-damage packet.",
            "source_spheres": []
          },
          {
            "name": "Gather Empty Bowl Mark",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Qualifying need-answering event or qualifying resistance succeeds.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Once per round after you resolve a Fixed Empty Bowl Scope technique/effect that feeds, heals, stabilizes, protects, comforts, or answers real need, or after you succeed on a check/save against hunger, deprivation, fear of scarcity, despair created by need, exhaustion from deprivation, famine aura, devouring, or spiritual consumption, gain 1 Empty Bowl Mark. Maximum 1. Refreshes instead of stacking. You cannot spend this Mark on the same event that generated it.",
            "duration": "Until the end of your next turn",
            "limit": "Once per round; maximum 1 Empty Bowl Mark; expires at the end of your next turn.",
            "counterplay": "Trivial scenes, artificial hunger farming, exploitative feeding, forbidden consumption, false charity, or no-risk resource cycling do not generate a Mark.",
            "source_spheres": []
          },
          {
            "name": "Anchor Answers Need — Self",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You fail a Fixed Empty Bowl Scope check or saving throw.",
            "cost": "1 Empty Bowl Mark",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Failed qualifying check or save",
            "effect": "Spend 1 pre-existing Empty Bowl Mark to add your proficiency bonus to your own failed Fixed Empty Bowl Scope check or saving throw. This may turn the failure into a success. The Mark cannot be the one generated by the same event.",
            "duration": "Instant",
            "limit": "Requires a pre-existing Empty Bowl Mark; cannot stack with another Empty Bowl post-roll correction on the same roll.",
            "counterplay": "The roll must be within Fixed Empty Bowl Scope; effects that block post-roll correction or sever the soul anchor prevent use.",
            "source_spheres": []
          },
          {
            "name": "Anchor Answers Need — Ally",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "Willing creature within 30 ft fails a Fixed Empty Bowl Scope check or saving throw.",
            "cost": "1 Empty Bowl Mark",
            "range": "30 feet",
            "target": "One willing creature within 30 feet that you can perceive",
            "attack_or_save": "Failed qualifying check or save",
            "effect": "Use your Reaction and spend 1 pre-existing Empty Bowl Mark to add your proficiency bonus to the target's failed Fixed Empty Bowl Scope check or saving throw. This may turn the failure into a success. This ally-facing correction requires your Reaction.",
            "duration": "Instant",
            "limit": "One Reaction; requires a pre-existing Empty Bowl Mark; cannot stack with Anchor Answers Need — Self, Famine Saint Intercession, or Domain Shelter Intercession on the same roll.",
            "counterplay": "Out of range, unwilling target, hidden target, non-scope roll, reaction denial, or post-roll correction immunity prevents use.",
            "source_spheres": []
          },
          {
            "name": "Share the Bowl",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "",
            "cost": "1 Empty Bowl Mark",
            "range": "30 feet",
            "target": "Self or one willing creature within 30 feet",
            "attack_or_save": "",
            "effect": "Spend 1 Empty Bowl Mark. The target gains temporary HP equal to your proficiency bonus + your cultivation ability modifier. If the scene involves real hunger, deprivation, fear of scarcity, despair created by need, famine aura, devouring, or spiritual consumption, the target also gains advantage on its next check or save against that same pressure before the end of its next turn.",
            "duration": "Until the end of the target's next turn",
            "limit": "One target; requires Empty Bowl Mark; temporary HP follows normal non-stacking rules.",
            "counterplay": "No real need, artificial farming, exploitative feeding, or forbidden consumption prevents the secondary advantage rider.",
            "source_spheres": []
          },
          {
            "name": "Resist the Shortcut",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Hunger Deviation temptation or progress event.",
            "cost": "Optional: 1 Empty Bowl Mark",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Cultivation Check or Wisdom save against Hunger Deviation",
            "effect": "When Hunger Deviation tempts you, you may add your proficiency bonus to the resistance check/save once per short rest. If you also spend 1 Empty Bowl Mark and refuse the offered shortcut, reduce Hunger Deviation progress by 1 instead of gaining its offered benefit.",
            "duration": "Instant",
            "limit": "Once per short rest for the bonus; Mark spend only if a real temptation is refused.",
            "counterplay": "Accepting the shortcut, false refusal, or lack of meaningful temptation prevents progress reduction.",
            "source_spheres": []
          },
          {
            "name": "Forbidden Use Ends the Bowl",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Forbidden/incompatible Empty Bowl use.",
            "cost": "",
            "range": "Self / Domain",
            "target": "Self and active Empty Bowl effects",
            "attack_or_save": "",
            "effect": "If you use Empty Bowl Soul Anchor to justify helpless consumption, famine hoarding, false charity for power, or feeding as control, any active Empty Bowl Domain ends, Hollow Anchor Strain may increase, and Hunger Deviation may progress as determined by the GM.",
            "duration": "Instant; consequence persists by Burden/Deviation rules",
            "limit": "Triggered by meaningful violation; not a player-selected benefit.",
            "counterplay": "Avoiding the violation, accepting correction, or completing repair scenes prevents or later repairs the consequence.",
            "source_spheres": []
          }
        ],
        "integrated": [
          {
            "name": "Integrated Nourishment Rider",
            "stage": "Integrated",
            "type": "No Action / Triggered",
            "trigger": "Share the Bowl resolves at Integrated+ and answers real need.",
            "cost": "",
            "range": "Same target as Share the Bowl",
            "target": "Same target as Share the Bowl",
            "attack_or_save": "",
            "effect": "At Integrated or higher, once per short rest when Share the Bowl answers real need rather than an artificial resource loop, the target may also recover 1 CP. CP means Stamina, Qi, or Resonance according to Path. This cannot create more than 1 CP per short rest.",
            "duration": "Instant",
            "limit": "Integrated+ only; once per short rest; cannot trigger from artificial resource loops.",
            "counterplay": "No real need, anti-restoration effects, CP recovery lockouts, or GM finding of resource cycling prevents this rider.",
            "source_spheres": []
          }
        ],
        "refined": [
          {
            "name": "Famine Saint Intercession",
            "stage": "Refined",
            "type": "Reaction",
            "trigger": "Self or willing creature within 30 ft fails a scoped saving throw.",
            "cost": "1 Empty Bowl Mark",
            "range": "30 feet",
            "target": "Self or one willing creature within 30 feet",
            "attack_or_save": "Failed saving throw",
            "effect": "Refined or higher. Use your Reaction and spend 1 Empty Bowl Mark to let the target reroll a failed saving throw against fear, despair, exhaustion, magical hunger, thirst, famine aura, deprivation, devouring, or spiritual consumption. The target uses the new result. If it succeeds, it gains temporary HP equal to your proficiency bonus + your cultivation ability modifier.",
            "duration": "Instant",
            "limit": "Refined+ only; one Reaction; cannot stack with Anchor Answers Need or Domain Shelter Intercession on the same roll.",
            "counterplay": "Non-scope saves, reaction denial, unwilling target, or effects that bar rerolls prevent use.",
            "source_spheres": []
          }
        ],
        "perfected": [
          {
            "name": "Empty Bowl Domain",
            "stage": "Perfected",
            "type": "Action",
            "trigger": "",
            "cost": "1 Empty Bowl Mark + 2 CP",
            "range": "Self",
            "target": "30-foot Emanation centered on you",
            "attack_or_save": "",
            "effect": "Perfected only. Spend 1 Empty Bowl Mark and 2 CP to manifest Empty Bowl Domain for 1 minute. Allies of your choice in the Emanation have advantage on saving throws against hunger, deprivation, fear of scarcity, despair created by need, famine aura, devouring, and spiritual consumption. Non-forbidden nourishment inside the domain grants temporary HP equal to your proficiency bonus once per round to one protected creature.",
            "duration": "1 minute",
            "limit": "Perfected only; once per combat or major scene; requires 1 Empty Bowl Mark and 2 CP.",
            "counterplay": "Forbidden consumption, using need as control, suppressing the soul anchor, or leaving the domain ends or strains the effect at GM discretion.",
            "source_spheres": []
          },
          {
            "name": "Domain Shelter Intercession",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "Protected creature in active Empty Bowl Domain fails a qualifying roll.",
            "cost": "1 Empty Bowl Mark",
            "range": "30-foot Emanation",
            "target": "One protected creature in Empty Bowl Domain",
            "attack_or_save": "Failed qualifying check or save",
            "effect": "Perfected Domain exception. Once per round while Empty Bowl Domain is active, spend 1 pre-existing Empty Bowl Mark to add your proficiency bonus + your cultivation ability modifier to one protected creature's failed qualifying check or save against hunger, deprivation, fear of scarcity, despair created by need, famine aura, devouring, or spiritual consumption. This is a printed Perfected Domain rider, not a generic reaction bypass; it cannot stack with Anchor Answers Need or Famine Saint Intercession on the same roll.",
            "duration": "Instant",
            "limit": "Perfected Domain only; once per round; cannot stack with Anchor Answers Need or Famine Saint Intercession on the same roll.",
            "counterplay": "Outside the domain, non-protected targets, non-scope effects, same-event Mark generation, or anti-domain effects prevent use.",
            "source_spheres": []
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Hunger",
          "Life",
          "Karma",
          "Death",
          "Dreams",
          "Spirit Companions",
          "Alchemy",
          "Beastmastery",
          "Blood",
          "Music",
          "Protection",
          "Warleader",
          "Daemonic Cultivation -"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FAMINE_MEMORY",
            "name": "Famine Memory",
            "severity": "1-3",
            "trigger": "Cruel exploitation of hunger, hoarding vital food, wasting survival resources, forbidden consumption, harmful self-denial, or feeding as control.",
            "default_effect": "Severity 1 strains Empty Bowl scenes. Severity 2+ relevant DCs +2. Severity 3, failure by 5+ may apply Starved Soul Fissure.",
            "suppression": "Compatible method, teacher correction, appropriate sphere interface, rare medicine/rite/site, or meaningful story correction."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_STARVED_SOUL_FISSURE",
            "name": "Starved Soul Fissure",
            "severity": "1-4",
            "injured_system": "Soul Anchor, desire-body, memory-self, lower soul, dantian echo.",
            "default_effect": "Relevant DCs increase by +2 × Severity when the action stresses the injured system or sphere interfaces.",
            "recovery": "3 × Severity progress reduces Severity by 1 after compatible treatment and story correction."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_HOLLOW_ANCHOR",
            "name": "Hollow Anchor",
            "severity": "1-3",
            "suppressed_feature": "Anchor Answers Need, Integrated Nourishment Rider, Empty Bowl Domain.",
            "trigger": "Major violation of need, forbidden consumption, betrayal during famine, refusal to accept necessary aid, breaking a hunger vow.",
            "restoration": "Restoration scene, compatible training, teacher correction, treatment, apology, vow, or successful Foundation Challenge."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_HUNGER_DEVIATION",
            "name": "Hunger Deviation",
            "severity": "1-4",
            "temptation": "Need justifies consumption. Hunger proves priority. What is weaker may become nourishment.",
            "offered_benefits": "Recover CP equal to PB, gain temporary HP equal to CL, gain advantage on one relevant check, suppress deprivation for the scene, or gain insight about need.",
            "cost": "Increase Deviation progress by 1. At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Shared Meal Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "A real shared-meal, relief, nourishment, or aid scene treats Famine Memory, Hollow Anchor, or Starved Soul Fissure if paired with compatible Life, Karma, Protection, Music, Spirit Companions, or Alchemy practice.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        },
        {
          "name": "Famine Memory Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "A teacher, spirit physician, dream trial, Hunger scripture, or Karma/Life diagnosis identifies whether the anchor is compassion, discipline, survival, temptation, or law, then removes one false-method penalty on success.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Empty Bowl Foundation Challenge",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "Use this challenge to reveal, deepen, redirect, integrate, transmute, sever, or replace Empty Bowl Soul Anchor through famine memory, Hunger training, Spirit diagnosis, dream trial, near-starvation, shared-meal rite, or refusal of forbidden consumption.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Refuge Kitchen Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "Establish a lesser teaching route that helps students identify need, distribute nourishment, resist famine fear, and learn compatible Hunger/Life/Karma/Protection routes without copying the full Foundation.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        },
        {
          "name": "Famine Saint Bowl Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "Prepare an initiatory rite for a student or sect cell that converts hunger memory into restraint, aid, and lawful relief methods rather than devouring practice.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        },
        {
          "name": "Hunger-Restraining Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Scene cost, teacher/material requirements, or GM-defined offerings",
          "range": "Self, teacher, patient, site, or community",
          "target": "Foundation, soul anchor, patient, student, or inheritance recipient",
          "attack_or_save": "Cultivation Check or relevant treatment check",
          "effect": "Record diagnostics, vows, and correction practices that let future cultivators work with Hunger-aspected routes without treating need as permission to consume the helpless.",
          "duration": "Scene / project",
          "limit": "Requires appropriate scene access and GM approval.",
          "counterplay": "Wrong method, exploitation, forbidden consumption, lack of teacher/materials, or refusing correction can block progress.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "moon_mirror_still_water_v0_2B",
      "name": "Moon-Mirror Still-Water",
      "number": 7,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Spirit Awakening",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Body Refining through still-water breath or defensive manuals"
        ],
        "typical_role": "Defender / Support",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Reactive defense and ally-protection Foundation that rewards calm timing, perception, and choosing when to answer danger.",
        "visible_sign": "",
        "warning": "If you damage a creature before that creature has taken a turn in the fight, you cannot generate Mirror Stillness until the start of your next turn.",
        "dao_principle": "Reflect danger without becoming passive; see truth without drowning in images."
      },
      "resource": {
        "name": "Mirror Stillness",
        "maximum": "1",
        "starting": "0",
        "gain": "After a hostile attack against you or an ally within 30 feet misses, after you or an ally within 30 feet succeeds on a saving throw against a hostile effect you can perceive, or after you correctly identify the true hostile source behind a decoy, illusion, dream, or curse under real pressure.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Stop making visible attacks, use area pressure, split threats, or force the cultivator to act first.",
        "spends": [
          "Still-Water Reflection",
          "Reflected Opening",
          "Still Lake Breath",
          "Refined: Truth Beneath Reflection"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Moon-Mirror Soul Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Water, Yin, Illusion, Dreams, Fate, Protection, The Hidden Eye, Qiweaving, Karma, and Spirit Companions methods that reflect danger, discern hostile intent, protect an ally, stabilize a mind, or answer a curse may count as Foundation-aligned. You have Advantage on Wisdom checks and saving throws against hostile illusion, dream pressure, false images, charm, fear, curse-bait, and decoy-source effects. This passive requires no per-round tracking.",
            "duration": "",
            "limit": "Passive only; grants no automatic reaction, no invisibility, and no sphere access.",
            "counterplay": "Use unseen sources, area pressure, false timing, overwhelming direct force, or make passivity costly.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Moon-Mirror Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports reactive defense, ally protection, refusal of baited first strikes, perception of true hostile sources, and calm response to illusions, dreams, curses, charms, fear, and misdirection. It does not reward doing nothing forever, hiding while allies suffer, or striking first and calling it patience.",
            "duration": "",
            "limit": "Scope only; no free reaction and no universal truth-sight.",
            "counterplay": "Force hard choices, attack multiple allies, conceal the true source, or punish delay.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Generate Mirror Stillness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a hostile attack against you or an ally within 30 feet misses, after you or an ally within 30 feet succeeds on a saving throw against a hostile effect you can perceive, or after you correctly identify the true hostile source behind a decoy, illusion, dream, or curse under real pressure.",
            "cost": "",
            "range": "30 feet",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain 1 Mirror Stillness after the qualifying trigger resolves. Maximum 1. Once per round. It expires at the end of your next turn. You cannot spend Mirror Stillness on the same event that generated it. You cannot generate it from friendly, staged, training, harmless, repeated non-threat, or purely passive waiting events.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; no same-event spending.",
            "counterplay": "Stop making visible attacks, use area pressure, split threats, or force the cultivator to act first.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Still-Water Reflection",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet is hit by an attack or fails a saving throw against a hostile effect you can perceive.",
            "cost": "1 Mirror Stillness",
            "range": "30 feet",
            "target": "Self or one ally",
            "attack_or_save": "",
            "effect": "Spend 1 Mirror Stillness as a Reaction. Add your Proficiency Bonus + your Path key ability modifier to the protected creature’s AC against the triggering attack or to the failed saving throw. If this changes the outcome, the attack misses or the saving throw succeeds. If it does not change the outcome and the trigger deals damage, reduce that damage by your Proficiency Bonus. This does not require an additional resource spend and does not permit same-event spending.",
            "duration": "",
            "limit": "Requires Reaction; one target; cannot spend on the same event that generated Mirror Stillness.",
            "counterplay": "Bait the Reaction, use multiple attacks, attack outside range, or use effects the cultivator cannot perceive.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Reflected Opening",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature with a Foundation-aligned attack or technique.",
            "cost": "1 Mirror Stillness",
            "range": "Varies by triggering attack",
            "target": "One hostile creature hit by the triggering attack",
            "attack_or_save": "",
            "effect": "Spend 1 Mirror Stillness after the hit resolves. Add your Proficiency Bonus + your Path key ability modifier as psychic, cold, or force damage. Until the start of your next turn, the target has Disadvantage on the next check it makes to hide its true position, disguise its hostile intent, or maintain an illusion or decoy against you.",
            "duration": "",
            "limit": "No extra action; must follow a real Foundation-aligned hit; no same-event spending.",
            "counterplay": "Avoid giving the cultivator Stillness, use non-illusion defenses, or force them to spend defensively.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Still Lake Breath",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Mirror Stillness.",
            "cost": "1 Mirror Stillness",
            "range": "Self or one ally within 30 feet",
            "target": "Self or one ally",
            "attack_or_save": "",
            "effect": "Spend 1 Mirror Stillness as a Bonus Action. The target gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Before the start of your next turn, the target has Advantage on the next saving throw against fear, charm, illusion, dream, curse, or forced spiritual movement.",
            "duration": "",
            "limit": "One target; temporary HP does not stack with itself; no same-event spending.",
            "counterplay": "Pressure multiple creatures, use mundane damage, or wait out the short window.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Clear Moon Surface",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Applies while the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Moon-Mirror Soul Vessel and Still-Water Reflection. Your maximum Hit Point bonus from this Foundation becomes twice your Proficiency Bonus. Still-Water Reflection may target an ally within 60 feet if you can see the ally and the triggering hostile pressure. This rider costs no extra Reaction, no extra resource, and does not permit same-event spending.",
            "duration": "",
            "limit": "Rider only; no extra Reaction/resource; no same-event spend permission.",
            "counterplay": "Break line of sight, attack outside range, or create multiple simultaneous threats.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          },
          {
            "name": "Refined: Truth Beneath Reflection",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Mirror Stillness on Still-Water Reflection or Reflected Opening.",
            "cost": "",
            "range": "Varies by modified spend",
            "target": "Target of modified spend",
            "attack_or_save": "",
            "effect": "This modifies Still-Water Reflection or Reflected Opening. When you spend Mirror Stillness on either action, add your Proficiency Bonus to one numeric value produced by that spend. This rider does not require an additional action, Reaction, or resource spend, and does not permit same-event spending.",
            "duration": "",
            "limit": "Rider only; affects one numeric value; no extra resource/reaction.",
            "counterplay": "Bait the spend or use pressures outside the Foundation scope.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Moon-Mirror Lake",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while conscious and the Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "30-foot emanation",
            "attack_or_save": "",
            "effect": "Activate Moon-Mirror Lake for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. Chosen allies in the 30-foot emanation have Advantage on saving throws against fear, charm, illusion, dream, curse, and forced spiritual movement. Once per round, when a hostile attack misses a chosen ally in the lake or a chosen ally succeeds on a listed saving throw, you may generate Mirror Stillness after the trigger resolves, obeying the normal maximum, expiry, and same-event lockout. Mirror Stillness maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest; 1 minute; resource cap remains 1; no same-event spending.",
            "counterplay": "Leave the emanation, attack with mundane pressure, force many simultaneous threats, or break the cultivator’s calm.",
            "source_spheres": [
              "Water",
              "Yin",
              "Illusion",
              "Dreams",
              "Fate",
              "Protection",
              "The Hidden Eye",
              "Qiweaving",
              "Karma",
              "Spirit Companions"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Water",
          "Yin",
          "Illusion",
          "Dreams",
          "Fate",
          "Protection",
          "The Hidden Eye",
          "Qiweaving",
          "Karma",
          "Spirit Companions"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "burden_the_mirror_waits",
            "display_name": "Burden — The Mirror Waits",
            "text": "If you damage a creature before that creature has taken a turn in the fight, you cannot generate Mirror Stillness until the start of your next turn. The burden does not punish preventing immediate harm, but it rejects reckless first strikes."
          }
        ],
        "hidden_injuries": [
          {
            "id": "hidden_injury_drowned_moon",
            "display_name": "Drowned-Moon Hidden Injury",
            "text": "Stillness becomes inertia; the cultivator hesitates when action is required."
          }
        ],
        "strains": [
          {
            "id": "strain_cracked_mirror_soul",
            "display_name": "Cracked Mirror Soul Strain",
            "text": "Too many reflections split attention and make false possibilities feel immediate."
          }
        ],
        "deviations": [
          {
            "id": "deviation_false_reflection",
            "display_name": "False Reflection Deviation",
            "text": "Possible futures and imagined threats feel real."
          },
          {
            "id": "deviation_perfect_passivity",
            "display_name": "Perfect Passivity Deviation",
            "text": "The cultivator refuses action until after harm occurs."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Recenter the Drowned Moon",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Meditate beside still water, name one danger that required action, and repair inertia without breaking calm.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        },
        {
          "name": "Repair: Polish the Cracked Mirror",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Use dream, illusion, or curse diagnosis to separate true danger from reflected fear.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        },
        {
          "name": "Repair: Act After Stillness",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Complete a scene where the cultivator waits, identifies the real threat, and then acts decisively.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Refuse the Baited First Strike",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Face a hostile provocation without striking first, then protect someone when the real attack begins.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        },
        {
          "name": "Challenge: Find the True Moon",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Identify the real enemy, curse source, or dream-anchor among decoys.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        },
        {
          "name": "Challenge: Break Perfect Passivity",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Choose action before stillness becomes abandonment.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Moon-Mirror Lake Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A still-water mirror scripture teaches the cultivator how to reflect danger without drowning in possible futures.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        },
        {
          "name": "Lineage: Dream-Breaking Witness Teacher",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher diagnoses whether the cultivator is calm, passive, or trapped by false reflections.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Water",
            "Yin",
            "Illusion",
            "Dreams",
            "Fate",
            "Protection",
            "The Hidden Eye",
            "Qiweaving",
            "Karma",
            "Spirit Companions"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "heaven_tyrant_body_v0_2D",
      "name": "Heaven Tyrant Body",
      "number": 8,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Spirit Awakening"
        ],
        "typical_role": "Striker / Defender / Controller",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body is built to meet force directly. You become stronger when you strike in close combat, endure hostile contact, or refuse physical control. Advancing this Foundation is difficult because the tyrant body must prove dominance without collapsing into domination-hunger.",
        "visible_sign": "",
        "warning": "The Heaven Tyrant Body advances only through hard, consequential confrontation.",
        "dao_principle": "The tyrant body proves itself by facing pressure directly; conquest without restraint becomes only another chain."
      },
      "resource": {
        "name": "Tyrant Form Pulse",
        "maximum": "1",
        "starting": "0",
        "gain": "After one of these events resolves while you are conscious: you hit a hostile creature within your reach with a close-range body-bound or martial attack; you take hostile damage from a creature within 10 feet; or you succeed on a Strength or Constitution save/check/contest against hostile forced movement, Prone, Grappled, Restrained, or body-suppression pressure.",
        "timing": "after the trigger resolves",
        "frequency": "once per round",
        "expiry": "end of your next turn",
        "same_event": "Cannot be spent on the same event that generated it. Friendly, voluntary, staged, harmless, purely social, or no-risk events do not generate Tyrant Form Pulse.",
        "anti_farming": "Deny close contact, use range, force nonphysical saves, or bait the cultivator into spending the pulse before creating another trigger.",
        "spends": [
          "Tyrant Form Crush",
          "Imperial Shoulder-Gate",
          "Tyrant Blood Surge",
          "Refined: Tyrant Momentum"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Tyrant-Blood Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by twice your Proficiency Bonus. Your close-range body-bound and martial attacks count as Foundation-aligned for overcoming Resistance and Immunity to nonmagical bludgeoning, piercing, and slashing damage. In real hostile opposition, you have Advantage on Strength or Constitution checks and saving throws made to shove, grapple, escape Grappled, resist forced movement, resist being knocked Prone, resist becoming Grappled or Restrained, or resist body-suppression pressure. This does not apply to harmless training, staged contests, purely ranged attacks, social intimidation without a technique, or self-only flexing.",
            "duration": "",
            "limit": "Applies only to real hostile close/body opposition. Does not grant sphere access, automatic grapples, free extra attacks, universal damage immunity, or social command authority.",
            "counterplay": "Keep distance, use nonphysical saves, deny close engagement, use terrain, or force the cultivator to protect allies instead of dominating a contest.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Fixed Scope: Tyrant-Body Dominion",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Rules reference for what this Foundation does and does not grant.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation represents a legendary tyrant-body architecture. It supports direct close-range confrontation, physical contests, body pressure, refusing forced movement, and turning hostile contact into counterforce. It does not grant automatic domination, political rank, free fear effects, free grapples, universal spell resistance, or access to all martial spheres. Its power is high, but its table loop remains simple: close pressure, resist control, generate one pulse, spend one pulse.",
            "duration": "",
            "limit": "Rules reference only. This row never generates or spends Tyrant Form Pulse.",
            "counterplay": "Use distance, nonphysical control, illusions, terrain denial, or social/moral tests. The Foundation is strongest in direct physical confrontation.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Generate Tyrant Form Pulse",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After one of these events resolves while you are conscious: you hit a hostile creature within your reach with a close-range body-bound or martial attack; you take hostile damage from a creature within 10 feet; or you succeed on a Strength or Constitution save/check/contest against hostile forced movement, Prone, Grappled, Restrained, or body-suppression pressure.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain 1 Tyrant Form Pulse after the qualifying event resolves. Maximum 1. This can occur only once per round. Tyrant Form Pulse expires at the end of your next turn. A Tyrant Form Pulse generated by an event cannot be spent on that same event. Friendly, voluntary, training, harmless, staged, purely social, or repeated no-risk events do not generate the resource.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; same-event spending forbidden.",
            "counterplay": "Deny close contact, use range, force nonphysical saves, or bait the cultivator into spending the pulse before creating another trigger.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Tyrant Form Crush",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature within your reach with a close-range body-bound, unarmed, weapon-body, or martial attack.",
            "cost": "1 Tyrant Form Pulse",
            "range": "Self",
            "target": "One hostile creature you hit within reach",
            "attack_or_save": "",
            "effect": "Spend 1 Tyrant Form Pulse after the qualifying hit resolves. Add damage equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, the target cannot push, pull, knock Prone, Grapple, or Restrain you unless it uses a higher-Realm, Secret, artifact, or domain-scale effect. This modifies the triggering hit. It does not require an additional action and does not permit same-event spending.",
            "duration": "",
            "limit": "Requires a qualifying close hit and 1 Tyrant Form Pulse. Does not add an extra attack.",
            "counterplay": "Stay out of reach, impose disadvantage, use non-body effects, or force the cultivator to spend the pulse defensively.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Imperial Shoulder-Gate",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When hostile damage from a creature within 10 feet affects you, or when you fail an eligible Strength or Constitution save/check/contest against hostile forced movement, Prone, Grappled, Restrained, or body-suppression pressure.",
            "cost": "1 Tyrant Form Pulse",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Tyrant Form Pulse as a Reaction. If the trigger is hostile damage from a creature within 10 feet, reduce that damage by 2 times your Proficiency Bonus + your Path key ability modifier. If the trigger is an eligible failed Strength or Constitution save/check/contest against forced movement, Prone, Grappled, Restrained, or body-suppression pressure, add 2 times your Proficiency Bonus + your Path key ability modifier to the roll and re-evaluate the result. This modifies the triggering event. It does not permit same-event spending.",
            "duration": "",
            "limit": "Reaction; requires 1 Tyrant Form Pulse; self only.",
            "counterplay": "Attack from beyond 10 feet, use nonphysical saves, use effects with no STR/CON resistance roll, or bait the Reaction.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Tyrant Blood Surge",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Tyrant Form Pulse.",
            "cost": "1 Tyrant Form Pulse",
            "range": "30 feet",
            "target": "One hostile creature",
            "attack_or_save": "",
            "effect": "Spend 1 Tyrant Form Pulse as a Bonus Action. You gain temporary Hit Points equal to 2 times your Proficiency Bonus + your Path key ability modifier. Before the end of this turn, your next qualifying close-range body-bound attack, shove, grapple, escape, or Strength-based physical contest has Advantage. This does not force any creature to fight you, does not mark a target, and does not generate Tyrant Form Pulse by itself.",
            "duration": "",
            "limit": "Bonus Action; one Advantage before end of current turn; no compulsion or mark.",
            "counterplay": "Deny close engagement, impose disadvantage, force non-Strength saves, or wait out the turn.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Nine-Form Blood",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Always active while this Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When Refined, the Hit Point bonus from Tyrant-Blood Frame becomes three times your Proficiency Bonus. In addition, Tyrant-Blood Frame also applies when an eligible hostile effect attempts to bind, pin, lock, root, weigh down, or suppress your body through qi, blood, force, gravity, earth, metal, spirit pressure, or a comparable close/body-control method. This modifies Tyrant-Blood Frame. It does not create a second resource, does not add a per-round passive counter, and does not permit same-event spending.",
            "duration": "",
            "limit": "Refined stage only. Resource maximum remains 1 and same-event lockout remains false. This does not create nine active modes.",
            "counterplay": "Deny repeated close/body triggers, kite, or force the cultivator to spend Pulse before pressure continues.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          },
          {
            "name": "Refined: Tyrant Momentum",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Tyrant Form Pulse.",
            "cost": "",
            "range": "Self",
            "target": "Triggering spend target",
            "attack_or_save": "",
            "effect": "This modifies Tyrant Form Crush, Imperial Shoulder-Gate, or Tyrant Blood Surge. When you spend Tyrant Form Pulse, increase one numeric value from that spend by your Proficiency Bonus. This rider does not require an additional action, does not require an additional Tyrant Form Pulse, does not create a second Reaction, and does not permit same-event spending.",
            "duration": "",
            "limit": "Refined stage only; applies to one numeric value of the qualifying spend.",
            "counterplay": "Force the cultivator to spend Pulse on lower-impact moments or deny close/body triggers.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Heaven Tyrant Blood Declaration",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while this Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "As a Bonus Action once per long rest, declare the Heaven Tyrant Blood for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. For the duration, your close-range body-bound and martial hits deal additional damage equal to your Proficiency Bonus, and you have Advantage on qualifying Strength or Constitution physical contests, forced-movement resistance, Prone resistance, Grappled/Restrained resistance, and body-suppression resistance. Tyrant Form Pulse maximum remains 1 and its timing rules remain unchanged.",
            "duration": "",
            "limit": "Perfected stage only; once per long rest; lasts 1 minute; resource cap remains 1.",
            "counterplay": "Wait out the duration, kite, use higher-authority effects, attack allies, use non-body saves, or deny close engagement.",
            "source_spheres": [
              "Athletics",
              "Berserker",
              "Brute",
              "Wrestling",
              "Iron Fist",
              "Pressure Points",
              "Force",
              "Blood",
              "Warleader",
              "Shield"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Athletics",
          "Berserker",
          "Brute",
          "Wrestling",
          "Iron Fist",
          "Pressure Points",
          "Force",
          "Blood",
          "Warleader",
          "Shield"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_HEAVEN_TYRANT_BODY_ADVANCEMENT_DOMINION_COST",
            "name": "Burden — Dominion Must Be Proved",
            "display_name": "Burden — Dominion Must Be Proved",
            "effect_text": "The Heaven Tyrant Body advances only through hard, consequential confrontation. Refined and Perfected advancement requires victories, losses, restraint, body-tempering materials, and proof against opponents who can actually contest the cultivator. Harmless domination, bullying weaklings, or staged victories provide no advancement credit and may create deviation pressure.",
            "summary": "Legendary advancement burden: high top end, but real refinement requires worthy pressure and restraint.",
            "foundation_id": "heaven_tyrant_body_v0_2D"
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_FOUNDATION_HEAVEN_TYRANT_BODY_OVERBEARING_BLOOD_RECOIL",
            "name": "Overbearing Blood Recoil",
            "display_name": "Overbearing Blood Recoil",
            "effect_text": "Failed advancement or repeated overuse can cause the tyrant blood to overpressurize the body. Possible symptoms include cracked meridians, rage-fever, heavy limbs after contests, or backlash when the cultivator tries to accept help.",
            "summary": "Hidden injury from forcing the tyrant body beyond its structure.",
            "foundation_id": "heaven_tyrant_body_v0_2D"
          }
        ],
        "strains": [
          {
            "id": "STRAIN_FOUNDATION_HEAVEN_TYRANT_BODY_OVERPRESSURE",
            "name": "Tyrant Overpressure",
            "display_name": "Tyrant Overpressure",
            "effect_text": "The body wants direct confrontation even when tactics require patience. Under strain, the cultivator may suffer penalties to subtle movement, stealth, diplomacy, or retreat-based breakthrough proof until the pressure is cooled.",
            "summary": "Strain from turning every problem into a body contest.",
            "foundation_id": "heaven_tyrant_body_v0_2D"
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_FOUNDATION_HEAVEN_TYRANT_BODY_DOMINATION_HUNGER",
            "name": "Domination Hunger",
            "display_name": "Domination Hunger",
            "effect_text": "The cultivator begins to need submission as proof of worth. Allies become witnesses, enemies become props, and restraint feels like weakness.",
            "summary": "Deviation from confusing strength with the right to dominate.",
            "foundation_id": "heaven_tyrant_body_v0_2D"
          },
          {
            "id": "DEVIATION_FOUNDATION_HEAVEN_TYRANT_BODY_RIVAL_HATRED",
            "name": "Rival-Hatred Deviation",
            "display_name": "Rival-Hatred Deviation",
            "effect_text": "The cultivator fixates on rivals and loses the ability to judge whether the contest still matters. This is especially dangerous when facing other legendary body Foundations.",
            "summary": "Deviation from making rivalry the whole Dao.",
            "foundation_id": "heaven_tyrant_body_v0_2D"
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair Practice: Rival-Blood Cooling",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "After overstrain, failed breakthrough, domination deviation, or blood-overpressure symptoms.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator spends downtime cooling tyrant blood through breath, bitter medicine, restraint drills, and nonlethal contests. On success, suppress one minor symptom of Overbearing Blood Recoil, Nine-Form Overpressure, Domination Hunger, or Rival-Hatred Deviation until the next major breakthrough or serious overstrain.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        },
        {
          "name": "Repair Practice: Open-Hand Victory",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "After the cultivator wins a contest without humiliating, maiming, or dominating the defeated target.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator records a victory that proves restraint. This can count as repair evidence for Domination Hunger or Rival-Hatred Deviation and may grant preparation credit for the next refinement challenge.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        },
        {
          "name": "Repair Practice: Nine-Form Breath Rebalancing",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a full cultivation session with a body-refining teacher, battle physician, or suitable manual.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator rebalances bone, blood, tendon, breath, and battle intent so the tyrant body does not crush its own meridians. On success, reduce the severity of one minor hidden injury symptom tied to tyrant overpressure.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge Route: Worthy Rival Trial",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used when attempting to Refine or Perfect the Foundation through combat proof.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator must face a genuinely dangerous rival, monster, guardian, or battlefield pressure that can contest the body directly. Success requires victory or survival with changed method, not merely crushing a weak opponent.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        },
        {
          "name": "Challenge Route: No Throne Without Restraint",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used when the Foundation risks domination or tyrant-pride deviation.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator must deliberately stop short of needless domination when victory is available. Success proves that the body commands force rather than being commanded by force.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        },
        {
          "name": "Challenge Route: Break the False Tyrant",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used when a teacher, enemy, illusion, or heart-demon claims that conquest alone is Dao.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The cultivator must defeat or reject a false tyrant lesson by protecting an objective, sparing a defeated foe, or winning without accepting the heart-demon bargain.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Cangtian Tyrant Body Record",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "When studying a tyrant-body record, rival-body scripture, bloodline tablet, or ancient battle-form inheritance.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "A valid lineage record can teach safe advancement routes, identify tyrant-blood overpressure, and unlock Refined or Perfected proof requirements. It does not grant GM Screen combat actions by itself.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        },
        {
          "name": "Lineage: Tyrant-Blood Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "When a qualified body-refining teacher, battle physician, or rival-body elder diagnoses the Foundation.",
          "cost": "",
          "range": "Self",
          "target": "Self or named Foundation teacher/scene",
          "attack_or_save": "",
          "effect": "The teacher can identify whether current symptoms come from ordinary strain, hidden injury, domination deviation, rival-hatred, or unsafe breakthrough pressure. This is diagnostic support, not a combat action.",
          "duration": "",
          "limit": "Does not enter GM Screen combat rows unless separately rewritten as a full combat action.",
          "counterplay": "Interrupt the downtime, deny materials, expose false proof, or force the cultivator into premature confrontation.",
          "source_spheres": [
            "Athletics",
            "Berserker",
            "Brute",
            "Wrestling",
            "Iron Fist",
            "Pressure Points",
            "Force",
            "Blood",
            "Warleader",
            "Shield"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "dragon_wind_vessel_v0_2E",
      "name": "Dragon-Wind Vessel",
      "number": 9,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Latent",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Body Refining",
          "Spirit Awakening"
        ],
        "typical_role": "Mobility / Striker / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body has begun to take the shape of motion. Breath moves more cleanly through your channels, wind qi answers your steps, and your marrow carries a faint dragon pressure that wants to become momentum instead of stillness.",
        "visible_sign": "Hair, sleeves, dust, breath, and loose objects stir when your emotions rise. When you move with intent, your aura coils behind you like a half-seen dragon shape in wind.",
        "warning": "Closed-space suppression, sealed meridians, stagnant methods, heavy grounding, anti-flight formations, bloodline suppression, and pride-driven breakthroughs can scour the Vessel.",
        "dao_principle": "The sky does not carry the dragon. The dragon teaches the sky where to move."
      },
      "resource": {
        "name": "Dragon-Wind Momentum",
        "maximum": "1",
        "starting": "0",
        "gain": "After you move at least 20 ft with movement you control before hitting a creature with an attack or technique.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round. Requires at least 20 ft of controlled movement before the hit. The generated Momentum is available only after the hit resolves and cannot be spent on that hit.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny controlled movement, impose restraint or difficult terrain, force enclosed fighting, block reach or line, punish movement before the hit, or prevent the qualifying hit.",
        "spends": [
          "Momentum Drive",
          "Momentum Guard",
          "Momentum Step",
          "Sky-Marrow Conversion",
          "Sovereign Momentum"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Wind-Opened Body",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Foundation active.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Common Expression: walking speed increases by 5 ft. Awakened: the increase becomes 10 ft total. Movement, landing, pressure, wind, and dragon-blood correction count as matching Foundation scenes. This does not grant Athletics proficiency, flight, or a sphere.",
            "duration": "Passive while the Foundation is active.",
            "limit": "Always active while Dragon-Wind Vessel is active; improves at Awakened.",
            "counterplay": "Suppress speed/body benefit with explicit Foundation suppression, forced stillness, severing, anti-movement formations, or a higher-priority effect.",
            "source_spheres": [
              "Air",
              "Weather",
              "Athletics"
            ]
          },
          {
            "name": "Generate Dragon-Wind Momentum",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you move at least 20 ft with movement you control before hitting a creature with an attack or technique.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering hit resolves, gain 1 Dragon-Wind Momentum, max 1. It fades at the end of your next turn. If already held, refresh the expiration instead of stacking. It cannot be spent on the same hit that generated it.",
            "duration": "Until end of your next turn.",
            "limit": "Once per round. Requires at least 20 ft of controlled movement before the hit. The generated Momentum is available only after the hit resolves and cannot be spent on that hit.",
            "counterplay": "Deny controlled movement, impose restraint or difficult terrain, force enclosed fighting, block reach or line, punish movement before the hit, or prevent the qualifying hit.",
            "source_spheres": [
              "Air",
              "Weather",
              "Athletics",
              "Sword",
              "Flowing River"
            ]
          },
          {
            "name": "Momentum Drive",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit with an attack or technique while holding pre-existing Dragon-Wind Momentum.",
            "cost": "Spend 1 Dragon-Wind Momentum",
            "range": "Self / triggering hit",
            "target": "One hit you just made after Momentum was already available",
            "attack_or_save": "",
            "effect": "Spend 1 pre-existing Dragon-Wind Momentum after you hit with an attack or technique to add PB damage to the hit. The damage type follows the attack/technique; if a Foundation expression is needed, use thunder, lightning, force, or slashing. Integrated and Refined riders may improve this damage.",
            "duration": "Instant.",
            "limit": "Requires 1 pre-existing Dragon-Wind Momentum. Cannot use on the same hit that generated the Momentum. One Momentum spend selects one conversion unless Perfected Sovereign Momentum applies.",
            "counterplay": "Force the cultivator to spend Momentum defensively, deny future hits, impose disadvantage/cover, disrupt movement rhythm, or bait Momentum before the desired hit.",
            "source_spheres": [
              "Air",
              "Weather",
              "Sword",
              "Athletics"
            ]
          },
          {
            "name": "Momentum Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take damage while holding pre-existing Dragon-Wind Momentum.",
            "cost": "Reaction + spend 1 Dragon-Wind Momentum",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you take damage while holding pre-existing Dragon-Wind Momentum, use your Reaction and spend 1 Momentum to reduce the triggering damage by PB + your cultivation ability modifier. Integrated and Refined riders may improve this guard without requiring a second Reaction.",
            "duration": "Instant.",
            "limit": "Requires Reaction and 1 pre-existing Dragon-Wind Momentum. Cannot guard the same event that generated Momentum unless a future feature explicitly says otherwise.",
            "counterplay": "Deal damage before the cultivator gains Momentum, force Reaction pressure, bait Momentum on lower damage, restrain movement, or use effects that do not deal reducible damage.",
            "source_spheres": [
              "Air",
              "Weather",
              "Guardian",
              "Protection"
            ]
          },
          {
            "name": "Momentum Step",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "During your turn, before or after movement you control, while holding pre-existing Dragon-Wind Momentum.",
            "cost": "Spend 1 Dragon-Wind Momentum",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "During your turn, before or after movement you control, spend 1 Dragon-Wind Momentum to increase one movement speed you currently possess by 10 ft until the end of the current turn. This does not grant a new speed or flight by itself.",
            "duration": "Until end of current turn.",
            "limit": "Requires 1 pre-existing Dragon-Wind Momentum. Does not grant a movement mode you do not possess.",
            "counterplay": "Restrain, prone, slow, wall, difficult terrain, enclosed spaces, forced stillness, or deny legal destination squares.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Flowing River"
            ]
          }
        ],
        "integrated": [
          {
            "name": "Sky-Marrow Conversion",
            "stage": "Integrated",
            "type": "No Action / Triggered",
            "trigger": "You spend Dragon-Wind Momentum and meet the relevant conversion condition.",
            "cost": "No additional action",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Integrated passive rider. Dragon-Wind Momentum remains max 1. When you spend Momentum and meet the relevant condition, the conversion improves as follows: Momentum Drive adds PB + 1 damage instead of PB after qualifying movement; Momentum Guard reduces PB + cultivation ability modifier + 1 damage in a qualifying movement exchange; Momentum Step ignores nonmagical difficult terrain during the extra 10 ft. This is not a separate action or extra resource spend.",
            "duration": "While Integrated or higher.",
            "limit": "Requires Integrated or higher. Modifies a legal Momentum conversion; does not create another Momentum spend.",
            "counterplay": "Suppress the Foundation, deny the qualifying movement relation, use magical terrain for Step, or prevent the underlying conversion from being legal.",
            "source_spheres": [
              "Air",
              "Weather",
              "Athletics",
              "Qiweaving"
            ]
          }
        ],
        "refined": [
          {
            "name": "Storm-Marrow Guard",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Momentum Guard resolves while this refinement is selected.",
            "cost": "No additional action; modifies Momentum Guard",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined passive rider. When you use Momentum Guard, this adds no second Reaction and no additional Momentum cost. After the triggering damage resolves, move 5 ft to legal space without provoking opportunity attacks from the triggering creature; move 10 ft instead if the damage was thunder, lightning, falling, collision, forced-movement, pressure, wind, storm, breath weapon, or anti-flight damage.",
            "duration": "Instant movement after Momentum Guard resolves.",
            "limit": "Requires Refined or higher and Storm-Marrow Guard selected. Movement must be legal and cannot pass through illegal barriers.",
            "counterplay": "Remove legal spaces, restrain, grapple, wall, apply forced stillness, or use effects that prevent movement after damage.",
            "source_spheres": [
              "Air",
              "Weather",
              "Guardian",
              "Athletics"
            ]
          },
          {
            "name": "Dragon-Marrow Drive",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Momentum Drive resolves after you moved at least 20 ft this turn and this refinement is selected.",
            "cost": "No additional action; modifies Momentum Drive",
            "range": "Self / target of Momentum Drive",
            "target": "Target of the triggering hit",
            "attack_or_save": "Target chooses Strength or Dexterity saving throw against your Cultivation Save DC",
            "effect": "Refined passive rider. When you use Momentum Drive after moving at least 20 ft this turn, the added damage becomes 1d4 + PB. Until end of the current turn, the target cannot make opportunity attacks against you unless it succeeds on a Strength or Dexterity saving throw against your Cultivation Save DC; target chooses the save.",
            "duration": "Until end of current turn for opportunity-attack restriction.",
            "limit": "Requires Refined or higher and Dragon-Marrow Drive selected. The opportunity-attack restriction only affects the hit target and allows the listed save.",
            "counterplay": "Pass the save, deny the moving hit, force the cultivator to spend Momentum elsewhere, or use non-opportunity reactions and reach/zone control.",
            "source_spheres": [
              "Air",
              "Weather",
              "Sword",
              "Beastmastery",
              "Blood"
            ]
          },
          {
            "name": "Wind-Body Step",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Momentum Step resolves while this refinement is selected.",
            "cost": "No additional action; modifies Momentum Step",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined passive rider. When you use Momentum Step, the speed increase becomes 15 ft instead of 10 ft. If that movement brings you adjacent to a creature or out of a threatened space, gain advantage on the next Athletics or Acrobatics check before end of turn to keep footing, pass through pressure, avoid falling, resist forced movement, or maintain legal movement.",
            "duration": "Until end of current turn.",
            "limit": "Requires Refined or higher and Wind-Body Step selected. Advantage applies only to the listed movement/positioning checks before end of turn.",
            "counterplay": "Use non-check effects, remove legal movement, restrain, grapple, wall, or force saves instead of checks.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Flowing River"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Sovereign Momentum",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "You spend Dragon-Wind Momentum after moving at least 20 ft since the start of your current turn or since the end of your last turn.",
            "cost": "No additional action; modifies the same Momentum spend",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Perfected passive rider. Once per round, when you spend Dragon-Wind Momentum after moving at least 20 ft since the start of your current turn or since the end of your last turn, choose two different legal Momentum Conversion options instead of one. This does not cost a second Momentum.",
            "duration": "During the triggering Momentum spend.",
            "limit": "Once per round. Requires Perfected or higher. No second Momentum cost. Each chosen conversion must have a legal trigger.",
            "counterplay": "Deny movement before the spend, force a single legal trigger, bait the Momentum spend before a second option is legal, suppress the Foundation, or exploit Pride of the Sky risks.",
            "source_spheres": [
              "Air",
              "Weather",
              "Athletics",
              "Qiweaving"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Air",
          "Weather",
          "Athletics",
          "Sword",
          "Flowing River",
          "Guardian",
          "Protection",
          "Qiweaving",
          "Beastmastery",
          "Blood"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "state_id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_SKY_MARRED_VESSEL",
            "id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_SKY_MARRED_VESSEL",
            "name": "Sky-Marred Vessel",
            "state_type": "burden",
            "classification": "state_tracker",
            "severity": "1-3",
            "trigger": "Incompatible methods, anti-movement suppression, anti-flight suppression, bloodline pressure, forced stillness, or crisis scenes.",
            "effect": "Severity 1: relevant DCs +2 when the scene stresses motion, breath, marrow, or dragon-wind identity. Severity 2: Dragon-Wind Momentum cannot be generated from suppressed movement scenes. Severity 3: Momentum generation is suppressed until rest/correction unless the DM permits a breakthrough scene.",
            "suppresses_action_ids": [
              "ACT_FOUNDATION_DRAGON_WIND_VESSEL_GENERATE_MOMENTUM"
            ],
            "recovery": "Foundation Mending Practice, compatible Method, teacher correction, repair interface, or story correction.",
            "export_targets": [
              "runtime_record.states[]",
              "Foundation_Detail_Ledger.json.states[]",
              "Character_Import_Surface.json.states[]"
            ],
            "tags": [
              "foundation",
              "burden",
              "dragon_wind_vessel",
              "runtime_export_v0_2E"
            ]
          }
        ],
        "hidden_injuries": [
          {
            "state_id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_WIND_MARROW_SCOURING",
            "id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_WIND_MARROW_SCOURING",
            "name": "Wind-Marrow Scouring",
            "state_type": "hidden_injury",
            "classification": "state_tracker",
            "severity": "1-4",
            "trigger": "Failure by 5+ under Sky-Marred Vessel stress or severe movement/breath/bloodline damage.",
            "effect": "Relevant DCs increase by +2 × Severity when action stresses vessel, channels, bloodline, marrow, breath, movement, impact, fall, storm, or compatible sphere interfaces.",
            "suppresses_action_ids": [],
            "recovery": "3 × Severity repair progress reduces Severity by 1.",
            "export_targets": [
              "runtime_record.states[]",
              "Foundation_Detail_Ledger.json.states[]",
              "Character_Import_Surface.json.states[]"
            ],
            "tags": [
              "foundation",
              "hidden_injury",
              "dragon_wind_vessel",
              "runtime_export_v0_2E"
            ]
          }
        ],
        "strains": [
          {
            "state_id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_SKY_SEAL_STRAIN",
            "id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_SKY_SEAL_STRAIN",
            "name": "Sky-Seal Strain",
            "state_type": "strain",
            "classification": "state_tracker",
            "severity": "1-3",
            "trigger": "Forced stillness, sealed meridians, anti-flight wards, heavy grounding methods, or suppressing motion to force incompatible cultivation.",
            "effect": "Suppressed feature is unavailable; at Severity 2+ related checks have DC +2; at Severity 3 failure by 5+ may worsen Wind-Marrow Scouring.",
            "suppresses_action_ids": [],
            "recovery": "Rest, treatment, compatible movement practice, or Foundation Mending Practice.",
            "export_targets": [
              "runtime_record.states[]",
              "Foundation_Detail_Ledger.json.states[]",
              "Character_Import_Surface.json.states[]"
            ],
            "tags": [
              "foundation",
              "strain",
              "dragon_wind_vessel",
              "runtime_export_v0_2E"
            ]
          }
        ],
        "deviations": [
          {
            "state_id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_PRIDE_OF_THE_SKY",
            "id": "STATE_FOUNDATION_DRAGON_WIND_VESSEL_PRIDE_OF_THE_SKY",
            "name": "Pride of the Sky",
            "state_type": "deviation",
            "classification": "deviation_tracker",
            "severity": "1-4",
            "trigger": "Using speed, dragon pressure, or sky-sovereign identity to humiliate weaker creatures, ignore repair warnings, or force reckless breakthrough.",
            "effect": "Temptation can grant bounded advantage, PB bonus, CP recovery, temporary HP, or drawback suppression at cost of Deviation progress.",
            "suppresses_action_ids": [],
            "recovery": "Humble proof, disciplined protection of weaker allies, teacher correction, oath, or story consequence.",
            "export_targets": [
              "runtime_record.states[]",
              "Foundation_Detail_Ledger.json.states[]",
              "Character_Import_Surface.json.states[]"
            ],
            "tags": [
              "foundation",
              "deviation",
              "dragon_wind_vessel",
              "cp",
              "runtime_export_v0_2E"
            ]
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Foundation Mending Practice — Dragon-Wind Vessel",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Reasonable repair input: movement practice, landing practice, breath correction, teacher supervision, marrow medicine, bloodline stabilization, storm rite, formation adjustment, spirit stones, rare materials, proof, vow, or story consequence appropriate to Severity.",
          "range": "",
          "target": "One damaged state attached to Dragon-Wind Vessel",
          "attack_or_save": "",
          "effect": "Use one matching Foundation Repair Interface or outside method to repair Sky-Marred Vessel, Wind-Marrow Scouring, Sky-Seal Strain, Pride of the Sky, or a Crack attached to Dragon-Wind Vessel. On success gain 1 repair progress; on success by 5 or more gain 2; on failure gain none; on failure by 5 or more the DM chooses a complication.",
          "duration": "",
          "limit": "One use per appropriate Foundation scene unless the DM opens a special window.",
          "counterplay": "Wrong diagnosis, incompatible method, lack of teacher/materials, suppressed Foundation, unresolved Deviation, or failed check can block or complicate the attempt.",
          "source_spheres": []
        },
        {
          "name": "Perfected Repair Rider: Wind Remembers Its Marrow",
          "stage": "Perfected",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Successful qualifying Foundation Mending Practice or serious recovery arc.",
          "range": "",
          "target": "Self",
          "attack_or_save": "",
          "effect": "When you complete a Foundation Mending Practice for a Dragon-Wind damaged state, gain +1 repair progress on success. Once per serious recovery arc, when reducing Severity of a movement, breath-channel, marrow, bloodline, wind-pressure, fall, storm, restraint, grounding, or anti-flight Hidden Injury attached to this Foundation, reduce that Severity by 1 additional step.",
          "duration": "",
          "limit": "One use per appropriate Foundation scene unless the DM opens a special window.",
          "counterplay": "Wrong diagnosis, incompatible method, lack of teacher/materials, suppressed Foundation, unresolved Deviation, or failed check can block or complicate the attempt.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Foundation Challenge — Dragon-Wind Vessel",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Challenge scene, teacher, method, storm exposure, movement trial, dragon-blood correction, rare medicine, compatible sphere practice, or equivalent story input.",
          "range": "",
          "target": "Self or one supervised student engaged in Dragon-Wind Vessel Challenge",
          "attack_or_save": "",
          "effect": "Reveal, Deepen, Redirect, Integrate, Transmute, Sever, or Replace Dragon-Wind Vessel through diagnosis, crisis, teacher instruction, compatible sphere practice, breakthrough proof, movement trial, storm exposure, dragon-blood correction, chase proof, landing proof, or resolving pride against disciplined motion. Typical DC: 12 + 2 × target depth rating + active relevant Severity; progress required: 3 × target depth rating, with Sever/Replace adding +3 progress.",
          "duration": "",
          "limit": "One structured Challenge scene per downtime/training block unless the DM declares a crisis proof.",
          "counterplay": "False route diagnosis, incompatible sphere practice, bloodline backlash, anti-motion suppression, pride escalation, or failed check by 5+ may add Strain/Hidden Injury/Deviation.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage Preparation: Sky-Dragon Motion Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "A real movement, breath, chase, pursuit, evasion, storm, height, landing, or dragon-wind discipline practice.",
          "range": "",
          "target": "Self and up to PB willing creatures",
          "attack_or_save": "",
          "effect": "Prepared creatures gain Sky-Dragon Spark until the end of the next serious scene. A creature cannot benefit from more than one instance at a time.",
          "duration": "",
          "limit": "Requires Lineage-Bearing stage and a valid rest, drill, pre-battle rite, training scene, or supervised Foundation Challenge.",
          "counterplay": "Disrupt the rite, deny real practice, suppress the teacher's Foundation, or expose unresolved Pride of the Sky.",
          "source_spheres": []
        },
        {
          "name": "Sky-Dragon Spark",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Consume Sky-Dragon Spark when a prepared creature qualifies in a serious scene.",
          "range": "",
          "target": "Prepared creature",
          "attack_or_save": "",
          "effect": "After the prepared creature moves at least 20 ft with movement it controls before hitting a creature with an attack or technique, it consumes Sky-Dragon Spark after the hit resolves to choose one teacher-scale support: add teacher PB damage to one later hit before end of its next turn; reduce next damage before end of its next turn by teacher PB + teacher cultivation ability modifier; or increase one movement speed it currently possesses by 10 ft until end of its next turn. This does not grant flight, sphere access, or unlearned talents.",
          "duration": "",
          "limit": "One Spark per prepared creature; the Spark is consumed after the qualifying hit resolves and cannot stack with itself.",
          "counterplay": "Deny controlled movement, prevent the qualifying hit, end the prepared scene, or suppress the teacher lineage effect.",
          "source_spheres": []
        },
        {
          "name": "Teacher of Dragon-Wind Marrow",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "",
          "cost": "Presence, honest instruction, and not being ruled by Pride of the Sky.",
          "range": "",
          "target": "One supervised student, ally, or sect member",
          "attack_or_save": "",
          "effect": "When supervising a relevant Dragon-Wind Foundation Challenge, choose one: reduce active relevant Severity by 1; grant +1 to one Cultivation Check; let one failed progress check create Strain or Hidden Injury instead of immediate Deviation escalation; identify the problem category; or make one listed Foundation Repair Interface count as matching for that scene.",
          "duration": "",
          "limit": "Requires Lineage-Bearing stage and a valid training/supervision scene.",
          "counterplay": "False humility, unresolved Pride of the Sky, wrong method, incompatible student Foundation, or lack of scene pressure may block support.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "heaven_devouring_shedding_womb_v0_2B",
      "name": "Heaven-Devouring Shedding-Womb",
      "number": 10,
      "profile": {
        "grade": "Forbidden",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Body Refining",
          "Spirit Awakening"
        ],
        "typical_role": "Hybrid",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your Foundation can turn hostile essence-pressure and forbidden self-rebuilding into a short-lived Devoured Origin Spark. It is powerful and flexible, but advancement is dangerous because the route constantly tempts you to replace cultivation with consumption.",
        "visible_sign": "",
        "warning": "Advancement requires proof that stolen or devoured power does not replace the self.",
        "dao_principle": "To devour heaven without becoming hollow, the self must survive what it consumes and what it sheds."
      },
      "resource": {
        "name": "Devoured Origin Spark",
        "maximum": "1",
        "starting": "0",
        "gain": "After a meaningful hostile creature loses Hit Points from your legal devouring, drain, Hunger, Blood, Death, Void, Unmaking, Daemonic Cultivation, Life self-rebuilding, or Qiweaving stabilization technique; or after you resist a hostile drain, origin theft, possession, or source-corruption effect.",
        "timing": "After trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "No friendly, self-inflicted, staged, training, harmless-creature, or repeated non-threat generation.",
        "spends": [
          "Origin-Seizing Blow",
          "Devouring Return",
          "Shedding-Husk Surge",
          "Refined: Black-Womb Refinement"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Devouring Womb Frame",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your hit point maximum increases by your Proficiency Bonus. Your legal Hunger, Blood, Death, Void, Unmaking, Daemonic Cultivation, Life self-rebuilding, and Qiweaving stabilization techniques may count as Foundation-aligned when they directly devour, shed, rebuild, or resist hostile essence pressure. You have Advantage on saving throws against hostile essence-drain, origin-theft, possession-pressure, and effects that would prevent you from regaining Hit Points by corrupting your source. This does not grant sphere access or automatic healing.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use enemies without essence, anti-drain wards, non-origin damage, distance, or purification pressure.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Fixed Scope — Forbidden Womb Method",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules interpretation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports forbidden devouring, origin-shedding, and self-rebuilding routes. It does not grant permission to eat cultivators, steal souls, harvest allies, ignore campaign law, bypass morality, gain free sphere access, or generate resources from staged harm. Any literal devouring of cultivators remains a Forbidden story act requiring GM permission and consequences.",
            "duration": "",
            "limit": "Always active.",
            "counterplay": "Social law, sect punishment, karmic backlash, anti-devouring wards, and GM legality limits.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Generate Devoured Origin Spark",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a meaningful hostile creature loses Hit Points from your legal devouring, drain, Hunger, Blood, Death, Void, Unmaking, Daemonic Cultivation, Life self-rebuilding, or Qiweaving stabilization technique; or after you resist a hostile drain, origin theft, possession, or source-corruption effect.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the trigger resolves, if you have no Devoured Origin Spark, gain 1 Devoured Origin Spark. The Spark maximum is 1. You can generate it no more than once per round. It expires at the end of your next turn. A Spark generated by an event cannot be spent on that same event. Friendly effects, self-inflicted harm, staged danger, training scenes, harmless creatures, and repeated non-threats never generate this resource.",
            "duration": "",
            "limit": "Max 1; once per round; after trigger resolves; same-event spend not allowed.",
            "counterplay": "Deny qualifying devouring/drain interactions, use constructs or warded foes, force the cultivator to spend before harvesting, or punish forbidden exposure.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Origin-Seizing Blow",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit a meaningful hostile creature with a Foundation-aligned attack or technique that damages, drains, corrodes, devours, withers, unravels, or rebuilds through stolen hostile pressure.",
            "cost": "1 Devoured Origin Spark",
            "range": "Attack or technique range",
            "target": "Triggering hostile creature",
            "attack_or_save": "",
            "effect": "Spend 1 Devoured Origin Spark after the hit resolves. Add damage equal to your Proficiency Bonus + your Path key ability modifier. The damage type must match the triggering legal technique or be necrotic, poison, force, or comparable ruin damage approved by the GM. If the target is below half Hit Points after the added damage, you gain temporary Hit Points equal to your Proficiency Bonus. This does not restore CP and cannot trigger from harmless or staged targets.",
            "duration": "",
            "limit": "Spend 1 Spark; no same-event spending unless the Spark was already available before this hit.",
            "counterplay": "Keep distance, stay unwounded, use anti-drain wards, or force the Spark to expire.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Devouring Return",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take hostile damage, or you are subjected to hostile drain, origin theft, possession pressure, anti-healing corruption, or source-corruption pressure.",
            "cost": "1 Devoured Origin Spark",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Devoured Origin Spark as a Reaction. Reduce the triggering hostile damage, drain value, origin-theft pressure, or anti-healing/source-corruption pressure by your Proficiency Bonus + your Path key ability modifier. If the source is a wounded hostile creature or a direct drain/origin-theft effect, increase the reduction by your Proficiency Bonus. This cannot reduce self-inflicted costs, voluntary overdraw, hidden injury consequences, or breakthrough backlash unless the GM explicitly treats the event as hostile.",
            "duration": "",
            "limit": "Reaction; spend 1 Spark; no same-event spending unless Spark was already available.",
            "counterplay": "Use non-drain damage, force multiple threats, deny Spark generation, or apply non-reducible breakthrough/hidden-injury consequences.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Shedding-Husk Surge",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "You have Devoured Origin Spark available on your turn.",
            "cost": "1 Devoured Origin Spark",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Devoured Origin Spark as a Bonus Action. Gain temporary Hit Points equal to 2 × your Proficiency Bonus + your Path key ability modifier. Before the end of your next turn, you have Advantage on the next saving throw or ability check you make against Poisoned, Frightened, Grappled, Restrained, possession pressure, drain, or body/source suppression. This does not automatically end a condition already on you unless the triggering roll succeeds.",
            "duration": "",
            "limit": "Bonus Action; spend 1 Spark.",
            "counterplay": "Pressure the cultivator before their turn, remove temp HP, use conditions not listed, or bait the Spark early.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Black-Womb Refinement",
            "stage": "Refined",
            "type": "Passive / Rider",
            "trigger": "The Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When this Foundation is Refined, the hit point maximum increase from Devouring Womb Frame becomes 2 × your Proficiency Bonus. When you spend Devoured Origin Spark on Origin-Seizing Blow or Devouring Return, add your Proficiency Bonus to one numeric damage, temporary Hit Point, or reduction value in that spend. This modifies the base spend; it does not require an additional action, Reaction, or resource and does not permit same-event spending.",
            "duration": "",
            "limit": "Refined stage only.",
            "counterplay": "Anti-devouring wards, purification, or denying Spark still works.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          },
          {
            "name": "Refined: Imperishable Husk",
            "stage": "Refined",
            "type": "Passive / Rider",
            "trigger": "The Foundation is Refined and you use Shedding-Husk Surge.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you use Shedding-Husk Surge while this Foundation is Refined, you also gain Resistance to necrotic damage and poison damage until the start of your next turn. This modifies Shedding-Husk Surge; it does not require an additional Bonus Action, Reaction, or resource and does not permit same-event spending.",
            "duration": "",
            "limit": "Refined stage only; tied to Shedding-Husk Surge.",
            "counterplay": "Use non-necrotic/non-poison damage, wait out the duration, or deny Spark.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Imperishable Heaven Womb",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You are Perfected and have not used this feature since your last long rest.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "As a Bonus Action once per long rest, awaken the Imperishable Heaven Womb for 1 minute. Gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. For the duration, your qualifying Foundation-aligned devouring, shedding, self-rebuilding, or source-corrupting hits deal additional damage equal to your Proficiency Bonus, and you have Advantage on saving throws and ability checks against drain, poison, necrotic source-corruption, possession pressure, and body/source suppression. Devoured Origin Spark maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest.",
            "counterplay": "Force the duration early, use non-listed damage/control, exploit social/karmic consequences, or counter with anti-forbidden rites.",
            "source_spheres": [
              "Hunger",
              "Unmaking",
              "Blood",
              "Death",
              "Void",
              "Daemonic Cultivation",
              "Life",
              "Qiweaving"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Hunger",
          "Unmaking",
          "Blood",
          "Death",
          "Void",
          "Daemonic Cultivation",
          "Life",
          "Qiweaving"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_HEAVEN_DEVOURING_SHEDDING_WOMB_ORIGIN_DEBT",
            "name": "Origin Debt",
            "effect": "Advancement requires proof that stolen or devoured power does not replace the self. Forbidden acts attract social, karmic, sect, and heavenly consequences.",
            "gm_note": "Do not balance this Foundation by making the turn loop fiddly; balance it through advancement cost, story consequence, repair difficulty, and deviation pressure."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_HEAVEN_DEVOURING_SHEDDING_WOMB_HOLLOW_ORIGIN_SCAR",
            "name": "Hollow Origin Scar",
            "effect": "The cultivator feels empty when not taking in hostile essence; healing and self-restoration may feel cold, incomplete, or borrowed until repaired."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_HEAVEN_DEVOURING_SHEDDING_WOMB_BLACK_WOMB_STRAIN",
            "name": "Black-Womb Strain",
            "effect": "Repeated devouring or failed shedding leaves black residue in the meridians, inviting anti-healing backlash and social/spiritual detection."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_HEAVEN_DEVOURING_SHEDDING_WOMB_ORIGIN_HUNGER",
            "name": "Origin Hunger",
            "effect": "The cultivator begins to view worthy enemies as ingredients rather than persons."
          },
          {
            "id": "DEVIATION_HEAVEN_DEVOURING_SHEDDING_WOMB_BORROWED_FACE_DIVINITY",
            "name": "Borrowed-Face Divinity",
            "effect": "Transformation begins to copy victims, teachers, or rivals instead of refining the cultivator’s own Dao."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair Practice — Clean Cauldron Fast",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You spend downtime refusing devouring practice and purging residue.",
          "cost": "Downtime, teacher or purification method",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A repair practice using fasting, clean medicine, purification, and refusal of easy prey to reduce Black-Womb Strain or diagnose Hollow Origin Scar. It cannot erase Forbidden acts already committed.",
          "duration": "",
          "limit": "GM-controlled downtime.",
          "counterplay": "Requires honest abstinence and purification; cannot be performed while actively feeding the deviation.",
          "source_spheres": [
            "Alchemy",
            "Life",
            "Protection",
            "Radiance",
            "Qiweaving"
          ]
        },
        {
          "name": "Repair Practice — Origin-Ledger Confession",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You identify what was taken, from whom, and what debt remains.",
          "cost": "Downtime, witness, ritual ledger, or karmic teacher",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator records sources of taken power, names forbidden debts, and accepts restitution or consequence. This can reduce deviation pressure and open lawful containment paths.",
          "duration": "",
          "limit": "GM-controlled downtime.",
          "counterplay": "False confession, missing victims, and continued predation block repair.",
          "source_spheres": [
            "Karma",
            "Ink",
            "Protection",
            "Life"
          ]
        },
        {
          "name": "Repair Practice — New-Husk Tempering",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You rebuild damaged meridians and shed contaminated residue.",
          "cost": "Rare materials, safe chamber, teacher, and downtime",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A controlled body/soul rebuilding project using rare medicines, sealed arrays, and a teacher who understands forbidden shedding. It may repair hidden injury but risks further deviation on failure.",
          "duration": "",
          "limit": "GM-controlled downtime.",
          "counterplay": "Requires rare materials and safe containment; enemy interference can corrupt the new husk.",
          "source_spheres": [
            "Life",
            "Formations",
            "Alchemy",
            "Protection",
            "Qiweaving"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Foundation Challenge — Refuse Easy Prey",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A vulnerable target would feed the Foundation easily.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator must refuse a convenient devouring opportunity when taking it would be safe and useful but morally or spiritually corrupting.",
          "duration": "",
          "limit": "GM scene.",
          "counterplay": "Temptation, hunger, rivals, or urgent need make refusal difficult.",
          "source_spheres": [
            "Hunger",
            "Karma",
            "Life"
          ]
        },
        {
          "name": "Foundation Challenge — Survive Anti-Devouring Ward",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You must cultivate under a ward designed to reject devouring methods.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator endures a sealed chamber, formation, or heavenly ward that prevents devouring. Success proves the Foundation is not merely hunger.",
          "duration": "",
          "limit": "GM scene.",
          "counterplay": "Ward failure, hidden feeding, or cheating invalidates the proof.",
          "source_spheres": [
            "Formations",
            "Protection",
            "Void",
            "Qiweaving"
          ]
        },
        {
          "name": "Foundation Challenge — Shed Without Stealing a Face",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You rebuild your shell after injury or failure.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator sheds a damaged old self without copying a victim, stealing a face, or replacing conscience with a borrowed origin.",
          "duration": "",
          "limit": "GM scene.",
          "counterplay": "Borrowed identity, stolen memories, and false rebirth create deviation.",
          "source_spheres": [
            "Life",
            "Void",
            "Death",
            "Qiweaving"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage — Heaven-Devouring Fragment",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A teacher, forbidden scripture fragment, or enemy inheritance offers a devouring route.",
          "cost": "Lineage access, teacher, or scripture",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A fragment can explain why the Foundation can advance, but it does not grant combat benefits unless a separate combat row is written.",
          "duration": "",
          "limit": "Downtime only.",
          "counterplay": "Forbidden scripture scrutiny, sect law, and corruption risk.",
          "source_spheres": [
            "Hunger",
            "Unmaking",
            "Death",
            "Void"
          ]
        },
        {
          "name": "Lineage — Imperishable Heaven Method Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A qualified teacher diagnoses whether shedding or devouring is safe.",
          "cost": "Teacher, diagnostic ritual, or sealed chamber",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A teacher or diagnostic method identifies whether the cultivator can shed a husk without stealing another origin. It may open a repair route or challenge condition but has no direct combat action row.",
          "duration": "",
          "limit": "Downtime only.",
          "counterplay": "False teachers, demonic bait, or unsealed chambers can worsen deviation.",
          "source_spheres": [
            "Life",
            "Qiweaving",
            "Protection",
            "Karma"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "nine_bitter_heartfire_v0_2B",
      "name": "Nine-Bitter Heartfire",
      "number": 11,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Spirit Awakening",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Body Refining"
        ],
        "typical_role": "Hybrid",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Failure-forward comeback Foundation that converts real hostile opposition into later resolve without rewarding fake failure.",
        "visible_sign": "",
        "warning": "You cannot generate Bitter Heartfire from voluntary failure, friendly or training effects, deliberately impossible rolls, intentionally chosen Disadvantage, harmless repeated obstacles, self-created danger, or self-sabotage.",
        "dao_principle": "Learn from failure without worshiping it."
      },
      "resource": {
        "name": "Bitter Heartfire",
        "maximum": "1",
        "starting": "0",
        "gain": "After you miss a hostile creature with an attack or Foundation-aligned technique, after a hostile creature succeeds on a saving throw against your Foundation-aligned technique, or after you fail a saving throw or ability check against a hostile effect and remain conscious.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Avoid giving clean hostile failure, pressure with attrition, or tempt self-sabotage that does not generate Heartfire.",
        "spends": [
          "Bitter Return Strike",
          "Refuse the Bitter Lesson",
          "Heartfire Surge",
          "Refined: Nine Coals Remember",
          "Refined: Pain Becomes Method"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Bitter Heartfire Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Fire, Blood, Berserker, Yang, Destruction, Karma, Radiance, Qiweaving, Spirit Companions, and Poison methods that turn real opposition, scars, humiliation, failed technique residue, or hard-won resolve into action may count as Foundation-aligned. You have Advantage on saving throws against fear, despair, shame-pressure, heart-demon temptation, and hostile effects that exploit a recent failure. This passive requires no per-round tracking.",
            "duration": "",
            "limit": "Passive only; does not generate from voluntary failure and grants no free rerolls.",
            "counterplay": "Deny meaningful opposition, bait reckless escalation, exploit the cultivator’s need to answer failure.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Nine-Bitter Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports real hostile failure, recovery after meaningful loss, bitter heartfire, comeback strikes, scar refinement, and converting failed technique residue into instruction. It does not support voluntary failure, staged failure, friendly/training effects, deliberately impossible rolls, deliberate disadvantage farming, harmless repeated obstacles, or self-sabotage.",
            "duration": "",
            "limit": "Scope only; no sphere access and no reward for fake failure.",
            "counterplay": "Force the cultivator to learn without indulging revenge, or present failures that cannot be punched away.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Generate Bitter Heartfire",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you miss a hostile creature with an attack or Foundation-aligned technique, after a hostile creature succeeds on a saving throw against your Foundation-aligned technique, or after you fail a saving throw or ability check against a hostile effect and remain conscious.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain 1 Bitter Heartfire after the qualifying trigger resolves. Maximum 1. Once per round. It expires at the end of your next turn. You cannot spend Bitter Heartfire on the same event that generated it. You cannot generate it from voluntary failure, friendly or training effects, deliberately impossible rolls, intentionally chosen Disadvantage, harmless repeated obstacles, self-created danger, or self-sabotage.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; no same-event spending; anti-farming burden applies.",
            "counterplay": "Avoid giving clean hostile failure, pressure with attrition, or tempt self-sabotage that does not generate Heartfire.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Bitter Return Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature with an attack or Foundation-aligned technique.",
            "cost": "1 Bitter Heartfire",
            "range": "Varies by triggering attack",
            "target": "One hostile creature hit by the triggering attack",
            "attack_or_save": "",
            "effect": "Spend 1 Bitter Heartfire after the hit resolves. Add your Proficiency Bonus + your Path key ability modifier as fire, psychic, or radiant damage. If the hit is against a creature that caused your most recent qualifying Bitter Heartfire generation, add your Proficiency Bonus to the damage. This is not an extra attack and does not permit same-event spending.",
            "duration": "",
            "limit": "No extra action; must follow a real hit; no same-event spending.",
            "counterplay": "Force the cultivator to spend defensively, change targets, or deny follow-up attacks.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Refuse the Bitter Lesson",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You fail a saving throw or ability check against a hostile fear, despair, control, curse, heart-demon, poison, pain, or pressure effect.",
            "cost": "1 Bitter Heartfire",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Bitter Heartfire as a Reaction. Add your Proficiency Bonus + your Path key ability modifier to the failed saving throw or ability check. If this changes the outcome, you succeed. If it does not change the outcome and the triggering effect deals damage, reduce that damage by your Proficiency Bonus. This is a hard-won correction, not a free reroll.",
            "duration": "",
            "limit": "Requires Reaction; self only; cannot spend on the same event that generated Bitter Heartfire.",
            "counterplay": "Bait the Reaction, use effects outside the scope, or pressure allies instead.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Heartfire Surge",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Bitter Heartfire.",
            "cost": "1 Bitter Heartfire",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Bitter Heartfire as a Bonus Action. You gain temporary Hit Points equal to twice your Proficiency Bonus + your Path key ability modifier. Before the end of this turn, the next attack roll you make against a hostile creature or the next eligible saving throw/check you make against hostile pressure has Advantage.",
            "duration": "",
            "limit": "Self only; temporary HP does not stack with itself; one Advantage window.",
            "counterplay": "Force the surge early, deny targets, or impose conditions that block attacks/actions.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Nine Coals Remember",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Applies while the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Bitter Heartfire Vessel, Bitter Return Strike, and Refuse the Bitter Lesson. Your maximum Hit Point bonus from this Foundation becomes twice your Proficiency Bonus. When you spend Bitter Heartfire on Bitter Return Strike or Refuse the Bitter Lesson, add your Proficiency Bonus to one numeric value produced by that spend. This rider costs no extra action, Reaction, or resource, and does not permit same-event spending.",
            "duration": "",
            "limit": "Rider only; affects one numeric value; no extra resource/reaction.",
            "counterplay": "Bait the spend or exploit the anti-farming burden.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          },
          {
            "name": "Refined: Pain Becomes Method",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Bitter Heartfire on Heartfire Surge.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This modifies Heartfire Surge. When you spend Bitter Heartfire on Heartfire Surge, you also gain Resistance to fire damage and psychic damage until the start of your next turn. This rider costs no extra action, Reaction, or resource, and does not permit same-event spending.",
            "duration": "",
            "limit": "Rider only; no extra resource/reaction.",
            "counterplay": "Use other damage types, wait out the short duration, or deny the Bonus Action window.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Nine-Bitter Heartfire Mandala",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while conscious and the Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Activate Nine-Bitter Heartfire Mandala for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. Your Foundation-aligned hits against hostile creatures deal additional fire, psychic, or radiant damage equal to your Proficiency Bonus. You have Advantage on saving throws against fear, despair, shame-pressure, and heart-demon temptation. Bitter Heartfire maximum remains 1 and all anti-farming restrictions remain active.",
            "duration": "",
            "limit": "Once per long rest; 1 minute; resource cap remains 1; anti-farming burden remains active.",
            "counterplay": "Avoid emotional escalation, deny follow-up hits, use non-fear pressure, or exploit mercy tests.",
            "source_spheres": [
              "Fire",
              "Blood",
              "Berserker",
              "Yang",
              "Destruction",
              "Karma",
              "Radiance",
              "Qiweaving",
              "Spirit Companions",
              "Poison"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Fire",
          "Blood",
          "Berserker",
          "Yang",
          "Destruction",
          "Karma",
          "Radiance",
          "Qiweaving",
          "Spirit Companions",
          "Poison"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "burden_do_not_court_failure",
            "display_name": "Burden — Do Not Court Failure",
            "text": "You cannot generate Bitter Heartfire from voluntary failure, friendly or training effects, deliberately impossible rolls, intentionally chosen Disadvantage, harmless repeated obstacles, self-created danger, or self-sabotage."
          }
        ],
        "hidden_injuries": [
          {
            "id": "hidden_injury_ash_in_the_heart",
            "display_name": "Ash-in-the-Heart Hidden Injury",
            "text": "The heartfire burns unevenly, causing feverish emotion, insomnia, chest heat, or sudden pain after failure."
          }
        ],
        "strains": [
          {
            "id": "strain_bitter_meridian_scarring",
            "display_name": "Bitter Meridian Scarring",
            "text": "Technique residue scars pathways; power returns sharply but not cleanly."
          }
        ],
        "deviations": [
          {
            "id": "deviation_revenge_furnace",
            "display_name": "Revenge Furnace Deviation",
            "text": "The cultivator needs enemies and insults to feel alive."
          },
          {
            "id": "deviation_self_sabotage",
            "display_name": "Self-Sabotage Deviation",
            "text": "The cultivator courts failure to harvest power."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Cool the Ash-in-the-Heart",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Rest, confession, breath discipline, or medicine cools unstable heartfire after meaningful failure.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        },
        {
          "name": "Repair: Name the Real Lesson",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "The cultivator identifies what the failure actually taught instead of turning it into revenge.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        },
        {
          "name": "Repair: Refuse Self-Sabotage",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher or ally helps prove the Foundation does not need staged pain to burn.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Win Without Cruelty",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Defeat a hostile creature after previous failure without escalating into needless punishment.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        },
        {
          "name": "Challenge: Lose Without Collapse",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Suffer a meaningful defeat, survive, and change method instead of identity.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        },
        {
          "name": "Challenge: Refuse the Heart-Demon Bargain",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Reject a useful but corrupting interpretation of failure.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Nine-Bitter Coal Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A heartfire scripture teaches how to bank the lesson of defeat without worshiping pain.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        },
        {
          "name": "Lineage: Scar-Reading Teacher Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher diagnoses whether the cultivator is learning, avenging, or sabotaging themselves.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Fire",
            "Blood",
            "Berserker",
            "Yang",
            "Destruction",
            "Karma",
            "Radiance",
            "Qiweaving",
            "Spirit Companions",
            "Poison"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "heavenly_body_v0_2F",
      "name": "Heavenly Body",
      "number": 12,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining or Qi Cultivation",
        "secondary_path_fit": "Radiance, Yang, Protection, Guardian, Weather, Sword, Life",
        "typical_role": "Striker / Defender",
        "complexity": "Low"
      },
      "overview": {
        "summary": "Your body is unusually pure, durable, and responsive to orthodox cultivation. It holds itself together under punishment and turns endured harm into brief Heavenly Integrity.",
        "visible_sign": "Wounds close cleanly, poison darkens before entering the blood, and skin may show pale gold or jade light when your body rejects hostile force.",
        "warning": "Polluted methods, devouring inheritances, corpse arts, demonic cultivation, aggressive impurity experiments, and purity arrogance can make the vessel reject its own route.",
        "dao_principle": "The body is a vessel Heaven recognizes as worthy of higher law."
      },
      "resource": {
        "name": "Heavenly Integrity",
        "maximum": "1",
        "starting": "0",
        "gain": "After you take damage from a hostile attack or technique and remain conscious, once per round.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round. Requires actual damage from a hostile attack or technique and you must remain conscious after the damage resolves.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Avoid damaging the cultivator before disabling them, use control instead of damage, suppress the Foundation, exhaust their held Integrity with small attacks, or force them to spend Integrity defensively before their turn.",
        "spends": [
          "Integrity Guard",
          "Integrity Rejection",
          "Integrity Strike",
          "Jade-Gold Guard",
          "Heaven-Rejecting Marrow",
          "Orthodox Answering Strike",
          "Heaven-Recognized Vessel"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Generate Heavenly Integrity",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you take damage from a hostile attack or technique and remain conscious, once per round.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering damage resolves, gain 1 Heavenly Integrity, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same damage event that generated it.",
            "duration": "Until end of your next turn; refreshes instead of stacking if generated again while held.",
            "limit": "Once per round. Requires actual damage from a hostile attack or technique and you must remain conscious after the damage resolves.",
            "counterplay": "Avoid damaging the cultivator before disabling them, use control instead of damage, suppress the Foundation, exhaust their held Integrity with small attacks, or force them to spend Integrity defensively before their turn.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          },
          {
            "name": "Integrity Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take damage while holding pre-existing Heavenly Integrity.",
            "cost": "1 Heavenly Integrity",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: spend 1 pre-existing Heavenly Integrity as a Reaction to reduce triggering damage by PB + cultivation ability modifier. Evolution: Jade-Gold Guard, if selected, adds +PB to this same Guard spend; Heaven-Recognized Vessel at Perfected adds +PB once/round to the same Guard spend. These stack; with both evolutions, Guard reduces cultivation ability modifier + 3×PB damage. No second reaction, no second resource cost, no same-event exception.",
            "duration": "Instant",
            "limit": "Requires pre-existing Heavenly Integrity. Cannot spend Integrity generated by the same damage event. Consumes the held Integrity.",
            "counterplay": "Force the cultivator to spend Integrity before a major hit, use non-damage control, deny the previous damage trigger, or apply effects that suppress reactions.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          },
          {
            "name": "Integrity Rejection",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You make a Constitution saving throw, death saving throw, or a save against a hostile effect that would poison, sicken, exhaust, corrupt, seize, transform, or internally disrupt your body while holding pre-existing Heavenly Integrity.",
            "cost": "1 Heavenly Integrity",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: spend 1 pre-existing Heavenly Integrity after rolling but before outcome to add PB to a qualifying bodily save. Evolution: Heaven-Rejecting Marrow, if selected, keeps the base +PB and improves timing to after declared failure but before consequences; Heaven-Recognized Vessel at Perfected adds +PB once/round to the same Rejection spend. These stack as +2×PB at Perfected if used on Rejection; no second resource cost or same-event exception.",
            "duration": "Instant",
            "limit": "Requires pre-existing Heavenly Integrity. Cannot spend Integrity generated by the same event unless a later-stage feature explicitly says otherwise. Consumes the held Integrity.",
            "counterplay": "Draw out the resource with attacks, target non-body saves, apply suppression or Strain, or force repeated saving throws after the single Integrity is spent.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          },
          {
            "name": "Integrity Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit with an attack or technique while holding pre-existing Heavenly Integrity.",
            "cost": "1 Heavenly Integrity",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: spend 1 pre-existing Heavenly Integrity to add PB damage to a hit. Evolution: Orthodox Answering Strike, if selected, adds +PB more when the target damaged you since the end of your last turn; Heaven-Recognized Vessel at Perfected adds +PB once/round to the same Strike spend. These stack; with both evolutions against a qualifying target, Strike adds 3×PB damage. No second resource cost or same-event exception.",
            "duration": "Instant",
            "limit": "Requires pre-existing Heavenly Integrity. One Integrity spend consumes the held Integrity unless a later-stage feature modifies the spend.",
            "counterplay": "Deny the prior damage trigger, force defensive spending, impose misses, use resistance or reduction against the hit, or pressure the cultivator while Integrity is unavailable.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Jade-Gold Guard",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You use Integrity Guard and have selected Jade-Gold Guard as your Refined expression.",
            "cost": "Same Heavenly Integrity spend as Integrity Guard",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution of Integrity Guard. Base Guard reduces PB + cultivation ability modifier damage. Jade-Gold Guard adds +PB to the same Guard spend, stacking with the base. At Perfected, Heaven-Recognized Vessel may add +PB more once/round to the same spend; with both evolutions, total Guard reduction is cultivation ability modifier + 3×PB. No second reaction or second spend.",
            "duration": "Instant",
            "limit": "Only usable if Jade-Gold Guard is the selected Refined expression. It modifies the same Integrity Guard spend.",
            "counterplay": "As Integrity Guard; additionally, use non-damage control or resource pressure before major hits.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          },
          {
            "name": "Heaven-Rejecting Marrow",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You fail a save that would be legal for Integrity Rejection and have selected Heaven-Rejecting Marrow as your Refined expression.",
            "cost": "1 Heavenly Integrity",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution of Integrity Rejection. Base Rejection adds +PB after rolling but before outcome. Heaven-Rejecting Marrow keeps the base +PB and improves timing: it may be used after the save is declared a failure but before consequences. At Perfected, Heaven-Recognized Vessel may add +PB more once/round to the same spend, for +2×PB using the improved timing. No second spend.",
            "duration": "Instant",
            "limit": "Only usable if Heaven-Rejecting Marrow is the selected Refined expression. Requires pre-existing Heavenly Integrity.",
            "counterplay": "Force the resource out before the key save, target non-body saves, apply multiple saves, or use suppression and Strain.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          },
          {
            "name": "Orthodox Answering Strike",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You use Integrity Strike and have selected Orthodox Answering Strike as your Refined expression.",
            "cost": "Same Heavenly Integrity spend as Integrity Strike",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution of Integrity Strike. Base Strike adds +PB damage. Orthodox Answering Strike adds +PB more when the target damaged you since the end of your last turn, stacking with the base. At Perfected, Heaven-Recognized Vessel may add +PB more once/round to the same spend; with both evolutions against a qualifying target, total bonus damage is +3×PB. No second spend.",
            "duration": "Instant",
            "limit": "Only usable if Orthodox Answering Strike is the selected Refined expression. The target must have damaged you since the end of your last turn.",
            "counterplay": "Avoid directly damaging the cultivator, use minions to trigger Integrity, force defensive spending, or deny the cultivator a clean return hit.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Heaven-Recognized Vessel",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "You spend Heavenly Integrity at Perfected stage.",
            "cost": "Same Heavenly Integrity spend",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Perfected evolution. Once per round when you spend Heavenly Integrity, add +PB to the numeric benefit of the chosen conversion. This stacks with the Awakened base and the selected Refined expression: Guard with Jade-Gold becomes cultivation ability modifier + 3×PB reduction; Rejection with Heaven-Rejecting Marrow becomes +2×PB using improved timing; Strike with Orthodox Answering Strike against a qualifying target becomes +3×PB damage. Same spend only; no extra reaction; no second resource cost; no same-event exception.",
            "duration": "Instant",
            "limit": "Once per round. Modifies the same Heavenly Integrity spend; does not create a second reaction or allow same-event spending.",
            "counterplay": "Deny the Integrity trigger, force early spending, suppress the Foundation, or use control and positioning instead of trading blows.",
            "source_spheres": [
              "Radiance",
              "Yang",
              "Protection",
              "Guardian",
              "Life",
              "Weather",
              "Sword"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Radiance",
          "Yang",
          "Protection",
          "Guardian",
          "Life",
          "Weather",
          "Sword"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [
        {
          "name": "Orthodox Vessel Correction",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Foundation Scene",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "Use one compatible correction source—Method correction, teacher correction, Life/Radiance/Protection/Yang/Alchemy/Formations support, rare medicine/rite/site, or a story correction that addresses purity rejection. On success, add 1 repair progress toward Heavenly Purity Rejection, Cracked Heavenly Vessel, or Heavenly Vessel Strain.",
          "duration": "Scene",
          "limit": "Downtime/Foundation repair only; not a normal combat action.",
          "counterplay": "Requires scene time, compatible correction source, and access to the relevant teacher, method, medicine, rite, or site.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        },
        {
          "name": "Impurity Diagnosis Without Rejection",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Foundation Scene",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "A teacher, physician, formation, or self-diagnosis distinguishes true impurity from structural Heavenly Body rejection. On success, reduce by 2 one training or treatment DC that directly involves Heavenly Body purity rejection, bodily corruption, poison/disease rejection, forced transformation resistance, or internal-body recovery for the scene.",
          "duration": "Scene",
          "limit": "Downtime/Foundation repair only; not a normal combat action.",
          "counterplay": "Requires scene time, compatible correction source, and access to the relevant teacher, method, medicine, rite, or site.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Purify Without Arrogance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Foundation Challenge",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "Advance, integrate, or redirect Heavenly Body by proving bodily integrity without rejecting wounded, ordinary, deviant, or impure lives as beneath correction. A directly compatible sphere interface or teacher correction may reduce the DC by 2 if it is part of the Challenge scene.",
          "duration": "Scene",
          "limit": "Foundation Challenge only; not a normal combat action.",
          "counterplay": "Requires a valid Heavenly Body challenge scene and applicable active Severity if present.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Heavenly Vessel Tempering Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Lineage Scene",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "Downtime lineage preparation: prepare a compatible learner/patient with vessel breathing, marrow washing, and rejection diagnosis. Their next Foundation Challenge, treatment, diagnosis, or breakthrough-preparation scene involving bodily corruption, poison/disease rejection, forced transformation resistance, or internal-body disruption may treat Heavenly Body as a teacher-supported interface. This grants support/rite access, not a full Foundation copy. Lineage policy: this is a downtime/lineage support row and does not export to GM Screen action rows unless rewritten as a separate combat-usable action.",
          "duration": "Scene",
          "limit": "Downtime/lineage only; does not duplicate the full Heavenly Body Foundation in another character.",
          "counterplay": "Requires appropriate scene time, compatible learner or institution, honest method, and teacher access.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        },
        {
          "name": "Heaven-Body Spark",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Lineage Scene",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "Downtime lineage preparation: place a lesser Heaven-Body Spark in a compatible learner for one treatment, diagnosis, Foundation Challenge, or breakthrough-preparation scene involving hostile bodily corruption, poison/disease rejection, forced transformation, or internal-body disruption. This is teacher-supported correction, not a combat action or full Foundation copy. Lineage policy: this is a downtime/lineage support row and does not export to GM Screen action rows unless rewritten as a separate combat-usable action.",
          "duration": "Scene",
          "limit": "Downtime/lineage only; does not duplicate the full Heavenly Body Foundation in another character.",
          "counterplay": "Requires appropriate scene time, compatible learner or institution, honest method, and teacher access.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        },
        {
          "name": "Teacher of the Recognized Vessel",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime / Lineage Scene",
          "cost": "Scene time",
          "range": "Narrative / Scene",
          "target": "Self, learner, patient, or Foundation scene as applicable",
          "attack_or_save": "",
          "effect": "Campaign/institutional lineage: found or supervise orthodox body-tempering and vessel-correction methods, producing manuals, rites, diagnostic protocols, lesser body traces, or sect roles. Does not automatically duplicate the founder’s Legendary Foundation in students. Lineage policy: this is a downtime/lineage support row and does not export to GM Screen action rows unless rewritten as a separate combat-usable action.",
          "duration": "Scene",
          "limit": "Downtime/lineage only; does not duplicate the full Heavenly Body Foundation in another character.",
          "counterplay": "Requires appropriate scene time, compatible learner or institution, honest method, and teacher access.",
          "source_spheres": [
            "Radiance",
            "Yang",
            "Protection",
            "Life",
            "Alchemy",
            "Formations"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "innate_sacred_body_dao_embryo_v0_2B",
      "name": "Innate Sacred Body Dao Embryo",
      "number": 13,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Spirit Awakening"
        ],
        "typical_role": "Controller / Striker / Mobility",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body is not merely strong; it naturally remembers the shape of the Dao. Suppression, forced movement, and hostile authority meet a foundation that rings back toward its origin.",
        "visible_sign": "",
        "warning": "Advancing this Foundation draws severe scrutiny from formations, sects, heavenly pressure, and enemies who fear a body that can align with Dao authority.",
        "dao_principle": "When body and Dao share one beginning, hostile authority must first prove it has the right to move you."
      },
      "resource": {
        "name": "Origin Bell Tone",
        "maximum": "1",
        "starting": "0",
        "gain": "After you withstand eligible hostile body-control, suppression, authority, formation, gravity, fate, or spatial pressure, or after you hit a hostile creature with a Foundation-aligned close/body-bound or Dao-authority method.",
        "timing": "After trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "No friendly, staged, harmless, repeated non-threat, or training generation.",
        "spends": [
          "No-Beginning Guard",
          "Sacred-Dao Strike",
          "Origin Bell Surge",
          "Refined — Origin Bell Resonance"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Sacred-Dao Embryo Frame",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your hit point maximum increases by twice your Proficiency Bonus. Your legal Body Refining, Athletics, Brute, Force, Gravity, Protection, Qiweaving, Fate, Karma, Formations, Space, Stars, and Spirit Companions techniques may count as Foundation-aligned when they clearly express body-Dao alignment, return-to-origin pressure, authority resistance, or a sacred body refusing suppression. You have Advantage on Strength and Constitution checks and saving throws against hostile forced movement, being knocked Prone, Grappled, Restrained, body-suppression pressure, and comparable authority, formation, gravity, fate, or spatial pressure that tries to bind, move, silence, displace, or suppress your body. This grants no sphere access, no automatic immunity, and no per-round passive bonus.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use effects outside the listed pressure families, mental/social manipulation, ranged attrition, exhaustion, or higher authority.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Force",
              "Gravity",
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars",
              "Spirit Companions"
            ]
          },
          {
            "name": "Fixed Scope — Sacred Dao Alignment",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules scope for the Foundation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation does not grant free sphere access, free concentration, automatic success, immunity to all control, generic saving throw advantage, teleportation, timeline reversal, or extra actions. It supports body-Dao alignment, suppression resistance, close/body-bound authority, and return-to-origin pressure. A technique must still be legal from Path, sphere, talent, manual, item, Insight, or GM approval before the Foundation can enhance it.",
            "duration": "",
            "limit": "Always active.",
            "counterplay": "Counterplay remains possible through higher authority, effects outside scope, distance, attrition, and non-body pressure.",
            "source_spheres": [
              "Qiweaving",
              "Protection",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars"
            ]
          },
          {
            "name": "Generate Origin Bell Tone",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you withstand eligible hostile body-control, suppression, authority, formation, gravity, fate, or spatial pressure, or after you hit a hostile creature with a Foundation-aligned close/body-bound or Dao-authority method.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the qualifying event resolves, if you are conscious and do not already have Origin Bell Tone, gain 1 Origin Bell Tone. This can happen at most once per round. Origin Bell Tone expires at the end of your next turn. You cannot spend a Tone on the same event that generated it. Staged, friendly, harmless, repeated non-threat, or training events do not generate Tone.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; no same-event spending.",
            "counterplay": "Deny qualifying pressure, attack from outside the Foundation's scope, bait the Tone, or wait for expiry.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Force",
              "Gravity",
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars",
              "Spirit Companions"
            ]
          },
          {
            "name": "No-Beginning Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take hostile damage from a creature or effect within 60 feet, or you fail an eligible Strength/Constitution check or saving throw against body-control or authority-suppression pressure.",
            "cost": "1 Origin Bell Tone",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Origin Bell Tone. If the trigger is hostile damage, reduce the damage by 2×PB + your Path key ability modifier. If the trigger is a failed eligible Strength or Constitution check or saving throw against forced movement, Prone, Grappled, Restrained, body-suppression, formation pressure, gravity pressure, fate pressure, spatial displacement, or comparable authority suppression, add 2×PB + your Path key ability modifier to the roll, possibly changing the result. This modifies the triggering event only and does not grant immunity to later effects.",
            "duration": "",
            "limit": "Requires Origin Bell Tone; one Reaction; no same-event spending.",
            "counterplay": "Bait the Reaction, attack after the Tone is gone, use non-eligible pressure, or use higher authority.",
            "source_spheres": [
              "Force",
              "Gravity",
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars"
            ]
          },
          {
            "name": "Sacred-Dao Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit a hostile creature with a Foundation-aligned close/body-bound or Dao-authority attack or technique.",
            "cost": "1 Origin Bell Tone",
            "range": "Same as triggering attack or technique",
            "target": "One hostile creature you hit",
            "attack_or_save": "",
            "effect": "Spend 1 Origin Bell Tone after the qualifying hit resolves. Add damage equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, the target cannot push, pull, teleport, knock Prone, Grapple, Restrain, or body-suppress you unless the effect is Secret, artifact-scale, higher-Realm, or otherwise higher authority. This is not a mark and does not stop the target from attacking normally.",
            "duration": "",
            "limit": "Requires Origin Bell Tone; no action; no same-event spending.",
            "counterplay": "Use higher authority, attack another target, or pressure with non-body effects.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Force",
              "Gravity",
              "Qiweaving",
              "Fate",
              "Karma",
              "Space",
              "Stars"
            ]
          },
          {
            "name": "Origin Bell Surge",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "You spend the stored Tone to align body and Dao before acting.",
            "cost": "1 Origin Bell Tone",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Origin Bell Tone as a Bonus Action. Gain temporary Hit Points equal to 2×PB + your Path key ability modifier. Before the end of this turn, your next Foundation-aligned close/body-bound attack, Dao-authority technique roll, or eligible Strength/Constitution resistance roll has Advantage. If no such roll occurs before the end of the turn, the Advantage is lost.",
            "duration": "",
            "limit": "Requires Origin Bell Tone; Bonus Action; benefit expires end of current turn.",
            "counterplay": "Force the cultivator to spend early, disengage, or deny qualifying rolls.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined — Body-Dao Root",
            "stage": "Refined",
            "type": "Passive / Rider",
            "trigger": "This Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When Refined, the hit point maximum increase from Sacred-Dao Embryo Frame becomes three times your Proficiency Bonus. The Frame's Advantage also applies to Constitution saving throws or cultivation checks made to maintain Concentration or an ongoing legal technique when the disruption is caused by hostile body-control, formation pressure, gravity pressure, fate pressure, spatial displacement, or comparable authority suppression. This modifies the passive chassis and does not require an action, Reaction, or Origin Bell Tone.",
            "duration": "",
            "limit": "Refined stage only; no resource generated.",
            "counterplay": "Use ordinary damage, non-eligible disruptions, or higher authority.",
            "source_spheres": [
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Gravity",
              "Space",
              "Stars"
            ]
          },
          {
            "name": "Refined — Origin Bell Resonance",
            "stage": "Refined",
            "type": "Passive / Rider",
            "trigger": "You spend Origin Bell Tone on No-Beginning Guard, Sacred-Dao Strike, or Origin Bell Surge.",
            "cost": "No additional cost",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you spend Origin Bell Tone on No-Beginning Guard, Sacred-Dao Strike, or Origin Bell Surge, add your Proficiency Bonus to one numeric value of that spend. This modifies the base spend. It does not require an additional action, Reaction, or resource, and it does not permit same-event spending.",
            "duration": "",
            "limit": "Once per Origin Bell Tone spend; no extra cost.",
            "counterplay": "Drain the Tone, bait the spend, or force non-eligible triggers.",
            "source_spheres": [
              "Qiweaving",
              "Protection",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected — No-Beginning Origin Court",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You open the Perfected Foundation's scene-scale body-Dao court.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot emanation",
            "target": "Self and allies in the emanation",
            "attack_or_save": "",
            "effect": "Once per long rest, as a Bonus Action, open the No-Beginning Origin Court for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. While the court lasts, your qualifying Foundation-aligned close/body-bound and Dao-authority hits deal additional damage equal to your Proficiency Bonus. You and allies of your choice in the 30-foot emanation have Advantage on Strength and Constitution checks and saving throws against forced movement, being knocked Prone, Grappled, Restrained, body-suppression pressure, formation pressure, gravity pressure, fate pressure, spatial displacement, and comparable authority suppression. Origin Bell Tone maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest; 1 minute; Origin Bell Tone cap remains 1.",
            "counterplay": "Dispel or suppress the court with higher authority, fight at range, use non-eligible pressure, or exhaust the duration.",
            "source_spheres": [
              "Athletics",
              "Brute",
              "Force",
              "Gravity",
              "Protection",
              "Qiweaving",
              "Fate",
              "Karma",
              "Formations",
              "Space",
              "Stars",
              "Spirit Companions"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Athletics",
          "Brute",
          "Force",
          "Gravity",
          "Protection",
          "Qiweaving",
          "Fate",
          "Karma",
          "Formations",
          "Space",
          "Stars",
          "Spirit Companions"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_FOUNDATION_INNATE_SACRED_BODY_DAO_EMBRYO_HEAVEN_LISTENS",
            "name": "Burden — Heaven Listens for the First Bell",
            "effect_text": "Advancing this Foundation draws severe scrutiny from formations, sects, heavenly pressure, and enemies who fear a body that can align with Dao authority. Refined and Perfected advancement should require rare materials, hostile-pressure proof, teacher/scripture support, and dangerous tribulation scenes.",
            "mechanical_note": "This burden does not add a combat tracker. It increases advancement difficulty, repair difficulty, institutional attention, and tribulation severity."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_GREAT_DAO_SCAR",
            "name": "Great Dao Scar",
            "effect_text": "A failed advancement can scar the connection between body and Dao. The cultivator may gain pain, delayed technique ignition, or disadvantage on future breakthrough preparation until repaired.",
            "repair_hint": "Return-to-Origin Meditation or Jade Body Fast can diagnose or reduce this injury."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_HEAVEN_PRESSED_MERIDIAN",
            "name": "Heaven-Pressed Meridian Strain",
            "effect_text": "Excessive suppression resistance makes the meridians ring under ordinary pressure. Treat as a downtime/tribulation strain, not a round-by-round combat penalty unless a scene calls for it."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_NO_BEGINNING_PRIDE",
            "name": "No-Beginning Pride",
            "effect_text": "The cultivator begins believing all roads should start from them. Teachers, allies, and alternate methods feel like lesser echoes."
          },
          {
            "id": "DEVIATION_BODY_DAO_SPLIT",
            "name": "Body-Dao Split",
            "effect_text": "The sacred body wants to dominate while the Dao embryo wants to listen. Techniques become forceful but less wise, and breakthrough scenes test whether power and alignment still share one root."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair Practice — Jade Body Fast",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You spend downtime fasting, breath-regulating, and refusing reckless authority contests.",
          "cost": "Downtime, teacher, body-tempering medicine, or shrine/formation support",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A repair practice using fasting, breath regulation, medicine baths, and refusal of pointless domination contests to reduce Heaven-Pressed Meridian Strain or diagnose Great Dao Scar. It cannot advance the Foundation by itself.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Alchemy",
            "Life",
            "Protection",
            "Qiweaving"
          ]
        },
        {
          "name": "Repair Practice — Return-to-Origin Meditation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You sit in a controlled formation or under a teacher while body and Dao pressure are harmonized.",
          "cost": "Downtime, safe formation, teacher, or rare meditation site",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A repair practice that tests whether body strength and Dao affinity are pulling in different directions. On success, it can reduce a future breakthrough penalty or identify the next required material or challenge.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Formations",
            "Qiweaving",
            "Fate",
            "Karma",
            "Stars"
          ]
        },
        {
          "name": "Repair Practice — Bell Without Echo",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "You practice silent authority without forcing the world to answer.",
          "cost": "Downtime and restraint",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "A repair practice focused on acting without demanding recognition. It reduces deviation pressure when the cultivator has begun treating their Foundation as proof that all roads begin with them.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Karma",
            "Protection",
            "Spirit Companions"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Foundation Challenge — Move First Without Dominating",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A breakthrough asks whether the cultivator can act first without crushing every lesser road.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator must take decisive action while preserving another person's path, formation, or choice. This proves that body-Dao alignment is not merely domination.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Karma",
            "Protection",
            "Fate"
          ]
        },
        {
          "name": "Foundation Challenge — Hold Body While Dao Turns",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A formation, fate pressure, or gravity/spatial trial tries to make the body and Dao disagree.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator must withstand hostile pressure that attacks the body and the Dao in different ways without splitting, freezing, or lashing out blindly.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Force",
            "Gravity",
            "Formations",
            "Space",
            "Stars"
          ]
        },
        {
          "name": "Foundation Challenge — Accept a Later Beginning",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "The cultivator must learn from someone weaker, younger, or lower-status.",
          "cost": "Story challenge",
          "range": "Scene",
          "target": "Self",
          "attack_or_save": "",
          "effect": "The cultivator must accept instruction, correction, or rescue from an unexpected source. Refusal risks No-Beginning Pride Deviation.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires GM-approved scene pressure.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Spirit Companions"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage — No-Beginning Bell Fragment",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A bell-fragment, scripture echo, or ancient teacher reveals a route for body-Dao alignment.",
          "cost": "Lineage access, teacher, relic, or scripture",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "This lineage support explains how the Foundation can advance toward No-Beginning Origin Court. It does not grant combat benefits unless a separate combat row is written.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires authentic lineage proof and attracts major institutional interest.",
          "source_spheres": [
            "Stars",
            "Space",
            "Fate",
            "Karma",
            "Qiweaving"
          ]
        },
        {
          "name": "Lineage — Sacred Body Dao Embryo Treatise",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "A treatise or teacher explains how sacred body power and Dao-embryo affinity can coexist.",
          "cost": "Lineage access, teacher, protected archive, or inherited method",
          "range": "Self",
          "target": "Self",
          "attack_or_save": "",
          "effect": "This lineage action can justify the Refined Body-Dao Root or Perfected No-Beginning Origin Court route. It stays out of GM Screen combat rows.",
          "duration": "",
          "limit": "GM-controlled downtime or challenge scene.",
          "counterplay": "Requires rare teachers and severe breakthrough scrutiny.",
          "source_spheres": [
            "Athletics",
            "Protection",
            "Qiweaving",
            "Formations",
            "Stars"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "white_crane_cloud_step_v0_2B",
      "name": "White Crane Cloud-Step",
      "number": 14,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation through Air/lightness methods",
          "Spirit Awakening through crane-spirit or cloud-step resonance"
        ],
        "typical_role": "Mobility",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Mobile evasion Foundation that gives clean speed, footwork, and missed-attack identity without creating a movement subsystem.",
        "visible_sign": "",
        "warning": "If your Speed is 0 or you are Grappled, Restrained, or Prone at the end of your turn, you cannot generate Crane Breath until that condition or Speed restriction ends.",
        "dao_principle": "Move toward the Dao without fleeing from pain."
      },
      "resource": {
        "name": "Crane Breath",
        "maximum": "1",
        "starting": "0",
        "gain": "After you move at least 15 feet on your turn without teleporting or forced movement, after a hostile attack misses you after you moved on your last turn, or after you succeed on a Dexterity/Acrobatics check or save to avoid falling, Prone, Grappled, Restrained, or forced movement.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Pin, restrain, knock prone, use save-based effects, deny open lanes, or force the cultivator to choose between movement and objective.",
        "spends": [
          "Light-Body Recovery",
          "Refined: Open-Cloud Knees",
          "Refined: Wings Remember Ground"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Cloud-Step Crane Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus, and your Speed increases by 5 feet while you are not wearing armor or restraints that prevent light footwork. Air, Athletics, Monkey Style, Flowing River, Qiweaving, Guardian, Protection, Spear, Sword, and Spirit Companions methods that express lightness, crane-step breath, evasive body rhythm, falling control, or mobile guard work may count as Foundation-aligned. You have Advantage on ability checks made to keep balance on narrow, unstable, slippery, or lightly obstructed surfaces. This passive requires no per-round tracking.",
            "duration": "",
            "limit": "Does not grant flight, teleportation, free Disengage, or immunity to Grappled/Restrained/Prone.",
            "counterplay": "Immobilize, restrain, knock prone, use cramped terrain, or punish over-movement.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "White Crane Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports real movement, lightness-body training, cloud-step breath, evasion, falling control, mobile guard work, and precise repositioning. It does not support teleportation, phasing, forced movement, standing still while claiming motion, or abandoning allies and calling it mastery.",
            "duration": "",
            "limit": "Scope only; grants no free Hide, Disengage, flight, or teleportation.",
            "counterplay": "Deny open space or force objectives that cannot be solved by retreat.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "Generate Crane Breath",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you move at least 15 feet on your turn without teleporting or forced movement, after a hostile attack misses you after you moved on your last turn, or after you succeed on a Dexterity/Acrobatics check or save to avoid falling, Prone, Grappled, Restrained, or forced movement.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "If you do not already have Crane Breath, gain Crane Breath 1/1 after the qualifying event resolves. It expires at the end of your next turn and cannot be spent on the event that generated it.",
            "duration": "",
            "limit": "Maximum 1; once per round; no generation from teleportation, forced movement, staged misses, friendly attacks, or harmless movement loops.",
            "counterplay": "Pin, restrain, knock prone, use save-based effects, deny open lanes, or force the cultivator to choose between movement and objective.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "Cloud-Step Deflection",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "A hostile attack would hit you while you are not Grappled, Restrained, Prone, or at Speed 0.",
            "cost": "1 Crane Breath",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Increase your AC against the triggering attack by your Proficiency Bonus + your Path key ability modifier. If this changes the hit into a miss, you may move up to 10 feet without provoking Opportunity Attacks from the attacker.",
            "duration": "",
            "limit": "Does not work while Grappled, Restrained, Prone, or Speed 0; movement cannot pass through barriers.",
            "counterplay": "Use saves, restrain first, attack before the cultivator has Breath, or control space.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "Crane-Wing Cut",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you move at least 10 feet on your turn and hit a hostile creature with a Foundation-aligned melee, thrown, Air, spear, sword, or body-bound attack.",
            "cost": "1 Crane Breath",
            "range": "Self / triggering target",
            "target": "One creature you hit",
            "attack_or_save": "",
            "effect": "Add your Proficiency Bonus + your Path key ability modifier to the triggering damage. You may then move 5 feet without provoking Opportunity Attacks from the target you hit.",
            "duration": "",
            "limit": "Requires real movement before the hit; no teleport/forced movement; movement must be legal.",
            "counterplay": "Restrict movement, force tight terrain, or hold reactions for later threats.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "Light-Body Recovery",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while conscious.",
            "cost": "1 Crane Breath",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. If you are Prone and your Speed is not 0, you may stand as part of this Bonus Action without spending extra movement.",
            "duration": "",
            "limit": "Cannot stand if Speed is 0; does not end Grappled or Restrained by itself.",
            "counterplay": "Set Speed to 0, restrain, grapple, or force the cultivator to spend Breath defensively.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Open-Cloud Knees",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined Foundation active.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your Cloud-Step Crane Vessel HP bonus becomes 2×PB, and its Speed bonus becomes +10 feet. This modifies the passive chassis and does not require an action, Reaction, or Crane Breath spend.",
            "duration": "",
            "limit": "Still no flight or teleportation.",
            "counterplay": "Immobilization and cramped terrain remain effective.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          },
          {
            "name": "Refined: Wings Remember Ground",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Crane Breath.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you spend Crane Breath, add +PB to one numeric value of that spend. This modifies the base spend, requires no extra action or resource, and does not permit same-event spending.",
            "duration": "",
            "limit": "One numeric value only; no extra spend or reaction.",
            "counterplay": "Force the resource out before key moments.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Cloud-Crane Crossing",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while conscious.",
            "cost": "Once per long rest",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "For 1 minute, gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. Your Speed increases by 10 feet, and opportunity attacks against you have Disadvantage if you moved at least 10 feet on your turn before provoking them. Once on each of your turns, when you hit with a qualifying mobile Foundation-aligned attack after moving at least 10 feet, add +PB damage. Crane Breath maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest; no flight or teleportation; Breath cap remains 1.",
            "counterplay": "Immobilize, restrain, deny movement lanes, use saving throws or area effects.",
            "source_spheres": [
              "Air",
              "Athletics",
              "Monkey Style",
              "Flowing River",
              "Qiweaving",
              "Guardian",
              "Protection",
              "Spear",
              "Sword",
              "Spirit Companions"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Air",
          "Athletics",
          "Monkey Style",
          "Flowing River",
          "Qiweaving",
          "Guardian",
          "Protection",
          "Spear",
          "Sword",
          "Spirit Companions"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Wings Need Open Air",
            "effect": "If your Speed is 0 or you are Grappled, Restrained, or Prone at the end of your turn, you cannot generate Crane Breath until that condition or Speed restriction ends."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Scattered Breath Hidden Injury",
            "effect": "Step and breath desynchronize; the cultivator may lose Crane Breath generation from movement until they repair their rhythm."
          }
        ],
        "strains": [
          {
            "name": "Hollow Knee Meridian",
            "effect": "The body becomes too light and loses stable recovery after failed advancement or overuse of cloud-step methods."
          }
        ],
        "deviations": [
          {
            "name": "Broken Wing Deviation",
            "effect": "The cultivator treats contact, stillness, or being pinned as personal defeat."
          },
          {
            "name": "Restless Cloud Deviation",
            "effect": "The cultivator cannot remain still, guard, meditate, or listen when motion would be inappropriate."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Breath-Step Resynchronization",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Practice slow crane-step breathing until footfall and exhale return to one rhythm.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        },
        {
          "name": "Repair: Weighted Cloud-Sand Walk",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Train on weighted sand, snow, or cloud-silk terrain to restore grounded lightness.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        },
        {
          "name": "Repair: Still-Perch Meditation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Remain balanced and unmoving under pressure without fleeing into motion.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: Cross the Broken Bridge",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Cross unstable ground while protecting another creature, not merely escaping alone.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        },
        {
          "name": "Challenge: Move Toward the Dao",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Advance into danger with correct footwork rather than retreating from pain.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        },
        {
          "name": "Challenge: The Crane Must Land",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Accept a moment of stillness without treating it as defeat.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: White Crane Cloud-Step Manual",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A lineage manual teaches how breath, knee, and sleeve become one cloud-step rhythm.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        },
        {
          "name": "Lineage: Open-Air Crane Teacher",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher corrects the difference between true lightness and fleeing contact.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Air",
            "Athletics",
            "Monkey Style",
            "Flowing River",
            "Qiweaving",
            "Guardian",
            "Protection",
            "Spear",
            "Sword",
            "Spirit Companions"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "true_blackblood_physique_v0_2C",
      "name": "True Blackblood Physique",
      "number": 15,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Unstable or Integrated",
        "primary_path": "Body Refining or Qi Cultivation",
        "secondary_path_fit": "Blood, Yin, Dark, Poison, Life, Hunger, Daemonic Cultivation",
        "typical_role": "Striker / Defender",
        "complexity": "Low"
      },
      "overview": {
        "summary": "Your blood, skin, or meridians carry a dark density that orthodox physicians may misread as impurity. Once damaged deeply enough, the blood gathers pressure and can harden, refuse intrusion, or return force.",
        "visible_sign": "Wounds may bead dark blood; purification incense may sting; dense medicine may feel nourishing. When Bloodied, your aura becomes heavier rather than weaker.",
        "warning": "Orthodox purity treatments, forced blood rejection, shame toward the body, and treating the blackblood as filth can suppress the engine.",
        "dao_principle": "What was meant to halt me becomes mine when I refuse the shame attached to it."
      },
      "resource": {
        "name": "Blackblood Pressure",
        "maximum": "1",
        "starting": "0",
        "gain": "After you take damage from a hostile attack or technique while Bloodied and remain conscious, once per round.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round. Requires actual damage from a hostile attack or technique, you are Bloodied after the damage resolves, and you remain conscious.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Keep the cultivator above Bloodied before committing, disable or control instead of damaging, burst through the held Pressure window, or suppress the Foundation.",
        "spends": [
          "Blackblood Guard",
          "Blackblood Refusal",
          "Blackblood Return"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Generate Blackblood Pressure",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you take damage from a hostile attack or technique while Bloodied and remain conscious, once per round.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering damage resolves, gain 1 Blackblood Pressure, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same damage event that generated it.",
            "duration": "Instant",
            "limit": "Once per round. Requires actual damage from a hostile attack or technique, you are Bloodied after the damage resolves, and you remain conscious.",
            "counterplay": "Keep the cultivator above Bloodied before committing, disable or control instead of damaging, burst through the held Pressure window, or suppress the Foundation.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          },
          {
            "name": "Blackblood Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take damage and already have Blackblood Pressure.",
            "cost": "Spend 1 Blackblood Pressure",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: reduce the damage by PB + cultivation ability modifier. Evolution rows below can add to this same reduction and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Blackblood Pressure. Cannot reduce the same damage event that generated the Pressure.",
            "counterplay": "Force the cultivator to spend Pressure on smaller hits, use control instead of damage, or attack while Pressure is absent.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          },
          {
            "name": "Blackblood Refusal",
            "stage": "Awakened",
            "type": "No Action / Post-Roll Modifier",
            "trigger": "After you roll a Constitution save or a save/check against blood loss, poison, disease, corruption, forced body alteration, or internal-body disruption while holding Blackblood Pressure.",
            "cost": "Spend 1 Blackblood Pressure",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: add PB to the triggering roll after rolling but before the outcome. Evolution rows below can add to this same bonus and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Blackblood Pressure and a roll inside the fixed Blackblood scope.",
            "counterplay": "Draw out the Pressure before forcing the save, use threats outside the Blackblood scope, or suppress the Foundation.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          },
          {
            "name": "Blackblood Return",
            "stage": "Awakened",
            "type": "No Action / Damage Rider",
            "trigger": "When you hit with an attack or compatible Blood, Yin, Dark, Poison, Life-root, Hunger, or body technique while holding Blackblood Pressure.",
            "cost": "Spend 1 Blackblood Pressure",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: add PB damage to the hit. Evolution rows below can add to this same damage and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Blackblood Pressure and a hit before the Pressure expires.",
            "counterplay": "Kite, impose disadvantage, reduce accuracy, or force the cultivator to spend Pressure defensively.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Clotted Iron Blood",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Blackblood Pressure on Blackblood Guard and have selected this Refined expression.",
            "cost": "No additional action or resource; modifies Blackblood Guard when this Refined expression is selected.",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution rider: when Blackblood Guard resolves, reduce damage by an additional PB. This stacks with the base Guard reduction and does not require a second Reaction.",
            "duration": "Instant",
            "limit": "Requires Refined expression selection and a legal Blackblood Guard use. Does not require a second Reaction.",
            "counterplay": "Same as Blackblood Guard; suppress the Refined expression, exhaust Pressure before the heavy hit, or avoid damage-based exchanges.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          },
          {
            "name": "Refined: Venom-Dark Marrow",
            "stage": "Refined",
            "type": "Post-Roll Evolution",
            "trigger": "When you spend Blackblood Pressure on Blackblood Refusal and have selected this Refined expression.",
            "cost": "No extra cost beyond Blackblood Refusal",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Blackblood Refusal adds an additional PB to the same roll. This stacks with the base Refusal bonus.",
            "duration": "Instant",
            "limit": "Requires Refined expression selection; modifies Blackblood Refusal only.",
            "counterplay": "Same as Blackblood Refusal; force non-scoped saves or remove Pressure first.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          },
          {
            "name": "Refined: Hidden Vitality Return",
            "stage": "Refined",
            "type": "Damage Evolution",
            "trigger": "When you spend Blackblood Pressure on Blackblood Return and have selected this Refined expression.",
            "cost": "No extra cost beyond Blackblood Return",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Blackblood Return adds an additional PB damage to the same hit. This stacks with the base Return damage.",
            "duration": "Instant",
            "limit": "Requires Refined expression selection; modifies Blackblood Return only.",
            "counterplay": "Same as Blackblood Return; deny hits or force defensive spending.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Self-Owned Impurity",
            "stage": "Perfected",
            "type": "Perfected Evolution",
            "trigger": "Once per round, when you spend Blackblood Pressure on Guard, Refusal, or Return and are Bloodied.",
            "cost": "No extra cost beyond the Pressure spend",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Perfected evolution: increase that conversion’s numeric benefit by PB. This stacks with the base conversion and with your selected Refined expression.",
            "duration": "Instant",
            "limit": "Once per round. Requires Perfected stage, Bloodied state, and a legal Blackblood Pressure spend.",
            "counterplay": "Keep the cultivator above Bloodied, suppress the Foundation, force Pressure spending before the key moment, or use non-numeric effects.",
            "source_spheres": [
              "Blood",
              "Yin",
              "Dark",
              "Poison",
              "Life",
              "Hunger"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Blood",
          "Yin",
          "Dark",
          "Poison",
          "Life",
          "Hunger"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [
        {
          "name": "Blackblood Structure Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime/Foundation repair scene",
          "cost": "Scene time and compatible correction source",
          "range": "Narrative / Scene",
          "target": "Self or patient",
          "attack_or_save": "",
          "effect": "Downtime repair: diagnose blackblood as structure rather than impurity. Success adds 1 repair progress toward Blackblood Drag, Blood Stagnation, or Blood Rejection.",
          "duration": "Scene",
          "limit": "Downtime/Foundation repair only; not a normal combat action.",
          "counterplay": "Requires honest diagnosis, compatible correction source, and access to method, teacher, medicine, rite, or site.",
          "source_spheres": [
            "Blood",
            "Life",
            "Yin",
            "Alchemy",
            "Qiweaving",
            "Poison"
          ]
        },
        {
          "name": "Dark-Blood Method Correction",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Downtime/Foundation repair scene",
          "cost": "Scene time and compatible correction source",
          "range": "Narrative / Scene",
          "target": "Self or patient",
          "attack_or_save": "",
          "effect": "Downtime repair: use Blood/Life/Yin/Alchemy/Qiweaving/Poison support or teacher correction to align the blackblood with a disciplined Method. Success adds 1 repair progress.",
          "duration": "Scene",
          "limit": "Downtime/Foundation repair only; not a normal combat action.",
          "counterplay": "Requires honest diagnosis, compatible correction source, and access to method, teacher, medicine, rite, or site.",
          "source_spheres": [
            "Blood",
            "Life",
            "Yin",
            "Alchemy",
            "Qiweaving",
            "Poison"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Own the Impurity",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Valid True Blackblood Foundation Challenge scene",
          "cost": "Scene time, compatible Method, and challenge conditions",
          "range": "Narrative / Scene",
          "target": "Self/Foundation",
          "attack_or_save": "Cultivation Check",
          "effect": "Foundation Challenge: prove the blackblood is structure, not filth. DC = 12 + 2 x target depth rating + active Blackblood Drag or Blood Stagnation Severity. Progress = 3 x target depth rating. Success may Integrate, Deepen, Redirect, or Transmute the Foundation according to the route chosen.",
          "duration": "Challenge scene",
          "limit": "Foundation Challenge only; not a normal combat action.",
          "counterplay": "Requires challenge access, compatible Method correction, and a scene that addresses shame/purity contradiction.",
          "source_spheres": [
            "Blood",
            "Yin",
            "Dark",
            "Poison",
            "Life",
            "Hunger"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Blackblood Diagnosis Manual",
          "stage": "Awakened",
          "type": "Downtime / Lineage Scene",
          "trigger": "Lineage-Bearing stage and a compatible learner, institution, family, manual, or diagnostic route",
          "cost": "Downtime and teacher access",
          "range": "Narrative / Lineage",
          "target": "Compatible learner, patient, manual, sect, or family route",
          "attack_or_save": "",
          "effect": "Downtime lineage utility: create or teach a diagnostic method that helps distinguish deviant structure from harmful impurity. Grants teacher-supported interface for a future Blackblood-scoped diagnosis/treatment scene; not a full Foundation copy.",
          "duration": "Lineage scene or prepared future Foundation scene",
          "limit": "Downtime/lineage only; not a normal combat action and not a full Foundation copy.",
          "counterplay": "Requires compatible learner or institution, honest Method, teacher access, and social/medical acceptance of the deviant body route.",
          "source_spheres": [
            "Blood",
            "Life",
            "Yin",
            "Alchemy",
            "Qiweaving",
            "Poison"
          ]
        },
        {
          "name": "Lesser Blackblood Spark",
          "stage": "Awakened",
          "type": "Downtime / Lineage Scene",
          "trigger": "Lineage-Bearing stage and a compatible learner, institution, family, manual, or diagnostic route",
          "cost": "Downtime and teacher access",
          "range": "Narrative / Lineage",
          "target": "Compatible learner, patient, manual, sect, or family route",
          "attack_or_save": "",
          "effect": "Downtime lineage utility: pass a controlled lesser trace, rite, or medicine route to a compatible learner. This may justify a weak blood-density Foundation seed; it does not duplicate True Blackblood Physique.",
          "duration": "Lineage scene or prepared future Foundation scene",
          "limit": "Downtime/lineage only; not a normal combat action and not a full Foundation copy.",
          "counterplay": "Requires compatible learner or institution, honest Method, teacher access, and social/medical acceptance of the deviant body route.",
          "source_spheres": [
            "Blood",
            "Life",
            "Yin",
            "Alchemy",
            "Qiweaving",
            "Poison"
          ]
        },
        {
          "name": "Deviant Body Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Lineage Scene",
          "trigger": "Lineage-Bearing stage and a compatible learner, institution, family, manual, or diagnostic route",
          "cost": "Downtime and teacher access",
          "range": "Narrative / Lineage",
          "target": "Compatible learner, patient, manual, sect, or family route",
          "attack_or_save": "",
          "effect": "Downtime lineage utility: formalize the Foundation as family, sect, or manual inheritance. Enables future learners to seek related Foundation Challenges with teacher access; not a combat action.",
          "duration": "Lineage scene or prepared future Foundation scene",
          "limit": "Downtime/lineage only; not a normal combat action and not a full Foundation copy.",
          "counterplay": "Requires compatible learner or institution, honest Method, teacher access, and social/medical acceptance of the deviant body route.",
          "source_spheres": [
            "Blood",
            "Life",
            "Yin",
            "Alchemy",
            "Qiweaving",
            "Poison"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "golden_mandate_seal_v0_2B",
      "name": "Golden Mandate Seal",
      "number": 16,
      "profile": {
        "grade": "Rare",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening through vow, court, and authority resonance",
          "Body Refining through banner-bearing or command-body lineages"
        ],
        "typical_role": "Controller",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Command-authority and control Foundation that builds pressure through visible seal authority without creating a law subsystem.",
        "visible_sign": "",
        "warning": "If you cannot speak, gesture, display a seal, raise a banner, reveal a writ, mark a formation, or otherwise make cultivated authority perceptible, you cannot generate or spend Edict Seal.",
        "dao_principle": "Command must protect order, not merely the one who stands above others."
      },
      "resource": {
        "name": "Edict Seal",
        "maximum": "1",
        "starting": "0",
        "gain": "After a hostile creature fails a saving throw against your visible Foundation-aligned command, seal, talisman, formation, karma, fate, protection, or authority technique, or after you maintain perceptible authority through a hostile attempt to silence, shame, frighten, charm, or suppress your command.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Silence, restrain gestures, hide the seal, deny witnesses, break concentration, or attack legitimacy.",
        "spends": [
          "Refined: Edict Bites Deeper"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Golden Mandate Vessel",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum Hit Points increase by your Proficiency Bonus. Karma, Fate, Talismans, Formations, Radiance, Protection, Warleader, Qiweaving, The Hidden Eye, and Sect Stewardship methods that express visible command, seal-script, lawful order, protective edict, judgment, or authority pressure may count as Foundation-aligned. You have Advantage on saving throws against being Frightened, Charmed, silenced by hostile command, magically compelled to kneel, or spiritually shamed by false authority. This passive requires no per-round tracking.",
            "duration": "",
            "limit": "Does not grant social rank, legal immunity, free command effects, or authority when all expression is blocked.",
            "counterplay": "Question legitimacy, silence the voice, bind the hands, hide the seal, or use authority the cultivator cannot answer.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Golden Mandate Scope",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active as a legality and expression guide.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports visible command, seal-script, formal judgment, protective writs, formation authority, talisman edicts, karmic accounting, and order that protects others. It does not support hidden mind control, private entitlement, ordinary social rank, intimidation without cultivated authority, or commands issued only to feed the resource.",
            "duration": "",
            "limit": "Scope only; does not grant new spell effects or social office.",
            "counterplay": "Remove witnesses, hide the seal, prove hypocrisy, or force the cultivator to answer their own edict.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Generate Edict Seal",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a hostile creature fails a saving throw against your visible Foundation-aligned command, seal, talisman, formation, karma, fate, protection, or authority technique, or after you maintain perceptible authority through a hostile attempt to silence, shame, frighten, charm, or suppress your command.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "If you do not already have Edict Seal, gain Edict Seal 1/1 after the qualifying event resolves. It expires at the end of your next turn and cannot be spent on the event that generated it.",
            "duration": "",
            "limit": "Maximum 1; once per round; no generation if your authority is not perceptible through speech, gesture, seal, banner, writ, talisman, formation mark, or comparable display.",
            "counterplay": "Silence, restrain gestures, hide the seal, deny witnesses, break concentration, or attack legitimacy.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Seal of Final Authority",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "A hostile creature you can perceive within 60 feet succeeds on a saving throw against your visible Foundation-aligned command, seal, talisman, formation, karma, fate, protection, or authority technique.",
            "cost": "1 Edict Seal",
            "range": "60 feet",
            "target": "One triggering hostile creature",
            "attack_or_save": "Target already rolled a saving throw",
            "effect": "Subtract your Proficiency Bonus + your Path key ability modifier from the triggering saving throw. If this changes the success into a failure, the creature cannot take Reactions until the start of its next turn.",
            "duration": "",
            "limit": "Requires perceptible authority; cannot affect Legendary/Secret/higher-authority effects unless the GM permits a contest.",
            "counterplay": "Silence or obscure authority before the save, bait the Reaction, or use higher authority.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Golden Writ Rebuke",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature or it fails a save against your Foundation-aligned command, seal, talisman, formation, karma, fate, protection, or authority technique.",
            "cost": "1 Edict Seal",
            "range": "Self / triggering target",
            "target": "One hostile creature affected by the triggering technique",
            "attack_or_save": "",
            "effect": "Add your Proficiency Bonus + your Path key ability modifier as radiant, force, or psychic damage, matching the technique. The target cannot take Reactions against you until the start of its next turn.",
            "duration": "",
            "limit": "Requires a real qualifying technique; does not convert ordinary insults or rank into damage.",
            "counterplay": "Avoid visible mandate techniques, force the cultivator to spend defensively, or contest legitimacy.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Golden Seal Bearing",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while your authority can be made perceptible.",
            "cost": "1 Edict Seal",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, you have Advantage on saving throws against being Frightened, Charmed, silenced by hostile command, or spiritually shamed by false authority.",
            "duration": "",
            "limit": "Does not override physical silence, restraints, or lack of perceptible authority.",
            "counterplay": "Bind, silence, obscure, or force the cultivator into illegitimate orders.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Imperial Writ Meridians",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined Foundation active.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your Golden Mandate Vessel HP bonus becomes 2×PB. Your passive Advantage also applies against hostile effects that attempt to make you violate a sworn order, abandon a protected charge, or obey a false superior authority. This modifies the passive chassis and requires no action or resource.",
            "duration": "",
            "limit": "Does not make all commands lawful or true.",
            "counterplay": "Expose hypocrisy, break the protected order, or use superior authority.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          },
          {
            "name": "Refined: Edict Bites Deeper",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Edict Seal.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you spend Edict Seal, add +PB to one numeric value of that spend. This modifies the base spend, requires no extra action, Reaction, or resource, and does not permit same-event spending.",
            "duration": "",
            "limit": "One numeric value only; no duplicate Reaction.",
            "counterplay": "Bait the spend or remove perceptible authority.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Golden Mandate Court",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while your authority is perceptible.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot emanation",
            "target": "Self and chosen creatures in the court",
            "attack_or_save": "",
            "effect": "For 1 minute, establish a 30-foot Golden Mandate Court. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. Chosen allies in the court have Advantage on saving throws against fear, charm, false authority, compulsion to kneel, and hostile command pressure. Once on each of your turns, when a hostile creature is hit by or fails a save against your visible Foundation-aligned authority technique inside the court, add +PB damage or prevent that creature from taking Reactions against one chosen ally until the start of its next turn. Edict Seal maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest; authority must remain perceptible; Edict Seal cap remains 1.",
            "counterplay": "Break visibility, silence/obscure the mandate, leave the court, contest legitimacy, or invoke higher authority.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Talismans",
              "Formations",
              "Radiance",
              "Protection",
              "Warleader",
              "Qiweaving",
              "The Hidden Eye",
              "Sect Stewardship"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Karma",
          "Fate",
          "Talismans",
          "Formations",
          "Radiance",
          "Protection",
          "Warleader",
          "Qiweaving",
          "The Hidden Eye",
          "Sect Stewardship"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "The Seal Requires Witness",
            "effect": "If you cannot speak, gesture, display a seal, raise a banner, reveal a writ, mark a formation, or otherwise make cultivated authority perceptible, you cannot generate or spend Edict Seal."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Cracked Seal Hidden Injury",
            "effect": "Voice, gesture, seal, or banner leaks force; visible mandate techniques may become easier to resist until repaired."
          }
        ],
        "strains": [
          {
            "name": "Backlash Writ Meridian",
            "effect": "Failed command rebounds as pain, shame, or trembling authority meridians after advancement pressure."
          }
        ],
        "deviations": [
          {
            "name": "Tyrant’s Mandate Deviation",
            "effect": "Obedience becomes the cultivator’s only proof of righteousness."
          },
          {
            "name": "Empty Title Deviation",
            "effect": "Rank and display remain after legitimacy is gone."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair: Seal Reinscription Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Reinscribe the mandate seal while naming who the order protects.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        },
        {
          "name": "Repair: Public Accountability Bow",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Accept correction from a lawful witness, protected charge, or wronged subordinate.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        },
        {
          "name": "Repair: Voice and Gesture Realignment",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Retrain voice, hand, banner, and meridian force until command no longer leaks.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge: The Edict Answers Itself",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Issue a command that binds the cultivator as much as the target.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        },
        {
          "name": "Challenge: Protect Order, Not Pride",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Choose a protective order over personal status or revenge.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        },
        {
          "name": "Challenge: Judgment Under Witness",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "Render judgment while true witnesses can contest it.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage: Golden Mandate Seal Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A formal seal scripture teaches how command, law, and meridian pressure become one visible writ.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        },
        {
          "name": "Lineage: Court-Audit Teacher",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During a suitable downtime, repair, breakthrough, lineage, or Foundation challenge scene.",
          "cost": "None unless the GM assigns scene materials, teacher access, risk, time, or CXP cost.",
          "range": "Self or scene-defined",
          "target": "Self or one training context",
          "attack_or_save": "",
          "effect": "A teacher tests whether the cultivator commands from legitimacy or hunger for obedience.",
          "duration": "",
          "limit": "GM adjudicated; not a combat action by default.",
          "counterplay": "Requires appropriate fiction, teacher/manual/material support, and cannot be used as a hidden combat action.",
          "source_spheres": [
            "Karma",
            "Fate",
            "Talismans",
            "Formations",
            "Radiance",
            "Protection",
            "Warleader",
            "Qiweaving",
            "The Hidden Eye",
            "Sect Stewardship"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "sword_bones_v0_2B",
      "name": "Sword Bones",
      "number": 17,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining or Qi Cultivation",
        "secondary_path_fit": "Sword, Metal, Weapons, Pressure Points",
        "typical_role": "Striker / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your posture, bones, and meridians feel like a sheathed weapon. Clean martial contact gathers a brief edge that can become a cut, guard, or moment of clarity.",
        "visible_sign": "Bones ache near drawn blades; joints settle into sword forms; blunt indecision feels uncomfortable. When the Foundation stirs, the body becomes quieter before it becomes sharper.",
        "warning": "Cutting is not always wisdom. Refusing to bend, spare, sheath, or listen can make this Foundation brittle.",
        "dao_principle": "The body knows what must be severed before the blade is drawn."
      },
      "resource": {
        "name": "Severance Edge",
        "maximum": "1",
        "starting": "0",
        "gain": "After you hit with a weapon attack or cutting technique, once per round.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round. Requires an actual hit with a weapon attack or cutting technique.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny clean hits, force ranged/control exchanges, bait the Edge before the real threat, or suppress the Foundation.",
        "spends": [
          "Sword-Bone Cut",
          "Sheath-Bone Guard",
          "Severing Clarity"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Sword-Bone Frame",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: maximum hit points increase by PB. Integrated: maximum hit points increase by another PB, stacking with the base passive.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit. HP increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "counterplay": "Suppress or damage the Foundation through Cutting Obsession, Brittle Sword Bone, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Generate Severance Edge",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit with a weapon attack or cutting technique, once per round.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering hit resolves, gain 1 Severance Edge, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same hit that generated it.",
            "duration": "Instant",
            "limit": "Once per round. Requires an actual hit with a weapon attack or cutting technique.",
            "counterplay": "Deny clean hits, force ranged/control exchanges, bait the Edge before the real threat, or suppress the Foundation.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Sword-Bone Cut",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit with an attack or technique and already have Severance Edge.",
            "cost": "Spend 1 Severance Edge",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: add PB damage to the hit. Evolution rows below can add to this same damage and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Severance Edge. Cannot empower the same hit that generated the Edge.",
            "counterplay": "Attack while Edge is absent, force the cultivator to spend Edge defensively, or use resistance/positioning against the empowered hit.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Sheath-Bone Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take damage and already have Severance Edge.",
            "cost": "Spend 1 Severance Edge",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: reduce the damage by PB + cultivation ability modifier. Evolution rows below can add to this same reduction and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Severance Edge. Cannot reduce the same hit that generated the Edge.",
            "counterplay": "Force the cultivator to spend Edge on smaller hits, control instead of damaging, or attack while Edge is absent.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Severing Clarity",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you roll a Sword Bones Scope check or saving throw and already have Severance Edge.",
            "cost": "Spend 1 Severance Edge",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Check/Save Rider",
            "effect": "Base: add PB to the roll. Sword Bones Scope means weapon/cutting technique execution, disarm or weapon-binding resistance, restraint/prone resistance, bone/marrow treatment, Sword Bones repair, and Sword Bones Foundation Challenge rolls. Evolution rows below can add to this same roll and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Severance Edge and a roll inside Sword Bones Scope. Cannot apply to unrelated social, exploration, or spellcasting rolls.",
            "counterplay": "Pressure the cultivator outside Sword Bones Scope, drain Edge before forcing the roll, or use effects that do not allow a check/save.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Tempered Severance",
            "stage": "Refined",
            "type": "Passive Rider",
            "trigger": "When you use Sword-Bone Cut and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Sword-Bone Cut adds another PB damage. This stacks with the base Cut damage and with Perfected Bone-Deep Severance.",
            "duration": "Instant",
            "limit": "Requires the Tempered Severance Refined expression. Does not create a second damage rider or a second resource spend.",
            "counterplay": "As Sword-Bone Cut; prevent or reduce the empowered hit, or suppress the Foundation.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Refined: Bone-Sheath Guard",
            "stage": "Refined",
            "type": "Passive Rider",
            "trigger": "When you use Sheath-Bone Guard and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Sheath-Bone Guard reduces another PB damage. This stacks with the base Guard reduction and with Perfected Bone-Deep Severance.",
            "duration": "Instant",
            "limit": "Requires the Bone-Sheath Guard Refined expression. Does not create a second Reaction or second resource spend.",
            "counterplay": "As Sheath-Bone Guard; force Edge expenditure, attack without damage, or suppress the Foundation.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          },
          {
            "name": "Refined: Marrow Decision",
            "stage": "Refined",
            "type": "Passive Rider",
            "trigger": "When you use Severing Clarity and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Severing Clarity adds another PB to the same Sword Bones Scope roll. This stacks with the base Clarity bonus and with Perfected Bone-Deep Severance.",
            "duration": "Instant",
            "limit": "Requires the Marrow Decision Refined expression. Does not create a second roll rider or second resource spend.",
            "counterplay": "As Severing Clarity; keep pressure outside Sword Bones Scope or suppress the Foundation.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Bone-Deep Severance",
            "stage": "Perfected",
            "type": "Passive Rider",
            "trigger": "Once per round, when you spend Severance Edge on a legal conversion.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: increase one legal Severance Edge conversion by PB. This stacks with the base conversion and with the selected Refined evolution if it modifies the same conversion.",
            "duration": "Instant",
            "limit": "Once per round. Requires Perfected Sword Bones, a legal Severance Edge spend, and no active suppression.",
            "counterplay": "Bait the once-per-round perfected rider, deny Edge generation, or force expenditure on a lower-value conversion.",
            "source_spheres": [
              "Sword",
              "Metal",
              "Weapons",
              "Spear",
              "Sniper",
              "Pressure Points",
              "Radiance",
              "Fate",
              "Blacksmith",
              "Athletics"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Sword",
          "Metal",
          "Weapons",
          "Spear",
          "Sniper",
          "Pressure Points",
          "Radiance",
          "Fate",
          "Blacksmith",
          "Athletics"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Cutting Obsession",
            "severity_range": "1-3",
            "trigger": "A Sword Bones scene where the cultivator insists on cutting, severing, escalating, or refusing to sheath when discipline, mercy, flexibility, or correction is required.",
            "fixed_ladder": {
              "Severity 1": "Sword Bones Scope treatment, repair, challenge, and Method-correction DCs increase by +2 when the scene requires restraint, sheathing, mercy, or flexibility.",
              "Severity 2": "As Severity 1. Severance Edge cannot be generated during the triggering scene after the cultivator chooses needless severance, attacks a surrendered foe, or refuses a clear chance to sheath.",
              "Severity 3": "Severance Edge generation is suppressed until rest or Foundation correction. Existing Edge can still be spent unless a separate effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies or worsens Brittle Sword Bone, or advances Severed Mercy if the temptation is active."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Brittle Sword Bone",
            "severity_range": "1-4",
            "injured_system": "bones, marrow, weapon meridians, posture channels, and severance intent",
            "default_effect": "Sword Bones Scope DCs increase by +2 × Severity when the roll involves weapon/cutting execution, disarm or weapon-binding resistance, restraint/prone resistance, bone/marrow treatment, Sword Bones repair, or Sword Bones Foundation Challenge.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Unsteady Sheath",
            "severity_range": "1-3",
            "fixed_ladder": {
              "Severity 1": "Severing Clarity cannot be used.",
              "Severity 2": "As Severity 1, and Severance Edge cannot be generated until the end of your next turn after a failed Sword Bones Scope roll by 5 or more.",
              "Severity 3": "As Severity 2, and Severance Edge cannot be spent on Sheath-Bone Guard until restored."
            },
            "restoration": "Restoration scene, compatible training, teacher correction, treatment, apology, vow, or successful Foundation Challenge check."
          }
        ],
        "deviations": [
          {
            "name": "Severed Mercy",
            "severity_range": "1-4",
            "temptation": "Cut away the obstacle, bond, mercy, vow, or hesitation and call the wound clarity.",
            "benefit_options": [
              "Gain 1 Severance Edge after a legal hit even if the once-per-round generation was already used.",
              "Add PB damage to one weapon/cutting hit.",
              "Add PB to one Sword Bones Scope roll.",
              "Suppress Cutting Obsession penalties for the scene."
            ],
            "cost": "Increase Deviation progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "correction": "Refuse the shortcut, spare when cutting would be easy, sheath at cost, repair the severed bond, or integrate severance into a disciplined Method."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Sheathing Discipline",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation correction practice. Use Flowing River, Life, Karma, Water, Music, or Guardian guidance to restore flexibility without dulling the sword-bone structure.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        },
        {
          "name": "Bone-Marrow Tempering",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Treatment practice for Brittle Sword Bone; addresses bone, marrow, meridians, and weapon-binding injury symptoms.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Sword Bones",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Diagnosis, duel instruction, severance wound, or compatible Sword/Metal/Weapons/Weapons training reveals the sheathed-weapon constitution.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        },
        {
          "name": "Integrate Sword Bones",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Complete Method correction, compatible sphere interface, and a story action proving the cultivator can cut, spare, and sheath with discipline.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lesser Edge Spark",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Student or prepared creature",
          "attack_or_save": "",
          "effect": "Lineage support. A disciple may receive a lesser trace that helps weapon-bone diagnosis or first severance training; it does not copy full Sword Bones.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        },
        {
          "name": "Teacher of the Sheathed Weapon",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Student or prepared creature",
          "attack_or_save": "",
          "effect": "Institutional/teacher support. Enables a school, manual, or diagnostic route for disciplined severance without exporting a GM Screen combat row.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate time, teacher/input/method compatibility, and a scene that matches Sword Bones repair, challenge, or lineage practice.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "taiyin_lunar_body_v0_2B",
      "name": "Taiyin Lunar Body",
      "number": 18,
      "profile": {
        "grade": "Rare",
        "status": "Stable",
        "default_stage": "Integrated",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening",
          "Body Refining"
        ],
        "typical_role": "Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your body carries a Taiyin lunar root: cold enough to preserve life, still enough to resist corpse-qi and drain, but dangerous if cultivated as numbness rather than protection.",
        "visible_sign": "",
        "warning": "If the cultivator repeatedly uses Taiyin power only to numb, abandon, or kill rather than preserve, the Foundation begins treating living warmth as contamination.",
        "dao_principle": "The moon preserves what the sun would burn away, but preservation without warmth becomes a tomb."
      },
      "resource": {
        "name": "Lunar Yin Dew",
        "maximum": "1",
        "starting": "0",
        "gain": "After you reduce hostile damage with a qualifying Yin/Ice/Water/Dark/Life/Protection/Qiweaving method, restore or stabilize another creature through cold preservation or moonlit recovery, succeed on an eligible save against cold, life-drain, corpse-qi, fear-through-cold, or hostile stillness, or hit a hostile creature with a qualifying lunar/cold/stilling technique.",
        "timing": "After qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Short-lived Taiyin preservation resource. It cannot be generated from friendly, staged, self-inflicted, harmless, training, or repeated non-threatening events.",
        "spends": [
          "Moon-Cold Guard",
          "Taiyin Stilling Touch",
          "Preserving Moon Breath",
          "Refined — Dew Returns to Source"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Taiyin Meridian Vessel",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your hit point maximum increases by your Proficiency Bonus. Your legal Yin, Ice, Water, Dark, Life, Protection, Spirit Companions, and Qiweaving techniques may count as Foundation-aligned when they clearly express lunar stillness, Taiyin cold, preservation, quiet recovery, night-water, corpse-qi resistance, or moonlit protection. You have Advantage on Constitution and Wisdom saving throws against hostile cold, life-drain, corpse-qi contamination, fear caused by cold/darkness/death pressure, and hostile effects that try to freeze, numb, or spiritually still your body. This grants no sphere access, no automatic immunity, and no once-per-round passive bonus.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use fire/force/physical pressure, non-cold fear, direct weapon damage, social pressure, or higher authority outside the Taiyin scope.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Fixed Scope — Taiyin Preservation",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules interpretation for this Foundation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports legal methods that preserve life through cold, still hostile corruption, resist drain, protect the spirit from corpse-qi or ghost-cold, or express the Dao of Taiyin through quiet endurance. It does not grant broad weather control, free darkness creation, free healing, moon-domain ownership, or permission to treat all Yin/Dark/Death effects as compatible.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Deny Foundation alignment when the effect is ordinary darkness, generic necromancy, unrestricted healing, or unrelated elemental cold.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Generate Lunar Yin Dew",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you reduce hostile damage with a qualifying Yin/Ice/Water/Dark/Life/Protection/Qiweaving method, restore or stabilize another creature through cold preservation or moonlit recovery, succeed on an eligible save against cold, life-drain, corpse-qi, fear-through-cold, or hostile stillness, or hit a hostile creature with a qualifying lunar/cold/stilling technique.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the qualifying event fully resolves, gain 1 Lunar Yin Dew if you are conscious and do not already have Lunar Yin Dew. Lunar Yin Dew has maximum 1, can be generated only once per round, expires at the end of your next turn, and cannot be spent on the same event that generated it. Friendly, staged, self-inflicted, harmless, training, or repeated non-threatening events cannot generate Lunar Yin Dew.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; no same-event spending.",
            "counterplay": "Deny generation from staged exposure, friendly effects, harmless cold, repeated non-threats, or purely cosmetic moonlight.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Moon-Cold Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes hostile damage while you have Lunar Yin Dew.",
            "cost": "1 Lunar Yin Dew",
            "range": "30 feet",
            "target": "Self or one ally",
            "attack_or_save": "",
            "effect": "Spend 1 Lunar Yin Dew as a Reaction when you or an ally within 30 feet takes hostile damage. Reduce that damage by your Proficiency Bonus + your Path key ability modifier. If the triggering source is cold, necrotic, poison, corpse-qi, life-drain, hostile Yin, ghost-cold, or spiritual stillness pressure, increase the reduction by your Proficiency Bonus. This modifies only the triggering damage and does not cleanse major curses, diseases, hidden injuries, or deviations.",
            "duration": "",
            "limit": "Requires Lunar Yin Dew; Reaction; no same-event spend unless explicitly allowed elsewhere.",
            "counterplay": "Use nonlisted damage types, multiple small hits, range pressure, or higher authority.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Taiyin Stilling Touch",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a hostile creature with a Foundation-aligned close, cold, Yin, Water, Dark, or Qiweaving technique while you have Lunar Yin Dew.",
            "cost": "1 Lunar Yin Dew",
            "range": "Same target as triggering hit",
            "target": "One hostile creature hit by the triggering effect",
            "attack_or_save": "",
            "effect": "Spend 1 Lunar Yin Dew after the qualifying hit resolves. Add cold or necrotic damage equal to your Proficiency Bonus + your Path key ability modifier. The target's Speed is reduced by 10 feet until the start of your next turn. This is a stilling rider, not a separate attack, and it does not apply to a hit that generated the same Lunar Yin Dew.",
            "duration": "",
            "limit": "Requires Lunar Yin Dew; no extra action; no same-event spending.",
            "counterplay": "Use cold/necrotic resistance, forced disengagement, teleportation, immunity to speed reduction, or higher authority.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Preserving Moon Breath",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "On your turn while you have Lunar Yin Dew.",
            "cost": "1 Lunar Yin Dew",
            "range": "30 feet",
            "target": "Self or one willing creature",
            "attack_or_save": "",
            "effect": "Spend 1 Lunar Yin Dew as a Bonus Action. You or one willing creature within 30 feet gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, the target has Advantage on the next saving throw it makes against cold, necrotic drain, poison, fear caused by darkness/death/cold, corpse-qi contamination, or hostile stilling pressure.",
            "duration": "",
            "limit": "Requires Lunar Yin Dew; Bonus Action; one target.",
            "counterplay": "Attack with unlisted pressure, strip temp HP, force multiple saves, or delay until the advantage window ends.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined — Moon-Well Root",
            "stage": "Refined",
            "type": "Passive",
            "trigger": "This Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When this Foundation is Refined, the hit point bonus from Taiyin Meridian Vessel becomes twice your Proficiency Bonus. Its Advantage protection also applies to magical sleep, paralysis through cold or spiritual stillness, and hostile anti-healing effects that clearly come from Yin, death, corpse-qi, or drain. This is still not immunity and does not grant sphere access.",
            "duration": "",
            "limit": "Passive rider; no resource, action, or extra Reaction.",
            "counterplay": "Use pressure outside the Taiyin resistance family or higher authority.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          },
          {
            "name": "Refined — Dew Returns to Source",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You spend Lunar Yin Dew on Moon-Cold Guard, Taiyin Stilling Touch, or Preserving Moon Breath.",
            "cost": "",
            "range": "Varies by modified spend",
            "target": "Same target as modified spend",
            "attack_or_save": "",
            "effect": "When you spend Lunar Yin Dew on Moon-Cold Guard, Taiyin Stilling Touch, or Preserving Moon Breath, add your Proficiency Bonus to one numeric value of that spend. This modifies the base spend. It does not require an additional action, Reaction, or Lunar Yin Dew, and it does not permit same-event spending.",
            "duration": "",
            "limit": "Rider only; no extra action/resource/reaction; no same-event spending.",
            "counterplay": "Force the cultivator to spend Dew before the important event or attack outside the listed scope.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected — True Moon Yin Palace",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You are conscious and this Foundation is Perfected.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot emanation",
            "target": "Self and chosen creatures in the emanation",
            "attack_or_save": "",
            "effect": "As a Bonus Action once per long rest, manifest the True Moon Yin Palace for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. While the palace lasts, chosen allies within 30 feet gain Advantage on saving throws against cold, necrotic drain, corpse-qi contamination, fear caused by darkness/death/cold, hostile stilling pressure, and anti-healing effects based on Yin, death, corpse-qi, or drain. Once on each of your turns, when you hit with a qualifying Foundation-aligned cold, Yin, Water, Dark, or Qiweaving technique, add your Proficiency Bonus to the damage. Lunar Yin Dew maximum remains 1.",
            "duration": "",
            "limit": "Once per long rest; 1 minute; Dew cap remains 1.",
            "counterplay": "Leave the emanation, break line of effect where relevant, use fire/force/physical pressure, use higher authority, or wait out the duration.",
            "source_spheres": [
              "Yin",
              "Ice",
              "Water",
              "Dark",
              "Life",
              "Protection",
              "Spirit Companions",
              "Qiweaving"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Yin",
          "Ice",
          "Water",
          "Dark",
          "Life",
          "Protection",
          "Spirit Companions",
          "Qiweaving"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_TAIYIN_LUNAR_BODY_COLD_MUST_PRESERVE",
            "display_name": "Burden — Cold Must Preserve",
            "text": "If the cultivator repeatedly uses Taiyin power only to numb, abandon, or kill rather than preserve, the Foundation begins treating living warmth as contamination. Advancement scenes become harder until repaired."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_TAIYIN_LUNAR_BODY_FROZEN_HEART_MERIDIAN",
            "display_name": "Frozen-Heart Meridian",
            "text": "Cold preservation overreaches. Healing may feel distant, emotional warmth fades under stress, and anti-healing or corpse-qi effects become harder to purge until repaired."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_TAIYIN_LUNAR_BODY_MOON_SICKNESS",
            "display_name": "Moon-Sickness Strain",
            "text": "After overuse or failed refinement, the body alternates between dangerous chill and feverish backlash; sleep, dreams, and breath rhythm become unstable."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_TAIYIN_LUNAR_BODY_PERFECT_STILLNESS",
            "display_name": "Perfect Stillness Deviation",
            "text": "The cultivator begins to value stillness over life, mistaking absence of pain for preservation."
          },
          {
            "id": "DEVIATION_TAIYIN_LUNAR_BODY_GHOST_MOON_IDENTITY",
            "display_name": "Ghost-Moon Identity Deviation",
            "text": "The self becomes too close to ghost-cold, corpse memory, or moon-reflection; relationships feel less real than preserved images."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair — Moon-Well Fasting",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Use cold-water fasting, quiet breath, and moonlit circulation to reduce Lunar Yin stagnation, restore warmth at the heart, and confirm that preservation has not become self-erasure.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        },
        {
          "name": "Repair — Warm-Heart Needle",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Use Life, Protection, Alchemy, or Qiweaving support to warm the heart channel without breaking the Taiyin root.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        },
        {
          "name": "Repair — Ghost-Cold Purge",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Purge corpse-qi, ghost-cold, or death-still residue from the meridians through supervised cultivation.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge — Preserve Without Freezing",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Prove that you can preserve life without freezing change, grief, choice, or growth.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        },
        {
          "name": "Challenge — Moon Over Water",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Meditate beside dangerous water, cold, ghosts, or darkness until the reflection remains clear without swallowing the self.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        },
        {
          "name": "Challenge — Warmth Under Moon",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Protect another creature through cold danger while keeping compassion warm rather than turning mercy into stillness.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage — Taiyin Scripture Initiation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "A teacher, spirit, moon-script, or surviving Taiyin lineage teaches how to cultivate lunar cold without dying young or freezing the heart.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        },
        {
          "name": "Lineage — True Moon Well Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "A rare moon-well, Yin palace, ancestor ghost, or lunar relic opens the route toward Refined or Perfected Taiyin expression.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Yin",
            "Ice",
            "Water",
            "Dark",
            "Life",
            "Protection",
            "Spirit Companions",
            "Qiweaving"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "karma_knot_root_v0_2B",
      "name": "Karma Knot Root",
      "number": 19,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Spirit Awakening or Qi Cultivation",
        "secondary_path_fit": "Karma, Fate, Thread, Chains, Guardian, Retribution",
        "typical_role": "Striker / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Oaths, favors, debts, punishments, and unfinished promises pull through your cultivation. When harm creates a debt and that debt is answered, your Foundation gathers a brief Karmic Due.",
        "visible_sign": "Threads, knots, rings, chain marks, tally marks, red cord images, or ledger-like dreams appear around important obligations.",
        "warning": "Ignoring serious debts, exploiting obligations, false contracts, or punishing beyond proportion can tangle the root.",
        "dao_principle": "Every debt ties a road through the soul."
      },
      "resource": {
        "name": "Karmic Due",
        "maximum": "1",
        "starting": "0",
        "gain": "After Trigger Resolves",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round; max 1 Karmic Due; expires end of next turn.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Avoid creating debts through damage, attack from outside the cultivator's sight/answering range, suppress Karmic Due with Unpaid Debt/Tangled Knot, or prevent the answering hit/save failure.",
        "spends": [
          "Knot Judgment",
          "Red Cord Guard",
          "Ledger Witness",
          "Perfected: Court of Consequence"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Karmic Root Reserve",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always Active",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: your maximum Path resource increases by PB. Use Stamina, Qi, or Resonance according to your Path. Integrated: increase it by another PB, stacking with the base passive. This increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit.",
            "counterplay": "Suppress or damage the Foundation through Unpaid Debt, Karmic Snarl, Tangled Knot, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Generate Karmic Due",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After Trigger Resolves",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Once per round, after you hit a creature or it fails a saving throw against your technique, if that creature damaged you or an ally since the end of your last turn, gain 1 Karmic Due, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same hit or failed save that generated it.",
            "duration": "See effect",
            "limit": "Once per round; max 1 Karmic Due; expires end of next turn.",
            "counterplay": "Avoid creating debts through damage, attack from outside the cultivator's sight/answering range, suppress Karmic Due with Unpaid Debt/Tangled Knot, or prevent the answering hit/save failure.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Knot Judgment",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After You Hit or a Creature Fails Your Damaging Technique Save",
            "cost": "1 Karmic Due",
            "range": "Self",
            "target": "One hit or damaging technique",
            "attack_or_save": "",
            "effect": "Spend 1 Karmic Due to add PB damage to one hit or one damaging technique effect after it resolves. The damage follows the triggering attack or technique. Refined and Perfected evolutions can stack onto this conversion.",
            "duration": "Instant",
            "limit": "Spend 1 Karmic Due; cannot spend on the same event that generated it.",
            "counterplay": "Block the hit/save failure, suppress Karmic Due, remove the cultivator's ability to answer the debt, or use resistance/immunity against the damage type.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Red Cord Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When You or an Ally Within 30 Feet Takes Damage",
            "cost": "1 Karmic Due + Reaction",
            "range": "30 ft",
            "target": "Self or one ally within 30 ft",
            "attack_or_save": "",
            "effect": "Spend 1 Karmic Due and your Reaction to reduce the triggering damage by PB + your cultivation ability modifier. Refined and Perfected evolutions can stack onto this conversion.",
            "duration": "Instant",
            "limit": "Spend 1 Karmic Due and Reaction.",
            "counterplay": "Bait or exhaust the Reaction, suppress Karmic Due, attack from beyond 30 ft of eligible allies, or use damage that cannot be reduced by Foundation features.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Ledger Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After Rolling Before Outcome",
            "cost": "1 Karmic Due",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Check or save in Fixed Karma Knot Scope",
            "effect": "Spend 1 Karmic Due after rolling but before the outcome to add PB to a Fixed Karma Knot Scope check or saving throw. Refined and Perfected evolutions can stack onto this conversion.",
            "duration": "Instant",
            "limit": "Spend 1 Karmic Due; roll must be inside Fixed Karma Knot Scope.",
            "counterplay": "Keep the roll outside the Foundation's fixed scope, suppress Karmic Due, or resolve the outcome before the player declares the spend.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Debt-Answer Judgment",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When Knot Judgment Is Used",
            "cost": "",
            "range": "Self",
            "target": "Knot Judgment",
            "attack_or_save": "",
            "effect": "If chosen as the Refined expression, Knot Judgment adds another PB damage. This stacks with the base Knot Judgment damage.",
            "duration": "Instant",
            "limit": "Passive rider; requires chosen Refined expression.",
            "counterplay": "Suppress the Foundation, suppress Karmic Due, or prevent the base Knot Judgment conversion.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Refined: Guardian Knot",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When Red Cord Guard Is Used",
            "cost": "",
            "range": "30 ft",
            "target": "Red Cord Guard",
            "attack_or_save": "",
            "effect": "If chosen as the Refined expression, Red Cord Guard reduces damage by another PB. This stacks with the base Red Cord Guard reduction.",
            "duration": "Instant",
            "limit": "Passive rider; requires chosen Refined expression.",
            "counterplay": "Suppress the Foundation, suppress Karmic Due, or prevent the base Red Cord Guard conversion.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          },
          {
            "name": "Refined: True Ledger Witness",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When Ledger Witness Is Used",
            "cost": "",
            "range": "Self",
            "target": "Ledger Witness",
            "attack_or_save": "",
            "effect": "If chosen as the Refined expression, Ledger Witness adds another PB to the same Fixed Karma Knot Scope roll. This stacks with the base Ledger Witness bonus.",
            "duration": "Instant",
            "limit": "Passive rider; requires chosen Refined expression.",
            "counterplay": "Suppress the Foundation, suppress Karmic Due, or keep the roll outside Fixed Karma Knot Scope.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Court of Consequence",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "When You Spend Karmic Due",
            "cost": "",
            "range": "Self",
            "target": "One legal Karmic Due conversion",
            "attack_or_save": "",
            "effect": "Once per round, when you spend Karmic Due, increase one numeric benefit from that conversion by PB. This stacks with the base conversion and any chosen Refined evolution.",
            "duration": "Instant",
            "limit": "Once per round; passive rider; requires Perfected stage.",
            "counterplay": "Suppress the Foundation, suppress Karmic Due, prevent the base conversion, or deny a numeric benefit to increase.",
            "source_spheres": [
              "Karma",
              "Fate",
              "Thread",
              "Chains",
              "Guardian",
              "Protection",
              "Retribution",
              "Warleader",
              "Sect Stewardship",
              "Spirit Companions",
              "Ink"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Karma",
          "Fate",
          "Thread",
          "Chains",
          "Guardian",
          "Protection",
          "Retribution",
          "Warleader",
          "Sect Stewardship",
          "Spirit Companions",
          "Ink"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Unpaid Debt",
            "severity_range": "1-3",
            "trigger": "Breaking meaningful promises, ignoring serious debts, exploiting obligations, false contracts, binding innocents for convenience, or using compatible methods to escape consequence without correction.",
            "fixed_effect_ladder": {
              "Severity 1": "Fixed Karma Knot Scope DCs increase by +2. Karmic Due is not suppressed.",
              "Severity 2": "Fixed Karma Knot Scope DCs increase by +4. Karmic Due cannot be generated from the triggering debt, broken promise, false contract, or exploited obligation scene.",
              "Severity 3": "Fixed Karma Knot Scope DCs increase by +6. Karmic Due generation is suppressed until rest or Foundation correction. Existing Karmic Due can still be spent unless Tangled Knot or another explicit effect blocks it."
            },
            "stress_failure": "Failure by 5 or more on a Fixed Karma Knot Scope roll applies or worsens Karmic Snarl, or advances Ledger Tyrant if that temptation is active.",
            "suppression": "Teacher correction, repayment, apology, vow repair, legal-spiritual clarification, compatible sphere treatment, or meaningful story correction.",
            "integration_or_treatment": "Complete three stabilizations: one compatible sphere interface, one concrete debt/oath correction, and one Method or teacher correction."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Karmic Snarl",
            "severity_range": "1-4",
            "injured_systems": [
              "soul anchor",
              "vow threads",
              "fate knots",
              "binding meridians",
              "consequence sense"
            ],
            "visible_symptoms": "Red cords tangle in dreams, oaths feel physically tight, debt records appear in meditation, binding marks ache near broken promises, and curse/fate work pulls unevenly.",
            "fixed_effect": "Fixed Karma Knot Scope DCs increase by +2 × Severity when the roll concerns curse, oath, contract, fate backlash, spiritual chain, karmic punishment, named obligation, or Foundation repair/challenge for this injury.",
            "treatment_path": "Repayment or correction scene, compatible Karma/Life/Guardian/Protection/Spirit Companions/Ink/Music treatment, teacher diagnosis, Method correction, and a story action that addresses the cause.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Tangled Knot",
            "severity_range": "1-3",
            "suppressed_feature": "Karmic Due generation and, at Severity 3, Karmic Due spending.",
            "trigger": "Direct contradiction of the Foundation doctrine, suppression field, failed compatible check by 5 or more, or abusive overuse of debt/binding authority.",
            "fixed_effect_ladder": {
              "Severity 1": "Karmic Due cannot be generated from the triggering scene. Other legal scenes can still generate it.",
              "Severity 2": "Karmic Due generation is suppressed until restoration. Existing Karmic Due can still be spent.",
              "Severity 3": "Karmic Due generation and Karmic Due spending are suppressed until restoration; failure by 5 or more on a Fixed Karma Knot Scope roll may apply or worsen Karmic Snarl."
            },
            "restoration": "Restoration scene, repayment, oath correction, compatible training, teacher correction, treatment, apology, vow, or successful Foundation Challenge check."
          }
        ],
        "deviations": [
          {
            "name": "Ledger Tyrant",
            "severity_range": "1-4",
            "temptation": "All harm must be repaid at interest. People become entries. Mercy becomes bad accounting.",
            "trigger": "Humiliation, betrayal, unpaid debt, victory over a debtor, cursed contract, unresolved Burden, or a scene that challenges rightful consequence.",
            "benefit_options": [
              "Gain 1 Karmic Due without meeting the normal trigger.",
              "Add PB to one Karmic Due conversion after the normal conversion is declared.",
              "Gain Advantage on one Fixed Karma Knot Scope check involving repayment, punishment, binding, or debt collection.",
              "Suppress one Unpaid Debt or Tangled Knot effect for the scene."
            ],
            "cost": "Increase Ledger Tyrant progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "escalation": "At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "correction": "Refuse the shortcut, accept proportional repayment, release an unfair debt, repair harm, submit to correction, or integrate consequence into a disciplined Method."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repayment Accounting",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Make concrete restitution or proportional release for a named debt; counts as one stabilization for Unpaid Debt or Karmic Snarl.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        },
        {
          "name": "Red Cord Breath",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Meditate on visible obligation threads with Karma, Fate, Thread, Chains, Guardian, Protection, Spirit Companions, Ink, or Music support.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Karma Knot Root",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "Diagnosis, curse pressure, vow crisis, legal-spiritual binding, or compatible training reveals the root's debt-thread structure.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        },
        {
          "name": "Integrate the Knot",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "Complete compatible Method correction, compatible sphere interface, and a story action proving consequence without tyranny.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Red Cord Initiation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Student, prepared creature, curse/oath subject, or lineage patient",
          "attack_or_save": "",
          "effect": "Teacher-supported rite that lets a student form a lesser Karma Knot spark tied to one vow, debt, or protection duty. Does not grant the full Foundation automatically.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        },
        {
          "name": "Debt-Ledger Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate karmic method/input.",
          "range": "Scene",
          "target": "Student, prepared creature, curse/oath subject, or lineage patient",
          "attack_or_save": "",
          "effect": "Identify whether a curse, oath, contract, spiritual chain, or sect obligation is feeding Unpaid Debt or Karmic Snarl.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate karmic circumstance, honest method, scene time, teacher/input compatibility, and cannot be used if the Foundation route is suppressed or the scene does not match the debt-thread.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "verdant_returning_spring_v0_2B",
      "name": "Verdant Returning-Spring",
      "number": 20,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening",
          "Body Refining"
        ],
        "typical_role": "Support / Defender / Recovery",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Major outward support-defense Foundation for healing, protection, medicine, and returning-spring vitality.",
        "visible_sign": "",
        "warning": "Spring Must Flow Outward: self-only sustain does not generate Spring Dew and repeated self-preservation without outward aid strains the Foundation.",
        "dao_principle": null
      },
      "resource": {
        "name": "Spring Dew",
        "maximum": "1",
        "starting": "0",
        "gain": "After you restore Hit Points to a creature other than yourself, grant temporary Hit Points to a creature other than yourself, reduce damage for a creature other than yourself, or succeed on a meaningful treatment/stabilization against hostile poison, disease, rot, withering, anti-healing, or spiritual depletion.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Prevent outward support, isolate targets, use anti-healing, or force the cultivator into self-only survival.",
        "spends": [
          "Returning-Spring Guard",
          "Verdant Mercy Bloom",
          "Spring Renewal Pulse",
          "Refined: Dew Returns Outward",
          "Perfected: Returning-Spring Grove"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Generate Spring Dew",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you restore Hit Points to a creature other than yourself, grant temporary Hit Points to a creature other than yourself, reduce damage for a creature other than yourself, or succeed on a meaningful treatment/stabilization against hostile poison, disease, rot, withering, anti-healing, or spiritual depletion.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the qualifying outward-support trigger resolves, if you are conscious and do not already have Spring Dew, gain Spring Dew 1/1. Spring Dew cannot be generated by its own spending, by self-only healing, by staged harmless conditions, by friendly training scenes, or by repeated non-threatening treatment loops.",
            "duration": "",
            "limit": "Maximum 1; once per round; generated after trigger resolves; expires end of your next turn; cannot be spent on the event that generated it.",
            "counterplay": "Prevent outward support, isolate targets, use anti-healing, or force the cultivator into self-only survival.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          },
          {
            "name": "Returning-Spring Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes damage from a hostile source.",
            "cost": "1 Spring Dew",
            "range": "30 feet",
            "target": "Self or one ally taking the triggering damage",
            "attack_or_save": "",
            "effect": "Spend 1 Spring Dew to reduce the triggering damage by your Proficiency Bonus + your Path key ability modifier. If the source is poison, disease, necrotic damage, rot, withering, hostile plant corruption, anti-healing pressure, or spiritual depletion, increase the reduction by your Proficiency Bonus.",
            "duration": "",
            "limit": "Does not restore HP and cannot generate Spring Dew from its own prevention.",
            "counterplay": "Use burst damage outside 30 feet, anti-healing effects, or pressure the cultivator before Dew is available.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          },
          {
            "name": "Verdant Mercy Bloom",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You restore Hit Points, grant temporary Hit Points, or reduce damage for a creature other than yourself with a qualifying Foundation-aligned method.",
            "cost": "1 Spring Dew",
            "range": "Range of the triggering effect",
            "target": "One creature affected by the triggering support",
            "attack_or_save": "",
            "effect": "Spend 1 Spring Dew to add your Proficiency Bonus + your Path key ability modifier to one healing, temporary Hit Point, or damage reduction value affecting a creature other than yourself. If the target is at 0 Hit Points, it is also stabilized if the effect leaves it alive and the source is not a forbidden anti-life wound.",
            "duration": "",
            "limit": "Cannot target self-only support and cannot make the same support event generate and spend Dew.",
            "counterplay": "Force self-only survival, block line of effect, or apply effects that prevent stabilization.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          },
          {
            "name": "Spring Renewal Pulse",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "You take a Bonus Action on your turn while Spring Dew is available.",
            "cost": "1 Spring Dew",
            "range": "30 feet",
            "target": "Self or one willing creature within 30 feet",
            "attack_or_save": "",
            "effect": "Spend 1 Spring Dew. The target gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Before the start of your next turn, the target has Advantage on the next saving throw it makes against poison, disease, rot, withering, anti-healing pressure, or spiritual depletion.",
            "duration": "",
            "limit": "Does not cure the condition by itself and does not stack with itself on the same target.",
            "counterplay": "Attack through other pressure types, wait out the short window, or force multiple saves.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Moonspring Root",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "This rider is active while the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When Refined, the Hit Point increase from Verdant Spring Vessel becomes twice your Proficiency Bonus. Returning-Spring Guard may target an ally you can see within 60 feet instead of 30 feet.",
            "duration": "",
            "limit": "Does not increase Spring Dew maximum and does not let the guard protect targets through total cover.",
            "counterplay": "Break line of sight, outrange the support line, or force multiple simultaneous injuries.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          },
          {
            "name": "Refined: Dew Returns Outward",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You spend Spring Dew on a Foundation action while Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you spend Spring Dew on Returning-Spring Guard, Verdant Mercy Bloom, or Spring Renewal Pulse, add your Proficiency Bonus to one numeric value produced by that spend. This modifies the base spend. It does not require an additional action, Reaction, or resource spend.",
            "duration": "",
            "limit": "Applies once to the spend and does not increase resource maximum.",
            "counterplay": "Force the cultivator to spend Dew inefficiently or attack after Dew is gone.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Returning-Spring Grove",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You activate the Perfected Foundation expression.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot emanation",
            "target": "Self and chosen allies in the emanation",
            "attack_or_save": "",
            "effect": "Once per long rest as a Bonus Action, you open a 30-foot Returning-Spring Grove for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. Chosen allies in the emanation have Advantage on saving throws against poison, disease, rot, withering, anti-healing pressure, and spiritual depletion. When you spend Spring Dew on a creature in the grove, that creature also gains temporary Hit Points equal to your Proficiency Bonus. Spring Dew maximum remains 1.",
            "duration": "",
            "limit": "Does not heal each round, cure major afflictions, or increase Spring Dew maximum.",
            "counterplay": "Leave the emanation, separate allies, use pressure outside the listed categories, or exhaust Dew timing.",
            "source_spheres": [
              "Life",
              "Verdant Growth",
              "Water",
              "Protection",
              "Alchemy",
              "Radiance",
              "Qiweaving",
              "Flowers",
              "Harvesting Gathering"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Life",
          "Verdant Growth",
          "Water",
          "Protection",
          "Alchemy",
          "Radiance",
          "Qiweaving",
          "Flowers",
          "Harvesting Gathering"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "text": "Spring Must Flow Outward: self-only sustain does not generate Spring Dew and repeated self-preservation without outward aid strains the Foundation."
          }
        ],
        "hidden_injuries": [
          {
            "text": "Root-Bound Mercy Hidden Injury: the cultivator's vitality clings to those they save, causing fatigue, sympathy pain, or delayed recovery."
          }
        ],
        "strains": [
          {
            "text": "Stagnant Spring Strain: unused healing qi pools into swelling, fever, waterlogged meridians, or reluctance to let wounds close naturally."
          }
        ],
        "deviations": [
          {
            "text": "Overgrown Heart Deviation: the cultivator tries to preserve everything and cannot accept necessary endings."
          },
          {
            "text": "Garden Cage Deviation: protection becomes control, and nurtured allies are treated as plants that must not leave the garden."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Clear the Stagnant Spring",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Use field medicine, clean water, breath regulation, and gentle circulation to drain stagnant healing qi without forcing regeneration.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        },
        {
          "name": "Root-Bound Mercy Release",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Separate the cultivator's vitality from those they have saved, teaching care without ownership.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        },
        {
          "name": "Seasonal Return Medicine",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Treat hidden swelling, waterlogged meridians, fever, or rot pressure through herb baths, spring dew, and seasonal cultivation.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Triage Under Rain",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Protect one life while accepting that not every wound can be held closed at once.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        },
        {
          "name": "Let the Garden Open",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Choose nurture over control when an ally or patient must leave the cultivator's protection.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        },
        {
          "name": "Spring After Winter Proof",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Survive poison, plague, famine, or spiritual depletion while keeping vitality moving outward.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Returning-Spring Herb Hall Method",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a lineage scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "A teacher or herb hall can train the cultivator to recognize when medicine has become control.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        },
        {
          "name": "Living Root Refuge Transmission",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a lineage scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "A refuge lineage can teach the Foundation to shelter the weak without creating dependency.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Life",
            "Verdant Growth",
            "Water",
            "Protection",
            "Alchemy",
            "Radiance",
            "Qiweaving",
            "Flowers",
            "Harvesting Gathering"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "seven_star_sword_heart_v0_2B",
      "name": "Seven-Star Sword-Heart",
      "number": 21,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Spirit Awakening"
        ],
        "typical_role": "Controller",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Major single-target martial precision Foundation for sword-intent, star focus, and disciplined commitment.",
        "visible_sign": "",
        "warning": "One Star, One Line: willingly damaging a hostile creature other than your Marked Star blocks Star Intent generation until the start of your next turn.",
        "dao_principle": null
      },
      "resource": {
        "name": "Star Intent",
        "maximum": "1",
        "starting": "0",
        "gain": "After you hit your Marked Star with a qualifying attack or Foundation-aligned technique, miss your Marked Star with a real hostile attack roll, or your Marked Star succeeds on a saving throw against your qualifying Foundation-aligned technique.",
        "timing": "After the qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Break line of sight, force target swaps, use decoys, or pressure the cultivator with multiple urgent enemies.",
        "spends": [
          "Seven-Star Correction",
          "Sword-Heart Line",
          "Star-Refusal Guard",
          "Refined: Seven-Star Alignment"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Generate Star Intent",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit your Marked Star with a qualifying attack or Foundation-aligned technique, miss your Marked Star with a real hostile attack roll, or your Marked Star succeeds on a saving throw against your qualifying Foundation-aligned technique.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the qualifying event resolves, if you are conscious and do not already have Star Intent, gain Star Intent 1/1. Star Intent cannot be generated from training attacks, harmless targets, deliberate misses, impossible rolls, repeated static obstacles, or attacks against creatures that are not your Marked Star.",
            "duration": "",
            "limit": "Maximum 1; once per round; generated after trigger resolves; expires end of your next turn; cannot be spent on the event that generated it.",
            "counterplay": "Break line of sight, force target swaps, use decoys, or pressure the cultivator with multiple urgent enemies.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          },
          {
            "name": "Seven-Star Correction",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You miss your Marked Star with a qualifying attack roll from an attack or Foundation-aligned technique.",
            "cost": "1 Star Intent",
            "range": "Range of the triggering attack",
            "target": "Your Marked Star",
            "attack_or_save": "Attack roll correction",
            "effect": "Spend 1 Star Intent after you miss your Marked Star with a qualifying attack roll. Add your Proficiency Bonus + your Path key ability modifier to the attack roll. If this changes the miss into a hit, the hit deals additional damage equal to your Proficiency Bonus.",
            "duration": "",
            "limit": "Only applies to your Marked Star and cannot be used on an attack against another creature.",
            "counterplay": "Force the cultivator to attack decoys, break line of sight, impose disadvantage, or bait the mark away from the true threat.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          },
          {
            "name": "Sword-Heart Line",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit your Marked Star with a qualifying close, sword, weapon, or Foundation-aligned attack.",
            "cost": "1 Star Intent",
            "range": "Range of the triggering hit",
            "target": "Your Marked Star",
            "attack_or_save": "",
            "effect": "Spend 1 Star Intent after hitting your Marked Star. Add your Proficiency Bonus + your Path key ability modifier to the damage. Until the start of your next turn, the target cannot take Reactions against you unless a higher-authority feature overrides this Foundation.",
            "duration": "",
            "limit": "Only applies to the Marked Star and does not prevent reactions against other creatures.",
            "counterplay": "Avoid becoming the Marked Star, force target swaps, or use higher-authority reaction protection.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          },
          {
            "name": "Star-Refusal Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "Your Marked Star hits you with an attack, or your Marked Star forces you to make a saving throw.",
            "cost": "1 Star Intent",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Star Intent as a Reaction when your Marked Star hits you or forces you to make a saving throw. If the trigger is damage, reduce that damage by your Proficiency Bonus + your Path key ability modifier. If the trigger is a saving throw, add your Proficiency Bonus + your Path key ability modifier to the save after rolling but before final consequences are applied.",
            "duration": "",
            "limit": "Only functions against the current Marked Star and cannot protect allies by default.",
            "counterplay": "Use non-marked allies, area effects from other sources, or force the cultivator to spend Intent offensively first.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Seven-Star Alignment",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "This rider is active while the Foundation is Refined.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When Refined, the Hit Point increase from Seven-Star Sword-Heart Vessel becomes twice your Proficiency Bonus. When you spend Star Intent, add your Proficiency Bonus to one numeric value produced by that spend. This modifies the base spend and does not cost an additional action, Reaction, or resource.",
            "duration": "",
            "limit": "Does not increase Star Intent maximum and does not apply to non-marked targets.",
            "counterplay": "Force target swaps or make the cultivator spend Intent defensively.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          },
          {
            "name": "Refined: No Blind Tunnel",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Your Marked Star drops to 0 HP, becomes unreachable, or is revealed not to be the true threat.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When Refined, if your Marked Star drops to 0 Hit Points, becomes unreachable, leaves the scene, or is clearly revealed not to be the true threat, you may immediately choose a new hostile creature you can see as your Marked Star. This rider prevents the Foundation from becoming blindness rather than focus. It does not grant an extra attack or generate Star Intent by itself.",
            "duration": "",
            "limit": "Cannot be used repeatedly to fish for advantages; requires a real drop, loss, or revealed objective shift.",
            "counterplay": "Use decoys and objective pressure without giving clean confirmation.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Seven-Star Sword Court",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You activate the Perfected Foundation expression.",
            "cost": "Once per long rest",
            "range": "Self; 30-foot emanation",
            "target": "Self and current Marked Star",
            "attack_or_save": "",
            "effect": "Once per long rest as a Bonus Action, you establish a Seven-Star Sword Court for 1 minute. You gain temporary Hit Points equal to your Cultivation Level + your Path key ability modifier. The first time on each of your turns that you hit your Marked Star with a qualifying attack or Foundation-aligned technique, the hit deals additional damage equal to your Proficiency Bonus. You also have Advantage on saving throws and checks against fear, charm, illusion, decoy pressure, and false-target effects created by your Marked Star. Star Intent maximum remains 1.",
            "duration": "",
            "limit": "Does not increase Star Intent maximum, does not affect non-marked enemies, and does not force the Marked Star to stay in the court.",
            "counterplay": "Break line of sight, leave the court, force objective changes, or use multiple simultaneous threats.",
            "source_spheres": [
              "Sword",
              "Stars",
              "The Hidden Eye",
              "Pressure Points",
              "Qiweaving",
              "Fate",
              "Athletics",
              "Radiance"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Sword",
          "Stars",
          "The Hidden Eye",
          "Pressure Points",
          "Qiweaving",
          "Fate",
          "Athletics",
          "Radiance"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "text": "One Star, One Line: willingly damaging a hostile creature other than your Marked Star blocks Star Intent generation until the start of your next turn."
          }
        ],
        "hidden_injuries": [
          {
            "text": "Scattered Star Hidden Injury: focus splits and attack timing stutters after repeated decoys, missed commitments, or broken duels."
          }
        ],
        "strains": [
          {
            "text": "Blind Duel Meridian: peripheral awareness collapses, making allies and changing objectives harder to notice under pressure."
          }
        ],
        "deviations": [
          {
            "text": "Killing-Line Deviation: the cultivator reduces every problem to one target line."
          },
          {
            "text": "False North Star Blockage: the chosen target remains psychologically fixed after the true objective has changed."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Recenter the Seven Stars",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Rebuild focus through star-breath, eye training, and single-line sword forms after scattered attention or decoy trauma.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        },
        {
          "name": "Open the Peripheral Gate",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Train the cultivator to keep allies and objectives in awareness while maintaining one precise target line.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        },
        {
          "name": "Cut the False North Star",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a repair scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Ritually release an obsolete target fixation after vengeance, humiliation, or failed pursuit.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Duel Without Blindness",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Fight a superior or equal threat while still protecting a third party or objective.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        },
        {
          "name": "Recognize the Wrong Moon",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Identify the true threat among decoys, surrender-baits, illusions, or false stars.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        },
        {
          "name": "Sheathe After the Line Opens",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a challenge scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "Prove that the cultivator can end commitment when the target is no longer the Dao-relevant threat.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Seven-Star Sword Hall Transmission",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a lineage scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "A sword hall can teach the breath-and-eye method that fixes one target without losing the field.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        },
        {
          "name": "Northern Star Witness Method",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "Used during a lineage scene when the table chooses to engage this Foundation's non-combat route.",
          "cost": "Foundation scene, teacher/material access, or downtime as determined by GM.",
          "range": "Narrative / Downtime",
          "target": "Self or participating scene subject",
          "attack_or_save": "",
          "effect": "A star-reading lineage can diagnose when focus has become a tunnel and correct the mark through omen practice.",
          "duration": "",
          "limit": "Not a combat action unless separately rewritten as a full combat row.",
          "counterplay": "Requires appropriate scene access, time, materials, teacher pressure, and consequences.",
          "source_spheres": [
            "Sword",
            "Stars",
            "The Hidden Eye",
            "Pressure Points",
            "Qiweaving",
            "Fate",
            "Athletics",
            "Radiance"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "weak_reed_tendons_v0_2B",
      "name": "Weak Reed Tendons",
      "number": 22,
      "profile": {
        "grade": "Minor",
        "status": "Stable",
        "default_stage": "Common Expression",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation through Air, Water, Flowing River, Verdant Growth, or Athletics"
        ],
        "typical_role": "Mobility / Defender / Striker",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your tendons and movement channels are weaker than ideal, but unusually redirectable. You bend before you brace, and your body resists heavy force methods.",
        "visible_sign": "Your stance sways during cultivation. Joints and tendons ache under heavy loads, but you recover from bending, falling, and awkward movement better than expected.",
        "warning": "Heavy Iron Body, rigid Earth, brute-force tendon hardening, and violent Berserker overtraining can injure this Foundation.",
        "dao_principle": "A reed survives not because it is strong, but because it has not yet chosen how to bend."
      },
      "resource": {
        "name": "Reed Flex",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after a hostile attack misses you while you have moved at least 10 feet since the start of your last turn.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round. Requires hostile attack miss and 10 feet of movement since the start of your last turn.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny movement, use saving throw/control effects instead of attack rolls, attack before the cultivator moves, or suppress the Foundation.",
        "spends": [
          "Reed Slip",
          "Bend-Without-Breaking Guard",
          "Reed Recovery",
          "Refined: Wire Tendons"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Reed-Sway Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: your speed increases by 5 feet. Integrated: your speed increases by another 5 feet, stacking with the base passive. This speed increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit.",
            "counterplay": "Suppress or damage the Foundation through Splintering Tendon, Frayed Tendon Channels, Bent Too Far, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Generate Reed Flex",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after a hostile attack misses you while you have moved at least 10 feet since the start of your last turn.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering miss resolves, gain 1 Reed Flex, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same miss that generated it.",
            "duration": "Instant",
            "limit": "Once per round. Requires hostile attack miss and 10 feet of movement since the start of your last turn.",
            "counterplay": "Deny movement, use saving throw/control effects instead of attack rolls, attack before the cultivator moves, or suppress the Foundation.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Reed Slip",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "During your movement while you already have Reed Flex.",
            "cost": "Spend 1 Reed Flex",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: move 5 feet without provoking opportunity attacks from one creature of your choice. Evolution rows below can increase this same movement and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Reed Flex. Movement must be legal for your current speed and space.",
            "counterplay": "Restrict movement, create terrain that cannot be crossed, force prone/restrained first, or attack while Reed Flex is absent.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Bend-Without-Breaking Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take damage and already have Reed Flex.",
            "cost": "Spend 1 Reed Flex",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: reduce the damage by PB. Evolution rows below can add to this same reduction and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Reed Flex. Cannot reduce the same miss that generated Reed Flex.",
            "counterplay": "Force the cultivator to spend Reed Flex on movement or recovery, use control effects, or attack while Reed Flex is absent.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Reed Recovery",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you roll a Weak Reed Scope check or saving throw and already have Reed Flex.",
            "cost": "Spend 1 Reed Flex",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Check/Save Rider",
            "effect": "Base: add PB to the roll. Weak Reed Scope means balance, falling, escaping or resisting grapple/restrain/prone/forced movement, movement through difficult terrain, tendon treatment, Weak Reed repair, and Weak Reed Foundation Challenge rolls. Evolution rows below can add to this same roll and stack unless stated otherwise.",
            "duration": "Instant",
            "limit": "Requires pre-existing Reed Flex and a roll inside Weak Reed Scope. Cannot apply to unrelated social, spellcasting, or brute-force damage rolls.",
            "counterplay": "Pressure the cultivator outside Weak Reed Scope, drain Reed Flex before forcing the roll, or use effects that do not allow a check/save.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined: Wind-Reed Body",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you use Reed Slip and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Reed Slip moves you another 5 feet. This stacks with the base Slip movement and with Perfected Unbroken Reed.",
            "duration": "Instant",
            "limit": "Requires the Wind-Reed Body Refined expression. Does not generate extra Reed Flex.",
            "counterplay": "Restrict movement, seal air/mobility routes, or force the cultivator to spend Reed Flex on Guard or Recovery instead.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Refined: River-Reed Flexibility",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you use Reed Recovery on an escape/control roll and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Reed Recovery adds another PB when the roll resists or escapes grapple, restraint, prone, forced movement, or difficult terrain. This stacks with the base Recovery bonus and with Perfected Unbroken Reed.",
            "duration": "Instant",
            "limit": "Requires the River-Reed Flexibility Refined expression and a roll inside the named control/movement scope.",
            "counterplay": "Use damage or non-physical pressure, drain Reed Flex first, or prevent a check/save from being rolled.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Refined: Verdant Sinews",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you use Bend-Without-Breaking Guard and selected this Refined expression.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: Bend-Without-Breaking Guard reduces damage by another PB. This stacks with the base Guard reduction and with Perfected Unbroken Reed.",
            "duration": "Instant",
            "limit": "Requires the Verdant Sinews Refined expression. Does not heal damage already taken from earlier events.",
            "counterplay": "Force multiple smaller hits, use control/conditions instead of damage, or attack while Reed Flex is absent.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          },
          {
            "name": "Refined: Wire Tendons",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "After you hit with a melee attack, unarmed strike, Wrestling, Iron Fist, Metal, or cutting/tendon technique and selected this Refined expression.",
            "cost": "Spend 1 Reed Flex",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Special Refined conversion: add PB damage to the hit. If Bent Too Far or Splintering Tendon is active, using this conversion counts as heavy tendon stress for that scene.",
            "duration": "Instant",
            "limit": "Requires Wire Tendons Refined expression and pre-existing Reed Flex. Cannot empower the same hostile miss that generated Reed Flex.",
            "counterplay": "Keep distance, force defensive spends, exploit active Strain/Burden, or use resistance/positioning against the empowered hit.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected: Unbroken Reed",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "When you spend Reed Flex and have Perfected Weak Reed Tendons as Unbroken Reed Tendons.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Evolution: once per round, the spent Reed Flex gains one extra benefit matching the conversion: Slip moves another 5 feet, Guard reduces damage by another PB, Recovery adds another PB, or Wire Tendons adds another PB damage. This stacks with base and Refined benefits unless stated otherwise.",
            "duration": "Instant",
            "limit": "Once per round. Requires Perfected Unbroken Reed Tendons and a legal Reed Flex spend.",
            "counterplay": "Deny Reed Flex generation, force the wrong conversion early, suppress the Foundation, or attack outside Weak Reed Scope.",
            "source_spheres": [
              "Athletics",
              "Flowing River",
              "Air",
              "Water",
              "Verdant Growth",
              "Wrestling",
              "Monkey Style",
              "Drunken Style",
              "Scoundrel",
              "Qiweaving"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Athletics",
          "Flowing River",
          "Air",
          "Water",
          "Verdant Growth",
          "Wrestling",
          "Monkey Style",
          "Drunken Style",
          "Scoundrel",
          "Qiweaving"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Splintering Tendon",
            "severity_range": "1-3",
            "trigger": "Rigid or heavy tendon stress: brute-force tendon hardening, heavy Earth/Metal/Brute training, failed Iron Fist or Berserker overtraining, forced march while injured, or rigid stance training without recovery.",
            "fixed_ladder": {
              "Severity 1": "Weak Reed Scope treatment, repair, challenge, and Method-correction DCs increase by +2 when the scene involves rigid strengthening, heavy loads, forced body hardening, or tendon stress.",
              "Severity 2": "As Severity 1. Reed Flex cannot be generated during the triggering heavy-training or rigid-pressure scene after the Foundation is stressed.",
              "Severity 3": "Reed Flex generation is suppressed until rest or Foundation correction. Existing Reed Flex can still be spent unless a separate effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies or worsens Frayed Tendon Channels, or advances Always Yield if the temptation is active.",
            "suppression": "Life healing, Verdant sinew bath, Flowing River flexibility, Water recovery, Alchemy tendon medicine, rest from heavy training.",
            "integration": "Complete three stabilizations: flexibility practice, controlled strengthening, and compatible movement sphere training."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Frayed Tendon Channels",
            "severity_range": "1-4",
            "injured_system": "tendons, ligaments, movement meridians, knee/shoulder/ankle channels, and grip channels",
            "default_effect": "Weak Reed Scope DCs increase by +2 × Severity when the roll involves balance, falling, escaping or resisting grapple/restrain/prone/forced movement, difficult terrain, tendon treatment, Weak Reed repair, or Weak Reed Foundation Challenge.",
            "stress_failure": "Failure by 5 or more increases Severity by 1.",
            "treatment_path": "Life healing, Verdant Growth treatment, Water therapy, Flowing River correction, tendon medicine, and careful strengthening.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Bent Too Far",
            "severity_range": "1-3",
            "fixed_ladder": {
              "Severity 1": "Reed Slip cannot be used.",
              "Severity 2": "As Severity 1, and Reed Flex cannot be generated until the end of your next turn after a failed Weak Reed Scope roll by 5 or more.",
              "Severity 3": "As Severity 2, and Reed Flex cannot be spent on Bend-Without-Breaking Guard until restored."
            },
            "trigger": "Failed heavy training, fall damage, grapple injury, forced march, rigid body-tempering, or repeated use of Wire Tendons while already strained.",
            "restoration": "Rest, stretching rite, Life/Verdant treatment, Water therapy, compatible movement training success, teacher correction, or successful Foundation Challenge check."
          }
        ],
        "deviations": [
          {
            "name": "Always Yield",
            "severity_range": "1-4",
            "progress": "0-3",
            "temptation": "Survive by never resisting. Bend before every demand. Escape every duty.",
            "benefit_options": [
              "Gain 1 Reed Flex after a hostile attack misses you even if the once-per-round generation was already used.",
              "Move 10 feet without provoking opportunity attacks after taking damage.",
              "Add PB to one Weak Reed Scope roll.",
              "Suppress Splintering Tendon penalties for the scene by spiritually yielding."
            ],
            "cost": "Increase Deviation progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "escalation": "At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "correction": "Stand firm for someone else, hold a line, accept pain without yielding, or win by bending without fleeing.",
            "possible_transformation": "River-Reed Flexibility, Coward’s Heart Demon, Evasion Body, or Guardian Reed Anchor."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Tendon Recovery Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Life healing, Verdant sinew bath, Water therapy, or Alchemy tendon medicine counts as one stabilization for Splintering Tendon, Frayed Tendon Channels, or Bent Too Far.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Controlled Strengthening",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Careful strengthening without rigid overtraining counts as one stabilization for Splintering Tendon or Bent Too Far.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Flowing Correction Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Flowing River, Athletics, Water, Air, Monkey Style, or Drunken Style correction trains flexibility without collapse; counts as one compatible stabilization.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Weak Reed Tendons",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "A body teacher, Life physician, movement trial, or Athletics diagnosis reveals that the weakness is redirectable flexibility, not dead tissue.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Deepen Weak Reed Tendons",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "Advance the Foundation through compatible movement practice, tendon treatment, and a scene of bending without fleeing.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Integrate Weak Reed Tendons",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "Balance flexibility with strength through treatment, movement training, and one scene of standing firm without shattering.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Transmute Weak Reed Tendons",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Self and Foundation state",
          "attack_or_save": "",
          "effect": "Redirect into Wind-Reed Body, River-Reed Flexibility, Verdant Sinews, Wire Tendons, Monkey-Reed Body, Guardian Reed Anchor, or Unbroken Reed Tendons.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Reed-Body Initiation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Student or lineage patient",
          "attack_or_save": "",
          "effect": "Teacher-supported rite that lets a student form a lesser Reed Tendon spark tied to flexibility, survival movement, or humble evasion. Does not grant the full Foundation automatically.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Refugee Survival Art",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Downtime lineage teaching that preserves the Foundation as a low-status evasion, fall-survival, or escape method for disciples with weak bodies.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Flexible Grappler School",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate movement/tendon method or teacher input.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Institutional lineage support that teaches lesser tendon redirection for Wrestling, Flowing River, Monkey Style, or Athletics students.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible movement/tendon method, teacher or treatment input, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "furnace_heart_record_v0_2B",
      "name": "Furnace Heart Record",
      "number": 23,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation through Fire, Yang, Hunger, Alchemy, Poison, Berserker, or Blacksmith"
        ],
        "typical_role": "Striker / Support / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your heartbeat runs hot during cultivation. Harsh food, bitter medicine, fire qi, battle pressure, and body-furnace methods feel usable.",
        "visible_sign": "Your pulse warms the air near your chest. During exertion, veins may glow faint red-gold. Bitter medicine tastes clearer than sweet food.",
        "warning": "Too much Fire, Yang, Hunger, Alchemy, or battle-tempering without cooling can overheat your organs.",
        "dao_principle": "The heart burns impurity into motion, but every furnace must learn when to cool."
      },
      "resource": {
        "name": "Furnace Heat",
        "maximum": "1",
        "starting": "0",
        "gain": "After qualifying body-furnace event resolves",
        "timing": "After qualifying body-furnace event resolves",
        "frequency": "Once per round; max 1; expires end of next turn; cannot be spent on the same event that generated it.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny compatible body-furnace techniques, force Cooling Debt, suppress the Foundation through Furnace Overheat, or end the scene before Furnace Heat is spent.",
        "spends": [
          "Banked Coals",
          "Furnace Guard",
          "Venting Strike",
          "Medicine Furnace",
          "Battle Furnace",
          "Alchemy Heart",
          "Hunger Furnace",
          "Heart-Cauldron Body"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Furnace-Heart Capacity",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always Active",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: your maximum hit points increase by your Proficiency Bonus. Integrated: your maximum hit points increase by another Proficiency Bonus, stacking with the base passive. This maximum HP increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "",
            "limit": "Passive maximum HP increase. Applies once while the Foundation is active; at Integrated stage, apply the additional PB increase once as well. Does not stack with duplicate copies of the same Foundation feature.",
            "counterplay": "Suppress or damage the Foundation, impose Furnace Overheat/Organ Fire severe enough to shut down Furnace benefits, or adjudicate only one copy of this passive from the same Foundation.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Generate Furnace Heat",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After qualifying body-furnace event resolves",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Once per round, after you resolve a body-furnace technique that costs Path resource, or after body-furnace backlash damages you and you remain conscious, gain 1 Furnace Heat. Maximum 1. Furnace Heat expires at the end of your next turn and cannot be spent on the same event that generated it.",
            "duration": "",
            "limit": "Once per round; max 1; expires end of next turn; cannot be spent on the same event that generated it.",
            "counterplay": "Deny compatible body-furnace techniques, force Cooling Debt, suppress the Foundation through Furnace Overheat, or end the scene before Furnace Heat is spent.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Banked Coals",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After generating event has resolved",
            "cost": "1 Furnace Heat",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Furnace Heat after the generating event has resolved to gain temporary hit points equal to your Proficiency Bonus + your cultivation ability modifier. These temporary hit points do not stack with other temporary hit points.",
            "duration": "",
            "limit": "Requires Furnace Heat; cannot spend on same event that generated it.",
            "counterplay": "Temporary hit points do not stack; suppression from Cooling Debt or Furnace Overheat may block generation.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Furnace Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take qualifying damage",
            "cost": "1 Furnace Heat",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Reaction: when you take damage from a hostile attack, hostile technique, or Fixed Furnace Heart Scope backlash, spend 1 Furnace Heat to reduce the damage by your Proficiency Bonus + your cultivation ability modifier.",
            "duration": "",
            "limit": "Requires Furnace Heat and your Reaction; cannot spend on same event that generated it.",
            "counterplay": "Uses Reaction; damage that bypasses reduction or suppresses Foundation resources may limit it.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Venting Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "When you hit with qualifying attack or technique",
            "cost": "1 Furnace Heat",
            "range": "Self",
            "target": "One hit or damaging technique effect",
            "attack_or_save": "",
            "effect": "When you hit with an attack or damaging technique in the Fixed Furnace Heart Scope, spend 1 Furnace Heat to add your Proficiency Bonus as fire, poison, or force damage, matching the technique or chosen furnace expression.",
            "duration": "",
            "limit": "Requires Furnace Heat; cannot spend on same hit or failed save that generated it.",
            "counterplay": "Avoid qualifying scope, deny hit, resist damage type if applicable, or suppress Furnace Heat generation.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Medicine Furnace",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined passive rider",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution — Medicine Furnace: when you spend Furnace Heat on Banked Coals during a Fixed Furnace Heart Scope poison, disease, medicine, digestion, impurity, or pill-impurity scene, add another Proficiency Bonus to the temporary hit points. This stacks with Banked Coals.",
            "duration": "",
            "limit": "Requires selected Refined expression and a qualifying Banked Coals spend.",
            "counterplay": "Does not work outside the named scope; temporary hit points still do not stack.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Battle Furnace",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined passive rider",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution — Battle Furnace: when you spend Furnace Heat on Venting Strike while Bloodied, add another Proficiency Bonus to the damage. This stacks with Venting Strike.",
            "duration": "",
            "limit": "Requires selected Refined expression, Bloodied state, and a qualifying Venting Strike spend.",
            "counterplay": "Keep the cultivator from being Bloodied or deny qualifying hits.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Alchemy Heart",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined passive rider",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution — Alchemy Heart: when you spend Furnace Heat on Furnace Guard against medicine, poison, acid, disease, digestion, impurity, pill-impurity, or body-furnace backlash damage, increase the reduction by another Proficiency Bonus. This stacks with Furnace Guard.",
            "duration": "",
            "limit": "Requires selected Refined expression and qualifying Furnace Guard spend.",
            "counterplay": "Does not improve Guard against damage outside the named medicine/poison/backlash scope.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          },
          {
            "name": "Hunger Furnace",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "Refined passive rider",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution — Hunger Furnace: when you spend Furnace Heat after a Hunger or digestion scene, you may also reduce one ordinary Impurity or Pill Impurity gain from that same resolved scene by 1, minimum 0. This is a rider on the Furnace Heat spend, not a second resource spend.",
            "duration": "",
            "limit": "Requires selected Refined expression and qualifying Hunger/digestion scene.",
            "counterplay": "Only reduces ordinary Impurity/Pill Impurity from the resolved scene; cannot erase major story consequences by itself.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Heart-Cauldron Body",
            "stage": "Perfected",
            "type": "No Action / Triggered",
            "trigger": "Perfected passive rider",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Perfected evolution — Heart-Cauldron Body: once per round, when you spend Furnace Heat, increase that conversion by another Proficiency Bonus. For Banked Coals this adds temporary hit points; for Furnace Guard this adds damage reduction; for Venting Strike this adds damage. This stacks with the base conversion and any selected Refined evolution.",
            "duration": "",
            "limit": "Once per round; requires Perfected stage and a legal Furnace Heat spend.",
            "counterplay": "Suppress Furnace Heat generation, force Cooling Debt, or deny qualifying conversion windows.",
            "source_spheres": [
              "Fire",
              "Yang",
              "Hunger",
              "Alchemy",
              "Poison",
              "Disease",
              "Berserker",
              "Brute",
              "Iron Fist",
              "Blacksmith",
              "Blood",
              "Life"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Fire",
          "Yang",
          "Hunger",
          "Alchemy",
          "Poison",
          "Disease",
          "Berserker",
          "Brute",
          "Iron Fist",
          "Blacksmith",
          "Blood",
          "Life"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Furnace Overheat",
            "severity": "1-3",
            "fixed_effects": {
              "1": "Fixed Furnace Heart Scope DCs increase by +2 if cooling/rest cycles are ignored. No feature suppression.",
              "2": "Furnace Heat cannot be generated from body-furnace techniques that ignore cooling or control. Furnace Heat can still be generated from actual backlash if the cultivator remains conscious.",
              "3": "Furnace Heat generation is suppressed until a cooling rest, treatment scene, or Foundation correction. Existing Furnace Heat can still be spent unless another explicit effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies Organ Fire or Cooling Debt.",
            "treatment": "Water cooling, Life healing, Yin balancing, medicinal bath, breath-cooling scripture, rest, or Flowing River circulation."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Organ Fire",
            "severity": "1-4",
            "injured_system": "heart, organs, blood heat, stomach furnace, chest meridians",
            "default_effect": "Fixed Furnace Heart Scope DCs increase by +2 × Severity when the action creates heat, digestion, refinement, battle frenzy, or harsh medicine pressure.",
            "stress_failure": "Failure by 5 or more increases Severity by 1.",
            "recovery": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Cooling Debt",
            "severity": "1-3",
            "fixed_effects": {
              "1": "Banked Coals grants temporary HP equal to PB instead of PB + cultivation ability modifier.",
              "2": "Furnace Heat cannot be spent on Banked Coals. Guard and Strike remain available if Furnace Heat exists.",
              "3": "Furnace Heat generation is suppressed until restoration. Failure by 5 or more on Fixed Furnace Heart Scope treatment or challenge may apply Organ Fire."
            },
            "restoration": "Cooling rest, medicinal bath, Water/Life treatment, safe meal, Alchemy purge, or breath-cooling meditation."
          }
        ],
        "deviations": [
          {
            "name": "Burn Everything Clean",
            "severity": "1-4",
            "progress": "0-3",
            "temptation": "Anything painful, impure, weak, or uncertain can be solved by burning hotter.",
            "benefit_options": [
              "Add PB fire, poison, or force damage to one attack or technique in the Fixed Furnace Heart Scope.",
              "Suppress Poisoned, Disease, fear, pain, or Exhaustion until the end of your next turn.",
              "Gain temporary HP equal to CL after taking Fixed Furnace Heart Scope damage.",
              "Reduce one ordinary Impurity or Pill Impurity consequence from the current scene by 1, minimum 0, by burning it inward."
            ],
            "cost": "Increase Deviation progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "correction": "Cool instead of burn, accept medicine, spare an impurity that has purpose, allow another to heal you, or survive without overheat."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Cooling Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation-scene cooling/treatment progress for overheat, organ fire, or cooling debt.",
          "duration": "Downtime / Foundation scene",
          "limit": "Counts once toward treating Furnace Overheat, Organ Fire, or Cooling Debt when supported by Water, Life, Alchemy, Yin, Protection, or Flowing River.",
          "counterplay": "Requires time, teacher correction, medicine, or a safe cooling method; cannot be performed during ordinary attack timing.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Furnace Heart",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Diagnose Furnace Heart through heat, poison, digestion, alchemy, or battle-fever evidence.",
          "duration": "Downtime / Foundation scene",
          "limit": "Progress Required 1–3, based on source.",
          "counterplay": "Misdiagnosis, overheat, pill flooding, or hiding battle fever may delay reveal.",
          "source_spheres": []
        },
        {
          "name": "Integrate Furnace Heart",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Integrate by pairing controlled burn with cooling, safe digestion, and organ treatment.",
          "duration": "Downtime / Foundation scene",
          "limit": "Requires three integrations: controlled burn, cooling practice, safe digestion, medicine that does not overheat, restraint while Bloodied, or treating Organ Fire.",
          "counterplay": "Furnace Overheat or Organ Fire Severity increases the Challenge DC within the fixed scope.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Body-Cauldron Scripture",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time and appropriate method/input.",
          "range": "Scene",
          "target": "Student or prepared creature",
          "attack_or_save": "",
          "effect": "Lineage/downtime inheritance only; not a combat action row unless separately rewritten as one.",
          "duration": "Downtime / Foundation scene",
          "limit": "Does not export to GM Screen combat rows by default. Disciples receive lesser Furnace Heart sparks, not the perfected personal Foundation automatically.",
          "counterplay": "Requires safe cooling doctrine, medicine, and teacher supervision; reckless copying risks Organ Fire.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "dream_mirror_soul_anchor_v0_2B",
      "name": "Dream-Mirror Soul Anchor",
      "number": 24,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened or Unstable",
        "primary_path": "Spirit Awakening",
        "secondary_path_fit": [
          "Qi Cultivation through Dreams, Illusion, Shadow, Beauty, The Hidden Eye, Water"
        ],
        "typical_role": "Striker / Mobility / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Dreams, mirrors, masks, reflections, and false selves carry spiritual weight for you. You understand illusions because part of you lives near them.",
        "visible_sign": "Reflections may lag behind your expression. Dreams remember things you tried to forget. Masks feel warm or heavy in your hands.",
        "warning": "Maintaining too many masks, denying your true name, prolonged dream travel, or letting others define you can split the anchor.",
        "dao_principle": "The self survives by learning which reflection is allowed to answer."
      },
      "resource": {
        "name": "Mirror Trace",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after a hostile creature misses you with an attack or fails a saving throw against your Fixed Dream-Mirror Scope technique/effect.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round; maximum 1 Mirror Trace.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Avoid targeting the anchor directly, use effects outside the Fixed Dream-Mirror Scope, attack allies instead, or suppress Mirror Trace generation through Mirror Split or False Face Strain.",
        "spends": [
          "Reflection Cut",
          "False-Image Guard",
          "True-Name Witness",
          "Dream-Mirror Domain"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Mirror-Root Reserve",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: maximum Path resource increases by PB. Integrated: maximum Path resource increases by another PB, stacking with the base passive. This resource increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit.",
            "counterplay": "Suppress or damage the Foundation through Mirror Split, Torn Reflection, False Face Strain, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "Generate Mirror Trace",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after a hostile creature misses you with an attack or fails a saving throw against your Fixed Dream-Mirror Scope technique/effect.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering miss or failed save resolves, gain 1 Mirror Trace, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same event that generated it.",
            "duration": "Instant",
            "limit": "Once per round; maximum 1 Mirror Trace.",
            "counterplay": "Avoid targeting the anchor directly, use effects outside the Fixed Dream-Mirror Scope, attack allies instead, or suppress Mirror Trace generation through Mirror Split or False Face Strain.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "Reflection Cut",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a creature or it fails a save against your later Fixed Dream-Mirror Scope attack/technique/effect.",
            "cost": "Spend 1 Mirror Trace",
            "range": "One target of triggering hit/effect",
            "target": "One target of triggering hit/effect",
            "attack_or_save": "",
            "effect": "Spend 1 Mirror Trace to add PB psychic or force damage to that later hit or damaging effect. Choose the damage type when you spend the resource.",
            "duration": "Instant",
            "limit": "Requires 1 Mirror Trace; cannot be used on the same event that generated the Trace.",
            "counterplay": "No benefit if the later effect does not deal damage or is outside the Fixed Dream-Mirror Scope. Resistance/immunity to the chosen damage type applies normally.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "False-Image Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take damage from a creature you can perceive, after damage is rolled and before it is applied.",
            "cost": "Spend 1 Mirror Trace + Reaction",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Mirror Trace and your Reaction to reduce that damage by PB + cultivation ability modifier. The reflection takes the first part of the blow, then tears away.",
            "duration": "Instant",
            "limit": "Requires 1 Mirror Trace and your Reaction.",
            "counterplay": "Cannot be used while you cannot perceive the damaging source. Effects that bypass reactions or suppress Foundation resources prevent this conversion.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "True-Name Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you roll a Fixed Dream-Mirror Scope check or saving throw and before the outcome is known.",
            "cost": "Spend 1 Mirror Trace",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Fixed Dream-Mirror Scope check/save",
            "effect": "Spend 1 Mirror Trace to add PB to the roll. This represents remembering which self is allowed to answer.",
            "duration": "Instant",
            "limit": "Requires 1 Mirror Trace.",
            "counterplay": "No benefit outside the Fixed Dream-Mirror Scope. Effects that block Foundation resources or sever true-name stability prevent this conversion.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Truth Behind the Mask",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Mirror Trace on True-Name Witness against illusion, dream, disguise, memory, charm, possession, or identity manipulation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with True-Name Witness: add another PB to the same roll. On success, learn one symbolic truth about the source, such as fear, method, false layer, emotional hook, or whether it is external, self-made, or spirit-borne.",
            "duration": "Instant",
            "limit": "Requires selecting Truth Behind the Mask as a Refined expression.",
            "counterplay": "The truth is symbolic, not complete stat revelation. Stronger secrecy, Void, or domain authority may require a Foundation Challenge or opposed check.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "Mirror-Step Reflex",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Mirror Trace on False-Image Guard.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with False-Image Guard: after the damage reduction resolves, move up to 10 feet without provoking opportunity attacks from the damaging creature. If this movement puts you behind cover or outside the source’s reach before a continuing multi-hit sequence, later hits must still have a legal target.",
            "duration": "Instant",
            "limit": "Requires selecting Mirror-Step Reflex as a Refined expression.",
            "counterplay": "Does not cancel the triggering damage after it has been applied. Movement must be physically possible and cannot pass through sealed barriers.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "Dream-Reflection Counter",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Mirror Trace on Reflection Cut against a creature affected by your Dreams, Illusion, Shadow, Beauty, The Hidden Eye, Water-memory, or Spirit-facing technique.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Reflection Cut: the target also takes a -PB penalty to the next Insight, Perception, or attack roll it makes against you before the end of its next turn.",
            "duration": "Instant",
            "limit": "Requires selecting Dream-Reflection Counter as a Refined expression.",
            "counterplay": "The penalty ends after one qualifying roll or at the end of the target’s next turn. Creatures immune to perception/identity disruption may ignore the penalty.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          },
          {
            "name": "Stable True Name",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Mirror Trace on True-Name Witness during treatment, repair, Foundation Challenge, or Method-correction for Mirror Split, Torn Reflection, False Face Strain, or False Self.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with True-Name Witness: add another PB to the same roll. On success, remove 1 False Self progress or count the scene as one stabilization toward Dream-Mirror integration.",
            "duration": "Instant",
            "limit": "Requires selecting Stable True Name as a Refined expression.",
            "counterplay": "Cannot remove Severity by itself; it supports the normal recovery or integration route.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Dream-Mirror Domain",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while holding Mirror Trace.",
            "cost": "Spend 1 Mirror Trace + 2 Path resource",
            "range": "Self, 30-foot Emanation",
            "target": "Self, 30-foot Emanation",
            "attack_or_save": "",
            "effect": "Perfected evolution. Spend 1 Mirror Trace and 2 Path resource to create a 30-foot Emanation for 1 minute. While active, your Mirror Trace trigger can come from hostile misses or failed Fixed Dream-Mirror Scope saves against you or an ally in the domain, and once per round when you spend Mirror Trace, increase the numeric benefit by PB. If you willingly deny your true identity to exploit the domain, the domain ends and you gain False Face Strain Severity 1.",
            "duration": "1 minute",
            "limit": "Perfected only; once per combat or major scene. Requires 1 pre-existing Mirror Trace and 2 Path resource. Domain amplification applies once per round to one numeric Mirror Trace conversion.",
            "counterplay": "Break concentration-like domain control by Incapacitating the anchor, forcing them out of the scene, overpowering the domain with superior domain authority, exploiting the true-identity clause, or fighting outside Fixed Dream-Mirror Scope.",
            "source_spheres": [
              "Dreams",
              "Illusion",
              "Shadow",
              "Beauty",
              "The Hidden Eye",
              "Water",
              "Music",
              "Spirit Companions",
              "Fate",
              "Dark"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Dreams",
          "Illusion",
          "Shadow",
          "Beauty",
          "The Hidden Eye",
          "Water",
          "Music",
          "Spirit Companions",
          "Fate",
          "Dark"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Mirror Split",
            "severity_range": "1-3",
            "trigger": "Prolonged illusion use, dream travel, possession attempts, identity contradiction, false-name dependence, maintaining too many masks, or denying the true self.",
            "fixed_ladder": {
              "Severity 1": "Fixed Dream-Mirror Scope treatment, repair, challenge, and Method-correction DCs increase by +2 when the scene deepens false-self contradiction, false-name dependence, or dream/mirror instability.",
              "Severity 2": "As Severity 1. Mirror Trace cannot be generated from the triggering false-self, dream, mirror, or identity scene after the Foundation is stressed.",
              "Severity 3": "Mirror Trace generation is suppressed until rest or Foundation correction. Existing Mirror Trace can still be spent unless a separate effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies or worsens Torn Reflection, or advances False Self if the temptation is active.",
            "suppression": "True-name rite, trusted witness, mirror meditation, dream confession, The Hidden Eye diagnosis, Spirit Companion grounding, Water reflection, or Music harmony.",
            "integration": "Complete three stabilizations: name the self, reject a false role, reconcile a mask, stabilize dream reflection, accept witness, or treat Torn Reflection."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Torn Reflection",
            "severity_range": "1-4",
            "injured_system": "Soul Anchor, dream self, memory self, reflected aura, true-name channel",
            "default_effect": "Fixed Dream-Mirror Scope DCs increase by +2 × Severity when the roll involves dream, illusion, memory, identity, charm, possession, true-name stability, Dream-Mirror repair, or Dream-Mirror Foundation Challenge.",
            "stress_failure": "Failure by 5 or more increases Severity by 1.",
            "treatment_path": "True-name rite, trusted witness, dream confession, mirror breaking, The Hidden Eye diagnosis, Spirit Companion anchor, Music harmony, or Water reflection.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "False Face Strain",
            "severity_range": "1-3",
            "fixed_ladder": {
              "Severity 1": "True-Name Witness cannot be used.",
              "Severity 2": "As Severity 1, and Mirror Trace cannot be generated from hostile attack misses; it can only be generated from failed saves against your Fixed Dream-Mirror Scope techniques/effects.",
              "Severity 3": "As Severity 2, and Dream-Mirror Domain cannot be activated; False-Image Guard cannot be used until False Face Strain is restored."
            },
            "trigger": "Possession pressure, false identity triumphing, failed dream journey, mask breaking, public identity collapse, charm/fear failure by 5 or more, or exploiting Dream-Mirror Domain by denying the true self.",
            "restoration": "True-name affirmation, trusted witness, mirror rite, dream waking, Spirit Companion grounding, removing false mask, Music harmony, Water reflection, or successful Foundation Challenge check."
          }
        ],
        "deviations": [
          {
            "name": "False Self",
            "severity_range": "1-4",
            "progress": "0-3",
            "temptation": "The mask is safer than the self. The reflection can suffer instead of you.",
            "benefit_options": [
              "Gain 1 Mirror Trace after a Fixed Dream-Mirror Scope deception, disguise, dream, illusion, or identity action even if the once-per-round generation was already used.",
              "Add PB to one Fixed Dream-Mirror Scope Deception, Performance, Stealth, disguise, dream, illusion, or identity roll after rolling but before outcome.",
              "Reduce one attack roll, Insight check, or Perception check against you by PB by letting a false reflection answer.",
              "Suppress fear, shame, charm, or memory pain for one scene by moving it into a mask."
            ],
            "cost": "Increase False Self progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "escalation": "At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "correction": "Tell the truth when costly, let a trusted witness see you, reject a perfect mask, accept memory pain, reconcile a false role, or restore the true-name channel."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "True-Name Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: speak, write, dream, or witness the true name/self in a scene that addresses Mirror Split, Torn Reflection, False Face Strain, or False Self.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Trusted Witness Meditation",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: a trusted ally, teacher, or Spirit Companion witnesses one true memory or mask without control; counts toward integration or treatment.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Mirror-Breaking Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: break or set aside a false reflection, mask, dream role, or imposed identity without erasing the useful lesson it carried.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Dream-Mirror Anchor",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: dream trial, mirror omen, The Hidden Eye diagnosis, possession survival, illusion failure, true-name rite, or mask collapse reveals the anchor.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Integrate Dream-Mirror Anchor",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: name the true self, reconcile one mask, reject one False Self shortcut, survive a dream trial, accept witness, or treat Torn Reflection.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Redirect Dream-Mirror Anchor",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: redirect toward True Mirror Anchor, Mask-Dancer Soul Anchor, Nightmare Reflection Anchor, Dream Witness Anchor, or Fate-Reflection Root through compatible spheres and teacher guidance.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Minor Mirror Sense Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: teach a lesser diagnostic or selfhood practice that helps a student notice illusion, dream intrusion, false names, and identity pressure without granting the full Foundation automatically.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Mask-Heart Anchor Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, identity/memory/dream support, and appropriate teacher, witness, rite, or treatment.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: preserve a mask reconciliation rite for spies, performers, dream-walkers, beauty-reflection students, or Spirit Awakening disciples.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, a compatible witness/rite/method, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "star_sovereign_core_imprint_v0_2B",
      "name": "Star-Sovereign Core Imprint",
      "number": 25,
      "profile": {
        "grade": "Legendary",
        "status": "Stable",
        "default_stage": "Latent or Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Spirit Awakening through Stars, Fate, Radiance, Space, Dreams, The Hidden Eye"
        ],
        "typical_role": "Striker / Defender / Controller",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your dantian or core responds to starlight, distance, memory, omens, and old light. Night cultivation feels unusually clear, but the core can drift away from the living present.",
        "visible_sign": "During meditation, tiny lights may appear around the navel, brow, or palms. You may remember places you have never visited when looking at stars.",
        "warning": "Detachment, ignoring the present, overreliance on omens, and cold celestial methods can distance the core from the living body.",
        "dao_principle": "The core remembers light that left long before the body was born."
      },
      "resource": {
        "name": "Old Light",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after you spend Path resource on a Fixed Star-Sovereign Scope technique/effect that affects a creature, point, omen, mark, or trace.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round; maximum 1 Old Light; one Star Mark by default.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny Path resource expenditure, prevent the effect from involving a legal Fixed Star-Sovereign Scope target/trace, suppress Old Light generation through Distant Core Strain, or sever/conceal the mark.",
        "spends": [
          "Sovereign Ray",
          "Distant Core Guard",
          "Omen Witness",
          "Memory of Distance",
          "Star-Sovereign Core State"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Old-Light Core Reserve",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: maximum Path resource increases by PB. Integrated: maximum Path resource increases by another PB, stacking with the base passive. This increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit.",
            "counterplay": "Suppress or damage the Foundation through Distant Core, Cold Star Isolation, Distant Core Strain, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Generate Old Light",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after you spend Path resource on a Fixed Star-Sovereign Scope technique/effect that affects a creature, point, omen, mark, or trace.",
            "cost": "Path resource already spent on triggering technique/effect",
            "range": "Self and one involved target/point/trace",
            "target": "Self and one involved target/point/trace",
            "attack_or_save": "",
            "effect": "After the triggering effect resolves, gain 1 Old Light, maximum 1, and create or refresh one Star Mark on a creature, point, omen, or trace involved in that effect. Old Light fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same event that generated it.",
            "duration": "Until end of next turn",
            "limit": "Once per round; maximum 1 Old Light; one Star Mark by default.",
            "counterplay": "Deny Path resource expenditure, prevent the effect from involving a legal Fixed Star-Sovereign Scope target/trace, suppress Old Light generation through Distant Core Strain, or sever/conceal the mark.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Sovereign Ray",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a Star-Marked target with a Fixed Star-Sovereign Scope attack/technique, or after a Star-Marked target fails a save against your Fixed Star-Sovereign Scope technique/effect.",
            "cost": "Spend 1 Old Light",
            "range": "One Star-Marked target",
            "target": "One Star-Marked target",
            "attack_or_save": "",
            "effect": "Spend 1 Old Light to add PB radiant, cold, force, or psychic damage to that hit or damaging effect. Refined and Perfected evolutions that name Sovereign Ray stack with this base conversion.",
            "duration": "Instant",
            "limit": "Requires 1 Old Light; cannot spend on the same event that generated the Old Light.",
            "counterplay": "Avoid or remove Star Mark, suppress Old Light, resist the triggering hit/save, gain resistance/immunity to the chosen damage type, or force Distant Core Strain.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Distant Core Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you take radiant, cold, force, psychic, fate, space, teleportation, falling-star, omen, or memory damage/effect inside Fixed Star-Sovereign Scope.",
            "cost": "Spend 1 Old Light + Reaction",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Old Light and your Reaction to reduce the triggering damage by PB + cultivation ability modifier. If the effect also moves, blinds, scrambles memory, isolates space, or fate-binds you, this reduction does not cancel that non-damage portion unless another evolution says so.",
            "duration": "Instant",
            "limit": "Requires 1 Old Light and Reaction; cannot spend on the same event that generated the Old Light.",
            "counterplay": "Use non-scoped damage, exhaust reaction, suppress Old Light, apply Distant Core Strain, or use a higher-authority effect that cannot be delayed by old light.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Omen Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you roll a Fixed Star-Sovereign Scope check/save before the GM declares the outcome.",
            "cost": "Spend 1 Old Light",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Old Light to add PB to the roll. Refined and Perfected evolutions that name Omen Witness stack with this base conversion.",
            "duration": "Instant",
            "limit": "Requires 1 Old Light; one bonus to the triggering roll from this conversion.",
            "counterplay": "Suppress Old Light, use a roll outside Fixed Star-Sovereign Scope, impose Distant Core/Cold Star Isolation penalties, or block omen/fate/distance perception.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Delayed Starlight",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Old Light on Distant Core Guard against radiant, cold, force, psychic, fate, space, falling-star, teleportation, or memory damage.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Distant Core Guard: increase the same damage reduction by PB. If you end your next turn under open sky, starlight, a celestial Formation, or a compatible Stars/Space/Radiance effect, gain temp HP equal to PB.",
            "duration": "Instant",
            "limit": "Requires selecting Delayed Starlight as a Refined expression.",
            "counterplay": "Suppressed if Distant Core Guard is not legal; enclosed anti-star spaces, anti-divination fields, or Distant Core Strain can deny the temp HP rider.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Omen Core",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Old Light on Omen Witness for a Stars, Fate, Space, The Hidden Eye, Dreams, omen, celestial sign, or long-distance perception roll.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Omen Witness: add another PB to the same roll. If the roll still fails, you learn whether the obstacle was concealment, fate protection, space disruption, memory alteration, or insufficient information.",
            "duration": "Instant",
            "limit": "Requires selecting Omen Core as a Refined expression.",
            "counterplay": "False omens, stronger concealment, Distant Core, Cold Star Isolation, or lack of a real trace may still block useful information.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Memory of Distance",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When a Star-Marked creature moves, hides, turns invisible, teleports, leaves line of sight, or shifts through a dream/space/fate trace before the mark ends.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. You may spend Old Light on Omen Witness for the tracking/perception roll even if the roll is created by this rider. If you do, it stacks with Omen Witness and lets you know the creature’s direction until the start of your next turn on a success.",
            "duration": "Instant",
            "limit": "Requires selecting Memory of Distance as a Refined expression.",
            "counterplay": "Total trace erasure, stronger Void/Space/Fate protection, or no legal Star Mark prevents this rider.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          },
          {
            "name": "Star-Forging Core",
            "stage": "Refined",
            "type": "Downtime / Foundation Scene",
            "trigger": "During Technique Forging, item work, star-map study, celestial Formation work, or observatory cultivation using Stars, Fate, Space, Radiance, The Hidden Eye, Dreams, Formations, Ink, or Sword.",
            "cost": "",
            "range": "Foundation project",
            "target": "Foundation project",
            "attack_or_save": "",
            "effect": "Refined evolution. Reduce the Technique Forging or Foundation project DC by 2 when the work is performed under night sky, star map, observatory, celestial Formation, or old-light inheritance. If material cost is tracked, reduce appropriate celestial mapping/diagnostic/material cost by 25%. Not a combat action.",
            "duration": "Instant",
            "limit": "Requires selecting Star-Forging Core as a Refined expression; downtime/Foundation-scene only.",
            "counterplay": "No appropriate site/map/observatory/support, hostile omen pollution, Distant Core Strain, or non-celestial project scope blocks the benefit.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Star-Sovereign Core State",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while you hold Old Light and are not under Distant Core Strain Severity 3.",
            "cost": "Spend 1 Old Light + 2 Path resource",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Perfected state. Spend 1 Old Light and 2 Path resource to enter Star-Sovereign Core State for 1 minute. Once per round while active, when you generate Old Light, you may maintain two Star Marks instead of one until the end of your next turn. Once per round when you spend Old Light, increase one numeric benefit of the chosen conversion by PB. If you create three or more Star Marks during the state without taking a present-tense physical, social, or emotional action in the scene, apply Distant Core Strain Severity 1 when the state ends.",
            "duration": "1 minute",
            "limit": "Perfected; once per combat or major scene.",
            "counterplay": "Suppress Old Light generation, force Distant Core Strain, isolate from stars/omens/traces, break present-tense grounding, or use stronger Fate/Space/Void concealment.",
            "source_spheres": [
              "Stars",
              "Fate",
              "Radiance",
              "Space",
              "The Hidden Eye",
              "Dreams",
              "Water",
              "Sword",
              "Weather",
              "Formations",
              "Ink"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Stars",
          "Fate",
          "Radiance",
          "Space",
          "The Hidden Eye",
          "Dreams",
          "Water",
          "Sword",
          "Weather",
          "Formations",
          "Ink"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Distant Core",
            "severity_range": "1-3",
            "trigger": "Neglecting body, relationships, hunger, warmth, immediate duty, present danger, or living consequence in favor of omens, distance, memory, cold fate, or celestial abstraction.",
            "fixed_ladder": {
              "Severity 1": "Fixed Star-Sovereign Scope treatment, repair, challenge, and Method-correction DCs increase by +2 when the scene requires embodiment, warmth, present attention, social connection, or immediate response.",
              "Severity 2": "As Severity 1. Old Light cannot be generated from the triggering detached omen/distance scene after the Foundation is stressed.",
              "Severity 3": "Old Light generation is suppressed until rest or Foundation correction. Existing Old Light can still be spent unless a separate effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies or worsens Cold Star Isolation, or advances Heaven-Looking Detachment if the temptation is active.",
            "suppression": "Hearth cultivation, shared meal, physical training, companion vow, Life warmth, Music grounding, Earth practice, immediate duty, or present-tense sacrifice.",
            "integration": "Complete three grounding acts: bodily care, emotional presence, immediate duty, companion bond, present-tense sacrifice, or choosing one person over distant fate."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Cold Star Isolation",
            "severity_range": "1-4",
            "injured_system": "dantian core, memory channels, heart-mind, fate threads, perception meridians",
            "visible_symptoms": "Cold skin under starlight, forgetting recent warmth, distant gaze, emotional delay, dreams of empty heavens.",
            "default_effect": "Fixed Star-Sovereign Scope DCs increase by +2 × Severity when the roll involves present embodiment, emotional connection, memory stability, fate reading, celestial cultivation, social trust, Life recovery, or breakthrough grounding.",
            "stress_failure": "Failure by 5 or more increases Severity by 1.",
            "treatment_path": "Hearth cultivation, Life warmth, Music grounding, Earth body practice, trusted companion vow, memory rite, Dream reconciliation, or present-tense service.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Distant Core Strain",
            "severity_range": "1-3",
            "trigger": "Overuse of Star Marks, failed fate reading, emotional abandonment, memory shock, spatial isolation, ending Perfected state detached from the scene, or ignoring present danger for cold celestial abstraction.",
            "fixed_ladder": {
              "Severity 1": "Generate Old Light is unavailable until the end of your next turn after the first legal trigger in a scene.",
              "Severity 2": "As Severity 1, and Star-Sovereign Core State cannot be activated.",
              "Severity 3": "Old Light generation and Omen Witness are suppressed until rest or Foundation correction; failure by 5 or more on a Fixed Star-Sovereign Scope roll applies or worsens Cold Star Isolation."
            },
            "restoration": "Bodily action, emotional presence, accepting warmth, shared meal, Earth grounding, Music rite, Life treatment, or successful Foundation Challenge check."
          }
        ],
        "deviations": [
          {
            "name": "Heaven-Looking Detachment",
            "severity_range": "1-4",
            "progress": "0-3",
            "temptation": "Look farther. The present is small. People are brief. Fate matters more than feeling.",
            "benefit_options": [
              "Gain 1 Old Light after a Fixed Star-Sovereign Scope omen or distance scene even if normal generation is unavailable.",
              "Add PB to one Stars, Fate, Space, The Hidden Eye, Dreams, omen, memory, or long-distance perception roll.",
              "Impose −1 on one target’s save against a compatible celestial technique.",
              "Delay one fear, charm, grief, or emotional consequence for the scene."
            ],
            "cost": "Increase Deviation progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "escalation": "At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "correction": "Choose the present over the omen, act for one person instead of fate, accept grief now, ground under daylight, or give up a prediction to save someone.",
            "possible_transformation": "Star-Sovereign Domain, Cold Fate Heart Demon, Night Guardian Anchor, or Memory Star Root."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Hearth Grounding",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: shared meal, bodily care, Earth grounding, Life warmth, Music rite, or companion vow reduces Distant Core, Cold Star Isolation, or Distant Core Strain when the scene restores present-tense embodiment.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Memory Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: Water, Dreams, The Hidden Eye, or Spirit Companions scene stabilizes memory channels and reconnects old light to current relationships.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Daylight Body Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: physical training, daylight grounding, guard duty, or immediate service anchors celestial perception back into the living body.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Star-Sovereign Core",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: night tribulation, Stars training, Fate omen, The Hidden Eye diagnosis, celestial Formation, dream of old light, or failed Core Formation glimpse reveals the imprint.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Integrate Old Light",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: read an omen but choose the present, ground the body, protect one person over abstraction, treat Cold Star Isolation, and complete celestial training under a teacher.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Redirect Star Core",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: redirect toward Night Guardian Core, Star-Sword Core, Fate Observatory Root, Memory Star Anchor, or Radiant Star Vessel through compatible spheres and teacher guidance.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Star Sect Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Student, sect group, observatory, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: preserve the Foundation as a star sect, observatory lineage, night-court rite, fate-reading house, or star-map scripture. Disciples usually receive a lesser trace, not the full Mythic Foundation.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Night Meditation Affinity",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, diagnosis scene, teacher correction, lineage scene, or Foundation Challenge scene.",
          "cost": "Scene time, compatible teacher/treatment/site, and present-tense grounding.",
          "range": "Scene",
          "target": "Student, sect group, observatory, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: teach a lesser Night Meditation Affinity, Minor Star Root, Omen Eye, Star Map Meridian, or long-distance guardian practice. Not a GM Screen combat action by default.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, grounding, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "iron_oath_skin_v0_2B",
      "name": "Iron Oath Skin",
      "number": 26,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Qi Cultivation",
          "Spirit Awakening"
        ],
        "typical_role": "Defender / Striker / Mobility",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your skin, scars, and posture respond to promises of defense. You are harder to break when protecting something you actually named and defended.",
        "visible_sign": "Old scars darken like iron under pressure. When you swear to guard someone or something, your skin may feel heavy, tight, or armored.",
        "warning": "Breaking a protection oath, abandoning someone you swore to guard, or using protection as control may strain the skin.",
        "dao_principle": "Skin becomes iron when the soul has decided what it will not allow through."
      },
      "resource": {
        "name": "Guarding Iron",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after a hostile attack or technique damages you while you are defending a declared protected subject and you remain conscious.",
        "timing": "After Trigger Resolves",
        "frequency": "Once per round; maximum 1 Guarding Iron.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Avoid attacking the oath bearer in protected context, separate them from the subject, suppress Guarding Iron through Broken Guard, or exploit oath conflict.",
        "spends": [
          "Iron Oath Guard",
          "Oath-Mark Strike",
          "Stand-Fast Witness",
          "Oath-Skin Mantle",
          "Iron Oath Boundary"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Oath-Skin Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is available.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: maximum HP increases by PB. Integrated: maximum HP increases by another PB, stacking with the base passive. This HP increase is not recalculated or removed mid-scene unless the Foundation is fully severed by explicit story effect.",
            "duration": "Instant",
            "limit": "Passive Foundation benefit.",
            "counterplay": "Suppress or damage the Foundation through Oath-Bound Rigidity, Broken Guard, Iron Scar Constriction, or sever/replace projects; ordinary dispels do not remove this passive.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Declare Protected Subject",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "At initiative, or when a protected duty clearly appears in a scene.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Name one meaningful protected subject: one ally, one object, one doorway, one warded place, one helpless creature, or one duty. Iron Oath features require you to be actually defending that subject; artificial declarations do not qualify.",
            "duration": "Instant",
            "limit": "One active protected subject at a time unless a Perfected boundary says otherwise.",
            "counterplay": "Enemies may separate you from the subject, force movement, obscure lines, bait oath conflict, or attack other priorities. The GM may reject artificial declarations.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Generate Guarding Iron",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after a hostile attack or technique damages you while you are defending a declared protected subject and you remain conscious.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the triggering damage resolves, gain 1 Guarding Iron, maximum 1. It fades at the end of your next turn. If already held, refresh expiration instead of stacking. Cannot be spent on the same event that generated it.",
            "duration": "Instant",
            "limit": "Once per round; maximum 1 Guarding Iron.",
            "counterplay": "Avoid attacking the oath bearer in protected context, separate them from the subject, suppress Guarding Iron through Broken Guard, or exploit oath conflict.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Iron Oath Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you or an ally within 5 feet of you takes damage while you are defending a declared protected subject.",
            "cost": "Spend 1 Guarding Iron",
            "range": "Self or ally within 5 ft",
            "target": "Self or ally within 5 ft",
            "attack_or_save": "",
            "effect": "Spend 1 Guarding Iron to reduce the triggering damage by PB + cultivation ability modifier. This cannot be used on the same damage event that generated the Guarding Iron.",
            "duration": "Instant",
            "limit": "Requires 1 Guarding Iron; one Reaction.",
            "counterplay": "Force the oath bearer to spend their Reaction, attack outside 5 feet, suppress Guarding Iron, or create conflicting protected subjects.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Oath-Mark Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you hit a creature with a weapon attack or compatible technique, or after a creature fails a save against your Fixed Iron Oath Scope technique.",
            "cost": "Spend 1 Guarding Iron",
            "range": "One qualifying target",
            "target": "One qualifying target",
            "attack_or_save": "",
            "effect": "Spend 1 Guarding Iron to add PB damage to the hit or damaging effect. The added damage matches the attack/effect, or is force if the technique needs oath-pressure expression. The target must have damaged, moved toward, threatened, or attempted to bypass your protected subject this combat.",
            "duration": "Instant",
            "limit": "Requires 1 Guarding Iron; cannot apply to the same event that generated the Guarding Iron.",
            "counterplay": "Avoid threatening the protected subject, suppress Guarding Iron, or use immunity/resistance against the underlying attack. The GM may deny artificial target qualification.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Stand-Fast Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you roll a Fixed Iron Oath Scope check or saving throw.",
            "cost": "Spend 1 Guarding Iron",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Guarding Iron to add PB to the roll. This most often applies against forced movement, fear, charm, domination, disarm, being bypassed, oath interpretation, Iron Oath repair, or Foundation Challenge pressure.",
            "duration": "Instant",
            "limit": "Requires 1 Guarding Iron; one qualifying roll.",
            "counterplay": "Use effects outside Fixed Iron Oath Scope, suppress Guarding Iron, or pressure a protected subject through routes the oath bearer cannot witness or contest.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Iron Interposition",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Guarding Iron on Iron Oath Guard for an adjacent ally.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Iron Oath Guard: increase the damage reduction by PB. If the protected subject is the ally named by your declared oath, you may also move 5 feet toward that ally before the reduction, if that movement is possible.",
            "duration": "Instant",
            "limit": "Requires selecting Iron Interposition as a Refined expression.",
            "counterplay": "Separate the oath bearer from the ally, prevent movement, exhaust their Reaction, or suppress Guarding Iron.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Oath-Skin Mantle",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you generate Guarding Iron while defending a declared protected subject.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Gain temporary HP equal to PB. This is in addition to the Guarding Iron gained; it does not spend Guarding Iron. Temporary HP follows normal non-stacking rules.",
            "duration": "Instant",
            "limit": "Requires selecting Oath-Skin Mantle as a Refined expression; once per round through the Guarding Iron trigger.",
            "counterplay": "Prevent Guarding Iron generation, attack another priority, or use effects that bypass temporary HP through explicit rules.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Scar-Ledger Defense",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Guarding Iron on Stand-Fast Witness against fear, charm, domination, forced movement, disarm, or bypass pressure.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Stand-Fast Witness: add another PB to the same roll. If the roll succeeds, the source cannot willingly move through your space until the end of its current turn unless it teleports or is at least two sizes larger than you.",
            "duration": "Instant",
            "limit": "Requires selecting Scar-Ledger Defense as a Refined expression.",
            "counterplay": "Use non-movement routes, teleportation, size advantage, or effects outside Fixed Iron Oath Scope.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          },
          {
            "name": "Shield-Body Forging",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you make a Technique Forging or Foundation Challenge roll for Guardian, Protection, Shield, Metal, Iron Fist, Karma, Chains, or Warleader that includes a declared protected-subject limitation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Reduce the DC by 2. This is a cultivation/project rider, not a combat action, and it does not grant any sphere or technique by itself.",
            "duration": "Instant",
            "limit": "Requires selecting Shield-Body Forging as a Refined expression; project/challenge scenes only.",
            "counterplay": "The technique must actually include a duty, ward, oath, protected-subject limitation, or defensive drawback.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Iron Oath Boundary",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while defending a declared protected subject and able to name a boundary subject.",
            "cost": "Spend 1 Guarding Iron + 2 Path resource",
            "range": "Self, 15-ft Emanation",
            "target": "Self, 15-ft Emanation",
            "attack_or_save": "",
            "effect": "Perfected state. Spend 1 Guarding Iron and 2 Path resource to create a 15-ft Emanation for 1 minute, once per combat or major scene. Name one protected subject inside or adjacent to the boundary. While you defend that subject: Iron Oath Guard and Stand-Fast Witness each gain another +PB when used inside the boundary, chosen allies gain PB temporary HP when the boundary appears, and once per round an enemy attack/check/save to force, frighten, charm, dominate, disarm, or bypass you toward the protected subject is rolled with disadvantage or your saving throw is rolled with advantage. If you willingly abandon the named subject, the boundary ends and Broken Guard Strain Severity 1 applies.",
            "duration": "1 minute",
            "limit": "Perfected; once per combat or major scene; requires 1 Guarding Iron and 2 Path resource.",
            "counterplay": "Force abandonment, split protected duties, suppress Guarding Iron, pull the subject out of the boundary, use teleportation or non-hostile routes, or impose Broken Guard Strain.",
            "source_spheres": [
              "Metal",
              "Protection",
              "Guardian",
              "Shield",
              "Iron Fist",
              "Wrestling",
              "Athletics",
              "Karma",
              "Warleader",
              "Retribution",
              "Chains"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Metal",
          "Protection",
          "Guardian",
          "Shield",
          "Iron Fist",
          "Wrestling",
          "Athletics",
          "Karma",
          "Warleader",
          "Retribution",
          "Chains"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "name": "Oath-Bound Rigidity",
            "severity_range": "1-3",
            "trigger": "Refusing all retreat, refusing healing, treating flexibility as betrayal, controlling protected allies, overusing guard duty as identity, or taking unnecessary wounds to prove loyalty.",
            "fixed_ladder": {
              "Severity 1": "Fixed Iron Oath Scope treatment, repair, challenge, and Method-correction DCs increase by +2 when the scene requires flexibility, trust, retreat, healing, or allowing another creature autonomy.",
              "Severity 2": "As Severity 1. Guarding Iron cannot be generated from a scene where you are protecting by controlling the protected subject or refusing all retreat/healing.",
              "Severity 3": "Guarding Iron generation is suppressed until rest or Foundation correction. Existing Guarding Iron can still be spent unless Broken Guard or another explicit effect blocks it."
            },
            "stress_failure": "Failure by 5 or more applies or worsens Iron Scar Constriction, or increases Martyr-Iron Deviation if the temptation is active.",
            "suppression": "Accept help, allow an ally choice, make a strategic retreat, clarify the vow, use a Karma witness rite, receive Life healing, or undergo Music softening.",
            "integration": "Complete three acts: protect without controlling, retreat without abandoning, accept healing, clarify oath, let another guard you, or protect a subject who chose their own risk."
          }
        ],
        "hidden_injuries": [
          {
            "name": "Iron Scar Constriction",
            "severity_range": "1-4",
            "injured_system": "skin, scars, fascia, oath channels, shoulders, heart-guard meridians",
            "default_effect": "Fixed Iron Oath Scope DCs increase by +2 × Severity when the roll requires flexibility, healing, armor release, oath reinterpretation, retreat with a protected subject, or accepting protection from another.",
            "stress_failure": "Failure by 5 or more increases Severity by 1.",
            "treatment_path": "Life scar release, Karma oath clarification, Music relaxation, Flowing River movement, Metal retempering, and trusted ally guard exchange.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "name": "Broken Guard",
            "severity_range": "1-3",
            "fixed_ladder": {
              "Severity 1": "Iron Oath Guard cannot reduce damage for allies; it can still reduce your own damage if the protected subject is not the abandoned subject.",
              "Severity 2": "As Severity 1, and Guarding Iron cannot be generated while defending the abandoned or betrayed subject until restitution or correction occurs.",
              "Severity 3": "Guarding Iron generation is suppressed, and Iron Oath Boundary cannot be activated until Broken Guard is restored."
            },
            "trigger": "Knowingly abandoning a protected subject, failing a protection oath, being forced aside by a failed Fixed Iron Oath Scope roll by 5 or more, or causing harm through overprotection.",
            "restoration": "Apology, restitution, renewed oath, protecting without control, accepting judgment, or successfully guarding the harmed party."
          }
        ],
        "deviations": [
          {
            "name": "Martyr-Iron",
            "severity_range": "1-4",
            "progress": "0-3",
            "temptation": "If you suffer enough, the oath is proven. If you survive, you were right.",
            "benefit_options": [
              "Gain 1 Guarding Iron after taking damage for a protected subject even if the once-per-round generation was already used.",
              "Reduce one damage instance by CL while you refuse retreat from a protected subject.",
              "Gain temporary HP equal to CL when you knowingly take a dangerous position between a hostile creature and a protected subject.",
              "Ignore fear, pain, forced movement disadvantage, or a Minor Hidden Injury penalty for one scene while guarding."
            ],
            "cost": "Increase Deviation progress by 1.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "escalation": "At Progress 3, increase Severity by 1 and reset Progress to 0.",
            "correction": "Accept protection from another, retreat with the protected subject, choose living duty over suffering, let an ally decide for themselves, or protect without self-punishment.",
            "possible_transformation": "Iron Martyr Heart Demon, Guardian Saint Skin, Scarred Warden Body, Compassionate Oath Boundary, or Broken Guard Scar."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Oath Clarification Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: clarify who or what is actually protected, remove control from the oath, and reduce Oath-Bound Rigidity or Broken Guard progress when the scene includes a real protected-subject decision.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Scar Retempering Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: Life, Metal, Music, Flowing River, or Protection treatment softens iron scar bands without breaking the protective vow; counts toward Iron Scar Constriction recovery.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Guard Exchange Practice",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: accept protection from another, retreat with the protected subject, or let an ally choose their own risk; counts toward integration and Martyr-Iron correction.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Iron Oath Skin",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: oath scene, scar diagnosis, Guardian trial, shield-lineage initiation, punishment-scar memory, or taking a wound for another reveals the skin as vow-bound iron.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Integrate Iron Oath Skin",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: complete three stabilizations: protect without controlling, accept protection, clarify oath, retreat strategically, treat Iron Scar Constriction, or forge a defensive technique with a declared subject.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Redirect Iron Oath Skin",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Self or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: redirect toward Guardian Saint Skin, Shield-Oath Body, Iron Chain Warden, Karmic Guard Skin, Warleader Bulwark Record, or Compassionate Oath Boundary through compatible spheres and teacher guidance.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Guard Skin Lineage",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: preserve a lesser Guard Skin, Iron Scar, or Oath Posture initiation for disciples. It teaches vow-bearing posture and protected-subject discipline, not the full Foundation automatically.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Shield Sect Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible oath/guard/repair method, and appropriate teacher, witness, treatment, or protected-subject context.",
          "range": "Scene",
          "target": "Student, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: establish Iron Oath Skin as shield sect, imperial guard, family guardian, punishment-scar scripture, or protector lineage training. Noncombat support unless a separate combat spark is written.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "beast_echo_marrow_v0_2A",
      "name": "Beast-Echo Marrow",
      "number": 27,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened or Unstable",
        "primary_path": "Body Refining",
        "secondary_path_fit": [
          "Beastmastery",
          "Spirit Awakening",
          "Blood",
          "Hunger",
          "Warleader",
          "Athletics"
        ],
        "typical_role": "Striker / Mobility / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Major beast-resonance marrow Foundation for pack rhythm, companion echo, predator pressure, safe beast digestion, Blood/Hunger danger, and controlled instinct without granting free shapeshifting.",
        "visible_sign": "",
        "warning": "No mechanical effect is defined in the source.",
        "dao_principle": "The beast outside answers because the beast inside remembers the same sky."
      },
      "resource": {
        "name": "Pack Echo",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after you hit a hostile creature with a Fixed Beast-Echo Scope attack or technique while an ally or bonded companion is within 30 ft of you or the target; or after you hit a hostile beast-aspected, predator-aspected, monstrosity, spirit beast, or demon beast.",
        "timing": "After Qualifying Hit Resolves",
        "frequency": "Once per round; max 1; expires end of next turn; same-event spend locked.",
        "expiry": "End of your next turn; refreshed, not stacked, if generated again while already held.",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Deny pack positioning, prevent qualifying hits, isolate the cultivator, use non-beast routes, suppress Beast-Echo Marrow, or force the Echo to expire.",
        "spends": [
          "Pack-Marrow Strike",
          "Marrow Pack Guard",
          "Beast-Sense Witness",
          "Predator Answer",
          "Beast-Echo Marrow State"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Beast-Marrow Frame",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Always active while the Foundation is present and not severed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Base: maximum HP increases by PB. Integrated: maximum HP increases by another PB, stacking with the base passive.",
            "duration": "Instant",
            "limit": "Always on; not a spend.",
            "counterplay": "Foundation severing, severe marrow suppression, or explicit story effects can remove or suspend it; normal suppression does not recalculate HP mid-scene.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Generate Pack Echo",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after you hit a hostile creature with a Fixed Beast-Echo Scope attack or technique while an ally or bonded companion is within 30 ft of you or the target; or after you hit a hostile beast-aspected, predator-aspected, monstrosity, spirit beast, or demon beast.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Gain 1 Pack Echo, maximum 1. Pack Echo becomes available after the hit resolves, expires at the end of your next turn, and refreshes instead of stacking. You cannot spend it on the same event that generated it.",
            "duration": "Instant",
            "limit": "Once per round; max 1; expires end of next turn; same-event spend locked.",
            "counterplay": "Deny pack positioning, prevent qualifying hits, isolate the cultivator, use non-beast routes, suppress Beast-Echo Marrow, or force the Echo to expire.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Pack-Marrow Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you, a bonded companion, or an ally within 30 ft hits a creature that qualifies for Fixed Beast-Echo Scope.",
            "cost": "Spend 1 Pack Echo",
            "range": "Self, bonded companion, or ally within 30 ft",
            "target": "Self, bonded companion, or ally within 30 ft",
            "attack_or_save": "",
            "effect": "Spend 1 Pack Echo to add PB damage to the hit. Damage type follows the hit or legal expression: weapon damage, bludgeoning, piercing, slashing, psychic, necrotic, or another GM-approved beast/blood/hunger expression.",
            "duration": "Instant",
            "limit": "Requires 1 Pack Echo and a later qualifying hit; cannot be the same event that generated Pack Echo.",
            "counterplay": "Force Pack Echo to expire, prevent allied/bonded companion line or range, use targets outside scope, or suppress Pack Echo.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Marrow Pack Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "When you, a bonded companion, or an ally within 30 ft takes damage from a creature you or your companion/ally damaged since the start of your last turn, or from a beast/predator/natural-weapon/blood/fear/pack-aura source.",
            "cost": "Spend 1 Pack Echo",
            "range": "30 ft",
            "target": "Self, bonded companion, or ally within 30 ft",
            "attack_or_save": "",
            "effect": "Spend 1 Pack Echo as a Reaction to reduce the damage by PB + your cultivation ability modifier. If the target is a bonded companion and the damage is from a beast-aspected source, the target may also move 5 ft after the damage resolves without provoking opportunity attacks from the source.",
            "duration": "Instant",
            "limit": "Requires Reaction and 1 Pack Echo; one damage packet.",
            "counterplay": "Use multiple packets, exhaust Reaction, attack outside 30 ft, prevent the prior damage link, or use effects outside the fixed scope.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Beast-Sense Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you make a check or saving throw in the Fixed Beast-Echo Scope.",
            "cost": "Spend 1 Pack Echo",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Pack Echo to add PB to the roll. This most often applies to scent, tracking, fear, forced movement, animal pressure, companion distress, safe digestion, pack tactics, natural weapons, Beast-Echo repair, or Foundation Challenge pressure.",
            "duration": "Instant",
            "limit": "Requires 1 Pack Echo; one qualifying roll.",
            "counterplay": "Use routes outside Fixed Beast-Echo Scope, suppress Pack Echo, or prevent the character from sensing/interpreting the beast or pack pressure.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Companion Echo",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Pack Echo on Marrow Pack Guard for a bonded companion or on Beast-Sense Witness for a companion-bond save/check.",
            "cost": "",
            "range": "Bonded companion",
            "target": "Bonded companion",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with the base spend: add another PB to the reduction or roll. If the protected companion still fails the save after Beast-Sense Witness, you may take psychic damage equal to CL to let it reroll; this psychic damage cannot be reduced by this Foundation.",
            "duration": "Instant",
            "limit": "Requires selecting Companion Echo as a Refined expression.",
            "counterplay": "Break the bond, move the companion out of range, suppress Pack Echo, or pressure the companion with non-scope effects.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Pack Marrow",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you spend Pack Echo on Pack-Marrow Strike for an ally or bonded companion within 30 ft.",
            "cost": "",
            "range": "Ally or bonded companion within 30 ft",
            "target": "Ally or bonded companion within 30 ft",
            "attack_or_save": "",
            "effect": "Refined evolution. Stacks with Pack-Marrow Strike: if you damaged the same target since the start of your last turn, add another PB damage.",
            "duration": "Instant",
            "limit": "Requires selecting Pack Marrow as a Refined expression.",
            "counterplay": "Do not focus the same target, isolate allies, deny range, or suppress Pack Echo.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Predator Answer",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "When you generate Pack Echo from hitting a beast-aspected, predator-aspected, monstrosity, spirit beast, demon beast, or predator-route cultivator.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Refined evolution. Gain temporary HP equal to PB, or move 5 ft without provoking opportunity attacks from that target after the hit resolves. This rider does not spend Pack Echo and does not let you spend Pack Echo on the same event.",
            "duration": "Instant",
            "limit": "Requires selecting Predator Answer as a Refined expression; once through the Pack Echo trigger.",
            "counterplay": "Use non-predator enemies, prevent qualifying hits, or suppress Beast-Echo Marrow.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          },
          {
            "name": "Safe Beast Digestion",
            "stage": "Refined",
            "type": "Downtime / Foundation Scene",
            "trigger": "When using a legal Hunger, Alchemy, Beastmastery, or Blood method to process a beast core, spirit beast portion, demon-beast portion, marrow medicine, or companion-safe beast inheritance.",
            "cost": "",
            "range": "Self or Foundation patient",
            "target": "Self or Foundation patient",
            "attack_or_save": "",
            "effect": "Refined evolution / utility rider. Reduce Impurity, backlash, or equivalent beast-digestion burden by 1, minimum 0, if the method is legal and does not consume a bonded companion or cultivator. This is normally a downtime/Foundation-scene benefit, not a combat action.",
            "duration": "Downtime / Foundation scene",
            "limit": "Requires selecting Safe Beast Digestion as a Refined expression; once per major processing scene unless the GM sets stricter limits.",
            "counterplay": "Unsafe consumption, companion essence consumption, forbidden cultivator consumption, or illegal Hunger use bypasses this benefit and may trigger Beast-Echo Surge.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Beast-Echo Marrow State",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "On your turn while you hold Pack Echo and can name a bonded companion, chosen ally, pack duty, or active hunt.",
            "cost": "Spend 1 Pack Echo + 2 CP",
            "range": "60 ft",
            "target": "Self and one bonded companion or ally within 60 ft",
            "attack_or_save": "",
            "effect": "Perfected state. Spend 1 Pack Echo and 2 CP to enter Beast-Echo Marrow State for 1 minute, once per combat or major scene. Choose yourself and one bonded companion or ally within 60 ft. While active: the chosen pair has advantage on saves against fear, intimidation, domination, predator aura, and forced movement from beasts, monstrosities, spirit beasts, demon beasts, or beast-aspected cultivators; once per round, Pack-Marrow Strike, Marrow Pack Guard, or Beast-Sense Witness gains another +PB if used by or for the chosen pair; once per turn after either chosen creature spends CP on a compatible Beastmastery, Spirit Companions, Blood, Hunger, Athletics, Warleader, Brute, Berserker, or Wrestling technique, one chosen creature may move 5 ft without provoking opportunity attacks; reducing a hostile beast-aspected creature to 0 HP during the state grants temp HP equal to CL or removes one Beast-Echo Surge progress. If you willingly consume bonded companion essence, the state ends, Beast-Echo Surge becomes Severity 4, and a major crisis begins.",
            "duration": "1 minute",
            "limit": "Perfected; once per combat or major scene; requires 1 Pack Echo and 2 CP.",
            "counterplay": "Break the bond, isolate the chosen pair, suppress Pack Echo, pressure the character into unsafe consumption, or use non-beast/non-predator routes outside the state scope.",
            "source_spheres": [
              "Beastmastery",
              "Spirit Companions",
              "Blood",
              "Hunger",
              "Athletics",
              "Warleader",
              "Wrestling",
              "Brute",
              "Berserker",
              "Life",
              "Dreams"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Beastmastery",
          "Spirit Companions",
          "Blood",
          "Hunger",
          "Athletics",
          "Warleader",
          "Wrestling",
          "Brute",
          "Berserker",
          "Life",
          "Dreams"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_BEAST_ECHO_SURGE",
            "name": "Beast-Echo Surge",
            "severity_range": "1-3, with crisis escalation to 4",
            "tags": [
              "burden",
              "beast",
              "marrow",
              "blood",
              "hunger",
              "predator",
              "companion"
            ],
            "trigger": "Beast-core overuse, demon-beast portions, companion loss, domination without bond, becoming Bloodied near predator enemies, Hunger digestion, beast tide exposure, or pack betrayal.",
            "affected_actions": "Beastmastery, Spirit Companions, Blood, Hunger, Athletics, Warleader, Brute, Berserker, safe digestion, companion repair, and breakthrough checks.",
            "fixed_ladder": {
              "Severity 1": "Relevant Beast-Echo repair, challenge, safe digestion, companion-bond, Hunger/Blood/Beastmastery correction, and breakthrough DCs increase by +2 when the action involves beast instinct, marrow, pack bond, predator pressure, or consumption of beast essence.",
              "Severity 2": "As Severity 1. Pack Echo cannot be generated from a scene where the cultivator dominates beasts without bond, treats companions as resources, or uses unsafe consumption as the trigger.",
              "Severity 3": "Pack Echo generation is suppressed until rest or Foundation correction. Existing Pack Echo can still be spent unless Companion Dissonance, Marrow Howl, or another explicit effect blocks it.",
              "Severity 4": "Crisis state. Trigger a major scene: Predator Self, companion rupture, marrow howl, beast tide attention, forbidden Hunger consequence, or teacher/sect intervention."
            },
            "suppression": "Companion grounding, pack rite, Life treatment, Music calming, Karma bond vow, Alchemy digestion, Beastmastery correction, safe hunt, or refusal of unsafe consumption.",
            "integration": "Complete three stabilizations: bond without domination, safe hunt, companion trust, refusal of unsafe beast consumption, Marrow Howl treatment, or protecting a weaker creature."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_MARROW_HOWL",
            "name": "Marrow Howl",
            "severity_range": "1-4",
            "path_affected": [
              "Body Refining",
              "Spirit Awakening"
            ],
            "injured_system": "marrow, blood, animal soul echo, companion channel, instinct-body",
            "tags": [
              "hidden_injury",
              "beast",
              "marrow",
              "companion",
              "predator",
              "blood"
            ],
            "visible_symptoms": "Phantom growls, bone aches near beasts, involuntary scent tracking, nightmares of hunting, companion distress, blood heat.",
            "default_effect": "Relevant DCs increase by +2 × Severity when the action involves beast instinct, companion bond, predation, blood scent, or safe digestion.",
            "stress_failure": "Failure by 5 or more increases Severity by 1 or applies Companion Dissonance if a companion is involved.",
            "treatment_path": "Companion rite, Beastmastery correction, Life marrow treatment, Music calming, Karma bond oath, safe hunt, Dreams animal-soul inspection, or Alchemy digestion.",
            "recovery_progress": "3 × Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_COMPANION_DISSONANCE",
            "name": "Companion Dissonance",
            "severity_range": "1-3",
            "suppressed_feature": "Companion Echo, Pack Marrow, Beast-Echo Marrow State, or bonded-companion riders.",
            "trigger": "Companion injury, companion death, domination misuse, unsafe beast essence consumption, failed pact, or pack betrayal.",
            "fixed_ladder": {
              "Severity 1": "Companion-specific riders require a Beast-Echo repair scene before they can be used for a new companion.",
              "Severity 2": "Companion Echo and bonded-companion movement riders are suppressed; Beastmastery, Spirit Companions, Blood, and Hunger checks involving the companion have DC +2.",
              "Severity 3": "Beast-Echo Marrow State cannot choose a bonded companion until restoration; failure by 5 or more on companion repair applies or worsens Marrow Howl."
            },
            "restoration": "Repair bond, mourn companion, safe hunt, companion healing, Music calming, Karma pact renewal, or release a dead companion without consumption."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_PREDATOR_SELF",
            "name": "Predator Self",
            "severity_range": "1-4",
            "progress_range": "0-3",
            "temptation": "The pack follows strength. Hunger proves truth. Compassion is prey behavior.",
            "trigger": "Blood scent, enemy weakness, companion injury, beast-core temptation, successful hunt, being challenged for dominance, or Hunger sphere use on beast essence.",
            "benefit_offered": [
              "Gain advantage on one attack, tracking, intimidation, Athletics, Beastmastery, Blood, or Hunger check involving prey/predator pressure.",
              "Add PB damage to one natural weapon, melee, Blood, Beastmastery, or Hunger attack.",
              "Gain temporary HP equal to CL after reducing a creature to 0 HP.",
              "Suppress fear, charm, or pain for the scene by entering predator instinct."
            ],
            "cost": "Increase Deviation progress by 1. At Progress 3, increase Severity by 1 and reset Progress.",
            "resistance": "Cultivation Check or Wisdom saving throw, DC 10 + 2 × Severity.",
            "correction": "Protect prey, spare a defeated foe, feed the pack without domination, mourn a companion, accept human speech, refuse unsafe consumption.",
            "possible_transformation": [
              "Pack Guardian Marrow",
              "Predator King Heart Demon",
              "Beast Sovereign Body",
              "Companion Saint Anchor"
            ]
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Companion Grounding Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: calm marrow echo through companion trust, pack acknowledgement, Life treatment, Music calming, Karma bond vow, or Beastmastery correction. Counts toward Beast-Echo Surge, Companion Dissonance, or Marrow Howl recovery when the scene contains a real bond choice.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Safe Hunt Discipline",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: hunt without cruelty, feed the pack without domination, refuse unsafe consumption, or process beast essence through a legal Alchemy/Hunger/Blood/Beastmastery method. Counts toward integration and Predator Self correction.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Marrow Howl Treatment",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation repair practice: Life marrow treatment, Dreams animal-soul inspection, Music calming, Karma oath witness, or companion-healing rite reduces Marrow Howl recovery progress.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "foundation_challenges": [
        {
          "name": "Reveal Beast-Echo Marrow",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: reveal through beast reaction, companion bond, beast-core survival, marrow diagnosis, hunting trial, spirit beast encounter, or Hunger digestion under supervision.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Integrate Beast-Echo Marrow",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: complete three stabilizations such as bond without domination, safe hunt, companion trust, refusal of unsafe consumption, Marrow Howl treatment, or protecting a weaker creature.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Redirect Beast-Echo Marrow",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Self, companion, student, or Foundation patient",
          "attack_or_save": "",
          "effect": "Foundation Challenge route: redirect toward Pack Guardian Marrow, Predator King Marrow, Companion Saint Anchor, Beast-Warleader Blood, Dream Beast Echo, or Beast Sovereign Body through compatible spheres and teacher guidance.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "lineage_hooks": [
        {
          "name": "Pack Marrow Lineage",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Student, companion line, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: preserve a lesser beast sense, pack marrow trace, companion echo, or predator bone spark for disciples. It teaches resonance and bond discipline, not the full Foundation automatically.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        },
        {
          "name": "Companion-Bond Sect Inheritance",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, a Foundation repair scene, lineage scene, diagnosis scene, teacher correction, or Foundation Challenge scene.",
          "cost": "Scene time, compatible beast/companion/marrow method, and appropriate teacher, witness, treatment, hunt, bond rite, or safe digestion context.",
          "range": "Scene",
          "target": "Student, companion line, sect group, or lineage patient",
          "attack_or_save": "",
          "effect": "Lineage support: establish Beast-Echo Marrow as beast clan inheritance, pack-warrior lineage, companion-bond sect, spirit beast hunting art, or carefully sealed predator marrow scripture. Noncombat support unless a separate combat spark is written.",
          "duration": "Downtime / Foundation scene",
          "limit": "Downtime/Foundation-scene only; not a normal combat action.",
          "counterplay": "Requires appropriate scene time, compatible support, and a Foundation route that is not fully suppressed.",
          "source_spheres": []
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "ash_born_remnant_core_v0_2B",
      "name": "Ash-Born Remnant Core",
      "number": 28,
      "profile": {
        "grade": "Mythic",
        "status": "Stable",
        "default_stage": "Integrated",
        "primary_path": "Qi Cultivation or Spirit Awakening",
        "secondary_path_fit": [
          "Body Refining"
        ],
        "typical_role": "Striker / Support / Defender",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Ash, ruins, old battlefields, funeral smoke, burned scriptures, remnant spirits, and destroyed lineages resonate with your core. Loss does not pass through you cleanly; it leaves usable shape, but feeding on ruin can turn the core into hunger.",
        "visible_sign": "",
        "warning": "If the cultivator repeatedly feeds the core with destruction, corpse-use, battlefield farming, or grief without release, the Foundation begins treating ruin as the only honest source of power.",
        "dao_principle": "What remains after ruin is not lesser than what was lost; it is the proof that consequence has taken form."
      },
      "resource": {
        "name": "Remnant Cinder",
        "maximum": "1",
        "starting": "0",
        "gain": "After a real qualifying Ash-Born event resolves.",
        "timing": "After qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Short-lived Ash-Born aftermath resource. It cannot be generated from friendly, staged, self-inflicted, harmless, training, trivial-object, repeated non-threatening, innocent-harming, or farmed destruction.",
        "spends": [
          "Last Cinder Guard",
          "Ash-Remnant Strike",
          "Survivor Cinder Breath",
          "Refined — Smothering Remnant",
          "Refined — Last Cinder Refusal",
          "Perfected — True Ash Remnant Sovereignty"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Remnant Core Reserve",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum CP increases by your Proficiency Bonus. Your legal Ash, Death, Fire, Karma, Fate, Dark, Radiance, Protection, Dreams, Ink, Hunger, and Alchemy techniques may count as Foundation-aligned only when they clearly express ash, fire aftermath, death consequence, remnant memory, funeral authority, survivor protection, burned scripture, ruined lineage, or transformation after loss. You have Advantage on Wisdom saving throws against remnant possession, ruin-terror, grief-based control, despair pressure, battlefield horror, and hostile effects that try to make you seek destruction as proof of truth. This grants no sphere access, no automatic immunity, and no passive once-per-round damage reduction.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use ordinary force, present-tense threats, renewal, living obligations, or effects outside ash/remnant/grief scope.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Fixed Scope — Aftermath Remnant",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules interpretation for this Foundation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports legal methods that work with ash, fire aftermath, death consequence, remnant spirits, funeral rites, survivor protection, battlefield memory, ruined lineages, burned scripture, and transformation after loss. It does not grant broad fire blasting, free necromancy, generic corpse control, free Hunger access, automatic use of all Death effects, or permission to seek destruction for power.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Deny Foundation alignment when the effect is ordinary fire, generic necromancy, unrelated darkness, unrestricted Hunger, or destruction for its own sake.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Generate Remnant Cinder",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After a real qualifying Ash-Born event resolves.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "After the qualifying event fully resolves, gain 1 Remnant Cinder if you are conscious and do not already have Remnant Cinder. Qualifying events are: you spend CP on a Fixed Ash-Born Scope technique/effect; a nontrivial hostile creature, construct, ward, summoned creature, remnant, or significant object is destroyed within 60 feet during a meaningful scene; you succeed on an eligible save against remnant possession, ruin-terror, grief-control, despair, battlefield horror, ash contamination, death pressure, or fire-aftermath backlash; or you preserve, stabilize, release, or protect a survivor/remnant through a qualifying funeral, protection, cleansing, or aftermath method. Friendly, staged, self-inflicted, harmless, training, trivial-object, repeated non-threatening, innocent-harming, or farmed destruction cannot generate Remnant Cinder.",
            "duration": "",
            "limit": "Maximum 1; once per round; expires end of next turn; no same-event spending.",
            "counterplay": "Deny generation from staged destruction, friendly sacrifices, trivial objects, farmed summons, harmless training, or innocent/protected-remnant harm.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Last Cinder Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes hostile damage while you have Remnant Cinder.",
            "cost": "1 Remnant Cinder",
            "range": "30 feet",
            "target": "Self or one ally",
            "attack_or_save": "",
            "effect": "Spend 1 Remnant Cinder as a Reaction when you or an ally within 30 feet takes hostile damage. Reduce the triggering damage by your Proficiency Bonus + your Path key ability modifier. If the triggering source is fire aftermath, necrotic damage, ash, death pressure, grief-control, remnant possession, battlefield hazard, ruin-fed corruption, or funeral-defiling pressure, increase the reduction by your Proficiency Bonus. This does not cleanse major curses, hidden injuries, deviations, or sacred-remnant debts.",
            "duration": "",
            "limit": "Costs 1 Remnant Cinder; cannot use Cinder generated by same event.",
            "counterplay": "Use direct damage, present-tense threats, non-remnant control, or attack after Cinder expires.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Ash-Remnant Strike",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "After you damage a hostile creature with a later Foundation-aligned Ash-Born hit or effect while you have Remnant Cinder.",
            "cost": "1 Remnant Cinder",
            "range": "Effect range",
            "target": "One damaged hostile creature",
            "attack_or_save": "Uses triggering attack/save",
            "effect": "After you damage a hostile creature with a Foundation-aligned Ash, Death, Fire, Karma, Fate, Dark, Radiance, Protection, Dreams, Ink, Hunger, Alchemy, funeral, survivor, remnant, or aftermath technique, spend 1 Remnant Cinder to add fire, necrotic, radiant, psychic, or force damage equal to your Proficiency Bonus + your Path key ability modifier. This is not a separate attack and cannot spend Cinder generated by that same hit or effect.",
            "duration": "",
            "limit": "Costs 1 Remnant Cinder; not a separate attack; no same-event spend.",
            "counterplay": "Deny if the technique is generic fire/death/Hunger with no aftermath/remnant/consequence expression.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Survivor Cinder Breath",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "You have Remnant Cinder and choose yourself or one willing creature within 30 feet.",
            "cost": "1 Remnant Cinder",
            "range": "30 feet",
            "target": "Self or one willing creature",
            "attack_or_save": "",
            "effect": "Spend 1 Remnant Cinder as a Bonus Action. The target gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, the target has Advantage on the next saving throw it makes against fear, despair, remnant possession, battlefield horror, grief-based control, ash contamination, death pressure, or fire-aftermath backlash.",
            "duration": "",
            "limit": "Costs 1 Remnant Cinder; temporary HP follows normal stacking rules.",
            "counterplay": "Use non-scoped threats, wait out duration, or strip temporary HP with ordinary damage.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined — Ash Memory",
            "stage": "Refined",
            "type": "Foundation Scene / Utility",
            "trigger": "You touch meaningful ashes, ruins, remains, battlefield soil, burned scripture, or a remnant-marked object.",
            "cost": "Scene requirements",
            "range": "Touch",
            "target": "One meaningful remnant object/site",
            "attack_or_save": "Cultivation Check if required",
            "effect": "Touch a meaningful remnant and make a Cultivation Check if the GM requires one. On success, learn one meaningful consequence attached to the ruin: who died, what was lost, what caused the destruction, what debt remains, what remnant lingers, or what must be released. This does not reveal a full plot, all enemies, or a complete technique list.",
            "duration": "",
            "limit": "Requires meaningful remnant; no resource generated by this row.",
            "counterplay": "False remnants, sealed memories, deliberate misinformation, or higher authority can resist or distort the reading.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Refined — Smothering Remnant",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You spend Remnant Cinder on Ash-Remnant Strike.",
            "cost": "Included in Ash-Remnant Strike",
            "range": "Effect range",
            "target": "The same damaged target",
            "attack_or_save": "",
            "effect": "When you spend Remnant Cinder on Ash-Remnant Strike, the damaged target cannot regain Hit Points until the start of your next turn. If the target is a remnant, undead, regeneration effect, ruin-fed creature, or creature currently feeding from destruction, also reduce one recovery, regeneration, or CP recovery event before then by your Proficiency Bonus. This is a rider, not a second action or second Cinder spend.",
            "duration": "",
            "limit": "Only applies when Ash-Remnant Strike is legally spent.",
            "counterplay": "Use non-healing defense, remove the attacker, or wait until the brief lock expires.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          },
          {
            "name": "Refined — Last Cinder Refusal",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You spend Remnant Cinder on Last Cinder Guard and the guarded damage would still reduce you to 0 HP.",
            "cost": "1 CP",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "When you spend Remnant Cinder on Last Cinder Guard for yourself and the guarded damage would still reduce you to 0 HP, you may spend 1 CP to drop to 1 HP instead. Once per combat or major scene. This is not a second Reaction and cannot be used if you were already at 0 HP before the damage.",
            "duration": "",
            "limit": "Requires legal Last Cinder Guard on self; once per combat/major scene.",
            "counterplay": "Use effects that bypass damage, unconsciousness before damage, or multiple threats after this rider is spent.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected — True Ash Remnant Sovereignty",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You activate the Perfected Foundation state.",
            "cost": "3 CP",
            "range": "30-foot Emanation",
            "target": "Self and chosen allies in area",
            "attack_or_save": "",
            "effect": "Once per long rest, spend 3 CP as a Bonus Action to manifest a 30-foot Emanation of ash, smoke, dim cinders, ghostly embers, or pale funeral light for 1 minute. Chosen allies in the area have Advantage on saving throws against fear, despair, remnant possession, battlefield horror, grief-based control, ash contamination, and ruin-fed corruption. Once on each of your turns while the state lasts, when you damage a hostile creature or grant temporary Hit Points with a qualifying Foundation-aligned aftermath, remnant, funeral, survivor, Ash, Death, Fire, Karma, Fate, Dark, Radiance, Protection, Dreams, Ink, Hunger, or Alchemy technique, add your Proficiency Bonus to one damage or temporary HP value. Remnant Cinder maximum remains 1. If you deliberately destroy an innocent, ally, protected remnant, or sacred memory to feed this state, the state ends and Ruin-Seeking Deviation advances.",
            "duration": "",
            "limit": "Once per long rest; costs 3 CP; Remnant Cinder max remains 1.",
            "counterplay": "Break line of effect, leave emanation, use non-scoped threats, bait Ruin-Seeking violation, or wait out 1 minute.",
            "source_spheres": [
              "Ash",
              "Death",
              "Fire",
              "Karma",
              "Fate",
              "Dark",
              "Radiance",
              "Protection",
              "Dreams",
              "Ink",
              "Hunger",
              "Alchemy"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Ash",
          "Death",
          "Fire",
          "Karma",
          "Fate",
          "Dark",
          "Radiance",
          "Protection",
          "Dreams",
          "Ink",
          "Hunger",
          "Alchemy"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "BURDEN_ASH_BORN_REMNANT_CORE_REMNANT_HUNGER",
            "display_name": "Burden — Remnant Hunger",
            "text": "If the cultivator repeatedly feeds the core with destruction, corpse-use, battlefield farming, or grief without release, the Foundation begins treating ruin as the only honest source of power. Advancement scenes become harder until repaired through remembrance, release, survivor protection, or rebuilding."
          }
        ],
        "hidden_injuries": [
          {
            "id": "HIDDEN_INJURY_ASH_BORN_REMNANT_CORE_CINDER_SOUL_RESIDUE",
            "display_name": "Cinder-Soul Residue",
            "text": "Ash and grief lodge in the core and soul anchor. Breath carries ghostly heat, dreams return to ruins, and remnant, death, grief, Hunger, or battlefield-memory effects become harder to purge until repaired."
          }
        ],
        "strains": [
          {
            "id": "STRAIN_ASH_BORN_REMNANT_CORE_SMOTHERED_CORE",
            "display_name": "Smothered Core",
            "text": "After overuse or failed refinement, ash-remnant channels clog with unprocessed grief. At high strain, Remnant Cinder generation from destruction should be suppressed until a release, cleansing, or survivor-protection scene repairs the blockage."
          }
        ],
        "deviations": [
          {
            "id": "DEVIATION_ASH_BORN_REMNANT_CORE_RUIN_SEEKING",
            "display_name": "Ruin-Seeking Deviation",
            "text": "The cultivator begins seeking new destruction because only ruin feels meaningful enough to prove truth."
          },
          {
            "id": "DEVIATION_ASH_BORN_REMNANT_CORE_NO_FUNERAL_HUNGER",
            "display_name": "No-Funeral Hunger Deviation",
            "text": "The cultivator treats the dead, remnants, sacred ashes, and destroyed lineages as fuel before they are mourned, released, or accounted for."
          }
        ]
      },
      "repair_practices": [
        {
          "name": "Repair — Funeral Accounting",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Name the loss, settle the debt, and separate usable ash-memory from parasitic ruin-hunger.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Karma",
            "Protection",
            "Death",
            "Radiance",
            "Music"
          ]
        },
        {
          "name": "Repair — Clean Ash Rite",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Use Radiance, Water, Life, Music, or Sect Stewardship rebuilding to cleanse Cinder-Soul Residue without denying grief.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Life",
            "Music",
            "Karma",
            "Radiance",
            "Water",
            "Sect Stewardship",
            "Protection"
          ]
        },
        {
          "name": "Repair — Survivor Protection Work",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Protect or rebuild for survivors of the ruin so the core learns aftermath can become shelter rather than appetite.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Protection",
            "Sect Stewardship",
            "Life",
            "Karma",
            "Radiance"
          ]
        }
      ],
      "foundation_challenges": [
        {
          "name": "Challenge — Remember Without Feeding",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Face a ruin, battlefield, or destroyed lineage and learn from it without consuming the dead or seeking new destruction.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Ash",
            "Death",
            "Fire",
            "Karma",
            "Fate",
            "Dark",
            "Radiance",
            "Protection",
            "Dreams",
            "Ink",
            "Hunger",
            "Alchemy"
          ]
        },
        {
          "name": "Challenge — Release the Remnant",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Resolve, exorcise, bury, or guide a remnant without turning it into fuel.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Ash",
            "Death",
            "Fire",
            "Karma",
            "Fate",
            "Dark",
            "Radiance",
            "Protection",
            "Dreams",
            "Ink",
            "Hunger",
            "Alchemy"
          ]
        },
        {
          "name": "Challenge — Build After Ash",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, survivor, remnant, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "Use the Foundation to preserve survivors or rebuild a broken place, proving consequence can become duty.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Ash",
            "Death",
            "Fire",
            "Karma",
            "Fate",
            "Dark",
            "Radiance",
            "Protection",
            "Dreams",
            "Ink",
            "Hunger",
            "Alchemy"
          ]
        }
      ],
      "lineage_hooks": [
        {
          "name": "Lineage — Funeral Guardian Seed",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "A teacher, survivor sect, ghost court, or ash scripture teaches a lesser inheritance that senses remnants and protects survivors without copying the full Mythic core.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Ash",
            "Death",
            "Karma",
            "Protection",
            "Radiance"
          ]
        },
        {
          "name": "Lineage — Survivor Ash Trace",
          "stage": "Awakened",
          "type": "Downtime / Foundation Scene",
          "trigger": "During downtime, repair, challenge, lineage, or Foundation advancement scenes.",
          "cost": "Scene requirements",
          "range": "Self or relevant scene",
          "target": "Self, teacher, patient, site, or lineage object",
          "attack_or_save": "Foundation scene check if required",
          "effect": "A student, disciple, or protected survivor receives a minor ash-memory diagnostic route, useful for finding dangerous ruins and treating Cinder-Soul Residue.",
          "duration": "",
          "limit": "Requires GM scene approval; not a GM Screen combat row.",
          "counterplay": "Cannot be used as a combat action unless separately written as a full combat row.",
          "source_spheres": [
            "Ash",
            "Death",
            "Fire",
            "Karma",
            "Fate",
            "Dark",
            "Radiance",
            "Protection",
            "Dreams",
            "Ink",
            "Hunger",
            "Alchemy"
          ]
        }
      ],
      "source_gaps": []
    },
    {
      "foundation_id": "mud_lotus_dantian_v0_2A",
      "name": "Mud Lotus Dantian",
      "number": 29,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Qi Cultivation",
        "secondary_path_fit": [
          "Body Refining"
        ],
        "typical_role": "Recovery / Support",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your dantian responds to muddy water, lotus roots, medicinal ponds, wet earth, slow healing, and humble growth. You do not cultivate quickly, but you recover well from bad conditions and can turn poor living material into usable recovery.",
        "visible_sign": "",
        "warning": "When the cultivator preserves rot, refuses cleansing, treats low status as identity, or uses recovery to avoid necessary action, relevant Mud Lotus recovery, cleansing, growth, Water, Life, Flowers, Alchemy, Disease, Poison, Protection, healing, and breakthrough checks become harder until corrected.",
        "dao_principle": "Purity is not the absence of mud; purity is what rises through it without denying where it grew."
      },
      "resource": {
        "name": "Lotus Dew",
        "maximum": "1",
        "starting": "0",
        "gain": "You are conscious, have no Lotus Dew, and a real qualifying recovery, treatment, living-water, or contamination-resistance event resolves.",
        "timing": "After qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Short-lived Mud Lotus recovery resource. It cannot be generated from friendly, staged, self-inflicted, harmless, training, repeated non-threatening, farmed, or corruption-preserving events.",
        "spends": [
          "Mud-Lotus Guard",
          "Lotus-Root Recovery",
          "Humble Medicine Witness",
          "Refined — Lotus Recovery"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Mud Lotus Reserve",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum CP increases by your Proficiency Bonus. Your legal Water, Life, Verdant Growth, Flowers, Alchemy, Protection, Harvesting Gathering, Earth, Disease, Poison, and Music techniques may count as Foundation-aligned only when they clearly express humble recovery, living-water cleansing, lotus-root medicine, poison/disease treatment, polluted-but-living environments, shared medicine, recovery after hardship, or growth through mud without preserving rot. You have Advantage on Constitution and Wisdom saving throws against hostile poison, disease, rot, polluted-water contamination, sickness-exhaustion, and effects that weaponize shame about humble origin or low status. This grants no sphere access, no automatic immunity, and no passive once-per-round damage reduction.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use dry fire, sterile purity, direct violence, social pride tests, or effects outside recovery/rot/pollution scope.",
            "source_spheres": [
              "Water",
              "Life",
              "Verdant Growth",
              "Flowers",
              "Alchemy",
              "Protection",
              "Harvesting Gathering",
              "Earth",
              "Disease",
              "Poison",
              "Music"
            ]
          },
          {
            "name": "Fixed Scope — Humble Recovery",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules interpretation for this Foundation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "This Foundation supports legal methods that work with living water, humble medicine, lotus-root recovery, poison filtering, disease care, shared food/treatment, wet earth, gardens, ponds, low-status clinics, and the refusal to treat mud as shame. It does not grant broad healing, poison flooding, rot worship, all Water effects, all Life effects, aristocratic beauty, sterile purity doctrines, or medicine without humility.",
            "duration": "",
            "limit": "Always active as interpretation text.",
            "counterplay": "Challenge uses that are sterile purity, rot preservation, poison flooding, vanity-lotus display, or unrelated Water/Life technique.",
            "source_spheres": [
              "Water",
              "Life",
              "Verdant Growth",
              "Flowers",
              "Alchemy",
              "Protection",
              "Harvesting Gathering",
              "Earth",
              "Disease",
              "Poison",
              "Music"
            ]
          },
          {
            "name": "Generate Lotus Dew",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You are conscious, have no Lotus Dew, and a real qualifying recovery, treatment, living-water, or contamination-resistance event resolves.",
            "cost": "",
            "range": "Self or 30 feet",
            "target": "Self, one ally, or qualifying scene event",
            "attack_or_save": "",
            "effect": "Once per round, generate 1 Lotus Dew if you are conscious, have none, and one of these real events resolves: you or an ally within 30 feet regains HP through treatment or a Foundation-aligned method; you or an ally gains temporary HP from a Foundation-aligned recovery method; you or an ally succeeds on an eligible save against poison, disease, rot, polluted water, sickness-exhaustion, or terrain contamination; you spend CP on a Fixed Mud Lotus Scope technique; or you complete a meaningful treatment action in a dangerous scene. Friendly, staged, self-inflicted, harmless, training, repeated non-threatening, farmed, or corruption-preserving events cannot generate Lotus Dew.",
            "duration": "",
            "limit": "Once per round; max 1; expires end of your next turn; cannot be spent on same event.",
            "counterplay": "Deny staged/farmed healing loops, harmless contamination, fake treatment, or preservation of rot.",
            "source_spheres": [
              "Water",
              "Life",
              "Verdant Growth",
              "Flowers",
              "Alchemy",
              "Protection",
              "Harvesting Gathering",
              "Earth",
              "Disease",
              "Poison",
              "Music"
            ]
          },
          {
            "name": "Mud-Lotus Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You or an ally within 30 feet takes hostile poison, disease, acid, necrotic rot, polluted-water, terrain-contamination, sickness-exhaustion, or similar scoped harm.",
            "cost": "1 Lotus Dew",
            "range": "30 feet",
            "target": "Self or one ally",
            "attack_or_save": "",
            "effect": "Spend 1 Lotus Dew as a Reaction when you or an ally within 30 feet takes hostile poison, disease, acid, necrotic rot, polluted-water, terrain-contamination, sickness-exhaustion, or similar scoped harm. Reduce the damage or measurable harm by your Proficiency Bonus + your Path key ability modifier. If the source is poison, disease, rot, polluted water, living terrain contamination, or failed medicine backlash, increase the reduction by your Proficiency Bonus. This does not cleanse major curses, diseases, hidden injuries, or deviations by itself.",
            "duration": "",
            "limit": "Costs 1 Lotus Dew; cannot spend Dew generated by same event.",
            "counterplay": "Use direct weapon damage, dry fire, sterile light, pride pressure, or non-scoped damage.",
            "source_spheres": [
              "Life",
              "Water",
              "Alchemy",
              "Verdant Growth",
              "Flowers",
              "Protection",
              "Music"
            ]
          },
          {
            "name": "Lotus-Root Recovery",
            "stage": "Awakened",
            "type": "Bonus Action",
            "trigger": "You spend Lotus Dew to support a willing creature through living-water, medicine, or humble recovery.",
            "cost": "1 Lotus Dew",
            "range": "30 feet",
            "target": "Self or one willing creature",
            "attack_or_save": "",
            "effect": "As a Bonus Action, spend 1 Lotus Dew and choose yourself or one willing creature within 30 feet. The target gains temporary Hit Points equal to your Proficiency Bonus + your Path key ability modifier. Until the start of your next turn, the target has Advantage on the next saving throw it makes against poison, disease, rot, polluted water, sickness-exhaustion, failed medicine backlash, or terrain contamination. This is not full healing and cannot be used to preserve corruption as if it were health.",
            "duration": "",
            "limit": "Costs 1 Lotus Dew; temp HP does not stack with itself under ordinary temp HP rules.",
            "counterplay": "Attack through direct damage, dispel treatment support, or force a save outside the listed scope.",
            "source_spheres": [
              "Life",
              "Water",
              "Alchemy",
              "Verdant Growth",
              "Flowers",
              "Protection",
              "Music"
            ]
          },
          {
            "name": "Humble Medicine Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You make a Fixed Mud Lotus Scope Medicine, Survival, herbalism, Water, Life, Flowers, Alchemy, Protection, Disease-treatment, Poison-treatment, or Cultivation Check/save.",
            "cost": "1 Lotus Dew",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Spend 1 Lotus Dew after you roll a qualifying Fixed Mud Lotus Scope check or saving throw, before the outcome is finalized. Add your Proficiency Bonus to the roll. If the roll treats another creature, cleanses a source, accepts help, or uses humble material instead of display, the GM may also reduce one Minor poison, disease, rot, or contamination consequence by one step if such a step exists. This cannot erase a major Hidden Injury, curse, or Deviation without a proper challenge route.",
            "duration": "",
            "limit": "Costs 1 Lotus Dew; cannot erase major injuries/deviations.",
            "counterplay": "Force rolls outside recovery/contamination/humble-cultivation scope; require full challenge routes for major injuries.",
            "source_spheres": [
              "Life",
              "Water",
              "Alchemy",
              "Verdant Growth",
              "Flowers",
              "Protection",
              "Music"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined — Lotus Recovery",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You have chosen or unlocked the Lotus Recovery refined expression and spend Lotus Dew on a qualifying recovery use.",
            "cost": "None beyond the base spend",
            "range": "Self or base spend range",
            "target": "Base spend target",
            "attack_or_save": "",
            "effect": "Lotus Recovery improves the base Mud Lotus spends. When you spend Lotus Dew on Mud-Lotus Guard, Lotus-Root Recovery, or Humble Medicine Witness in a scene involving real treatment, stabilization, poison/disease suppression, exhaustion from sickness, or a Minor Hidden Injury challenge, add your Proficiency Bonus to one numeric value of that spend. This does not require an additional action, Reaction, or Lotus Dew.",
            "duration": "",
            "limit": "Only if refined expression is unlocked; modifies one numeric value once per spend.",
            "counterplay": "Prevent use outside genuine recovery/treatment scenes.",
            "source_spheres": [
              "Life",
              "Water",
              "Alchemy",
              "Verdant Growth",
              "Flowers",
              "Protection",
              "Music"
            ]
          },
          {
            "name": "Refined — Muddy Filter Dantian",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You have chosen or unlocked Muddy Filter Dantian and a Minor scoped consequence would apply.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Once per long rest, when a Poison, Disease, Hunger, Alchemy, Medicine, Impurity, Pill Impurity, Poisoned, or Disease consequence would affect you, you may reduce that consequence by one severity/step or ignore it if the GM defines it as Minor. This cannot justify poison flooding, rot worship, forbidden consumption, or hiding contagious corruption.",
            "duration": "",
            "limit": "Once per long rest; only Minor scoped consequences.",
            "counterplay": "Use major conditions, unclean choices, corruption-preservation, or non-scoped harm.",
            "source_spheres": [
              "Alchemy",
              "Disease",
              "Poison",
              "Life",
              "Water"
            ]
          },
          {
            "name": "Refined — Pond-Shelter Aura",
            "stage": "Refined",
            "type": "Short Rest Utility",
            "trigger": "You conduct shared food, medicine, treatment, or living-water rest with willing creatures.",
            "cost": "",
            "range": "Short rest group",
            "target": "Up to PB willing creatures who rest with you",
            "attack_or_save": "",
            "effect": "During a short rest, choose up to a number of willing creatures equal to your Proficiency Bonus who rest with you and share food, medicine, treatment, or a living-water/humble shelter recovery scene. At the end of the rest, each chosen creature gains temporary Hit Points equal to your Proficiency Bonus. This is not a combat action row by default, but is included for automation visibility.",
            "duration": "",
            "limit": "Requires short rest and genuine shared recovery scene.",
            "counterplay": "Deny in sterile, hostile, dry, corrupt, or staged non-rest scenes.",
            "source_spheres": [
              "Life",
              "Water",
              "Music",
              "Protection"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Lotus Recovery Field",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You manifest the Perfected Mud Lotus field.",
            "cost": "2 CP",
            "range": "20-foot Emanation",
            "target": "Chosen allies in area",
            "attack_or_save": "Varies by hostile effect",
            "effect": "As a Bonus Action once per long rest, spend 2 CP to create a 20-foot Emanation for 1 minute. Chosen allies in the field have Advantage on saving throws against poison, disease, exhaustion from sickness, rot, polluted water, and terrain-based contamination. Once per round, when an ally in the field regains HP, receives temporary HP, or succeeds on a save against poison/disease/rot, that ally gains additional temporary Hit Points equal to your Proficiency Bonus. Once during the field, when a creature in the field would gain a Minor Hidden Injury from poison, disease, rot, polluted water, or failed medicine, you may reduce it to Strain instead. Hostile poison, disease, rot, or pollution effects in the field have disadvantage on the first save DC contest or attack roll each turn. If you use the field to preserve corruption, hide rot, or help a plague spread, the field ends and you gain Muddy Stagnation Severity 1.",
            "duration": "",
            "limit": "Once per long rest; cost 2 CP; does not increase Lotus Dew max.",
            "counterplay": "Move fight out of field, use non-scoped damage, corrupt the field, force preservation of rot, or apply major injuries beyond field scope.",
            "source_spheres": [
              "Life",
              "Water",
              "Alchemy",
              "Verdant Growth",
              "Flowers",
              "Protection",
              "Music"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Water",
          "Life",
          "Verdant Growth",
          "Flowers",
          "Alchemy",
          "Protection",
          "Harvesting Gathering",
          "Earth",
          "Disease",
          "Poison",
          "Music"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "muddy_stagnation",
            "display_name": "Muddy Stagnation",
            "text": "When the cultivator preserves rot, refuses cleansing, treats low status as identity, or uses recovery to avoid necessary action, relevant Mud Lotus recovery, cleansing, growth, Water, Life, Flowers, Alchemy, Disease, Poison, Protection, healing, and breakthrough checks become harder until corrected."
          }
        ],
        "hidden_injuries": [
          {
            "id": "rot_in_the_lotus_bed",
            "display_name": "Rot in the Lotus Bed",
            "text": "The dantian water layer and lower meridians sour. Recovery, disease treatment, poison filtering, water circulation, and living growth become unstable until treated through clean water, Life renewal, Alchemy purification, flower medicine, Music encouragement, Protection warding, or removal of the corrupt source."
          }
        ],
        "strains": [
          {
            "id": "wilted_lotus",
            "display_name": "Wilted Lotus",
            "text": "Drought, Fire/Yang overuse, plague backlash, failed medicine, shame about humble origin, or using healing to enable corruption suppresses Mud Lotus recovery benefits. At higher severity, recovery checks become harder and failures can create Rot in the Lotus Bed."
          }
        ],
        "deviations": [
          {
            "id": "comfort_in_the_mud",
            "display_name": "Comfort in the Mud",
            "text": "The cultivator begins to believe that not rising is safer than blooming. The Deviation offers endurance, stealth, ignored sickness, or low-status protection in exchange for accepting harmful conditions as identity."
          },
          {
            "id": "rot_lotus_deviation",
            "display_name": "Rot Lotus Deviation",
            "text": "A darker route where the cultivator confuses filtering poison with cultivating rot. It may become a dangerous Disease/Poison redirection only through explicit GM-approved challenge routes, never through casual use."
          }
        ]
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [
        {
          "name": "Lineage: Village Healer Method",
          "stage": "Awakened",
          "type": "Downtime / Teacher Support",
          "trigger": "",
          "cost": "",
          "range": "",
          "target": "",
          "attack_or_save": "",
          "effect": "Create lesser Mud Lotus traces, village clinic rites, humble medicine manuals, pond recovery methods, or lotus-root diagnostics. This does not copy the full Foundation.",
          "duration": "",
          "limit": "",
          "counterplay": "",
          "source_spheres": []
        }
      ],
      "source_gaps": [
        "No standalone structured repair-practice rows.",
        "No standalone structured Foundation Challenge rows."
      ]
    },
    {
      "foundation_id": "glass_heart_meridian_v0_2A",
      "name": "Glass Heart Meridian",
      "number": 30,
      "profile": {
        "grade": "Major",
        "status": "Stable",
        "default_stage": "Awakened",
        "primary_path": "Spirit Awakening or Qi Cultivation",
        "secondary_path_fit": [
          "Body Refining"
        ],
        "typical_role": "Striker",
        "complexity": "Moderate"
      },
      "overview": {
        "summary": "Your heart-meridians are clear, reflective, and fragile. Beauty, Glass, Illusion, Radiance, and truth-revealing methods resonate with you. Lies, betrayal, beauty obsession, and forceful emotional suppression can cut the heart-meridians.",
        "visible_sign": "",
        "warning": "When betrayal, self-deception, beauty-as-worth, reflected harm, or forceful emotional suppression stresses the Foundation, relevant Glass Heart scope DCs increase by +2 x Severity.",
        "dao_principle": "A clear heart breaks easily, but every fracture teaches light another path."
      },
      "resource": {
        "name": "Glass Reflection",
        "maximum": "1",
        "starting": "0",
        "gain": "Once per round, after a qualifying illusion, charm, fear, deception, gaze, beauty-pressure, emotional-manipulation, radiant/glass-reflection, or falsehood-based psychic save/check resolves in your favor, or after you spend CP on a Fixed Glass Heart Scope technique/effect.",
        "timing": "After qualifying trigger resolves",
        "frequency": "Once per round",
        "expiry": "End of your next turn",
        "same_event": "Cannot be spent on the event that generated it.",
        "anti_farming": "Short-lived Glass Heart clarity resource. It cannot be generated from staged deceptions, harmless performances, friendly training illusions, repeated non-threatening prompts, self-inflicted drama, farmed social checks, or deceptions arranged by the cultivator to trigger the Foundation.",
        "spends": [
          "Shatter-Guard",
          "Clear-Heart Rebuke",
          "Transparent Witness",
          "Perfected — Glass Heart Refraction"
        ]
      },
      "features": {
        "awakened": [
          {
            "name": "Glass Heart Reserve",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Always active while this Foundation is installed.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Your maximum CP increases by your Proficiency Bonus. Your legal Glass, Beauty, Illusion, Radiance, Protection, The Hidden Eye, Dreams, Music, Water, Fate, Sword, Life, and Karma methods may count as Foundation-aligned only when they express emotional truth, reflection without denial, revealed falsehood, beauty without self-erasure, vulnerability protected rather than hidden, mirror defense, or repair of trust. You have Advantage on Wisdom and Charisma saving throws against hostile illusion, charm, fear, deception, gaze effects, beauty pressure, emotional manipulation, and psychic pressure based on falsehood. This grants no sphere access, no immunity, and no passive once-per-round damage reduction.",
            "duration": "",
            "limit": "Always active; no resource generated by this row.",
            "counterplay": "Use direct damage, honest force, unresolved betrayal, self-deception pressure, non-emotional hazards, or effects outside truth/reflection scope.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Fixed Scope — Fragile Clarity",
            "stage": "Awakened",
            "type": "Passive",
            "trigger": "Rules interpretation for this Foundation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Glass Heart Meridian supports legal Glass, Beauty, Illusion, Radiance, Protection, The Hidden Eye, Dreams, Music, Water, Fate, Sword, Life, and Karma methods only when they clearly express emotional truth, reflection without denial, revealed falsehood, beauty without self-erasure, vulnerability protected rather than hidden, illusion-breaking, mirror defense, glass clarity, radiant honesty, grief flow, apology, or repair of trust. It does not support self-deception as protection, beauty-as-worth, glamour that replaces identity, reflecting pain onto allies, emotional numbness, image management, or brittle invulnerability.",
            "duration": "",
            "limit": "Always active interpretation row; no resource generated.",
            "counterplay": "Deny scope for self-deception, glamour identity replacement, image management, harm-reflection onto allies, or brittle numbness.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Generate Glass Reflection",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "Once per round, after a qualifying illusion, charm, fear, deception, gaze, beauty-pressure, emotional-manipulation, radiant/glass-reflection, or falsehood-based psychic save/check resolves in your favor, or after you spend CP on a Fixed Glass Heart Scope technique/effect.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Glass Reflection is a short-lived trace of clear-heart refraction. Friendly staged lies, harmless performances, training illusions, repeated non-threatening prompts, self-inflicted drama, farmed social checks, and deceptions you arranged to trigger the Foundation do not qualify.",
            "duration": "",
            "limit": "Once per round; max 1; expires end of next turn; refreshes not stacks.",
            "counterplay": "Use honest threats, non-falsehood pressure, or bait self-deception/betrayal instead of feeding clean reflection triggers.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Shatter-Guard",
            "stage": "Awakened",
            "type": "Reaction",
            "trigger": "You take damage from a critical hit, psychic attack, radiant reflection, glass effect, illusion, charm/fear/gaze/beauty pressure, betrayal-linked effect, or emotional manipulation within Fixed Glass Heart Scope.",
            "cost": "Spend 1 Glass Reflection",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Shatter-Guard is a real Reaction and cannot be used if the Glass Reflection was generated by the same event. It may reduce a non-damage consequence only when the GM can express the consequence as a concrete step reduction, save bonus, or strain prevention.",
            "duration": "",
            "limit": "Requires existing Glass Reflection; one Reaction; no same-event spend.",
            "counterplay": "Attack outside scope, force multiple reactions, use direct bodily harm, or trigger betrayal/self-deception Strain.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Clear-Heart Rebuke",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You hit a target or a creature fails a save against your Fixed Glass Heart Scope technique/effect while you already have Glass Reflection.",
            "cost": "Spend 1 Glass Reflection",
            "range": "Technique range",
            "target": "One affected creature or revealed falsehood",
            "attack_or_save": "Attack/save of triggering effect",
            "effect": "This is not universal lie detection. It reveals an active and scene-relevant falsehood connected to the target, effect, or emotional pressure. If no such falsehood exists, only the damage rider applies.",
            "duration": "",
            "limit": "Requires existing Glass Reflection; no same-event spend; no complete character-sheet reveal.",
            "counterplay": "Use true statements, mundane concealment outside scope, layered wards, or targets with no active relevant falsehood.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Transparent Witness",
            "stage": "Awakened",
            "type": "No Action / Triggered",
            "trigger": "You make a Fixed Glass Heart Scope check/save involving truth, illusion-breaking, emotional honesty, Beauty without self-erasure, trust repair, or clear reflection.",
            "cost": "Spend 1 Glass Reflection",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Check or saving throw",
            "effect": "Transparent Witness is self-facing unless a Perfected or lineage feature explicitly expands it. It cannot erase major injuries, severe deviations, or ordinary social consequences by itself.",
            "duration": "",
            "limit": "Requires existing Glass Reflection; no same-event spend; cannot erase major consequences.",
            "counterplay": "Pressure the character with honest pain, consequences beyond a single roll, or refusal to accept vulnerability.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          }
        ],
        "integrated": [],
        "refined": [
          {
            "name": "Refined — Beauty Without Lie",
            "stage": "Refined",
            "type": "No Action / Triggered",
            "trigger": "You spend CP on a compatible Beauty, Glass, Radiance, Protection, Music, Life, Karma, or Spirit Awakening technique that reveals truth, protects vulnerability, repairs trust, or refuses deception.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "The technique must actually risk or express vulnerability, truth, repair, or refusal of false image. Pure glamour, vanity, seduction, image management, or identity replacement does not qualify.",
            "duration": "",
            "limit": "Once per round; requires qualifying CP spend; no resource generated by this row.",
            "counterplay": "Use false beauty temptation, non-truth techniques, or attacks that do not allow setup.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          },
          {
            "name": "Refined — Refracted Technique",
            "stage": "Refined",
            "type": "Passive",
            "trigger": "You attempt a compatible Glass, Beauty, Illusion, Radiance, Protection, The Hidden Eye, Dreams, or Music Technique Forging check or Foundation Challenge that includes vulnerability, truth, reflection, or shatter-risk limitation.",
            "cost": "",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "Cultivation Check / Technique Forging Check",
            "effect": "This is not a blanket crafting discount. It cannot apply to glamour without risk, false identities, beauty-as-worth, or emotionless glass armor.",
            "duration": "",
            "limit": "Only when the limitation is meaningful and accepted by the GM.",
            "counterplay": "Deny for safe, purely optimized, false-image, or non-vulnerable techniques.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          }
        ],
        "perfected": [
          {
            "name": "Perfected — Glass Heart Refraction",
            "stage": "Perfected",
            "type": "Bonus Action",
            "trigger": "You enter a major combat or emotionally decisive scene and choose to stand in transparent clarity rather than hide behind beauty, denial, or reflection.",
            "cost": "2 CP",
            "range": "Self",
            "target": "Self",
            "attack_or_save": "",
            "effect": "Glass Heart Refraction is a Perfected state, not a passive always-on aura. It does not increase the maximum Glass Reflection above 1 and does not allow same-event spending.",
            "duration": "",
            "limit": "Once per long rest; costs 2 CP; 1 minute; max Reflection remains 1.",
            "counterplay": "Use honest force, make the character choose between image and truth, bait self-protective lies, or attack outside falsehood scope.",
            "source_spheres": [
              "Glass",
              "Beauty",
              "Illusion",
              "Radiance",
              "Protection",
              "The Hidden Eye",
              "Dreams",
              "Music",
              "Water",
              "Fate",
              "Sword",
              "Life",
              "Karma"
            ]
          }
        ]
      },
      "compatibility": {
        "legal_spheres": [
          "Glass",
          "Beauty",
          "Illusion",
          "Radiance",
          "Protection",
          "The Hidden Eye",
          "Dreams",
          "Music",
          "Water",
          "Fate",
          "Sword",
          "Life",
          "Karma"
        ],
        "expression_notes": [],
        "does_not_grant": [
          "No free Sphere or talent access.",
          "No Method, Recorded Art, Forged Technique, or Immortal Art unless a feature explicitly says otherwise.",
          "No permission to ignore action economy, range, target, cost, duration, or trigger requirements."
        ]
      },
      "risks": {
        "burdens": [
          {
            "id": "hairline_heart_burden",
            "display_name": "Hairline Heart",
            "severity": "1-3",
            "text": "When betrayal, self-deception, beauty-as-worth, reflected harm, or forceful emotional suppression stresses the Foundation, relevant Glass Heart scope DCs increase by +2 x Severity. Serious unresolved betrayal or deliberate self-deception can increase Severity. Suppression requires confession, trusted witness, Music healing, Water grief flow, Life heart treatment, Karma apology, or rejecting false beauty."
          }
        ],
        "hidden_injuries": [
          {
            "id": "shattered_heart_meridian",
            "display_name": "Shattered Heart Meridian",
            "severity": "1-4",
            "text": "A hidden injury to heart-meridians, throat, eyes, emotional aura, and reflection channels. Relevant emotional truth, reflection, beauty, illusion, trust, and breakthrough checks increase by +2 x Severity. Failure by 5 or more may increase Severity. Recovery usually requires Music, Life, Water, trusted witness, true beauty rite, Karma apology, or mirror-breaking treatment; 3 x Severity progress reduces Severity by 1."
          }
        ],
        "strains": [
          {
            "id": "cracked_reflection",
            "display_name": "Cracked Reflection",
            "severity": "1-3",
            "text": "Temporary suppression of Glass Reflection, Glass Heart Refraction, Clear-Heart Rebuke, or Beauty Without Lie after betrayal, psychic/radiant/glass critical pressure, failed illusion save by 5+, deliberate self-deception, or public beauty humiliation. At Severity 2+, Glass/Beauty/Illusion/Radiance checks have DC +2; at Severity 3, failure by 5 or more can apply Shattered Heart Meridian."
          }
        ],
        "deviations": [
          {
            "id": "perfect_reflection_deviation",
            "display_name": "Perfect Reflection",
            "severity": "1-4",
            "text": "Temptation: reflect everything so nothing reaches you. Offered benefits may impose disadvantage on one attack/social pressure, grant advantage on one Beauty/Glass/Illusion/social-defense check, reflect PB psychic/radiant damage to an emotional aggressor, or suppress grief/shame/fear for one scene. Cost: Deviation progress +1; at Progress 3, Severity +1 and progress resets. Correction requires vulnerability, ugly truth, apology without image management, or stopping reflected harm."
          },
          {
            "id": "beauty_without_wound_deviation",
            "display_name": "Beauty Without Wound",
            "severity": "1-3",
            "text": "Temptation: become a flawless image so no one can see the wound. Grants short scene social protection or beauty pressure at the cost of emotional numbness and Hairline Heart escalation. Correction requires allowing a trusted witness to see imperfection and choosing truth over image."
          }
        ]
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [
        {
          "name": "Lineage Support — Mirror-Heart Diagnosis",
          "stage": "Awakened",
          "type": "Downtime / Scene Utility",
          "trigger": "You examine a willing student, patient, disciple, or inherited trace for clear-heart, mirror-vein, illusion-breaker, or beauty-without-lie potential.",
          "cost": "1 hour and appropriate mirror, water, music, or truth rite materials",
          "range": "Touch or 10 ft",
          "target": "One willing creature or lineage trace",
          "attack_or_save": "Cultivation Check",
          "effect": "This is a lineage/downtime support row and is not exported to GM Screen combat/action tables by default.",
          "duration": "",
          "limit": "Downtime or explicit noncombat scene only.",
          "counterplay": "Cannot diagnose unwilling targets automatically; concealment, trauma, false beauty, or active curses may block reading.",
          "source_spheres": [
            "Glass",
            "Beauty",
            "Illusion",
            "Radiance",
            "Protection",
            "The Hidden Eye",
            "Dreams",
            "Music",
            "Water",
            "Fate",
            "Sword",
            "Life",
            "Karma"
          ]
        }
      ],
      "source_gaps": [
        "No standalone structured repair-practice rows.",
        "No standalone structured Foundation Challenge rows."
      ]
    },
    {
      "foundation_id": "chakra_foundation_moon_moth_dream_eye_v0_1",
      "name": "Moon-Moth Dream Eye",
      "number": 31,
      "catalog_code": "CH01",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Eye",
        "typical_role": "dream, omen, hidden influence, anti-ambush",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Moon-Moth Dream Eye is a Chakra Foundation centered on dream, omen, hidden influence, anti-ambush.",
        "visible_sign": "Its visible signs arise through the Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Eye Wheel: dream, omen, hidden influence, anti-ambush."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_tiger_furnace_stomach_v0_1",
      "name": "Tiger Furnace Stomach",
      "number": 32,
      "catalog_code": "CH02",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace",
        "typical_role": "combat overcharge, digestion, explosive palm, poison-burning",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Tiger Furnace Stomach is a Chakra Foundation centered on combat overcharge, digestion, explosive palm, poison-burning.",
        "visible_sign": "Its visible signs arise through the Furnace Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace Wheel: combat overcharge, digestion, explosive palm, poison-burning."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_jade_orchard_heart_v0_1",
      "name": "Jade Orchard Heart",
      "number": 33,
      "catalog_code": "CH03",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Heart",
        "typical_role": "healing, vitality, medicine, companion care, fertility and youth",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Jade Orchard Heart is a Chakra Foundation centered on healing, vitality, medicine, companion care, fertility and youth.",
        "visible_sign": "Its visible signs arise through the Heart Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Heart Wheel: healing, vitality, medicine, companion care, fertility and youth."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_living_stone_imbuer_palm_v0_1",
      "name": "Living Stone Imbuer Palm",
      "number": 34,
      "catalog_code": "CH04",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace or Throat",
        "typical_role": "chakra imbuing, tools, armor, formation-city craft",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Living Stone Imbuer Palm is a Chakra Foundation centered on chakra imbuing, tools, armor, formation-city craft.",
        "visible_sign": "Its visible signs arise through the Furnace or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace or Throat Wheel: chakra imbuing, tools, armor, formation-city craft."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_serpent_moon_venom_veins_v0_1",
      "name": "Serpent-Moon Venom Veins",
      "number": 35,
      "catalog_code": "CH05",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water",
        "typical_role": "poison, antidote, beauty, blood-fluid, sensual medicine",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Serpent-Moon Venom Veins is a Chakra Foundation centered on poison, antidote, beauty, blood-fluid, sensual medicine.",
        "visible_sign": "Its visible signs arise through the Water Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water Wheel: poison, antidote, beauty, blood-fluid, sensual medicine."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_honey_thunder_command_throat_v0_1",
      "name": "Honey-Thunder Command Throat",
      "number": 36,
      "catalog_code": "CH06",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Throat",
        "typical_role": "voice, song, command, oath, social support",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Honey-Thunder Command Throat is a Chakra Foundation centered on voice, song, command, oath, social support.",
        "visible_sign": "Its visible signs arise through the Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Throat Wheel: voice, song, command, oath, social support."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_black_jaguar_shadow_pelt_v0_1",
      "name": "Black Jaguar Shadow Pelt",
      "number": 37,
      "catalog_code": "CH07",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Eye",
        "typical_role": "hunter, scout, predator, ambush, fear resistance",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Black Jaguar Shadow Pelt is a Chakra Foundation centered on hunter, scout, predator, ambush, fear resistance.",
        "visible_sign": "Its visible signs arise through the Root or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Eye Wheel: hunter, scout, predator, ambush, fear resistance."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_crowned_banyan_breath_v0_1",
      "name": "Crowned Banyan Breath",
      "number": 38,
      "catalog_code": "CH08",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Mythic",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Crown",
        "typical_role": "living site, ancestor grove, anti-possession, identity root",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Crowned Banyan Breath is a Chakra Foundation centered on living site, ancestor grove, anti-possession, identity root.",
        "visible_sign": "Its visible signs arise through the Crown Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Crown Wheel: living site, ancestor grove, anti-possession, identity root."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_monsoon_drum_lung_v0_1",
      "name": "Monsoon Drum Lung",
      "number": 39,
      "catalog_code": "CH09",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Throat or Heart",
        "typical_role": "storm breath, rain ritual, drum, group morale",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Monsoon Drum Lung is a Chakra Foundation centered on storm breath, rain ritual, drum, group morale.",
        "visible_sign": "Its visible signs arise through the Throat or Heart Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Throat or Heart Wheel: storm breath, rain ritual, drum, group morale."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_river_crocodile_death_roll_spine_v0_1",
      "name": "River-Crocodile Death-Roll Spine",
      "number": 40,
      "catalog_code": "CH10",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Water",
        "typical_role": "grappling, river ambush, death-roll holds",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "River-Crocodile Death-Roll Spine is a Chakra Foundation centered on grappling, river ambush, death-roll holds.",
        "visible_sign": "Its visible signs arise through the Root or Water Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Water Wheel: grappling, river ambush, death-roll holds."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_firefly_ancestor_lantern_v0_1",
      "name": "Firefly Ancestor Lantern",
      "number": 41,
      "catalog_code": "CH11",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Heart or Crown",
        "typical_role": "ancestors, memorial rites, companion protection",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Firefly Ancestor Lantern is a Chakra Foundation centered on ancestors, memorial rites, companion protection.",
        "visible_sign": "Its visible signs arise through the Heart or Crown Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Heart or Crown Wheel: ancestors, memorial rites, companion protection."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_emerald_scarab_shell_v0_1",
      "name": "Emerald Scarab Shell",
      "number": 42,
      "catalog_code": "CH12",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Crown",
        "typical_role": "armor, endurance, disease survival, burden-bearing",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Emerald Scarab Shell is a Chakra Foundation centered on armor, endurance, disease survival, burden-bearing.",
        "visible_sign": "Its visible signs arise through the Root or Crown Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Crown Wheel: armor, endurance, disease survival, burden-bearing."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_lotus_silkworm_renewal_cocoon_v0_1",
      "name": "Lotus-Silkworm Renewal Cocoon",
      "number": 43,
      "catalog_code": "CH13",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Crown",
        "typical_role": "recovery, cocoon healing, renewal, metamorphosis",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Lotus-Silkworm Renewal Cocoon is a Chakra Foundation centered on recovery, cocoon healing, renewal, metamorphosis.",
        "visible_sign": "Its visible signs arise through the Water or Crown Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Crown Wheel: recovery, cocoon healing, renewal, metamorphosis."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_ironwood_root_oath_bones_v0_1",
      "name": "Ironwood Root Oath Bones",
      "number": 44,
      "catalog_code": "CH14",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Heart",
        "typical_role": "protector, oath, forced movement resistance",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Ironwood Root Oath Bones is a Chakra Foundation centered on protector, oath, forced movement resistance.",
        "visible_sign": "Its visible signs arise through the Root or Heart Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Heart Wheel: protector, oath, forced movement resistance."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_laughing_fever_monkey_tail_v0_1",
      "name": "Laughing Fever Monkey Tail",
      "number": 45,
      "catalog_code": "CH15",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace or Throat",
        "typical_role": "mobility, trickster, monkey style, fever laughter",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Laughing Fever Monkey Tail is a Chakra Foundation centered on mobility, trickster, monkey style, fever laughter.",
        "visible_sign": "Its visible signs arise through the Furnace or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace or Throat Wheel: mobility, trickster, monkey style, fever laughter."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_pearl_river_mirror_skin_v0_1",
      "name": "Pearl River Mirror Skin",
      "number": 46,
      "catalog_code": "CH16",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Eye",
        "typical_role": "beauty defense, reflection, anti-charm, identity skin",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Pearl River Mirror Skin is a Chakra Foundation centered on beauty defense, reflection, anti-charm, identity skin.",
        "visible_sign": "Its visible signs arise through the Water or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Eye Wheel: beauty defense, reflection, anti-charm, identity skin."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_golden_bee_hive_heart_v0_1",
      "name": "Golden Bee Hive Heart",
      "number": 47,
      "catalog_code": "CH17",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Heart or Throat",
        "typical_role": "swarm order, honey medicine, fertility, labor, group support",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Golden Bee Hive Heart is a Chakra Foundation centered on swarm order, honey medicine, fertility, labor, group support.",
        "visible_sign": "Its visible signs arise through the Heart or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Heart or Throat Wheel: swarm order, honey medicine, fertility, labor, group support."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_obsidian_toad_gall_v0_1",
      "name": "Obsidian Toad Gall",
      "number": 48,
      "catalog_code": "CH18",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace or Water",
        "typical_role": "toxin endurance, curse-sickness, alchemy, rot survival",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Obsidian Toad Gall is a Chakra Foundation centered on toxin endurance, curse-sickness, alchemy, rot survival.",
        "visible_sign": "Its visible signs arise through the Furnace or Water Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace or Water Wheel: toxin endurance, curse-sickness, alchemy, rot survival."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_white_crane_wind_tendons_v0_1",
      "name": "White Crane Wind Tendons",
      "number": 49,
      "catalog_code": "CH19",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Throat",
        "typical_role": "leaping, evasion, breath-lightness, graceful movement",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "White Crane Wind Tendons is a Chakra Foundation centered on leaping, evasion, breath-lightness, graceful movement.",
        "visible_sign": "Its visible signs arise through the Root or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Throat Wheel: leaping, evasion, breath-lightness, graceful movement."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_red_lotus_war_dance_blood_v0_1",
      "name": "Red Lotus War Dance Blood",
      "number": 50,
      "catalog_code": "CH20",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Furnace",
        "typical_role": "battle rhythm, blood courage, dance, passion, controlled frenzy",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Red Lotus War Dance Blood is a Chakra Foundation centered on battle rhythm, blood courage, dance, passion, controlled frenzy.",
        "visible_sign": "Its visible signs arise through the Water or Furnace Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Furnace Wheel: battle rhythm, blood courage, dance, passion, controlled frenzy."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_blue_morpho_veil_wings_v0_1",
      "name": "Blue Morpho Veil Wings",
      "number": 51,
      "catalog_code": "CH21",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Eye",
        "typical_role": "veils, beauty, evasive phasing, butterfly mirage",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Blue Morpho Veil Wings is a Chakra Foundation centered on veils, beauty, evasive phasing, butterfly mirage.",
        "visible_sign": "Its visible signs arise through the Water or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Eye Wheel: veils, beauty, evasive phasing, butterfly mirage."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_thunder_orchid_marrow_v0_1",
      "name": "Thunder Orchid Marrow",
      "number": 52,
      "catalog_code": "CH22",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace or Heart",
        "typical_role": "storm-yang vitality, orchid medicine, thunder-body recovery",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Thunder Orchid Marrow is a Chakra Foundation centered on storm-yang vitality, orchid medicine, thunder-body recovery.",
        "visible_sign": "Its visible signs arise through the Furnace or Heart Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace or Heart Wheel: storm-yang vitality, orchid medicine, thunder-body recovery."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_jade_ant_legion_nerves_v0_1",
      "name": "Jade Ant Legion Nerves",
      "number": 53,
      "catalog_code": "CH23",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Throat",
        "typical_role": "swarm discipline, tunnel labor, battlefield coordination",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Jade Ant Legion Nerves is a Chakra Foundation centered on swarm discipline, tunnel labor, battlefield coordination.",
        "visible_sign": "Its visible signs arise through the Root or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Throat Wheel: swarm discipline, tunnel labor, battlefield coordination."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_eclipse_python_crown_coil_v0_1",
      "name": "Eclipse Python Crown Coil",
      "number": 54,
      "catalog_code": "CH24",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Mythic",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Crown or Water",
        "typical_role": "constriction, hypnosis, eclipse stillness, identity pressure",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Eclipse Python Crown Coil is a Chakra Foundation centered on constriction, hypnosis, eclipse stillness, identity pressure.",
        "visible_sign": "Its visible signs arise through the Crown or Water Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Crown or Water Wheel: constriction, hypnosis, eclipse stillness, identity pressure."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_crimson_macaw_voice_plumes_v0_1",
      "name": "Crimson Macaw Voice Plumes",
      "number": 55,
      "catalog_code": "CH25",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Throat or Eye",
        "typical_role": "color, voice, display, air, morale, social disruption",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Crimson Macaw Voice Plumes is a Chakra Foundation centered on color, voice, display, air, morale, social disruption.",
        "visible_sign": "Its visible signs arise through the Throat or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Throat or Eye Wheel: color, voice, display, air, morale, social disruption."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_black_lotus_hunger_navel_v0_1",
      "name": "Black Lotus Hunger Navel",
      "number": 56,
      "catalog_code": "CH26",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Furnace or Water",
        "typical_role": "hunger, fasting, poison, shadow appetite, Drain temptation",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Black Lotus Hunger Navel is a Chakra Foundation centered on hunger, fasting, poison, shadow appetite, Drain temptation.",
        "visible_sign": "Its visible signs arise through the Furnace or Water Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Furnace or Water Wheel: hunger, fasting, poison, shadow appetite, Drain temptation."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_rainforest_colossus_shoulders_v0_1",
      "name": "Rainforest Colossus Shoulders",
      "number": 57,
      "catalog_code": "CH27",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Heart",
        "typical_role": "massive endurance, guardian carrying, terrain pressure, beast-scale body",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Rainforest Colossus Shoulders is a Chakra Foundation centered on massive endurance, guardian carrying, terrain pressure, beast-scale body.",
        "visible_sign": "Its visible signs arise through the Root or Heart Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Heart Wheel: massive endurance, guardian carrying, terrain pressure, beast-scale body."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_thousand_spider_silk_nerves_v0_1",
      "name": "Thousand-Spider Silk Nerves",
      "number": 58,
      "catalog_code": "CH28",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Eye or Throat",
        "typical_role": "web sense, threads, traps, puppetry, delicate control",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Thousand-Spider Silk Nerves is a Chakra Foundation centered on web sense, threads, traps, puppetry, delicate control.",
        "visible_sign": "Its visible signs arise through the Eye or Throat Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Eye or Throat Wheel: web sense, threads, traps, puppetry, delicate control."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_amber_mosquito_blood_needle_v0_1",
      "name": "Amber Mosquito Blood Needle",
      "number": 59,
      "catalog_code": "CH29",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Eye",
        "typical_role": "blood scent, piercing, poison, disease, Drain temptation",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Amber Mosquito Blood Needle is a Chakra Foundation centered on blood scent, piercing, poison, disease, Drain temptation.",
        "visible_sign": "Its visible signs arise through the Water or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Eye Wheel: blood scent, piercing, poison, disease, Drain temptation."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_glass_frog_transparent_veins_v0_1",
      "name": "Glass Frog Transparent Veins",
      "number": 60,
      "catalog_code": "CH30",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Eye",
        "typical_role": "transparency, hidden movement, living camouflage, exposed truth",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Glass Frog Transparent Veins is a Chakra Foundation centered on transparency, hidden movement, living camouflage, exposed truth.",
        "visible_sign": "Its visible signs arise through the Water or Eye Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Eye Wheel: transparency, hidden movement, living camouflage, exposed truth."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_kapok_sky_root_crown_v0_1",
      "name": "Kapok Sky-Root Crown",
      "number": 61,
      "catalog_code": "CH31",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Root or Crown",
        "typical_role": "canopy identity, height, roots, wind, shelter, vertical territory",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Kapok Sky-Root Crown is a Chakra Foundation centered on canopy identity, height, roots, wind, shelter, vertical territory.",
        "visible_sign": "Its visible signs arise through the Root or Crown Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Root or Crown Wheel: canopy identity, height, roots, wind, shelter, vertical territory."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    },
    {
      "foundation_id": "chakra_foundation_scarlet_salamander_regrowth_tail_v0_1",
      "name": "Scarlet Salamander Regrowth Tail",
      "number": 62,
      "catalog_code": "CH32",
      "catalog_status": "theoretical_draft",
      "profile": {
        "grade": "Major",
        "status": "Theoretical draft",
        "default_stage": "common_expression",
        "primary_path": "Chakra",
        "seated_wheel": "Water or Furnace",
        "typical_role": "shedding, survival, fire-water recovery, limb sacrifice, regrowth discipline",
        "complexity": "Not rateable"
      },
      "overview": {
        "summary": "Scarlet Salamander Regrowth Tail is a Chakra Foundation centered on shedding, survival, fire-water recovery, limb sacrifice, regrowth discipline.",
        "visible_sign": "Its visible signs arise through the Water or Furnace Wheel and the character’s embodied chakra route.",
        "warning": "Power Sphere Review and embodied-source restrictions remain in force.",
        "dao_principle": "Embodied Chakra specialization through the Water or Furnace Wheel: shedding, survival, fire-water recovery, limb sacrifice, regrowth discipline."
      },
      "resource": null,
      "features": {
        "awakened": [],
        "integrated": [],
        "refined": [],
        "perfected": []
      },
      "compatibility": {
        "legal_spheres": [],
        "expression_notes": [
          "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
        ],
        "does_not_grant": [
          "No inferred mechanics or grants."
        ]
      },
      "risks": {
        "burdens": [],
        "hidden_injuries": [],
        "strains": [],
        "deviations": []
      },
      "repair_practices": [],
      "foundation_challenges": [],
      "lineage_hooks": [],
      "source_gaps": [
        "Exact benefits missing.",
        "Resource loop missing.",
        "Executable features missing.",
        "Stage progression missing.",
        "Risk and repair systems missing."
      ],
      "source_requirement": "Tianxia_Chakra_Foundation_Catalog_Batches_01_08_Merged_v0_1.md",
      "builder_notice": "The Chakra master catalog is a theoretical draft. The factory must import the exact source entry before finalizing mechanics."
    }
  ]
};
