const GM_SCREEN_HF05B_PATCH = "v1.11.0-HF05B-IMPORT-SURFACE-FOUNDATION-UI-2026-06-25";
const TIANXIA_TRIBULATION_UI_PATCH = "v1.11.0-HF05C-TRIBULATION-INJURY-DEVIATION-COCKPIT-2026-06-25";
const TIANXIA_TRIBULATION_READABILITY_PATCH = "v1.11.0-HF05C-TRIBULATION-READABILITY-PASS-2026-06-25";
const TIANXIA_GM_HF05D_NPC_FIGHT_PROMPT_RESTORE = "v1.11.0-HF05D-NPC-FIGHT-PROMPT-HUNGER-CATALOGUE-2026-06-25";
const TIANXIA_GM_HF05M_COMPOSITE_PLAYBOOK_TAB = "v1.11.0-HF05M-COMPOSITE-PLAYBOOK-TAB-2026-06-27";
const TIANXIA_GM_HF05N_COMPOSITE_PRIORITY_TABLE = "v1.11.0-HF05N-COMPOSITE-PLAYBOOK-PRIORITY-TABLE-2026-06-27";
const TIANXIA_GM_HF05Q_FOUNDATION_STAGE_REFRESH = "v1.11.0-HF05Q-FOUNDATION-STAGE-BENEFIT-BURDEN-REFRESH-2026-06-28";
const TIANXIA_GM_HF05R_FOUNDATION_READABLE_TEXT = "v1.11.0-HF05R-FOUNDATION-READABLE-TEXT-POLISH-2026-06-28";
const TIANXIA_GM_HF05T_VISIBLE_ARTIFACT_POLISH = "v1.11.0-HF05T-VISIBLE-REGISTRY-ID-POLISH-2026-06-28";
const TIANXIA_GM_HF05W_STATE_IMPORT_REPAIR = "v1.11.0-HF05W-STATE-IMPORT-CLOSURE-2026-06-28";
const TIANXIA_GM_HF05Z_IMPORT_INTEGRITY_EMPTY_REGISTRY_FIX = "v1.11.0-HF05Z-IMPORT-INTEGRITY-EMPTY-REGISTRY-FIX-2026-06-28";

const TRIGRAMS = {
  Qian: {
    label: "Qian / Heaven",
    keys: "force, mandate, initiative, command, creative pressure",
    question: "What do you do when power, authority, or initiative presses down?",
    failure: "Pride, overreach, command without listening."
  },
  Kun: {
    label: "Kun / Earth",
    keys: "receptivity, support, service, bearing, nourishment, humility",
    question: "What do you do when the situation asks you to carry, receive, or support?",
    failure: "Self-erasure, passivity, support becoming captivity."
  },
  Zhen: {
    label: "Zhen / Thunder",
    keys: "shock, awakening, first movement, crisis, disruption",
    question: "What wakes up when the world strikes suddenly?",
    failure: "Panic, reckless motion, escalation for its own sake."
  },
  Xun: {
    label: "Xun / Wind-Wood",
    keys: "subtle entry, gradual influence, persuasion, growth, penetration",
    question: "What enters slowly, quietly, or persistently until the shape changes?",
    failure: "Manipulation, creeping control, never declaring the truth."
  },
  Kan: {
    label: "Kan / Water",
    keys: "peril, abyss, hidden danger, fear, depth, uncertainty",
    question: "What do you do when you cannot see the bottom?",
    failure: "Panic, secrecy, despair, drowning others to stay afloat."
  },
  Li: {
    label: "Li / Fire",
    keys: "clarity, visibility, attachment, illumination, exposure, what clings",
    question: "What becomes visible, and what does that visibility demand?",
    failure: "Burning nuance, exposure as violence, clinging too hard."
  },
  Gen: {
    label: "Gen / Mountain",
    keys: "stopping, boundary, stillness, restraint, gate, refusal",
    question: "When must motion stop, and what boundary is real?",
    failure: "Dead immobility, refusal to grow, protection becoming prison."
  },
  Dui: {
    label: "Dui / Lake-Marsh",
    keys: "joy, exchange, speech, openness, temptation, community",
    question: "What is shared, offered, enjoyed, or bargained away?",
    failure: "Indulgence, flattery, pleasure replacing truth."
  }
};

const SPHERES = [
  ["Air", "Qi Cultivation", ["Xun", "Zhen", "Dui"], ["Gen", "Kun", "Kan"], ["Xun Line 6", "Dui Line 6", "Zhen Line 6"], ["breathes", "moves", "redirects", "lifts", "scatters"], "Air is freedom through breath, current, vector, and release."],
  ["Alchemy", "Qi Cultivation, sometimes Spirit or Body", ["Li", "Xun", "Gen"], ["Zhen", "Kan", "Dui"], ["Li Line 6", "Xun Line 6", "Dui Line 6"], ["refines", "measures", "distills", "risks", "transforms"], "Alchemy separates impurity from potential."],
  ["Ash", "Qi Cultivation, sometimes Spirit Awakening", ["Li", "Gen", "Kun"], ["Zhen", "Xun", "Dui"], ["Gen Line 6", "Kun Line 6", "Li Line 6"], ["settles", "smothers", "remembers", "buries", "remains"], "Ash is aftermath, remnant, smothering, and what remains after fire."],
  ["Athletics", "Body Refining", ["Zhen", "Qian", "Xun"], ["Gen", "Kan", "Kun"], ["Zhen Line 6", "Qian Line 6", "Gen Line 6"], ["moves", "leaps", "climbs", "escapes", "arrives"], "Athletics turns the trained body into route, timing, and arrival."],
  ["Axes", "Body Refining or Qi Cultivation", ["Qian", "Gen", "Zhen"], ["Xun", "Kan", "Dui"], ["Qian Line 6", "Gen Line 6", "Zhen Line 6"], ["hews", "hooks", "breaks", "throws", "executes"], "Axes make a single committed line answer guard, weight, and false durability."],
  ["Barrage", "Body Refining or Qi Cultivation", ["Zhen", "Xun", "Qian"], ["Gen", "Kan", "Dui"], ["Zhen Line 6", "Xun Line 6", "Dui Line 6"], ["fires", "saturates", "pins", "threads", "suppresses"], "Barrage makes repetition into pressure, denial, and tempo."],
  ["Beastmastery", "Spirit Awakening, Qi Cultivation, or Body Refining", ["Kun", "Xun", "Dui"], ["Qian", "Kan", "Zhen"], ["Qian Line 6", "Kun Line 6", "Dui Line 6"], ["bonds", "listens", "commands", "feeds", "evolves"], "Beastmastery grows the self through bond with another living will."],
  ["Berserker", "Body Refining", ["Zhen", "Qian", "Kan"], ["Gen", "Kun", "Li"], ["Zhen Line 6", "Qian Line 6", "Kan Line 6"], ["rages", "bleeds", "presses", "endures", "shatters"], "Berserker turns pain, fury, and survival into honest force."],
  ["Blacksmith", "Qi Cultivation or Body Refining", ["Qian", "Gen", "Li"], ["Xun", "Kan", "Dui"], ["Qian Line 6", "Gen Line 6", "Li Line 6"], ["forges", "tempers", "repairs", "arms", "reshapes"], "Blacksmith makes strength useful through heat, impact, and patience."],
  ["Blood", "Qi Cultivation, Spirit Awakening, sometimes Body Refining", ["Kan", "Kun", "Li"], ["Gen", "Dui", "Zhen"], ["Kan Line 6", "Qian Line 6", "Dui Line 6"], ["bleeds", "binds", "inherits", "sacrifices", "tracks"], "Blood carries vitality, lineage, sacrifice, and debt."],
  ["Brute", "Body Refining", ["Qian", "Zhen", "Gen"], ["Kun", "Xun", "Kan"], ["Qian Line 6", "Zhen Line 6", "Dui"], ["endures", "breaks", "charges", "carries", "overpowers"], "Brute answers pressure by making the body more real than the obstacle."],
  ["Chains", "Qi Cultivation, Body Refining, or Spirit Awakening", ["Gen", "Kan", "Kun"], ["Dui", "Xun", "Zhen"], ["Gen Line 6", "Qian Line 6", "Kan Line 6"], ["binds", "anchors", "restrains", "captures", "links"], "Chains turn connection into restraint, rescue, capture, or consequence."],
  ["Daemonic Cultivation", "Qi Cultivation or Spirit Awakening, rare Body expression", ["Kan", "Zhen", "Qian"], ["Kun", "Li", "Gen"], ["Kan Line 6", "Qian Line 6", "Dui Line 6"], ["devours", "steals", "bargains", "corrupts", "ascends"], "Daemonic Cultivation is stolen growth with a price."],
  ["Dark", "Spirit Awakening", ["Kan", "Kun", "Gen"], ["Li", "Dui", "Qian"], ["Kan Line 6", "Gen Line 6", "Kun Line 6"], ["hides", "isolates", "frightens", "passes", "conceals"], "Dark cultivates hidden truth, unseen passage, fear, and shelter."],
  ["Death", "Qi Cultivation or Spirit Awakening", ["Gen", "Kan", "Kun"], ["Li", "Dui", "Xun"], ["Gen Line 6", "Kan Line 6", "Kun Line 6"], ["ends", "buries", "releases", "withers", "remembers"], "Death treats endings as law, release, memory, and boundary."],
  ["Destruction", "Qi Cultivation", ["Zhen", "Qian", "Li"], ["Kun", "Gen", "Xun"], ["Qian Line 6", "Zhen Line 6", "Li Line 6"], ["breaks", "blasts", "overwhelms", "ends", "shatters"], "Destruction is direct cultivated impact against false permanence."],
  ["Disease", "Qi Cultivation or Spirit Awakening", ["Kan", "Xun", "Kun"], ["Li", "Gen", "Dui"], ["Kan Line 6", "Xun Line 6", "Kun Line 6"], ["infects", "diagnoses", "quarantines", "weakens", "immunizes"], "Disease is weakness spreading through patterns until named, quarantined, or cured."],
  ["Dreams", "Spirit Awakening, sometimes Qi Cultivation", ["Kan", "Dui", "Li"], ["Gen", "Qian", "Zhen"], ["Kan Line 6", "Dui Line 6", "Li Line 6"], ["dreams", "remembers", "haunts", "heals", "reveals"], "Dreams make the sleeping self, image, memory, and fear into real pressure."],
  ["Drunken Style", "Body Refining, sometimes Spirit", ["Zhen", "Kan", "Dui"], ["Gen", "Li", "Qian"], ["Kan Line 6", "Dui Line 6", "Zhen Line 6"], ["sways", "stumbles", "converts", "baits", "rebounds"], "Drunken Style refines imbalance into timing, bait, and converted momentum."],
  ["Dual Wielding", "Body Refining", ["Zhen", "Dui", "Xun"], ["Gen", "Kan", "Qian"], ["Dui Line 6", "Zhen Line 6", "Xun Line 6"], ["alternates", "pressures", "guards", "cuts", "overwhelms"], "Dual Wielding turns divided motion into one rhythm and two threats."],
  ["Earth", "Qi Cultivation or Body Refining", ["Kun", "Gen", "Qian"], ["Xun", "Zhen", "Kan"], ["Kun Line 6", "Gen Line 6", "Qian Line 6"], ["roots", "bears", "fortifies", "grounds", "endures"], "Earth is bearing, grounding, load, and permanence under pressure."],
  ["Fate", "Spirit Awakening", ["Xun", "Zhen", "Kan"], ["Qian", "Gen", "Li"], ["Kan Line 6", "Zhen Line 6", "Xun Line 6"], ["risks", "nudges", "waits", "turns", "coincides"], "Fate moves in the uncertain space before event becomes fact."],
  ["Fire", "Qi Cultivation, sometimes Body Refining", ["Li", "Zhen", "Qian"], ["Kan", "Gen", "Kun"], ["Li Line 6", "Zhen Line 6", "Qian Line 6"], ["ignites", "burns", "purifies", "consumes", "transforms"], "Fire forces change through heat, consumption, purification, and risk."],
  ["Flowers", "Spirit Awakening or Qi Cultivation", ["Dui", "Xun", "Li"], ["Gen", "Kan", "Qian"], ["Dui Line 6", "Xun Line 6", "Li Line 6"], ["blooms", "lures", "perfumes", "heals", "poisons"], "Flowers make beauty, timing, scent, growth, lure, and poison dangerous."],
  ["Flowing River", "Body Refining, sometimes Qi", ["Kan", "Xun", "Kun"], ["Qian", "Gen", "Zhen"], ["Kan Line 6", "Xun", "Kun"], ["yields", "redirects", "borrows", "guides", "returns"], "Flowing River answers force by changing its direction."],
  ["Force", "Qi Cultivation", ["Qian", "Gen", "Zhen"], ["Xun", "Kun", "Dui"], ["Qian Line 6", "Gen Line 6", "Zhen Line 6"], ["pushes", "shields", "lifts", "presses", "strikes"], "Force is will touching the world invisibly."],
  ["Formations", "Qi Cultivation, sometimes Spirit or Body", ["Gen", "Kun", "Xun"], ["Zhen", "Kan", "Qian"], ["Gen Line 6", "Kun Line 6", "Xun Line 6"], ["anchors", "arrays", "seals", "channels", "prepares"], "Formations make place obey pattern through anchors, circuits, and prepared geometry."],
  ["Glass", "Qi Cultivation", ["Li", "Gen", "Dui"], ["Kan", "Zhen", "Kun"], ["Li Line 6", "Gen Line 6", "Dui Line 6"], ["reflects", "cuts", "reveals", "shatters", "lenses"], "Glass is fragile clarity."],
  ["Gravity", "Qi Cultivation or Body Refining", ["Kun", "Gen", "Qian"], ["Xun", "Zhen", "Dui"], ["Gen Line 6", "Kun Line 6", "Qian Line 6"], ["weighs", "pins", "pulls", "drops", "orbits"], "Gravity is burden, relation, attraction, orbit, and fall."],
  ["Guardian", "Body Refining, sometimes Spirit", ["Gen", "Kun", "Qian"], ["Kan", "Dui", "Zhen"], ["Gen Line 6", "Qian Line 6", "Kun Line 6"], ["shields", "interposes", "bears", "anchors", "refuses"], "Guardian makes protection active."],
  ["Harvesting Gathering", "Qi Cultivation, Body Refining, or sect craft", ["Kun", "Xun", "Gen"], ["Qian", "Kan", "Dui"], ["Kun Line 6", "Xun Line 6", "Dui Line 6"], ["gathers", "discerns", "preserves", "forages", "trades"], "Harvesting Gathering knows what can be taken without ruining the cycle."],
  ["Hunger", "Body Refining, Qi Cultivation, or Spirit Awakening; Forbidden branches require explicit permission", ["Kun", "Kan", "Li"], ["Dui", "Qian", "Gen"], ["Kan Line 6", "Dui Line 6", "Li Line 6"], ["tastes", "digests", "refines", "devours", "mantles"], "Hunger refines appetite, spiritual meals, beast and demon-beast digestion, self-buffing Mantles, famine memory, and the temptation of forbidden devouring."],
  ["The Hidden Eye", "Spirit Awakening or Qi Cultivation", ["Li", "Kan", "Xun"], ["Gen", "Qian", "Dui"], ["Li Line 6", "Kan Line 6", "Qian Line 6"], ["reads", "tracks", "foresees", "questions", "interprets"], "The Hidden Eye makes omens, traces, secrets, and hidden structure actionable."],
  ["Ice", "Qi Cultivation, sometimes Spirit Awakening", ["Kan", "Gen", "Kun"], ["Li", "Zhen", "Dui"], ["Gen Line 6", "Kan Line 6", "Kun Line 6"], ["freezes", "preserves", "slows", "numbs", "crystallizes"], "Ice arrests motion into crystalline line and preserved pressure."],
  ["Illusion", "Spirit Awakening", ["Li", "Xun", "Dui"], ["Gen", "Kan", "Qian"], ["Li Line 6", "Xun Line 6", "Dui Line 6"], ["misdirects", "reframes", "deceives", "reveals", "performs"], "Illusion makes a false premise cause a real choice."],
  ["Imbuement", "Qi Cultivation or Body Refining", ["Li", "Xun", "Qian"], ["Kan", "Dui", "Kun"], ["Li Line 6", "Xun Line 6", "Qian Line 6"], ["charges", "inscribes", "awakens", "arms", "releases"], "Imbuement places power into a vessel and changes what that vessel can mean."],
  ["Ink", "Qi Cultivation or Spirit Awakening", ["Li", "Xun", "Gen"], ["Dui", "Kan", "Qian"], ["Li Line 6", "Xun Line 6", "Gen Line 6"], ["writes", "marks", "records", "corrects", "animates"], "Ink revises reality through sign, image, and record."],
  ["Iron Fist", "Body Refining", ["Qian", "Gen", "Zhen"], ["Xun", "Kan", "Dui"], ["Qian Line 6", "Gen Line 6", "Zhen Line 6"], ["strikes", "conditions", "focuses", "breaks", "refines"], "Iron Fist makes the hand into discipline, impact, conditioning, and decisive contact."],
  ["Jester", "Spirit Awakening, Body Refining, or Qi Cultivation", ["Dui", "Xun", "Li"], ["Gen", "Qian", "Kan"], ["Dui Line 6", "Xun Line 6", "Li Line 6"], ["mocks", "deflects", "exposes", "tempts", "reverses"], "Jester lets truth pass through inversion, mockery, misrule, and timing."],
  ["Karma", "Spirit Awakening or Qi Cultivation", ["Qian", "Dui", "Gen"], ["Zhen", "Kan", "Xun"], ["Qian Line 6", "Dui Line 6", "Gen Line 6"], ["repays", "judges", "remembers", "binds", "balances"], "Karma makes consequence visible and payable."],
  ["Life", "Qi Cultivation, Spirit Awakening, sometimes Body Refining", ["Kun", "Xun", "Dui"], ["Zhen", "Kan", "Gen"], ["Kun Line 6", "Qian Line 6", "Dui Line 6"], ["restores", "preserves", "nurtures", "stabilizes", "heals"], "Life preserves, restores, nourishes, and stabilizes living systems."],
  ["Lightning", "Qi Cultivation, Chakra, sometimes Body Refining", ["Zhen", "Li", "Qian"], ["Kan", "Gen", "Kun"], ["Zhen Line 6", "Li Line 6", "Qian Line 6"], ["charges", "arcs", "interrupts", "flashes", "overloads"], "Lightning is consequence arriving before hesitation can close the circuit."],
  ["Magma", "Qi Cultivation", ["Li", "Kun", "Gen"], ["Kan", "Xun", "Dui"], ["Li Line 6", "Gen Line 6", "Kun Line 6"], ["erupts", "melts", "pressures", "buries", "forges"], "Magma is deep pressure becoming molten action."],
  ["Metal", "Qi Cultivation, sometimes Body Refining", ["Qian", "Gen", "Li"], ["Xun", "Dui", "Kan"], ["Qian Line 6", "Gen Line 6", "Li Line 6"], ["refines", "arms", "hardens", "conducts", "reforges"], "Metal is useful strength made precise."],
  ["Monkey Style", "Body Refining, sometimes Spirit", ["Zhen", "Dui", "Xun"], ["Gen", "Qian", "Kan"], ["Dui Line 6", "Zhen Line 6", "Xun"], ["mocks", "leaps", "steals", "scrambles", "reverses"], "Monkey Style breaks false order through embodied chaos."],
  ["Music", "Spirit Awakening, Qi Cultivation, or Body Refining", ["Dui", "Xun", "Li"], ["Gen", "Kan", "Qian"], ["Dui Line 6", "Xun Line 6", "Li Line 6"], ["harmonizes", "rallies", "sways", "disrupts", "remembers"], "Music shapes rhythm before thought can defend itself."],
  ["The Piercing Needle", "Body Refining, Qi Cultivation, or Spirit Awakening", ["Li", "Xun", "Gen"], ["Qian", "Zhen", "Kun"], ["Li Line 6", "Xun Line 6", "Gen Line 6"], ["pierces", "diagnoses", "seals", "reveals", "disrupts"], "The Piercing Needle reaches the vulnerable point with exact intervention."],
  ["Poison", "Qi Cultivation, sometimes Spirit Awakening", ["Xun", "Kan", "Dui"], ["Li", "Kun", "Gen"], ["Xun Line 6", "Kan Line 6", "Dui Line 6"], ["doses", "weakens", "contaminates", "delays", "cures"], "Poison is small cause becoming decisive harm, cure, or contamination."],
  ["Pressure Points", "Body Refining or Spirit Awakening", ["Li", "Gen", "Kan"], ["Qian", "Zhen", "Dui"], ["Li Line 6", "Gen Line 6", "Kan Line 6"], ["taps", "seals", "opens", "interrupts", "diagnoses"], "Pressure Points finds where gates, meridians, nerves, and timing decide the body from within."],
  ["Protection", "Qi Cultivation, Body Refining, or Spirit Awakening", ["Gen", "Kun", "Qian"], ["Kan", "Zhen", "Dui"], ["Gen Line 6", "Kun Line 6", "Qian Line 6"], ["wards", "interposes", "absorbs", "deflects", "shelters"], "Protection turns harm into a question for a prepared boundary."],
  ["Puppetry", "Qi Cultivation or Spirit Awakening, rare Body expression", ["Xun", "Gen", "Kun"], ["Qian", "Dui", "Kan"], ["Xun Line 6", "Kun Line 6", "Gen Line 6"], ["delegates", "commands", "substitutes", "hides", "animates"], "Puppetry houses, displaces, delegates, or hides agency."],
  ["Qiweaving", "Qi Cultivation", ["Xun", "Li", "Kan"], ["Gen", "Qian", "Dui"], ["Xun Line 6", "Li Line 6", "Kan Line 6"], ["weaves", "channels", "binds", "reroutes", "unravels"], "Qiweaving turns qi into thread, flow, circuit, and pattern."],
  ["Radiance", "Qi Cultivation or Spirit Awakening", ["Li", "Qian", "Dui"], ["Kan", "Kun", "Gen"], ["Li Line 6", "Qian Line 6", "Dui Line 6"], ["purifies", "reveals", "blesses", "blinds", "judges"], "Radiance is spiritual brilliance and cleansing pressure."],
  ["Retribution", "Spirit Awakening, Qi Cultivation, or Body Refining", ["Qian", "Li", "Gen"], ["Dui", "Kan", "Kun"], ["Qian Line 6", "Li Line 6", "Gen Line 6"], ["judges", "marks", "repays", "punishes", "balances"], "Retribution makes violation summon answer, punishment, repayment, and warning."],
  ["Sand", "Qi Cultivation", ["Kun", "Xun", "Kan"], ["Li", "Dui", "Zhen"], ["Xun Line 6", "Kun Line 6", "Gen Line 6"], ["erodes", "buries", "shifts", "blinds", "abrades"], "Sand wears permanence down grain by grain."],
  ["Scoundrel", "Body Refining, sometimes Qi or Spirit", ["Xun", "Dui", "Kan"], ["Qian", "Li", "Gen"], ["Xun Line 6", "Kan", "Dui Line 6"], ["exploits", "distracts", "slips", "cheats", "escapes"], "Scoundrel sees the opening everyone else is too proud to use."],
  ["Sect Stewardship", "Spirit Awakening, Qi Cultivation, or sect craft", ["Kun", "Gen", "Qian"], ["Dui", "Kan", "Zhen"], ["Kun Line 6", "Gen Line 6", "Qian Line 6"], ["reports", "commands", "serves", "records", "allocates"], "Sect Stewardship cultivates duty, institution, record, and service as authority."],
  ["Shadow", "Spirit Awakening", ["Kan", "Xun", "Li"], ["Qian", "Dui", "Gen"], ["Kan Line 6", "Xun Line 6", "Li Line 6"], ["stalks", "imitates", "pins", "follows", "ambushes"], "Shadow weaponizes the hidden double created by light."],
  ["Shield", "Body Refining", ["Gen", "Kun", "Qian"], ["Xun", "Zhen", "Kan"], ["Gen Line 6", "Kun Line 6", "Qian Line 6"], ["blocks", "bashes", "covers", "angles", "holds"], "Shield gives defense form, angle, impact, and returned force."],
  ["Smoke", "Qi Cultivation or Spirit Awakening", ["Xun", "Li", "Kan"], ["Dui", "Qian", "Gen"], ["Xun Line 6", "Kan Line 6", "Li Line 6"], ["screens", "chokes", "signals", "drifts", "escapes"], "Smoke makes obstruction active."],
  ["Sniper", "Body Refining or Qi Cultivation", ["Gen", "Li", "Qian"], ["Xun", "Dui", "Zhen"], ["Gen Line 6", "Li Line 6", "Qian Line 6"], ["waits", "marks", "aims", "pierces", "vanishes"], "Sniper turns patience, distance, line, and timing into one decisive opening."],
  ["Sound", "Qi Cultivation or Spirit Awakening", ["Dui", "Zhen", "Xun"], ["Gen", "Kan", "Li"], ["Dui Line 6", "Zhen Line 6", "Xun Line 6"], ["echoes", "speaks", "silences", "shatters", "harmonizes"], "Sound is vibration, communication, and disruption."],
  ["Space", "Qi Cultivation or Spirit Awakening", ["Qian", "Xun", "Gen"], ["Kun", "Kan", "Dui"], ["Qian Line 6", "Xun Line 6", "Gen Line 6"], ["folds", "crosses", "stores", "opens", "exiles"], "Space makes distance negotiable."],
  ["Spear", "Body Refining and Qi Cultivation", ["Qian", "Zhen", "Gen"], ["Xun", "Dui", "Kan"], ["Qian Line 6", "Gen Line 6", "Zhen Line 6"], ["points", "commits", "guards", "thrusts", "advances"], "Spear is disciplined direction."],
  ["Stars", "Spirit Awakening or Qi Cultivation", ["Qian", "Li", "Kan"], ["Kun", "Dui", "Zhen"], ["Qian Line 6", "Li Line 6", "Kan Line 6"], ["navigates", "marks", "remembers", "targets", "orients"], "Stars guide from distance and memory."],
  ["Sword", "Body Refining, Qi Cultivation, or Spirit Awakening", ["Qian", "Li", "Gen"], ["Kun", "Kan", "Dui"], ["Qian Line 6", "Li Line 6", "Gen Line 6"], ["cuts", "clarifies", "severs", "refines", "vows"], "Sword is will refined into severance."],
  ["Talismans", "Qi Cultivation or Spirit Awakening", ["Li", "Xun", "Gen"], ["Kan", "Zhen", "Dui"], ["Li Line 6", "Xun Line 6", "Dui Line 6"], ["inscribes", "stores", "triggers", "wards", "prepares"], "Talismans hold command in a prepared sign until the right trigger releases it."],
  ["Thread", "Body Refining, Qi Cultivation, or Spirit Awakening", ["Xun", "Gen", "Kan"], ["Li", "Zhen", "Qian"], ["Xun Line 6", "Gen Line 6", "Kan Line 6"], ["connects", "pulls", "cuts", "traps", "arranges"], "Thread controls through subtle lines."],
  ["Trap", "Body Refining or Qi Cultivation", ["Gen", "Xun", "Kan"], ["Zhen", "Li", "Dui"], ["Gen Line 6", "Xun Line 6", "Kan Line 6"], ["prepares", "baits", "triggers", "locks", "punishes"], "Trap makes prepared consequence out of expectation, route, and timing."],
  ["Unmaking", "Qi Cultivation", ["Zhen", "Gen", "Kan"], ["Kun", "Dui", "Xun"], ["Zhen Line 6", "Gen Line 6", "Kan Line 6"], ["cracks", "ruins", "overdraws", "unravels", "collapses"], "Unmaking tests how much structure can be broken before the breaker becomes the next ruin."],
  ["Verdant Growth", "Qi Cultivation, sometimes Body or Spirit", ["Xun", "Kun", "Gen"], ["Zhen", "Li", "Kan"], ["Xun Line 6", "Kun Line 6", "Gen Line 6"], ["roots", "grows", "supports", "entwines", "renews"], "Verdant Growth is patient growth, living structure, roots, renewal, and overgrowth."],
  ["Void", "Qi Cultivation or Spirit Awakening", ["Gen", "Kan", "Qian"], ["Dui", "Kun", "Zhen"], ["Gen Line 6", "Kan Line 6", "Qian Line 6"], ["nullifies", "erodes", "empties", "silences", "removes"], "Void is absence as active principle."],
  ["Warleader", "Qi Cultivation, Body Refining, or Spirit Awakening", ["Qian", "Kun", "Zhen"], ["Dui", "Kan", "Gen"], ["Qian Line 6", "Kun Line 6", "Zhen Line 6"], ["commands", "rallies", "arranges", "advances", "sacrifices"], "Warleader turns many wills into one blade."],
  ["Water", "Qi Cultivation", ["Kan", "Kun", "Xun"], ["Li", "Gen", "Qian"], ["Kan Line 6", "Kun Line 6", "Xun Line 6"], ["flows", "cleanses", "adapts", "erodes", "drowns"], "Water survives by adapting to vessel and pressure."],
  ["Wax", "Qi Cultivation or Spirit Awakening", ["Kun", "Xun", "Dui"], ["Li", "Gen", "Qian"], ["Kun Line 6", "Xun Line 6", "Dui Line 6"], ["softens", "seals", "molds", "preserves", "yields"], "Wax is the cultivation of yielding form."],
  ["Weather", "Qi Cultivation", ["Xun", "Zhen", "Kan"], ["Gen", "Qian", "Dui"], ["Zhen Line 6", "Kan Line 6", "Xun Line 6"], ["gathers", "rains", "thunders", "shifts", "surrounds"], "Weather is the surrounding pattern."],
  ["Wrestling", "Body Refining", ["Gen", "Kun", "Kan"], ["Xun", "Li", "Zhen"], ["Gen Line 6", "Kun Line 6", "Qian Line 6"], ["closes", "pins", "locks", "grounds", "escapes"], "Wrestling finds truth at the point of contact."],
  ["Yang", "Qi Cultivation or Body Refining, rare Spirit expression", ["Qian", "Li", "Zhen"], ["Kun", "Kan", "Gen"], ["Qian Line 6", "Li Line 6", "Zhen Line 6"], ["surges", "warms", "grows", "asserts", "vitalizes"], "Yang is active vitality and heat."],
  ["Yin", "Spirit Awakening or Qi Cultivation", ["Kun", "Kan", "Gen"], ["Li", "Zhen", "Qian"], ["Kun Line 6", "Kan Line 6", "Gen Line 6"], ["stills", "cools", "hides", "preserves", "withers"], "Yin is quiet force, concealment, preservation, cooling, withering, and inward depth."],
  ["Beauty", "Spirit Awakening, Qi Cultivation, or body-bound Body Refining", ["Dui", "Li", "Xun"], ["Kan", "Gen", "Qian"], ["Dui Line 6", "Li Line 6", "Kan Line 6"], ["captivates", "adorns", "softens", "hesitates", "marks"], "Beauty cultivates attention, harmony, poise, awe, tenderness, and unbearable presence without erasing personhood."],
  ["Spirit Companions", "Spirit Awakening, Qi Cultivation, or hosted/body-bound Body Refining", ["Kun", "Dui", "Xun"], ["Qian", "Kan", "Gen"], ["Qian Line 6", "Kan Line 6", "Dui Line 6"], ["bonds", "hosts", "bargains", "manifests", "answers"], "Spirit Companions cultivates relationship with spirits that already have Nature, desire, memory, oath, place, hunger, or personhood."],
  ["Weapons", "Body Refining, Qi Cultivation, or Spirit Awakening", ["Qian", "Gen", "Li"], ["Xun", "Kan", "Dui"], ["Qian Line 6", "Gen Line 6", "Dui Line 6"], ["readies", "chooses", "arms", "adapts", "answers"], "Weapons is appropriateness of form: choosing the implement whose shape, line, and promise answers the moment."],
  ["Chakra Imbuement", "Chakra only", ["Li", "Gen", "Xun"], ["Kan", "Dui", "Kun"], ["Li Line 6", "Gen Line 6", "Xun Line 6"], ["saturates", "stores", "releases", "hardens", "overfills"], "Chakra Imbuement makes the body, weapon, breath, or prepared vessel carry force until a chosen release reveals its cost."],
  ["Drain", "Chakra only; Forbidden by default", ["Kan", "Xun", "Li"], ["Gen", "Qian", "Dui"], ["Kan Line 6", "Xun Line 6", "Li Line 6"], ["draws", "hooks", "empties", "feeds", "taints"], "Drain makes another living rhythm into a temptation, testing whether hunger can be contained without becoming a claim on others."],
  ["Phasing", "Chakra only", ["Xun", "Qian", "Kan"], ["Gen", "Li", "Kun"], ["Xun Line 6", "Qian Line 6", "Kan Line 6"], ["slips", "thins", "passes", "redirects", "returns"], "Phasing treats the body as a changing relation to contact, timing, and the solid certainty of a hostile world."],
  ["Predator", "Chakra only", ["Zhen", "Gen", "Kan"], ["Dui", "Li", "Kun"], ["Zhen Line 6", "Gen Line 6", "Kan Line 6"], ["tracks", "names", "stalks", "pounces", "claims"], "Predator learns the truth of pursuit: a killing opening must be earned through attention, distance, and the burden of choosing prey."],
  ["Vitality", "Chakra only", ["Kun", "Xun", "Kan"], ["Li", "Zhen", "Qian"], ["Kun Line 6", "Xun Line 6", "Kan Line 6"], ["listens", "stabilizes", "renews", "shares", "endures"], "Vitality listens for the rhythm that still wants to live, then helps it continue without mistaking care for ownership."]
].map(([name, path, natural, testing, shadow, verbs, read]) => ({ name, path, natural, testing, shadow, verbs, read }));

const STORAGE_KEY = "tianxia-dao-dashboard-v1";
const TIANXIA_HF05A_IMPORT_PATCH_MARKER = "v1.11.0-HF05A-LEGAL-TALENT-DISPLAY-ALIAS-IMPORT-2026-06-25";
const PACKAGE_DATABASE_NAME = "tianxia-dao-dashboard-packages";
const PACKAGE_DATABASE_VERSION = 1;
const TIANXIA_READER_IMPORT_PATCH = "v1.11.0-HF05G-MANUAL-FORM-ACTION-NULLSAFE-2026-06-27";
const PACKAGE_STORE_NAME = "character-packages";
const TIANXIA_HF05_MARTIAL_ARTS_UI_PATCH = "v1.11.0-HF05-MARTIAL-ARTS-NESTED-UI-2026-06-25";
const TIANXIA_HF05E_MARKDOWN_MANUAL_IMPORT_PATCH = "v1.11.0-HF05E-MARKDOWN-MANUAL-IMPORT-2026-06-27";

let state = {
  packets: [],
  packages: [],
  characterNotes: {},
  campaign: null,
  globalRules: [],
  tacticalPatterns: [],
  reflections: [],
  tribulations: []
};
let lastNpcAnalysis = null;
let packageDatabaseWrite = Promise.resolve();

const $ = (id) => document.getElementById(id);
const trigramKeys = Object.keys(TRIGRAMS);
const allVerbs = [...new Set(SPHERES.flatMap((sphere) => sphere.verbs))].sort();
const SPHERE_ALIASES = {
  Alchemy: ["alchemy", "alchemy & pill forging", "pill forging", "pill forger", "pills"],
  Beastmastery: ["beastmastery", "beast taming", "beast tamer", "bonded beast"],
  "Daemonic Cultivation": ["daemonic cultivation", "demonic cultivation", "demonic", "daemonic"],
  Dark: ["dark", "darkness"],
  Ice: ["ice", "cold"],
  "The Hidden Eye": ["the hidden eye", "hidden eye", "divination", "omen reading", "prophecy"],
  "The Piercing Needle": ["the piercing needle", "piercing needle", "needle", "needle arts"],
  "Verdant Growth": ["verdant growth", "wood", "plant", "plants"],
  Warleader: ["warleader", "war sphere", "war", "battlefield command"],
  "Flowing River": ["flowing river", "river style"],
  Hunger: ["hunger", "sphere of hunger", "hunger sphere", "qi gourmand", "gourmand", "spiritual meals", "beast meals", "demon-beast digestion", "demon meat", "stomach furnace", "furnace hunger", "mantle", "devouring"],
  "Flowers": ["flower", "flower sphere", "flowers sphere"],
  "Monkey Style": ["monkey style"],
  "Puppetry": ["puppet", "puppet sphere", "puppet art"],
  Beauty: ["beauty", "sphere of beauty", "captivating presence", "beauty mark"],
  "Spirit Companions": ["spirit companions", "sphere of spirit companions", "spirit companion", "spirit bonds", "spirit nature", "hosted spirit", "bound spirit"],
  Weapons: ["weapons", "sphere of weapons", "weapon sphere", "weapon literacy", "legal weapons", "martial focus"],
  "Drunken Style": ["drunken style", "reeling immortal"],
  Axes: ["axe", "axes", "axe sphere", "poleaxe"],
  Lightning: ["lightning", "lightning sphere", "thunder lightning"],
  Unmaking: ["unmaking", "ruin", "ruin sphere", "black vein"],
  "Chakra Imbuement": ["chakra imbuement", "imbuement chakra", "saturation", "strike-swell", "hard-swell"],
  Drain: ["drain", "chakra drain", "stolen pulse", "devoured essence"],
  Phasing: ["phasing", "phase state", "slip the body", "half-phase"],
  Predator: ["predator", "name the prey", "killing pounce", "red-line pounce"],
  Vitality: ["vitality", "living wheel", "vitality layer", "overgiving"],
  Qiweaving: ["qiweaving", "qi weaving", "qi-weaving"],
  "Sect Stewardship": ["sect stewardship", "sect", "stewardship"],
  "Dual Wielding": ["dual wielding", "two weapon", "two-weapon", "twin moons"],
  "Spirit": ["spirit sphere", "sphere of spirit"]
};

const CANONICAL_SPHERE_NAMES = SPHERES.map((sphere) => sphere.name);
const FOUNDATION_CATALOG = Array.isArray(window.TIANXIA_FOUNDATION_CATALOG) ? window.TIANXIA_FOUNDATION_CATALOG : [];
const FOUNDATION_CATALOG_ALIASES = Array.isArray(window.TIANXIA_FOUNDATION_CATALOG_ALIASES) ? window.TIANXIA_FOUNDATION_CATALOG_ALIASES : [];
function foundationCatalogPriority(item = {}) {
  if (item.catalog_set === "foundation_split_v0_3B") return 300;
  if (item.catalog_set === "legacy_non_chakra_phase_out") return 100;
  if (/^chakra(?:_|$)/i.test(String(item.catalog_set || "")) || /^chakra$/i.test(String(item.primary_path || ""))) return 200;
  return 0;
}
function foundationPreferredMap(keySelector) {
  const map = new Map();
  FOUNDATION_CATALOG.forEach((item) => {
    const key = String(keySelector(item) || "").toLowerCase();
    if (!key) return;
    const existing = map.get(key);
    if (!existing || foundationCatalogPriority(item) > foundationCatalogPriority(existing)) map.set(key, item);
  });
  return map;
}
const FOUNDATION_CATALOG_BY_ID = foundationPreferredMap((item) => item.id || item.foundation_id || item.name);
const FOUNDATION_CATALOG_BY_NAME = foundationPreferredMap((item) => item.name || item.foundation_name);
FOUNDATION_CATALOG_ALIASES.forEach((alias) => {
  const canonical = FOUNDATION_CATALOG_BY_ID.get(String(alias.canonical_id || "").toLowerCase());
  if (!canonical) return;
  if (alias.legacy_id) FOUNDATION_CATALOG_BY_ID.set(String(alias.legacy_id).toLowerCase(), canonical);
  if (alias.legacy_name) FOUNDATION_CATALOG_BY_NAME.set(String(alias.legacy_name).toLowerCase(), canonical);
});
const SPHERE_CATALOGUE_TEXT = CANONICAL_SPHERE_NAMES.join(", ");
const FOUNDATION_IMPORT_CORRECTIONS = {
  "furnace-eye tiger foundation": {
    name: "Tiger Furnace Stomach",
    note: "Legacy import correction: Ketu's Foundation is Tiger Furnace Stomach. Eye remains an open Wheel and perception motif, not a second Foundation."
  }
};
const UNDERUSED_SPHERE_NAMES = ["Flowers", "Ash", "Glass", "Sand", "Smoke", "Music", "Thread", "Chains", "Ink", "Talismans", "Disease", "Gravity", "Weather", "Verdant Growth", "Beastmastery", "Flowing River", "Drunken Style", "Monkey Style", "Harvesting Gathering", "Hunger", "Wax", "Qiweaving", "Sect Stewardship", "Trap", "The Piercing Needle"];
const CREATIVITY_MODES = ["Balanced sect rival", "Rare but legal", "Stigmatized", "Forbidden edge", "Arena specialist", "Protector", "Predatory non-demonic", "Tribulation-shaped", "Teacher or examiner", "Environmental specialist"];
const STRATEGY_FAMILIES = ["Duelist", "Protector", "Controller", "Trap-setter", "Predator", "Commander", "Scout", "Infiltrator", "Summoner", "Puppeteer", "Anchor-breaker", "Debuffer", "Healer", "Exorcist", "Ritualist", "Hazard-shaper", "Mobility striker", "Attrition fighter", "Executioner", "Counter-technique specialist", "Battlefield scholar"];
const NPC_LIMITATIONS = ["needs setup before peak pressure", "strongest effects have visible anchors", "must protect a fragile dependent asset", "poor at direct burst damage", "poor at long chases", "overcommits when their Dao is insulted", "limited exact-target knowledge", "loses tempo if forced out of preferred range", "requires terrain or timing to become oppressive", "has a social taboo that changes how they reveal power"];

const RATING_PRESETS = {
  "Brute enforcer": {
    "Analysis Depth": 2,
    "Adaptation Speed": 2,
    "Toolkit Breadth": 1,
    "Deception Appetite": 0,
    "Pattern Exploitation": 1,
    "Preparation Bias": 1,
    "Pressure Bias": 5,
    "Risk Tolerance": 5,
    "Objective Discipline": 3,
    "Structural Literacy": 1,
    "Resource Patience": 2,
    "Emotional Stability": 3,
    "Team Awareness": 2,
    "Information Caution": 1
  },
  "Disciplined duelist": {
    "Analysis Depth": 4,
    "Adaptation Speed": 3,
    "Toolkit Breadth": 2,
    "Deception Appetite": 1,
    "Pattern Exploitation": 3,
    "Preparation Bias": 3,
    "Pressure Bias": 3,
    "Risk Tolerance": 3,
    "Objective Discipline": 4,
    "Structural Literacy": 4,
    "Resource Patience": 4,
    "Emotional Stability": 5,
    "Team Awareness": 3,
    "Information Caution": 3
  },
  "Prepared technician": {
    "Analysis Depth": 5,
    "Adaptation Speed": 4,
    "Toolkit Breadth": 5,
    "Deception Appetite": 2,
    "Pattern Exploitation": 3,
    "Preparation Bias": 5,
    "Pressure Bias": 2,
    "Risk Tolerance": 2,
    "Objective Discipline": 5,
    "Structural Literacy": 5,
    "Resource Patience": 5,
    "Emotional Stability": 4,
    "Team Awareness": 3,
    "Information Caution": 4
  },
  "Mobile trickster": {
    "Analysis Depth": 4,
    "Adaptation Speed": 5,
    "Toolkit Breadth": 4,
    "Deception Appetite": 5,
    "Pattern Exploitation": 5,
    "Preparation Bias": 2,
    "Pressure Bias": 3,
    "Risk Tolerance": 4,
    "Objective Discipline": 4,
    "Structural Literacy": 3,
    "Resource Patience": 3,
    "Emotional Stability": 4,
    "Team Awareness": 3,
    "Information Caution": 5
  },
  "Spirit controller": {
    "Analysis Depth": 4,
    "Adaptation Speed": 4,
    "Toolkit Breadth": 4,
    "Deception Appetite": 2,
    "Pattern Exploitation": 3,
    "Preparation Bias": 4,
    "Pressure Bias": 2,
    "Risk Tolerance": 2,
    "Objective Discipline": 4,
    "Structural Literacy": 3,
    "Resource Patience": 4,
    "Emotional Stability": 4,
    "Team Awareness": 4,
    "Information Caution": 4
  },
  "Attrition monster": {
    "Analysis Depth": 3,
    "Adaptation Speed": 3,
    "Toolkit Breadth": 2,
    "Deception Appetite": 1,
    "Pattern Exploitation": 2,
    "Preparation Bias": 2,
    "Pressure Bias": 5,
    "Risk Tolerance": 5,
    "Objective Discipline": 4,
    "Structural Literacy": 2,
    "Resource Patience": 3,
    "Emotional Stability": 4,
    "Team Awareness": 2,
    "Information Caution": 2
  }
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function sphereRuleKey(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/^sphere\s+of\s+/, "")
    .replace(/^the\s+/, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function sphereRulesEntry(name) {
  const rules = window.TIANXIA_SPHERE_RULES || {};
  const requested = String(name || "").trim();
  if (!requested || !Object.keys(rules).length) return null;
  const sphere = profile(requested);
  const candidates = [
    requested,
    sphere.name,
    `The ${sphere.name}`,
    ...(SPHERE_ALIASES[sphere.name] || []),
    ...(SPHERE_ALIASES[requested] || [])
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (rules[candidate]) return { name: candidate, markdown: rules[candidate] };
  }
  const requestedKey = sphereRuleKey(sphere.name || requested);
  const match = Object.entries(rules).find(([key]) => sphereRuleKey(key) === requestedKey);
  return match ? { name: match[0], markdown: match[1] } : null;
}

function markdownInlineHtml(text) {
  const smallTokens = [];
  const source = String(text || "").replace(/<small>\s*<em>([\s\S]*?)<\/em>\s*<\/small>/gi, (_match, content) => {
    const token = `@@TIANXIA_SMALL_${smallTokens.length}@@`;
    smallTokens.push(content);
    return token;
  });
  let html = escapeHtml(source);
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  smallTokens.forEach((content, index) => {
    html = html.replace(`@@TIANXIA_SMALL_${index}@@`, `<small><em>${escapeHtml(content)}</em></small>`);
  });
  return html;
}

function sphereRulesMarkdownHtml(markdown) {
  const lines = String(markdown || "").replace(/\r\n/g, "\n").split("\n");
  const html = [];
  let paragraph = [];
  let listType = "";
  let tableRows = [];

  const flushParagraph = () => {
    if (!paragraph.length) return;
    html.push(`<p>${markdownInlineHtml(paragraph.join(" "))}</p>`);
    paragraph = [];
  };
  const closeList = () => {
    if (!listType) return;
    html.push(`</${listType}>`);
    listType = "";
  };
  const flushTable = () => {
    if (!tableRows.length) return;
    const rows = tableRows
      .filter((row) => !/^\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?$/.test(row))
      .map((row) => row.replace(/^\||\|$/g, "").split("|").map((cell) => cell.trim()));
    if (rows.length) {
      const [header, ...body] = rows;
      html.push(`<div class="sphere-rules-table-wrap"><table><thead><tr>${header.map((cell) => `<th>${markdownInlineHtml(cell)}</th>`).join("")}</tr></thead>${body.length ? `<tbody>${body.map((row) => `<tr>${header.map((_cell, index) => `<td>${markdownInlineHtml(row[index] || "")}</td>`).join("")}</tr>`).join("")}</tbody>` : ""}</table></div>`);
    }
    tableRows = [];
  };

  lines.forEach((rawLine) => {
    const line = rawLine.trim();
    if (!line) {
      flushParagraph();
      closeList();
      flushTable();
      return;
    }
    if (/^---+$/.test(line)) {
      flushParagraph();
      closeList();
      flushTable();
      html.push("<hr>");
      return;
    }
    if (/^\|.+\|$/.test(line)) {
      flushParagraph();
      closeList();
      tableRows.push(line);
      return;
    }
    flushTable();
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) {
      flushParagraph();
      closeList();
      const level = Math.min(6, Math.max(3, heading[1].length + 2));
      html.push(`<h${level}>${markdownInlineHtml(heading[2])}</h${level}>`);
      return;
    }
    const quote = line.match(/^>\s*(.+)$/);
    if (quote) {
      flushParagraph();
      closeList();
      html.push(`<blockquote>${markdownInlineHtml(quote[1])}</blockquote>`);
      return;
    }
    const metadata = line.match(/^\*\*([^*]+:)\*\*\s*(.+)$/);
    if (metadata) {
      flushParagraph();
      closeList();
      html.push(`<p class="sphere-rule-meta"><strong>${markdownInlineHtml(metadata[1])}</strong> ${markdownInlineHtml(metadata[2])}</p>`);
      return;
    }
    const bullet = line.match(/^[-*]\s+(.+)$/);
    const numbered = line.match(/^\d+\.\s+(.+)$/);
    if (bullet || numbered) {
      flushParagraph();
      const nextType = numbered ? "ol" : "ul";
      if (listType && listType !== nextType) closeList();
      if (!listType) {
        html.push(`<${nextType}>`);
        listType = nextType;
      }
      html.push(`<li>${markdownInlineHtml((bullet || numbered)[1])}</li>`);
      return;
    }
    closeList();
    paragraph.push(line);
  });
  flushParagraph();
  closeList();
  flushTable();
  return html.join("");
}

function profile(name) {
  const requested = String(name || "").trim();
  if (!requested) return SPHERES[0];
  const exact = SPHERES.find((sphere) => sphere.name.toLowerCase() === requested.toLowerCase());
  if (exact) return exact;
  const alias = SPHERES.find((sphere) => sphereAliases(sphere).some((value) => value.toLowerCase() === requested.toLowerCase()));
  if (alias) return alias;
  return {
    name: requested,
    path: "Unmapped sphere",
    natural: ["Xun", "Kan", "Li"],
    testing: ["Gen", "Qian", "Zhen"],
    shadow: ["Unmapped sphere profile"],
    verbs: ["expresses", "tests", "reveals"],
    read: `${requested} is present in this package, but the dashboard sphere-Dao catalogue does not have a full profile for it yet.`
  };
}

function trigram(key) {
  return TRIGRAMS[key] || TRIGRAMS.Qian;
}

function randomItem(items) {
  return items[Math.floor(Math.random() * items.length)];
}

function fillSelect(select, options, getValue, getLabel, includeBlank = false) {
  select.innerHTML = "";
  if (includeBlank) {
    const blank = document.createElement("option");
    blank.value = "";
    blank.textContent = "None";
    select.appendChild(blank);
  }
  options.forEach((item) => {
    const option = document.createElement("option");
    option.value = getValue(item);
    option.textContent = getLabel(item);
    select.appendChild(option);
  });
}

function fillDataLists() {
  $("daoVerbs").innerHTML = allVerbs.map((verb) => `<option value="${escapeHtml(verb)}"></option>`).join("");
}

function populateControls() {
  const trigramOptions = trigramKeys.map((key) => ({ key, label: TRIGRAMS[key].label }));
  ["packetOuter", "packetInner", "packetAnswer", "npcDefaultTrigram", "npcStressTrigram", "encounterOuter", "encounterInner", "tribOuter", "tribInner", "tribAnswer"].forEach((id) => {
    if ($(id)) fillSelect($(id), trigramOptions, (item) => item.key, (item) => item.label);
  });
  ["packetSphere", "npcPrimary", "encounterSphere"].forEach((id) => {
    if ($(id)) fillSelect($(id), SPHERES, (sphere) => sphere.name, (sphere) => sphere.name);
  });
  if ($("builderSphereSelect")) fillSelect($("builderSphereSelect"), SPHERES, (sphere) => sphere.name, (sphere) => sphere.name);
  if ($("builderBackground")) {
    const backgrounds = Object.keys(TIANXIA_BACKGROUNDS).map((name) => ({ name }));
    fillSelect($("builderBackground"), backgrounds, (item) => item.name, (item) => item.name, true);
  }
  if ($("builderFoundationCatalogSet") && !$("builderFoundationCatalogSet").value) $("builderFoundationCatalogSet").value = "foundation_split_v0_3B";
  fillFoundationCatalogSelect();
  if ($("npcSecondary")) fillSelect($("npcSecondary"), SPHERES, (sphere) => sphere.name, (sphere) => sphere.name, true);
  fillDataLists();
}

function defaultGateState() {
  return {
    activeCharacterId: "",
    sceneTitle: "Hermit's Cave",
    location: "Outer mountain cave",
    worldTime: "Yr 1 - 5th Moon - Summer",
    sceneText: [
      "The cave holds its breath around the coals.",
      "",
      "A dark ingot rests on the flat stone between you and the old cultivator. Its surface drinks the firelight unevenly, not like ordinary iron, but like something that remembers the hand that shaped it.",
      "",
      "Master Jiang watches without hurry.",
      "",
      "\"Touch first,\" he says. \"Then tell me what your hands know before your mind invents an answer.\""
    ].join("\n"),
    choices: [
      "Describe the grain structure to Master Jiang in precise detail.",
      "Continue examining by touch, trying to map the ingot's internal qi pathways.",
      "Ask Master Jiang to demonstrate the first inlay principle on scrap metal.",
      "Set the ingot aside and speak honestly about what you cannot yet understand."
    ],
    events: [],
    quests: [
      {
        id: makeId("quest"),
        title: "The Poison Chain",
        notes: "Find who is supplying the merchant's poison and why the local sect territory is being used."
      }
    ],
    pinnedPeople: [
      {
        id: makeId("pin"),
        name: "Master Jiang",
        notes: "Cold Hammer Method. Tests through craft, touch, patience, and correction."
      }
    ],
    sectNotes: "No sect formally owns this thread yet. The next public scene can decide whether this becomes a sect rumor, private apprenticeship, or market debt."
  };
}

function normalizeGateState(gate = {}) {
  const fallback = defaultGateState();
  return {
    ...fallback,
    ...gate,
    choices: Array.isArray(gate.choices) ? gate.choices : fallback.choices,
    events: Array.isArray(gate.events) ? gate.events : [],
    quests: Array.isArray(gate.quests) ? gate.quests : fallback.quests,
    pinnedPeople: Array.isArray(gate.pinnedPeople) ? gate.pinnedPeople : fallback.pinnedPeople,
    sectNotes: gate.sectNotes ?? fallback.sectNotes
  };
}

function defaultCampaignState() {
  return {
    version: "gate-prototype-v1",
    gate: defaultGateState()
  };
}

function normalizeCampaignState(campaign = {}) {
  return {
    version: campaign.version || "gate-prototype-v1",
    gate: normalizeGateState(campaign.gate)
  };
}

function gateState() {
  if (!state.campaign) state.campaign = defaultCampaignState();
  state.campaign.gate = normalizeGateState(state.campaign.gate);
  return state.campaign.gate;
}

function packageDatabaseAvailable() {
  return typeof indexedDB !== "undefined";
}

function openPackageDatabase() {
  return new Promise((resolve, reject) => {
    if (!packageDatabaseAvailable()) {
      reject(new Error("This browser does not support the local character library."));
      return;
    }
    const request = indexedDB.open(PACKAGE_DATABASE_NAME, PACKAGE_DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(PACKAGE_STORE_NAME)) {
        database.createObjectStore(PACKAGE_STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open the local character library."));
  });
}

async function readStoredPackages() {
  const database = await openPackageDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const request = database.transaction(PACKAGE_STORE_NAME, "readonly").objectStore(PACKAGE_STORE_NAME).getAll();
      request.onsuccess = () => resolve(Array.isArray(request.result) ? request.result : []);
      request.onerror = () => reject(request.error || new Error("Could not read saved characters."));
    });
  } finally {
    database.close();
  }
}

async function replaceStoredPackages(packages) {
  const database = await openPackageDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = database.transaction(PACKAGE_STORE_NAME, "readwrite");
      const store = transaction.objectStore(PACKAGE_STORE_NAME);
      store.clear();
      packages.forEach((pkg) => store.put(pkg));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error || new Error("Could not save character library."));
      transaction.onabort = () => reject(transaction.error || new Error("Character library save was cancelled."));
    });
  } finally {
    database.close();
  }
}

function queueStoredPackages(packages) {
  const snapshot = packages.map(compactSavedPackage);
  packageDatabaseWrite = packageDatabaseWrite
    .catch(() => undefined)
    .then(() => replaceStoredPackages(snapshot));
  return packageDatabaseWrite;
}

function localStateSnapshot(includePackages = false) {
  return {
    ...state,
    packages: includePackages ? state.packages.map(compactSavedPackage) : []
  };
}

function saveState() {
  state.packages = state.packages.map(compactSavedPackage);
  if (packageDatabaseAvailable()) {
    queueStoredPackages(state.packages).catch(() => {
      // Keep a small-browser fallback. The visible app remains usable even if IndexedDB is disabled.
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(true)));
      } catch {
        // The next save can retry; do not discard the in-memory character roster.
      }
    });
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(false)));
      return true;
    } catch {
      // Continue through the legacy compact-storage fallback below.
    }
  }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(true)));
    return true;
  } catch {
    // Keep the active sheets, but cap only long-lived history when a browser has a small storage quota.
    state.packets = state.packets.slice(0, 300);
    state.reflections = state.reflections.slice(0, 60);
    state.globalRules = state.globalRules.slice(0, 80);
    state.tacticalPatterns = state.tacticalPatterns.slice(0, 80);
    state.campaign = normalizeCampaignState(state.campaign);
    state.campaign.gate.events = state.campaign.gate.events.slice(0, 100);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(true)));
    return true;
  }
}

function loadState() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    state = {
      packets: Array.isArray(stored.packets) ? stored.packets : [],
      packages: Array.isArray(stored.packages) ? stored.packages : [],
      characterNotes: stored.characterNotes && typeof stored.characterNotes === "object" ? stored.characterNotes : {},
      campaign: normalizeCampaignState(stored.campaign),
      globalRules: Array.isArray(stored.globalRules) ? stored.globalRules : [],
      tacticalPatterns: Array.isArray(stored.tacticalPatterns) ? stored.tacticalPatterns : [],
      reflections: Array.isArray(stored.reflections) ? stored.reflections : [],
      tribulations: Array.isArray(stored.tribulations) ? stored.tribulations : []
    };
    state.packages = state.packages.map((pkg) => (pkg.compact ? pkg : compactSavedPackage(pkg)));
    if (cleanupLegacyBadPackagesOnLoad()) {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(false))); } catch {}
    }
  } catch {
    state = { packets: [], packages: [], characterNotes: {}, campaign: defaultCampaignState(), globalRules: [], tacticalPatterns: [], reflections: [], tribulations: [] };
  }
}

async function hydrateStoredPackages() {
  if (!packageDatabaseAvailable()) return;
  const legacyPackages = state.packages.map(compactSavedPackage);
  try {
    const storedPackages = await readStoredPackages();
    if (storedPackages.length) {
      state.packages = storedPackages.map(compactSavedPackage);
      const purged = cleanupLegacyBadPackagesOnLoad();
      if (purged) {
        await queueStoredPackages(state.packages);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(false)));
      }
    } else if (legacyPackages.length) {
      state.packages = legacyPackages;
      await queueStoredPackages(legacyPackages);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(localStateSnapshot(false)));
    }
    renderAll();
  } catch {
    // Keep any legacy local-storage characters visible when a browser blocks IndexedDB.
  }
}

function players() {
  return [...new Set(state.packets.map((packet) => packet.player).filter(Boolean))].sort();
}

function updatePlayerControls() {
  const names = players();
  $("playerNames").innerHTML = names.map((name) => `<option value="${escapeHtml(name)}"></option>`).join("");
  const current = $("patternPlayer").value;
  $("patternPlayer").innerHTML = names.length
    ? names.map((name) => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join("")
    : `<option value="">No players recorded</option>`;
  if (names.includes(current)) {
    $("patternPlayer").value = current;
  }
}

function readPacketFields() {
  return {
    id: typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    timestamp: new Date().toISOString(),
    player: $("packetPlayer").value.trim(),
    outer: $("packetOuter").value,
    inner: $("packetInner").value,
    sphere: $("packetSphere").value,
    answer: $("packetAnswer").value,
    verb: $("packetVerb").value.trim(),
    line: $("packetLine").value,
    cost: $("packetCost").value.trim(),
    shadow: $("packetShadow").value.trim(),
    notes: $("packetNotes").value.trim()
  };
}

function packetText(packet) {
  return `${packet.outer} / ${packet.inner} | ${packet.sphere} | ${packet.answer} | ${packet.verb || "unmarked"} | ${packet.line} | ${packet.cost || "no cost recorded"}`;
}

function updatePacketPreview() {
  const packet = readPacketFields();
  const sphere = profile(packet.sphere);
  const outer = trigram(packet.outer);
  const inner = trigram(packet.inner);
  $("packetPreview").innerHTML = `
    <strong>${escapeHtml(packetText(packet))}</strong>
    <p><strong>Outer:</strong> ${escapeHtml(outer.keys)}</p>
    <p><strong>Inner:</strong> ${escapeHtml(inner.question)}</p>
    <p><strong>Sphere:</strong> ${escapeHtml(sphere.read)}</p>
    <p><strong>Shadow watch:</strong> ${escapeHtml(sphere.shadow.join(", "))}</p>
  `;
}

function recordPacket() {
  const packet = readPacketFields();
  if (!packet.player) {
    toast("Add a player or character name first.");
    return;
  }
  if (!packet.verb) {
    packet.verb = profile(packet.sphere).verbs[0];
  }
  state.packets.unshift(packet);
  saveState();
  renderAll();
  toast("Dao packet recorded.");
}

function clearPacketFields() {
  ["packetCost", "packetShadow", "packetNotes", "packetVerb"].forEach((id) => {
    $(id).value = "";
  });
  updatePacketPreview();
}

function deletePacket(id) {
  state.packets = state.packets.filter((packet) => packet.id !== id);
  saveState();
  renderAll();
  toast("Packet removed.");
}

function countValues(items) {
  return items.filter(Boolean).reduce((acc, item) => {
    acc[item] = (acc[item] || 0) + 1;
    return acc;
  }, {});
}

function topEntries(counts, limit = 5) {
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit);
}

function packetsForPlayer(name) {
  return state.packets.filter((packet) => packet.player === name);
}

function playerStats(name) {
  const packets = packetsForPlayer(name);
  return {
    packets,
    spheres: countValues(packets.map((packet) => packet.sphere)),
    answerTrigrams: countValues(packets.map((packet) => packet.answer)),
    pressureTrigrams: countValues(packets.flatMap((packet) => [packet.outer, packet.inner])),
    verbs: countValues(packets.map((packet) => packet.verb)),
    lines: countValues(packets.map((packet) => packet.line)),
    shadows: countValues(packets.filter((packet) => packet.shadow).map((packet) => packet.sphere))
  };
}

function thresholdLabel(count) {
  if (count >= 8) return "established personal expression";
  if (count >= 5) return "strong resonance";
  if (count >= 3) return "Dao trail";
  if (count >= 2) return "tendency";
  if (count >= 1) return "hint";
  return "no trail";
}

function renderCounts(title, entries) {
  if (!entries.length) {
    return `<div class="empty-state">No marks yet.</div>`;
  }
  return `
    <div class="metric-card">
      <h3>${escapeHtml(title)}</h3>
      <ol>
        ${entries.map(([name, count]) => `<li><strong>${escapeHtml(name)}</strong> x ${count}</li>`).join("")}
      </ol>
    </div>
  `;
}

function renderPatterns() {
  updatePlayerControls();
  const name = $("patternPlayer").value;
  if (!name) {
    $("patternSummary").innerHTML = `<div class="empty-state">Record a packet to start seeing character resonance.</div>`;
    $("suggestionOutput").value = "";
    return;
  }
  const stats = playerStats(name);
  const topSphere = topEntries(stats.spheres, 1)[0];
  const threshold = topSphere ? thresholdLabel(topSphere[1]) : "no trail";
  $("patternSummary").innerHTML = `
    <div class="metric-grid">
      ${renderCounts("Spheres", topEntries(stats.spheres))}
      ${renderCounts("Answer Trigrams", topEntries(stats.answerTrigrams))}
      ${renderCounts("Pressure Trigrams", topEntries(stats.pressureTrigrams))}
      ${renderCounts("Dao Verbs", topEntries(stats.verbs))}
      ${renderCounts("Changing Lines", topEntries(stats.lines))}
      ${renderCounts("Shadow Spheres", topEntries(stats.shadows))}
    </div>
    <div class="threshold">
      <strong>${escapeHtml(name)}:</strong> ${topSphere ? `${escapeHtml(topSphere[0])} is at ${topSphere[1]} marks, a ${threshold}.` : "No sphere trail yet."}
    </div>
  `;
  $("suggestionOutput").value = buildSuggestion(name, stats);
}

function buildSuggestion(name, stats) {
  const topSphere = topEntries(stats.spheres, 1)[0];
  const topAnswer = topEntries(stats.answerTrigrams, 1)[0];
  const topPressure = topEntries(stats.pressureTrigrams, 1)[0];
  const topVerb = topEntries(stats.verbs, 1)[0];
  const topLine = topEntries(stats.lines, 1)[0];
  if (!topSphere) {
    return `No Dao trail yet for ${name}. Record meaningful packets after scenes where the character pays a cost or reveals a pattern.`;
  }
  const sphere = profile(topSphere[0]);
  const level = thresholdLabel(topSphere[1]);
  const trigramAnswer = topAnswer ? trigram(topAnswer[0]) : null;
  const trigramPressure = topPressure ? trigram(topPressure[0]) : null;
  const opportunity =
    topSphere[1] >= 8 ? "Offer an established personal Dao expression, breakthrough relevance, or advanced technique refinement."
    : topSphere[1] >= 5 ? "Offer a major resonance opportunity: hidden teacher, inheritance clue, spirit bond, rival, or signature technique path."
    : topSphere[1] >= 3 ? "Offer a small resonance opportunity: omen, one lesson, minor manual passage, or environmental response."
    : "Offer only a poetic observation or subtle omen for now.";

  return [
    `Dao Reading for ${name}`,
    ``,
    `Strongest sphere: ${sphere.name} (${topSphere[1]} marks, ${level})`,
    `Sphere truth: ${sphere.read}`,
    `Most common answer: ${topAnswer ? `${trigramAnswer.label} - ${trigramAnswer.keys}` : "none yet"}`,
    `Most common pressure: ${topPressure ? `${trigramPressure.label} - ${trigramPressure.keys}` : "none yet"}`,
    `Common verb: ${topVerb ? topVerb[0] : "none yet"}`,
    `Common changing line: ${topLine ? topLine[0] : "none yet"}`,
    ``,
    `World response: ${opportunity}`,
    ``,
    `Suggested omen: Something connected to ${sphere.name} appears under ${topPressure ? trigramPressure.label : "an appropriate pressure"} but does not explain itself. It should feel inevitable in hindsight, not like a reward token.`,
    ``,
    `Possible teacher or rival: Create someone who expresses ${sphere.name} through a different answer trigram. If ${name} tends to answer through ${topAnswer ? trigramAnswer.label : "one familiar posture"}, the rival should pressure the same truth through another configuration of change.`,
    ``,
    `Poetic insight, not diagnosis: "The world has begun answering the place where you ${topVerb ? topVerb[0] : "return"}."`
  ].join("\n");
}

function renderPacketLog() {
  $("packetCount").textContent = `${state.packets.length} packets`;
  $("playerCount").textContent = `${players().length} players`;
  if (!state.packets.length) {
    $("packetLog").innerHTML = `<div class="empty-state">No packets yet. Record only the meaningful turns: costly choices, shadows, breakthroughs, forged techniques, or scene pivots.</div>`;
    return;
  }
  $("packetLog").innerHTML = state.packets.slice(0, 20).map((packet) => `
    <article class="packet-card">
      <header>
        <span><strong>${escapeHtml(packet.player)}</strong> recorded ${new Date(packet.timestamp).toLocaleString()}</span>
        <button class="ghost-button" type="button" data-delete="${escapeHtml(packet.id)}">Remove</button>
      </header>
      <p>${escapeHtml(packetText(packet))}</p>
      ${packet.notes ? `<p>${escapeHtml(packet.notes)}</p>` : ""}
      <div class="tag-row">
        <span class="tag trigram">${escapeHtml(TRIGRAMS[packet.outer].label)}</span>
        <span class="tag trigram">${escapeHtml(TRIGRAMS[packet.inner].label)}</span>
        <span class="tag sphere">${escapeHtml(packet.sphere)}</span>
        <span class="tag">${escapeHtml(packet.verb)}</span>
        <span class="tag">${escapeHtml(packet.line)}</span>
        ${packet.shadow ? `<span class="tag shadow">shadow</span>` : ""}
      </div>
    </article>
  `).join("");
  document.querySelectorAll("[data-delete]").forEach((button) => {
    button.addEventListener("click", () => deletePacket(button.dataset.delete));
  });
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function stripMarkdownLine(line) {
  return String(line || "")
    .replace(/^#+\s*/, "")
    .replace(/^[-*]\s*/, "")
    .replaceAll("**", "")
    .replaceAll("`", "")
    .trim();
}

function splitCleanLines(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map(stripMarkdownLine)
    .filter(Boolean);
}

function titleCase(value) {
  const text = String(value || "").trim();
  return text ? text[0].toUpperCase() + text.slice(1) : text;
}

function humanizeMachineToken(token = "") {
  const raw = String(token || "").trim();
  if (!raw || !/^[a-z][a-z0-9]*(?:_[a-z0-9]+)+$/.test(raw)) return raw;
  const prefixTrimmed = raw.replace(/^(act|exec)_/, "");
  const words = prefixTrimmed.split("_").filter(Boolean);
  const special = {
    ai: "AI", ac: "AC", dc: "DC", hp: "HP", pb: "PB", qi: "Qi", cl: "CL",
    str: "STR", dex: "DEX", con: "CON", int: "INT", wis: "WIS", cha: "CHA",
    aoe: "AoE", npc: "NPC", pc: "PC", gm: "GM"
  };
  return words.map((word) => special[word] || word.replace(/^[a-z]/, (letter) => letter.toUpperCase())).join(" ");
}

function polishMachineReadableText(value = "") {
  const text = String(value || "");
  if (!text) return "";
  return text.replace(/\b[a-z][a-z0-9]*(?:_[a-z0-9]+)+\b/g, (token) => humanizeMachineToken(token));
}

function cleanNameCandidate(value) {
  return String(value || "")
    .split(/[\\/]/)
    .pop()
    .replace(/\.(md|txt|json|docx|pdf)$/i, "")
    .replace(/\b(Generation Brief|Stat Block|Normalized Sheet|Readable Sheet Source|Readable Sheet|Combat Behaviour|Combat Behavior|Combat Package|Background.*Future|Background_and_Future|Canon Manifest|Reflection Ledger|Tactical Patterns|Pre[-_ ]Simulation Retrieval Template|Human Review Checklist|Codex Integration Notes)\b/ig, "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s:;,.#*-]+|[\s:;,.#*-]+$/g, "")
    .trim();
}

function isLikelyNameCandidate(value) {
  const name = cleanNameCandidate(value);
  if (name.length < 2 || name.length > 80) return false;
  if (/[;{}[\]]/.test(name)) return false;
  if (/^(name|character|npc|enemy|cultivator|identity|stat block|unknown|none|n\/a|not stated|not supplied|not recorded|no package selected)$/i.test(name)) return false;
  if (/specific information|not communicated|legally|ally information|confirmed facts|probable assumptions|false assumptions|unknowns|source encounter|participants|battlefield|workflow|normalizer|rules arbiter|pre[- ]simulation|post[- ]fight|human review|approval queue/i.test(name)) return false;
  return /[A-Za-z]/.test(name);
}

function extractLineValue(lines, labels) {
  for (const line of lines) {
    for (const label of labels) {
      const pattern = new RegExp(`^${escapeRegExp(label)}\\s*[:\\-]\\s*(.+)$`, "i");
      const match = line.match(pattern);
      if (match) return match[1].trim();
    }
  }
  return "";
}

function extractValidatedNameValue(lines, labels) {
  for (const line of lines) {
    for (const label of labels) {
      const pattern = new RegExp(`^${escapeRegExp(label)}\\s*[:\\-]\\s*(.+)$`, "i");
      const match = line.match(pattern);
      if (!match) continue;
      const candidate = cleanNameCandidate(match[1]);
      if (isLikelyNameCandidate(candidate)) return candidate;
    }
  }
  return "";
}

function extractNpcName(lines) {
  const earlyLines = lines.slice(0, 120);
  const named = extractValidatedNameValue(earlyLines, ["Character Name", "NPC Name", "Enemy Name", "Cultivator Name", "Name"]);
  if (named) return named;
  const firstTitle = lines.find((line) => (
    line.length <= 80
    && !line.includes(":")
    && !/^dao combat ai card$/i.test(line)
    && !/^identity$/i.test(line)
    && !/^stat block$/i.test(line)
    && isLikelyNameCandidate(line)
  ));
  return cleanNameCandidate(firstTitle || "");
}

function extractNpcPath(text, lines) {
  const pathLine = extractLineValue(lines, ["Path", "Cultivation Path", "Main Path"]);
  const haystack = `${pathLine} ${text}`.toLowerCase();
  if (/body\s+refining|body\s+cultivator|body\s+path/.test(haystack)) return "Body Refining";
  if (/qi\s+cultivation|qi\s+cultivator|qi\s+path/.test(haystack)) return "Qi Cultivation";
  if (/spirit\s+awakening|spirit\s+awakener|spirit\s+path/.test(haystack)) return "Spirit Awakening";
  return pathLine || "Mixed or Unclear";
}

function extractNpcRealm(text, lines) {
  const realmLine = extractLineValue(lines, ["Realm", "Cultivation Level", "Threat", "Level"]);
  if (realmLine) return realmLine;
  const cl = text.match(/\bCL\s*\d+\b/i);
  if (cl) return cl[0].toUpperCase().replace(/\s+/, " ");
  const realm = text.match(/\b(Mortal|Qi Condensation|Foundation Establishment|Foundation|Core Formation|Golden Core|Nascent Soul|Nascient Soul|Soul Formation|Spirit Severing|Immortal)\b/i);
  return realm ? realm[0] : "";
}

function extractNpcField(lines, labels) {
  return extractLineValue(lines, labels).replace(/\s+/g, " ").trim();
}

function countAliasInLine(line, alias) {
  const pattern = new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias.toLowerCase())}([^a-z0-9]|$)`, "g");
  return [...line.toLowerCase().matchAll(pattern)].length;
}

function sphereAliases(sphere) {
  return [sphere.name, ...(SPHERE_ALIASES[sphere.name] || [])];
}

function detectSphereWeights(text, lines) {
  const detected = SPHERES.map((sphere) => {
    let weight = 0;
    let hits = 0;
    const aliases = sphereAliases(sphere);
    lines.forEach((line, index) => {
      const lower = line.toLowerCase();
      if (
        sphere.name === "Spirit"
        && /spirit\s+awakening|spirit\s+awakener/.test(lower)
        && !/spheres?|insights?|techniques?|spirit\s+sphere/.test(lower)
      ) {
        return;
      }
      const lineHits = aliases.reduce((sum, alias) => sum + countAliasInLine(line, alias), 0);
      if (!lineHits) return;
      let lineWeight = lineHits;
      if (/primary\s+spheres?|main\s+spheres?|primary\s+resonance/.test(lower)) lineWeight += 6;
      else if (/secondary\s+spheres?|tertiary|accent|minor\s+spheres?/.test(lower)) lineWeight += 3.5;
      else if (/spheres?|resonance|sphere\s+spread/.test(lower)) lineWeight += 2.5;
      if (/insights?|dao|motifs?|cultivation/.test(lower)) lineWeight += 1.5;
      if (/techniques?|forged|actions?|attacks?|features?|subpath|domain|stance|talents?/.test(lower)) lineWeight += 1.2;
      if (index < 18) lineWeight += 0.75;
      weight += lineWeight;
      hits += lineHits;
    });
    return { sphere, weight: Number(weight.toFixed(2)), hits };
  })
    .filter((item) => item.weight > 0)
    .sort((a, b) => b.weight - a.weight || a.sphere.name.localeCompare(b.sphere.name));

  if (detected.length) return detected;

  const fallbackPrimary = profile($("npcPrimary")?.value);
  const fallbackSecondary = $("npcSecondary")?.value ? profile($("npcSecondary").value) : null;
  return [
    { sphere: fallbackPrimary, weight: 6, hits: 1 },
    fallbackSecondary ? { sphere: fallbackSecondary, weight: 4, hits: 1 } : null
  ].filter(Boolean);
}

function addWeight(weights, key, amount) {
  if (!TRIGRAMS[key] || !Number.isFinite(amount)) return;
  weights[key] = (weights[key] || 0) + amount;
}

function trigramKeyFromShadow(value) {
  const match = String(value || "").match(/\b(Qian|Kun|Zhen|Xun|Kan|Li|Gen|Dui)\b/);
  return match ? match[1] : "";
}

function topWeightEntries(weights, limit = 5) {
  return Object.entries(weights)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([key, weight]) => [key, Number(weight.toFixed(2))]);
}

function weightedChoice(entries) {
  const total = entries.reduce((sum, [, weight]) => sum + Math.max(weight, 0), 0);
  if (!total) return entries[0]?.[0] || "Qian";
  let roll = Math.random() * total;
  for (const [key, weight] of entries) {
    roll -= Math.max(weight, 0);
    if (roll <= 0) return key;
  }
  return entries[0][0];
}

function choosePosture(weights, mode, avoidKey = "") {
  const entries = topWeightEntries(weights, 8);
  if (!entries.length) return avoidKey && avoidKey !== "Qian" ? "Qian" : "Kan";
  if (mode === "Focused") {
    return entries.find(([key]) => key !== avoidKey)?.[0] || entries[0][0];
  }
  const poolSize = mode === "Volatile" ? 5 : 3;
  const pool = entries.slice(0, poolSize);
  let chosen = weightedChoice(pool);
  const second = entries.find(([key]) => key !== avoidKey);
  if (chosen === avoidKey && second && second[1] >= entries[0][1] * 0.65) {
    chosen = second[0];
  }
  return chosen;
}

function addPathPostureNudges(defaultWeights, stressWeights, path) {
  if (path === "Body Refining") {
    addWeight(defaultWeights, "Qian", 2.2);
    addWeight(defaultWeights, "Gen", 1.8);
    addWeight(defaultWeights, "Zhen", 1.3);
    addWeight(stressWeights, "Kan", 1.2);
    addWeight(stressWeights, "Xun", 1);
  } else if (path === "Qi Cultivation") {
    addWeight(defaultWeights, "Xun", 1.8);
    addWeight(defaultWeights, "Li", 1.5);
    addWeight(defaultWeights, "Kan", 1.2);
    addWeight(stressWeights, "Gen", 1.2);
    addWeight(stressWeights, "Zhen", 1);
  } else if (path === "Spirit Awakening") {
    addWeight(defaultWeights, "Kan", 2);
    addWeight(defaultWeights, "Li", 1.5);
    addWeight(defaultWeights, "Dui", 1.2);
    addWeight(stressWeights, "Qian", 1.3);
    addWeight(stressWeights, "Gen", 1.2);
  }
}

function addKeywordPostureNudges(defaultWeights, stressWeights, text) {
  const lower = text.toLowerCase();
  const nudges = [
    [/protect|guard|shield|interpose|defend|rescue/, [["Gen", 1.5], ["Kun", 1.1]], [["Kan", 0.6]]],
    [/ambush|hidden|shadow|stealth|conceal|mist|veil|invisible/, [["Kan", 1.6], ["Xun", 1.2]], [["Li", 0.8]]],
    [/command|authority|pressure|edict|domain|mandate|sovereign/, [["Qian", 1.7]], [["Qian", 0.8], ["Gen", 0.6]]],
    [/shock|lightning|sudden|rush|burst|interrupt/, [["Zhen", 1.6]], [["Zhen", 0.8], ["Kan", 0.5]]],
    [/reveal|light|radiance|clarity|truth|expose|judge/, [["Li", 1.6]], [["Dui", 0.5]]],
    [/persuade|song|speech|music|charm|bargain|tempt/, [["Dui", 1.4], ["Xun", 1]], [["Kan", 0.7]]],
    [/heal|support|restore|nurture|stabilize|mercy/, [["Kun", 1.5], ["Dui", 0.8]], [["Gen", 0.5]]],
    [/bind|seal|ward|anchor|still|stop|prison|wall/, [["Gen", 1.5]], [["Zhen", 0.6]]],
    [/devour|corrupt|blood|hunger|predator|forbidden/, [["Kan", 1.3], ["Qian", 0.8]], [["Dui", 0.8], ["Qian", 0.7]]]
  ];
  nudges.forEach(([pattern, defaultAdds, stressAdds]) => {
    if (!pattern.test(lower)) return;
    defaultAdds.forEach(([key, amount]) => addWeight(defaultWeights, key, amount));
    stressAdds.forEach(([key, amount]) => addWeight(stressWeights, key, amount));
  });
}

function computePostureAnalysis(detected, path, text) {
  const defaultWeights = {};
  const stressWeights = {};
  const mode = $("postureVariability")?.value || "Balanced";
  const influence = $("minorSphereInfluence")?.value || "Normal";
  const limit = influence === "Wide" ? 12 : influence === "Subtle" ? 5 : 8;
  const decay = influence === "Wide" ? 0.9 : influence === "Subtle" ? 0.58 : 0.74;

  detected.slice(0, limit).forEach((item, index) => {
    const rankMultiplier = Math.pow(decay, index);
    const base = Math.max(item.weight, 1) * rankMultiplier;
    item.sphere.natural.forEach((key, trigramIndex) => {
      addWeight(defaultWeights, key, base * (1.15 - trigramIndex * 0.18));
    });
    item.sphere.testing.forEach((key, trigramIndex) => {
      addWeight(stressWeights, key, base * (1.05 - trigramIndex * 0.15));
    });
    item.sphere.shadow.forEach((shadow) => {
      addWeight(stressWeights, trigramKeyFromShadow(shadow), base * 0.22);
    });
  });

  addPathPostureNudges(defaultWeights, stressWeights, path);
  addKeywordPostureNudges(defaultWeights, stressWeights, text);

  const explicitDefault = text.match(/default\s+(?:trigram\s+)?posture\s*[:\-]\s*(Qian|Kun|Zhen|Xun|Kan|Li|Gen|Dui)/i);
  const explicitStress = text.match(/stress\s+(?:trigram\s+)?(?:posture)?\s*[:\-]\s*(Qian|Kun|Zhen|Xun|Kan|Li|Gen|Dui)/i);
  const defaultKey = explicitDefault ? titleCase(explicitDefault[1].toLowerCase()) : choosePosture(defaultWeights, mode);
  const stressKey = explicitStress ? titleCase(explicitStress[1].toLowerCase()) : choosePosture(stressWeights, mode, defaultKey);
  return {
    defaultWeights,
    stressWeights,
    defaultKey,
    stressKey,
    defaultTop: topWeightEntries(defaultWeights),
    stressTop: topWeightEntries(stressWeights),
    mode,
    influence
  };
}

function detectedNames(detected, limit = 8) {
  return detected.slice(0, limit).map((item) => item.sphere.name);
}

function hasAnySphere(names, candidates) {
  return candidates.some((name) => names.includes(name));
}

function derivePreset(path, detected) {
  const names = detectedNames(detected, 8);
  if (hasAnySphere(names, ["Shadow", "Smoke", "Illusion", "Scoundrel", "Space", "Monkey Style"])) return "Mobile trickster";
  if (hasAnySphere(names, ["Formations", "Talismans", "Alchemy", "Ink", "Qiweaving", "Thread", "Trap"])) return "Prepared technician";
  if (path === "Spirit Awakening" || hasAnySphere(names, ["Dreams", "Fate", "Karma", "The Hidden Eye", "Dark", "Radiance", "Shadow"])) return "Spirit controller";
  if (hasAnySphere(names, ["Brute", "Berserker", "Blood", "Earth", "Ice", "Disease", "Poison", "Death", "Ash"])) return "Attrition monster";
  if (hasAnySphere(names, ["Sword", "Spear", "Iron Fist", "The Piercing Needle", "Metal", "Radiance", "Sniper"])) return "Disciplined duelist";
  return path === "Body Refining" ? "Brute enforcer" : "Prepared technician";
}

function deriveTags(path, detected, defaultKey) {
  const names = detectedNames(detected, 10);
  const tags = new Set();
  const add = (...items) => items.forEach((item) => tags.add(item));
  if (hasAnySphere(names, ["Shadow", "Smoke", "Illusion", "Scoundrel", "Space", "Monkey Style"])) add("Mobile Harrier", "Pattern Gambler", "Information Hunter");
  if (hasAnySphere(names, ["Formations", "Talismans", "Alchemy", "Ink", "Qiweaving", "Thread", "Trap"])) add("Ritual Technician", "Layered Planner", "Structural Reader");
  if (hasAnySphere(names, ["Guardian", "Protection", "Shield", "Earth", "Chains", "Force", "Gravity"])) add("Anchor Defender", "Protective Commander");
  if (hasAnySphere(names, ["Warleader", "Brute", "Berserker", "Spear", "Destruction", "Fire", "Yang", "Barrage"])) add("Relentless Pressure", "Setup Finisher");
  if (hasAnySphere(names, ["Life", "Beastmastery", "Music", "Sound", "Radiance", "Sect Stewardship"])) add("Spirit Shepherd", "Rescue Specialist");
  if (hasAnySphere(names, ["Void", "Space", "The Hidden Eye", "Fate", "Karma", "Glass"])) add("Formation Breaker", "Information Hunter");
  if (path === "Spirit Awakening") add("Information Hunter", "Symbolic Lawgiver");
  if (defaultKey === "Qian") add("Relentless Pressure");
  if (defaultKey === "Kun") add("Protective Commander");
  if (defaultKey === "Zhen") add("Calamity Engine");
  if (defaultKey === "Xun") add("Layered Planner");
  if (defaultKey === "Kan") add("Patient Hunter");
  if (defaultKey === "Li") add("Structural Reader");
  if (defaultKey === "Gen") add("Anchor Defender");
  if (defaultKey === "Dui") add("Opportunistic Predator");
  return [...tags].slice(0, 5);
}

function doctrineFromAnalysis(primary, secondary, defaultKey, stressKey, tags, preset) {
  const defaultPosture = trigram(defaultKey);
  const stressPosture = trigram(stressKey);
  const isTrickster = tags.includes("Pattern Gambler") || tags.includes("Mobile Harrier");
  const isStructural = tags.includes("Structural Reader") || tags.includes("Ritual Technician") || tags.includes("Formation Breaker");
  const isProtector = tags.includes("Protective Commander") || tags.includes("Rescue Specialist");
  const isPressure = tags.includes("Relentless Pressure") || preset === "Attrition monster";
  const learning = isTrickster ? "Adversarial Learning: test what the opponent believes they learned, then exploit the conclusion."
    : isStructural ? "Structural Learning: identify the load-bearing object, anchor, route, concentration holder, or battlefield rule."
    : isProtector ? "Relational Learning: study bonds, rescue instincts, debt, loyalty, and emotional priority."
    : isPressure ? "Forced Literacy: ignore symbolism until it blocks progress, then break the relevant piece."
    : "Probe-and-Reveal Learning: spend the cheapest legal tool that reveals how the threat works.";
  return {
    opening: `Open by expressing ${primary.name} through ${defaultPosture.label}: ${primary.verbs.slice(0, 3).join(", ")} before committing the full toolkit.`,
    target: isStructural ? "Prioritize the objective, anchor, concentration holder, or terrain structure over routine damage."
      : isProtector ? "Prioritize the ally, bonded asset, carrier, or protected position that keeps the objective alive."
      : isTrickster ? "Prioritize the target whose assumptions can be turned into a false map of the fight."
      : "Prioritize the target or position that advances the objective fastest.",
    resourceReveal: preset === "Prepared technician" || preset === "Spirit controller"
      ? "Reveal one layer at a time. Preserve the strongest technique until the battlefield has declared its true shape."
      : "Spend resources when they create tempo, deny recovery, or prevent the enemy from solving the current pressure.",
    reaction: `Preserve reactions for the first moment that would let ${stressPosture.label} take over: ${stressPosture.failure}`,
    learning,
    rescue: isProtector ? "Create direct rescue windows early; protection is part of the win condition."
      : "Rescue only when it preserves the objective or creates a better future exchange.",
    retreat: "Retreat, bargain, or reposition when continuing would betray the objective more than pride would preserve it.",
    stress: `Under pressure, shift toward ${stressPosture.label}: ${stressPosture.question}`,
    failure: stressPosture.failure,
    antiPattern: `Do not repeat solved ${primary.name} actions unless repetition is bait, attrition, resource pressure, or the best legal line.`,
    question: `How would ${primary.name}${secondary ? `, colored by ${secondary.name},` : ""} answer this obstacle through ${defaultPosture.label} without losing the objective?`
  };
}

function buildAutoContext(analysis) {
  return [
    "Auto-read from pasted block:",
    analysis.subpath ? `Subpath: ${analysis.subpath}` : null,
    analysis.role ? `Role: ${analysis.role}` : null,
    analysis.range ? `Preferred range: ${analysis.range}` : null,
    analysis.insights ? `Insights: ${analysis.insights}` : null,
    analysis.techniques ? `Techniques: ${analysis.techniques}` : null,
    `Detected sphere spread: ${analysis.detected.slice(0, 6).map((item) => `${item.sphere.name} ${item.weight}`).join(", ")}`
  ].filter(Boolean).join("\n");
}

function makeDaoPhrase(primary, secondary) {
  const verb = titleCase(primary.verbs[0] || "acts");
  return `${verb} through ${primary.name}, complicated by ${secondary ? secondary.name : "the current battlefield"}.`;
}

function analyzeNpcStatBlock(generateAfter = false) {
  const text = $("npcStatBlock").value.trim();
  if (!text) {
    toast("Paste a stat block first.");
    return;
  }
  const lines = splitCleanLines(text);
  const detected = detectSphereWeights(text, lines);
  const path = extractNpcPath(text, lines);
  const posture = computePostureAnalysis(detected, path, text);
  const primary = detected[0]?.sphere || profile($("npcPrimary").value);
  const secondary = detected.find((item) => item.sphere.name !== primary.name)?.sphere || null;
  const preset = derivePreset(path, detected);
  const tags = deriveTags(path, detected, posture.defaultKey);
  const doctrine = doctrineFromAnalysis(primary, secondary, posture.defaultKey, posture.stressKey, tags, preset);
  const analysis = {
    rawText: text,
    name: extractNpcName(lines),
    path,
    realm: extractNpcRealm(text, lines),
    subpath: extractNpcField(lines, ["Subpath", "Subclass", "Tradition"]),
    role: extractNpcField(lines, ["Role", "Combat Role"]),
    range: extractNpcField(lines, ["Preferred Range", "Range"]),
    objective: extractNpcField(lines, ["Objective", "Typical Battlefield Objective", "Fight Objective"]),
    insights: extractNpcField(lines, ["Relevant Insights", "Cultivation Insights", "Insights", "Path Insights"]),
    techniques: extractNpcField(lines, ["Relevant Forged Techniques", "Forged Techniques", "Techniques", "Signature Techniques"]),
    detected,
    primary,
    secondary,
    posture,
    preset,
    ratings: RATING_PRESETS[preset],
    tags,
    doctrine,
    daoPhrase: makeDaoPhrase(primary, secondary)
  };
  lastNpcAnalysis = analysis;
  applyNpcAnalysis(analysis);
  renderNpcAnalysis(analysis);
  if (generateAfter) generateFightPrompt();
  toast("Stat block analyzed.");
}

function applyNpcAnalysis(analysis) {
  if (analysis.name) $("npcName").value = analysis.name;
  if ([...$("npcPath").options].some((option) => option.value === analysis.path || option.textContent === analysis.path)) {
    $("npcPath").value = analysis.path;
  } else {
    $("npcPath").value = "Mixed or Unclear";
  }
  if (analysis.realm) $("npcRealm").value = analysis.realm;
  $("npcPrimary").value = analysis.primary.name;
  $("npcSecondary").value = analysis.secondary ? analysis.secondary.name : "";
  $("npcDefaultTrigram").value = analysis.posture.defaultKey;
  $("npcStressTrigram").value = analysis.posture.stressKey;
  if (analysis.objective && !$("npcObjective").value.trim()) $("npcObjective").value = analysis.objective;
  const currentContext = $("npcContext").value.trim();
  if (!currentContext || currentContext.startsWith("Auto-read from pasted block:")) {
    $("npcContext").value = buildAutoContext(analysis);
  }
}

function formatWeightRows(entries) {
  const max = Math.max(...entries.map(([, weight]) => weight), 1);
  return entries.map(([key, weight]) => {
    const percent = Math.max(6, Math.round((weight / max) * 100));
    return `
      <div class="weight-row">
        <span>${escapeHtml(TRIGRAMS[key]?.label || key)}</span>
        <span class="weight-bar"><i style="width: ${percent}%"></i></span>
        <strong>${escapeHtml(weight)}</strong>
      </div>
    `;
  }).join("");
}

function renderNpcAnalysis(analysis) {
  $("statBlockAnalysis").innerHTML = `
    <h3>Detected Combat Card</h3>
    <p><strong>${escapeHtml(analysis.name || "Unnamed NPC")}</strong> | ${escapeHtml(analysis.path)} | ${escapeHtml(analysis.realm || "realm unclear")}</p>
    <div class="tag-row">
      ${analysis.detected.slice(0, 8).map((item) => `<span class="tag sphere">${escapeHtml(item.sphere.name)} ${escapeHtml(item.weight)}</span>`).join("")}
    </div>
    <div class="analysis-grid">
      <div class="analysis-card">
        <strong>Default: ${escapeHtml(trigram(analysis.posture.defaultKey).label)}</strong>
        <div class="weight-list">${formatWeightRows(analysis.posture.defaultTop)}</div>
      </div>
      <div class="analysis-card">
        <strong>Stress: ${escapeHtml(trigram(analysis.posture.stressKey).label)}</strong>
        <div class="weight-list">${formatWeightRows(analysis.posture.stressTop)}</div>
      </div>
    </div>
    <p><strong>Preset:</strong> ${escapeHtml(analysis.preset)}. <strong>Tags:</strong> ${escapeHtml(analysis.tags.join(", "))}</p>
    <p><strong>Dao phrase:</strong> ${escapeHtml(analysis.daoPhrase)}</p>
  `;
}

function makeId(prefix) {
  const raw = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  return `${prefix}-${raw}`;
}

function parseFileBlocks(text) {
  const blocks = [];
  const pattern = /^={5}\s*FILE:\s*(.+?)\s*={5}\s*$/gim;
  const matches = [...String(text || "").matchAll(pattern)];
  if (!matches.length) return blocks;
  matches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index : text.length;
    blocks.push({
      name: match[1].trim(),
      content: text.slice(start, end).trim()
    });
  });
  return blocks;
}

function markdownSection(text, heading) {
  const escaped = String(heading || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const source = String(text || "");
  const match = new RegExp(`^##\\s+(?:\\d+\\.\\s+)?${escaped}\\s*\\r?\\n`, "im").exec(source);
  if (!match) return "";
  const remainder = source.slice(match.index + match[0].length);
  const nextHeading = /^##\s+/m.exec(remainder);
  return (nextHeading ? remainder.slice(0, nextHeading.index) : remainder).trim();
}

function firstNonEmptyObject(...values) {
  return values.find((value) => (
    value
    && typeof value === "object"
    && !Array.isArray(value)
    && Object.keys(value).length
  )) || {};
}

function markdownTableValue(text, label) {
  const escaped = String(label || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return String(text || "").match(new RegExp(`^\\|\\s*${escaped}\\s*\\|\\s*([^|\\r\\n]+)`, "im"))?.[1]?.trim() || "";
}

function markdownBoldValue(text, label) {
  const escaped = String(label || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return String(text || "").match(new RegExp(`^\\s*(?:[-*]\\s*)?\\*\\*${escaped}:\\*\\*\\s*([^\\r\\n]+)`, "im"))?.[1]?.trim() || "";
}

function markdownFirstValue(text, labels = []) {
  for (const label of labels) {
    const value = markdownBoldValue(text, label) || markdownTableValue(text, label);
    if (value) return value;
  }
  return "";
}

function markdownNumericValue(text, labels = []) {
  const value = markdownFirstValue(text, labels);
  if (!value) return "";
  const match = String(value).match(/[+-]?\d+/);
  return match ? Number(match[0]) : value;
}

function markdownBonusTableMap(text, heading, keyLabelPattern) {
  const source = String(text || "");
  const escaped = String(heading || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const start = source.search(new RegExp(`^##\\s+${escaped}\\s*$`, "im"));
  if (start < 0) return {};
  const bodyStart = source.indexOf("\n", start);
  if (bodyStart < 0) return {};
  const remainder = source.slice(bodyStart + 1);
  const next = remainder.search(/^##\s+/m);
  const section = next >= 0 ? remainder.slice(0, next) : remainder;
  const out = {};
  const rowPattern = /^\|\s*([^|]+?)\s*\|\s*([+-]?\d+)\s*\|\s*$/gm;
  let row;
  while ((row = rowPattern.exec(section))) {
    const key = row[1].trim();
    if (!key || /^[-:]+$/.test(key) || keyLabelPattern.test(key)) continue;
    out[key] = Number(row[2]);
  }
  return out;
}

function markdownRouteList(text) {
  const activeRoutes = markdownSection(text, "Active Routes");
  if (activeRoutes) {
    return activeRoutes
      .split(/[,;\n]/)
      .map((item) => normalizeManualMarkdownText(item.replace(/^[-*]\s+/, "")))
      .filter(Boolean);
  }
  return [];
}

function markdownCharacterSheetDetails(blocks = []) {
  const content = blocks.find((block) => /(?:^|[\\/])character_sheet\.md$/i.test(block.name || ""))?.content || "";
  const statBlockContent = blocks.find((block) => /(?:^|[\\/])Character_Stat_Block\.md$/i.test(block.name || ""))?.content || "";
  if (!content && !statBlockContent) return { spheres: [], abilityScores: {}, abilityModifiers: {}, saves: {}, skills: {}, resources: [], stats: {} };
  const sphereSection = markdownSection(content, "Spheres and Routes")
    || markdownSection(content, "Spheres / Routes")
    || markdownSection(content, "Legal Spheres / Routes")
    || markdownSection(content, "Legal Sphere Package")
    || markdownSection(content, "Sphere / Route Package");
  const spheres = [...sphereSection.matchAll(/^\s*(?:\d+\.\s+|[-*]\s+)\*\*(.+?)\*\*/gm)]
    .map((match) => match[1].replace(/\s+/g, " ").trim())
    .filter((name) => name && !/^(?:forbidden|locked|source-scale)/i.test(name));
  const abilityScores = {};
  const abilityModifiers = {};
  const abilityPattern = /^\|\s*(Strength|Dexterity|Constitution|Intelligence|Wisdom|Charisma|STR|DEX|CON|INT|WIS|CHA)\s*\|\s*(\d{1,2})\s*\|\s*([+-]\d+)\s*\|/gim;
  let abilityMatch;
  while ((abilityMatch = abilityPattern.exec(content))) {
    const short = abilityShortName(abilityMatch[1]);
    if (!short) continue;
    abilityScores[short] = Number(abilityMatch[2]);
    abilityModifiers[short] = Number(abilityMatch[3]);
  }
  const statSectionText = [markdownSection(content, "Stats"), markdownSection(statBlockContent, "Stats"), content, statBlockContent].filter(Boolean).join("\n");
  const jsonAbilityMatch = statSectionText.match(/\{\s*"?STR"?\s*:\s*\d{1,2}[\s\S]*?"?CHA"?\s*:\s*\d{1,2}\s*\}/i);
  if (jsonAbilityMatch) {
    try {
      const parsedStats = JSON.parse(jsonAbilityMatch[0].replace(/([,{]\s*)(STR|DEX|CON|INT|WIS|CHA)(\s*:)/g, '$1"$2"$3'));
      ABILITY_ROWS.forEach((ability) => {
        const value = parsedStats[ability.short];
        if (Number.isFinite(Number(value))) abilityScores[ability.short] = Number(value);
      });
    } catch (_) {}
  }
  const headerStatMatch = statSectionText.match(/\|\s*STR\s*\|\s*DEX\s*\|\s*CON\s*\|\s*INT\s*\|\s*WIS\s*\|\s*CHA\s*\|[\s\S]{0,120}?\|\s*(\d{1,2})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})\s*\|\s*(\d{1,2})\s*\|/i);
  if (headerStatMatch) {
    ["STR", "DEX", "CON", "INT", "WIS", "CHA"].forEach((key, idx) => {
      abilityScores[key] = Number(headerStatMatch[idx + 1]);
    });
  }
  const inlineAbilityPattern = /(?:\*\*)?\b(STR|DEX|CON|INT|WIS|CHA)\b(?:\*\*)?\s*[:=]?\s*(\d{1,2})/gim;
  let inlineAbilityMatch;
  while ((inlineAbilityMatch = inlineAbilityPattern.exec(statSectionText))) {
    abilityScores[inlineAbilityMatch[1].toUpperCase()] = Number(inlineAbilityMatch[2]);
  }
  Object.entries(abilityModifiersFromScores(abilityScores)).forEach(([key, value]) => {
    if (abilityModifiers[key] === undefined) abilityModifiers[key] = value;
  });
  const titleName = content.match(/^#\s+Character Sheet\s+[—-]\s+([^—\r\n]+)(?:\s+[—-].*)?$/im)?.[1]?.trim()
    || content.match(/^#\s+([^\r\n]+)/m)?.[1]?.replace(/\s+[—-]\s+.*/, "").trim()
    || "";
  const realmCl = markdownFirstValue(content, ["Realm / CL", "CL/Realm", "Realm and CL", "Realm"]) || markdownFirstValue(statBlockContent, ["Realm / CL", "CL/Realm", "Realm and CL", "Realm"]);
  const statLine = statBlockContent.match(/^\s*[-*]?\s*CL\s*(\d+)\s+(.+?)\s+(Body Refining|Qi Cultivation|Spirit Awakening)\s*$/im);
  const realm = realmCl
    ? String(realmCl).replace(/\bCL\s*\d+\b\s*\/?\s*/i, "").replace(/\/\s*CL\s*\d+.*/i, "").trim()
    : (statLine ? statLine[2].trim() : "");
  const clMatch = String(realmCl).match(/\bCL\s*(\d+)\b/i) || statLine;
  const resourceCandidates = ["Stamina", "Qi", "Resonance", "Cultivation Points", "CP"];
  const resourceName = resourceCandidates.find((label) => markdownBoldValue(content, label) || markdownTableValue(content, label)) || "";
  const resourceValue = resourceName ? markdownNumericValue(content, [resourceName]) : "";
  const resources = resourceName && resourceValue !== "" ? [{ name: resourceName === "CP" ? "Cultivation Points" : resourceName, current: resourceValue, maximum: resourceValue }] : [];
  return {
    spheres: [...new Set([...spheres, ...markdownRouteList(content)])],
    abilityScores,
    abilityModifiers,
    saves: markdownBonusTableMap(content, "Saving Throws", /^save$/i),
    skills: markdownBonusTableMap(content, "Skills", /^skill$/i),
    resources,
    stats: {
      name: markdownFirstValue(content, ["Name"]) || titleName,
      path: markdownFirstValue(content, ["Path"]) || (statLine ? statLine[3].trim() : ""),
      realm,
      cl: clMatch ? Number(clMatch[1]) : "",
      hp: markdownNumericValue(content, ["HP", "Hit Points"]),
      ac: markdownNumericValue(content, ["AC", "Armor Class"]),
      speed: markdownFirstValue(content, ["Speed"]) || markdownFirstValue(statBlockContent, ["Speed"]) || (statBlockContent.match(/\bSpeed\s+([^;\r\n]+)/i)?.[1]?.trim() || ""),
      attack: markdownFirstValue(content, ["Technique Attack", "Attack", "Cultivation Attack"]) || markdownFirstValue(statBlockContent, ["Technique Attack", "Attack", "Cultivation Attack"]) || (statBlockContent.match(/\bTechnique Attack\s+([+-]?\d+)/i)?.[1] || ""),
      saveDc: markdownNumericValue(content, ["Save DC", "Technique Save DC", "Cultivation Save DC"]) || markdownNumericValue(statBlockContent, ["Save DC", "Technique Save DC", "Cultivation Save DC"]) || (statBlockContent.match(/\bSave DC\s+(\d+)/i)?.[1] || "")
    }
  };
}

function markdownActionRegistryEntries(raw = "") {
  const source = String(raw || "").replace(/\r/g, "");
  if (!source) return [];
  const sections = [...source.matchAll(/^#{2,3}\s+(.+?)\n([\s\S]*?)(?=^#{2,3}\s+|$(?![\s\S]))/gm)];
  let contextType = "";
  const entries = [];
  for (const section of sections) {
    const heading = section[1].trim();
    const body = section[2];
    if (/^(?:passive|always-on|actions|bonus actions|reactions)$/i.test(heading)) {
      if (/bonus actions/i.test(heading)) contextType = "Bonus Action";
      else if (/reactions/i.test(heading)) contextType = "Reaction";
      else if (/actions/i.test(heading)) contextType = "Action";
      continue;
    }
    const field = (label) => body.match(new RegExp(`^-\\s*\\*\\*${label}:\\*\\*\\s*([^\\n]+)`, "im"))?.[1]?.trim() || "";
    const actionType = field("Action Type") || field("Type") || contextType;
    const effect = field("Effect");
    const trigger = field("Trigger");
    if (!actionType || (!effect && !trigger)) continue;
    entries.push({
      name: heading.replace(/^\d+\.\s*/, ""),
      type: actionType,
      cost: field("Cost"),
      range: field("Range") || field("Area"),
      attack: field("Attack") || field("Save"),
      damage: field("Damage"),
      effect: [trigger && `Trigger: ${trigger}`, effect, field("Rider")].filter(Boolean).join(" "),
      limit: field("Limit") || field("Requirement"),
      source: "Imported action-registry Markdown"
    });
  }
  return entries;
}

function markdownBulletLines(section = "") {
  return String(section || "").split(/\r?\n/)
    .map((line) => line.match(/^\s*[-*]\s+(.+)$/)?.[1]?.trim() || "")
    .filter(Boolean);
}

function cleanMarkdownFoundationSelection(raw = "") {
  let text = String(raw || "").replace(/[`*]/g, " ").replace(/\s+/g, " ").trim();
  const dash = text.match(/#?\d+\s*[—:\-]\s*(.+)$/);
  if (dash) text = dash[1].trim();
  text = text.replace(/\(#?\d+\)/g, "").replace(/^#?\d+\s*/, "").trim();
  return text;
}

function markdownFoundationRecord(blocks = []) {
  const content = blocks.find((block) => /foundation_record\.md$/i.test(block.name || ""))?.content || "";
  if (!content) return null;
  const field = (label) => content.match(new RegExp(`(?:^|[-\\s])\\*\\*${label}:\\*\\*\\s*([^\\r\\n]+)`, "im"))?.[1]?.trim() || "";
  const titleName = content.match(/^#\s+Foundation Record\s*[—:\-]\s*(.+?)\s*$/im)?.[1]?.trim()
    || content.match(/^#\s+(.+?)\s+Foundation Record\s*$/im)?.[1]?.trim()
    || "";
  const selectedRaw = field("Foundation Name") || field("Selected Foundation") || field("Catalog Foundation") || field("Foundation") || field("Catalog entry") || titleName;
  const catalogNumber = Number((selectedRaw.match(/#(\d+)/) || field("Catalog Number").match(/(\d+)/) || [])[1] || "");
  const thesis = markdownSection(content, "Foundation Thesis").replace(/\s+/g, " ").trim();
  const benefits = markdownBulletLines(markdownSection(content, "Benefits"));
  const drawbacks = markdownBulletLines(markdownSection(content, "Drawbacks"));
  const componentSection = markdownSection(content, "Foundation Components");
  const components = [...componentSection.matchAll(/^###\s+(.+)$/gim)].map((match) => match[1].trim()).filter(Boolean);
  const firstParagraph = String(content || "").replace(/^#.*$/m, "").split(/^##\s+/m)[0].replace(/\*\*[^\n]+\*\*\s*[^\n]*/g, "").replace(/\s+/g, " ").trim();
  return {
    name: cleanMarkdownFoundationSelection(selectedRaw) || "Foundation",
    catalog_number: Number.isFinite(catalogNumber) ? catalogNumber : undefined,
    family: field("Foundation Family") || field("Family"),
    depth: field("Depth"),
    stage: field("Stage"),
    path: field("Path") || field("Path fit") || field("Primary Path Fit"),
    dao_principle: thesis || firstParagraph,
    mechanical_permissions: [...components, ...benefits],
    explicit_non_permissions: drawbacks,
    disposition: field("Package Status") || field("Status") || field("Catalog result")
  };
}


function forgedTechniqueMarkdownSource(blocks = []) {
  const preferred = blocks.find((block) => /forged_technique_registry\.md$/i.test(block.name || ""))?.content || "";
  if (preferred) return preferred;
  return blocks.find((block) => /forged_technique_overlay\.md$/i.test(block.name || ""))?.content || "";
}

function parseForgedTechniqueMarkdown(source = "") {
  const text = String(source || "").replace(/\r/g, "");
  if (!text) return [];
  const matches = [...text.matchAll(/^##\s+(\d+)\.\s+(.+?)\s*$/gm)];
  return matches.map((match, index) => {
    const ordinal = Number(match[1]);
    const name = normalizeManualMarkdownText(match[2]);
    const start = match.index + match[0].length;
    const end = matches[index + 1]?.index ?? text.length;
    const body = text.slice(start, end);
    const fields = parseManualMarkdownBullets(body);
    const sourceText = fields.spheres || fields.components || fields.source || "";
    const components = sourceRouteChipsFromText(sourceText);
    const description = fields.effect || fields.resolution || "";
    return {
      forged_id: `markdown-forged-technique-${ordinal}-${techniqueKey(name)}`,
      name,
      display_name: name,
      technique_number: ordinal,
      type: fields.type || "Forged Technique",
      action_type: fields.type || "Forged Technique",
      action_economy: fields.type || "",
      cost: fields.cost || "",
      source: "Markdown-derived from Forged_Technique_Registry/Overlay.md",
      provenance: "Forged_Technique_Registry.md",
      spheres: normalizeManualMarkdownText(fields.spheres || ""),
      components,
      associated_spheres: components,
      trigger: fields.trigger || "",
      use_condition: fields.use_condition || "",
      attack_or_save: fields.roll_save || "",
      roll_save: fields.roll_save || "",
      effect: description,
      effect_summary: description,
      summary: description,
      description,
      duration: fields.duration || "",
      limit: fields.limit || "",
      limits: fields.limit || "",
      risk: fields.risk || fields.strain || fields.drawback || "",
      formula: fields.formula || "",
      raw_markdown: body.trim(),
      markdown_derived: true
    };
  }).filter((item) => item.name);
}

function forgedTechniqueMarkdownDetails(blocks = []) {
  return parseForgedTechniqueMarkdown(forgedTechniqueMarkdownSource(blocks));
}

function fileBlock(name, content) {
  return `===== FILE: ${name} =====\n${String(content || "").trim()}`;
}

let crcTable = null;

function crc32(bytes) {
  if (!crcTable) {
    crcTable = Array.from({ length: 256 }, (_, index) => {
      let value = index;
      for (let bit = 0; bit < 8; bit += 1) {
        value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
      }
      return value >>> 0;
    });
  }
  let crc = 0xffffffff;
  bytes.forEach((byte) => {
    crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  });
  return (crc ^ 0xffffffff) >>> 0;
}

function dosDateTime(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  const dosTime = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { dosDate, dosTime };
}

function pushUint16(out, value) {
  out.push(value & 0xff, (value >>> 8) & 0xff);
}

function pushUint32(out, value) {
  out.push(value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff);
}

function createStoredZip(files) {
  const encoder = new TextEncoder();
  const local = [];
  const central = [];
  const records = [];
  const { dosDate, dosTime } = dosDateTime();

  files.forEach((file) => {
    const nameBytes = encoder.encode(file.name.replace(/\\/g, "/"));
    const data = file.bytes || encoder.encode(String(file.content || ""));
    const checksum = crc32(data);
    const localOffset = local.length;
    pushUint32(local, 0x04034b50);
    pushUint16(local, 20);
    pushUint16(local, 0);
    pushUint16(local, 0);
    pushUint16(local, dosTime);
    pushUint16(local, dosDate);
    pushUint32(local, checksum);
    pushUint32(local, data.length);
    pushUint32(local, data.length);
    pushUint16(local, nameBytes.length);
    pushUint16(local, 0);
    local.push(...nameBytes, ...data);
    records.push({ nameBytes, data, checksum, localOffset });
  });

  const centralOffset = local.length;
  records.forEach((record) => {
    pushUint32(central, 0x02014b50);
    pushUint16(central, 20);
    pushUint16(central, 20);
    pushUint16(central, 0);
    pushUint16(central, 0);
    pushUint16(central, dosTime);
    pushUint16(central, dosDate);
    pushUint32(central, record.checksum);
    pushUint32(central, record.data.length);
    pushUint32(central, record.data.length);
    pushUint16(central, record.nameBytes.length);
    pushUint16(central, 0);
    pushUint16(central, 0);
    pushUint16(central, 0);
    pushUint16(central, 0);
    pushUint32(central, 0);
    pushUint32(central, record.localOffset);
    central.push(...record.nameBytes);
  });

  const end = [];
  pushUint32(end, 0x06054b50);
  pushUint16(end, 0);
  pushUint16(end, 0);
  pushUint16(end, records.length);
  pushUint16(end, records.length);
  pushUint32(end, central.length);
  pushUint32(end, centralOffset);
  pushUint16(end, 0);
  return new Uint8Array([...local, ...central, ...end]);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function fileExtension(name) {
  const match = String(name || "").toLowerCase().match(/\.([a-z0-9]+)$/);
  return match ? match[1] : "";
}

function isTextLikeFile(name) {
  return ["txt", "md", "markdown", "json", "csv", "yaml", "yml", "html", "htm", "xml"].includes(fileExtension(name));
}

function isDocxFile(name) {
  return fileExtension(name) === "docx";
}

function isZipFile(name) {
  return fileExtension(name) === "zip";
}

function hasDroppedFiles(event) {
  return Array.from(event.dataTransfer?.types || []).includes("Files");
}

function decodeText(bytes) {
  return new TextDecoder("utf-8").decode(bytes);
}

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error || new Error("Could not read file."));
    reader.readAsText(file);
  });
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error("Could not read file."));
    reader.readAsArrayBuffer(file);
  });
}

function findEndOfCentralDirectory(bytes) {
  for (let offset = bytes.length - 22; offset >= Math.max(0, bytes.length - 66000); offset -= 1) {
    if (
      bytes[offset] === 0x50
      && bytes[offset + 1] === 0x4b
      && bytes[offset + 2] === 0x05
      && bytes[offset + 3] === 0x06
    ) {
      return offset;
    }
  }
  return -1;
}

async function inflateRaw(bytes) {
  if (typeof DecompressionStream !== "undefined") {
    try {
      const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (error) {
      // Some mobile browsers expose DecompressionStream but reject deflate-raw.
      if (!(globalThis.pako && typeof globalThis.pako.inflateRaw === "function")) throw error;
    }
  }
  if (globalThis.pako && typeof globalThis.pako.inflateRaw === "function") {
    return new Uint8Array(globalThis.pako.inflateRaw(bytes));
  }
  throw new Error("Zip decompression is unavailable. Keep pako.min.js beside index.html or unzip the character package first.");
}

function arrayBufferToBytes(buffer) {
  return buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
}

async function extractZipEntries(buffer) {
  const bytes = arrayBufferToBytes(buffer);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const eocd = findEndOfCentralDirectory(bytes);
  if (eocd < 0) throw new Error("Could not find the zip directory. Try unzipping this file first.");

  const entryCount = view.getUint16(eocd + 10, true);
  const centralDirectoryOffset = view.getUint32(eocd + 16, true);
  const entries = [];
  let offset = centralDirectoryOffset;

  for (let index = 0; index < entryCount; index += 1) {
    if (view.getUint32(offset, true) !== 0x02014b50) break;
    const flags = view.getUint16(offset + 8, true);
    const method = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const uncompressedSize = view.getUint32(offset + 24, true);
    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localHeaderOffset = view.getUint32(offset + 42, true);
    const nameBytes = bytes.slice(offset + 46, offset + 46 + nameLength);
    const name = decodeText(nameBytes);
    offset += 46 + nameLength + extraLength + commentLength;

    if (!name || name.endsWith("/") || flags & 0x01) continue;
    if (view.getUint32(localHeaderOffset, true) !== 0x04034b50) continue;
    const localNameLength = view.getUint16(localHeaderOffset + 26, true);
    const localExtraLength = view.getUint16(localHeaderOffset + 28, true);
    const dataStart = localHeaderOffset + 30 + localNameLength + localExtraLength;
    const compressed = bytes.slice(dataStart, dataStart + compressedSize);
    let fileBytes;
    if (method === 0) {
      fileBytes = compressed;
    } else if (method === 8) {
      fileBytes = await inflateRaw(compressed);
    } else {
      entries.push({ name, skipped: true, reason: `Unsupported zip compression method ${method}.` });
      continue;
    }
    entries.push({ name, bytes: fileBytes, size: uncompressedSize });
  }

  return entries;
}

function xmlToText(xml) {
  return String(xml || "")
    .replace(/<\/w:p>/g, "\n")
    .replace(/<w:tab\/>/g, "\t")
    .replace(/<[^>]+>/g, "")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function extractDocxTextFromBytes(bytes) {
  const entries = await extractZipEntries(bytes);
  const documentEntry = entries.find((entry) => entry.name === "word/document.xml");
  if (!documentEntry?.bytes) return "";
  return xmlToText(decodeText(documentEntry.bytes));
}

// v1.11.0-HF05 reader calibration: accept both older CML packages and newer
// ChatGPT-generated strict packages, whether files sit under a root folder, at ZIP
// root, or inside a roster bundle's /packages/*.zip layer.
const CML_CHARACTER_RECORD_PATTERN = /(?:^|\/)(?:Complete_Character_Record|(?:[^/]+_)?Dashboard_Import|(?:[^/]+_)?Normalized(?:_Sheet)?|[^/]+(?:_Character|_Tournament)_Build[^/]*\.md|Character_Stat_Block|character_sheet\.md|Strict_Package_Envelope|Talent_Action_(?:Coverage_Audit|Universal_Expression_Map)|Tianxia_GM_Character_View_Model_v2|Background_Origin_Profile|Origin_Insight_Ledger|Sphere_Acquisition_Ledger|Talent_Source_Ledger|Level_Talent_Ledger|Trained_Choice_Ledger|Cultivation_Method_Profile|Dao_Profile|I_Ching_Combat_Generation_Profile|Character_Import_Surface|Character_Core|Ability_Score_Advancement_Ledger|Import_Surface_Field_Map|Import_Surface_Display_Alias_Map|Action_Execution_Scripts|Legal_Talent_Inventory|Legal_Talent_Display_Alias_Audit|Combat_Playbook|Composite_Action_Registry|Talent_Augmentation_Registry|Complete_Action_Surface|Temporal_Feasibility_Registry|State_Window_Lock_Audit|Execution_Block_Registry|Field_Object_Registry|Combat_State_Ledger_Template|Live_Combat_State_Audit|Dao_Combat_Behavior_Profile|Martial_Arts_and_Manuals|Martial_Manual_Registry|Forged_Technique_(?:Overlay|Registry)|Foundation_Registry|GM_Screen_(?:Projection|Display)_Rows|Martial_Manual_Display_Rows|Foundation_Display_Row|Background_Origin_Profile|Origin_Insight_Ledger|Sphere_Acquisition_Ledger|Talent_Source_Ledger|Level_Talent_Ledger|Trained_Choice_Ledger|Cultivation_Method_Profile|Dao_Profile|I_Ching_Combat_Generation_Profile|Tianxia_GM_Character_View_Model_v2)[^/]*$/i;
const CML_CHARACTER_IMPORT_PATTERN = /(?:README_FIRST|Complete_Character_Record|Dashboard_Import|Dashboard_Export|Normalized(?:_Sheet)?|(?:Character|Tournament)_Build|Tianxia_GM_Character_View_Model_v2|Character_(?:Stat_Block|Generation_Brief|Import_Surface|Core)|Background_Origin_Profile|Origin_Insight_Ledger|Sphere_Acquisition_Ledger|Talent_Source_Ledger|Level_Talent_Ledger|Trained_Choice_Ledger|Cultivation_Method_Profile|Dao_Profile|I_Ching_Combat_Generation_Profile|Dao_Yijing_Profile|Human_Review_Checklist|Foundation_(?:Registry|Record)|Background_Record|Martial_(?:Arts_and_)?Manuals|Martial_Manual_Registry|Combat_Playbook|Composite_Action_Registry|Talent_Augmentation_Registry|Complete_Action_Surface|Temporal_Feasibility_Registry|State_Window_Lock_Audit|Composite_Temporal_Feasibility_Reader|Execution_Block_Registry|Execution_Block_Audit|Execution_Block_Reader|Field_Object_Registry|Combat_State_Ledger_Template|Live_Combat_State_Audit|Live_Combat_State_Reader|Dao_Combat_Behavior_Profile|Forged_Technique_(?:Overlay|Registry)|Simulation_Behavior_Profile|Ruleset_Lock|Skill_Proficiency_Registry|Saving_Throw_Registry|Talent_Action_(?:Coverage_Audit|Universal_Expression_Map)|Talent_Manual_Foundation_Link_Map|Import_Surface_Field_Map|Import_Surface_Display_Alias_Map|Ability_Score_Advancement_Ledger|Ability_Source_Closure_Ledger|Legal_Talent_Inventory|Legal_Talent_Audit|Legal_Talent_Display_Alias_Audit|Action_Execution_Scripts|Action_Execution_Script_Display_Alias|(?:Character_)?Action_Registry|ACTION_REGISTRY|Technique_Registry|(?:Character_)?State_Registry|STATE_REGISTRY|Condition_Effect_Registry|Passive_Modifier_Registry|Limited_Resource_Counter_Inventory|Controlled_Asset_Inventory|Prepared_Object_Registry|Character_Field_Provenance|Package_Crosswalk_Index|Strict_Package_Envelope|State_Reference_Synchronization_Audit|Manual_Cost_Resource_Parity_Audit|Export_Synchronization_Audit|Package_Manifest_SHA256_Audit|Roster_Admission_Profile|Character_Source_Map|Workflow_Admission_Projection_Audit|Manual_Ledger_Projection_Audit|FINAL_INTEGRITY_REPORT|Character_Package_Completeness_Audit|Strict_Combat_Admission_Summary|Character_Multi_Pass_Audit|Character_Semantic_Coverage_Audit|Character_Sheet_Accessibility_Audit|ADMISSION_AUDIT|SOURCE_NOTES|CONCEPT_NOTES|character_sheet\.md|simulation_behavior_card|package_manifest|PACKAGE_MANIFEST|PACKAGE_FILE_SHA256SUMS|manifest\.json|Roll20_(?:Import|Compact)|roll20_compact_import|VTT_Export|character_compact|compact_export|CHARACTER_EXPORT|profile\.json|GM_Screen_(?:Projection|Display)_Rows|Martial_Manual_Display_Rows|Foundation_Display_Row|Background_Origin_Profile|Origin_Insight_Ledger|Sphere_Acquisition_Ledger|Talent_Source_Ledger|Level_Talent_Ledger|Trained_Choice_Ledger|Cultivation_Method_Profile|Dao_Profile|I_Ching_Combat_Generation_Profile|Tianxia_GM_Character_View_Model_v2)/i;

function isCmlInfrastructureEntryName(name) {
  const text = String(name || "").replace(/\\/g, "/");
  return /(?:^|\/)(?:00_BOOTSTRAPS|01_REFERENCE|02_HELPER_SCRIPTS|03_REFERENCE|04_REFERENCE|05_REFERENCE|06_SCHEMA_TEMPLATES|(?:\d+_)?ARCHIVE[^/]*|audits?|__MACOSX)(?:\/|$)/i.test(text)
    || /(?:^|\/)(?:HF05B3F_|HF05B3G_|HF05B3H_|validate_hf05|README_SEND_THIS_TO|TIANXIA_HF05|GM_SCREEN_)/i.test(text)
    || /(?:^|\/)[^/]*ARCHIVED_NOT_ACTIVE[^/]*$/i.test(text);
}

function entryBaseName(name) {
  return String(name || "").replace(/\\/g, "/").split("/").filter(Boolean).pop() || "";
}

function relativeCharacterEntryName(entryName, folder) {
  const name = String(entryName || "").replace(/\\/g, "/");
  if (folder === "__ROOT__") return entryBaseName(name);
  return name.startsWith(`${folder}/`) ? name.slice(folder.length + 1) : entryBaseName(name);
}

function isCmlCharacterRecordEntry(entry) {
  const name = String(entry?.name || "").replace(/\\/g, "/");
  if (!name || isCmlInfrastructureEntryName(name)) return false;
  // HF05S: do not let roster ZIP filenames such as *_STABLE_NORMALIZED_*.zip
  // or their checksum sidecars satisfy the loose legacy "Normalized" detector.
  // Only real text/docx package records should seed a character folder.
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  return CML_CHARACTER_RECORD_PATTERN.test(entryBaseName(name));
}

function cmlCharacterFolder(name) {
  const text = String(name || "").replace(/\\/g, "/");
  const base = entryBaseName(text);
  if (!CML_CHARACTER_RECORD_PATTERN.test(base)) return "";
  const index = text.length - base.length;
  const prefix = text.slice(0, index).replace(/\/$/, "");
  return prefix || "__ROOT__";
}

function cmlFolderCharacterName(folder) {
  if (folder === "__ROOT__") return "Imported Character";
  const base = String(folder || "").split(/[\/]/).filter(Boolean).pop() || "";
  return base
    .replace(/_CL\d+.*$/i, "")
    .replace(/_v\d+(?:_\d+)*.*$/i, "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isEntryInCharacterFolder(entryName, folder) {
  const name = String(entryName || "").replace(/\\/g, "/");
  if (isCmlInfrastructureEntryName(name)) return false;
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  const relative = relativeCharacterEntryName(name, folder);
  if (folder === "__ROOT__" && name.includes("/")) return false;
  if (folder !== "__ROOT__" && !name.startsWith(`${folder}/`)) return false;
  // Test the file's relative/basename only.  Roster bundle paths may contain
  // words like "Stable_Normalized_Roster" that should not make every nested
  // file importable.
  return CML_CHARACTER_IMPORT_PATTERN.test(relative);
}

function shortCharacterEntryName(entryName, folder) {
  return relativeCharacterEntryName(entryName, folder);
}

function normalizedZipEntryName(name) {
  return String(name || "").replace(/\\/g, "/").replace(/^\/+/, "");
}

function findRosterIndexEntry(entries = []) {
  return entries.find((entry) => {
    const name = normalizedZipEntryName(entry?.name);
    return isTextLikeFile(name) && /(?:^|\/)characters\/Character_Roster_Index[^/]*\.json$/i.test(name);
  }) || entries.find((entry) => {
    const name = normalizedZipEntryName(entry?.name);
    return isTextLikeFile(name) && /(?:^|\/)Character_Roster_Index[^/]*\.json$/i.test(name);
  }) || null;
}

function rosterIndexBasePrefix(rosterEntryName = "") {
  const name = normalizedZipEntryName(rosterEntryName);
  const marker = name.search(/(?:^|\/)characters\/Character_Roster_Index[^/]*\.json$/i);
  if (marker < 0) return "";
  const leading = name.slice(0, marker);
  return leading.replace(/\/$/, "");
}

function parseRosterIndexData(entry, notes, label) {
  if (!entry?.bytes) return null;
  try {
    const data = JSON.parse(decodeText(entry.bytes));
    const characters = Array.isArray(data?.characters) ? data.characters : [];
    if (!characters.length) return null;
    return { ...data, characters };
  } catch (error) {
    notes.push(`${label}::${entry.name}: roster index JSON could not be parsed.`);
    return null;
  }
}

function findRosterPackageEntry(entries = [], rosterEntry = {}, packagePath = "") {
  const target = normalizedZipEntryName(packagePath);
  if (!target) return null;
  const prefix = rosterIndexBasePrefix(rosterEntry.name);
  const preferred = prefix ? `${prefix}/${target}` : target;
  return entries.find((entry) => normalizedZipEntryName(entry.name) === preferred)
    || entries.find((entry) => normalizedZipEntryName(entry.name) === target)
    || entries.find((entry) => normalizedZipEntryName(entry.name).endsWith(`/${target}`))
    || null;
}

async function importRosterIndexCharacterPackages(entries, label, chunks, notes, depth, discoveredCharacterPackages) {
  // HF05S: R9/R12 bootstrap bundles are intentionally no-GM-screen outer
  // archives with an active Character_Roster_Index plus nested character ZIPs.
  // When that index exists, use it as authority and do not scan bootstrap
  // hotfix/validation fixture ZIPs as extra importable characters.
  if (depth !== 0) return 0;
  const rosterEntry = findRosterIndexEntry(entries);
  const roster = parseRosterIndexData(rosterEntry, notes, label);
  if (!roster?.characters?.length) return 0;

  let imported = 0;
  let missing = 0;
  for (const character of roster.characters) {
    const packagePath = character?.package || character?.package_path || character?.zip || "";
    const packageEntry = findRosterPackageEntry(entries, rosterEntry, packagePath);
    if (!packageEntry?.bytes) {
      missing += 1;
      notes.push(`${label}: roster package missing: ${packagePath || character?.display_name || "unnamed character"}.`);
      continue;
    }
    const before = discoveredCharacterPackages.length;
    imported += await importZipBytes(packageEntry.bytes, `${label}::${packagePath}`, chunks, notes, depth + 1, discoveredCharacterPackages);
    const discovered = discoveredCharacterPackages.length - before;
    if (!discovered) notes.push(`${label}: roster package contained no importable character surface: ${packagePath}.`);
  }
  notes.push(`${label}: active roster index detected (${roster.characters.length} listed; ${imported} imported${missing ? `; ${missing} missing` : ""}).`);
  return imported;
}

function isGenericPackageName(name) {
  const text = String(name || "").trim();
  return /^(?:background record|character sheet|character|sheet|unnamed(?: tianxia character)?)$/i.test(text)
    || /(?:admission audit|action registry|state registry|package manifest|source notes|concept notes|character export|compact export)$/i.test(text);
}

function packageSourceKeyFromFolder(folder = "") {
  const text = String(folder || "").replace(/\\/g, "/");
  const base = text.split("/").filter(Boolean).pop() || text || "imported_character";
  return base.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

function analyzeCmlCharacterPackage(characterPackage) {
  // HF05X: roster package folders are authoritative import boundaries, but the
  // display name should prefer Character_Import_Surface / Complete record names.
  // Passing the folder name as a fallback prevents early alphabetic ledgers such
  // as Ability_Source_Closure_Ledger.json from becoming dropdown labels.
  // The folder also becomes the source package key; using the first imported
  // block name caused many R9/R12 packages to share "ability_source_closure_ledger"
  // and overwrite each other in the saved dropdown.
  const analysis = analyzePackageText(characterPackage.text, cmlFolderCharacterName(characterPackage.folder));
  analysis.sourcePackageKey = packageSourceKeyFromFolder(characterPackage.folder);
  return analysis;
}

async function cmlCharacterPackagesFromEntries(entries, label, notes) {
  const records = entries.filter((entry) => isCmlCharacterRecordEntry(entry));
  if (!records.length) return [];
  const folders = [...new Set(records.map((entry) => cmlCharacterFolder(entry.name)).filter(Boolean))];
  if (!folders.length) return [];

  const packages = [];
  for (const folder of folders) {
    const folderEntries = entries
      .filter((entry) => isEntryInCharacterFolder(entry.name, folder))
      .sort((a, b) => a.name.localeCompare(b.name));
    const chunks = [];
    for (const entry of folderEntries) {
      const shortName = shortCharacterEntryName(entry.name, folder);
      if (entry.skipped) {
        notes.push(`${label}::${entry.name}: ${entry.reason}`);
      } else if (isTextLikeFile(entry.name)) {
        chunks.push(fileBlock(shortName, decodeText(entry.bytes)));
      } else if (isDocxFile(entry.name) && /character_sheet\.docx$/i.test(entry.name)) {
        try {
          const text = await extractDocxTextFromBytes(entry.bytes);
          chunks.push(fileBlock(shortName, text || "[DOCX present, but no readable text was extracted.]"));
        } catch {
          chunks.push(fileBlock(shortName, "[DOCX present. Text extraction failed, but the artifact exists.]"));
        }
      }
    }
    if (chunks.length) packages.push({ folder: folder === "__ROOT__" ? label.replace(/\.zip$/i, "") : folder, text: chunks.join("\n\n") });
  }
  return packages;
}

async function importZipBytes(bytes, label, chunks, notes, depth = 0, discoveredCharacterPackages = []) {
  if (depth > 2) {
    notes.push(`${label}: nested zip depth limit reached.`);
    return 0;
  }
  if (/(?:^|::|[\\/])audits?(?:[\\/]|::|$)/i.test(label)) {
    notes.push(`${label}: skipped audit archive during roster import.`);
    return 0;
  }
  const entries = await extractZipEntries(bytes);
  const rosterImported = await importRosterIndexCharacterPackages(entries, label, chunks, notes, depth, discoveredCharacterPackages);
  if (rosterImported) return rosterImported;
  const cmlPackages = await cmlCharacterPackagesFromEntries(entries, label, notes);
  if (cmlPackages.length) {
    discoveredCharacterPackages.push(...cmlPackages);
    notes.push(`${label}: found ${cmlPackages.length} character package${cmlPackages.length === 1 ? "" : "s"}.`);
    return cmlPackages.length;
  }
  const rosterCompleteSheets = depth === 0
    ? entries.filter((entry) => /\/characters\/[^/]+\/complete_sheet\.json$/i.test(entry.name || ""))
    : [];
  const isRosterArchive = rosterCompleteSheets.length > 1;
  if (isRosterArchive) {
    notes.push(`${label}: roster reconstruction archive detected (${rosterCompleteSheets.length} characters). Import one character package/folder at a time for sheet viewing.`);
  }
  let readable = 0;
  for (const entry of entries) {
    const displayName = depth ? `${label}::${entry.name}` : entry.name;
    if (entry.skipped) {
      notes.push(`${displayName}: ${entry.reason}`);
      continue;
    }
    if (/(?:^|[\\/])audits?(?:[\\/]|$)/i.test(entry.name || "")) {
      notes.push(`${displayName}: skipped audit material during roster import.`);
      continue;
    }
    if (isRosterArchive && /\/characters\//i.test(entry.name || "")) {
      continue;
    }
    if (/\/raw_package\//i.test(entry.name || "")) {
      notes.push(`${displayName}: skipped preserved raw-package copy; reconstructed sheet files carry the display fields.`);
      continue;
    }
    if (isZipFile(entry.name)) {
      readable += await importZipBytes(entry.bytes, displayName, chunks, notes, depth + 1, discoveredCharacterPackages);
    } else if (isTextLikeFile(entry.name)) {
      chunks.push(fileBlock(displayName, decodeText(entry.bytes)));
      readable += 1;
    } else if (isDocxFile(entry.name)) {
      try {
        const text = await extractDocxTextFromBytes(entry.bytes);
        chunks.push(fileBlock(displayName, text || "[DOCX present, but no readable text was extracted.]"));
        readable += 1;
      } catch {
        chunks.push(fileBlock(displayName, "[DOCX present. Text extraction failed, but the artifact exists.]"));
        readable += 1;
      }
    } else {
      notes.push(`${displayName}: kept as package asset, not imported as text.`);
    }
  }
  return readable;
}

async function importPackageFiles(files) {
  const list = [...files];
  if (!list.length) return;
  const chunks = [];
  const notes = [];
  const discoveredCharacterPackages = [];
  let savedFromZip = 0;
  $("packageFileStatus").textContent = `Reading ${list.length} file${list.length === 1 ? "" : "s"}...`;

  try {
    for (const file of list) {
      if (isZipFile(file.name)) {
        const bytes = await readFileAsArrayBuffer(file);
        const readable = await importZipBytes(bytes, file.name, chunks, notes, 0, discoveredCharacterPackages);
        notes.push(`${file.name}: imported ${readable} readable file${readable === 1 ? "" : "s"} from zip.`);
      } else if (isTextLikeFile(file.name)) {
        chunks.push(fileBlock(file.name, await readFileAsText(file)));
        notes.push(`${file.name}: imported.`);
      } else if (isDocxFile(file.name)) {
        try {
          const text = await extractDocxTextFromBytes(await readFileAsArrayBuffer(file));
          chunks.push(fileBlock(file.name, text || "[DOCX present, but no readable text was extracted.]"));
          notes.push(`${file.name}: imported DOCX text.`);
        } catch {
          chunks.push(fileBlock(file.name, "[DOCX present. Text extraction failed, but the artifact exists.]"));
          notes.push(`${file.name}: DOCX artifact detected.`);
        }
      } else {
        notes.push(`${file.name}: unsupported file type. Use zip, txt, md, json, or docx.`);
      }
    }

    if (discoveredCharacterPackages.length) {
      const analyses = discoveredCharacterPackages.map((characterPackage) => analyzeCmlCharacterPackage(characterPackage));
      const purged = purgeStalePackagesForIncomingAnalyses(analyses);
      analyses.forEach((analysis) => {
        storePackageAnalysis(analysis);
        savedFromZip += 1;
      });
      notes.push(`Saved ${discoveredCharacterPackages.length} character package${discoveredCharacterPackages.length === 1 ? "" : "s"} separately${purged ? `; replaced ${purged} stale import record${purged === 1 ? "" : "s"}` : ""}.`);
    }

    if (chunks.length) {
      const current = $("canonPackageInput").value.trim();
      $("canonPackageInput").value = [current, chunks.join("\n\n")].filter(Boolean).join("\n\n");
      analyzePackageInput();
    }
    if (savedFromZip) {
      saveState();
      renderAutomation();
      refreshPackageSelectors();
      if ($("activeCharacterSelect") && state.packages[0]) $("activeCharacterSelect").value = state.packages[0].id;
      renderCharacterViewer();
      $("canonPackageInput").value = "";
      $("canonPackageName").value = "";
      $("canonPackageVersion").value = "";
      renderPackageAnalysis(null);
    }
    $("packageFileStatus").textContent = notes.join(" ");
  } catch (error) {
    $("packageFileStatus").textContent = error.message || "File import failed. If this was a zip, unzip it first and drop the extracted files.";
    toast("File import failed.");
  }
}

const ARTIFACT_DEFINITIONS = [
  ["completeRecord", "Complete Character Record", /Complete_Character_Record|tianxia_complete_character_record/i],
  ["generationBrief", "Generation Brief", /generation\s+brief/i],
  ["statBlock", "Stat Block", /stat\s+block|character_sheet\.md/i],
  ["normalizedSheet", "Normalized Sheet", /normalized\s+sheet/i],
  ["normalizedJson", "Normalized JSON", /normalized\s+sheet\.json|normalized_character\.json|normalized\s+json|\"normalizer_version\"/i],
  ["sheetExport", "Sheet Export JSON", /sheet_export\.json|complete_sheet\.json|tianxia_character_sheet_export|tianxia_complete_sheet_export/i],
  ["actionRegistry", "Action Registry", /Character_Action_Registry|tianxia_action_registry|action_block_registry/i],
  ["stateRegistry", "State Registry", /Character_State_Registry|state_registry/i],
  ["passiveRegistry", "Passive Registry", /Passive_Modifier_Registry|passive_modifier_registry/i],
  ["resourceRegistry", "Resource Registry", /Limited_Resource_Counter_Inventory|resource_counter|resources\.json/i],
  ["assetInventory", "Controlled Assets", /Controlled_Asset_Inventory|controlled_asset/i],
  ["fieldProvenance", "Field Provenance", /Character_Field_Provenance|field_provenance|ability_score_provenance/i],
  ["integrityReport", "Integrity / Audit Report", /FINAL_INTEGRITY_REPORT|Character_Package_Completeness_Audit|Strict_Combat_Admission_Summary|Character_Multi_Pass_Audit|Character_Semantic_Coverage_Audit|Character_Sheet_Accessibility_Audit/i],
  ["readableSource", "Readable Sheet Source", /readable\s+sheet\s+source|character_sheet\.md/i],
  ["readableDocx", "Readable DOCX", /readable\s+sheet\.docx|character_sheet\.docx|\.docx/i],
  ["behaviorCard", "Dao Behavior Card", /simulation_behavior_card|combat\s+behaviou?r|dao\s+combat\s+ai/i],
  ["combatPackage", "Combat Package", /combat\s+package/i],
  ["backgroundFuture", "Background/Future", /background.*future|background_and_future/i],
  ["manifest", "Package Manifest", /package_manifest|canon\s+manifest/i],
  ["roll20Export", "Roll20 / VTT Export", /Roll20_Import|VTT_Export|roll20/i],
  ["sourceLock", "Active Source Lock", /active_source_lock|ACTIVE_RELEVANT_SPHERES|CHARACTER_AUTHORITY/i],
  ["reflectionLedger", "Reflection Ledger", /reflection\s+ledger/i],
  ["tacticalPatterns", "Tactical Patterns", /tactical\s+patterns?/i],
  ["retrievalTemplate", "Pre-Fight Retrieval", /pre[-\s]simulation\s+retrieval|retrieval\s+packet/i],
  ["humanReview", "Human Review", /human\s+review/i],
  ["codexNotes", "Codex Notes", /codex\s+integration/i]
];

function detectArtifacts(text, blocks) {
  const combinedNames = blocks.map((block) => block.name).join("\n");
  const haystack = `${combinedNames}\n${text}`;
  return ARTIFACT_DEFINITIONS.reduce((acc, [key, label, pattern]) => {
    acc[key] = {
      label,
      present: pattern.test(haystack)
    };
    return acc;
  }, {});
}

function packageReadiness(artifacts) {
  if (
    artifacts.completeRecord?.present
    && artifacts.actionRegistry?.present
    && (artifacts.passiveRegistry?.present || artifacts.integrityReport?.present)
  ) return "simulation-ready";
  if (artifacts.sheetExport?.present) return "simulation-ready";
  const core = [
    "completeRecord",
    "statBlock",
    "normalizedSheet",
    "normalizedJson",
    "sheetExport",
    "actionRegistry",
    "stateRegistry",
    "passiveRegistry",
    "resourceRegistry",
    "assetInventory",
    "readableSource",
    "behaviorCard",
    "combatPackage"
  ];
  const present = core.filter((key) => artifacts[key]?.present).length;
  if (present >= 6) return "simulation-ready";
  if (present >= 4) return "needs light review";
  if (present >= 2) return "draft package";
  return "raw concept only";
}

function summarizeArtifacts(artifacts) {
  const isCmlPackage = Boolean(artifacts.completeRecord?.present);
  const cmlOptionalKeys = new Set([
    "generationBrief",
    "normalizedSheet",
    "normalizedJson",
    "sheetExport",
    "combatPackage",
    "backgroundFuture",
    "reflectionLedger",
    "tacticalPatterns",
    "retrievalTemplate",
    "humanReview",
    "codexNotes"
  ]);
  const generallyOptionalKeys = new Set([
    "generationBrief",
    "backgroundFuture",
    "reflectionLedger",
    "tacticalPatterns",
    "retrievalTemplate",
    "humanReview",
    "codexNotes"
  ]);
  return ARTIFACT_DEFINITIONS.map(([key, label]) => ({
    key,
    label,
    present: Boolean(artifacts[key]?.present),
    status: artifacts[key]?.present
      ? "Ready"
      : isCmlPackage && cmlOptionalKeys.has(key)
        ? "Optional"
        : generallyOptionalKeys.has(key)
          ? "Optional"
          : "Missing"
  })).filter((item) => item.present || item.status !== "Optional" || isCmlPackage);
}

function packageBlockPriority(blockName) {
  const name = String(blockName || "").toLowerCase();
  if (/complete_character_record/.test(name)) return 0;
  if (/dashboard_import/.test(name)) return 1;
  if (/normalized(?:_sheet)?/.test(name)) return 2;
  if (/character_stat_block/.test(name)) return 3;
  if (/stat\s+block/.test(name)) return 1;
  if (/normalized\s+sheet/.test(name) && !/\.json/.test(name)) return 2;
  if (/readable\s+sheet\s+source|readable\s+sheet/.test(name)) return 3;
  if (/combat\s+package/.test(name)) return 4;
  if (/generation\s+brief/.test(name)) return 5;
  if (/canon\s+manifest/.test(name)) return 6;
  if (/combat\s+behaviou?r|dao\s+combat\s+ai/.test(name)) return 7;
  if (/background|future|reflection|tactical\s+patterns?|retrieval|human\s+review|codex\s+integration|notes/.test(name)) return 99;
  return 50;
}

function packageIdentityBlocks(blocks) {
  const ranked = blocks
    .map((block) => ({ ...block, priority: packageBlockPriority(block.name) }))
    .filter((block) => block.priority < 99)
    .sort((a, b) => a.priority - b.priority || a.name.localeCompare(b.name));
  return ranked.length ? ranked : blocks;
}

function packageIdentityText(blocks, rawText) {
  if (!blocks.length) {
    return splitCleanLines(rawText).slice(0, 220).join("\n");
  }
  return packageIdentityBlocks(blocks)
    .map((block) => `# ${block.name}\n${splitCleanLines(block.content).slice(0, 180).join("\n")}`)
    .join("\n\n");
}

function normalizePathCandidate(value) {
  const text = String(value || "").toLowerCase();
  if (/\bchakra\b|retained wheel|living circuit|inner mandala|living mandala/.test(text)) return "Chakra";
  if (/spirit\s+awakening|spirit\s+awakener|spirit\s+path|spirit\s+doll|soul\s+doll|resonance|spiritual\s+pressure/.test(text)) return "Spirit Awakening";
  if (/qi\s+cultivation|qi\s+cultivator|qi\s+path|meridian|dantian/.test(text)) return "Qi Cultivation";
  if (/body\s+refining|body\s+cultivator|body\s+path|stamina\s+guard/.test(text)) return "Body Refining";
  return "";
}

function isDependentContext(value) {
  return /protected|protects|ward|charge|companion|summon|puppet|construct|retainer|servant|mortal under|under protection|dependent|escorted|target of protection/i.test(String(value || ""));
}

function extractPackagePath(identityText) {
  const identityLines = splitCleanLines(identityText);
  const labels = ["Path", "Cultivation Path", "Main Path", "Primary Path"];
  for (const line of identityLines.slice(0, 160)) {
    if (isDependentContext(line)) continue;
    for (const label of labels) {
      const pattern = new RegExp(`^${escapeRegExp(label)}\\s*[:\\-]\\s*(.+)$`, "i");
      const match = line.match(pattern);
      const path = match ? normalizePathCandidate(match[1]) : "";
      if (path) return path;
    }
  }
  const subpath = extractLineValue(identityLines.slice(0, 160), ["Subpath", "Subclass", "Tradition"]);
  const subpathPath = normalizePathCandidate(subpath);
  if (subpathPath) return subpathPath;
  const earlyOwnText = identityLines.slice(0, 120).filter((line) => !isDependentContext(line)).join("\n");
  return normalizePathCandidate(earlyOwnText) || "Mixed or Unclear";
}

function normalizeRealmCandidate(value) {
  const text = String(value || "").trim();
  if (!text || isDependentContext(text)) return "";
  const cl = text.match(/\bCL\s*\d+\b/i);
  if (cl) return cl[0].toUpperCase().replace(/\s+/, " ");
  const realm = text.match(/\b(Qi Condensation|Foundation Establishment|Foundation|Core Formation|Golden Core|Nascent Soul|Nascient Soul|Soul Formation|Spirit Severing|Immortal|Mortal)\b/i);
  return realm ? realm[0] : text.slice(0, 80);
}

function extractPackageRealm(identityText) {
  const identityLines = splitCleanLines(identityText);
  const labels = ["Realm", "Cultivation Realm", "Cultivation Level", "Character Level", "Threat"];
  for (const line of identityLines.slice(0, 160)) {
    if (isDependentContext(line)) continue;
    for (const label of labels) {
      const pattern = new RegExp(`^${escapeRegExp(label)}\\s*[:\\-]\\s*(.+)$`, "i");
      const match = line.match(pattern);
      const realm = match ? normalizeRealmCandidate(match[1]) : "";
      if (realm) return realm;
    }
  }
  for (const line of identityLines.slice(0, 80)) {
    if (isDependentContext(line)) continue;
    const realm = normalizeRealmCandidate(line.match(/\bCL\s*\d+\b/i)?.[0] || "");
    if (realm) return realm;
  }
  return "";
}

function sphereNamesInText(value) {
  const text = String(value || "").toLowerCase();
  return SPHERES.map((sphere) => {
    const aliases = sphereAliases(sphere);
    const positions = aliases
      .map((alias) => {
        const match = text.match(new RegExp(`(^|[^a-z0-9])${escapeRegExp(alias.toLowerCase())}([^a-z0-9]|$)`));
        return match ? match.index : -1;
      })
      .filter((index) => index >= 0);
    return positions.length ? { sphere, index: Math.min(...positions) } : null;
  })
    .filter(Boolean)
    .sort((a, b) => a.index - b.index)
    .map((item) => item.sphere.name);
}

function extractExplicitPackageSpheres(identityText) {
  const identityLines = splitCleanLines(identityText).slice(0, 180);
  const result = { primary: [], secondary: [] };
  identityLines.forEach((line) => {
    if (isDependentContext(line)) return;
    const primary = line.match(/^(Primary Spheres?|Main Spheres?|Primary Resonance)\s*[:\-]\s*(.+)$/i);
    const secondary = line.match(/^(Secondary Spheres?|Tertiary Spheres?|Accent Spheres?|Minor Spheres?)\s*[:\-]\s*(.+)$/i);
    if (primary) result.primary.push(...sphereNamesInText(primary[2]));
    if (secondary) result.secondary.push(...sphereNamesInText(secondary[2]));
  });
  return {
    primary: [...new Set(result.primary)],
    secondary: [...new Set(result.secondary)]
  };
}

function jsonVersionScore(name) {
  const matches = [...String(name || "").matchAll(/v(\d+)(?:_(\d+))?/gi)];
  if (!matches.length) return 0;
  const last = matches[matches.length - 1];
  return Number(last[1] || 0) * 100 + Number(last[2] || 0);
}

function parseJsonPackageBlocks(blocks) {
  return (blocks || [])
    .filter((block) => /\.json$/i.test(block.name || ""))
    .map((block) => {
      try {
        return { name: block.name, data: JSON.parse(block.content), versionScore: jsonVersionScore(block.name) };
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function findJsonBlock(parsed, patterns) {
  const list = Array.isArray(patterns) ? patterns : [patterns];
  return parsed
    .filter((item) => list.some((pattern) => (
      pattern.test(item.name)
      || pattern.test(String(item.data?.schema_version || ""))
      || pattern.test(String(item.data?.schema || ""))
    )))
    .sort((a, b) => b.versionScore - a.versionScore || a.name.localeCompare(b.name))[0] || null;
}

function asDisplayText(value) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "string") return polishMachineReadableText(value);
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(asDisplayText).filter(Boolean).join("; ");
  if (typeof value === "object") {
    return asDisplayText(value.display)
      || asDisplayText(value.legacy_display)
      || asDisplayText(value.canonical_text)
      || asDisplayText(value.authoritative_source_text)
      || Object.entries(value)
        .filter(([, entry]) => entry !== null && entry !== undefined && entry !== "" && typeof entry !== "object")
        .map(([key, entry]) => `${titleCase(key.replace(/_/g, " "))}: ${asDisplayText(entry)}`)
        .join("; ");
  }
  return String(value);
}

const ABILITY_ROWS = [
  { name: "Strength", short: "STR" },
  { name: "Dexterity", short: "DEX" },
  { name: "Constitution", short: "CON" },
  { name: "Intelligence", short: "INT" },
  { name: "Wisdom", short: "WIS" },
  { name: "Charisma", short: "CHA" }
];

function abilityField(group, ability) {
  if (!group || typeof group !== "object") return undefined;
  const keys = [
    ability.name,
    ability.short,
    ability.name.toLowerCase(),
    ability.short.toLowerCase(),
    ability.name.toUpperCase()
  ];
  for (const key of keys) {
    if (group[key] !== undefined && group[key] !== null && group[key] !== "") return group[key];
  }
  return undefined;
}

function abilityScalarValue(value, keys = []) {
  if (value === null || value === undefined || value === "") return undefined;
  if (typeof value !== "object") return value;
  for (const key of keys) {
    if (value[key] !== undefined && value[key] !== null && value[key] !== "") return value[key];
  }
  return value.final ?? value.score ?? value.value ?? value.total ?? value.modifier ?? value.mod ?? value.bonus ?? asDisplayText(value);
}

function signedNumberText(value) {
  const scalar = abilityScalarValue(value);
  if (scalar === undefined || scalar === null || scalar === "") return "";
  const number = Number(scalar);
  if (Number.isFinite(number)) return `${number >= 0 ? "+" : ""}${number}`;
  const text = asDisplayText(scalar);
  return text ? (String(text).startsWith("+") || String(text).startsWith("-") ? text : `+${text}`) : "";
}

function scoreLine(ability, scores = {}, mods = {}, saves = {}) {
  const score = abilityScalarValue(abilityField(scores, ability), ["final", "score", "value", "total", "base"]);
  const mod = abilityScalarValue(abilityField(mods, ability), ["modifier", "mod", "bonus", "value", "total"]);
  const save = abilityScalarValue(abilityField(saves, ability), ["save", "bonus", "modifier", "mod", "value", "total"]);
  const modText = mod === undefined || mod === null || mod === "" ? "" : ` (${signedNumberText(mod)})`;
  const saveText = save === undefined || save === null || save === "" ? "" : ` save ${signedNumberText(save)}`;
  return `${ability.short} ${score === undefined || score === null || score === "" ? "?" : asDisplayText(score)}${modText}${saveText}`;
}

function hasAbilityScoreData(sheet) {
  return [sheet.abilityScores, sheet.abilityModifiers, sheet.saves].some((group) => (
    group && typeof group === "object" && Object.keys(group).length
  ));
}

function abilityModifiersFromScores(scores = {}) {
  if (!scores || typeof scores !== "object") return {};
  return ABILITY_ROWS.reduce((acc, ability) => {
    const score = Number(abilityField(scores, ability));
    if (Number.isFinite(score)) acc[ability.short] = Math.floor((score - 10) / 2);
    return acc;
  }, {});
}

function abilityShortName(value) {
  const text = String(value || "").trim().toLowerCase();
  return ABILITY_ROWS.find((ability) => (
    ability.short.toLowerCase() === text || ability.name.toLowerCase() === text
  ))?.short || "";
}

function parseBonusList(value) {
  const text = String(value || "");
  const result = {};
  const pattern = /\b(STR|DEX|CON|INT|WIS|CHA|Strength|Dexterity|Constitution|Intelligence|Wisdom|Charisma|[A-Z][A-Za-z'’\-\s]+?)\s*([+-]\d+)\b/g;
  let match;
  while ((match = pattern.exec(text))) {
    const rawName = match[1].trim();
    const ability = abilityShortName(rawName);
    const key = ability || rawName.replace(/\s+/g, " ");
    result[key] = Number(match[2]);
  }
  return result;
}

function savesFromLegacyText(value, modifiers = {}) {
  const listed = parseBonusList(value);
  if (/ordinary\s+saves?\s+otherwise\s+by\s+ability/i.test(String(value || ""))) {
    return { ...modifiers, ...listed };
  }
  return listed;
}

function listLines(items, mapper = (item) => String(item), empty = "- None listed.") {
  const list = compactImportList(items);
  if (!list.length) return empty;
  return list.map((item) => {
    try {
      return `- ${mapper(item)}`;
    } catch (error) {
      return `- ${entryDisplayName(item) || "Entry"}`;
    }
  }).join("\n");
}

function listFromJsonData(data, keys = []) {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  for (const key of keys) {
    if (Array.isArray(data[key])) return data[key];
  }
  // HF05ZC: resource inventories may arrive as object maps, e.g.
  // { resources: { Stamina: 78, HP: 161 } }. Preserve those as rows
  // instead of dropping numeric current/maximum values during GM Screen import.
  for (const key of keys) {
    if ((key === "resources" || key === "limited_resources" || key === "counters") && data[key] && typeof data[key] === "object" && !Array.isArray(data[key])) {
      return resourceEntriesFromMap(data[key]);
    }
  }
  // HF05 accepts both plural and singular schema shapes in repaired packages.
  const singularFallbacks = {
    foundations: "foundation",
    foundation_registry: "foundation",
    manuals: "manual",
    martial_arts: "martial_art",
    actions: "action",
    states: "state",
    counters: "counter",
    assets: "asset",
    controlled_assets: "asset",
    resources: "resource",
    limited_resources: "resource",
    passives: "passive",
    talents: "talent",
    features: "feature"
  };
  for (const key of keys) {
    const singular = singularFallbacks[key];
    if (singular && data[singular] && typeof data[singular] === "object" && !Array.isArray(data[singular])) return [data[singular]];
  }
  return [];
}

function resourceEntriesFromMap(resourceMap = {}) {
  if (!resourceMap || typeof resourceMap !== "object" || Array.isArray(resourceMap)) return [];
  return Object.entries(resourceMap).map(([resourceKey, value]) => {
    const cleanKey = String(resourceKey || "Resource").trim();
    if (value && typeof value === "object" && !Array.isArray(value)) {
      const name = value.display_name || value.name || value.resource_name || cleanKey;
      const max = value.maximum ?? value.max ?? value.value ?? value.total ?? value.current ?? value.remaining ?? "";
      const current = value.current ?? value.current_default ?? value.current_start ?? value.remaining ?? max;
      return {
        resource_id: value.resource_id || value.resource_key || cleanKey.toLowerCase().replace(/[^a-z0-9]+/g, "_"),
        resource_name: name,
        name,
        current,
        maximum: max,
        recovery: value.recovery || value.reset_cadence || value.maximum_formula || value.formula || "",
        tracking_model: value.tracking_model || ""
      };
    }
    return {
      resource_id: cleanKey.toLowerCase().replace(/[^a-z0-9]+/g, "_"),
      resource_name: cleanKey,
      name: cleanKey,
      current: value,
      maximum: value,
      recovery: "",
      tracking_model: ""
    };
  }).filter((entry) => entry.resource_name || entry.name || entry.current !== "" || entry.maximum !== "");
}

function resourceEntryFromIdentity(identity = {}, directRecord = {}, characterCore = {}, mobileStats = {}) {
  const candidates = [
    ["Stamina", identity.stamina ?? directRecord.stamina ?? directRecord.stats?.stamina ?? characterCore.stats?.stamina ?? mobileStats.stamina],
    ["Qi", identity.qi ?? directRecord.qi ?? directRecord.stats?.qi ?? characterCore.stats?.qi ?? mobileStats.qi],
    ["Resonance", identity.resonance ?? directRecord.resonance ?? directRecord.stats?.resonance ?? characterCore.stats?.resonance ?? mobileStats.resonance],
    ["Chakra Points", identity.chakra_points ?? directRecord.chakra_points ?? directRecord.stats?.chakra_points ?? characterCore.stats?.chakra_points ?? mobileStats.chakra_points],
    ["Cultivation Points", identity.cultivation_points ?? directRecord.cultivation_points ?? directRecord.stats?.cultivation_points ?? characterCore.stats?.cultivation_points ?? mobileStats.cultivation_points]
  ];
  const found = candidates.find(([, value]) => value !== undefined && value !== null && value !== "");
  if (!found) return [];
  const [name, value] = found;
  const max = value && typeof value === "object" ? (value.maximum ?? value.max ?? value.current ?? value.value ?? "") : value;
  const current = value && typeof value === "object" ? (value.current ?? value.current_default ?? value.current_start ?? max) : value;
  return [{
    resource_id: name.toLowerCase().replace(/[^a-z0-9]+/g, "_"),
    resource_name: name,
    name,
    current,
    maximum: max,
    recovery: identity.stamina_formula || identity.qi_formula || identity.resonance_formula || identity.chakra_formula || "",
    tracking_model: "primary_resource_from_identity"
  }];
}


// HF05ZD: display-safe primary resource and SV05 composite projection helpers.
// These prevent shallow legacy rows like {resource: "Stamina"} and missing
// legacy temporal registries from winning over explicit SV05 projection rows.
function resourceDisplayNumber(value) {
  if (value === undefined || value === null) return "";
  if (typeof value === "string") {
    const text = value.trim();
    if (!text) return "";
    // HF05ZE: visual placeholders must not count as resource values.
    if (/^(?:-|—|–|\/|n\/?a|none|null|undefined|unknown|\?|—)$/i.test(text)) return "";
  }
  return value;
}

function resourceEntryHasDisplayValues(resource = {}) {
  if (!resource || typeof resource !== "object") return false;
  return resourceDisplayNumber(resource.current) !== "" ||
    resourceDisplayNumber(resource.current_default) !== "" ||
    resourceDisplayNumber(resource.current_start) !== "" ||
    resourceDisplayNumber(resource.remaining) !== "" ||
    resourceDisplayNumber(resource.maximum) !== "" ||
    resourceDisplayNumber(resource.max) !== "" ||
    resourceDisplayNumber(resource.value) !== "" ||
    resourceDisplayNumber(resource.total) !== "";
}

function resourceDisplayName(resource = {}) {
  return String(resource?.display_name || resource?.resource_name || resource?.resource_id || resource?.name || "").trim();
}

function isPrimaryResourceCandidate(resource = {}) {
  const name = resourceDisplayName(resource).toLowerCase();
  return Boolean(name) && !["hp", "hit points", "reaction", "reactions", "concentration slot"].includes(name);
}

function preferredPathResourceName(sheet = {}, parsed = []) {
  const path = String(sheet?.path || "").toLowerCase();
  if (/body/.test(path)) return "Stamina";
  if (/qi/.test(path)) return "Qi";
  if (/spirit/.test(path)) return "Resonance";
  const surface = (findJsonBlock(parsed, [/^(?:.*[\\/])?Character_Import_Surface\.json$/i, /Character_Import_Surface/i])?.data || {});
  const resource = surface?.resource || surface?.primary_resource_name || surface?.resource_name;
  return typeof resource === "string" ? resource : "";
}

function resourceRowsFromParsedBlocks(parsed = []) {
  const inventory = findJsonBlock(parsed, [/Limited_Resource_Counter_Inventory/i, /limited_resource/i])?.data || {};
  const fromInventory = listFromJsonData(inventory, ["resources", "limited_resources", "counters"]);
  if (fromInventory.length) return fromInventory;
  const direct = [];
  parsed.forEach((block) => {
    const data = block?.data;
    if (!data || typeof data !== "object" || Array.isArray(data)) return;
    if (data.resources && typeof data.resources === "object" && !Array.isArray(data.resources)) {
      direct.push(...resourceEntriesFromMap(data.resources));
    }
  });
  return direct;
}

function choosePrimaryResourceRow(resources = [], preferredName = "") {
  const rows = compactImportList(resources).filter((row) => row && typeof row === "object" && isPrimaryResourceCandidate(row));
  const preferred = String(preferredName || "").toLowerCase();
  const withValues = rows.filter(resourceEntryHasDisplayValues);
  if (preferred) {
    const preferredWithValues = withValues.find((row) => resourceDisplayName(row).toLowerCase() === preferred.toLowerCase());
    if (preferredWithValues) return preferredWithValues;
  }
  return withValues[0] || rows[0] || null;
}

function primaryResourceForDisplay(pkg = {}, sheet = {}) {
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const preferred = preferredPathResourceName(sheet, parsed);
  const sheetChoice = choosePrimaryResourceRow(sheet.resources, preferred);
  const parsedChoice = choosePrimaryResourceRow(resourceRowsFromParsedBlocks(parsed), preferred || resourceDisplayName(sheetChoice));
  // HF05ZE: prefer exact package resource rows with numeric values over compacted
  // legacy rows that may only preserve the label (for example, "Stamina —/—").
  if (parsedChoice && resourceEntryHasDisplayValues(parsedChoice)) return parsedChoice;
  if (sheetChoice && resourceEntryHasDisplayValues(sheetChoice)) return sheetChoice;
  return parsedChoice || sheetChoice || null;
}

function resourceDisplayText(resource = {}) {
  if (!resource || typeof resource !== "object") return "—";
  const name = resource.resource_name || resource.display_name || resource.name || resource.resource_id || "Resource";
  const max = resourceDisplayNumber(resource.maximum) !== "" ? resource.maximum
    : resourceDisplayNumber(resource.max) !== "" ? resource.max
      : resourceDisplayNumber(resource.value) !== "" ? resource.value
        : resourceDisplayNumber(resource.total) !== "" ? resource.total
          : resourceDisplayNumber(resource.current) !== "" ? resource.current
            : resourceDisplayNumber(resource.current_default) !== "" ? resource.current_default
              : resourceDisplayNumber(resource.current_start) !== "" ? resource.current_start
                : resourceDisplayNumber(resource.remaining) !== "" ? resource.remaining : "—";
  const current = resourceDisplayNumber(resource.current) !== "" ? resource.current
    : resourceDisplayNumber(resource.current_default) !== "" ? resource.current_default
      : resourceDisplayNumber(resource.current_start) !== "" ? resource.current_start
        : resourceDisplayNumber(resource.remaining) !== "" ? resource.remaining : max;
  return `${name} ${current}/${max}`;
}

function sv05CompositeLineText(lines = [], fallback = "") {
  const list = compactImportList(lines).map(asDisplayText).filter(Boolean);
  return list.length ? list.join(" / ") : fallback;
}

function sv05CompositeRoleSpecificLine(item = {}) {
  const role = String(item.execution_role || item.priority || item.gm_screen_category || "").toLowerCase();
  if (/reaction/.test(role)) return sv05CompositeLineText(item.reaction_lines, "Use only when the listed reaction trigger, state, and resource windows are live.");
  if (/opener/.test(role)) return sv05CompositeLineText(item.opener_lines, "Use to begin a pressure sequence when the listed setup action and resource window are legal.");
  if (/finisher/.test(role)) return sv05CompositeLineText(item.finisher_lines, "Use only after the listed setup states exist; otherwise select a fallback line.");
  if (/fallback/.test(role)) return sv05CompositeLineText(item.fallback_lines, "Use when the preferred pressure line is illegal, broken, or resource-blocked.");
  if (/control/.test(role)) return sv05CompositeLineText(item.opener_lines || item.fallback_lines, "Use to maintain legal contact/control states and reset pressure.");
  return sv05CompositeLineText(item.opener_lines || item.reaction_lines || item.finisher_lines || item.fallback_lines, "Use when the listed SV05 projection contract is live.");
}

function sv05CompositeTimingText(item = {}) {
  if (!item || typeof item !== "object") return "";
  const temporal = item.temporal_feasibility || item.hf05b3h_temporal || item.temporal;
  if (typeof temporal === "object" && temporal) {
    const bits = [temporal.legal_sequence, temporal.window_order, temporal.action_economy_statement].map(asDisplayText).filter(Boolean);
    if (bits.length) return bits.join(" ");
  }
  return asDisplayText(item.temporal_feasibility_summary || item.timing || item.timing_window || item.activation_timing || item.turn_timing || item.when_to_use || item.window || item.when);
}

function entryDisplayName(item) {
  if (typeof item === "string") return polishMachineReadableText(item);
  if (!item || typeof item !== "object") return "";
  const sourceName = item.source_refs?.[0]?.source_name || item.source_name || item.source || "";
  const raw = item.display_name || item.name || item.item_name || item.manual_name || item.style_name || item.feature_name || item.option_name || item.action_name || item.passive_name || item.asset_name || item.entry_name || item.entry_id || item.sphere || "";
  const rawText = String(raw || "").replace(/\s+Sphere Base$/i, "").trim();
  const noisySource = /martial[_\s-]*manual[_\s-]*form|manual[_\s-]*form|hf0\d|expression[_\s-]*ready/i;
  if (/^Sphere of /i.test(sourceName) && !rawText && !noisySource.test(sourceName)) return sourceName.replace(/^Sphere of /i, "").trim();
  return polishMachineReadableText(rawText || String(sourceName || "").replace(/^Sphere of\s+/i, "").trim());
}

function namedEntries(items) {
  return listFromJsonData(items).map(entryDisplayName).filter(Boolean);
}

function cleanPackageSphereNames(items) {
  const ignored = /^(?:ability|speed|incompatible by default|none|unparsed|not recorded)$/i;
  const names = namedEntries(items).filter((name) => !ignored.test(String(name).trim()));
  const merged = names.includes("Harvesting") && names.includes("Gathering")
    ? names.filter((name) => name !== "Harvesting" && name !== "Gathering").concat("Harvesting Gathering")
    : names;
  return [...new Set(merged)];
}

function firstAvailableList(...candidates) {
  for (const candidate of candidates) {
    const list = Array.isArray(candidate) ? candidate : [];
    if (list.length) return list;
  }
  return [];
}

// HF05F: imported packages may contain sparse arrays/null placeholders from
// partial registries, markdown projections, or stale localStorage state.
// UI/automation renderers must never assume every array slot is an object.
function compactImportList(items = []) {
  return Array.isArray(items)
    ? items.filter((item) => item !== null && item !== undefined && item !== "")
    : [];
}

function safeDetail(detail, fallbackTitle = "Entry") {
  if (typeof detail === "string") return { title: asDisplayText(detail || fallbackTitle), body: "" };
  if (!detail || typeof detail !== "object") return { title: asDisplayText(fallbackTitle), body: "" };
  return {
    title: asDisplayText(detail.title || detail.name || fallbackTitle),
    body: asDisplayText(detail.body || "")
  };
}


// v1.11.0-HF05A display-alias support.
// Legal talent names remain system-facing; action/manual/macro UI may prefer aliases.
const HF05A_DISPLAY_ALIAS_FIELDS = [
  "manual_form_name",
  "script_display_name",
  "dashboard_display_label",
  "source_display_expression",
  "display_alias",
  "macro_label",
  "display_label",
  "source_alias",
  "source_technique_name",
  "technique_display_name",
  "form_display_name"
];

function cleanHf05aDisplayText(value) {
  const text = String(value || "")
    .replace(/^Sphere of\s+/i, "")
    .replace(/\s+/g, " ")
    .trim();
  const noisy = /^(?:martial[_\s-]*manual[_\s-]*form|manual[_\s-]*form|source[_\s-]*conversion|v?1[_\s.-]*11|hf0\d|hf05a|expression[_\s-]*ready|legal[_\s-]*talent[_\s-]*display[_\s-]*alias)$/i;
  return text && !noisy.test(text) ? text : "";
}

function firstHf05aAlias(item = {}) {
  if (!item || typeof item !== "object") return "";
  for (const field of HF05A_DISPLAY_ALIAS_FIELDS) {
    const value = cleanHf05aDisplayText(item[field]);
    if (value) return value;
  }
  return "";
}

function firstHf05aAliasList(item = {}) {
  if (!item || typeof item !== "object") return [];
  const out = [];
  for (const field of HF05A_DISPLAY_ALIAS_FIELDS) {
    const value = cleanHf05aDisplayText(item[field]);
    if (value && !out.includes(value)) out.push(value);
  }
  return out;
}

function legalAuditDisplayName(item = {}) {
  if (!item || typeof item !== "object") return "";
  const sphere = cleanHf05aDisplayText(item.legal_tianxia_sphere || item.legal_sphere || item.sphere);
  const func = cleanHf05aDisplayText(item.legal_talent_function || item.legal_talent_name || item.legal_function || item.talent_function);
  const explicit = cleanHf05aDisplayText(item.legal_name_for_audit || item.legal_display_name || item.legal_name);
  if (explicit) return explicit;
  return [sphere, func].filter(Boolean).join(" — ");
}

function preferredActionDisplayName(item = {}, fallback = "") {
  if (!item || typeof item !== "object") return cleanHf05aDisplayText(fallback) || "";
  return firstHf05aAlias(item)
    || cleanHf05aDisplayText(item?.display_name)
    || cleanHf05aDisplayText(item?.action_name)
    || cleanHf05aDisplayText(item?.name)
    || cleanHf05aDisplayText(item?.option_name)
    || cleanHf05aDisplayText(fallback)
    || "";
}

function actionRegistryId(item = {}) {
  return String(item?.action_id || item?.id || item?.actionId || item?.registry_id || "").trim();
}

function scriptRegistryId(item = {}) {
  return String(item?.script_id || item?.id || item?.scriptId || "").trim();
}

function talentNumberKey(item = {}) {
  const value = item?.talent_number ?? item?.talent_slot ?? item?.slot ?? item?.talent_id ?? "";
  return String(value || "").trim();
}

function hf05aScriptRowsFromRegistry(data = {}) {
  const rows = firstAvailableList(
    listFromJsonData(data, ["scripts", "action_execution_scripts", "execution_scripts", "registry", "entries", "actions"]),
    data && typeof data === "object" && !Array.isArray(data) && (data.script_id || data.action_id || data.legal_name_for_audit) ? [data] : []
  );
  return rows.filter((row) => row && typeof row === "object");
}

function hf05aAliasRowsFromAudit(data = {}) {
  if (!data || typeof data !== "object") return [];
  return firstAvailableList(
    listFromJsonData(data, ["rows", "talent_rows", "legal_talent_rows", "aliases", "entries", "registry", "talents"]),
    data.row && typeof data.row === "object" ? [data.row] : [],
    data.talent_number || data.legal_tianxia_sphere || data.legal_talent_function ? [data] : []
  ).filter((row) => row && typeof row === "object");
}

function mergeHf05aActionScripts(actions = [], scripts = []) {
  if (!Array.isArray(actions) || !actions.length || !Array.isArray(scripts) || !scripts.length) return actions;
  const byActionId = new Map();
  const byName = new Map();
  for (const script of scripts) {
    const actionId = String(script.action_id || script.linked_action_id || "").trim();
    if (actionId) byActionId.set(actionId, script);
    const legal = techniqueKey(legalAuditDisplayName(script));
    if (legal) byName.set(legal, script);
  }
  return actions.map((action) => {
    if (!action || typeof action !== "object") return action;
    const id = actionRegistryId(action);
    const actionLegal = techniqueKey(legalAuditDisplayName(action) || action?.action_name || action?.name || action?.display_name);
    const script = (id && byActionId.get(id))
      || (actionLegal && byName.get(actionLegal))
      || null;
    if (!script) return action;
    const alias = firstHf05aAlias(script);
    return {
      ...action,
      hf05a_script_id: scriptRegistryId(script),
      hf05a_display_aliases: firstHf05aAliasList(script),
      legal_name_for_audit: action.legal_name_for_audit || script.legal_name_for_audit,
      legal_tianxia_sphere: action.legal_tianxia_sphere || script.legal_tianxia_sphere,
      legal_talent_function: action.legal_talent_function || script.legal_talent_function,
      script_display_name: action.script_display_name || script.script_display_name,
      source_display_expression: action.source_display_expression || script.source_display_expression,
      display_alias: action.display_alias || script.display_alias || alias,
      macro_label: action.macro_label || script.macro_label,
      dashboard_display_label: action.dashboard_display_label || script.dashboard_display_label,
      result_mode_overlay: action.result_mode_overlay || script.result_mode_overlay,
      hf05a_script: script
    };
  });
}

function mergeHf05aTalentAliases(talents = [], scripts = [], auditRows = []) {
  if (!Array.isArray(talents) || !talents.length) return talents;
  const byTalentNumber = new Map();
  const rows = [...(Array.isArray(auditRows) ? auditRows : []), ...(Array.isArray(scripts) ? scripts : [])];
  for (const row of rows) {
    const key = talentNumberKey(row);
    if (key && !byTalentNumber.has(key)) byTalentNumber.set(key, row);
  }
  return talents.map((talent, index) => {
    const base = typeof talent === "object" && talent !== null ? talent : { name: String(talent || "") };
    const key = talentNumberKey(base) || String(index + 1);
    const row = byTalentNumber.get(key);
    if (!row) return talent;
    const legal = legalAuditDisplayName(row);
    return {
      ...base,
      hf05a_aliases: firstHf05aAliasList(row),
      legal_name_for_audit: base.legal_name_for_audit || legal,
      legal_tianxia_sphere: base.legal_tianxia_sphere || row.legal_tianxia_sphere,
      legal_talent_function: base.legal_talent_function || row.legal_talent_function,
      script_display_name: base.script_display_name || row.script_display_name,
      source_display_expression: base.source_display_expression || row.source_display_expression,
      macro_label: base.macro_label || row.macro_label,
      display_alias: base.display_alias || row.display_alias
    };
  });
}

function normalizeManualMarkdownText(value = "") {
  return String(value || "")
    .replace(/\*\*/g, "")
    .replace(/`/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\.$/, "");
}

function manualMarkdownFieldKey(label = "") {
  const text = String(label || "").toLowerCase().replace(/&/g, " and ");
  if (/^type$|economy|action type/.test(text)) return "type";
  if (/^cost/.test(text)) return "cost";
  if (/^source/.test(text)) return "source";
  if (/use condition/.test(text)) return "use_condition";
  if (/^trigger/.test(text)) return "trigger";
  if (/roll|save|contest|attack/.test(text)) return "roll_save";
  if (/^effect/.test(text)) return "effect";
  if (/^duration/.test(text)) return "duration";
  if (/opportunity/.test(text)) return "opportunity_attacks";
  if (/^limits?/.test(text)) return "limit";
  if (/requirement/.test(text)) return "requirements";
  return text.replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

function parseManualMarkdownBullets(body = "") {
  const fields = {};
  const lines = String(body || "").split(/\r?\n/);
  let currentKey = "";
  for (const line of lines) {
    const bullet = line.match(/^\s*-\s+\*\*([^*]+):\*\*\s*(.*)$/);
    if (bullet) {
      currentKey = manualMarkdownFieldKey(bullet[1]);
      if (!currentKey) continue;
      fields[currentKey] = normalizeManualMarkdownText(bullet[2]);
      continue;
    }
    if (currentKey && /^\s{2,}\S/.test(line)) {
      fields[currentKey] = normalizeManualMarkdownText(`${fields[currentKey] || ""} ${line.trim()}`);
    }
  }
  return fields;
}

function manualMarkdownSummary(body = "") {
  const beforeForms = String(body || "").split(/^##\s+\d+\./m)[0] || "";
  return normalizeManualMarkdownText(
    beforeForms
      .split(/\n{2,}/)
      .map((part) => part.trim())
      .filter((part) => part && !/^---+$/.test(part))[0] || ""
  );
}

function sourceRouteChipsFromText(value = "") {
  const raw = String(value || "")
    .replace(/—/g, ";")
    .replace(/[()]/g, " ")
    .split(/[;,/+]|\band\b|\bplus\b/i)
    .map((item) => item.replace(/\b(?:talent|route|form|source|mechanic|mechanics|fixed manual|universal|forged technique)\b/gi, "").trim())
    .filter(Boolean);
  const blocked = /^(?:not full|if active|body-refining palm entry|learned forged sequence|response|rider|ward|gap|null|seal|meld|black vein|hollow|void domain|athletics movement bridge|wrestling bridge)$/i;
  return [...new Set(raw.filter((item) => !blocked.test(item)))].slice(0, 8);
}

function parseManualMarkdownForms(manualBody = "") {
  const matches = [...String(manualBody || "").matchAll(/^##\s+(\d+)\.\s+(.+?)\s*$/gm)];
  return matches.map((match, index) => {
    const formNumber = Number(match[1]);
    const formName = normalizeManualMarkdownText(match[2]);
    const start = match.index + match[0].length;
    const end = matches[index + 1]?.index ?? manualBody.length;
    const body = manualBody.slice(start, end);
    const fields = parseManualMarkdownBullets(body);
    const triggerOrUse = fields.trigger || fields.use_condition || "";
    const effect = fields.effect || fields.resolution || "";
    const source = fields.source || "";
    return {
      form_id: `markdown-manual-form-${formNumber}-${techniqueKey(formName)}`,
      form_number: formNumber,
      name: formName,
      display_name: formName,
      timing: fields.type || "Manual form",
      type: fields.type || "Manual form",
      action_type: fields.type || "Manual form",
      cost: fields.cost || "",
      source,
      sphere_source: source,
      associated_spheres: sourceRouteChipsFromText(source),
      trigger: fields.trigger || "",
      use_condition: fields.use_condition || "",
      attack_or_save: fields.roll_save || "",
      roll_save: fields.roll_save || "",
      effect_summary: effect,
      description: effect,
      resolution: effect,
      duration: fields.duration || "",
      opportunity_attacks: fields.opportunity_attacks || "",
      limit: fields.limit || "",
      requirements: fields.requirements || "",
      markdown_derived: true,
      raw_markdown: body.trim()
    };
  });
}

function parseMartialManualMarkdown(source = "") {
  const text = String(source || "");
  const matches = [...text.matchAll(/^#\s+Manual\s+([IVXLCDM0-9]+)\s+[—-]\s+(.+?)\s*$/gmi)];
  return matches.map((match, index) => {
    const roman = match[1];
    const name = normalizeManualMarkdownText(match[2]);
    const start = match.index + match[0].length;
    const removedIndex = text.search(/^#\s+Removed\s+\/\s+deprecated/im);
    const end = matches[index + 1]?.index ?? (removedIndex >= 0 ? removedIndex : text.length);
    const body = text.slice(start, end);
    const manualForms = parseManualMarkdownForms(body);
    const associatedSpheres = [...new Set(manualForms.flatMap((form) => Array.isArray(form.associated_spheres) ? form.associated_spheres : []))].slice(0, 10);
    const noGrant = /do\s+not\s+grant\s+full|does\s+not\s+grant\s+full|do\s+not\s+grant\s+sphere|does\s+not\s+grant\s+sphere/i.test(body);
    return {
      manual_id: `markdown-manual-${techniqueKey(name)}`,
      name,
      display_name: name,
      style_name: name,
      manual_ordinal: roman,
      status: "learned",
      source_status: "Markdown-derived from Martial_Arts_and_Manuals.md",
      source_or_teacher: "Martial_Arts_and_Manuals.md",
      summary: manualMarkdownSummary(body),
      routes_or_spheres: associatedSpheres,
      associated_spheres: associatedSpheres,
      manual_forms: manualForms,
      forms: manualForms,
      techniques: manualForms,
      grants_spheres: false,
      does_not_grant_sphere_or_talent: noGrant,
      markdown_derived: true
    };
  }).filter((manual) => Array.isArray(manual.manual_forms) && manual.manual_forms.length);
}

function martialManualMarkdownDetails(blocks = []) {
  const source = blocks.find((block) => /martial_arts_and_manuals\.md$/i.test(block.name || ""))?.content || "";
  if (!source) return {};
  const details = source.split(/^##\s+/m).slice(1).reduce((acc, section) => {
    const [heading = "", ...body] = section.split(/\r?\n/);
    const name = heading.trim();
    const content = body.join("\n");
    if (!name) return acc;
    const techniques = content.match(/\*\*Associated Techniques:\*\*\s*([^\n]+)/i)?.[1]
      ?.split(",")
      .map((item) => item.trim())
      .filter(Boolean) || [];
    if (techniques.length) acc[name.toLowerCase()] = { associated_techniques: techniques };
    return acc;
  }, {});
  const markdownManuals = parseMartialManualMarkdown(source);
  if (markdownManuals.length) {
    details.__markdown_manuals = markdownManuals;
    for (const manual of markdownManuals) {
      details[String(manual.name || "").toLowerCase()] = {
        ...(details[String(manual.name || "").toLowerCase()] || {}),
        ...manual
      };
    }
  }
  return details;
}


function simpleMartialManualMarkdownList(blocks = []) {
  const source = blocks.find((block) => /martial_arts_and_manuals\.md$/i.test(block.name || ""))?.content || "";
  if (!source) return [];
  if (/^#\s+Manual\s+/im.test(source)) return [];
  const bodyText = source.replace(/^#\s+Martial Arts and Manuals\s*/i, "").trim();
  const summary = manualMarkdownSummary(bodyText) || "Manual/source record. No individual forms were declared in this package.";
  return [...source.matchAll(/^\s*\d+\.\s+(.+?)\s*$/gmi)]
    .map((match, index) => {
      const name = normalizeManualMarkdownText(match[1]);
      if (!name || /manuals grant no source sphere/i.test(name)) return null;
      const spheres = sourceRouteChipsFromText(name);
      return {
        manual_id: `markdown-simple-manual-${index + 1}-${techniqueKey(name)}`,
        name,
        display_name: name,
        style_name: name,
        manual_ordinal: String(index + 1),
        status: "learned",
        source_status: "Markdown-derived from Martial_Arts_and_Manuals.md",
        source_or_teacher: "Martial_Arts_and_Manuals.md",
        summary,
        routes_or_spheres: spheres,
        associated_spheres: spheres,
        manual_forms: [],
        forms: [],
        techniques: [],
        grants_spheres: false,
        does_not_grant_sphere_or_talent: /do not grant|grant no source sphere/i.test(source),
        markdown_derived: true,
        list_derived: true
      };
    })
    .filter(Boolean);
}

function enrichMartialArtEntries(entries = [], markdownDetails = {}) {
  const markdownManuals = Array.isArray(markdownDetails.__markdown_manuals) ? markdownDetails.__markdown_manuals : [];
  if ((!Array.isArray(entries) || !entries.length) && markdownManuals.length) return markdownManuals;
  return entries.map((item) => {
    if (!item || typeof item !== "object") return item;
    const name = String(item.name || item.manual_name || item.style_name || "").trim().toLowerCase();
    const details = markdownDetails[name];
    if (!details) return item;
    const hasForms = martialManualFormCount(item) > 0;
    const hasAssociated = Array.isArray(item.associated_techniques) && item.associated_techniques.length;
    if (hasForms && hasAssociated) return item;
    return { ...details, ...item, manual_forms: hasForms ? martialManualForms(item) : details.manual_forms || details.forms || [], forms: hasForms ? martialManualForms(item) : details.forms || details.manual_forms || [] };
  });
}

function martialManualForms(item = {}) {
  if (!item || typeof item !== "object") return [];
  const candidates = [
    item.manual_forms,
    item.forms,
    item.techniques,
    item.learned_forms,
    item.linked_forms,
    item.actions,
    item.entries
  ];
  for (const candidate of candidates) {
    if (Array.isArray(candidate) && compactImportList(candidate).length) return compactImportList(candidate);
  }
  return [];
}

function martialManualFormCount(item = {}) {
  return martialManualForms(item).length;
}

function martialArtListCompleteness(entries = []) {
  if (!Array.isArray(entries) || !entries.length) return -1;
  return entries.reduce((score, entry) => {
    if (typeof entry === "string") return score + 1;
    if (!entry || typeof entry !== "object") return score;
    return score
      + 2
      + (martialManualFormCount(entry) * 20)
      + (Array.isArray(entry.associated_techniques) ? entry.associated_techniques.length * 2 : 0)
      + (entry.doctrine ? 1 : 0)
      + (entry.source_or_teacher ? 1 : 0);
  }, 0);
}

function richestMartialArtList(...candidates) {
  return candidates
    .filter((candidate) => Array.isArray(candidate) && candidate.length)
    .sort((left, right) => martialArtListCompleteness(right) - martialArtListCompleteness(left))[0] || [];
}

function foundationListCompleteness(entries = []) {
  if (!Array.isArray(entries) || !entries.length) return -1;
  return entries.reduce((score, entry) => {
    if (!entry || typeof entry !== "object") return score + 1;
    const foundationName = String(entry.name || entry.foundation_name || "").trim();
    const placeholderPenalty = /^see\s+foundation[_\s-]*record/i.test(foundationName) || /^foundation$/i.test(foundationName) ? -100 : 0;
    const catalogNumber = Number(entry.catalog_number ?? entry.catalogue_number ?? entry.number);
    return score
      + 2
      + (foundationName && !/^foundation$/i.test(foundationName) ? 3 : 0)
      + (Number.isFinite(catalogNumber) ? 50 : 0)
      + (entry.catalog_enriched ? 20 : 0)
      + (entry.dao_principle ? 4 : 0)
      + (entry.origin ? 2 : 0)
      + (entry.known_player_text ? 4 : 0)
      + (Array.isArray(entry.compatible_spheres) && entry.compatible_spheres.length ? 6 : 0)
      + (Array.isArray(entry.mechanical_permissions) ? entry.mechanical_permissions.length * 5 : 0)
      + (Array.isArray(entry.explicit_non_permissions) ? entry.explicit_non_permissions.length * 3 : 0)
      + placeholderPenalty;
  }, 0);
}

function richestFoundationList(...candidates) {
  return candidates
    .filter((candidate) => Array.isArray(candidate) && candidate.length)
    .sort((left, right) => foundationListCompleteness(right) - foundationListCompleteness(left))[0] || [];
}

function foundationCatalogRecordForEntry(entry = {}) {
  if (!entry || typeof entry !== "object") return null;
  const rawKeys = [entry.id, entry.catalog_id, entry.foundation_id, entry.name, entry.foundation_name, entry.formal_name]
    .map((value) => String(value || "").trim().toLowerCase())
    .filter(Boolean);
  const directKeys = rawKeys.map((value) => foundationCatalogKey(value)).filter(Boolean);
  for (const raw of rawKeys) {
    const byName = FOUNDATION_CATALOG_BY_NAME.get(raw);
    if (byName) return byName;
    const byIdRaw = FOUNDATION_CATALOG_BY_ID.get(raw);
    if (byIdRaw) return byIdRaw;
  }
  for (const key of directKeys) {
    const byId = FOUNDATION_CATALOG_BY_ID.get(key);
    if (byId) return byId;
    const byName = FOUNDATION_CATALOG_BY_NAME.get(key);
    if (byName) return byName;
  }
  const catalogNumber = Number(entry.catalog_number ?? entry.catalogue_number ?? entry.number);
  if (Number.isFinite(catalogNumber)) {
    const byNumber = FOUNDATION_CATALOG.find((item) => Number(item.catalog_number) === catalogNumber);
    if (byNumber) return byNumber;
  }
  return null;
}

function mergeFoundationCatalogEntry(entry = {}) {
  if (!entry || typeof entry !== "object") return entry;
  const catalog = foundationCatalogRecordForEntry(entry);
  if (!catalog) return entry;
  const compatibility = catalog.compatibility || {};
  return {
    ...catalog,
    compatibility: { ...(catalog.compatibility || {}), ...(entry.compatibility || {}) },
    ...entry,
    name: entry.name || entry.foundation_name || catalog.name,
    family: entry.family || entry.foundation_family || catalog.family,
    depth: entry.depth || catalog.depth,
    stage: entry.stage || catalog.stage,
    origin: entry.origin || catalog.origin,
    dao_principle: entry.dao_principle || catalog.dao_principle,
    known_player_text: { ...(catalog.known_player_text || {}), ...(entry.known_player_text || {}) },
    compatible_spheres: entry.compatible_spheres || compatibility.compatible_spheres,
    strained_spheres: entry.strained_spheres || compatibility.strained_spheres,
    incompatible_spheres: entry.incompatible_spheres || compatibility.incompatible_spheres,
    foundation_catalogue_status: entry.foundation_catalogue_status || entry.status || "catalog-found",
    catalog_enriched: true
  };
}

function normalizeFoundationEntry(entry) {
  if (!entry || typeof entry !== "object") return entry;
  const originalName = String(entry.name || entry.foundation_name || "").trim();
  const correction = FOUNDATION_IMPORT_CORRECTIONS[originalName.toLowerCase()];
  const corrected = correction ? {
    ...entry,
    name: correction.name,
    legacy_name: originalName,
    import_correction: correction.note
  } : entry;
  return mergeFoundationCatalogEntry(corrected);
}

function normalizeFoundationEntries(entries) {
  return Array.isArray(entries) ? entries.map(normalizeFoundationEntry) : [];
}

function savedLinkedAsEntries(items = []) {
  if (!Array.isArray(items)) return [];
  return items.map((item) => ({
    name: item.name || "Unnamed",
    status: item.status || "",
    notes: item.notes || "",
    source: "Dashboard note"
  }));
}

function mobileAbilityMap(group = {}, field = "final") {
  if (!group || typeof group !== "object") return {};
  return Object.entries(group).reduce((acc, [key, value]) => {
    if (value === null || value === undefined || value === "") return acc;
    if (typeof value === "object") {
      const picked = value[field] ?? value.value ?? value.score ?? value.total ?? value.bonus;
      if (picked !== undefined && picked !== null && picked !== "") acc[key] = picked;
      return acc;
    }
    acc[key] = value;
    return acc;
  }, {});
}

function abilityScoreRecord(value) {
  const mapped = mobileAbilityMap(value, "final");
  return ABILITY_ROWS.some((ability) => abilityField(mapped, ability) !== undefined) ? mapped : {};
}

function normalizeHpRecord(value) {
  if (value === null || value === undefined || value === "") return {};
  if (typeof value === "object") {
    return {
      ...value,
      maximum: value.maximum ?? value.max ?? value.hp_max,
      current: value.current ?? value.current_start ?? value.hp_current ?? value.maximum ?? value.max ?? value.hp_max
    };
  }
  return { current: value, maximum: value };
}

function normalizeAcRecord(value) {
  if (value === null || value === undefined || value === "") return {};
  if (typeof value === "object") {
    const base = value.base ?? value.baseline ?? value.normal ?? value.ac_base ?? value.ac ?? value.armor_class ?? value.value;
    const current = value.current ?? value.active ?? value.liming_radiant_gown ?? value.ac_active ?? value.ac_alt ?? value.baseline ?? base;
    return {
      ...value,
      base,
      current
    };
  }
  return { current: value, base: value };
}

function levelFromText(value) {
  const match = String(value || "").match(/\bCL\s*(\d+)\b/i);
  return match ? Number(match[1]) : "";
}

function levelValue(value) {
  if (typeof value === "number" || typeof value === "string") return value;
  if (!value || typeof value !== "object") return "";
  return value.CL ?? value.cl ?? value.level ?? value.cultivation_level ?? "";
}

function bonusMapFromRecord(record, abilityKeys = false) {
  if (!record || typeof record !== "object") return {};
  return Object.entries(record).reduce((acc, [key, value]) => {
    const label = abilityKeys
      ? abilityShortName(key) || key.toUpperCase()
      : key.split("_").map(titleCase).join(" ");
    if (typeof value === "number") acc[label] = value;
    else if (value && typeof value === "object") {
      const bonus = value.bonus ?? value.total ?? value.value ?? value.mod ?? value.modifier;
      if (bonus !== undefined && bonus !== null && bonus !== "") acc[label] = bonus;
    }
    return acc;
  }, {});
}

function savesFromProficiencyList(savingThrows, modifiers = {}, proficiencyBonus = 0) {
  if (!Array.isArray(savingThrows)) return {};
  const pb = Number(proficiencyBonus) || 0;
  return savingThrows.reduce((acc, ability) => {
    const key = abilityShortName(ability) || String(ability || "").toUpperCase();
    if (!key) return acc;
    const modifier = Number(abilityField(modifiers, key));
    acc[key] = (Number.isFinite(modifier) ? modifier : 0) + pb;
    return acc;
  }, {});
}

function saveBonusMap(value) {
  if (!Array.isArray(value)) return bonusMapFromRecord(value, true);
  return value.reduce((acc, item) => {
    if (!item || typeof item !== "object") return acc;
    const ability = abilityShortName(item.ability || item.name || item.save) || String(item.ability || item.name || item.save || "").toUpperCase();
    const bonus = item.bonus ?? item.total ?? item.value ?? item.modifier;
    if (ability && bonus !== undefined && bonus !== null && bonus !== "") acc[ability] = bonus;
    return acc;
  }, {});
}

function skillBonusMap(value, proficiencies = [], expertise = []) {
  const known = {};
  const proficientSet = new Set((Array.isArray(proficiencies) ? proficiencies : []).map((item) => String(item).trim()).filter(Boolean));
  const expertiseSet = new Set((Array.isArray(expertise) ? expertise : []).map((item) => String(item).trim()).filter(Boolean));
  const register = (rawName, rawValue, item = {}) => {
    const name = String(rawName || "").trim();
    if (!name) return;
    const bonus = typeof rawValue === "number" ? rawValue : rawValue?.bonus ?? rawValue?.total ?? rawValue?.value ?? item.bonus ?? item.total ?? item.value;
    if (bonus !== undefined && bonus !== null && bonus !== "") known[name] = bonus;
    else if (item.expertise || expertiseSet.has(name)) known[name] = "Expertise";
    else if (item.proficient || proficientSet.has(name)) known[name] = "Proficient";
    else known[name] = "Known";
  };

  if (Array.isArray(value)) {
    value.forEach((item) => {
      if (typeof item === "string") register(item, undefined, {});
      else if (item && typeof item === "object") register(item.skill || item.name || item.label, item, item);
    });
  } else if (value && typeof value === "object") {
    Object.entries(value).forEach(([name, item]) => register(name, item, item && typeof item === "object" ? item : {}));
  }

  proficientSet.forEach((name) => { if (!known[name]) register(name, undefined, { proficient: true }); });
  expertiseSet.forEach((name) => { register(name, known[name], { expertise: true }); });
  return known;
}

function talentLine(item) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  const bits = [
    item.display_name || item.name || item.feature_name || item.option_name || "Unnamed",
    item.slot ? `[${item.slot}]` : "",
    item.sphere ? `sphere: ${item.sphere}` : "",
    item.status ? `status: ${item.status}` : "",
    item.source ? `source: ${item.source}` : item.source_name ? `source: ${item.source_name}` : "",
    item.intent || item.effect || item.summary || item.description || ""
  ].filter(Boolean);
  return bits.join(" ");
}

function resourceLine(item) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Resource: tracked";
  const name = item.display_name || item.resource_name || item.resource_id || item.resource_key || item.name || "Resource";
  const current = item.current ?? item.current_default ?? item.current_start ?? item.start ?? item.opening;
  const max = item.maximum ?? item.max;
  const amount = max !== undefined ? `${current ?? max}/${max}` : asDisplayText(current);
  const recovery = item.recovery || item.reset_cadence || item.resolution_basis;
  return `${name}: ${amount || "tracked"}${recovery ? ` (${asDisplayText(recovery)})` : ""}`;
}

function weaponLine(item) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Attack";
  const parts = [
    item.name || "Attack",
    item.attack_bonus !== undefined ? `+${item.attack_bonus}` : "",
    item.damage || item.damage_or_effect || "",
    item.range ? `range ${item.range}` : "",
    Array.isArray(item.properties) && item.properties.length ? `[${item.properties.join(", ")}]` : ""
  ].filter(Boolean);
  return parts.join(" | ");
}

function speedDisplay(value) {
  if (!value) return "";
  if (typeof value !== "object") {
    const text = String(value).trim();
    return /\bft\b|feet|fly|swim|climb|burrow/i.test(text) ? text : `${text} ft`;
  }
  const entries = [];
  Object.entries(value).forEach(([key, entry]) => {
    if (Array.isArray(entry)) {
      entry.map(asDisplayText).filter(Boolean).forEach((text) => entries.push(text));
      return;
    }
    if (entry === null || entry === undefined || entry === "" || Number(entry) === 0) return;
    entries.push(`${titleCase(key)} ${entry} ft`);
  });
  return entries.join(", ");
}

function passiveLine(item) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Passive";
  const name = item.display_name || item.passive_name || item.name || item.feature_name || "Passive";
  const effect = item.effect || item.summary || item.description || item.mechanics || "";
  const source = item.source_name || item.source || "";
  return [name, effect, source ? `source: ${source}` : ""].filter(Boolean).join(" | ");
}

function assetLine(item) {
  if (typeof item === "string") return asDisplayText(item);
  if (!item || typeof item !== "object") return "Controlled Asset";
  const name = item.display_name || item.asset_name || item.name || item.companion_name || "Controlled Asset";
  const type = item.asset_type || item.type || item.category || "";
  const rule = item.command_rule || item.control_rule || item.mechanics || item.summary || item.destruction_or_loss || "";
  return [name, type, rule].map(asDisplayText).filter(Boolean).join(" | ");
}

function actionSortScore(action) {
  const name = String(action?.display_name || action?.action_name || action?.name || "").toLowerCase();
  const basic = /^(dash|disengage|dodge|help|hide|influence|ready|search|study|utilize|cultivation session)/.test(name);
  const offensive = /(attack|strike|shot|slash|fang|wave|bind|guard|counter|technique|arrow|blade|sword|qi|shadow|spirit|burst|blast|throw|grapple|shove)/.test(name);
  return (basic ? 20 : 0) + (offensive ? -10 : 0) + name.length / 1000;
}

function damageInstancesText(instances) {
  if (!Array.isArray(instances) || !instances.length) return "";
  return instances.map((instance) => {
    if (typeof instance === "string") return asDisplayText(instance);
    const amount = instance.formula || instance.damage || instance.dice || instance.amount || "";
    const type = instance.damage_type ? `${asDisplayText(instance.damage_type)} damage` : "";
    const kind = instance.packet_type || instance.type || "";
    return [
      amount || instance.effect || instance.description || "",
      amount ? type : "",
      kind && kind !== "damage" ? asDisplayText(kind) : "",
      instance.packet_count && instance.packet_count !== 1 ? `x${instance.packet_count}` : ""
    ].map(asDisplayText).filter(Boolean).join(" ");
  }).filter(Boolean).join("; ");
}

function actionLine(action) {
  const targeting = action.targeting || {};
  const resolution = action.resolution || {};
  const duration = action.duration || {};
  const name = action.display_name || action.action_name || action.name || action.option_name || "Unnamed Action";
  const type = action.action_type || action.type || action.action_economy || action.event_pattern?.action_economy_slot || "";
  const cost = asDisplayText(action.cost || action.resource_spent);
  const range = action.range_or_reach || action.range || targeting.range_or_reach || targeting.range || "";
  const target = action.target_rule || action.target || targeting.target_rule || targeting.target || "";
  const attackSave = asDisplayText(action.attack_or_save) || asDisplayText(resolution.attack_or_save) || asDisplayText(resolution.attack_or_save_summary) || asDisplayText(resolution.legacy_attack_or_save) || (action.save_ability ? `${action.save_ability} save` : "");
  const roll = [
    attackSave,
    (resolution.attack_bonus ?? action.attack_bonus) !== undefined && (resolution.attack_bonus ?? action.attack_bonus) !== null ? `+${resolution.attack_bonus ?? action.attack_bonus}` : "",
    (resolution.save_dc ?? action.save_dc) ? `DC ${resolution.save_dc ?? action.save_dc}` : ""
  ].filter(Boolean).join("; ");
  const damageText = damageInstancesText(resolution.damage_instances || action.damage_instances || action.effect_packets);
  const effects = Array.isArray(resolution.effects) ? resolution.effects : action.effects || action.effect_packets;
  const effectsText = Array.isArray(effects) ? effects.filter(Boolean).join("; ") : "";
  const effect = asDisplayText(action.damage_or_effect) || damageText || effectsText || asDisplayText(resolution.legacy_effect_display) || asDisplayText(resolution.authoritative_source_text);
  const durationText = asDisplayText(duration.display || duration);
  const tags = Array.isArray(action.tags) && action.tags.length ? ` [${action.tags.map(asDisplayText).join(", ")}]` : "";
  return [
    `- ${asDisplayText(name)}${tags}`,
    type ? `  Type: ${asDisplayText(type)}` : null,
    cost ? `  Cost: ${cost}` : null,
    range || target ? `  Target: ${[range && `range ${asDisplayText(range)}`, target && `target ${asDisplayText(target)}`].filter(Boolean).join("; ")}` : null,
    roll ? `  Roll: ${roll}` : null,
    effect ? `  Effect: ${effect}${damageText && effect !== damageText ? ` (${damageText})` : ""}` : null,
    durationText ? `  Duration: ${durationText}` : null
  ].filter(Boolean).join("\n");
}



// HF05Z-SV05 Projection Contract Patch
// Read explicit GM Screen projection rows before attempting legacy inference. This
// prevents the renderer from guessing action economy, composite roles, manual
// provenance, or foundation content from prose/nested registries.
function sv05ProjectionDataFromParsed(parsed = []) {
  const primary = findJsonBlock(parsed, [/(?:^|[\\/])GM_Screen_Projection_Rows\.json$/i, /GM_Screen_Projection_Rows/i])?.data || null;
  const display = findJsonBlock(parsed, [/(?:^|[\\/])GM_Screen_Display_Rows\.json$/i, /GM_Screen_Display_Rows/i])?.data || null;
  if (primary && Array.isArray(primary.rows)) return primary;
  if (display && Array.isArray(display.rows)) return display;
  return null;
}

function sv05ProjectionRows(projection = null) {
  return projection && Array.isArray(projection.rows) ? projection.rows.filter((row) => row && typeof row === "object") : [];
}

function sv05ProjectionRowsByType(projection = null, type = "") {
  const key = String(type || "").toLowerCase();
  return sv05ProjectionRows(projection).filter((row) => String(row.row_type || row.type || "").toLowerCase() === key);
}

function sv05ProjectionContractActive(projection = null) {
  return Boolean(projection && Array.isArray(projection.rows) && (projection.projection_contract_version || /SV05/i.test(String(projection.schema || ""))));
}

function canonicalEconomyBucket(action = {}) {
  const direct = String(action.economy_bucket || action.primary_economy_bucket || "").toLowerCase().replace(/[\s-]+/g, "_").trim();
  if (["action", "bonus_action", "reaction", "passive"].includes(direct)) return direct;
  const text = [
    action.economy_label,
    action.economy,
    action.action_economy,
    action.action_window,
    action.action_kind,
    action.action_type,
    action.type,
    action.event_pattern?.action_economy_slot,
    firstHf05aAlias(action)
  ].map((item) => String(item || "").toLowerCase()).join(" ");
  if (/bonus[_\s-]*action/.test(text)) return "bonus_action";
  if (/reaction|interrupt|triggered response/.test(text)) return "reaction";
  if (/passive|always[-\s]*on|no action|free observation/.test(text)) return "passive";
  if (/\baction\b|standard action|attack action/.test(text)) return "action";
  return "";
}

function actionEconomyCounts(actions = [], passives = []) {
  const counts = { action: 0, bonus_action: 0, reaction: 0, passive: 0 };
  compactImportList(actions).forEach((action) => {
    const bucket = canonicalEconomyBucket(action);
    if (bucket && Object.prototype.hasOwnProperty.call(counts, bucket)) counts[bucket] += 1;
  });
  if (!counts.passive) counts.passive = compactImportList(passives).length;
  return counts;
}

function sv05ProjectionActionRows(projection = null) {
  return sv05ProjectionRowsByType(projection, "action").map((row) => {
    const bucket = canonicalEconomyBucket(row) || "action";
    const label = row.economy_label || row.economy || (bucket === "bonus_action" ? "Bonus Action" : titleCase(bucket.replace(/_/g, " ")));
    const name = row.display_name || row.action_name || row.name || row.action_id || row.id || "Projection Action";
    return {
      ...row,
      id: row.id || row.action_id,
      action_id: row.action_id || row.id,
      name,
      action_name: row.action_name || name,
      display_name: name,
      action_economy: label,
      action_window: row.action_window || label,
      action_type: row.action_type || row.action_kind || label,
      type: row.type || row.action_kind || label,
      economy_label: label,
      economy_bucket: bucket,
      secondary_economy_buckets: Array.isArray(row.secondary_economy_buckets) ? row.secondary_economy_buckets : [],
      cost: row.cost || row.resource_cost || row.resource_spent || row.resource_costs || "",
      resource_spent: row.resource_spent || row.resource_cost || row.cost || "",
      range: row.range || row.range_or_reach || row.targeting || "",
      range_or_reach: row.range_or_reach || row.range || row.targeting || "",
      damage_or_effect: row.damage_or_effect || row.effect_summary || row.effects || row.effect_packets || "",
      projection_contract_active: true
    };
  });
}

function sv05ProjectionManualGroups(projection = null) {
  const rows = sv05ProjectionRowsByType(projection, "martial_manual_technique");
  if (!rows.length) return [];
  const groups = new Map();
  rows.forEach((row) => {
    const manualId = row.manual_id || row.manual_name || "SV05_MANUAL";
    if (!groups.has(manualId)) {
      groups.set(manualId, {
        manual_id: manualId,
        id: manualId,
        name: row.manual_name || manualId,
        manual_name: row.manual_name || manualId,
        style_name: row.manual_name || manualId,
        source_status: "SV05 projection contract",
        source_or_teacher: "GM_Screen_Projection_Rows.json",
        grants_spheres: false,
        does_not_grant_sphere_or_talent: true,
        summary: "Renderer-facing SV05 manual projection rows. Manuals express fixed techniques and do not grant unselected spheres or talents.",
        manual_forms: [],
        forms: [],
        techniques: [],
        projection_contract_active: true
      });
    }
    const group = groups.get(manualId);
    const technique = {
      ...row,
      form_id: row.technique_id || row.id,
      id: row.technique_id || row.id,
      name: row.technique_name || row.display_name || row.technique_id || "Manual Technique",
      display_name: row.technique_name || row.display_name || row.technique_id || "Manual Technique",
      linked_action_id: Array.isArray(row.act_action_refs) ? row.act_action_refs[0] : row.act_action_refs,
      associated_spheres: Array.isArray(row.source_spheres) ? row.source_spheres : [],
      source_status: "SV05 projection contract",
      learned_from: row.learned_from || [
        Array.isArray(row.source_spheres) ? row.source_spheres.join(", ") : row.source_spheres,
        Array.isArray(row.source_talent_names) ? row.source_talent_names.join(", ") : row.source_talent_names
      ].map(asDisplayText).filter(Boolean).join(" — "),
      projection_contract_active: true
    };
    group.manual_forms.push(technique);
    group.forms = group.manual_forms;
    group.techniques = group.manual_forms;
  });
  return [...groups.values()];
}

function sv05ProjectionFoundationRows(projection = null) {
  return sv05ProjectionRowsByType(projection, "foundation").map((row) => ({
    ...row,
    id: row.foundation_id || row.id,
    name: row.display_name || row.foundation_name || row.name || row.foundation_id || "Foundation",
    display_name: row.display_name || row.foundation_name || row.name || row.foundation_id || "Foundation",
    foundation_name: row.display_name || row.foundation_name || row.name || row.foundation_id || "Foundation",
    family: row.foundation_family || row.family || row.foundation_type || "SV05 Foundation",
    foundation_family: row.foundation_family || row.family || "SV05 Foundation",
    foundation_type: row.foundation_type || row.type || "Foundation",
    mechanical_benefits: row.mechanical_benefits_or_constraints || row.mechanical_benefits || row.benefits || [],
    burdens: row.burden_deviation_risks || row.burdens || row.deviation_risks || [],
    explicit_non_permissions: row.does_not_grant_boundaries || row.non_permissions || [],
    triggers: row.breakthrough_relevance || row.triggers || [],
    counters: row.body_refining_interaction || row.counters || [],
    summary: row.summary || row.mechanics_delta || "SV05 projection foundation row.",
    source_status: "SV05 projection contract",
    projection_contract_active: true
  }));
}

function sv05ProjectionCompositeRows(projection = null) {
  return sv05ProjectionRowsByType(projection, "composite").map((row) => {
    const roleSeed = Array.isArray(row.tactical_roles) ? row.tactical_roles.join(" ") : (row.tactical_roles || row.execution_role || row.gm_screen_category || "");
    const priority = normalizeCompositePriority(row.execution_role || roleSeed || row.gm_screen_category);
    return {
      ...row,
      id: row.composite_id || row.id,
      composite_id: row.composite_id || row.id,
      name: row.display_name || row.name || row.composite_id || "SV05 Composite",
      display_name: row.display_name || row.name || row.composite_id || "SV05 Composite",
      priority,
      category: row.gm_screen_category || priority,
      role: row.execution_role || priority,
      tactical_role: Array.isArray(row.tactical_roles) ? row.tactical_roles.join(", ") : (row.tactical_roles || row.execution_role || priority),
      source_file: "GM_Screen_Projection_Rows.json",
      projection_contract_active: true
    };
  });
}

function sv05ProjectionLineList(value) {
  return compactImportList(value).map(asDisplayText).filter(Boolean);
}

function projectionDetailField(label, value, max = 900) {
  const text = asDisplayText(value);
  return text ? `<div class="composite-detail-field"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(truncateValue(text, max))}</div>` : "";
}

function buildCharacterSheetData(pkg) {
  if (pkg?.sheetData) {
    return {
      ...pkg.sheetData,
      equipment: Array.isArray(pkg.sheetData.equipment) ? pkg.sheetData.equipment : [],
      consumables: Array.isArray(pkg.sheetData.consumables) ? pkg.sheetData.consumables : [],
      martialArtsLearned: Array.isArray(pkg.sheetData.martialArtsLearned) ? pkg.sheetData.martialArtsLearned : [],
      hf05aActionScripts: Array.isArray(pkg.sheetData.hf05aActionScripts) ? pkg.sheetData.hf05aActionScripts : [],
      foundations: normalizeFoundationEntries(pkg.sheetData.foundations),
      background: pkg.sheetData.background || null,
      chakraRecord: pkg.sheetData.chakraRecord || ""
    };
  }
  const blocks = pkg?.blocks || [];
  const parsed = parseJsonPackageBlocks(blocks);
  const sv05Projection = sv05ProjectionDataFromParsed(parsed);
  const sv05ProjectionActions = sv05ProjectionActionRows(sv05Projection);
  const sv05ProjectionManuals = sv05ProjectionManualGroups(sv05Projection);
  const sv05ProjectionFoundations = sv05ProjectionFoundationRows(sv05Projection);
  const sheetExport = findJsonBlock(parsed, [/sheet_export/i, /complete_sheet/i, /Complete_Character_Record/i, /tianxia_character_sheet_export/i, /tianxia_complete_sheet_export/i, /tianxia_complete_character_record/i])?.data || {};
  const dashboardImport = findJsonBlock(parsed, [/Dashboard_Import/i, /tianxia_dashboard_import/i])?.data || {};
  const normalizedBlock = findJsonBlock(parsed, [/Normalized_Sheet/i, /Normalized_Character/i, /normalized_character/i, /tianxia_normalized_sheet/i, /_Normalized\.json$/i])?.data || {};
  const normalizedRaw = firstNonEmptyObject(normalizedBlock, sheetExport.raw_normalized_character, sheetExport.normalized_sheet);
  const normalized = normalizedRaw.character && typeof normalizedRaw.character === "object" && !Array.isArray(normalizedRaw.character)
    ? { ...normalizedRaw, ...normalizedRaw.character }
    : normalizedRaw;
  const legacyOverlay = findJsonBlock(parsed, [/Final_Normalized_Sheet/i, /strict_v110_rebuild_overlay/i, /tianxia_character_strict_v110$/i, /_Normalized\.json$/i])?.data || {};
  const legacyCharacter = legacyOverlay.character || {};
  const runtime = findJsonBlock(parsed, [/Fight_Runtime_Initialization_Profile/i, /fight_runtime_initialization/i])?.data || {};
  const characterCore = findJsonBlock(parsed, [/^(?:.*[\/])?Character_Core\.json$/i, /Tianxia\.CharacterCore/i, /character_core/i])?.data || {};
  const abilityAdvancement = findJsonBlock(parsed, [/Ability_Score_Advancement_Ledger/i, /ability_score_advancement/i])?.data || {};
  const resourceInventory = findJsonBlock(parsed, [/Limited_Resource_Counter_Inventory/i, /limited_resource/i])?.data || {};
  const actionRegistry = (findJsonBlock(parsed, [/^(?:.*[\\/])?Character_Action_Registry\.json$/i, /character_action_registry/i])?.data || findJsonBlock(parsed, [/_Action_Registry\.json$/i])?.data || {});
  const skillRegistry = findJsonBlock(parsed, [/Skill_Proficiency_Registry/i, /skill_proficiency_registry/i])?.data || {};
  const savingThrowRegistry = findJsonBlock(parsed, [/Saving_Throw_Registry/i, /saving_throw_registry/i])?.data || {};
  const talentInventory = findJsonBlock(parsed, [/Legal_Talent_Inventory/i, /Talent_Option_Inventory/i, /talent_option_inventory/i])?.data || {};
  const forgedTechniqueRegistry = findJsonBlock(parsed, [/^(?:.*[\\/])?Forged_Technique_Registry\.json$/i, /Forged_Technique_Registry/i])?.data || {};
  const stateRegistry = findJsonBlock(parsed, [/Character_State_Registry/i, /character_state_registry/i])?.data || {};
  const passivesRegistry = findJsonBlock(parsed, [/Passive_Modifier_Registry/i, /passives/i])?.data || {};
  const controlledAssets = findJsonBlock(parsed, [/Controlled_Asset_Inventory/i, /controlled_assets/i])?.data || {};
  const foundationRegistry = findJsonBlock(parsed, [/Foundation_Registry/i, /foundation_registry/i, /_Foundation_Record\.json$/i])?.data || {};
  const martialArtsRegistry = findJsonBlock(parsed, [/Martial_Arts_and_Manuals/i, /martial_arts.*manuals/i, /_Martial_Manuals\.json$/i])?.data || {};
  const actionScriptsRegistry = findJsonBlock(parsed, [/Action_Execution_Scripts/i, /Action_Execution_Script_Display_Alias/i])?.data || {};
  const legalTalentDisplayAliasAudit = findJsonBlock(parsed, [/Legal_Talent_Display_Alias_Audit/i, /HF05A.*Alias/i])?.data || {};
  // Some repaired packages use Complete_Character_Record as a wrapper around Normalized_Sheet.
  const directRecord = sheetExport.character && typeof sheetExport.character === "object" ? sheetExport.character : sheetExport;
  const identity = firstNonEmptyObject(sheetExport.identity, directRecord.identity, dashboardImport.identity, dashboardImport.character);
  const cultivation = firstNonEmptyObject(sheetExport.cultivation, sheetExport.progression, directRecord.cultivation, dashboardImport.cultivation, dashboardImport.progression);
  const mobileStats = firstNonEmptyObject(sheetExport.stats, dashboardImport.stats, normalized.stats, normalized.derived);
  const abilities = firstNonEmptyObject(sheetExport.abilities, directRecord.abilities, normalized.abilities);
  const combat = firstNonEmptyObject(sheetExport.combat, directRecord.combat);
  const build = sheetExport.build || {};
  const runtimeContent = sheetExport.runtime || {};
  const inventory = sheetExport.inventory || sheetExport.equipment_inventory || dashboardImport.inventory || dashboardImport.equipment_inventory || normalized.inventory || {};
  const markdownSheet = markdownCharacterSheetDetails(blocks);
  const directAbilityScores = firstNonEmptyObject(abilities.final, abilities.scores, directRecord.ability_scores, directRecord.stats?.ability_scores, abilityScoreRecord(directRecord.stats), mobileStats.ability_scores, abilityScoreRecord(mobileStats), characterCore.ability_scores, characterCore.stats?.ability_scores, abilityScoreRecord(characterCore.stats), abilityAdvancement.ability_scores, normalized.abilities?.final, normalized.ability_scores, normalized.abilities, normalized.scores, normalized.stats?.ability_scores, normalized.derived?.ability_scores, abilityScoreRecord(normalized.stats), markdownSheet.abilityScores);
  const directAbilityModifiers = firstNonEmptyObject(abilities.mods, abilities.modifiers, directRecord.ability_mods, directRecord.mods, directRecord.ability_modifiers, directRecord.stats?.ability_modifiers, directRecord.stats?.mods, mobileStats.ability_modifiers, mobileStats.mods, characterCore.ability_modifiers, characterCore.mods, characterCore.stats?.ability_modifiers, characterCore.stats?.mods, abilityAdvancement.ability_modifiers, abilityAdvancement.mods, normalized.abilities?.mods, normalized.mods, normalized.ability_modifiers, normalized.derived?.ability_modifiers, markdownSheet.abilityModifiers);
  const directFoundation = sheetExport.foundation || directRecord.foundation || normalized.foundation || foundationRegistry.foundation || null;
  const markdownFoundation = markdownFoundationRecord(blocks);
  const markdownForgedTechniques = forgedTechniqueMarkdownDetails(blocks);
  const directAc = sheetExport.ac || directRecord.ac || normalized.ac || normalized.armor_class || dashboardImport.ac || markdownSheet.stats.ac || null;
  const directAcRecord = directAc && typeof directAc === "object"
    ? {
      ...directAc,
      current: directAc.current ?? directAc.active ?? directAc.ac_active ?? directAc.ac_alt ?? directAc.liming_radiant_gown ?? directAc.ac ?? directAc.baseline ?? directAc.normal ?? directAc.base_with_harness_and_shield ?? directAc.base,
      base: directAc.base ?? directAc.normal ?? directAc.baseline ?? directAc.ac_base ?? directAc.base_with_harness_and_shield ?? directAc.ac,
      formula: directAc.formula || directAc.notes || ""
    }
    : directAc;

  const legacyResource = legacyCharacter.resource ? [{
    resource_name: legacyCharacter.resource.name,
    maximum: legacyCharacter.resource.max,
    current: legacyCharacter.resource.max,
    recovery: legacyCharacter.resource.formula
  }] : [];
  const normalizedMainResource = normalized.main_resource ? [normalized.main_resource] : normalized.primary_resource ? [normalized.primary_resource] : normalized.path?.max_cp !== undefined ? [{ name: normalized.path.name === "Qi Cultivation" ? "Qi" : "Cultivation Points", current: normalized.path.current_cp ?? normalized.path.max_cp, maximum: normalized.path.max_cp }] : [];
  const flatNormalizedResource = normalized.cp_name && normalized.cp_max !== undefined
    ? [{ name: normalized.cp_name, current: normalized.cp_current ?? normalized.cp_max, maximum: normalized.cp_max }]
    : normalized.cp && typeof normalized.cp === "object"
      ? [{ ...normalized.cp, current: normalized.cp.current ?? normalized.cp.max, maximum: normalized.cp.maximum ?? normalized.cp.max }]
    : normalized.resource && typeof normalized.resource === "object"
      ? [{ ...normalized.resource, current: normalized.resource.current ?? normalized.resource.current_start ?? normalized.resource.max, maximum: normalized.resource.maximum ?? normalized.resource.max }]
      : normalized.chakra_points && typeof normalized.chakra_points === "object"
        ? [{ name: "Chakra Points", current: normalized.chakra_points.current ?? normalized.chakra_points.start ?? normalized.chakra_points.max, maximum: normalized.chakra_points.maximum ?? normalized.chakra_points.max }]
        : mobileStats.resource_name && mobileStats.resource_max !== undefined
          ? [{ name: mobileStats.resource_name, current: mobileStats.resource_current ?? mobileStats.resource_max, maximum: mobileStats.resource_max }]
    : normalized.qi !== undefined
      ? [{ name: "Qi", current: normalized.qi, maximum: normalized.qi }]
      : normalized.stamina !== undefined
        ? [{ name: "Stamina", current: normalized.stamina, maximum: normalized.stamina }]
        : normalized.derived?.stamina !== undefined
          ? [{ name: "Stamina", current: normalized.derived.stamina, maximum: normalized.derived.stamina }]
          : [];
  const normalizedResources = Array.isArray(normalized.resources)
    ? normalized.resources
    : Object.entries(normalized.resources || normalized.trackers || {}).map(([resource_id, value]) => ({ resource_id, ...(typeof value === "object" ? value : { current: value }) }));
  const dashboardStartingResources = Object.entries(dashboardImport.starting_resources || {}).map(([resource_id, current]) => ({ resource_id, current, maximum: current }));
  const dashboardResource = dashboardImport.resource && typeof dashboardImport.resource === "object" ? [{ ...dashboardImport.resource, current: dashboardImport.resource.current ?? dashboardImport.resource.current_start ?? dashboardImport.resource.max, maximum: dashboardImport.resource.maximum ?? dashboardImport.resource.max }] : [];
  const exportResources = Array.isArray(sheetExport.resources) ? sheetExport.resources : Array.isArray(directRecord.resources) ? directRecord.resources : Array.isArray(dashboardImport.resources) ? dashboardImport.resources : Array.isArray(dashboardImport.resources_counters) ? dashboardImport.resources_counters : dashboardStartingResources;
  const inventoryResources = listFromJsonData(resourceInventory, ["resources", "limited_resources", "counters"]);
  const inventoryMainResource = resourceInventory.main_resource && typeof resourceInventory.main_resource === "object" ? [resourceInventory.main_resource] : [];
  const runtimeResources = listFromJsonData(runtimeContent.resource_inventory, ["resources", "limited_resources", "counters"]);
  const identityResources = resourceEntryFromIdentity(identity, directRecord, characterCore, mobileStats);
  const registryActions = listFromJsonData(actionRegistry, ["actions", "registry", "summary"]);
  const markdownRegistryActions = markdownActionRegistryEntries(actionRegistry.raw_markdown || blocks.find((block) => /(?:^|[\\/])(?:character_)?action_registry\.md$/i.test(block.name || ""))?.content || "");
  const runtimeActions = listFromJsonData(runtimeContent.actions);
  const exportActions = Array.isArray(sheetExport.actions) ? sheetExport.actions : Array.isArray(dashboardImport.actions) ? dashboardImport.actions : listFromJsonData(sheetExport.actions, ["registry", "summary", "actions"]);
  const rawActions = sv05ProjectionActions.length ? sv05ProjectionActions : registryActions.length ? registryActions : markdownRegistryActions.length ? markdownRegistryActions : runtimeActions.length ? runtimeActions : exportActions.length ? exportActions : Array.isArray(normalized.actions) ? normalized.actions : Array.isArray(normalized.core_actions) ? normalized.core_actions : [];
  const hf05aActionScripts = hf05aScriptRowsFromRegistry(actionScriptsRegistry);
  const hf05aAliasRows = hf05aAliasRowsFromAudit(legalTalentDisplayAliasAudit);
  const actions = mergeHf05aActionScripts(rawActions, hf05aActionScripts);
  const talentFeatures = listFromJsonData(talentInventory, ["features", "talents", "options"]);
  const normalizedTalents = Array.isArray(build.talents) && build.talents.length ? build.talents : Array.isArray(sheetExport.talents) && sheetExport.talents.length ? sheetExport.talents : Array.isArray(directRecord.selected_talents) && directRecord.selected_talents.length ? directRecord.selected_talents : Array.isArray(dashboardImport.talents) && dashboardImport.talents.length ? dashboardImport.talents : Array.isArray(normalized.talents) && normalized.talents.length ? normalized.talents : Array.isArray(normalized.selected_talents) ? normalized.selected_talents : [];
  const inferredTalentsRaw = normalizedTalents.length ? normalizedTalents : talentFeatures
    .filter((feature) => !/2024 Fifth Edition core action/i.test(feature.source_name || ""))
    .map((feature) => {
      if (feature && typeof feature === "object" && (feature.display_name || feature.name || feature.feature_name || feature.option_name)) return feature;
      return { name: feature?.feature_name || feature?.display_name || feature?.name || "Talent", source: feature?.source_name || feature?.source_anchor || feature?.source || "" };
    });
  const inferredTalents = mergeHf05aTalentAliases(inferredTalentsRaw, hf05aActionScripts, hf05aAliasRows);
  const legacyScores = legacyCharacter.abilities || legacyCharacter.stats || {};
  const legacyModifiers = abilityModifiersFromScores(legacyScores);
  const legacySaves = savesFromLegacyText(legacyCharacter.saves, legacyModifiers);
  const legacySkills = parseBonusList(legacyCharacter.skills);
  const recordSkills = bonusMapFromRecord(sheetExport.skills || directRecord.skills || mobileStats.skills || normalized.proficiencies?.skills);
  const registrySkills = skillBonusMap(skillRegistry.skills, skillRegistry.proficiencies, skillRegistry.expertise);
  const listedSkills = skillBonusMap(sheetExport.skills || directRecord.skills || mobileStats.skills || normalized.skills, normalized.proficiencies?.skills);
  const markdownSkills = skillBonusMap(markdownSheet.skills);
  const recordSaves = bonusMapFromRecord(sheetExport.saving_throws || sheetExport.saves || directRecord.saving_throws || directRecord.saves || mobileStats.saving_throws || normalized.saves, true);
  const registrySaves = saveBonusMap(savingThrowRegistry.saving_throws || savingThrowRegistry.saves);
  const proficiencySaves = savesFromProficiencyList(normalized.proficiencies?.saving_throws, directAbilityModifiers, normalized.level?.proficiency_bonus || cultivation.proficiency_bonus || normalized.proficiency_bonus);
  const markdownSaves = saveBonusMap(markdownSheet.saves);
  const mobileAbilityScores = mobileAbilityMap(mobileStats.abilities, "final");
  const mobileAbilityModifiers = mobileAbilityMap(mobileStats.abilities, "modifier");
  const registryForgedTechniques = listFromJsonData(forgedTechniqueRegistry, ["forged_techniques", "learned_forged_techniques", "forgedTechniques", "techniques", "entries", "items", "registry"]);
  const packageSpheres = [...new Set([
    pkg.primary,
    pkg.secondary,
    ...((pkg.detected || []).map((item) => item.name))
  ].filter(Boolean))];
  const sourceSpheres = Array.isArray(sheetExport.spheres) && sheetExport.spheres.length
    ? cleanPackageSphereNames(sheetExport.spheres)
    : Array.isArray(directRecord.spheres) && directRecord.spheres.length ? cleanPackageSphereNames(directRecord.spheres)
    : Array.isArray(dashboardImport.spheres) && dashboardImport.spheres.length ? cleanPackageSphereNames(dashboardImport.spheres) : [];
  const preferredSpheres = [
    Array.isArray(build.spheres) ? cleanPackageSphereNames(build.spheres) : [],
    sourceSpheres,
    Array.isArray(normalized.spheres) ? cleanPackageSphereNames(normalized.spheres) : [],
    Array.isArray(normalized.spheres_routes) ? cleanPackageSphereNames(normalized.spheres_routes) : [],
    Array.isArray(normalized.spheres_known) ? cleanPackageSphereNames(normalized.spheres_known) : [],
    Array.isArray(normalized.spheres_or_routes) ? cleanPackageSphereNames(normalized.spheres_or_routes) : [],
    Array.isArray(dashboardImport.spheres) ? cleanPackageSphereNames(dashboardImport.spheres) : [],
    markdownSheet.spheres,
    Array.isArray(legacyCharacter.spheres) ? cleanPackageSphereNames(legacyCharacter.spheres) : [],
    packageSpheres
  ].find((entries) => entries.length) || [];

  return {
    normalized,
    sheetExport,
    runtime,
    resourceInventory,
    actionRegistry,
    actionScriptsRegistry,
    legalTalentDisplayAliasAudit,
    hf05aActionScripts,
    hf05aAliasRows,
    talentInventory,
    stateRegistry,
    passivesRegistry,
    controlledAssets,
    name: normalized.name || normalized.character_name || sheetExport.name || identity.name || dashboardImport.display_name || normalized.display_name || markdownSheet.stats.name || runtime.name || pkg.name,
    characterId: sheetExport.character_id || directRecord.character_id || sheetExport.runtime_actor_id || identity.character_id || identity.canonical_character_id || identity.runtime_actor_id || normalized.character_id || runtime.canonical_character_id || runtime.runtime_actor_id || "",
    path: cultivation.path || identity.path || directRecord.path || dashboardImport.path || normalized.path?.name || normalized.path || markdownSheet.stats.path || runtime.path || legacyCharacter.path || pkg.path,
    realm: cultivation.realm_and_stage || [cultivation.stage, cultivation.realm].filter(Boolean).join(" ") || cultivation.realm || identity.realm || directRecord.realm || dashboardImport.realm || normalized.realm_and_stage || normalized.realm || normalized.level?.realm || markdownSheet.stats.realm || runtime.realm || legacyCharacter.realm_folder || pkg.realm,
    cultivationLevel: cultivation.level || cultivation.cultivation_level || identity.cl || directRecord.cl || directRecord.stats?.cultivation_level || characterCore.stats?.cultivation_level || dashboardImport.cl || normalized.cultivation_level || normalized.level?.CL || normalized.level?.cl || normalized.level?.level || normalized.cl || levelValue(normalized.level) || mobileStats.CL || mobileStats.cl || levelFromText(normalized.tier) || runtime.cultivation_level || markdownSheet.stats.cl || legacyCharacter.cultivation_level || "",
    keyAbility: cultivation.key_ability || identity.key_ability || directRecord.key_ability || directRecord.stats?.key_ability || characterCore.stats?.key_ability || normalized.key_ability || normalized.path?.key_ability || legacyCharacter.key_ability || "",
    proficiencyBonus: cultivation.proficiency_bonus ?? combat.proficiency_bonus ?? identity.proficiency_bonus ?? directRecord.proficiency_bonus ?? directRecord.stats?.proficiency_bonus ?? characterCore.stats?.proficiency_bonus ?? dashboardImport.proficiency_bonus ?? normalized.proficiency_bonus ?? normalized.proficiency ?? normalized.level?.proficiency_bonus ?? mobileStats.proficiency ?? legacyCharacter.proficiency_bonus ?? "",
    cultivationAttackBonus: combat.primary_attack_bonus ?? combat.cultivation_attack_bonus ?? cultivation.cultivation_attack_bonus ?? cultivation.primary_attack_bonus ?? identity.technique_attack_bonus ?? directRecord.technique_attack_bonus ?? directRecord.stats?.technique_attack_bonus ?? characterCore.stats?.technique_attack_bonus ?? dashboardImport.attack ?? sheetExport.chakra_attack_bonus ?? normalized.chakra_attack_bonus ?? normalized.cultivation_attack_bonus ?? normalized.primary_attack_bonus ?? normalized.technique_attack ?? normalized.attack_bonus ?? normalized.path?.qi_attack_modifier ?? mobileStats.technique_attack ?? legacyCharacter.cultivation_attack ?? markdownSheet.stats.attack ?? pkg.primary_attack_bonus,
    cultivationSaveDc: combat.save_dc ?? combat.cultivation_save_dc ?? cultivation.cultivation_save_dc ?? cultivation.primary_save_dc ?? identity.save_dc ?? directRecord.save_dc ?? directRecord.stats?.save_dc ?? characterCore.stats?.save_dc ?? dashboardImport.dc ?? sheetExport.chakra_save_dc ?? normalized.chakra_save_dc ?? normalized.cultivation_save_dc ?? normalized.primary_save_dc ?? normalized.save_dc ?? normalized.path?.qi_save_dc ?? mobileStats.save_DC ?? mobileStats.save_dc ?? markdownSheet.stats.saveDc ?? legacyCharacter.cultivation_dc ?? pkg.primary_save_dc,
    attacksPerAttackAction: combat.attacks_per_attack_action ?? normalized.attacks_per_attack_action,
    physicalDescription: identity.description || identity.appearance || normalized.physical_description || normalized.appearance || normalized.description || runtime.physical_description || "",
    background: sheetExport.background || identity.background || build.background || dashboardImport.background || normalized.background || null,
    foundations: normalizeFoundationEntries(richestFoundationList(
      sv05ProjectionFoundations,
      listFromJsonData(foundationRegistry, ["foundations", "foundation_registry"]),
      listFromJsonData(sheetExport.foundations),
      listFromJsonData(build.foundations),
      listFromJsonData(normalized.foundations),
      listFromJsonData(dashboardImport.foundations),
      listFromJsonData(dashboardImport.foundation_registry),
      markdownFoundation ? [markdownFoundation] : [],
      directFoundation ? [typeof directFoundation === "string" ? { name: directFoundation } : directFoundation] : []
    )),
    chakraRecord: cultivation.chakra_record || normalized.chakra_record || dashboardImport.chakra_record || (sheetExport.path === "Chakra" || normalized.path === "Chakra" ? `Primary Wheel: ${sheetExport.primary_wheel || normalized.primary_wheel || "unrecorded"}; Open Wheels: ${(sheetExport.open_wheels || normalized.open_wheels || []).join(", ") || "unrecorded"}.` : ""),
    hp: normalizeHpRecord(combat.hit_points || mobileStats.hit_points || (mobileStats.HP ? { maximum: mobileStats.HP, current: mobileStats.HP } : null) || (mobileStats.hp ? { maximum: mobileStats.hp, current: mobileStats.hp } : null) || (mobileStats.max_hp ? { maximum: mobileStats.max_hp, current: mobileStats.current_hp ?? mobileStats.max_hp } : null) || (dashboardImport.stats?.hp ? { maximum: dashboardImport.stats.hp, current: dashboardImport.stats.current_hp ?? dashboardImport.stats.hp } : null) || (directRecord.stats?.hp ? { maximum: directRecord.stats.hp, current: directRecord.stats.current_hp ?? directRecord.stats.hp } : null) || (characterCore.stats?.hp ? { maximum: characterCore.stats.hp, current: characterCore.stats.current_hp ?? characterCore.stats.hp } : null) || (normalized.stats?.hp ? { maximum: normalized.stats.hp, current: normalized.stats.current_hp ?? normalized.stats.hp } : null) || (combat.hp_max ? { maximum: combat.hp_max, current: combat.hp_current ?? combat.hp_max } : null) || (sheetExport.hp !== undefined ? sheetExport.hp : null) || (directRecord.hp !== undefined ? directRecord.hp : null) || (dashboardImport.hp !== undefined ? dashboardImport.hp : null) || (normalized.max_hp ? { maximum: normalized.max_hp, current: normalized.hp_current ?? normalized.max_hp } : null) || (normalized.hp_max ? { maximum: normalized.hp_max, current: normalized.hp_current ?? normalized.hp_max } : null) || normalized.hp || markdownSheet.stats.hp || (legacyCharacter.hp ? { maximum: legacyCharacter.hp, current: legacyCharacter.hp } : {})),
    ac: normalizeAcRecord(combat.armor_class || mobileStats.armor_class || (mobileStats.AC_base ? { base: mobileStats.AC_base, current: mobileStats.AC_active ?? mobileStats.AC_base } : null) || (mobileStats.ac_base ? { base: mobileStats.ac_base, current: mobileStats.ac_active ?? mobileStats.ac_base } : null) || (combat.ac_base ? { base: combat.ac_base } : null) || directRecord.stats?.ac || characterCore.stats?.ac || directAcRecord || markdownSheet.stats.ac || (legacyCharacter.ac ? { base: legacyCharacter.ac } : {})),
    speed: combat.speed ?? combat.speed_ft ?? combat.speeds ?? directRecord.speed ?? directRecord.speed_ft ?? directRecord.stats?.speed_ft ?? characterCore.stats?.speed_ft ?? dashboardImport.speed ?? mobileStats.speed ?? mobileStats.speed_ft ?? normalized.speed ?? normalized.speed_ft ?? markdownSheet.stats.speed ?? runtime.speed ?? "",
    resources: (() => {
      const resourceCandidates = [
        inventoryResources,
        inventoryMainResource,
        exportResources,
        normalizedResources,
        normalizedMainResource,
        flatNormalizedResource,
        dashboardResource,
        runtimeResources,
        identityResources,
        (markdownSheet.resources || []),
        legacyResource
      ];
      return resourceCandidates.find((list) => compactImportList(list).some(resourceEntryHasDisplayValues))
        || resourceCandidates.find((list) => compactImportList(list).length)
        || [];
    })(),
    spheres: preferredSpheres,
    talents: inferredTalents,
    insights: Array.isArray(build.insights) && build.insights.length ? build.insights : Array.isArray(sheetExport.insights) && sheetExport.insights.length ? sheetExport.insights : Array.isArray(dashboardImport.insights) && dashboardImport.insights.length ? dashboardImport.insights : Array.isArray(normalized.insights) ? normalized.insights : [],
    forgedTechniques: registryForgedTechniques.length ? registryForgedTechniques : Array.isArray(build.forged_techniques) && build.forged_techniques.length ? build.forged_techniques : Array.isArray(sheetExport.forged_techniques) && sheetExport.forged_techniques.length ? sheetExport.forged_techniques : Array.isArray(dashboardImport.forged_techniques) && dashboardImport.forged_techniques.length ? dashboardImport.forged_techniques : Array.isArray(normalized.forged_techniques) && normalized.forged_techniques.length ? normalized.forged_techniques : markdownForgedTechniques,
    weapons: Array.isArray(combat.weapon_and_unarmed_profiles) && combat.weapon_and_unarmed_profiles.length ? combat.weapon_and_unarmed_profiles : Array.isArray(normalized.weapon_and_unarmed_profiles) ? normalized.weapon_and_unarmed_profiles : [],
    actions: actions.sort((a, b) => actionSortScore(a) - actionSortScore(b)),
    states: listFromJsonData(stateRegistry, ["states", "registry"]).length ? listFromJsonData(stateRegistry, ["states", "registry"]) : listFromJsonData(runtimeContent.states).length ? listFromJsonData(runtimeContent.states) : Array.isArray(sheetExport.states) ? sheetExport.states : listFromJsonData(sheetExport.states, ["registry", "states"]),
    passives: listFromJsonData(passivesRegistry, ["passives", "registry"]).length ? listFromJsonData(passivesRegistry, ["passives", "registry"]) : listFromJsonData(runtimeContent.passives).length ? listFromJsonData(runtimeContent.passives) : Array.isArray(sheetExport.passives) ? sheetExport.passives : listFromJsonData(sheetExport.passives, ["registry", "passives"]),
    assets: listFromJsonData(controlledAssets, ["assets", "controlled_assets"]).length ? listFromJsonData(controlledAssets, ["assets", "controlled_assets"]) : listFromJsonData(runtimeContent.controlled_assets).length ? listFromJsonData(runtimeContent.controlled_assets) : Array.isArray(sheetExport.controlled_assets) ? sheetExport.controlled_assets : listFromJsonData(sheetExport.controlled_assets, ["assets", "controlled_assets"]),
    equipment: firstAvailableList(
      listFromJsonData(sheetExport.equipment),
      listFromJsonData(build.equipment),
      listFromJsonData(normalized.equipment),
      listFromJsonData(inventory, ["equipment", "items", "gear", "weapons", "armor"])
    ),
    consumables: firstAvailableList(
      listFromJsonData(sheetExport.consumables),
      listFromJsonData(build.consumables),
      listFromJsonData(normalized.consumables),
      listFromJsonData(dashboardImport.consumables),
      listFromJsonData(inventory, ["consumables", "pills", "elixirs", "talismans", "potions"])
    ),
    martialArtsLearned: sv05ProjectionManuals.length ? sv05ProjectionManuals : enrichMartialArtEntries(richestMartialArtList(
      listFromJsonData(sheetExport.martial_arts),
      listFromJsonData(sheetExport.martialArtsLearned),
      listFromJsonData(sheetExport.manuals),
      listFromJsonData(build.martial_arts),
      listFromJsonData(build.martialArtsLearned),
      listFromJsonData(build.manuals),
      listFromJsonData(normalized.martial_arts),
      listFromJsonData(normalized.martialArtsLearned),
      listFromJsonData(normalized.manuals),
      listFromJsonData(normalized, ["manuals"]),
      listFromJsonData(dashboardImport.martial_arts),
      listFromJsonData(martialArtsRegistry, ["martial_arts", "manuals", "learned_styles"]),
      listFromJsonData(inventory, ["martial_arts", "martialArtsLearned", "learned_styles", "manuals", "tablets"]),
      simpleMartialManualMarkdownList(blocks)
    ), martialManualMarkdownDetails(blocks)),
    senses: Array.isArray(combat.senses) && combat.senses.length ? combat.senses.map((sense) => typeof sense === "string" ? sense : [sense.name, sense.range, sense.notes].filter(Boolean).join(" | ")) : Array.isArray(mobileStats.senses) && mobileStats.senses.length ? mobileStats.senses : Array.isArray(normalized.senses) ? normalized.senses : [],
    skills: Object.keys(registrySkills).length ? registrySkills : sheetExport.skills?.bonuses || (Object.keys(recordSkills).length ? recordSkills : null) || (Object.keys(listedSkills).length ? listedSkills : null) || (Object.keys(markdownSkills).length ? markdownSkills : null) || abilities.skills || normalized.skills || legacySkills,
    abilityScores: firstNonEmptyObject(abilities.scores, directAbilityScores, mobileAbilityScores, normalized.ability_scores, normalized.abilities, normalized.scores, normalized.stats?.ability_scores, normalized.derived?.ability_scores, abilityScoreRecord(normalized.stats), markdownSheet.abilityScores, legacyScores),
    abilityModifiers: firstNonEmptyObject(abilities.modifiers, directAbilityModifiers, mobileAbilityModifiers, normalized.ability_modifiers, normalized.derived?.ability_modifiers, markdownSheet.abilityModifiers, abilityModifiersFromScores(directAbilityScores), legacyModifiers),
    saves: Object.keys(registrySaves).length ? registrySaves : sheetExport.saves?.bonuses || sheetExport.saving_throws?.bonuses || (Object.keys(recordSaves).length ? recordSaves : null) || (Object.keys(markdownSaves).length ? markdownSaves : null) || abilities.saves || normalized.saves || (Object.keys(proficiencySaves).length ? proficiencySaves : null) || legacySaves,
    resistances: Array.isArray(combat.resistances) ? combat.resistances.map(entryDisplayName) : Array.isArray(mobileStats.defenses?.resistances) ? mobileStats.defenses.resistances.map(entryDisplayName) : normalized.resistances || [],
    immunities: Array.isArray(combat.immunities) ? combat.immunities.map(entryDisplayName) : Array.isArray(mobileStats.defenses?.immunities) ? mobileStats.defenses.immunities.map(entryDisplayName) : normalized.immunities || [],
    vulnerabilities: Array.isArray(combat.vulnerabilities) ? combat.vulnerabilities.map(entryDisplayName) : Array.isArray(mobileStats.defenses?.vulnerabilities) ? mobileStats.defenses.vulnerabilities.map(entryDisplayName) : normalized.vulnerabilities || []
  };
}


// v1.11.0-HF05B Import Surface Normalization Patch
// Prefer Character_Import_Surface.json when present. Fall back to legacy registries.
function surfaceObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function surfaceArray(value) {
  if (Array.isArray(value)) return compactImportList(value);
  if (value && typeof value === "object") return compactImportList(Object.values(value));
  if (value === null || value === undefined || value === "") return [];
  return [value];
}

function surfaceFirstList(source = {}, keys = []) {
  for (const key of keys) {
    if (!source || typeof source !== "object") continue;
    const direct = source[key];
    const arr = surfaceArray(direct);
    if (arr.length) return arr;
  }
  return [];
}

function surfaceFirstObject(source = {}, keys = []) {
  for (const key of keys) {
    const obj = surfaceObject(source?.[key]);
    if (Object.keys(obj).length) return obj;
  }
  return {};
}

function surfaceFirstScalar(source = {}, keys = []) {
  for (const key of keys) {
    const value = source?.[key];
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return "";
}

function normalizeImportSurfaceSheet(surface = {}, legacy = {}) {
  const root = surfaceObject(surface);
  const identity = surfaceFirstObject(root, ["identity", "character", "character_identity", "profile"]);
  const stats = surfaceFirstObject(root, ["stats", "stat_block", "combat", "combat_stats"]);
  const cultivation = surfaceFirstObject(root, ["cultivation", "path", "progression", "realm"]);
  const build = surfaceFirstObject(root, ["build", "loadout", "character_build"]);
  const resources = surfaceFirstList(root, ["resources", "resource_registry", "limited_resources", "counters_as_resources"]);
  const surfaceResourceName = surfaceFirstScalar(root, ["primary_resource_name", "resource_name"])
    || surfaceFirstScalar(stats, ["primary_resource_name", "resource_name"])
    || (typeof root.resource === "string" ? root.resource : surfaceFirstScalar(surfaceObject(root.resource), ["name", "display_name", "resource", "type"]))
    || (typeof stats.resource === "string" ? stats.resource : surfaceFirstScalar(surfaceObject(stats.resource), ["name", "display_name", "resource", "type"]));
  const surfaceResourceMax = surfaceFirstScalar(root, ["primary_resource_max", "resource_max", "max_resource"])
    || surfaceFirstScalar(stats, ["primary_resource_max", "resource_max", "max_resource"])
    || surfaceFirstScalar(surfaceObject(root.resource), ["maximum", "max", "value", "total"])
    || surfaceFirstScalar(surfaceObject(stats.resource), ["maximum", "max", "value", "total"]);
  const surfaceResourceCurrent = surfaceFirstScalar(root, ["primary_resource_current", "resource_current", "current_resource"])
    || surfaceFirstScalar(stats, ["primary_resource_current", "resource_current", "current_resource"])
    || surfaceFirstScalar(surfaceObject(root.resource), ["current", "remaining"])
    || surfaceFirstScalar(surfaceObject(stats.resource), ["current", "remaining"]);
  const surfaceResource = surfaceResourceName ? {
    name: surfaceResourceName === "CP" ? "Cultivation Points" : surfaceResourceName,
    current: surfaceResourceCurrent !== "" ? surfaceResourceCurrent : surfaceResourceMax,
    maximum: surfaceResourceMax !== "" ? surfaceResourceMax : surfaceResourceCurrent
  } : null;
  const foundations = surfaceFirstList(root, ["foundations", "foundation_registry", "foundation_records"])
    .concat(root.foundation ? surfaceArray(root.foundation) : [])
    .concat(surfaceArray(build.foundation || build.foundations));
  const manuals = surfaceFirstList(root, ["martial_manuals", "manuals", "martial_arts", "martialArtsLearned", "learned_styles"])
    .concat(surfaceFirstList(build, ["martial_manuals", "manuals", "martial_arts", "martialArtsLearned"]));
  const actions = surfaceFirstList(root, ["actions", "action_registry", "action_objects", "action_execution_scripts", "action_scripts"]);
  const legalTalentsList = Array.isArray(root.legal_talents) ? root.legal_talents
    : Array.isArray(root.legal_talents?.talents) ? root.legal_talents.talents
      : Array.isArray(root.legal_talents?.entries) ? root.legal_talents.entries
        : [];
  const talents = surfaceFirstList(root, ["talents", "talent_registry", "talent_coverage"])
    .concat(legalTalentsList)
    .concat(surfaceFirstList(build, ["talents", "legal_talents"]));
  const spheres = surfaceFirstList(root, ["spheres", "sphere_routes", "legal_spheres"])
    .concat(surfaceFirstList(build, ["spheres", "sphere_routes", "legal_spheres"]));
  const background = root.background || identity.background || build.background || null;
  const hp = root.hp || stats.hp || stats.hit_points || stats.hitPoints
    || (surfaceFirstScalar(root, ["hp_max", "max_hp", "hit_points_max"]) !== "" ? {
      current: surfaceFirstScalar(root, ["hp_current", "current_hp", "hit_points_current"]) || surfaceFirstScalar(root, ["hp_max", "max_hp", "hit_points_max"]),
      maximum: surfaceFirstScalar(root, ["hp_max", "max_hp", "hit_points_max"])
    } : null)
    || (surfaceFirstScalar(stats, ["hp_max", "max_hp", "hit_points_max"]) !== "" ? {
      current: surfaceFirstScalar(stats, ["hp_current", "current_hp", "hit_points_current"]) || surfaceFirstScalar(stats, ["hp_max", "max_hp", "hit_points_max"]),
      maximum: surfaceFirstScalar(stats, ["hp_max", "max_hp", "hit_points_max"])
    } : null)
    || null;
  const ac = root.ac || stats.ac || stats.armor_class || stats.armorClass
    || (surfaceFirstScalar(root, ["ac_active", "active_ac", "armor_class_active", "ac_base", "base_ac"]) !== "" ? {
      current: surfaceFirstScalar(root, ["ac_active", "active_ac", "armor_class_active"]) || surfaceFirstScalar(root, ["ac_base", "base_ac"]),
      base: surfaceFirstScalar(root, ["ac_base", "base_ac"]) || surfaceFirstScalar(root, ["ac_active", "active_ac", "armor_class_active"])
    } : null)
    || (surfaceFirstScalar(stats, ["ac_active", "active_ac", "armor_class_active", "ac_base", "base_ac"]) !== "" ? {
      current: surfaceFirstScalar(stats, ["ac_active", "active_ac", "armor_class_active"]) || surfaceFirstScalar(stats, ["ac_base", "base_ac"]),
      base: surfaceFirstScalar(stats, ["ac_base", "base_ac"]) || surfaceFirstScalar(stats, ["ac_active", "active_ac", "armor_class_active"])
    } : null)
    || null;
  return {
    importSurfaceVersion: root.import_surface_version || root.schema || "Character_Import_Surface",
    name: surfaceFirstScalar(identity, ["name", "character_name", "display_name", "full_name"]) || surfaceFirstScalar(root, ["name", "character_name", "display_name", "full_name"]),
    characterId: surfaceFirstScalar(identity, ["character_id", "id", "runtime_actor_id"]) || root.character_id || root.id || "",
    path: surfaceFirstScalar(cultivation, ["path", "path_name", "cultivation_path"]) || surfaceFirstScalar(identity, ["path"]) || surfaceFirstScalar(root, ["path", "path_name", "cultivation_path"]),
    realm: surfaceFirstScalar(cultivation, ["realm", "realm_and_stage", "stage"]) || surfaceFirstScalar(identity, ["realm"]) || surfaceFirstScalar(root, ["realm", "realm_and_stage", "stage"]),
    cultivationLevel: surfaceFirstScalar(cultivation, ["cl", "CL", "cultivation_level", "level"]) || root.cl || root.CL || root.level || root.cultivation_level || "",
    keyAbility: surfaceFirstScalar(cultivation, ["key_ability", "primary_ability"]) || surfaceFirstScalar(root, ["key_ability", "primary_ability"]),
    proficiencyBonus: surfaceFirstScalar(stats, ["proficiency_bonus", "proficiency", "pb"]) || surfaceFirstScalar(root, ["proficiency_bonus", "proficiency", "pb"]),
    cultivationAttackBonus: surfaceFirstScalar(stats, ["cultivation_attack_bonus", "primary_attack_bonus", "technique_attack", "technique_attack_bonus", "attack_bonus", "attack"]) || surfaceFirstScalar(root, ["cultivation_attack_bonus", "primary_attack_bonus", "technique_attack", "technique_attack_bonus", "attack_bonus", "attack"]),
    cultivationSaveDc: surfaceFirstScalar(stats, ["cultivation_save_dc", "primary_save_dc", "technique_dc", "technique_save_dc", "save_dc", "dc"]) || surfaceFirstScalar(root, ["cultivation_save_dc", "primary_save_dc", "technique_dc", "technique_save_dc", "save_dc", "dc"]),
    attacksPerAttackAction: surfaceFirstScalar(stats, ["attacks_per_attack_action"]) || surfaceFirstScalar(root, ["attacks_per_attack_action"]),
    physicalDescription: surfaceFirstScalar(identity, ["physical_description", "appearance", "description"]) || root.physical_description || "",
    background,
    foundations: normalizeFoundationEntries(foundations),
    chakraRecord: root.chakra_record || cultivation.chakra_record || "",
    hp: normalizeHpRecord(hp),
    ac: normalizeAcRecord(ac),
    speed: root.speed || root.speed_ft || stats.speed || stats.speed_ft || "",
    resources: resources.length ? resources : (surfaceResource ? [surfaceResource] : []),
    spheres: namedEntries(spheres),
    talents,
    insights: surfaceFirstList(root, ["insights", "insight_records"]),
    forgedTechniques: surfaceFirstList(root, ["forged_techniques", "forgedTechniques"]),
    weapons: surfaceFirstList(root, ["weapons", "weapon_and_unarmed_profiles", "attack_profiles"]),
    actions,
    states: surfaceFirstList(root, ["states", "state_registry", "conditions"]),
    passives: surfaceFirstList(root, ["passives", "passive_registry", "passive_modifiers"]),
    assets: surfaceFirstList(root, ["assets", "controlled_assets", "controlled_asset_inventory"]),
    equipment: surfaceFirstList(root, ["equipment", "gear", "items"]),
    consumables: surfaceFirstList(root, ["consumables", "pills", "elixirs", "talismans"]),
    martialArtsLearned: manuals,
    senses: surfaceFirstList(root, ["senses"]),
    skills: surfaceObject(root.skills || stats.skills),
    abilityScores: firstNonEmptyObject(surfaceObject(root.ability_scores || stats.ability_scores || root.abilities || root.ability_scores_final), abilityScoreRecord(stats), abilityScoreRecord(root.stats)),
    abilityModifiers: firstNonEmptyObject(surfaceObject(root.ability_modifiers || root.mods || stats.ability_modifiers || stats.mods), surfaceObject(root.modifiers || stats.modifiers)),
    saves: surfaceObject(root.saves || root.saving_throws || stats.saves || stats.saving_throws),
    resistances: surfaceFirstList(root, ["resistances"]),
    immunities: surfaceFirstList(root, ["immunities"]),
    vulnerabilities: surfaceFirstList(root, ["vulnerabilities"])
  };
}

function listDisplayRichnessScore(list = [], key = "") {
  if (!Array.isArray(list) || !list.length) return 0;
  return list.reduce((score, item) => {
    if (typeof item === "string") return score + (key === "spheres" || key === "resources" || key === "senses" ? 4 : 1);
    if (!item || typeof item !== "object") return score;
    let itemScore = 6;
    if (item.display_name || item.name || item.action_name || item.feature_name || item.manual_name || item.style_name || item.foundation_name || item.resource_name) itemScore += 6;
    if (item.description || item.summary || item.effect || item.effect_summary || item.damage || item.rules_text || item.dao_principle) itemScore += 4;
    if (Array.isArray(item.forms) || Array.isArray(item.manual_forms) || Array.isArray(item.techniques) || Array.isArray(item.learned_forms)) itemScore += 10 + martialManualForms(item).length * 3;
    if (Array.isArray(item.optional_riders)) itemScore += item.optional_riders.length;
    if (Array.isArray(item.stage_benefits) || item.stage_benefits) itemScore += 5;
    if (key === "foundations") {
      if (item.catalog_number || item.catalogue_number) itemScore += 40;
      if (Array.isArray(item.mechanical_permissions) && item.mechanical_permissions.length) itemScore += item.mechanical_permissions.length * 4;
      if (Array.isArray(item.explicit_non_permissions) && item.explicit_non_permissions.length) itemScore += item.explicit_non_permissions.length * 3;
      if (item.known_player_text || item.dao_principle || item.origin) itemScore += 10;
    }
    return score + itemScore;
  }, 0);
}

function shouldUseSurfaceList(legacyList = [], surfaceList = [], key = "") {
  if (!Array.isArray(surfaceList) || !surfaceList.length) return false;
  if (!Array.isArray(legacyList) || !legacyList.length) return true;
  const legacyScore = listDisplayRichnessScore(legacyList, key);
  const surfaceScore = listDisplayRichnessScore(surfaceList, key);
  // HF05U: compact Character_Import_Surface arrays often contain only display
  // strings (especially actions).  They are useful fallback data but must not
  // replace full registries with costs, riders, links, or rules text.
  // Foundation records from Markdown/catalog bindings are often more authoritative
  // than compact legacy aliases, so they must win ties.
  if (key === "foundations") return surfaceScore > legacyScore;
  return surfaceScore >= legacyScore;
}

function mergeImportSurfaceSheet(legacy = {}, surface = {}) {
  const merged = { ...legacy };
  const scalarKeys = ["importSurfaceVersion", "name", "characterId", "path", "realm", "cultivationLevel", "keyAbility", "proficiencyBonus", "cultivationAttackBonus", "cultivationSaveDc", "attacksPerAttackAction", "physicalDescription", "chakraRecord", "speed"];
  scalarKeys.forEach((key) => {
    if (surface[key] !== undefined && surface[key] !== null && surface[key] !== "") merged[key] = surface[key];
  });
  ["background", "hp", "ac", "skills", "abilityScores", "abilityModifiers", "saves"].forEach((key) => {
    if (surface[key] && (typeof surface[key] !== "object" || Object.keys(surface[key]).length)) merged[key] = surface[key];
  });
  ["resources", "spheres", "talents", "insights", "forgedTechniques", "weapons", "actions", "states", "passives", "assets", "equipment", "consumables", "martialArtsLearned", "senses", "resistances", "immunities", "vulnerabilities"].forEach((key) => {
    if (shouldUseSurfaceList(merged[key], surface[key], key)) merged[key] = surface[key];
  });
  if (Array.isArray(surface.foundations) && surface.foundations.length && shouldUseSurfaceList(merged.foundations, surface.foundations, "foundations")) merged.foundations = normalizeFoundationEntries(surface.foundations);
  merged.importSurfaceActive = Boolean(surface.importSurfaceVersion || surface.name || (surface.actions || []).length || (surface.foundations || []).length);
  return merged;
}

function tianxiaAbilityMods(sheet = {}) {
  const mods = { ...(sheet.abilityModifiers || {}) };
  const fromScores = abilityModifiersFromScores(sheet.abilityScores || {});
  ABILITY_ROWS.forEach((ability) => {
    const key = ability.short;
    if (mods[key] === undefined && fromScores[key] !== undefined) mods[key] = fromScores[key];
  });
  return mods;
}

const TIANXIA_SKILL_ABILITIES = {
  Athletics: "STR",
  Acrobatics: "DEX",
  "Sleight of Hand": "DEX",
  Stealth: "DEX",
  Arcana: "INT",
  History: "INT",
  Investigation: "INT",
  Nature: "INT",
  Religion: "INT",
  "Animal Handling": "WIS",
  Insight: "WIS",
  Medicine: "WIS",
  Perception: "WIS",
  Survival: "WIS",
  Deception: "CHA",
  Intimidation: "CHA",
  Performance: "CHA",
  Persuasion: "CHA"
};

function normalizeVisibleBonusMap(value = {}, abilityKeys = false) {
  const out = {};
  const register = (key, val) => {
    const parsed = String(key || "").match(/^(.+?)\s*([+-]\d+)$/);
    const labelRaw = parsed ? parsed[1].trim() : String(key || "").trim();
    const label = abilityKeys ? (abilityShortName(labelRaw) || labelRaw.toUpperCase()) : labelRaw.replace(/_/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
    const bonus = typeof val === "number" ? val : parsed ? Number(parsed[2]) : val?.bonus ?? val?.total ?? val?.value ?? val?.mod ?? val?.modifier;
    if (label && bonus !== undefined && bonus !== null && bonus !== "" && Number.isFinite(Number(bonus))) out[label] = Number(bonus);
  };
  if (Array.isArray(value)) {
    value.forEach((item) => {
      if (typeof item === "string") {
        const parsed = item.match(/^(.+?)\s*([+-]\d+)$/);
        if (parsed) register(parsed[1], Number(parsed[2]));
      } else if (item && typeof item === "object") {
        register(item.ability || item.skill || item.name || item.label || item.save, item);
      }
    });
  } else if (value && typeof value === "object") {
    Object.entries(value).forEach(([key, val]) => register(key, val));
  }
  return out;
}

function fillBaselineSaves(saves = {}, mods = {}) {
  const out = { ...(saves || {}) };
  ABILITY_ROWS.forEach((ability) => {
    if (out[ability.short] === undefined && mods[ability.short] !== undefined) out[ability.short] = mods[ability.short];
  });
  return out;
}

function fillBaselineSkills(skills = {}, mods = {}) {
  const out = { ...(skills || {}) };
  Object.entries(TIANXIA_SKILL_ABILITIES).forEach(([skill, ability]) => {
    if (out[skill] === undefined && mods[ability] !== undefined) out[skill] = mods[ability];
  });
  return out;
}

function finalizeSheetDisplayStats(sheet = {}) {
  const clean = { ...sheet };
  if (!clean.abilityScores || !Object.keys(clean.abilityScores || {}).length) clean.abilityScores = {};
  clean.abilityModifiers = tianxiaAbilityMods(clean);
  clean.saves = fillBaselineSaves(normalizeVisibleBonusMap(clean.saves, true), clean.abilityModifiers);
  clean.skills = fillBaselineSkills(normalizeVisibleBonusMap(clean.skills, false), clean.abilityModifiers);
  return clean;
}

const buildCharacterSheetDataLegacyHf05b = buildCharacterSheetData;
function sanitizeSheetCollections(sheet = {}) {
  if (!sheet || typeof sheet !== "object") return {};
  const listKeys = [
    "resources", "spheres", "talents", "insights", "forgedTechniques", "weapons",
    "actions", "states", "passives", "assets", "equipment", "consumables",
    "martialArtsLearned", "senses", "resistances", "immunities", "vulnerabilities",
    "foundations"
  ];
  const clean = { ...sheet };
  for (const key of listKeys) {
    if (Array.isArray(clean[key])) clean[key] = compactImportList(clean[key]);
  }
  if (Array.isArray(clean.martialArtsLearned)) {
    clean.martialArtsLearned = clean.martialArtsLearned.map((manual) => {
      if (!manual || typeof manual !== "object") return manual;
      const merged = { ...manual };
      ["manual_forms", "forms", "techniques", "learned_forms", "linked_forms", "actions", "entries"].forEach((key) => {
        if (Array.isArray(merged[key])) merged[key] = compactImportList(merged[key]);
      });
      return merged;
    });
  }
  return clean;
}

buildCharacterSheetData = function buildCharacterSheetDataHf05b(pkg) {
  const legacy = sanitizeSheetCollections(buildCharacterSheetDataLegacyHf05b(pkg));
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const surface = (findJsonBlock(parsed, [/^(?:.*[\\/])?Character_Import_Surface\.json$/i, /character_import_surface\.hf05/i])?.data || findJsonBlock(parsed, [/Character_Import_Surface/i, /Import_Surface/i])?.data || null);
  const merged = (!surface || typeof surface !== "object")
    ? legacy
    : mergeImportSurfaceSheet(legacy, normalizeImportSurfaceSheet(surface, legacy));
  return sanitizeSheetCollections(finalizeSheetDisplayStats(merged));
};

function plainObjectPick(source = {}, keys = []) {
  if (!source || typeof source !== "object") return {};
  return keys.reduce((acc, key) => {
    if (source[key] !== undefined && source[key] !== null && source[key] !== "") acc[key] = source[key];
    return acc;
  }, {});
}

function truncateValue(value, max = 700) {
  const text = asDisplayText(value).replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1).trim()}...` : text;
}

function compactFeatureEntry(item, max = 260) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  return {
    name: entryDisplayName(item) || item.display_name || item.item_name || item.manual_name || item.style_name || item.passive_name || item.action_name || "Unnamed",
    acquisition_type: item.acquisition_type || item.type || item.category || "",
    status: item.status || "",
    summary: truncateValue(item.mechanical_summary || item.summary || item.description || item.effect || item.intent || item.source_text || item.damage_or_effect || item.mechanics || "", max),
    source: item.source_name || item.source_refs?.[0]?.source_name || item.source_file || item.source_refs?.[0]?.source_file || ""
  };
}


function compactForgedTechniqueEntry(item, max = 420) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  return {
    id: item.id || item.technique_id || item.forged_technique_id || "",
    technique_id: item.technique_id || item.forged_technique_id || item.id || "",
    name: forgedTechniqueDisplayName(item),
    display_name: item.display_name || item.name || item.technique_name || item.forged_technique_name || "",
    realm: item.realm || item.realm_gate || item.minimum_realm || "",
    grade: item.grade || item.rank || item.tier || "",
    cost: truncateValue(item.cost || item.resource_spent || item.activation_cost || "", 180),
    complexity: item.complexity || item.forge_complexity || item.acquisition_type || item.type || "",
    action_economy: item.action_economy || item.action_type || item.type || item.timing || "",
    trigger: truncateValue(item.trigger || item.use_condition || item.activation || "", 240),
    roll_save: truncateValue(item.roll_save || item.attack_or_save || item.check || item.save || "", 240),
    effect: truncateValue(item.effect || item.effects || item.damage_or_effect || item.resolution || item.summary || item.description || item.mechanics || item.intent || "", max),
    duration: truncateValue(item.duration || item.cleanup || item.expiry || "", 180),
    limit: truncateValue(item.limit || item.limits || item.uses || item.restrictions || "", 260),
    risk: truncateValue(item.risk || item.risks || item.strain || item.drawback || item.drawbacks || item.burden || "", 260),
    formula: truncateValue(item.formula || item.forging_formula || item.recipe || item.creation_notes || "", max),
    components: forgedTechniqueComponents(item).slice(0, 12),
    linked_action_id: item.linked_action_id || item.action_id || "",
    source: item.source_name || item.source || item.provenance || item.origin || item.source_file || "",
    status: item.status || item.source_status || ""
  };
}

function compactMartialArtEntry(item, max = 420) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  const forms = martialManualForms(item);
  const sphereList = Array.isArray(item.associated_spheres) ? item.associated_spheres : Array.isArray(item.routes_or_spheres) ? item.routes_or_spheres : [];
  const notGrantList = Array.isArray(item.does_not_grant) ? item.does_not_grant : item.grants_spheres === false ? ["Does not grant a sphere or talent."] : [];
  return {
    name: item.display_name || item.name || item.manual_name || item.style_name || "Unnamed Manual",
    status: item.status || item.source_status || "",
    source_or_teacher: item.source_or_teacher || item.source || item.source_name || item.source_status || "",
    doctrine: truncateValue(item.doctrine || item.summary || item.description || item.realm_gate || "", max),
    associated_spheres: sphereList.slice(0, 12),
    associated_talents: Array.isArray(item.associated_talents) ? item.associated_talents.slice(0, 20) : [],
    associated_techniques: Array.isArray(item.associated_techniques) ? item.associated_techniques.slice(0, 20) : forms.slice(0, 20).map((form) => entryDisplayName(form)).filter(Boolean),
    techniques: forms.slice(0, 24).map((technique) => compactMartialTechnique(technique, max)).filter(Boolean),
    equipment_or_body_requirements: Array.isArray(item.equipment_or_body_requirements) ? item.equipment_or_body_requirements.slice(0, 12) : [],
    advancement_hooks: Array.isArray(item.advancement_hooks) ? item.advancement_hooks.slice(0, 12) : [],
    does_not_grant: notGrantList.slice(0, 12),
    notes: truncateValue(item.notes || item.limits || "", max)
  };
}

function compactMartialTechnique(item, max = 420) {
  if (typeof item === "string") return { name: item };
  if (!item || typeof item !== "object") return null;
  return {
    technique_id: item.technique_id || item.form_id || item.id || "",
    name: item.name || item.display_name || item.form_name || "Unnamed Form",
    grade: item.grade || item.minimum_realm || item.realm || "",
    form_type: item.form_type || item.type || "",
    sphere_source: item.sphere_source || item.sphere || "",
    reproduces: item.reproduces || item.reproduced_ability || item.source_package || "",
    source_authority: item.source_authority || item.source || "",
    learned_from: item.learned_from || [
      Array.isArray(item.source_spheres) ? item.source_spheres.join(", ") : item.source_spheres || item.sphere_source || item.sphere,
      Array.isArray(item.source_talent_names) ? item.source_talent_names.join(", ") : item.source_talent_names
    ].map(asDisplayText).filter(Boolean).join(" — "),
    source_spheres: Array.isArray(item.source_spheres) ? item.source_spheres.slice(0, 12) : (item.source_spheres ? [item.source_spheres] : []),
    source_talent_ids: Array.isArray(item.source_talent_ids) ? item.source_talent_ids.slice(0, 24) : (item.source_talent_ids ? [item.source_talent_ids] : []),
    source_talent_names: Array.isArray(item.source_talent_names) ? item.source_talent_names.slice(0, 24) : (item.source_talent_names ? [item.source_talent_names] : []),
    source_packet_ids: Array.isArray(item.source_packet_ids) ? item.source_packet_ids.slice(0, 24) : (item.source_packet_ids ? [item.source_packet_ids] : []),
    act_action_refs: Array.isArray(item.act_action_refs) ? item.act_action_refs.slice(0, 24) : (item.act_action_refs ? [item.act_action_refs] : []),
    action_cost_policy: item.action_cost_policy || "",
    fixed_talent_expression: item.fixed_talent_expression || "",
    does_not_grant_policy: item.does_not_grant_policy || "",
    linked_action_id: item.linked_action_id || item.action_id || (Array.isArray(item.act_action_refs) ? item.act_action_refs[0] : item.act_action_refs) || "",
    linked_action_name: item.linked_action_name || "",
    action_type: item.action_type || "",
    cost: item.cost || "",
    range: item.range || "",
    target_rule: item.target_rule || item.target || "",
    resolution: truncateValue(item.resolution || item.attack_or_save || item.effect_summary || item.summary || "", max),
    effect_summary: truncateValue(item.effect_summary || item.effect || item.description || item.mechanical_summary || "", max),
    duration_cleanup: truncateValue(item.duration_cleanup || item.cleanup || item.duration || "", max),
    counterplay_limits: truncateValue(item.counterplay_limits || item.counterplay || item.limits || item.limit || "", max),
    practice_requirement: item.practice_requirement || item.practice || ""
  };
}

function compactFoundationEntry(item, max = 360) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  return {
    id: item.id || item.foundation_id || "",
    name: item.name || item.foundation_name || "Unnamed Foundation",
    family: item.family || item.foundation_family || "",
    depth: item.depth || "",
    stage: item.stage || "",
    dao_principle: truncateValue(item.dao_principle || "", max),
    origin: truncateValue(item.origin || "", max),
    known_player_text: item.known_player_text || {},
    foundation_type: item.foundation_type || item.type || "",
    foundation_family: item.foundation_family || item.family || "",
    mechanics_delta: item.mechanics_delta || "",
    mechanical_benefits_or_constraints: Array.isArray(item.mechanical_benefits_or_constraints) ? item.mechanical_benefits_or_constraints.slice(0, 20) : [],
    body_refining_interaction: Array.isArray(item.body_refining_interaction) ? item.body_refining_interaction.slice(0, 20) : [],
    burden_deviation_risks: Array.isArray(item.burden_deviation_risks) ? item.burden_deviation_risks.slice(0, 20) : [],
    breakthrough_relevance: Array.isArray(item.breakthrough_relevance) ? item.breakthrough_relevance.slice(0, 20) : [],
    does_not_grant_boundaries: Array.isArray(item.does_not_grant_boundaries) ? item.does_not_grant_boundaries.slice(0, 20) : [],
    formal_name: item.formal_name || item.name || item.foundation_name || "",
    epithet: item.epithet || "",
    foundation_catalogue_status: item.foundation_catalogue_status || "",
    foundation_provenance: item.foundation_provenance || item.provenance || {},
    mechanical_permissions: Array.isArray(item.mechanical_permissions) ? item.mechanical_permissions.slice(0, 12) : [],
    explicit_non_permissions: Array.isArray(item.explicit_non_permissions) ? item.explicit_non_permissions.slice(0, 12) : [],
    benefits: foundationListValues(item, ["benefits", "mechanical_benefits", "foundation_benefits"]).slice(0, 16),
    burdens: foundationListValues(item, ["burdens", "drawbacks", "foundation_burdens"]).slice(0, 16),
    triggers: foundationListValues(item, ["triggers", "trigger_registry", "foundation_triggers", "activation_triggers"]).slice(0, 16),
    counters: foundationListValues(item, ["counters", "counter_registry", "counter_closure", "countermeasures"]).slice(0, 16),
    permissions: foundationListValues(item, ["permissions"]).slice(0, 16),
    non_permissions: foundationListValues(item, ["non_permissions"]).slice(0, 16),
    status: item.status || "",
    source_status: item.source_status || "",
    realm_gate: item.realm_gate || "",
    core_doctrine: truncateValue(item.core_doctrine || "", max),
    disposition: truncateValue(item.disposition || "", max),
    import_correction: item.import_correction || ""
  };
}

function compactResourceEntry(item) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  const max = resourceDisplayNumber(item.maximum) !== "" ? item.maximum
    : resourceDisplayNumber(item.max) !== "" ? item.max
      : resourceDisplayNumber(item.value) !== "" ? item.value
        : resourceDisplayNumber(item.total) !== "" ? item.total
          : resourceDisplayNumber(item.current) !== "" ? item.current
            : resourceDisplayNumber(item.remaining) !== "" ? item.remaining : "";
  const current = resourceDisplayNumber(item.current) !== "" ? item.current
    : resourceDisplayNumber(item.current_default) !== "" ? item.current_default
      : resourceDisplayNumber(item.current_start) !== "" ? item.current_start
        : resourceDisplayNumber(item.start) !== "" ? item.start
          : resourceDisplayNumber(item.remaining) !== "" ? item.remaining : max;
  return {
    resource_id: item.resource_id || item.resource_key || String(item.resource_name || item.name || "").toLowerCase().replace(/[^a-z0-9]+/g, "_"),
    resource_name: item.resource_name || item.display_name || item.name || item.resource_id || "Resource",
    name: item.display_name || item.name || item.resource_name || item.resource_id || "Resource",
    current,
    maximum: max,
    temporary: item.temporary ?? "",
    recovery: truncateValue(item.recovery || item.reset_cadence || item.maximum_formula || item.resolution_basis || item.formula || "", 240),
    tracking_model: item.tracking_model || ""
  };
}

function compactActionEntry(action) {
  if (!action || typeof action !== "object") return action;
  const targeting = action.targeting || {};
  const resolution = action.resolution || {};
  const duration = action.duration || {};
  const bucket = canonicalEconomyBucket(action);
  const economyLabel = action.economy_label || action.action_economy || action.economy || (bucket === "bonus_action" ? "Bonus Action" : bucket ? titleCase(bucket.replace(/_/g, " ")) : "");
  return {
    action_id: action.action_id || action.id || "",
    action_name: action.display_name || action.action_name || action.name || action.option_name || "Unnamed Action",
    action_type: action.action_type || action.type || action.action_economy || action.event_pattern?.action_economy_slot || economyLabel || "",
    action_kind: action.action_kind || action.kind || "",
    action_economy: economyLabel,
    economy_label: economyLabel,
    economy_bucket: bucket,
    primary_economy_bucket: action.primary_economy_bucket || bucket,
    secondary_economy_buckets: Array.isArray(action.secondary_economy_buckets) ? action.secondary_economy_buckets.slice(0, 8) : [],
    is_composite: Boolean(action.is_composite || action.composite_id),
    composite_id: action.composite_id || "",
    gm_screen_category: action.gm_screen_category || "",
    cost: truncateValue(action.cost || action.resource_spent || "", 180),
    range_or_reach: action.range_or_reach || action.range || targeting.range_or_reach || targeting.range || "",
    target_rule: action.target_rule || action.target || targeting.target_rule || targeting.target || "",
    targeting: {
      range_or_reach: action.range_or_reach || action.range || targeting.range_or_reach || targeting.range || "",
      target_rule: action.target_rule || action.target || targeting.target_rule || targeting.target || "",
      sight_requirement: targeting.sight_requirement || targeting.requires_sight || "",
      cover_interaction: targeting.cover_interaction || targeting.cover || "",
      gate: action.targeting_gate || ""
    },
    attack_or_save: truncateValue(action.attack_or_save || resolution.attack_or_save || resolution.legacy_attack_or_save || resolution.attack_or_save_summary || (action.save_ability ? `${action.save_ability} save` : ""), 220),
    attack_bonus: resolution.attack_bonus ?? action.attack_bonus ?? "",
    save_dc: resolution.save_dc ?? action.save_dc ?? "",
    damage_or_effect: truncateValue(action.damage_or_effect || damageInstancesText(action.effect_packets) || resolution.legacy_effect_display || resolution.effects || resolution.authoritative_source_text || "", 900),
    duration: {
      display: duration.display || duration.text || truncateValue(duration, 160),
      concentration_required: Boolean(duration.concentration_required ?? action.concentration_required)
    },
    tags: Array.isArray(action.tags) ? action.tags.slice(0, 8) : [],
    source: Array.isArray(action.source) ? action.source.slice(0, 8) : action.source || action.source_name || ""
  };
}

function compactSheetData(sheet) {
  sheet = sanitizeSheetCollections(sheet || {});
  return {
    name: sheet.name,
    characterId: sheet.characterId,
    path: sheet.path,
    realm: sheet.realm,
    cultivationLevel: sheet.cultivationLevel,
    keyAbility: sheet.keyAbility,
    proficiencyBonus: sheet.proficiencyBonus,
    cultivationAttackBonus: sheet.cultivationAttackBonus,
    cultivationSaveDc: sheet.cultivationSaveDc,
    attacksPerAttackAction: sheet.attacksPerAttackAction,
    physicalDescription: truncateValue(sheet.physicalDescription || "", 700),
    background: sheet.background || null,
    foundations: (sheet.foundations || []).map((item) => compactFoundationEntry(item, 360) || item).filter(Boolean),
    chakraRecord: truncateValue(sheet.chakraRecord || "", 700),
    hp: plainObjectPick(sheet.hp, ["maximum", "max", "current", "current_default", "temporary", "formula"]),
    ac: plainObjectPick(sheet.ac, ["base", "current", "normal", "active", "ac", "ac_base", "ac_active", "ac_alt", "armor_class", "liming_radiant_gown", "formula", "notes"]),
    speed: sheet.speed,
    resources: (sheet.resources || []).map(compactResourceEntry).filter(Boolean),
    spheres: (sheet.spheres || []).map(asDisplayText).filter(Boolean),
    talents: (sheet.talents || []).map((item) => compactFeatureEntry(item)).filter(Boolean),
    insights: (sheet.insights || []).map((item) => compactFeatureEntry(item)).filter(Boolean),
    forgedTechniques: (sheet.forgedTechniques || []).map((item) => compactForgedTechniqueEntry(item)).filter(Boolean),
    weapons: (sheet.weapons || []).map((item) => (typeof item === "string" ? item : {
      name: item.name || "Attack",
      attack_bonus: item.attack_bonus ?? "",
      damage: item.damage || item.damage_or_effect || "",
      range: item.range || "",
      properties: Array.isArray(item.properties) ? item.properties.slice(0, 8) : []
    })).filter(Boolean),
    actions: (sheet.actions || []).map(compactActionEntry).filter(Boolean),
    states: (sheet.states || []).map((item) => compactFeatureEntry(item, 180)).filter(Boolean),
    passives: (sheet.passives || []).map((item) => compactFeatureEntry(item, 220)).filter(Boolean),
    assets: (sheet.assets || []).map((item) => compactFeatureEntry(item, 260)).filter(Boolean),
    equipment: (sheet.equipment || []).map((item) => compactFeatureEntry(item, 180) || asDisplayText(item)).filter(Boolean),
    consumables: (sheet.consumables || []).map((item) => compactFeatureEntry(item, 180) || asDisplayText(item)).filter(Boolean),
    martialArtsLearned: (sheet.martialArtsLearned || []).map((item) => compactMartialArtEntry(item, 420) || asDisplayText(item)).filter(Boolean),
    senses: (sheet.senses || []).map(asDisplayText).filter(Boolean),
    skills: sheet.skills || {},
    abilityScores: sheet.abilityScores || {},
    abilityModifiers: sheet.abilityModifiers || {},
    saves: sheet.saves || {},
    resistances: (sheet.resistances || []).map(asDisplayText).filter(Boolean),
    immunities: (sheet.immunities || []).map(asDisplayText).filter(Boolean),
    vulnerabilities: (sheet.vulnerabilities || []).map(asDisplayText).filter(Boolean)
  };
}

function compactSupportBlocks(blocks = []) {
  if (!Array.isArray(blocks)) return [];
  const supportPattern = /(?:Character_Import_Surface|Combat_Playbook|Composite_Action_Registry|Composite_Playbook_Registry|Talent_Augmentation_Registry|Forged_Technique_Registry|Character_Action_Registry|Complete_Action_Surface|Temporal_Feasibility_Registry|State_Window_Lock_Audit|Execution_Block_Registry|Field_Object_Registry|Combat_State_Ledger_Template|Live_Combat_State_Audit|Dao_Combat_Behavior_Profile|Foundation_Registry|Martial_Arts_and_Manuals|Martial_Manual_Registry|Legal_Talent_Inventory|GM_Screen_Projection_Rows|GM_Screen_Display_Rows|Martial_Manual_Display_Rows|Foundation_Display_Row)\.(?:json|md)$/i;
  return blocks
    .filter((block) => supportPattern.test(String(block?.name || "")))
    .map((block) => ({ name: block.name, content: block.content }));
}

function compactSavedPackage(pkg) {
  const sheetData = compactSheetData(pkg.sheetData || buildCharacterSheetData(pkg));
  return {
    id: pkg.id || makeId("pkg"),
    created: pkg.created,
    updated: pkg.updated,
    name: sheetData.name || pkg.name,
    version: pkg.version || "unversioned",
    path: pkg.path || sheetData.path || "",
    realm: pkg.realm || sheetData.realm || "",
    primary: pkg.primary || sheetData.spheres?.[0] || "",
    secondary: pkg.secondary || sheetData.spheres?.find((name) => name !== (pkg.primary || sheetData.spheres?.[0])) || "",
    daoPhrase: pkg.daoPhrase || "",
    detected: Array.isArray(pkg.detected) ? pkg.detected.slice(0, 8) : [],
    artifacts: pkg.artifacts || {},
    readiness: pkg.readiness || "simulation-ready",
    sheetData,
    sourcePackageKey: pkg.sourcePackageKey || importSourcePackageKeyFromBlocks(pkg.blocks || []),
    blocks: compactSupportBlocks(pkg.blocks),
    compact: true
  };
}

let builderSphereNames = [];

const TIANXIA_BACKGROUNDS = window.TIANXIA_BACKGROUND_CATALOG || {};

const PATH_BUILDER_DEFAULTS = {
  "Body Refining": { key: "Constitution", hitDie: 12, resource: "Stamina", saveProficiencies: [], acMode: "body" },
  "Qi Cultivation": { key: "Intelligence", hitDie: 8, resource: "Qi", saveProficiencies: [], acMode: "light" },
  "Spirit Awakening": { key: "Wisdom", hitDie: 8, resource: "Resonance", saveProficiencies: [], acMode: "light" },
  Chakra: { key: "Constitution", hitDie: 10, resource: "Chakra Points", saveProficiencies: [], acMode: "light" },
  "Mixed / Special": { key: "Wisdom", hitDie: 8, resource: "Cultivation Points", saveProficiencies: [], acMode: "light" }
};

function builderConfig(pathName = "") {
  return PATH_BUILDER_DEFAULTS[pathName] || PATH_BUILDER_DEFAULTS["Mixed / Special"];
}


function foundationCatalogKey(value = "") {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

function foundationKnownValue(item = {}, key = "") {
  const known = item.known_player_text || item.known || item.player_known || {};
  const aliases = {
    summary: ["summary", "common_knowledge", "text", "description"],
    sign: ["sign", "visible_sign", "known_sign"],
    benefit: ["benefit", "known_benefit", "mechanical_benefit"],
    warning: ["warning", "known_warning", "risk"]
  }[key] || [key];
  for (const alias of aliases) {
    if (known && known[alias]) return asDisplayText(known[alias]);
    if (item[alias]) return asDisplayText(item[alias]);
  }
  return "";
}

function foundationPrimaryFamily(item = {}) {
  const raw = Array.isArray(item.family) ? item.family[0] : (item.family || item.foundation_family || "qi_root");
  const key = foundationCatalogKey(raw);
  if (key.includes("tempering")) return "tempering_record";
  if (key.includes("qi_root")) return "qi_root";
  if (key.includes("meridian")) return "meridian_imprint";
  if (key.includes("soul")) return "soul_anchor";
  if (key.includes("domain")) return "domain_seed";
  if (key.includes("hybrid") || key.includes("constitution") || key.includes("bloodline")) return "hybrid_constitution";
  if (key.includes("injury")) return "hidden_injury";
  if (key.includes("deviation")) return "deviation_seed";
  return key || "qi_root";
}

function foundationDepthKey(value = "") {
  const key = foundationCatalogKey(value);
  if (key.includes("mythic")) return "mythic";
  if (key.includes("major")) return "major";
  if (key.includes("notable")) return "notable";
  if (key.includes("minor")) return "minor";
  return key || "minor";
}

function foundationStageKey(value = "") {
  const key = foundationCatalogKey(value);
  if (key.includes("common")) return "common_expression";
  if (key.includes("awakened")) return "awakened";
  if (key.includes("integrated")) return "integrated";
  if (key.includes("refined")) return "refined";
  if (key.includes("perfected")) return "perfected";
  if (key.includes("lineage")) return "lineage_bearing";
  if (key.includes("unstable")) return "unstable";
  if (key.includes("latent")) return "latent";
  return key || "latent";
}


function foundationStageLabel(value = "") {
  const key = foundationStageKey(value);
  return titleCase(key.replace(/_/g, " "));
}

function currentBuilderFoundationStageKey() {
  return foundationStageKey($("builderFoundationStage")?.value || "");
}

function foundationReadableToken(value = "") {
  const text = String(value || "").replace(/_/g, " ").replace(/\s+/g, " ").trim();
  if (!text) return "";
  const acronyms = new Set(["cp", "pb", "hp", "dc", "qi", "str", "dex", "con", "int", "wis", "cha"]);
  return text.split(" ").map((word) => {
    const lower = word.toLowerCase();
    if (acronyms.has(lower)) return lower.toUpperCase() === "QI" ? "Qi" : lower.toUpperCase();
    return word ? word[0].toUpperCase() + word.slice(1) : word;
  }).join(" ");
}

const FOUNDATION_RULE_TEXT_OVERRIDES = {
  cp: "CP",
  pb: "PB",
  hp: "HP",
  dc: "DC",
  qi: "Qi",
  short_rest: "once per short rest",
  long_rest: "once per long rest",
  once_per_turn: "once per turn",
  once_per_round: "once per round",
  bonus_action: "bonus action",
  reaction: "reaction",
  no_action: "no action",
  until_end_next_turn: "until the end of the next turn",
  end_current_turn: "until the end of the current turn",
  end_field_add_binding_recoil_progress_2: "the field ends and Binding Recoil progresses by 2",
  after_spend_cp_on_containment_technique: "after you spend CP on a containment technique",
  would_reduce_creature_to_zero: "when you would reduce a creature to 0 HP",
  creature_teleports_escapes_restraint_breaks_seal_or_moves_after_restraint: "when a creature teleports, escapes restraint, breaks a seal, or moves after being restrained",
  difficult_terrain_for_hostiles: "Hostile creatures treat the area as difficult terrain",
  difficult_terrain_for_hostiles_affected_by_user_containment: "Hostile creatures affected by your containment treat the area as difficult terrain",
  suppress_escape_options: "Suppress an escape option",
  instead_restrain_at_one_hp: "Restrain the target at 1 HP instead of reducing it to 0 HP",
  set_speed: "Set speed to 0",
  damage_reduction: "Reduce damage.",
  grant_advantage: "Grant advantage.",
  impose_disadvantage: "Impose disadvantage.",
  forced_movement: "forced movement",
  teleportation: "teleportation",
  teleportation_displacement: "teleportation or displacement",
  phasing: "phasing",
  invisibility: "invisibility",
  possession: "possession",
  domination: "domination",
  restraint: "restraint",
  chosen_allies: "chosen allies",
  hostile_creatures_realm_lte_user: "hostile creatures at or below your realm",
  source_realm_lte_user_realm: "source is at or below your realm",
  proficiency_bonus: "PB",
  key_ability_modifier: "key ability modifier"
};

function foundationRuleText(value = "", { sentence = false } = {}) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  const raw = String(value || "").trim();
  if (!raw) return "";
  const key = foundationCatalogKey(raw);
  const overridden = FOUNDATION_RULE_TEXT_OVERRIDES[key];
  let text = overridden || raw
    .replace(/_/g, " ")
    .replace(/\bcp\b/gi, "CP")
    .replace(/\bpb\b/gi, "PB")
    .replace(/\bhp\b/gi, "HP")
    .replace(/\bdc\b/gi, "DC")
    .replace(/\bqi\b/gi, "Qi")
    .replace(/\bproficiency bonus\b/gi, "PB")
    .replace(/\buser\b/gi, "your")
    .replace(/\bhostiles\b/gi, "hostile creatures")
    .replace(/\blte\b/gi, "at or below")
    .replace(/\bcreature\b/gi, "creature")
    .replace(/\bs([0-9])\b/gi, "severity $1")
    .replace(/\s+/g, " ")
    .trim();
  if (sentence && text && !/[.!?]$/.test(text)) text += ".";
  return text;
}

function foundationRuleListText(items = []) {
  return (Array.isArray(items) ? items : [items]).map((item) => foundationRuleText(item)).filter(Boolean).join(", ");
}

function foundationDisplayValue(value) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return foundationRuleText(value);
  if (Array.isArray(value)) return value.map(foundationDisplayValue).filter(Boolean).join(", ");
  if (typeof value === "object") {
    return foundationDisplayValue(value.display)
      || foundationDisplayValue(value.legacy_display)
      || foundationDisplayValue(value.canonical_text)
      || foundationDisplayValue(value.authoritative_source_text)
      || foundationDisplayValue(value.player_text)
      || foundationDisplayValue(value.dm_text)
      || foundationDisplayValue(value.rules_text)
      || foundationEffectSummary(value);
  }
  return String(value);
}

function foundationCostSummary(cost) {
  if (!cost) return "";
  if (typeof cost === "string" || typeof cost === "number") return foundationRuleText(cost);
  if (Array.isArray(cost)) return cost.map(foundationCostSummary).filter(Boolean).join("; ");
  if (typeof cost === "object") {
    const resource = cost.resource || cost.type || cost.name || "";
    const amount = cost.amount ?? cost.value ?? cost.cost ?? "";
    if (resource && amount !== "") return `${amount} ${foundationRuleText(resource)}`;
    return Object.entries(cost)
      .filter(([, value]) => value !== null && value !== undefined && value !== "")
      .map(([key, value]) => `${foundationReadableToken(key)} ${foundationCostSummary(value)}`.trim())
      .join("; ");
  }
  return String(cost);
}

function foundationTriggerSummary(trigger = {}) {
  if (!trigger) return "";
  if (typeof trigger === "string") return foundationRuleText(trigger);
  if (Array.isArray(trigger)) return trigger.map(foundationTriggerSummary).filter(Boolean).join("; ");
  if (typeof trigger !== "object") return String(trigger);
  const events = [
    ...(trigger.events_any || []),
    ...(trigger.event_tags_any || []),
    ...(trigger.tags_any || []),
    ...(trigger.save_tags_any || []),
    ...(trigger.threshold_tags_any || []),
    ...(trigger.source_tags_any || [])
  ].map((item) => foundationRuleText(item)).filter(Boolean);
  const condition = trigger.condition || trigger.when || trigger.text || trigger.summary || "";
  const range = trigger.range_ft ? `within ${trigger.range_ft} ft` : "";
  return [condition ? foundationDisplayValue(condition) : "", events.length ? events.join(", ") : "", range].filter(Boolean).join(" — ");
}

function foundationEffectSummary(effect = {}) {
  if (!effect) return "";
  if (typeof effect === "string") return foundationRuleText(effect);
  if (Array.isArray(effect)) return effect.map(foundationEffectSummary).filter(Boolean).join("; ");
  if (typeof effect !== "object") return String(effect);
  const explicit = foundationDisplayValue(effect.display || effect.legacy_display || effect.canonical_text || effect.authoritative_source_text || effect.player_text || effect.dm_text || effect.rules_text || effect.text || effect.description || effect.summary || "");
  if (explicit) return explicit;
  const type = foundationCatalogKey(effect.type || "");
  if (type === "add_die") return `add ${effect.die || effect.amount || "a die"}`;
  if (type === "add_bonus") return `add ${foundationRuleText(effect.amount_formula || effect.amount || "bonus")}`;
  if (type === "damage_reduction") return `reduce damage by ${foundationRuleText(effect.amount_formula || effect.amount || "foundation amount")}`;
  if (type === "move_without_opportunity") return `move ${effect.distance_ft || effect.distance || ""} ft without provoking opportunity attacks`.replace(/\s+/g, " ").trim();
  if (type === "teleport") return `teleport ${effect.distance_ft || effect.distance || ""} ft${effect.requires_line_of_sight ? " with line of sight" : ""}`.replace(/\s+/g, " ").trim();
  if (type === "mark_return_anchor") return `mark a return anchor${effect.duration ? ` until ${foundationRuleText(effect.duration)}` : ""}`;
  if (type === "grant_advantage") return `grant advantage${effect.targets ? ` to ${foundationRuleText(effect.targets)}` : ""}${effect.save_tags_any?.length ? ` against ${foundationRuleListText(effect.save_tags_any)}` : ""}`;
  if (type === "impose_disadvantage") return `impose disadvantage${effect.targets ? ` on ${foundationRuleText(effect.targets)}` : ""}`;
  if (type === "teleport_after_cp_spend") return `after spending CP, teleport ${effect.distance_ft || effect.distance || ""} ft${effect.frequency ? ` ${foundationRuleText(effect.frequency)}` : ""}`.replace(/\s+/g, " ").trim();
  if (type === "difficult_terrain_for_hostiles" || type === "difficult_terrain_for_hostiles_affected_by_user_containment") return foundationRuleText(type);
  if (type === "instead_restrain_at_one_hp") return foundationRuleText(type);
  if (type === "set_speed") return `set speed to ${effect.amount ?? 0}${effect.duration ? ` until ${foundationRuleText(effect.duration)}` : ""}`;
  if (type === "suppress_escape_options") {
    const details = [
      effect.frequency ? foundationRuleText(effect.frequency) : "",
      effect.trigger ? foundationRuleText(effect.trigger) : "",
      effect.suppressed_tags?.length ? `options: ${foundationRuleListText(effect.suppressed_tags)}` : "",
      effect.save_options?.length ? `save: ${foundationRuleListText(effect.save_options)}` : ""
    ].filter(Boolean).join("; ");
    return `${foundationRuleText(type)}${details ? ` (${details})` : ""}`;
  }
  const fallbackType = type ? foundationRuleText(type, { sentence: true }) : "";
  const details = Object.entries(effect)
    .filter(([key, value]) => key !== "type" && value !== null && value !== undefined && value !== "")
    .map(([key, value]) => `${foundationReadableToken(key)}: ${foundationDisplayValue(value)}`)
    .filter(Boolean)
    .join("; ");
  return [fallbackType, details].filter(Boolean).join(" ");
}

function foundationStageBenefitLine(entry = {}) {
  if (!entry) return "";
  if (typeof entry === "string") return entry;
  const name = entry.name || entry.title || (entry.benefit_id ? foundationReadableToken(entry.benefit_id) : "Foundation Benefit");
  const cadence = entry.frequency ? foundationRuleText(entry.frequency) : "";
  const action = entry.action_type ? foundationRuleText(entry.action_type) : "";
  const cost = foundationCostSummary(entry.cost);
  const trigger = foundationTriggerSummary(entry.trigger);
  const effect = foundationEffectSummary(entry.effect)
    || foundationEffectSummary(entry.effects)
    || (entry.effect_options ? `choose: ${foundationEffectSummary(entry.effect_options)}` : "")
    || asDisplayText(entry.description || entry.summary || entry.text || "");
  const risks = [entry.absence_risk, entry.end_risk]
    .map((risk) => risk ? foundationEffectSummary(risk.effect || risk) : "")
    .filter(Boolean);
  const meta = [cadence, action, cost ? `Cost ${cost}` : ""].filter(Boolean).join("; ");
  return [name, meta, trigger ? `when ${trigger}` : "", effect, risks.length ? `Risk: ${risks.join("; ")}` : ""].filter(Boolean).join(" — ");
}

function foundationStageBenefitEntries(item = {}, stage = "") {
  const stageKey = foundationStageKey(stage || item.stage || item.default_stage || "");
  const benefits = item.stage_benefits || item.stage_benefit_map || {};
  const direct = benefits?.[stageKey];
  if (Array.isArray(direct)) return direct;
  if (direct) return [direct];
  if ((stageKey === "latent" || stageKey === "unstable") && benefits?.common_expression) return [];
  return [];
}

function foundationStageBenefitText(item = {}, stage = "") {
  const entries = foundationStageBenefitEntries(item, stage);
  const text = entries.map(foundationStageBenefitLine).filter(Boolean).join("; ");
  return text || foundationKnownValue(item, "benefit") || item.stage_benefits_summary?.common_expression || item.stage_benefits_summary?.awakened || "";
}

function foundationStageBurdenText(item = {}, stage = "") {
  const burdens = Array.isArray(item.burdens) ? item.burdens : (item.burdens ? [item.burdens] : []);
  const base = burdens.map((burden) => {
    if (typeof burden === "string") return foundationReadableToken(burden);
    const name = foundationPressureName(burden, "Foundation Burden");
    const text = foundationPressureText(burden);
    return text ? `${name} — ${text}` : name;
  }).filter(Boolean).join("; ");
  const stageRisks = foundationStageBenefitEntries(item, stage).flatMap((entry) => [entry.absence_risk, entry.end_risk]).filter(Boolean)
    .map((risk) => foundationEffectSummary(risk.effect || risk)).filter(Boolean);
  return [base, stageRisks.length ? `Stage risk: ${stageRisks.join("; ")}` : ""].filter(Boolean).join("; ");
}

function foundationCatalogBySelection(value = "") {
  const key = String(value || "").toLowerCase();
  return FOUNDATION_CATALOG_BY_ID.get(key) || FOUNDATION_CATALOG_BY_NAME.get(key) || null;
}

function foundationCatalogNotes(item = {}, stage = "") {
  if (!item) return "";
  const stageKey = foundationStageKey(stage || item.stage || item.default_stage || "");
  const stageBenefit = foundationStageBenefitText(item, stageKey);
  const stageBurden = foundationStageBurdenText(item, stageKey);
  const lines = [
    item.origin ? `Origin: ${foundationDisplayValue(item.origin)}` : "",
    item.dao_principle ? `Dao Principle: ${foundationDisplayValue(item.dao_principle)}` : "",
    stageKey ? `Stage: ${foundationStageLabel(stageKey)}` : "",
    foundationKnownValue(item, "summary") ? `Known: ${foundationKnownValue(item, "summary")}` : "",
    foundationKnownValue(item, "sign") ? `Sign: ${foundationKnownValue(item, "sign")}` : "",
    stageBenefit ? `Benefit: ${stageBenefit}` : "",
    foundationKnownValue(item, "warning") ? `Warning: ${foundationKnownValue(item, "warning")}` : "",
    item.sphere_interfaces?.compatible_spheres?.length ? `Compatible Spheres: ${item.sphere_interfaces.compatible_spheres.map(foundationRuleText).join(", ")}` : "",
    item.sphere_interfaces?.conditional_spheres_unlocked?.length ? `Conditional Spheres: ${item.sphere_interfaces.conditional_spheres_unlocked.map(foundationRuleText).join(", ")}` : "",
    stageBurden ? `Burden: ${stageBurden}` : ""
  ].filter(Boolean);
  return lines.join("\n");
}

function ensureSelectValue(select, value, label = value) {
  if (!select || !value) return;
  const exists = [...select.options].some((option) => option.value === value);
  if (!exists) select.appendChild(new Option(label, value));
}


function foundationCatalogSetValue() {
  return $("builderFoundationCatalogSet")?.value || "foundation_split_v0_3B";
}
function foundationCatalogGroup(item = {}) {
  if (item.catalog_set === "foundation_split_v0_3B") return "canonical";
  if (item.catalog_set === "legacy_non_chakra_phase_out") return "legacy";
  if (/^chakra(?:_|$)/i.test(String(item.catalog_set || "")) || /^chakra$/i.test(String(item.primary_path || ""))) return "chakra";
  return "legacy";
}
function foundationRuntimeItemText(item, fallback = "Record") {
  if (typeof item === "string") return foundationReadableToken(item);
  const name = item?.name || item?.display_name || item?.resource_name || item?.action_name || item?.state_name || item?.title || item?.id || fallback;
  const effect = item?.summary || item?.description || item?.effect_summary || item?.damage_or_effect || item?.gm_screen_text || item?.mechanics || item?.effect;
  const text = effect ? foundationDisplayValue(effect) : "";
  return text && text !== name ? `${name} — ${text}` : name;
}
function foundationCatalogLifecycleText(item = {}) {
  const runtime = item.runtime_record || {};
  const groups = [
    ["Passive chassis", runtime.passives], ["Resources", runtime.resources], ["Actions / reactions", runtime.actions],
    ["States", runtime.states], ["Burdens", runtime.burdens || item.burdens],
    ["Hidden injuries", runtime.hidden_injuries || item.hidden_injuries], ["Strains", runtime.strains || item.strains],
    ["Deviations", runtime.deviations || item.deviations], ["Integration / repair", runtime.repair_practices],
    ["Foundation challenge routes", runtime.challenge_actions], ["Lineage-bearing routes", runtime.lineage_actions]
  ];
  const lines=[];
  groups.forEach(([label,rows]) => {
    const values=(Array.isArray(rows)?rows:(rows?[rows]:[])).map((row)=>foundationRuntimeItemText(row,label)).filter(Boolean);
    if(values.length) lines.push(`${label}: ${values.join("; ")}`);
  });
  const boundary=item.foundation_display_row?.does_not_grant_boundaries || item.fixed_scope?.does_not_grant || item.fixed_scope?.boundaries;
  if(boundary) {
    const values=(Array.isArray(boundary)?boundary:[boundary]).map(foundationDisplayValue).filter(Boolean);
    if(values.length) lines.push(`Does not grant: ${values.join("; ")}`);
  }
  return lines.join("\n");
}
function fillFoundationCatalogSelect() {
  const select = $("builderFoundationCatalogSelect");
  if (!select) return;
  const current = select.value;
  const view = foundationCatalogSetValue();
  const groups = [
    { key:"canonical", label:"Foundation Split v0.3B — FS01–FS30 (recommended)" },
    { key:"chakra", label:"Chakra Foundations — CH numbering" },
    { key:"legacy", label:"Legacy non-Chakra — phase-out" }
  ];
  select.innerHTML = `<option value="">Custom Foundation</option>`;
  groups.forEach((group) => {
    if (view !== "all" && view !== group.key && !(view === "foundation_split_v0_3B" && group.key === "canonical")) return;
    const rows=FOUNDATION_CATALOG.filter((item)=>foundationCatalogGroup(item)===group.key)
      .sort((a,b)=>String(a.catalog_code||"").localeCompare(String(b.catalog_code||""),undefined,{numeric:true}) || String(a.name||"").localeCompare(String(b.name||"")));
    if(!rows.length) return;
    const optgroup=document.createElement("optgroup"); optgroup.label=group.label;
    rows.forEach((item)=>{
      const option=document.createElement("option"); option.value=item.id||item.name;
      const chunk=item.source_chunk||item.chunk; const grade=item.foundation_grade||item.depth;
      option.textContent=`${item.catalog_code||"--"} · ${item.name||item.id}${chunk?` [${chunk}]`:""}${grade?` — ${grade}`:""}`;
      optgroup.appendChild(option);
    });
    select.appendChild(optgroup);
  });
  if (current && [...select.options].some((item) => item.value === current)) select.value = current;
  else select.value = "";
}

function applyBuilderFoundationCatalogSelection() {
  const selected = foundationCatalogBySelection($("builderFoundationCatalogSelect")?.value || "");
  if (!selected) {
    if ($("builderFoundationPreview")) $("builderFoundationPreview").innerHTML = `Custom foundation mode. Enter the foundation fields manually.`;
    updateBuilderPreview();
    return;
  }
  if ($("builderFoundationName")) $("builderFoundationName").value = selected.name || "";
  if ($("builderFoundationCatalogCode")) $("builderFoundationCatalogCode").value = selected.catalog_code || "";
  if ($("builderFoundationGrade")) $("builderFoundationGrade").value = selected.foundation_grade || selected.depth || "";
  if ($("builderFoundationFamily")) {
    const family = foundationPrimaryFamily(selected);
    ensureSelectValue($("builderFoundationFamily"), family, titleCase(family.replace(/_/g, " ")));
    $("builderFoundationFamily").value = family;
  }
  if ($("builderFoundationDepth")) {
    const depth = foundationDepthKey(selected.depth);
    ensureSelectValue($("builderFoundationDepth"), depth, titleCase(depth.replace(/_/g, " ")));
    $("builderFoundationDepth").value = depth;
  }
  if ($("builderFoundationStage")) {
    const stage = foundationStageKey(selected.stage || selected.default_stage);
    ensureSelectValue($("builderFoundationStage"), stage, titleCase(stage.replace(/_/g, " ")));
    $("builderFoundationStage").value = stage;
  }
  const selectedStage = foundationStageKey($("builderFoundationStage")?.value || selected.stage || selected.default_stage || "");
  if ($("builderFoundationNotes")) $("builderFoundationNotes").value = foundationCatalogNotes(selected, selectedStage);
  if ($("builderFoundationLifecycle")) $("builderFoundationLifecycle").value = foundationCatalogLifecycleText(selected);
  if ($("builderFoundationPreview")) $("builderFoundationPreview").innerHTML = foundationBuilderPreviewHtml(selected, selectedStage);
  updateBuilderPreview();
}

function foundationBuilderPreviewHtml(item = {}, stage = "") {
  if (!item || !item.name) return `Custom foundation mode. Enter the foundation fields manually.`;
  const stageKey = foundationStageKey(stage || item.stage || item.default_stage || "");
  const compatible = item.sphere_interfaces?.compatible_spheres || [];
  const conditional = item.sphere_interfaces?.conditional_spheres_unlocked || [];
  const stageBenefit = foundationStageBenefitText(item, stageKey);
  const stageBurden = foundationStageBurdenText(item, stageKey);
  return `
    <strong>${escapeHtml(item.catalog_code ? `${item.catalog_code} · ${item.name}` : item.name)}</strong>
    <span class="foundation-pill">${escapeHtml(item.foundation_grade || titleCase(String(item.depth || "minor").replace(/_/g, " ")))}</span>
    ${item.source_chunk || item.chunk ? `<span class="foundation-pill">Source ${escapeHtml(item.source_chunk || item.chunk)}</span>` : ""}
    ${item.catalog_status === "legacy_phase_out" ? `<span class="foundation-pill tone-warning">Legacy / phase-out</span>` : `<span class="foundation-pill tone-ready">Audited v0.3B</span>`}
    <span class="foundation-pill tone-ready">${escapeHtml(foundationStageLabel(stageKey))}</span>
    <p>${escapeHtml(item.dao_principle || foundationKnownValue(item, "summary") || "No doctrine recorded.")}</p>
    ${stageBenefit ? `<p><strong>${escapeHtml(foundationStageLabel(stageKey))} Benefit:</strong> ${escapeHtml(stageBenefit)}</p>` : ""}
    ${compatible.length ? `<p><strong>Compatible:</strong> ${escapeHtml(compatible.slice(0, 12).map(foundationRuleText).join(", "))}</p>` : ""}
    ${conditional.length ? `<p><strong>Conditional:</strong> ${escapeHtml(conditional.slice(0, 12).map(foundationRuleText).join(", "))}</p>` : ""}
    ${stageBurden ? `<p><strong>${escapeHtml(foundationStageLabel(stageKey))} Burden:</strong> ${escapeHtml(stageBurden)}</p>` : ""}
  `;
}

function applyBuilderFoundationStageSelection() {
  const selected = selectedBuilderFoundationCatalog();
  if (!selected) {
    updateBuilderPreview();
    return;
  }
  const stage = currentBuilderFoundationStageKey();
  if ($("builderFoundationNotes")) $("builderFoundationNotes").value = foundationCatalogNotes(selected, stage);
  if ($("builderFoundationPreview")) $("builderFoundationPreview").innerHTML = foundationBuilderPreviewHtml(selected, stage);
  updateBuilderPreview();
}

function selectedBuilderFoundationCatalog() {
  return foundationCatalogBySelection($("builderFoundationCatalogSelect")?.value || "");
}

function cloneFoundationRecord(item = {}) {
  return JSON.parse(JSON.stringify(item || {}));
}

function foundationBenefitCost(text = "") {
  const value = String(text || "");
  const match = value.match(/once per (short rest|long rest|round|scene|turn)/i);
  return match ? `Once per ${match[1].toLowerCase()}` : "Foundation cadence / GM trigger";
}

function foundationRouteText(routes = []) {
  if (!Array.isArray(routes)) return foundationDisplayValue(routes);
  return routes.map((route) => {
    if (typeof route === "string") return foundationRuleText(route);
    return [route.route || route.name || route.type, route.text || route.summary || route.effect]
      .map(foundationDisplayValue)
      .filter(Boolean)
      .join(": ");
  }).filter(Boolean).join("; ");
}

function foundationPressureName(item, fallback = "Foundation Pressure") {
  if (typeof item === "string") return foundationReadableToken(item);
  return foundationReadableToken(item?.name || item?.burden || item?.title || fallback);
}

function foundationPressureText(item) {
  if (typeof item === "string") return "";
  if (!item || typeof item !== "object") return "";
  return [
    item.trigger && `Trigger: ${foundationDisplayValue(item.trigger)}`,
    item.default_effect && `Effect: ${foundationDisplayValue(item.default_effect)}`,
    item.temporary_effect && `Temporary Effect: ${foundationDisplayValue(item.temporary_effect)}`,
    item.benefit_offered && `Temptation Benefit: ${foundationDisplayValue(item.benefit_offered)}`,
    item.cost && `Cost: ${foundationCostSummary(item.cost)}`,
    item.suppression && `Suppression: ${foundationDisplayValue(item.suppression)}`,
    item.correction && `Correction: ${foundationDisplayValue(item.correction)}`
  ].filter(Boolean).join(" ");
}

function builderFoundationActionTemplates(foundation = {}, ownerName = "") {
  const name = foundationDisplayName(foundation);
  const idBase = foundationCatalogKey(foundation.id || name || ownerName || "foundation");
  const benefit = foundationStageBenefitText(foundation, foundation.stage) || "Foundation benefit not recorded.";
  const warning = foundationKnownValue(foundation, "warning");
  const burden = Array.isArray(foundation.burdens) ? foundation.burdens[0] : null;
  const challenges = foundation.foundation_challenge_options || foundation.advancement_routes || [];
  const actions = [];
  if (benefit && benefit !== "Foundation benefit not recorded.") {
    actions.push({
      action_id: `foundation_${idBase}_benefit`,
      action_name: `Foundation Benefit — ${name}`,
      display_name: `Foundation Benefit — ${name}`,
      action_type: "No Action / Conditional",
      cost: foundationBenefitCost(benefit),
      attack_or_save: "Applies to the qualifying check/save described by the Foundation.",
      damage_or_effect: benefit,
      targeting: { target_rule: "Self; qualifying Foundation trigger" },
      resolution: { legacy_effect_display: benefit },
      limit: foundationBenefitCost(benefit),
      source: name,
      tags: ["builder", "foundation", "autofilled"]
    });
  }
  if (burden) {
    const burdenName = foundationPressureName(burden, name);
    const effect = foundationPressureText(burden) || `Track ${burdenName} Foundation pressure.`;
    actions.push({
      action_id: `foundation_${idBase}_burden_watch`,
      action_name: `Foundation Burden Watch — ${burdenName}`,
      display_name: `Foundation Burden Watch — ${burdenName}`,
      action_type: "GM Trigger / Passive",
      cost: "Burden Severity as tracked",
      attack_or_save: (typeof burden === "object" && burden?.resistance) || "Foundation Challenge / relevant save as fiction demands",
      damage_or_effect: effect,
      targeting: { target_rule: "Self; Foundation stress condition" },
      resolution: { legacy_effect_display: effect },
      source: name,
      tags: ["builder", "foundation", "burden", "autofilled"]
    });
  }
  if (challenges && foundationRouteText(challenges)) {
    const text = foundationRouteText(challenges);
    actions.push({
      action_id: `foundation_${idBase}_challenge`,
      action_name: `Foundation Challenge — ${name}`,
      display_name: `Foundation Challenge — ${name}`,
      action_type: "Cultivation Scene / Downtime",
      cost: "Scene time, CXP pressure, teacher/site/material requirements",
      attack_or_save: "Foundation Challenge DC per campaign rule",
      damage_or_effect: text,
      targeting: { target_rule: "Self; Foundation route" },
      resolution: { legacy_effect_display: text },
      source: name,
      tags: ["builder", "foundation", "challenge", "autofilled"]
    });
  }
  if (warning && !actions.some((action) => /burden/i.test(action.action_name))) {
    actions.push({
      action_id: `foundation_${idBase}_warning`,
      action_name: `Foundation Warning — ${name}`,
      display_name: `Foundation Warning — ${name}`,
      action_type: "GM Trigger / Passive",
      cost: "Triggered by misuse or stress",
      attack_or_save: "Relevant save/check if escalated",
      damage_or_effect: warning,
      targeting: { target_rule: "Self" },
      resolution: { legacy_effect_display: warning },
      source: name,
      tags: ["builder", "foundation", "warning", "autofilled"]
    });
  }
  return actions;
}

function builderFoundationPassiveTemplates(foundation = {}) {
  const name = foundationDisplayName(foundation);
  const benefit = foundationStageBenefitText(foundation, foundation.stage) || "";
  return benefit ? [{
    passive_id: `foundation_${foundationCatalogKey(foundation.id || name)}_passive`,
    passive_name: `Foundation Passive — ${name}`,
    source_name: name,
    summary: benefit,
    tags: ["foundation", "autofilled"]
  }] : [];
}

function builderFoundationStateTemplates(foundation = {}) {
  const name = foundationDisplayName(foundation);
  const rows = [];
  const addRows = (items, type) => {
    (Array.isArray(items) ? items : []).forEach((item, index) => {
      const pressureName = foundationPressureName(item, `${name} ${type}`);
      rows.push({
        state_id: `foundation_${foundationCatalogKey(foundation.id || name)}_${foundationCatalogKey(type)}_${index + 1}`,
        name: pressureName,
        type,
        severity: (typeof item === "object" && item?.severity) || "tracked",
        trigger: (typeof item === "object" && (item?.trigger || item?.temptation)) || "Foundation stress",
        effect: foundationPressureText(item) || `Track ${pressureName} when this Foundation pressure applies.`,
        source: name,
        tags: ["foundation", "autofilled"]
      });
    });
  };
  addRows(foundation.burdens, "Burden");
  addRows(foundation.hidden_injuries, "Hidden Injury");
  addRows(foundation.strains, "Strain");
  addRows(foundation.deviations, "Deviation");
  return rows;
}

function foundationLibraryCard(item = {}) {
  const benefit = foundationKnownValue(item, "benefit");
  const warning = foundationKnownValue(item, "warning");
  const compatible = item.sphere_interfaces?.compatible_spheres || [];
  const conditional = item.sphere_interfaces?.conditional_spheres_unlocked || [];
  const actions = (Array.isArray(item.runtime_record?.actions) ? item.runtime_record.actions : [])
    .slice(0, 8)
    .map((action) => action?.display_name || action?.action_name || action?.name || action?.id)
    .filter(Boolean);
  return `
    <article class="library-card foundation-library-card">
      <h3>${escapeHtml(item.catalog_code ? `${item.catalog_code} · ${item.name}` : item.catalog_number ? `${item.catalog_number}. ${item.name}` : item.name || "Foundation")}</h3>
      <p><strong>Family:</strong> ${escapeHtml((Array.isArray(item.family) ? item.family : [item.family || "Unclassified"]).map(foundationReadableToken).join(", "))}</p>
      <p><strong>Depth / Stage:</strong> ${escapeHtml([item.depth, item.stage].filter(Boolean).map(foundationReadableToken).join(" / "))}</p>
      ${item.primary_path ? `<p><strong>Path:</strong> ${escapeHtml(foundationDisplayValue(item.primary_path))}</p>` : ""}
      ${item.dao_principle ? `<p><strong>Dao:</strong> ${escapeHtml(truncateValue(item.dao_principle, 260))}</p>` : ""}
      ${benefit ? `<p><strong>Benefit:</strong> ${escapeHtml(truncateValue(benefit, 360))}</p>` : ""}
      ${warning ? `<p><strong>Warning:</strong> ${escapeHtml(truncateValue(warning, 280))}</p>` : ""}
      ${compatible.length ? `<p><strong>Compatible:</strong> ${escapeHtml(compatible.slice(0, 14).map(foundationRuleText).join(", "))}</p>` : ""}
      ${conditional.length ? `<p><strong>Conditional:</strong> ${escapeHtml(conditional.slice(0, 14).map(foundationRuleText).join(", "))}</p>` : ""}
      ${actions.length ? `<p><strong>Builder Actions:</strong> ${escapeHtml(actions.join("; "))}</p>` : ""}
    </article>`;
}

function proficiencyByLevel(level) {
  const value = Number(level);
  if (!Number.isFinite(value) || value < 5) return 2;
  if (value < 9) return 3;
  if (value < 13) return 4;
  if (value < 17) return 5;
  return 6;
}

function realmByLevel(level) {
  const value = Number(level);
  if (!Number.isFinite(value) || value <= 0) return "Level 0 Mortal";
  if (value <= 4) return "Mortal Realm";
  if (value <= 9) return "Foundation Realm";
  if (value <= 14) return "Core Formation Realm";
  return "Nascent Soul Realm";
}

function chakraRealmByLevel(level) {
  const value = Number(level);
  if (!Number.isFinite(value) || value <= 0) return "Level 0 Mortal";
  if (value <= 4) return "Loose Chakra";
  if (value <= 9) return "Retained Wheel";
  if (value <= 14) return "Living Circuit";
  if (value <= 19) return "Inner Mandala";
  return "Living Mandala";
}

function builderBackgroundSelectedGrant() {
  const selected = document.querySelector('input[name="builderBackgroundGrant"]:checked');
  if (!selected) return null;
  return {
    choice_id: selected.value || "",
    sphere: selected.dataset.backgroundSphere || "",
    talent: selected.dataset.backgroundTalent || "",
    status: selected.dataset.backgroundStatus || "active"
  };
}

function builderBackgroundRecord() {
  const name = $("builderBackground")?.value || "";
  const template = TIANXIA_BACKGROUNDS[name];
  if (!template) return null;
  const grant = builderBackgroundSelectedGrant();
  return {
    name,
    region_or_origin: $("builderBackgroundRegion")?.value.trim() || template.region || "Campaign origin",
    description: template.description || "",
    ability_score_options: Array.isArray(template.ability_options) ? [...template.ability_options] : [],
    skill_proficiencies: Array.isArray(template.skills) ? [...template.skills] : [],
    tools_and_languages: Array.isArray(template.tools) ? [...template.tools] : (template.tools_text ? [template.tools_text] : []),
    feature: template.feature || template.social_hook || "",
    basic_equipment: Array.isArray(template.kit) ? [...template.kit] : (template.equipment_text ? [template.equipment_text] : []),
    origin_insight_options: Array.isArray(template.origin_insights) ? [...template.origin_insights] : [],
    background_sphere: grant?.sphere || "",
    background_talent: grant?.talent || "",
    background_sphere_status: grant?.status || "",
    background_grant_choice_id: grant?.choice_id || "",
    background_grant_is_free: Boolean(grant),
    background_grant_source: grant ? template.source : ""
  };
}

function builderFoundationRecord(name) {
  const selected = selectedBuilderFoundationCatalog();
  const foundationName = $("builderFoundationName")?.value.trim() || selected?.name || "Ordinary Cultivation Foundation";
  const notes = $("builderFoundationNotes")?.value.trim() || (selected ? foundationCatalogNotes(selected) : "A modest foundation record. Its deeper truth has not yet been tested.");
  if (selected) {
    const record = cloneFoundationRecord(selected);
    record.id = record.id || `foundation_${foundationCatalogKey(foundationName)}`;
    record.name = foundationName;
    record.content_type = record.content_type || "foundation_state";
    record.family = [$("builderFoundationFamily")?.value || foundationPrimaryFamily(record) || "qi_root"];
    record.depth = $("builderFoundationDepth")?.value || foundationDepthKey(record.depth) || "minor";
    record.stage = $("builderFoundationStage")?.value || foundationStageKey(record.stage || record.default_stage) || "latent";
    const stageBenefit = foundationStageBenefitText(record, record.stage);
    const stageBurden = foundationStageBurdenText(record, record.stage);
    record.builder_catalog_source = record.catalog_source || "Tianxia Foundation Catalog";
    record.catalog_code = record.catalog_code || $("builderFoundationCatalogCode")?.value || "";
    record.foundation_grade = record.foundation_grade || $("builderFoundationGrade")?.value || "";
    record.builder_selected_stage = record.stage;
    record.builder_stage_label = foundationStageLabel(record.stage);
    record.builder_stage_benefit = stageBenefit;
    record.builder_stage_burden = stageBurden;
    record.builder_notes = notes;
    record.known_player_text = record.known_player_text || {};
    if (stageBenefit) {
      record.known_player_text.benefit = stageBenefit;
      record.known_player_text.known_benefit = stageBenefit;
      record.known_player_text.mechanical_benefit = stageBenefit;
    }
    if (stageBurden) record.known_player_text.burden = stageBurden;
    record.known_player_text.stage = foundationStageLabel(record.stage);
    if (notes && !record.known_player_text.builder_notes) record.known_player_text.builder_notes = notes;
    return record;
  }
  return {
    id: `foundation_${name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "character"}`,
    name: foundationName,
    content_type: "foundation_state",
    family: [$("builderFoundationFamily")?.value || "qi_root"],
    depth: $("builderFoundationDepth")?.value || "minor",
    stage: $("builderFoundationStage")?.value || "latent",
    origin: "custom builder entry",
    dao_principle: notes,
    known_player_text: {
      summary: notes,
      common_knowledge: notes,
      visible_sign: "Not recorded.",
      benefit: "Not recorded.",
      warning: "Not recorded."
    },
    compatibility: { compatible_spheres: [], strained_spheres: [], incompatible_spheres: [] },
    sphere_interfaces: { compatible_spheres: [], strained_spheres: [], conditional_spheres_unlocked: [] },
    advancement_routes: ["reveal", "deepen", "redirect", "integrate"]
  };
}

function builderMartialArtRecord() {
  const name = $("builderMartialArtName")?.value.trim();
  if (!name) return [];
  return [{
    name,
    status: $("builderMartialArtStatus")?.value.trim() || "primary",
    doctrine: $("builderMartialArtDoctrine")?.value.trim() || "Doctrine not recorded.",
    associated_spheres: [...builderSphereNames],
    equipment_or_body_requirements: []
  }];
}

function builderAbilityScores() {
  return {
    STR: Number($("builderStr")?.value || 10),
    DEX: Number($("builderDex")?.value || 10),
    CON: Number($("builderCon")?.value || 10),
    INT: Number($("builderInt")?.value || 10),
    WIS: Number($("builderWis")?.value || 10),
    CHA: Number($("builderCha")?.value || 10)
  };
}

function abilityMod(score) {
  const value = Number(score);
  return Number.isFinite(value) ? Math.floor((value - 10) / 2) : 0;
}

function builderListLines(id) {
  return String($(id)?.value || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function builderFeatureFromLine(line, fallbackSource = "") {
  const parts = String(line || "").split("|").map((part) => part.trim()).filter(Boolean);
  return {
    name: parts[0] || "Unnamed",
    source: parts[1] || fallbackSource,
    summary: parts.slice(2).join(" | ")
  };
}

function builderActionFromLine(line, index) {
  const parts = String(line || "").split("|").map((part) => part.trim());
  return {
    action_id: `builder_action_${index + 1}`,
    action_name: parts[0] || `Custom Action ${index + 1}`,
    action_type: parts[1] || "Action",
    range_or_reach: parts[2] || "",
    attack_or_save: parts[3] || "",
    cost: "",
    damage_or_effect: [parts[4], parts.slice(5).join(" | ")].filter(Boolean).join(" | "),
    targeting: {
      range_or_reach: parts[2] || "",
      target_rule: ""
    },
    resolution: {
      attack_or_save: parts[3] || "",
      legacy_effect_display: [parts[4], parts.slice(5).join(" | ")].filter(Boolean).join(" | ")
    },
    tags: ["builder"]
  };
}

function builderDerivedData() {
  const pathName = $("builderPath")?.value || "Body Refining";
  const config = builderConfig(pathName);
  const level = Math.max(1, Math.min(20, Number($("builderLevel")?.value || 1)));
  const pb = proficiencyByLevel(level);
  const keyAbility = $("builderKeyAbility")?.value || config.key;
  const keyShort = abilityShortName(keyAbility) || abilityShortName(config.key) || "WIS";
  const scores = builderAbilityScores();
  const mods = Object.fromEntries(Object.entries(scores).map(([key, score]) => [key, abilityMod(score)]));
  const saves = Object.fromEntries(Object.entries(mods).map(([key, mod]) => [key, mod + (config.saveProficiencies.includes(key) ? pb : 0)]));
  const conMod = mods.CON || 0;
  const dexMod = mods.DEX || 0;
  const keyMod = mods[keyShort] || 0;
  const effectiveLevel = Math.max(1, level || 1);
  const averageHit = Math.ceil((config.hitDie + 1) / 2);
  const hpMax = level <= 0 ? Math.max(1, 6 + conMod) : Math.max(1, config.hitDie + conMod + (effectiveLevel - 1) * Math.max(1, averageHit + conMod));
  const ac = config.acMode === "body" ? 10 + dexMod + conMod : 10 + dexMod;
  const resourceMax = level <= 0 ? 0 : Math.max(0, level * keyMod);
  const realm = $("builderRealm")?.value.trim() || (pathName === "Chakra" ? chakraRealmByLevel(level) : realmByLevel(level));
  return {
    pathName,
    config,
    level,
    pb,
    keyAbility,
    keyShort,
    scores,
    mods,
    saves,
    hpMax,
    ac,
    resourceMax,
    resourceName: config.resource,
    attackBonus: pb + keyMod,
    saveDc: 8 + pb + keyMod,
    realm
  };
}

function builderCompleteSheet() {
  const derived = builderDerivedData();
  const name = $("builderName")?.value.trim() || "Unnamed Tianxia Character";
  const spheres = builderSphereNames.length ? builderSphereNames : [];
  const talents = builderListLines("builderTalents").map((line) => builderFeatureFromLine(line, "Talent"));
  const insights = builderListLines("builderInsights").map((line) => builderFeatureFromLine(line, "Cultivation Insight"));
  const forgedTechniques = builderListLines("builderTechniques").map((line) => builderFeatureFromLine(line, "Forged Technique"));
  const actions = builderListLines("builderActions").map(builderActionFromLine);
  const background = builderBackgroundRecord();
  const foundation = builderFoundationRecord(name);
  const foundationActions = builderFoundationActionTemplates(foundation, name);
  const foundationPassives = builderFoundationPassiveTemplates(foundation);
  const foundationStates = builderFoundationStateTemplates(foundation);
  const martialArts = builderMartialArtRecord();
  const equipment = [...(background?.basic_equipment || []), ...builderListLines("builderEquipment")];
  return {
    schema_version: "tianxia_dashboard_builder_v1",
    character_id: `builder_${name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "character"}`,
    identity: {
      name,
      description: $("builderDescription")?.value.trim() || "",
      background
    },
    cultivation: {
      path: derived.pathName,
      level: String(derived.level),
      cultivation_level: String(derived.level),
      realm: derived.realm,
      realm_and_stage: derived.realm,
      key_ability: derived.keyAbility,
      proficiency_bonus: derived.pb,
      chakra_record: derived.pathName === "Chakra" ? $("builderChakraRecord")?.value.trim() || "Chakra ability, Wheels, and permissions not recorded." : ""
    },
    abilities: {
      scores: derived.scores,
      modifiers: derived.mods,
      saves: derived.saves
    },
    combat: {
      proficiency_bonus: derived.pb,
      hit_points: { maximum: derived.hpMax, current: derived.hpMax, formula: `${derived.config.hitDie} hit die path baseline` },
      armor_class: { base: derived.ac, current: derived.ac, formula: derived.config.acMode === "body" ? "10 + DEX + CON" : "10 + DEX" },
      speed: { walking: 30 },
      primary_attack_bonus: derived.attackBonus,
      cultivation_attack_bonus: derived.attackBonus,
      save_dc: derived.saveDc,
      cultivation_save_dc: derived.saveDc,
      attacks_per_attack_action: derived.level >= 5 && derived.pathName === "Body Refining" ? 2 : 1,
      senses: []
    },
    resources: [{
      resource_id: derived.resourceName.toLowerCase().replace(/\s+/g, "_"),
      resource_name: derived.resourceName,
      maximum: derived.resourceMax,
      current: derived.resourceMax,
      recovery: "Long rest baseline; adjust if a path feature says otherwise."
    }],
    build: {
      spheres,
      talents,
      insights,
      forged_techniques: forgedTechniques,
      equipment,
      martial_arts: martialArts,
      background,
      foundations: [foundation]
    },
    actions: { registry: [...foundationActions, ...actions] },
    passives: { registry: [
      ...foundationPassives,
      ...talents.map((talent, index) => ({
        passive_id: `builder_talent_${index + 1}`,
        passive_name: talent.name,
        source_name: talent.source,
        summary: talent.summary
      }))
    ] },
    controlled_assets: { assets: [] },
    states: { registry: foundationStates }
  };
}

function builderPackageFiles() {
  const sheet = builderCompleteSheet();
  const name = sheet.identity.name;
  const safeName = name.replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "") || "Tianxia_Character";
  const manifest = {
    package_name: `${name} Dashboard Builder Package`,
    package_version: $("builderVersion")?.value.trim() || "dashboard-builder-v1",
    created_at: new Date().toISOString(),
    files: [
      "README_FIRST.md",
      "Complete_Character_Record_v1_31.json",
      "Character_Action_Registry.json",
      "Limited_Resource_Counter_Inventory.json",
      "Passive_Modifier_Registry.json",
      "Martial_Arts_and_Manuals.json",
      "Foundation_Registry.json",
      "Foundation_Action_Registry.json",
      "Background_Record.json",
      "character_sheet.md",
      "package_manifest.json"
    ]
  };
  const readable = [
    `# ${name}`,
    ``,
    `Path: ${sheet.cultivation.path}`,
    `Realm / CL: ${sheet.cultivation.realm_and_stage} | CL ${sheet.cultivation.level}`,
    `Key Ability: ${sheet.cultivation.key_ability}`,
    ``,
    `## Background`,
    sheet.identity.background ? `${sheet.identity.background.name} | ${sheet.identity.background.region_or_origin}\nSkills: ${sheet.identity.background.skill_proficiencies.join(", ")}\nTools/Languages: ${sheet.identity.background.tools_and_languages.join(", ")}\nFeature: ${sheet.identity.background.feature}` : "Not recorded.",
    ``,
    `## Foundation`,
    `${sheet.build.foundations[0].name} | ${sheet.build.foundations[0].depth} | ${sheet.build.foundations[0].stage}\n${sheet.build.foundations[0].dao_principle}`,
    ``,
    `## Martial Art`,
    ...(sheet.build.martial_arts.length ? sheet.build.martial_arts.map((item) => `- ${item.name} (${item.status}): ${item.doctrine}`) : ["- Not recorded."]),
    ``,
    `## Combat Snapshot`,
    `HP: ${sheet.combat.hit_points.current}/${sheet.combat.hit_points.maximum}`,
    `AC: ${sheet.combat.armor_class.current}`,
    `Speed: 30 ft`,
    `Attack Bonus: ${formatSigned(sheet.combat.primary_attack_bonus)}`,
    `Save DC: ${sheet.combat.save_dc}`,
    `${sheet.resources[0].resource_name}: ${sheet.resources[0].current}/${sheet.resources[0].maximum}`,
    ``,
    `## Spheres`,
    ...(sheet.build.spheres.length ? sheet.build.spheres.map((sphere) => `- ${sphere}`) : ["- None selected"]),
    ``,
    `## Talents`,
    ...(sheet.build.talents.length ? sheet.build.talents.map((item) => `- ${item.name}${item.source ? ` (${item.source})` : ""}${item.summary ? `: ${item.summary}` : ""}`) : ["- None listed"]),
    ``,
    `## Insights`,
    ...(sheet.build.insights.length ? sheet.build.insights.map((item) => `- ${item.name}${item.summary ? `: ${item.summary}` : ""}`) : ["- None listed"]),
    ``,
    `## Forged Techniques`,
    ...(sheet.build.forged_techniques.length ? sheet.build.forged_techniques.map((item) => `- ${item.name}${item.summary ? `: ${item.summary}` : ""}`) : ["- None listed"]),
    ``,
    `## Actions`,
    ...(sheet.actions.registry.length ? sheet.actions.registry.map(actionLine) : ["- No custom actions entered."]),
    ``,
    `## Equipment`,
    ...(sheet.build.equipment.length ? sheet.build.equipment.map((item) => `- ${item}`) : ["- None listed."]),
    ``,
    `## Description`,
    sheet.identity.description || "Not recorded."
  ].join("\n");

  return {
    safeName,
    blocks: [
      { name: "README_FIRST.md", content: `# ${name}\n\nDashboard-built Tianxia character package. Load the Complete Character Record first, then use the registries as supporting files.` },
      { name: "Complete_Character_Record_v1_31.json", content: JSON.stringify(sheet, null, 2) },
      { name: "Character_Action_Registry.json", content: JSON.stringify({ actions: sheet.actions.registry }, null, 2) },
      { name: "Limited_Resource_Counter_Inventory.json", content: JSON.stringify({ resources: sheet.resources }, null, 2) },
      { name: "Passive_Modifier_Registry.json", content: JSON.stringify(sheet.passives, null, 2) },
      { name: "Martial_Arts_and_Manuals.json", content: JSON.stringify({ martial_arts: sheet.build.martial_arts }, null, 2) },
      { name: "Foundation_Registry.json", content: JSON.stringify({ foundations: sheet.build.foundations }, null, 2) },
      { name: "Foundation_Action_Registry.json", content: JSON.stringify({ actions: sheet.actions.registry.filter((action) => (action.tags || []).includes("foundation")), states: sheet.states.registry, passives: sheet.passives.registry.filter((passive) => (passive.tags || []).includes("foundation")) }, null, 2) },
      { name: "Background_Record.json", content: JSON.stringify(sheet.identity.background || {}, null, 2) },
      { name: "character_sheet.md", content: readable },
      { name: "package_manifest.json", content: JSON.stringify(manifest, null, 2) }
    ]
  };
}

function builderPackageText() {
  return builderPackageFiles().blocks.map((block) => fileBlock(block.name, block.content)).join("\n\n");
}

function renderBuilderSphereList() {
  const target = $("builderSphereList");
  if (!target) return;
  target.innerHTML = builderSphereNames.length
    ? builderSphereNames.map((sphere) => `<button type="button" data-remove-builder-sphere="${escapeHtml(sphere)}">${escapeHtml(sphere)}</button>`).join("")
    : `<div class="empty-state">No spheres selected yet.</div>`;
  target.querySelectorAll("[data-remove-builder-sphere]").forEach((button) => {
    button.addEventListener("click", () => {
      builderSphereNames = builderSphereNames.filter((sphere) => sphere !== button.dataset.removeBuilderSphere);
      updateBuilderPreview();
    });
  });
}

function updateBuilderPreview() {
  if (!$("builderDerivedStats")) return;
  const derived = builderDerivedData();
  if ($("builderRealm") && !$("builderRealm").value.trim()) $("builderRealm").placeholder = derived.pathName === "Chakra" ? chakraRealmByLevel(derived.level) : realmByLevel(derived.level);
  const background = builderBackgroundRecord();
  if ($("builderBackgroundPreview")) {
    const template = background ? TIANXIA_BACKGROUNDS[background.name] : null;
    $("builderBackgroundPreview").innerHTML = background
      ? `<div class="builder-background-overview"><div><strong>${escapeHtml(background.name)}</strong><span class="background-source-pill">Published background</span></div>${template?.description ? `<p>${escapeHtml(template.description)}</p>` : ""}<div class="background-fact-grid"><span><strong>Ability options</strong>${escapeHtml((background.ability_score_options || []).join(", ") || "See source")}</span><span><strong>Skills</strong>${escapeHtml(background.skill_proficiencies.join(", ") || "None recorded")}</span><span><strong>Tools / languages</strong>${escapeHtml(background.tools_and_languages.join(" ") || "None recorded")}</span><span><strong>Origin Insight ideas</strong>${escapeHtml((background.origin_insight_options || []).join(", ") || "Open choice")}</span></div>${template?.social_hook ? `<p class="muted-copy"><strong>Social hook:</strong> ${escapeHtml(template.social_hook)}</p>` : ""}${template?.equipment_text ? `<details><summary>Starting equipment</summary><p>${escapeHtml(template.equipment_text)}</p></details>` : ""}</div>`
      : "Choose a background to see its published benefits and select its free Background Sphere and talent.";
  }
  if ($("builderFoundationPreview")) {
    const selectedFoundation = selectedBuilderFoundationCatalog();
    $("builderFoundationPreview").innerHTML = selectedFoundation ? foundationBuilderPreviewHtml(selectedFoundation, currentBuilderFoundationStageKey()) : `Custom foundation mode. Enter the foundation fields manually.`;
  }
  const text = builderPackageText();
  $("builderPackageOutput").value = text;
  $("builderDerivedStats").innerHTML = `
    <h3>${escapeHtml($("builderName")?.value.trim() || "Unnamed Tianxia Character")}</h3>
    <p>${escapeHtml(derived.pathName)} | ${escapeHtml(derived.realm)} | CL ${escapeHtml(derived.level)}</p>
    <div class="status-grid">
      <div class="status-item ready"><strong>HP</strong>${escapeHtml(derived.hpMax)}</div>
      <div class="status-item ready"><strong>AC</strong>${escapeHtml(derived.ac)}</div>
      <div class="status-item ready"><strong>PB</strong>${escapeHtml(formatSigned(derived.pb))}</div>
      <div class="status-item ready"><strong>Attack</strong>${escapeHtml(formatSigned(derived.attackBonus))}</div>
      <div class="status-item ready"><strong>Save DC</strong>${escapeHtml(derived.saveDc)}</div>
      <div class="status-item ready"><strong>${escapeHtml(derived.resourceName)}</strong>${escapeHtml(derived.resourceMax)}</div>
    </div>
  `;
  const analysis = analyzePackageText(text, $("builderName")?.value.trim(), $("builderVersion")?.value.trim());
  if ($("builderVisualSheet")) {
    $("builderVisualSheet").innerHTML = renderVisualCharacterSheet(analysis);
    attachVisualSheetTabs("builderVisualSheet");
  }
  renderBuilderSphereList();
}

function addBuilderSphere() {
  const selected = $("builderSphereSelect")?.value || "";
  if (!selected || builderSphereNames.includes(selected)) return;
  builderSphereNames.push(selected);
  updateBuilderPreview();
}

function resetBuilder() {
  builderSphereNames = [];
  ["builderName", "builderDescription", "builderRealm", "builderBackgroundRegion", "builderFoundationName", "builderFoundationNotes", "builderMartialArtName", "builderMartialArtStatus", "builderMartialArtDoctrine", "builderChakraRecord", "builderTalents", "builderInsights", "builderTechniques", "builderActions", "builderEquipment"].forEach((id) => {
    if ($(id)) $(id).value = "";
  });
  if ($("builderPath")) $("builderPath").value = "Body Refining";
  if ($("builderBackground")) $("builderBackground").value = "";
  if ($("builderFoundationCatalogSelect")) $("builderFoundationCatalogSelect").value = "";
  if ($("builderFoundationPreview")) $("builderFoundationPreview").innerHTML = "Choose Custom Foundation or select a catalog Foundation to autofill its record and action surfaces.";
  if ($("builderFoundationFamily")) $("builderFoundationFamily").value = "qi_root";
  if ($("builderFoundationDepth")) $("builderFoundationDepth").value = "minor";
  if ($("builderFoundationStage")) $("builderFoundationStage").value = "latent";
  if ($("builderLevel")) $("builderLevel").value = 1;
  if ($("builderVersion")) $("builderVersion").value = "dashboard-builder-v1";
  ["builderStr", "builderDex", "builderCon", "builderInt", "builderWis", "builderCha"].forEach((id) => {
    if ($(id)) $(id).value = 10;
  });
  if ($("builderKeyAbility")) $("builderKeyAbility").value = builderConfig("Body Refining").key;
  updateBuilderPreview();
}

function saveBuilderCharacter() {
  const analysis = analyzePackageText(builderPackageText(), $("builderName")?.value.trim(), $("builderVersion")?.value.trim());
  const saved = storePackageAnalysis(analysis);
  saveState();
  renderAutomation();
  refreshPackageSelectors();
  if ($("activeCharacterSelect")) $("activeCharacterSelect").value = saved.id;
  renderCharacterViewer();
  setActiveTab("fight");
  toast("Builder character saved to dashboard.");
}

function exportBuilderZip() {
  const packageFiles = builderPackageFiles();
  const zipBytes = createStoredZip(packageFiles.blocks);
  downloadBlob(new Blob([zipBytes], { type: "application/zip" }), `${packageFiles.safeName}_Tianxia_Character_Package.zip`);
  toast("Character package zip exported.");
}

function renderReadableCharacterSheet(pkg, notes = {}) {
  if (!pkg) return "";
  const sheet = buildCharacterSheetData(pkg);
  const hpMax = sheet.hp.maximum ?? sheet.hp.max ?? "";
  const hpCurrent = sheet.hp.current ?? sheet.hp.current_default ?? hpMax;
  const acValue = sheet.ac.current ?? sheet.ac.base ?? sheet.ac.ac ?? "";
  const speedText = speedDisplay(sheet.speed);
  const actionLines = sheet.actions.length
    ? sheet.actions.map(actionLine).join("\n\n")
    : "- No action registry found in this package.";
  const equipmentEntries = [...(sheet.equipment || []), ...savedLinkedAsEntries(notes.equipment)];
  const consumableEntries = [...(sheet.consumables || []), ...savedLinkedAsEntries(notes.consumables)];
  const martialArtEntries = [...(sheet.martialArtsLearned || []), ...savedLinkedAsEntries(notes.martialArts)];
  const foundationEntries = sheet.foundations || [];
  const backgroundText = sheet.background
    ? [sheet.background.name, sheet.background.region_or_origin, sheet.background.feature, Array.isArray(sheet.background.skill_proficiencies) ? `Skills: ${sheet.background.skill_proficiencies.join(", ")}` : "", Array.isArray(sheet.background.tools_and_languages) ? `Tools/Languages: ${sheet.background.tools_and_languages.join(", ")}` : ""].filter(Boolean).join(" | ")
    : "Not recorded.";
  const abilityLines = hasAbilityScoreData(sheet)
    ? ABILITY_ROWS
      .map((ability) => scoreLine(ability, sheet.abilityScores, sheet.abilityModifiers, sheet.saves))
      .join("\n")
    : "- Ability scores, ability modifiers, and save bonuses were not included in this package.";

  return [
    `# ${sheet.name}`,
    sheet.characterId ? `ID: ${asDisplayText(sheet.characterId)}` : null,
    `Path: ${sheet.path || "unknown"}`,
    `Realm / CL: ${[sheet.realm, sheet.cultivationLevel ? `CL ${sheet.cultivationLevel}` : ""].filter(Boolean).join(" | ") || "unknown"}`,
    sheet.keyAbility ? `Key Ability: ${sheet.keyAbility}` : null,
    sheet.proficiencyBonus !== "" ? `Proficiency Bonus: +${sheet.proficiencyBonus}` : null,
    ``,
    `## Physical Description`,
    notes.physicalDescription?.trim() || sheet.physicalDescription || "[Not recorded yet. Use the Physical Description box above.]",
    ``,
    `## Background`,
    sheet.background ? `${sheet.background.name || "Background"}${sheet.background.region_or_origin ? ` | ${sheet.background.region_or_origin}` : ""}${sheet.background.feature ? ` | ${sheet.background.feature}` : ""}` : "- Not recorded.",
    ``,
    `## Foundation`,
    listLines(sheet.foundations, (item) => `${item.name || item.foundation_name || item.id || "Foundation"}${item.depth ? ` | ${item.depth}` : ""}${item.stage ? ` | ${item.stage}` : ""}${item.dao_principle ? ` | ${item.dao_principle}` : ""}`),
    sheet.chakraRecord ? `Chakra Record: ${sheet.chakraRecord}` : null,
    ``,
    `## Combat Snapshot`,
    `HP: ${hpCurrent || "?"}/${hpMax || "?"}`,
    `AC: ${acValue || "?"}${sheet.ac.formula ? ` (${sheet.ac.formula})` : ""}`,
    speedText ? `Speed: ${speedText}` : null,
    `Cultivation Attack Bonus: ${sheet.cultivationAttackBonus ?? "?"}`,
    `Cultivation Save DC: ${sheet.cultivationSaveDc ?? "?"}`,
    `Attacks / Attack Action: ${sheet.attacksPerAttackAction ?? "?"}`,
    sheet.senses.length ? `Senses: ${sheet.senses.join(", ")}` : null,
    ``,
    `## Ability Scores and Saves`,
    abilityLines,
    ``,
    `## Skills`,
    Object.keys(skillBonusMap(sheet.skills)).length
      ? Object.entries(skillBonusMap(sheet.skills)).map(([name, value]) => `- ${name}: ${formatSigned(value)}`).join("\n")
      : "- None listed.",
    ``,
    `## Defenses`,
    `Resistances: ${sheet.resistances.length ? sheet.resistances.join(", ") : "none listed"}`,
    `Immunities: ${sheet.immunities.length ? sheet.immunities.join(", ") : "none listed"}`,
    `Vulnerabilities: ${sheet.vulnerabilities.length ? sheet.vulnerabilities.join(", ") : "none listed"}`,
    ``,
    `## Resources`,
    listLines(sheet.resources, resourceLine),
    ``,
    `## Spheres`,
    listLines(sheet.spheres),
    ``,
    `## Talents`,
    listLines(sheet.talents, talentLine),
    ``,
    `## Insights`,
    listLines(sheet.insights, talentLine),
    ``,
    `## Forged Techniques`,
    listLines(sheet.forgedTechniques, (item) => {
      if (typeof item === "string") return item;
      if (!item || typeof item !== "object") return "Technique";
      return [
        item.display_name || item.name || "Unnamed Technique",
        item.realm ? `realm: ${item.realm}` : "",
        item.cost ? `cost: ${forgedTechniqueCost(item) || asDisplayText(item.cost)}` : "",
        item.complexity ? `complexity: ${item.complexity}` : "",
        item.damage_or_effect || item.summary || item.effect || item.description || item.intent || "",
        Array.isArray(item.components) && item.components.length ? `components: ${item.components.join(", ")}` : ""
      ].filter(Boolean).join(" | ");
    }),
    ``,
    `## Weapon and Basic Attack Profiles`,
    listLines(sheet.weapons, weaponLine),
    ``,
    `## Programmed Actions / Attacks`,
    actionLines,
    ``,
    `## Passive Features`,
    listLines(sheet.passives, passiveLine),
    ``,
    `## Controlled Assets`,
    listLines(sheet.assets, assetLine),
    ``,
    `## Active State Templates`,
    listLines(sheet.states, (item) => `${item?.display_name || item?.state_name || item?.name || item?.state_id || "State"}${item?.duration ? ` | ${asDisplayText(item.duration)}` : ""}${item?.effect ? ` | ${asDisplayText(item.effect)}` : ""}`),
    ``,
    `## Equipment`,
    listLines(equipmentEntries, inventoryLine),
    ``,
    `## Consumables`,
    listLines(consumableEntries, inventoryLine),
    ``,
    `## Martial Arts Learned`,
    listLines(martialArtEntries, inventoryLine)
  ].filter((line) => line !== null && line !== undefined).join("\n");
}

function formatSigned(value) {
  const scalar = abilityScalarValue(value, ["modifier", "mod", "save", "bonus", "value", "total"]);
  if (scalar === undefined || scalar === null || scalar === "") return "—";
  const number = Number(String(scalar).replace(/^\+/, ""));
  if (Number.isFinite(number)) return number >= 0 ? `+${number}` : String(number);
  const text = asDisplayText(scalar);
  return text || "—";
}

function compactText(value, max = 180) {
  const text = asDisplayText(value).replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1).trim()}…` : text;
}

function characterInitials(name) {
  const words = String(name || "Tianxia Character")
    .replace(/[,—-].*$/, "")
    .split(/\s+/)
    .filter(Boolean);
  return words.slice(0, 2).map((word) => word[0]?.toUpperCase()).join("") || "TC";
}

function visualList(items, mapper = (item) => String(item), empty = "None listed.") {
  if (!Array.isArray(items) || !items.length) return `<p class="sheet-description">${escapeHtml(empty)}</p>`;
  return `<ul class="sheet-list">${items.map((item) => `<li>${escapeHtml(asDisplayText(mapper(item)))}</li>`).join("")}</ul>`;
}

function visualChips(items, empty = "None listed.") {
  if (!Array.isArray(items) || !items.length) return `<p class="sheet-description">${escapeHtml(empty)}</p>`;
  return `<div class="sheet-chip-list">${items.map((item) => `<span>${escapeHtml(asDisplayText(item))}</span>`).join("")}</div>`;
}

function sphereReferenceBody(name) {
  const sphere = profile(name);
  const rulesEntry = sphereRulesEntry(sphere.name);
  const natural = sphere.natural.map((key) => TRIGRAMS[key]?.label || key).join(", ");
  const testing = sphere.testing.map((key) => TRIGRAMS[key]?.label || key).join(", ");
  return `
    <div class="sheet-sphere-reference-heading">
      <div>
        <span>Sphere Reference</span>
        <h4>${escapeHtml(sphere.name)}</h4>
      </div>
      <button type="button" class="ghost-button compact" data-open-library-sphere="${escapeHtml(sphere.name)}">Open in Library</button>
    </div>
    <p class="sheet-description">${escapeHtml(sphere.read)}</p>
    <div class="sphere-reference-grid">
      <article><strong>Path</strong><span>${escapeHtml(sphere.path)}</span></article>
      <article><strong>Natural Trigrams</strong><span>${escapeHtml(natural)}</span></article>
      <article><strong>Testing Trigrams</strong><span>${escapeHtml(testing)}</span></article>
      <article><strong>Shadow</strong><span>${escapeHtml(sphere.shadow.join(", "))}</span></article>
      <article><strong>Verbs</strong><span>${escapeHtml(sphere.verbs.join(", "))}</span></article>
    </div>
    ${rulesEntry ? `
      <details class="sheet-full-rules" open>
        <summary>Full Sphere Rules</summary>
        <div class="sheet-rules-markdown">${sphereRulesMarkdownHtml(rulesEntry.markdown)}</div>
      </details>
    ` : `
      <div class="sheet-full-rules missing">
        <strong>Full rules not linked yet.</strong>
        <p>The Dao profile is available, but this sphere was not found in the local sphere compendium database.</p>
      </div>
    `}
  `;
}

function sphereReferenceCard(name) {
  if (!name) {
    return `<p class="sheet-description">No sphere reference selected.</p>`;
  }
  return `<article class="sheet-sphere-reference" data-sheet-sphere-panel>${sphereReferenceBody(name)}</article>`;
}

function visualSphereChips(items, activeName = "", empty = "No spheres listed.") {
  if (!Array.isArray(items) || !items.length) return `<p class="sheet-description">${escapeHtml(empty)}</p>`;
  const active = String(activeName || asDisplayText(items[0])).toLowerCase();
  return `
    <div class="sheet-chip-list linked-sphere-list">
      ${items.map((item) => {
        const name = asDisplayText(item);
        return `<button type="button" class="${name.toLowerCase() === active ? "active" : ""}" data-sheet-sphere="${escapeHtml(name)}">${escapeHtml(name)}</button>`;
      }).join("")}
    </div>
  `;
}

function visualDetailCards(items, mapper, empty = "None listed.") {
  const list = compactImportList(items);
  if (!list.length) return `<p class="sheet-description">${escapeHtml(empty)}</p>`;
  return `<div class="sheet-detail-grid">${list.map((item) => {
    let detail;
    try {
      detail = safeDetail(mapper(item));
    } catch (error) {
      detail = { title: entryDisplayName(item) || "Entry", body: "Importer display guard: entry was malformed but preserved." };
    }
    return `
      <article class="sheet-detail-card">
        <strong>${escapeHtml(detail.title || "Entry")}</strong>
        ${detail.body ? `<p>${escapeHtml(detail.body)}</p>` : ""}
      </article>
    `;
  }).join("")}</div>`;
}

function talentDetail(item) {
  if (typeof item === "string") return { title: item, body: "" };
  if (!item || typeof item !== "object") return { title: "Talent", body: "" };
  const legalName = legalAuditDisplayName(item);
  const aliases = firstHf05aAliasList(item);
  return {
    title: item.name || item.feature_name || item.option_name || legalName || item.display_name || "Unnamed Talent",
    body: [
      item.slot ? `Slot: ${item.slot}` : "",
      item.legal_tianxia_sphere ? `Legal Sphere: ${item.legal_tianxia_sphere}` : item.sphere ? `Sphere: ${item.sphere}` : "",
      item.legal_talent_function ? `Legal Function: ${item.legal_talent_function}` : "",
      legalName && legalName !== (item.name || item.feature_name || item.option_name) ? `Audit Name: ${legalName}` : "",
      aliases.length ? `Display Alias: ${aliases.join(", ")}` : "",
      item.status ? `Status: ${item.status}` : "",
      item.source || item.source_name ? `Source: ${item.source || item.source_name}` : "",
      item.effect || item.summary || item.description || item.intent || item.mechanics || ""
    ].filter(Boolean).join(" | ")
  };
}

function techniqueDetail(item) {
  if (typeof item === "string") return { title: item, body: "" };
  if (!item || typeof item !== "object") return { title: "Technique", body: "" };
  return {
    title: item.display_name || item.name || "Unnamed Technique",
    body: [
      item.realm ? `Realm: ${item.realm}` : "",
      item.cost ? `Cost: ${item.cost}` : "",
      item.complexity ? `Complexity: ${asDisplayText(item.complexity)}` : "",
      item.summary || item.effect || item.description || item.damage_or_effect || item.intent || "",
      Array.isArray(item.components) && item.components.length ? `Components: ${item.components.join(", ")}` : ""
    ].filter(Boolean).join(" | ")
  };
}


function forgedTechniqueDisplayName(item = {}) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Unnamed Forged Technique";
  return String(
    firstHf05aAlias(item)
    || item.display_name
    || item.name
    || item.technique_name
    || item.forged_technique_name
    || item.title
    || item.action_name
    || item.technique_id
    || item.id
    || "Unnamed Forged Technique"
  ).trim();
}

function forgedTechniqueComponents(item = {}) {
  if (!item || typeof item !== "object") return [];
  const raw = [
    item.components,
    item.component_spheres,
    item.source_spheres,
    item.required_spheres,
    item.spheres,
    item.routes,
    item.routes_or_spheres,
    item.forging_inputs,
    item.inputs
  ];
  const out = [];
  raw.forEach((value) => {
    if (!value) return;
    const values = Array.isArray(value) ? value : String(value).split(/[,;/]+/);
    values.forEach((entry) => {
      if (entry === null || entry === undefined || entry === "") return;
      if (typeof entry === "object") {
        const text = entry.display_name || entry.name || entry.sphere || entry.route || entry.component || entry.id;
        if (text) out.push(String(text).trim());
      } else {
        out.push(String(entry).trim());
      }
    });
  });
  return [...new Set(out.map((item) => item.replace(/\s+/g, " ").trim()).filter(Boolean))].slice(0, 12);
}

function forgedTechniqueAction(item = {}, actions = []) {
  if (!item || typeof item !== "object" || !Array.isArray(actions)) return null;
  const ids = [
    item.linked_action_id,
    item.action_id,
    item.id,
    item.technique_id,
    item.forged_technique_id
  ].map((value) => String(value || "").trim().toLowerCase()).filter(Boolean);
  const nameKey = techniqueKey(forgedTechniqueDisplayName(item));
  return compactImportList(actions).find((action) => {
    const actionIds = [action.action_id, action.id, action.technique_id, action.linked_technique_id]
      .map((value) => String(value || "").trim().toLowerCase())
      .filter(Boolean);
    if (ids.length && actionIds.some((id) => ids.includes(id))) return true;
    return nameKey && techniqueKey(actionDisplayName(action)) === nameKey;
  }) || null;
}

function forgedTechniqueText(item = {}, action = null) {
  if (typeof item === "string") return "";
  return martialTextSnippet(
    item?.summary,
    item?.effect,
    item?.effects,
    item?.damage_or_effect,
    item?.resolution,
    item?.description,
    item?.mechanics,
    item?.intent,
    action?.summary,
    action?.effect,
    action?.damage_or_effect,
    action?.resolution,
    action?.description
  );
}

function forgedTechniqueFieldHtml(label, value, max = 340) {
  const text = asDisplayText(value).trim();
  return text ? `<div class="manual-technique-meta"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(truncateValue(text, max))}</div>` : "";
}

function forgedTechniqueCostDisplay(value) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "number") return String(value);
  if (typeof value === "object" && !Array.isArray(value)) {
    const entries = Object.entries(value).filter(([, entry]) => entry !== null && entry !== undefined && entry !== "");
    if (!entries.length) return "";
    if (entries.length === 1 && /^stamina$/i.test(entries[0][0])) return String(entries[0][1]);
    return entries.map(([key, entry]) => /^stamina$/i.test(key) ? String(entry) : `${titleCase(key.replace(/_/g, " "))} ${entry}`).join("; ");
  }
  const text = asDisplayText(value).trim();
  if (!text) return "";
  const pairs = [...text.matchAll(/[{'"]\s*([^:'"{}]+?)\s*['"]?\s*:\s*['"]?([^,'"}]+)['"]?/g)]
    .map((match) => [match[1].trim(), match[2].trim()])
    .filter(([key, entry]) => key && entry);
  if (pairs.length) {
    if (pairs.length === 1 && /^stamina$/i.test(pairs[0][0])) return pairs[0][1];
    return pairs.map(([key, entry]) => /^stamina$/i.test(key) ? entry : `${titleCase(key.replace(/_/g, " "))} ${entry}`).join("; ");
  }
  return text;
}

function forgedTechniqueQuickGridHtml(rows = []) {
  const filtered = rows
    .map(([label, value, max]) => [label, asDisplayText(value).trim(), max || 180])
    .filter(([, value]) => value);
  if (!filtered.length) return "";
  return `
    <dl class="manual-meta-grid forged-technique-quick-grid">
      ${filtered.map(([label, value, max]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(truncateValue(value, max))}</dd></div>`).join("")}
    </dl>
  `;
}

function forgedTechniqueBadges(item = {}, action = null) {
  if (typeof item === "string") return "";
  const components = forgedTechniqueComponents(item);
  const economy = item?.action_economy || item?.action_type || item?.type || action?.action_economy || action?.action_type || action?.type || "";
  const badges = [
    "Forged Technique",
    economy,
    item?.realm ? `Realm: ${item.realm}` : "",
    item?.grade || item?.rank || item?.tier || "",
    item?.complexity ? `Complexity: ${asDisplayText(item.complexity)}` : "",
    item?.emergency_forged || item?.emergency ? "Emergency-forged" : "",
    item?.markdown_derived ? "Markdown import" : "",
    components.length ? `${components.length} component${components.length === 1 ? "" : "s"}` : ""
  ].map((value) => asDisplayText(value).trim()).filter(Boolean);
  return badges.map((badge) => `<span>${escapeHtml(badge)}</span>`).join("");
}

function forgedTechniqueCard(item, actions = []) {
  if (typeof item === "string") {
    return `
      <article class="manual-technique-card forged-technique-card">
        <div class="manual-technique-head"><h5>${escapeHtml(asDisplayText(item))}</h5><div class="manual-badge-list"><span>Forged Technique</span></div></div>
      </article>
    `;
  }
  if (!item || typeof item !== "object") {
    return `
      <article class="manual-technique-card forged-technique-card">
        <div class="manual-technique-head"><h5>Malformed forged technique</h5><div class="manual-badge-list"><span>Importer guard</span></div></div>
        <p class="manual-technique-effect">Entry was preserved but could not be rendered as a normal object.</p>
      </article>
    `;
  }
  const action = forgedTechniqueAction(item, actions);
  const name = forgedTechniqueDisplayName(item);
  const body = forgedTechniqueText(item, action);
  const components = forgedTechniqueComponents(item);
  const linkedAction = item.linked_action_id || item.action_id || action?.action_id || action?.id || "";
  const economy = item.action_economy || item.action_type || item.type || action?.action_economy || action?.action_type || action?.type || "";
  const cost = forgedTechniqueCostDisplay(item.cost || item.resource_cost || action?.cost || action?.resource_spent || "");
  const triggerOrUse = item.trigger || item.use_condition || item.activation || action?.trigger || action?.use_condition || "";
  const rollSave = item.roll_save || item.attack_or_save || item.check || item.save || action?.attack_or_save || "";
  const quickGrid = forgedTechniqueQuickGridHtml([
    ["Economy", economy, 160],
    ["Cost", cost, 180],
    ["Roll / Save", rollSave, 240],
    ["Components", components.join(", "), 260]
  ]);
  const triggerHtml = forgedTechniqueFieldHtml(item.trigger ? "Trigger" : "Use", triggerOrUse, 300);
  const durationHtml = forgedTechniqueFieldHtml("Duration", item.duration || action?.duration, 180);
  const limitHtml = forgedTechniqueFieldHtml("Limit", item.limit || item.limits || item.uses || action?.limit || action?.limits, 320);
  const riskHtml = forgedTechniqueFieldHtml("Risk / Strain", item.risk || item.risks || item.strain || item.drawback || item.drawbacks || item.burden, 320);
  const formulaHtml = forgedTechniqueFieldHtml("Formula", item.formula || item.forging_formula || item.recipe || item.creation_notes, 340);
  const sourceHtml = forgedTechniqueFieldHtml("Source", item.source || item.source_name || item.provenance || item.origin || item.status, 280);
  const actionHtml = linkedAction ? forgedTechniqueFieldHtml("Linked Action", linkedAction, 220) : "";
  return `
    <article class="manual-technique-card forged-technique-card">
      <div class="manual-technique-head">
        <h5>${escapeHtml(name)}</h5>
        <div class="manual-badge-list">${forgedTechniqueBadges(item, action)}</div>
      </div>
      ${quickGrid}
      ${body ? `<p class="manual-technique-resolution"><strong>Effect:</strong> ${escapeHtml(truncateValue(body, 620))}</p>` : ""}
      <div class="manual-technique-foot">
        ${triggerHtml}
        ${durationHtml}
        ${limitHtml}
        ${riskHtml}
        ${formulaHtml}
        ${sourceHtml}
        ${actionHtml}
      </div>
    </article>
  `;
}

function forgedTechniquePanelHtml(entries = [], actions = [], integrity = null) {
  const list = compactImportList(entries);
  const facet = importIntegrityFacetByKey(integrity, "forged");
  if (!list.length) return `<p class="sheet-description">${escapeHtml(importIntegrityEmptyMessage(facet, "No forged techniques declared in this package."))}</p>`;
  const componentPool = [...new Set(list.flatMap((item) => forgedTechniqueComponents(item)))];
  const markdownCount = list.filter((item) => item && typeof item === "object" && item.markdown_derived).length;
  const sourceBadge = markdownCount ? `${markdownCount} markdown-imported` : "structured import";
  const componentBadges = componentPool.slice(0, 10).map((name) => `<span>${escapeHtml(name)}</span>`).join("");
  return `
    <div class="manual-stack forged-registry-stack">
      <article class="martial-manual-card forged-registry-card">
        <header class="martial-manual-header">
          <div>
            <span class="manual-label">Forged Technique Registry</span>
            <h4>Studied / Emergency Forged Techniques</h4>
          </div>
          <span class="manual-count">${escapeHtml(String(list.length))} technique${list.length === 1 ? "" : "s"}</span>
        </header>
        <p class="manual-summary">Cross-sphere or crisis-forged techniques are separated from normal talents and martial manuals. Use this tab as the table-facing registry for economy, cost, required opening, roll/save, effect, and limits.</p>
        <div class="manual-badge-list">
          <span>${escapeHtml(sourceBadge)}</span>
          ${componentPool.length ? `<span>${escapeHtml(String(componentPool.length))} component route${componentPool.length === 1 ? "" : "s"}</span>` : ""}
          ${componentBadges}
        </div>
        <details class="manual-forms-details" open>
          <summary>Known forged techniques</summary>
          <div class="manual-technique-list forged-technique-list">
            ${list.map((item) => forgedTechniqueCard(item, actions)).join("")}
          </div>
        </details>
      </article>
    </div>
  `;
}

function inventoryDetail(item) {
  if (typeof item === "string") return { title: item, body: "" };
  if (!item || typeof item !== "object") return { title: "Entry", body: "" };
  return {
    title: item.display_name || item.name || item.item_name || item.manual_name || item.style_name || item.feature_name || item.entry_name || "Unnamed Entry",
    body: [
      item.quantity !== undefined && item.quantity !== "" ? `Qty: ${item.quantity}` : "",
      item.status ? `Status: ${item.status}` : "",
      item.uses !== undefined && item.uses !== "" ? `Uses: ${item.uses}` : "",
      item.charges !== undefined && item.charges !== "" ? `Charges: ${item.charges}` : "",
      item.source || item.source_name ? `Source: ${item.source || item.source_name}` : "",
      item.notes || item.summary || item.description || item.effect || item.mechanics || item.intent || ""
    ].filter(Boolean).join(" | ")
  };
}

function martialArtDetail(item) {
  if (typeof item === "string") return { title: item, body: "" };
  if (!item || typeof item !== "object") return { title: "Manual", body: "" };
  return {
    title: item.display_name || item.name || item.manual_name || item.style_name || "Unnamed Manual",
    body: [
      item.status ? `Status: ${item.status}` : "",
      Array.isArray(item.techniques) && item.techniques.length ? `Technique Ledger: ${item.techniques.length} recorded form${item.techniques.length === 1 ? "" : "s"}` : "Style Record Only: no structured form ledger supplied",
      item.source_or_teacher ? `Source: ${item.source_or_teacher}` : item.source || item.source_name ? `Source: ${item.source || item.source_name}` : "",
      item.doctrine ? `Doctrine: ${item.doctrine}` : "",
      Array.isArray(item.associated_spheres) && item.associated_spheres.length ? `Spheres: ${item.associated_spheres.join(", ")}` : "",
      Array.isArray(item.associated_techniques) && item.associated_techniques.length ? `Techniques: ${item.associated_techniques.join(", ")}` : "",
      Array.isArray(item.associated_talents) && item.associated_talents.length ? `Talents: ${item.associated_talents.join(", ")}` : "",
      Array.isArray(item.equipment_or_body_requirements) && item.equipment_or_body_requirements.length ? `Requirements: ${item.equipment_or_body_requirements.join(", ")}` : "",
      Array.isArray(item.advancement_hooks) && item.advancement_hooks.length ? `Advancement: ${item.advancement_hooks.join(", ")}` : "",
      Array.isArray(item.does_not_grant) && item.does_not_grant.length ? `Does not grant: ${item.does_not_grant.join(", ")}` : "",
      item.notes || item.summary || item.description || ""
    ].filter(Boolean).join(" | ")
  };
}

function techniqueKey(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function actionDisplayName(action) {
  if (!action || typeof action !== "object") return "";
  return preferredActionDisplayName(action, action?.action_name || action?.name || action?.option_name || "");
}

function linkedManualActions(manual, actions = []) {
  if (!manual || typeof manual !== "object" || !Array.isArray(actions)) return [];
  const forms = martialManualForms(manual);
  const declaredIds = new Set(forms.map((form) => String(form?.linked_action_id || form?.action_id || form?.id || "").trim()).filter(Boolean));
  const declaredNames = [
    ...(manual.associated_techniques || []),
    ...forms.map((form) => typeof form === "string" ? form : form?.name || form?.display_name || form?.linked_action_name)
  ].map((name) => ({ key: techniqueKey(name), words: String(name || "").toLowerCase() })).filter((entry) => entry.key);
  return actions.filter((action) => {
    const actionId = String(action?.action_id || action?.id || "").trim();
    if (actionId && declaredIds.has(actionId)) return true;
    const actionName = techniqueKey(actionDisplayName(action));
    return actionName && declaredNames.some((entry) => entry.key.length >= 6 && (actionName.includes(entry.key) || entry.key.includes(actionName) || sharedTechniqueWords(entry.words, actionDisplayName(action)) >= 2));
  });
}

function sharedTechniqueWords(left, right) {
  const leftWords = String(left || "").match(/[a-z]+/g) || [];
  const rightWords = new Set(String(right || "").match(/[a-z]+/g) || []);
  return leftWords.filter((word) => word.length > 3 && rightWords.has(word)).length;
}

function manualActionForForm(form, actions = []) {
  if (!form || typeof form !== "object") return null;
  const actionId = String(form?.linked_action_id || form?.action_id || form?.id || "").trim();
  if (actionId) {
    const exact = actions.find((action) => String(action?.action_id || action?.id || "").trim() === actionId);
    if (exact) return exact;
  }
  const formKey = techniqueKey(firstHf05aAlias(form) || form?.name || form?.display_name || form?.linked_action_name);
  if (!formKey) return null;
  return actions.find((action) => {
    const actionKey = techniqueKey(actionDisplayName(action));
    return actionKey && (actionKey.includes(formKey) || formKey.includes(actionKey));
  }) || null;
}

function manualSourceNames(form, action, manual) {
  const rawSources = [
    ...(Array.isArray(manual?.routes_or_spheres) ? manual.routes_or_spheres : []),
    ...(Array.isArray(manual?.associated_spheres) ? manual.associated_spheres : []),
    ...(Array.isArray(form?.associated_spheres) ? form.associated_spheres : []),
    ...(Array.isArray(action?.legal_backbone) ? action.legal_backbone.map((item) => item?.sphere_or_route || item?.sphere || item?.route) : []),
    ...(form?.sphere_source ? [form.sphere_source] : []),
    ...(form?.source ? [form.source] : []),
    ...(Array.isArray(action?.source) ? action.source : action?.source ? [action.source] : [])
  ];
  const ignored = new Set(["body refining", "qi cultivation", "spirit awakening", "chakra", String(manual?.name || "").toLowerCase(), "manual form"]);
  const noisy = /^(?:martial[_\s-]*manual[_\s-]*form|manual[_\s-]*form|source[_\s-]*conversion|v?1[_\s.-]*11|hf0\d|expression[_\s-]*ready)$/i;
  const clean = rawSources
    .map((source) => String(source || "").replace(/^Sphere of\s+/i, "").trim())
    .filter((source) => source && !ignored.has(source.toLowerCase()) && !noisy.test(source));
  return [...new Set(clean)].slice(0, 6);
}

function manualGrade(form) {
  const text = String(form?.grade || form?.minimum_realm || "").trim();
  const match = text.match(/mortal|foundation|core formation|nascent soul/i);
  return match ? titleCase(match[0].toLowerCase()) : text || "Learned";
}

function manualPractice(form) {
  const text = String(form?.practice_requirement || "").replace(/\s+/g, " ").trim();
  const dc = text.match(/Martial Practice DC\s*(\d+)/i);
  return dc ? `Martial Practice DC ${dc[1]}` : text || "Practice requirement recorded";
}

function martialFormName(form, action = null) {
  if (typeof form === "string") return form;
  if (!form || typeof form !== "object") return actionDisplayName(action) || "Unnamed Form";
  return String(firstHf05aAlias(form) || form?.display_name || form?.name || form?.linked_action_name || actionDisplayName(action) || form?.form_id || form?.linked_action_id || "Unnamed Form").replace(/^Sphere of\s+/i, "").trim();
}

function martialTextSnippet(...values) {
  return values.map((value) => asDisplayText(value).replace(/\s+/g, " ").trim()).find(Boolean) || "";
}

function martialFormFormula(form, manual, actions = []) {
  if (typeof form === "string") return form;
  const action = manualActionForForm(form, actions);
  return martialFormName(form, action);
}

function martialFormDescription(form, actions = []) {
  const action = manualActionForForm(form, actions);
  const description = martialTextSnippet(
    form?.effect_summary,
    form?.resolution,
    form?.description,
    form?.effect,
    action?.effect_summary,
    action?.resolution,
    action?.damage_or_effect,
    action?.description,
    action?.effect,
    action?.action_validation_gate_v1_11?.defined_result
  );
  return truncateValue(description, 540);
}

function martialFormBadges(form = {}, action = null, manual = null) {
  const grade = manualGrade(form);
  const badges = [
    form?.timing || action?.timing || action?.type || action?.action_type,
    form?.cost || action?.cost,
    form?.range || action?.range,
    form?.target || action?.target,
    grade && grade !== "Learned" ? grade : "Learned form"
  ].map((item) => asDisplayText(item).replace(/\s+/g, " ").trim()).filter(Boolean);
  return [...new Set(badges)].slice(0, 8).map((badge) => `<span>${escapeHtml(badge)}</span>`).join("");
}

function manualTitle(manual = {}) {
  if (!manual || typeof manual !== "object") return String(manual || "Unnamed Manual").trim();
  return String(firstHf05aAlias(manual) || manual.display_name || manual.name || manual.manual_name || manual.style_name || "Unnamed Manual").trim();
}

function manualSummary(manual = {}) {
  return asDisplayText(martialTextSnippet(manual.summary, manual.doctrine, manual.description, manual.notes, manual.source_status, manual.source_or_teacher, manual.source, manual.source_name));
}

function manualChipList(manual = {}) {
  const chips = [
    ...(Array.isArray(manual.routes_or_spheres) ? manual.routes_or_spheres : []),
    ...(Array.isArray(manual.associated_spheres) ? manual.associated_spheres : []),
    manual.realm_gate ? "Realm gated" : "",
    manual.grants_spheres === false || manual.does_not_grant_sphere_or_talent ? "No free sphere/talent" : "",
    manual.source_status ? "Source-linked" : ""
  ].map((item) => String(item || "").trim()).filter(Boolean);
  return [...new Set(chips)].slice(0, 10).map((chip) => `<span>${escapeHtml(chip)}</span>`).join("");
}

function manualTechniqueFieldHtml(label, value, max = 280) {
  const text = asDisplayText(martialTextSnippet(value));
  return text ? `<div class="manual-technique-meta"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(truncateValue(text, max))}</div>` : "";
}

function martialTechniqueCard(form, manual, actions = []) {
  const action = manualActionForForm(form, actions);
  const name = martialFormName(form, action);
  const description = martialFormDescription(form, actions);
  const linkedAction = form?.linked_action_id || action?.action_id || action?.id || "";
  const resolution = martialTextSnippet(form?.resolution, action?.resolution, action?.action_validation_gate_v1_11?.defined_result);
  const practice = manualPractice(form);
  const sources = manualSourceNames(form, action, manual);
  const sourceHtml = sources.length ? `<div class="manual-technique-meta"><strong>Backbone:</strong> ${escapeHtml(sources.join(", "))}</div>` : "";
  const actionHtml = linkedAction ? `<div class="manual-technique-meta"><strong>Action:</strong> ${escapeHtml(asDisplayText(linkedAction))}</div>` : "";
  const practiceHtml = practice ? `<div class="manual-technique-meta"><strong>Practice:</strong> ${escapeHtml(practice)}</div>` : "";
  const learnedFrom = form?.learned_from || [
    Array.isArray(form?.source_spheres) ? form.source_spheres.join(", ") : form?.source_spheres || (Array.isArray(form?.associated_spheres) ? form.associated_spheres.join(", ") : form?.associated_spheres),
    Array.isArray(form?.source_talent_names) ? form.source_talent_names.join(", ") : form?.source_talent_names
  ].map(asDisplayText).filter(Boolean).join(" — ");
  const sv05ManualHtml = [
    manualTechniqueFieldHtml("Learned from", learnedFrom, 360),
    manualTechniqueFieldHtml("Source spheres", form?.source_spheres || form?.associated_spheres, 260),
    manualTechniqueFieldHtml("Source talents", form?.source_talent_names || form?.source_talent_ids, 320),
    manualTechniqueFieldHtml("Packet refs", form?.source_packet_ids, 360),
    manualTechniqueFieldHtml("ACT refs", form?.act_action_refs || form?.linked_action_id, 260),
    manualTechniqueFieldHtml("Action cost policy", form?.action_cost_policy, 360),
    manualTechniqueFieldHtml("Fixed expression", form?.fixed_talent_expression, 420),
    manualTechniqueFieldHtml("Does-not-grant", form?.does_not_grant_policy || manual?.does_not_grant_policy, 520)
  ].join("");
  const triggerHtml = manualTechniqueFieldHtml(form?.trigger ? "Trigger" : "Use", form?.trigger || form?.use_condition || action?.trigger || action?.use_condition, 260);
  const rollHtml = manualTechniqueFieldHtml("Roll/Save", form?.roll_save || form?.attack_or_save || action?.attack_or_save, 260);
  const durationHtml = manualTechniqueFieldHtml("Duration", form?.duration || action?.duration, 180);
  const oaHtml = manualTechniqueFieldHtml("Opportunity Attacks", form?.opportunity_attacks || action?.opportunity_attacks, 220);
  const limitHtml = manualTechniqueFieldHtml("Limit", form?.limit || form?.limits || action?.limit || action?.limits, 320);
  const resolutionHtml = resolution && resolution !== description ? `<p class="manual-technique-resolution"><strong>Resolution:</strong> ${escapeHtml(truncateValue(resolution, 360))}</p>` : "";
  return `
    <article class="manual-technique-card">
      <div class="manual-technique-head">
        <h5>${escapeHtml(name)}</h5>
        <div class="manual-badge-list">${martialFormBadges(form, action, manual)}</div>
      </div>
      ${description ? `<p class="manual-technique-effect">${escapeHtml(description)}</p>` : ""}
      ${resolutionHtml}
      <div class="manual-technique-foot">
        ${triggerHtml}
        ${rollHtml}
        ${durationHtml}
        ${oaHtml}
        ${limitHtml}
        ${actionHtml}
        ${sourceHtml}
        ${practiceHtml}
        ${sv05ManualHtml}
      </div>
    </article>
  `;
}

function martialArtPanelHtml(entries = [], actions = [], integrity = null) {
  const facet = importIntegrityFacetByKey(integrity, "manuals");
  if (!Array.isArray(entries) || !entries.length) return `<p class="sheet-description">${escapeHtml(importIntegrityEmptyMessage(facet, "No martial manuals declared outside sphere/talent limits."))}</p>`;
  return `<div class="manual-stack">${entries.map((manual) => {
    if (!manual || typeof manual !== "object") return visualDetailCards([manual], martialArtDetail);
    const forms = martialManualForms(manual);
    const actionLinks = linkedManualActions(manual, actions);
    const title = manualTitle(manual);
    const summary = manualSummary(manual);
    const source = manual.source_status || manual.source_or_teacher || manual.source || manual.source_name || "";
    const realm = manual.realm_gate || manual.status || "";
    const formCount = forms.length || actionLinks.length || 0;
    const formHtml = forms.length
      ? `<div class="manual-technique-list">${forms.map((form) => martialTechniqueCard(form, manual, actions)).join("")}</div>`
      : actionLinks.length
        ? `<div class="manual-technique-list">${actionLinks.map((action) => martialTechniqueCard({ name: actionDisplayName(action), linked_action_id: action.action_id || action.id, resolution: action.resolution || action.effect_summary || action.damage_or_effect, timing: action.timing || action.type, cost: action.cost, range: action.range, target: action.target }, manual, actions)).join("")}</div>`
        : `<p class="sheet-description">Manual summary imported. No separate form ledger or linked action IDs were provided in this package.</p>`;
    return `
      <article class="martial-manual-card">
        <header class="martial-manual-header">
          <div>
            <span class="manual-label">Martial Manual</span>
            <h4>${escapeHtml(title)}</h4>
          </div>
          <span class="manual-count">${escapeHtml(String(formCount))} form${formCount === 1 ? "" : "s"}</span>
        </header>
        ${summary ? `<p class="manual-summary">${escapeHtml(summary)}</p>` : ""}
        <div class="manual-badge-list">${manualChipList(manual)}</div>
        ${(source || realm) ? `<dl class="manual-meta-grid">${source ? `<div><dt>Source</dt><dd>${escapeHtml(source)}</dd></div>` : ""}${realm ? `<div><dt>Gate</dt><dd>${escapeHtml(realm)}</dd></div>` : ""}</dl>` : ""}
        <details class="manual-forms-details" open>
          <summary>Learned techniques</summary>
          ${formHtml}
        </details>
      </article>
    `;
  }).join("")}</div>`;
}


function foundationValueText(value) {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "string") return polishMachineReadableText(value);
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(foundationValueText).filter(Boolean).join("; ");
  if (typeof value === "object") {
    return [value.name, value.title, value.id, value.when, value.effect, value.text, value.summary, value.description, value.rule]
      .map((item) => String(item || "").trim())
      .filter(Boolean)
      .join(value.when && value.effect ? " — " : " | ");
  }
  return String(value);
}

function foundationListValues(item = {}, keys = []) {
  const out = [];
  keys.forEach((key) => {
    const value = item?.[key];
    if (Array.isArray(value)) out.push(...value);
    else if (value && typeof value === "object") out.push(...Object.values(value));
    else if (value !== undefined && value !== null && value !== "") out.push(value);
  });
  return out.map(foundationValueText).map((text) => text.replace(/\s+/g, " ").trim()).filter(Boolean);
}

function foundationDisplayName(item = {}) {
  if (!item || typeof item !== "object") return String(item || "Foundation").trim();
  return String(item.display_name || item.name || item.foundation_name || item.formal_name || item.foundation_id || item.id || "Foundation").trim();
}

function foundationDoctrine(item = {}) {
  return martialTextSnippet(item.core_doctrine, item.dao_principle, item.thesis, item.doctrine, item.known_player_text?.common_knowledge, item.summary, item.description);
}

function foundationPill(text, tone = "") {
  return text ? `<span class="foundation-pill ${tone}">${escapeHtml(text)}</span>` : "";
}

function foundationBullets(items = [], empty = "Not recorded.") {
  const rows = [...new Set((items || []).map(foundationValueText).map((text) => text.trim()).filter(Boolean))];
  if (!rows.length) return `<p class="foundation-empty">${escapeHtml(empty)}</p>`;
  return `<ul class="foundation-bullet-list">${rows.slice(0, 18).map((row) => `<li>${escapeHtml(row)}</li>`).join("")}</ul>`;
}

function foundationStatCards(item = {}) {
  const family = foundationValueText(item.foundation_type || (Array.isArray(item.family) ? item.family : (item.family || item.foundation_family || item.path || "Unclassified")));
  const stage = foundationValueText(item.foundation_family || [item.depth, item.stage].filter(Boolean).join(" / ") || item.realm_gate || "Recorded");
  const status = foundationValueText(item.status || item.disposition || item.foundation_catalogue_status || item.source_status || "Active package foundation");
  const authority = foundationValueText(item.foundation_provenance?.authority_tier || item.provenance?.authority_tier || item.source_status || "Package source");
  return `
    <div class="foundation-stat-grid">
      <article><strong>Family</strong><span>${escapeHtml(String(family))}</span></article>
      <article><strong>Depth / Stage</strong><span>${escapeHtml(String(stage))}</span></article>
      <article><strong>Status</strong><span>${escapeHtml(String(status))}</span></article>
      <article><strong>Authority</strong><span>${escapeHtml(String(authority))}</span></article>
    </div>
  `;
}

function foundationKnownTextHtml(item = {}) {
  const known = item.known_player_text || {};
  const rows = [
    ["Common knowledge", known.common_knowledge],
    ["Visible sign", known.visible_sign],
    ["Known benefit", known.known_benefit],
    ["Known warning", known.known_warning],
    ["Origin", item.origin],
    ["Correction", item.import_correction]
  ].filter(([, value]) => value);
  if (!rows.length) return "";
  return `<div class="foundation-fact-grid">${rows.map(([label, value]) => `
    <article><strong>${escapeHtml(label)}</strong><p>${escapeHtml(truncateValue(value, 520))}</p></article>
  `).join("")}</div>`;
}

function foundationBenefits(item = {}) {
  const stageText = foundationStageBenefitText(item, item.stage || item.default_stage || "");
  const compatible = item.compatible_spheres || item.compatibility?.compatible_spheres || [];
  return [
    stageText,
    ...foundationListValues(item, ["benefits", "mechanical_benefits", "mechanical_benefits_or_constraints", "foundation_benefits", "body_refining_interaction"]),
    ...foundationListValues(item, ["mechanical_permissions", "permissions"]),
    ...(Array.isArray(compatible) && compatible.length ? [`Compatible sphere expressions: ${compatible.map(asDisplayText).join(", ")}`] : [])
  ].filter(Boolean);
}

function foundationBurdens(item = {}) {
  const burdenText = foundationStageBurdenText(item, item.stage || item.default_stage || "");
  const strained = item.strained_spheres || item.compatibility?.strained_spheres || [];
  const incompatible = item.incompatible_spheres || item.compatibility?.incompatible_spheres || [];
  return [
    burdenText,
    ...foundationListValues(item, ["burdens", "drawbacks", "foundation_burdens", "burden_deviation_risks"]),
    ...foundationListValues(item, ["explicit_non_permissions", "non_permissions"]),
    ...(Array.isArray(strained) && strained.length ? [`Strained spheres: ${strained.map(asDisplayText).join(", ")}`] : []),
    ...(Array.isArray(incompatible) && incompatible.length ? [`Forbidden or unsafe expressions: ${incompatible.map(asDisplayText).join(", ")}`] : [])
  ].filter(Boolean);
}

function foundationTriggers(item = {}) {
  return foundationListValues(item, ["triggers", "trigger_registry", "foundation_triggers", "activation_triggers", "breakthrough_relevance"]);
}

function foundationCounters(item = {}) {
  return foundationListValues(item, ["counters", "counter_registry", "counter_closure", "countermeasures", "does_not_grant_boundaries"]);
}

function foundationExplainerHtml() {
  return `
    <section class="foundation-explainer">
      <div>
        <span class="manual-label">Foundations in play</span>
        <h4>What a Foundation does</h4>
        <p>A Foundation is the character's cultivation architecture: the reason their talents, manuals, burdens, breakthrough risks, and source expression hold together. It is not a free sphere or a loose power permission.</p>
      </div>
      <div class="foundation-explainer-grid">
        <article><strong>Benefits</strong><p>Stable advantages, permitted synergies, and package-specific ways the build can express its legal spheres/actions.</p></article>
        <article><strong>Burdens</strong><p>Costs, lockouts, strain, deviations, and the exact things the Foundation refuses to let the character do safely.</p></article>
        <article><strong>Triggers</strong><p>When special Foundation clauses fire: thresholds, failed saves, resource strain, last-stand clauses, or cleanup checks.</p></article>
        <article><strong>Counters</strong><p>The state/counter IDs used by the simulator so the Foundation remains executable instead of just descriptive prose.</p></article>
      </div>
    </section>
  `;
}

function foundationCardHtml(item = {}, index = 0) {
  const name = foundationDisplayName(item);
  const doctrine = foundationDoctrine(item);
  const pills = [
    item.path,
    item.realm_gate,
    item.epithet,
    item.foundation_catalogue_status,
    item.import_correction ? "Corrected import" : ""
  ].map((text) => String(text || "").trim()).filter(Boolean);
  return `
    <article class="foundation-card">
      <header class="foundation-card-header">
        <div>
          <span class="manual-label">Current Foundation ${index + 1}</span>
          <h4>${escapeHtml(name)}</h4>
        </div>
        <span class="foundation-index">${escapeHtml(String(index + 1))}</span>
      </header>
      ${pills.length ? `<div class="foundation-pill-row">${pills.slice(0, 8).map((pill) => foundationPill(pill)).join("")}</div>` : ""}
      ${doctrine ? `<p class="foundation-doctrine">${escapeHtml(truncateValue(doctrine, 760))}</p>` : ""}
      ${foundationStatCards(item)}
      ${foundationKnownTextHtml(item)}
      <div class="foundation-section-grid">
        <section><h5>Benefits / Permissions</h5>${foundationBullets(foundationBenefits(item), "No mechanical benefits recorded.")}</section>
        <section><h5>Burdens / Non-permissions</h5>${foundationBullets(foundationBurdens(item), "No burdens recorded.")}</section>
        <section><h5>Triggers</h5>${foundationBullets(foundationTriggers(item), "No Foundation trigger registry imported.")}</section>
        <section><h5>Counters / Tracking</h5>${foundationBullets(foundationCounters(item), "No counters linked to this Foundation.")}</section>
      </div>
    </article>
  `;
}

function foundationPanelHtml(entries = [], sheet = {}) {
  const foundations = Array.isArray(entries) ? entries.filter(Boolean) : [];
  const summary = foundations.length
    ? `${foundations.length} Foundation record${foundations.length === 1 ? "" : "s"} imported for ${sheet?.name || "this character"}.`
    : "No Foundation record imported for this character.";
  return `
    <div class="foundation-panel">
      ${foundationExplainerHtml()}
      <div class="foundation-panel-summary">${escapeHtml(summary)}</div>
      ${foundations.length ? foundations.map((item, index) => foundationCardHtml(item, index)).join("") : `<p class="sheet-description">No Foundation record. Re-import an HF05/HF05B package or inspect Foundation_Registry.json.</p>`}
      ${sheet.chakraRecord ? `<div class="section-divider">Chakra Record</div><p class="sheet-description">${escapeHtml(sheet.chakraRecord)}</p>` : ""}
    </div>
  `;
}

function inventoryLine(item) {
  const detail = inventoryDetail(item);
  return [detail.title, detail.body].filter(Boolean).join(" | ");
}

function visualActionRows(actions) {
  if (!Array.isArray(actions) || !actions.length) {
    return `<p class="sheet-description">No action registry found in this package.</p>`;
  }
  return `
    <div class="action-table-wrap">
      <table class="action-table">
        <thead>
          <tr>
            <th>Action</th>
            <th>Type</th>
            <th>Range</th>
            <th>Roll</th>
            <th>Cost</th>
            <th>Effect</th>
          </tr>
        </thead>
        <tbody>
          ${actions.map((action) => {
            const targeting = action.targeting || {};
            const resolution = action.resolution || {};
            const type = action.action_type || action.type || action.action_economy || action.event_pattern?.action_economy_slot || "—";
            const range = action.range_or_reach || targeting.range_or_reach || targeting.range || "—";
            const attackSave = asDisplayText(action.attack_or_save) || asDisplayText(resolution.attack_or_save) || asDisplayText(resolution.attack_or_save_summary) || asDisplayText(resolution.legacy_attack_or_save);
            const roll = [
              attackSave,
              (resolution.attack_bonus ?? action.attack_bonus) !== undefined && (resolution.attack_bonus ?? action.attack_bonus) !== null ? formatSigned(resolution.attack_bonus ?? action.attack_bonus) : "",
              (resolution.save_dc ?? action.save_dc) ? `DC ${resolution.save_dc ?? action.save_dc}` : ""
            ].filter(Boolean).join("; ") || "—";
            const damageText = damageInstancesText(resolution.damage_instances || action.damage_instances);
            const effects = Array.isArray(resolution.effects) ? resolution.effects : action.effects;
            const effectsText = Array.isArray(effects) ? effects.filter(Boolean).join("; ") : "";
            const effect = compactText(action.damage_or_effect || damageText || effectsText || resolution.legacy_effect_display || resolution.authoritative_source_text || "—", 220);
            return `
              <tr>
                <td>${escapeHtml(action.action_name || action.name || action.option_name || "Unnamed Action")}</td>
                <td>${escapeHtml(asDisplayText(type))}</td>
                <td>${escapeHtml(asDisplayText(range))}</td>
                <td>${escapeHtml(roll)}</td>
                <td>${escapeHtml(compactText(action.cost || "—", 120))}</td>
                <td>${escapeHtml(effect)}</td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function visualActionRowsV2(actions) {
  if (!Array.isArray(actions) || !actions.length) {
    return `<p class="sheet-description">No action registry found in this package.</p>`;
  }
  return `
    <div class="action-table-wrap">
      <table class="action-table">
        <thead>
          <tr>
            <th>Action</th>
            <th>Type</th>
            <th>Range</th>
            <th>Roll</th>
            <th>Cost</th>
            <th>Effect</th>
          </tr>
        </thead>
        <tbody>
          ${actions.map((action) => {
            const targeting = action.targeting || {};
            const resolution = action.resolution || {};
            const type = action.economy_label || action.action_economy || action.action_type || action.type || action.event_pattern?.action_economy_slot || "-";
            const range = action.range_or_reach || action.range || targeting.range_or_reach || targeting.range || "-";
            const attackSave = asDisplayText(action.attack_or_save)
              || asDisplayText(resolution.attack_or_save)
              || asDisplayText(resolution.attack_or_save_summary)
              || asDisplayText(resolution.legacy_attack_or_save)
              || (action.save_ability ? `${action.save_ability} save` : "");
            const roll = [
              attackSave,
              (resolution.attack_bonus ?? action.attack_bonus) !== undefined && (resolution.attack_bonus ?? action.attack_bonus) !== null ? formatSigned(resolution.attack_bonus ?? action.attack_bonus) : "",
              (resolution.save_dc ?? action.save_dc) ? `DC ${resolution.save_dc ?? action.save_dc}` : ""
            ].filter(Boolean).join("; ") || "-";
            const damageText = damageInstancesText(resolution.damage_instances || action.damage_instances || action.effect_packets);
            const effects = Array.isArray(resolution.effects) ? resolution.effects : action.effects || action.effect_packets;
            const effectsText = Array.isArray(effects) ? effects.map(asDisplayText).filter(Boolean).join("; ") : "";
            const effect = compactText(action.damage_or_effect || damageText || effectsText || action.description || resolution.legacy_effect_display || resolution.authoritative_source_text || "-", 220);
            return `
              <tr>
                <td>${escapeHtml(actionDisplayName(action) || "Unnamed Action")}${legalAuditDisplayName(action) ? `<br><small class="muted">${escapeHtml(legalAuditDisplayName(action))}</small>` : ""}</td>
                <td>${escapeHtml(asDisplayText(type))}</td>
                <td>${escapeHtml(asDisplayText(range))}</td>
                <td>${escapeHtml(roll)}</td>
                <td>${escapeHtml(compactText(action.cost || action.resource_spent || "-", 120))}</td>
                <td>${escapeHtml(effect)}</td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function actionsByType(actions, pattern) {
  return compactImportList(actions).filter((action) => {
    const bucket = canonicalEconomyBucket(action);
    if (/bonus/i.test(String(pattern))) return bucket === "bonus_action";
    if (/reaction|trigger/i.test(String(pattern))) return bucket === "reaction";
    if (/\bAction\b/i.test(String(pattern))) return bucket === "action";
    if (/passive/i.test(String(pattern))) return bucket === "passive";
    const haystack = [
      bucket,
      action?.economy_label,
      action?.economy,
      action?.action_type,
      action?.type,
      action?.action_economy,
      action?.event_pattern?.action_economy_slot,
      firstHf05aAlias(action),
      action?.display_name,
      action?.action_name,
      action?.name
    ].join(" ");
    return pattern.test(haystack);
  });
}

const COMPOSITE_PRIORITY_ORDER = [
  { key: "opener", label: "Opener" },
  { key: "reaction line", label: "Reaction Line" },
  { key: "control engine", label: "Control Engine" },
  { key: "anti-caster line", label: "Anti-Caster Line" },
  { key: "finisher", label: "Finisher" },
  { key: "fallback", label: "Fallback" },
  { key: "uncategorized", label: "Uncategorized" }
];

function compositeKey(value = "") {
  return techniqueKey(value || "");
}

function compositeDisplayName(item = {}) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "Unnamed Composite";
  return item.display_name || item.name || item.composite_name || item.playbook_name || item.title || item.id || item.composite_id || item.use || item.ref || item.composite_ref || "Unnamed Composite";
}

function normalizeCompositePriority(value = "") {
  const text = String(value || "").toLowerCase().replace(/[_-]+/g, " ").trim();
  if (/anti\s*caster|caster\s*break|mage\s*break|spell/.test(text)) return "anti-caster line";
  if (/reaction|response|counter|interrupt/.test(text)) return "reaction line";
  if (/control|control engine|grapple chain|state conversion|lockdown|pin/.test(text)) return "control engine";
  if (/open|setup|engage|first/.test(text)) return "opener";
  if (/finish|kill|execute|closure|checkmate/.test(text)) return "finisher";
  if (/fallback|default|safe|reset|recover|backup/.test(text)) return "fallback";
  return "uncategorized";
}

function compositeNumericPriority(item = {}) {
  if (!item || typeof item !== "object") return -Infinity;
  const raw = item.ai_priority ?? item.priority_score ?? item.priority_value ?? item.priority_number ?? item.priority;
  const value = Number(raw);
  return Number.isFinite(value) ? value : -Infinity;
}

function compositePriorityWhen(item = {}) {
  if (!item || typeof item !== "object") return "";
  const projected = item.projection_contract_active ? sv05CompositeRoleSpecificLine(item) : "";
  return projected || asDisplayText(item.priority_when || item.when || item.when_to_use || item.use_when || item.trigger_window || item.tactical_when);
}

function compositeSortRank(item = {}) {
  const numeric = compositeNumericPriority(item);
  if (Number.isFinite(numeric)) return { numeric, role: 0 };
  const role = normalizeCompositePriority(item?.priority || item?.role || item?.category || item?.playbook_role);
  const index = COMPOSITE_PRIORITY_ORDER.findIndex((entry) => entry.key === role);
  return { numeric: -Infinity, role: index >= 0 ? index : 999 };
}

function compositeArrayFromData(data, keys = []) {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  for (const key of keys) {
    if (Array.isArray(data[key])) return data[key];
  }
  return [];
}

function compositeDeclaredListFromRegistry(data) {
  return compositeArrayFromData(data, [
    "composite_actions", "composites", "compositeActionRegistry", "composite_registry",
    "registry", "entries", "items", "playbook", "combat_playbook", "actions"
  ]);
}

function compositePriorityRailEntries(data) {
  const priorityTable = data?.priority_table || data?.priorityTable || null;
  if (Array.isArray(priorityTable)) {
    return priorityTable.map((entry) => ({
      entry,
      priorityHint: entry?.role || entry?.category || entry?.playbook_role || entry?.priority_role || "priority table",
      priorityMeta: entry
    }));
  }
  const rail = data?.priority_rail || data?.priorityRail || data?.priorities || data?.priority || null;
  if (!rail) return [];
  const out = [];
  if (Array.isArray(rail)) {
    rail.forEach((entry) => out.push({
      entry,
      priorityHint: entry?.priority || entry?.role || entry?.category || "uncategorized",
      priorityMeta: entry && typeof entry === "object" ? entry : null
    }));
    return out;
  }
  if (typeof rail === "object") {
    Object.entries(rail).forEach(([priority, entries]) => {
      if (Array.isArray(entries)) entries.forEach((entry) => out.push({ entry, priorityHint: priority, priorityMeta: entry && typeof entry === "object" ? { ...entry, priority_hint: priority } : null }));
      else if (entries) out.push({ entry: entries, priorityHint: priority, priorityMeta: entries && typeof entries === "object" ? { ...entries, priority_hint: priority } : null });
    });
  }
  return out;
}

function compositeIdentityKeys(item = {}) {
  if (typeof item === "string") return [compositeKey(item)].filter(Boolean);
  if (!item || typeof item !== "object") return [];
  return [
    item.id, item.composite_id, item.compositeId, item.playbook_id, item.key,
    item.use, item.ref, item.composite_ref, item.composite_reference, item.reference,
    item.name, item.display_name, item.composite_name, item.title
  ].map(compositeKey).filter(Boolean);
}

function makeCompositeMap(entries = []) {
  const map = new Map();
  entries.forEach((entry) => {
    compositeIdentityKeys(entry).forEach((key) => {
      if (key && !map.has(key)) map.set(key, entry);
    });
  });
  return map;
}

function mergeCompositeEntries(base = {}, overlay = {}) {
  const left = typeof base === "object" && base ? base : {};
  const right = typeof overlay === "object" && overlay ? overlay : { name: overlay };
  return { ...left, ...right };
}

function normalizeCompositeEntry(raw, priorityHint = "", sourceName = "Composite registry", registryMap = new Map(), priorityMeta = null) {
  let resolved = raw;
  if (typeof raw === "string") {
    resolved = registryMap.get(compositeKey(raw)) || { name: raw, declared_reference: raw };
  } else if (raw && typeof raw === "object") {
    const keys = compositeIdentityKeys(raw);
    const base = keys.map((key) => registryMap.get(key)).find(Boolean);
    if (base && base !== raw) resolved = mergeCompositeEntries(base, raw);
  } else {
    return null;
  }
  if (priorityMeta && typeof priorityMeta === "object") {
    resolved = {
      ...resolved,
      ai_priority: priorityMeta.priority ?? priorityMeta.ai_priority ?? resolved.ai_priority,
      priority_when: priorityMeta.when || priorityMeta.priority_when || priorityMeta.when_to_use || resolved.priority_when || resolved.when,
      priority_use: priorityMeta.use || priorityMeta.ref || priorityMeta.composite_ref || resolved.priority_use,
      priority_source: "Combat_Playbook.priority_table"
    };
  }
  const priority = normalizeCompositePriority(resolved.execution_role || resolved.gm_screen_category || resolved.role || resolved.category || resolved.playbook_role || resolved.tactical_role || (Array.isArray(resolved.tactical_roles) ? resolved.tactical_roles.join(" ") : "") || priorityHint || resolved.priority || resolved.phase);
  return {
    ...resolved,
    display_name: compositeDisplayName(resolved),
    priority,
    source_file: resolved.source_file || sourceName
  };
}

function componentDisplayName(component = {}) {
  if (typeof component === "string") return polishMachineReadableText(component);
  if (!component || typeof component !== "object") return "Unnamed Component";
  return polishMachineReadableText(component.display_name || component.name || component.action_name || component.talent_name || component.augment_name || component.forged_technique_name || component.technique_name || component.id || component.ref || component.action_id || component.talent_id || component.forged_technique_id || "Unnamed Component");
}

function componentType(component = {}) {
  if (typeof component === "string") return "component";
  const text = String(component?.component_type || component?.type || component?.kind || component?.ref_type || component?.source_type || "").toLowerCase();
  if (/forged/.test(text)) return "forged technique";
  if (/augment/.test(text)) return "augmentation";
  if (/talent/.test(text)) return "talent";
  if (/action/.test(text)) return "action";
  return text || "component";
}

function registrySearchKeys(item = {}) {
  if (typeof item === "string") return [compositeKey(item)].filter(Boolean);
  if (!item || typeof item !== "object") return [];
  return [
    item.id, item.ref, item.key, item.action_id, item.talent_id, item.augment_id,
    item.augmentation_id, item.technique_id, item.forged_technique_id, item.linked_action_id,
    item.action_link, item.actionLink, item.linked_action, item.linkedAction,
    item.source_action_id, item.sourceActionId, item.exec_action_id, item.execution_action_id,
    item.execution_block_ref, item.executionBlockRef,
    item.name, item.display_name, item.action_name, item.talent_name, item.augment_name,
    item.forged_technique_name, item.technique_name, item.title
  ].map((value) => String(value || "").split("#").pop()).map(compositeKey).filter(Boolean);
}

function makeAnyRegistryMap(items = []) {
  const map = new Map();
  compactImportList(items).forEach((item) => {
    registrySearchKeys(item).forEach((key) => {
      if (key && !map.has(key)) map.set(key, item);
    });
  });
  return map;
}

function resolveComponentEntry(component, registries = {}) {
  const keys = registrySearchKeys(component);
  const type = componentType(component);
  const pools = [];
  if (/forged/.test(type)) pools.push(registries.forgedMap);
  if (/augment/.test(type)) pools.push(registries.augmentMap);
  if (/talent/.test(type)) pools.push(registries.augmentMap);
  if (/action/.test(type)) pools.push(registries.actionMap);
  pools.push(registries.actionMap, registries.augmentMap, registries.forgedMap);
  for (const pool of pools.filter(Boolean)) {
    for (const key of keys) {
      if (pool.has(key)) return pool.get(key);
    }
  }
  return null;
}

function compositeComponentList(item = {}) {
  if (!item || typeof item !== "object") return [];
  const direct = firstAvailableList(
    item.component_stack,
    item.components,
    item.sequence,
    item.steps,
    item.action_sequence,
    item.action_stack,
    item.required_components,
    item.component_order
  );
  return compactImportList(direct);
}

function compositeAugmentationList(item = {}) {
  if (!item || typeof item !== "object") return [];
  return compactImportList(firstAvailableList(
    item.augmentation_stack,
    item.augmentations,
    item.talent_augmentations,
    item.talent_augmentation_stack,
    item.augments
  ));
}

function compositeOutputs(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(item.outputs || item.output || item.result || item.results || item.damage_or_effect || item.effect || item.resolution || item.win_condition || item.table_result);
}

function compositeLogic(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(item.logic_statement || item.logic || item.if_then || item.tactical_logic || item.condition_statement || item.summary || item.description);
}

function compositeThesis(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(item.build_thesis || item.thesis || item.combat_thesis || item.purpose || item.role_statement);
}

function compositeRequiredSpheres(item = {}) {
  if (!item || typeof item !== "object") return [];
  const raw = firstAvailableList(item.required_spheres, item.spheres, item.routes, item.component_spheres, item.required_routes);
  if (raw.length) return raw.map(asDisplayText).filter(Boolean);
  const text = asDisplayText(item.required_spheres || item.spheres || item.routes || "");
  return text ? text.split(/[;,]/).map((part) => part.trim()).filter(Boolean) : [];
}

function compositeTiming(item = {}) {
  if (!item || typeof item !== "object") return "";
  const projected = item.projection_contract_active ? sv05CompositeTimingText(item) : "";
  return projected || asDisplayText(item.timing || item.timing_window || item.activation_timing || item.turn_timing || item.when_to_use || item.window || item.when);
}

function compositeEconomyLedger(item = {}) {
  if (!item || typeof item !== "object") return "";
  const raw = item.economy_resource_ledger || item.economy_ledger || item.resource_ledger || item.ledger || item.economy || item.costs || item.cost || item.action_economy || item.once_per_turn_limits;
  if (!raw) return "";
  if (typeof raw === "object" && !Array.isArray(raw)) {
    return Object.entries(raw)
      .map(([key, value]) => `${titleCase(key.replace(/_/g, " "))}: ${forgedTechniqueCostDisplay(value) || asDisplayText(value)}`)
      .filter(Boolean)
      .join("; ");
  }
  return forgedTechniqueCostDisplay(raw) || asDisplayText(raw);
}

function compositeCounterplay(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(item.counterplay_panel || item.counterplay || item.enemy_counterplay || item.break_points || item.escape_routes || item.resist_dispel_escape || item.counters || item.countermeasures || item.how_to_break);
}

function compositeDoNotUse(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(item.do_not_use_panel || item.do_not_use || item.avoid_when || item.do_not_use_when || item.failure_conditions || item.waste_conditions || item.ai_do_not_use);
}

function compositeAiPrompt(item = {}, components = []) {
  if (!item || typeof item !== "object") return "";
  const explicit = asDisplayText(item.ai_turn_prompt || item.ai_prompt || item.prompt_export || item.tactical_instruction || item.turn_prompt || item.ai_instruction);
  if (explicit) return explicit;
  const lines = [
    `Composite: ${compositeDisplayName(item)}`,
    Number.isFinite(compositeNumericPriority(item)) ? `AI Priority: ${compositeNumericPriority(item)}` : "",
    compositePriorityWhen(item) ? `When: ${compositePriorityWhen(item)}` : "",
    compositeLogic(item) ? `Logic: ${compositeLogic(item)}` : "",
    compositeTiming(item) ? `Timing: ${compositeTiming(item)}` : "",
    components.length ? `Component order: ${components.map(componentDisplayName).join(" -> ")}` : "",
    compositeEconomyLedger(item) ? `Economy/resource: ${compositeEconomyLedger(item)}` : "",
    compositeOutputs(item) ? `Output: ${compositeOutputs(item)}` : "",
    compositeDoNotUse(item) ? `Do not use when: ${compositeDoNotUse(item)}` : "",
    compositeCounterplay(item) ? `Respect counterplay: ${compositeCounterplay(item)}` : ""
  ].filter(Boolean);
  return lines.join("\n");
}

function compositeFullRuleText(item = {}) {
  if (!item || typeof item !== "object") return "";
  return asDisplayText(
    item.full_rules_text || item.rules_text || item.authoritative_source_text || item.raw_markdown || item.source_text ||
    item.mechanics || item.description || item.effect || item.effect_summary || item.summary || item.resolution || item.limit || item.limits
  );
}

function temporalEntriesFromRegistry(data) {
  return compactImportList(firstAvailableList(
    data?.composite_temporal_entries,
    data?.temporal_feasibility,
    data?.temporal_entries,
    data?.entries,
    data?.registry,
    data?.items
  ));
}

function temporalIdentityKeys(item = {}) {
  if (!item || typeof item !== "object") return [];
  return [
    item.composite_id, item.compositeId, item.composite_ref, item.composite_reference,
    item.composite_name, item.name, item.display_name, item.title, item.id
  ].map(compositeKey).filter(Boolean);
}

function makeTemporalMap(entries = []) {
  const map = new Map();
  compactImportList(entries).forEach((entry) => {
    temporalIdentityKeys(entry).forEach((key) => {
      if (key && !map.has(key)) map.set(key, entry);
    });
  });
  return map;
}

function temporalForComposite(composite = {}, temporalMap = new Map()) {
  if (!composite || typeof composite !== "object") return null;
  const normalizeTemporal = (entry = {}, synthesized = false) => {
    if (!entry || typeof entry !== "object") return null;
    const out = { ...entry };
    out.temporal_status = out.temporal_status || out.status || composite.temporal_status || composite.temporal_feasibility_status || composite.temporal_display_status || (composite.projection_contract_active ? "SV05_PROJECTION_READY" : "TEMPORAL_READY");
    out.timing_class = out.timing_class || composite.timing_class || composite.execution_role || composite.priority || "SV05 projection";
    out.primary_followup_window = out.primary_followup_window || out.followup_window || out.window_order || composite.primary_followup_window || composite.followup_window || "See projection contract";
    out.selection_condition = out.selection_condition || out.legal_sequence || composite.selection_condition || composite.temporal_feasibility_summary || composite.temporal_feasibility || "Projected composite timing is recorded in GM_Screen_Projection_Rows.json.";
    out.selection_allowed = out.selection_allowed === false ? false : true;
    out.required_state_windows = compactImportList(out.required_state_windows || out.required_states || out.state_windows || composite.required_state_windows || composite.state_windows || composite.live_state_contract);
    out.step_window_sequence = compactImportList(out.step_window_sequence || out.step_sequence || out.window_sequence || out.steps || composite.step_window_sequence || composite.object_steps);
    out.sv05_projection_synthesized = synthesized || out.sv05_projection_synthesized || composite.projection_contract_active || false;
    return out;
  };
  const direct = composite.temporal || composite.state_window_lock || composite.hf05b3h_temporal;
  if (direct && typeof direct === "object") return normalizeTemporal(direct, composite.projection_contract_active);
  for (const key of compositeIdentityKeys(composite)) {
    if (temporalMap.has(key)) return normalizeTemporal(temporalMap.get(key), composite.projection_contract_active);
  }
  const projectedTemporal = composite.temporal_feasibility_summary || composite.temporal_feasibility || composite.timing_class || composite.selection_condition;
  if (projectedTemporal || composite.projection_contract_active) {
    return normalizeTemporal({
      timing_class: composite.timing_class || composite.execution_role || composite.priority || "SV05 projection",
      primary_followup_window: composite.primary_followup_window || composite.followup_window || "See SV05 projection contract",
      selection_condition: composite.selection_condition || composite.temporal_feasibility_summary || composite.temporal_feasibility || "Projected composite timing is recorded in GM_Screen_Projection_Rows.json."
    }, true);
  }
  return null;
}

function temporalStatusBadge(status = "") {
  const value = String(status || "MISSING_TEMPORAL_STATUS").toUpperCase();
  const blocked = /BLOCKED|REWRITE|MISSING/.test(value);
  const bridge = /BRIDGE/.test(value);
  const legal = /LEGAL|SAFE|SAME_TURN|REACTION/.test(value) && !blocked;
  const css = blocked ? "blocked" : bridge ? "bridge" : legal ? "legal" : "neutral";
  return `<span class="temporal-status-badge ${css}">${escapeHtml(value)}</span>`;
}

function temporalWindowRows(entry = {}) {
  return compactImportList(entry.required_state_windows || entry.required_states || entry.state_windows || entry.prerequisite_states || entry.windows);
}

function temporalSteps(entry = {}) {
  return compactImportList(entry.step_window_sequence || entry.step_sequence || entry.window_sequence || entry.steps);
}

function fieldObjectsFromRegistry(data) {
  return compactImportList(firstAvailableList(data?.field_objects, data?.fields, data?.entries, data?.items, data?.registry));
}

function anchorObjectsFromRegistry(data) {
  return compactImportList(firstAvailableList(data?.anchor_objects, data?.anchors));
}

function executionBlocksFromRegistry(data) {
  return compactImportList(firstAvailableList(data?.execution_blocks, data?.blocks, data?.entries, data?.registry, data?.items));
}

function makeExecutionBlockMap(entries = []) {
  const map = new Map();
  compactImportList(entries).forEach((entry) => {
    registrySearchKeys(entry).concat([
      entry?.action_id, entry?.action_name, entry?.id, entry?.name,
      entry?.source_link, entry?.source
    ].map(compositeKey).filter(Boolean)).forEach((key) => {
      if (key && !map.has(key)) map.set(key, entry);
    });
  });
  return map;
}

const HF05B3F_BASIC_ACTION_EXECUTION_LABELS = {
  universal_01: "Attack / Basic Strike",
  universal_02: "Opportunity Attack / Opportunity Strike",
  universal_03: "Disengage",
  universal_04: "Dash",
  universal_05: "Dodge",
  universal_06: "Grapple",
  universal_07: "Shove",
  universal_08: "Escape Grapple / Basic Physical Escape",
  universal_09: "Help",
  universal_10: "Hide",
  universal_11: "Ready",
  universal_12: "Search",
  universal_13: "Study",
  universal_14: "Utilize / Use Object",
  universal_15: "Influence",
  universal_16: "Magic / Technique Action Declaration"
};

function basicExecutionBlockForComponent(component = {}) {
  const keys = registrySearchKeys(component);
  for (const key of keys) {
    const normalized = key.replace(/_/g, "_");
    if (HF05B3F_BASIC_ACTION_EXECUTION_LABELS[normalized]) {
      return {
        id: `exec_${normalized}`,
        action_id: normalized,
        action_name: HF05B3F_BASIC_ACTION_EXECUTION_LABELS[normalized],
        execution_archetype: "hf05b3f_canonical_basic_action",
        activation: "Use the canonical HF05B3F Basic Action Execution Block Database entry for this universal action.",
        trigger: "Declared through the universal basic action procedure.",
        cost: "Uses the printed D&D/Tianxia basic action economy for this universal action.",
        attack_or_save: "Use the canonical basic action procedure; character-specific packages do not rewrite it.",
        effect_text: "This is a database-backed universal action. The character package references the canonical HF05B3F basic action block instead of duplicating it locally.",
        duration: "As canonical basic action procedure.",
        end_conditions: "As canonical basic action procedure.",
        counterplay: "As canonical basic action procedure."
      };
    }
  }
  return null;
}

function executionBlockForComponent(component, resolved = null, executionMap = new Map()) {
  const basic = basicExecutionBlockForComponent(component) || basicExecutionBlockForComponent(resolved || {});
  if (basic) return basic;
  const directRef = component?.execution_block_ref || component?.executionBlockRef || resolved?.execution_block_ref || resolved?.executionBlockRef;
  const candidates = [directRef, ...(registrySearchKeys(component)), ...(registrySearchKeys(resolved || {}))]
    .map((value) => String(value || "").split("#").pop())
    .map(compositeKey)
    .filter(Boolean);
  for (const key of candidates) {
    if (executionMap.has(key)) return executionMap.get(key);
  }
  return null;
}

function daoLayerSummary(profile = {}) {
  const dao = profile?.dao_layer || profile?.dao || profile?.daoLayer || {};
  if (!dao || typeof dao !== "object") return "";
  return [
    dao.dao_name ? `Dao: ${dao.dao_name}` : "",
    dao.dao_thesis ? `Thesis: ${dao.dao_thesis}` : "",
    dao.preferred_victory ? `Preferred victory: ${dao.preferred_victory}` : "",
    dao.resource_temperament ? `Resource: ${dao.resource_temperament}` : "",
    dao.risk_temperament ? `Risk: ${dao.risk_temperament}` : ""
  ].filter(Boolean).join("\n");
}

function iChingLayerSummary(profile = {}) {
  const layer = profile?.i_ching_combat_layer || profile?.i_ching_layer || profile?.yijing_layer || profile?.iChingCombatLayer || {};
  if (!layer || typeof layer !== "object") return "";
  const lines = [];
  if (layer.default_change_strategy) lines.push(`Default change: ${asDisplayText(layer.default_change_strategy)}`);
  if (layer.trigram_biases) lines.push(`Trigram biases: ${asDisplayText(layer.trigram_biases)}`);
  if (layer.shift_triggers) lines.push(`Shift triggers: ${asDisplayText(layer.shift_triggers)}`);
  if (layer.low_resource_shift) lines.push(`Low-resource shift: ${asDisplayText(layer.low_resource_shift)}`);
  if (layer.combat_state_interpretation) lines.push(`State interpretation: ${asDisplayText(layer.combat_state_interpretation)}`);
  return lines.join("\n");
}

function temporalPanelHtml(composite = {}) {
  const temporal = temporalForComposite(composite);
  if (!temporal) {
    return `<section class="composite-panel-block temporal-panel"><h5>Temporal Feasibility</h5><p class="sheet-description">No HF05B3H temporal-feasibility row found for this composite.</p></section>`;
  }
  const windows = temporalWindowRows(temporal);
  const steps = temporalSteps(temporal);
  return `<section class="composite-panel-block temporal-panel">
    <h5>Temporal Feasibility</h5>
    <div class="temporal-summary-row">${temporalStatusBadge(temporal.temporal_status)} ${temporal.selection_allowed === false ? `<span class="temporal-status-badge blocked">Selection Blocked</span>` : `<span class="temporal-status-badge legal">Selection Allowed</span>`}</div>
    ${compositeDetailField("Timing Class", temporal.timing_class, 180)}
    ${compositeDetailField("Follow-Up Window", temporal.primary_followup_window || temporal.followup_window, 220)}
    ${compositeDetailField("Selection Condition", temporal.selection_condition, 520)}
    ${compositeDetailField("Blocked Reason", temporal.blocked_reason, 620)}
    ${windows.length ? `<div class="section-divider">Required State Windows</div><div class="temporal-window-list">${windows.map((win) => `<article class="temporal-window-card">
      <strong>${escapeHtml(asDisplayText(win.state_name || win.state_id || "Required State"))}</strong>
      <p>${escapeHtml([win.created_on_window ? `Created: ${asDisplayText(win.created_on_window)}` : "", win.expires_at ? `Expires: ${asDisplayText(win.expires_at)}` : "", win.earliest_consuming_window ? `Consumes: ${asDisplayText(win.earliest_consuming_window)}` : "", win.survives_to_consuming_window === false ? "Survives: no" : win.survives_to_consuming_window === true ? "Survives: yes" : ""].filter(Boolean).join(" | "))}</p>
      ${win.bridge_required ? `<p><strong>Bridge required:</strong> ${escapeHtml(asDisplayText([...(win.bridge_actions || []), ...(win.bridge_state_ids || [])].join(", ") || "yes"))}</p>` : ""}
      ${win.if_missing ? `<p><strong>If missing:</strong> ${escapeHtml(asDisplayText(win.if_missing))}</p>` : ""}
    </article>`).join("")}</div>` : ""}
    ${steps.length ? `<details class="composite-rules-drawer"><summary>Step Window Sequence (${escapeHtml(String(steps.length))})</summary><ol>${steps.map((step) => `<li>${escapeHtml([step.step ? `Step ${step.step}` : "", asDisplayText(step.component_id || step.component || step.name), step.actor_window ? `window: ${asDisplayText(step.actor_window)}` : "", step.cleanup_after_step ? "cleanup after step" : ""].filter(Boolean).join(" — "))}</li>`).join("")}</ol></details>` : ""}
  </section>`;
}

function executionBlockPanelHtml(components = [], registries = {}) {
  const executionMap = registries.executionMap || new Map();
  const found = [];
  const unresolved = [];
  compactImportList(components).forEach((component) => {
    const resolved = resolveComponentEntry(component, registries);
    const block = executionBlockForComponent(component, resolved, executionMap);
    if (block && !found.some((item) => item.id === block.id)) found.push(block);
    if (!block) unresolved.push(componentDisplayName(component));
  });
  if (!found.length) {
    return `<section class="composite-panel-block execution-block-panel"><h5>Execution Blocks</h5><p class="sheet-description">No component execution blocks resolved for this composite.</p>${unresolved.length ? `<p class="warning-text"><strong>Unresolved components:</strong> ${escapeHtml(unresolved.join(", "))}</p>` : ""}</section>`;
  }
  return `<section class="composite-panel-block execution-block-panel">
    <h5>Execution Blocks</h5>
    ${found.slice(0, 8).map((block) => `<details class="composite-rules-drawer">
      <summary>${escapeHtml(asDisplayText(block.action_name || block.name || block.id || "Execution Block"))}${block.execution_archetype ? ` — ${escapeHtml(asDisplayText(block.execution_archetype))}` : ""}</summary>
      ${compositeDetailField("Activation", block.activation, 420)}
      ${compositeDetailField("Trigger", block.trigger, 420)}
      ${compositeDetailField("Cost", block.cost || block.resource_ledger, 260)}
      ${compositeDetailField("Attack/Save", block.attack_or_save, 420)}
      ${compositeDetailField("Effect", block.effect_text || block.primary_effect, 1000)}
      ${compositeDetailField("Duration", block.duration, 300)}
      ${compositeDetailField("End Conditions", block.end_conditions, 420)}
      ${compositeDetailField("Counterplay", block.counterplay, 520)}
    </details>`).join("")}
    ${found.length > 8 ? `<p class="muted">${escapeHtml(String(found.length - 8))} additional execution block(s) not shown in this compact view.</p>` : ""}
    ${unresolved.length ? `<p class="warning-text"><strong>Unresolved execution component(s):</strong> ${escapeHtml(unresolved.join(", "))}</p>` : ""}
  </section>`;
}

function daoIChingPanelHtml(playbook = {}) {
  const profile = playbook.daoProfile || null;
  if (!profile) return `<section class="composite-panel-block dao-iching-panel"><h5>Dao / I Ching Behavior</h5><p class="sheet-description">No Dao_Combat_Behavior_Profile.json found.</p></section>`;
  return `<section class="composite-panel-block dao-iching-panel">
    <h5>Dao / I Ching Behavior</h5>
    ${daoLayerSummary(profile) ? `<div class="composite-detail-field"><strong>Dao Layer:</strong><pre class="mini-pre">${escapeHtml(daoLayerSummary(profile))}</pre></div>` : ""}
    ${iChingLayerSummary(profile) ? `<div class="composite-detail-field"><strong>I Ching Combat Layer:</strong><pre class="mini-pre">${escapeHtml(iChingLayerSummary(profile))}</pre></div>` : ""}
  </section>`;
}

function liveStatePanelHtml(playbook = {}) {
  const fields = playbook.fieldObjects || [];
  const anchors = playbook.anchorObjects || [];
  const ledger = playbook.combatStateLedger || null;
  return `<section class="composite-panel-block live-state-panel">
    <h5>Field / Live State Contract</h5>
    <p>${escapeHtml(`Fields: ${fields.length} | Anchors: ${anchors.length} | Ledger template: ${ledger ? "present" : "missing"}`)}</p>
    ${fields.length ? `<div class="manual-badge-list">${fields.slice(0, 8).map((field) => `<span>${escapeHtml(asDisplayText(field.name || field.id || "Field"))}</span>`).join("")}</div>` : `<p class="sheet-description">No Field_Object_Registry entries found.</p>`}
  </section>`;
}

function compositeRegistryDataFromPackage(pkg, sheet = {}) {
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const sv05Projection = sv05ProjectionDataFromParsed(parsed);
  const sv05ProjectionComposites = sv05ProjectionCompositeRows(sv05Projection);
  const byName = (pattern) => findJsonBlock(parsed, [pattern])?.data || null;
  const combatPlaybook = byName(/(?:^|[\/])Combat_Playbook\.json$/i) || byName(/Combat_Playbook/i);
  const compositeRegistry = byName(/(?:^|[\/])Composite_Action_Registry\.json$/i) || byName(/Composite_Action_Registry/i);
  const talentAugmentationRegistry = byName(/(?:^|[\/])Talent_Augmentation_Registry\.json$/i) || byName(/Talent_Augmentation_Registry/i);
  const forgedTechniqueRegistry = byName(/(?:^|[\/])Forged_Technique_Registry\.json$/i) || byName(/Forged_Technique_Registry/i);
  const characterActionRegistry = byName(/(?:^|[\/])Character_Action_Registry\.json$/i) || byName(/Character_Action_Registry/i);
  const completeActionSurface = byName(/(?:^|[\/])Complete_Action_Surface\.json$/i) || byName(/Complete_Action_Surface/i);
  const temporalRegistry = byName(/(?:^|[\/])Temporal_Feasibility_Registry\.json$/i) || byName(/Temporal_Feasibility_Registry/i);
  const stateWindowAudit = byName(/(?:^|[\/])State_Window_Lock_Audit\.json$/i) || byName(/State_Window_Lock_Audit/i);
  const executionBlockRegistry = byName(/(?:^|[\/])Execution_Block_Registry\.json$/i) || byName(/Execution_Block_Registry/i);
  const fieldObjectRegistry = byName(/(?:^|[\/])Field_Object_Registry\.json$/i) || byName(/Field_Object_Registry/i);
  const combatStateLedger = byName(/(?:^|[\/])Combat_State_Ledger_Template\.json$/i) || byName(/Combat_State_Ledger_Template/i);
  const daoProfile = byName(/(?:^|[\/])Dao_Combat_Behavior_Profile\.json$/i) || byName(/Dao_Combat_Behavior_Profile/i);
  const compositeRegistryList = compositeDeclaredListFromRegistry(compositeRegistry);
  const registryMap = makeCompositeMap(compositeRegistryList);
  const temporalEntries = temporalEntriesFromRegistry(temporalRegistry);
  const temporalMap = makeTemporalMap(temporalEntries);
  const executionBlocks = executionBlocksFromRegistry(executionBlockRegistry);
  const executionMap = makeExecutionBlockMap(executionBlocks);
  const fieldObjects = fieldObjectsFromRegistry(fieldObjectRegistry);
  const anchorObjects = anchorObjectsFromRegistry(fieldObjectRegistry);
  const declared = [];
  sv05ProjectionComposites.forEach((entry) => declared.push(entry));
  if (!sv05ProjectionComposites.length) compositePriorityRailEntries(combatPlaybook).forEach(({ entry, priorityHint, priorityMeta }) => {
    const normalized = normalizeCompositeEntry(entry, priorityHint, "Combat_Playbook.priority_table", registryMap, priorityMeta);
    if (normalized) declared.push(normalized);
  });
  if (!sv05ProjectionComposites.length) compositeRegistryList.forEach((entry) => {
    const normalized = normalizeCompositeEntry(entry, entry?.priority || entry?.role || "", "Composite_Action_Registry.json", registryMap);
    if (normalized) declared.push(normalized);
  });
  if (!sv05ProjectionComposites.length) compositeDeclaredListFromRegistry(combatPlaybook).forEach((entry) => {
    const normalized = normalizeCompositeEntry(entry, entry?.priority || entry?.role || "", "Combat_Playbook.json", registryMap);
    if (normalized) declared.push(normalized);
  });
  const seen = new Set();
  const composites = declared.filter((entry) => {
    const key = compositeIdentityKeys(entry)[0] || `${entry.priority}:${compositeDisplayName(entry)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).map((entry) => ({
    ...entry,
    hf05b3h_temporal: temporalForComposite(entry, temporalMap)
  })).sort((a, b) => {
    const ar = compositeSortRank(a);
    const br = compositeSortRank(b);
    if (Number.isFinite(ar.numeric) || Number.isFinite(br.numeric)) return br.numeric - ar.numeric;
    return ar.role - br.role;
  });
  const actions = [
    ...listFromJsonData(characterActionRegistry, ["actions", "registry", "entries", "items"]),
    ...listFromJsonData(completeActionSurface, ["actions", "complete_action_surface", "entries", "items", "registry"]),
    ...(sheet.actions || [])
  ];
  const augmentations = listFromJsonData(talentAugmentationRegistry, ["augmentations", "talent_augmentations", "entries", "items", "registry", "talents"]);
  const forged = [
    ...listFromJsonData(forgedTechniqueRegistry, ["forged_techniques", "learned_forged_techniques", "forgedTechniques", "techniques", "entries", "items", "registry"]),
    ...(sheet.forgedTechniques || [])
  ];
  const sourceFiles = {
    sv05ProjectionRows: Boolean(sv05ProjectionComposites.length),
    combatPlaybook: Boolean(combatPlaybook),
    compositeRegistry: Boolean(compositeRegistry),
    talentAugmentationRegistry: Boolean(talentAugmentationRegistry),
    forgedTechniqueRegistry: Boolean(forgedTechniqueRegistry),
    characterActionRegistry: Boolean(characterActionRegistry),
    completeActionSurface: Boolean(completeActionSurface),
    temporalRegistry: Boolean(temporalRegistry),
    stateWindowAudit: Boolean(stateWindowAudit),
    executionBlockRegistry: Boolean(executionBlockRegistry),
    fieldObjectRegistry: Boolean(fieldObjectRegistry),
    combatStateLedger: Boolean(combatStateLedger),
    daoProfile: Boolean(daoProfile)
  };
  return {
    hasDeclaredComposites: Boolean(sv05ProjectionComposites.length || combatPlaybook || compositeRegistry) && composites.length > 0,
    sourceFiles,
    composites,
    temporalEntries,
    executionBlocks,
    fieldObjects,
    anchorObjects,
    combatStateLedger,
    daoProfile,
    stateWindowAudit,
    registries: {
      actionMap: makeAnyRegistryMap(actions),
      augmentMap: makeAnyRegistryMap(augmentations),
      forgedMap: makeAnyRegistryMap(forged),
      executionMap
    }
  };
}


function importIntegrityBlockList(pkg = {}) {
  return Array.isArray(pkg?.blocks) ? pkg.blocks : [];
}

function importIntegrityParsedBlocks(pkg = {}) {
  try { return parseJsonPackageBlocks(importIntegrityBlockList(pkg)); }
  catch { return []; }
}

function importIntegrityBlockMatch(pkg = {}, pattern) {
  const blocks = importIntegrityBlockList(pkg);
  return blocks.filter((block) => pattern.test(String(block?.name || "")));
}

function importIntegrityFindJson(parsed = [], patterns = []) {
  try { return findJsonBlock(parsed, patterns)?.data || null; }
  catch { return null; }
}

function importIntegrityListCount(data, keys = []) {
  try { return compactImportList(listFromJsonData(data || {}, keys)).length; }
  catch { return 0; }
}


function importIntegrityHasExplicitEmptyList(data = {}, keys = []) {
  if (!data || typeof data !== "object") return false;
  for (const key of keys) {
    if (!Object.prototype.hasOwnProperty.call(data, key)) continue;
    const value = data[key];
    if (Array.isArray(value)) return compactImportList(value).length === 0;
    if (value && typeof value === "object") {
      const nestedKeys = ["items", "entries", "registry", "techniques", "forged_techniques", "installed_forged_techniques", "manuals", "composites", "talents", "foundations", "actions"];
      for (const nestedKey of nestedKeys) {
        if (Array.isArray(value[nestedKey])) return compactImportList(value[nestedKey]).length === 0;
      }
    }
  }
  return false;
}

function importIntegrityListFromSurface(surface = {}, keys = []) {
  for (const key of keys) {
    const value = surface?.[key];
    if (Array.isArray(value)) return compactImportList(value).length;
    if (value && typeof value === "object") {
      const nested = importIntegrityListCount(value, ["items", "entries", "registry", "actions", "techniques", "manuals", "composites", "talents", "foundations"]);
      if (nested) return nested;
    }
  }
  return 0;
}

function importIntegrityNumberFromSurface(surface = {}, keys = []) {
  for (const key of keys) {
    const value = surface?.[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value === "string" && /^\d+$/.test(value.trim())) return Number(value.trim());
  }
  return null;
}

function importIntegrityBooleanFromSurface(surface = {}, keys = []) {
  for (const key of keys) {
    const value = surface?.[key];
    if (value === true) return true;
    if (typeof value === "string" && /^(?:true|yes|declared|present)$/i.test(value.trim())) return true;
  }
  return false;
}

function importIntegrityPathReferenced(surface = {}, keys = [], pattern = null) {
  for (const key of keys) {
    const value = surface?.[key];
    if (!value) continue;
    const text = asDisplayText(value);
    if (text && (!pattern || pattern.test(text))) return true;
  }
  return false;
}

function importIntegrityFacet({ key, label, loaded = 0, registryCount = 0, fileCount = 0, surfaceCount = 0, declaredCount = null, declared = false, pathReferenced = false, explicitAbsent = false, files = [], notes = [] } = {}) {
  const expected = Number.isFinite(Number(declaredCount)) ? Number(declaredCount) : Math.max(registryCount || 0, surfaceCount || 0);
  const positiveExpected = Boolean(declared || pathReferenced || registryCount || surfaceCount || (Number.isFinite(Number(declaredCount)) && Number(declaredCount) > 0));
  const cleanExplicitAbsence = Boolean(explicitAbsent && loaded === 0 && !positiveExpected);
  const hasExplicitReference = !cleanExplicitAbsence && Boolean(declared || pathReferenced || fileCount || registryCount || surfaceCount || (Number.isFinite(Number(declaredCount)) && Number(declaredCount) > 0));
  const status = (() => {
    if (loaded > 0 && expected > 0 && loaded < expected) return "warning";
    if (loaded > 0) return "ok";
    if (hasExplicitReference) return "error";
    return "absent";
  })();
  const message = (() => {
    if (status === "ok") return expected > loaded ? `${label}: loaded ${loaded}; declared at least ${expected}.` : `${label}: loaded ${loaded}.`;
    if (status === "warning") return `${label}: declared/referenced ${expected}, loaded ${loaded}; inspect registry completeness.`;
    if (status === "error") {
      if (fileCount && !registryCount) return `${label}: registry file present but no readable entries loaded.`;
      if (pathReferenced && !fileCount) return `${label}: registry path/reference declared but matching file was not found.`;
      return `${label}: declared or referenced, but no entries loaded.`;
    }
    if (cleanExplicitAbsence) return `${label}: registry explicitly declares no installed entries.`;
    return `${label}: no declared data found in this package.`;
  })();
  return { key, label, loaded, declared_count: expected || 0, registry_count: registryCount || 0, file_count: fileCount || 0, surface_count: surfaceCount || 0, declared: hasExplicitReference, explicit_absent: cleanExplicitAbsence, status, message, files, notes };
}

function importIntegrityForPackage(pkg = {}, sheet = {}, playbook = null) {
  const parsed = importIntegrityParsedBlocks(pkg);
  const surface = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Character_Import_Surface\.json$/i, /Character_Import_Surface/i]) || {};
  const exactBlocks = {
    actions: importIntegrityBlockMatch(pkg, /(?:^|[\\/])(?:Character_)?Action_Registry\.json$/i),
    composites: importIntegrityBlockMatch(pkg, /(?:^|[\\/])(?:Composite_Action_Registry|Composite_Playbook_Registry|Combat_Playbook)\.json$/i),
    forged: importIntegrityBlockMatch(pkg, /(?:^|[\\/])Forged_Technique_Registry\.(?:json|md)$/i),
    manuals: importIntegrityBlockMatch(pkg, /(?:^|[\\/])(?:Martial_Arts_and_Manuals|Martial_Manual_Registry)\.(?:json|md)$/i),
    foundations: importIntegrityBlockMatch(pkg, /(?:^|[\\/])Foundation_Registry\.json$/i),
    talents: importIntegrityBlockMatch(pkg, /(?:^|[\\/])Legal_Talent_Inventory\.json$/i)
  };
  const actionRegistry = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?(?:Character_)?Action_Registry\.json$/i, /Character_Action_Registry/i]);
  const completeActionSurface = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Complete_Action_Surface\.json$/i, /Complete_Action_Surface/i]);
  const compositeRegistry = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Composite_Action_Registry\.json$/i, /Composite_Action_Registry/i]);
  const combatPlaybook = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Combat_Playbook\.json$/i, /Combat_Playbook/i]);
  const forgedRegistry = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Forged_Technique_Registry\.json$/i, /Forged_Technique_Registry/i]);
  const manualRegistry = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Martial_Manual_Registry\.json$/i, /Martial_Manual_Registry/i]) || importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Martial_Arts_and_Manuals\.json$/i, /Martial_Arts_and_Manuals/i]);
  const foundationRegistry = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Foundation_Registry\.json$/i, /Foundation_Registry/i]);
  const talentInventory = importIntegrityFindJson(parsed, [/^(?:.*[\\/])?Legal_Talent_Inventory\.json$/i, /Legal_Talent_Inventory/i]);
  const compositeLoaded = Array.isArray(playbook?.composites) ? playbook.composites.length : 0;
  const facets = [
    importIntegrityFacet({
      key: "actions", label: "Actions", loaded: compactImportList(sheet.actions).length,
      registryCount: importIntegrityListCount(actionRegistry, ["actions", "registry", "entries", "items"]) + importIntegrityListCount(completeActionSurface, ["actions", "complete_action_surface", "entries", "items", "registry"]),
      fileCount: exactBlocks.actions.length, surfaceCount: importIntegrityListFromSurface(surface, ["actions"]), declaredCount: importIntegrityNumberFromSurface(surface, ["action_count", "actions_count"]), files: exactBlocks.actions.map((b) => b.name)
    }),
    importIntegrityFacet({
      key: "composites", label: "Composite Playbook", loaded: compositeLoaded,
      registryCount: importIntegrityListCount(compositeRegistry, ["composite_actions", "composites", "compositeActionRegistry", "composite_registry"]) + importIntegrityListCount(combatPlaybook, ["priority_table", "composite_actions", "composites", "sequences", "entries", "items"]),
      fileCount: exactBlocks.composites.length, surfaceCount: importIntegrityListFromSurface(surface, ["composites", "composite_actions", "composite_playbook"]), declaredCount: importIntegrityNumberFromSurface(surface, ["composite_count", "composites_count", "composite_playbook_count"]),
      declared: importIntegrityBooleanFromSurface(surface, ["composites_declared", "composite_playbook_declared"]), pathReferenced: importIntegrityPathReferenced(surface, ["composite_registry_path", "composite_playbook_registry_path"], /Composite|Combat_Playbook/i), files: exactBlocks.composites.map((b) => b.name)
    }),
    importIntegrityFacet({
      key: "forged", label: "Forged Techniques", loaded: compactImportList(sheet.forgedTechniques).length,
      registryCount: importIntegrityListCount(forgedRegistry, ["installed_forged_techniques", "forged_techniques", "learned_forged_techniques", "forgedTechniques", "techniques", "entries", "items", "registry"]),
      fileCount: exactBlocks.forged.length, surfaceCount: importIntegrityListFromSurface(surface, ["forged_techniques", "forgedTechniques"]), declaredCount: importIntegrityNumberFromSurface(surface, ["forged_technique_count", "forged_techniques_count"]),
      declared: importIntegrityBooleanFromSurface(surface, ["forged_techniques_declared", "forged_declared"]), pathReferenced: importIntegrityPathReferenced(surface, ["forged_technique_registry_path", "forged_registry_path"], /Forged_Technique/i),
      explicitAbsent: importIntegrityHasExplicitEmptyList(forgedRegistry, ["installed_forged_techniques", "forged_techniques", "learned_forged_techniques", "forgedTechniques", "techniques", "entries", "items", "registry"]), files: exactBlocks.forged.map((b) => b.name)
    }),
    importIntegrityFacet({
      key: "manuals", label: "Martial Manuals", loaded: compactImportList(sheet.martialArtsLearned).length,
      registryCount: importIntegrityListCount(manualRegistry, ["martial_manuals", "manuals", "martialArtsLearned", "learned_manuals", "entries", "items", "registry"]),
      fileCount: exactBlocks.manuals.length, surfaceCount: importIntegrityListFromSurface(surface, ["martial_manuals", "martialArtsLearned", "manuals"]), declaredCount: importIntegrityNumberFromSurface(surface, ["martial_manual_count", "manual_count", "manuals_count"]),
      declared: importIntegrityBooleanFromSurface(surface, ["martial_manuals_declared", "manuals_declared"]), pathReferenced: importIntegrityPathReferenced(surface, ["martial_manual_registry_path", "manual_registry_path"], /Martial/i), files: exactBlocks.manuals.map((b) => b.name)
    }),
    importIntegrityFacet({
      key: "foundations", label: "Foundation", loaded: compactImportList(sheet.foundations).length,
      registryCount: importIntegrityListCount(foundationRegistry, ["foundations", "foundation", "entries", "items", "registry"]), fileCount: exactBlocks.foundations.length, surfaceCount: importIntegrityListFromSurface(surface, ["foundations", "foundation"]), declaredCount: importIntegrityNumberFromSurface(surface, ["foundation_count", "foundations_count"]), files: exactBlocks.foundations.map((b) => b.name)
    }),
    importIntegrityFacet({
      key: "talents", label: "Talents", loaded: compactImportList(sheet.talents).length,
      registryCount: importIntegrityListCount(talentInventory, ["talents", "legal_talents", "entries", "items", "inventory", "registry"]), fileCount: exactBlocks.talents.length, surfaceCount: importIntegrityListFromSurface(surface, ["talents", "legal_talents"]), declaredCount: importIntegrityNumberFromSurface(surface?.legal_talents || surface, ["talent_count", "talents_count", "slots_spent"]), pathReferenced: importIntegrityPathReferenced(surface?.legal_talents || surface, ["inventory_file", "talent_inventory_path"], /Legal_Talent_Inventory/i), files: exactBlocks.talents.map((b) => b.name)
    })
  ];
  const problems = facets.filter((facet) => facet.status === "error" || facet.status === "warning");
  return { facets, problems, pass: problems.length === 0 };
}

function importIntegrityStatusBadge(status = "absent") {
  const labels = { ok: "OK", warning: "WARN", error: "ERROR", absent: "ABSENT" };
  return `<span class="import-integrity-badge ${escapeHtml(status)}">${escapeHtml(labels[status] || status)}</span>`;
}

function importIntegrityPanelHtml(integrity = {}) {
  const facets = Array.isArray(integrity.facets) ? integrity.facets : [];
  if (!facets.length) return "";
  const problemCount = facets.filter((facet) => facet.status === "error" || facet.status === "warning").length;
  return `<section class="sheet-section import-integrity-section">
    <h4>Import Integrity</h4>
    <div class="sheet-section-body">
      <p class="sheet-description">Checks declared/referenced package surfaces against loaded GM Screen data. Absence is only clean when no registry, count, path, or import-surface reference exists.</p>
      <div class="import-integrity-grid">
        ${facets.map((facet) => `<article class="import-integrity-card ${escapeHtml(facet.status)}">
          <header><strong>${escapeHtml(facet.label)}</strong>${importIntegrityStatusBadge(facet.status)}</header>
          <p>${escapeHtml(facet.message)}</p>
          <small>${escapeHtml(`Loaded ${facet.loaded}; declared/ref ${facet.declared_count}; files ${facet.file_count}`)}</small>
        </article>`).join("")}
      </div>
      ${problemCount ? `<p class="warning-text"><strong>${escapeHtml(String(problemCount))} import warning${problemCount === 1 ? "" : "s"}:</strong> declared or referenced data did not fully load. Treat this as an importer/package contract issue, not a clean absence.</p>` : `<p class="sheet-description">All declared/referenced import surfaces loaded or were cleanly absent.</p>`}
    </div>
  </section>`;
}

function importIntegrityFacetByKey(integrity = {}, key = "") {
  return (integrity.facets || []).find((facet) => facet.key === key) || null;
}

function importIntegrityEmptyMessage(facet = null, cleanAbsent = "No data declared in this package.") {
  if (!facet) return cleanAbsent;
  if (facet.status === "error") return `${facet.label} were declared or referenced, but the importer loaded none. Check the named registry/path in Import Integrity.`;
  if (facet.status === "warning") return `${facet.label} loaded partially; check Import Integrity for declared versus loaded counts.`;
  return cleanAbsent;
}

function compositeSourceStatusHtml(sourceFiles = {}) {
  const rows = [
    ["Combat_Playbook.json", sourceFiles.combatPlaybook],
    ["Composite_Action_Registry.json", sourceFiles.compositeRegistry],
    ["Talent_Augmentation_Registry.json", sourceFiles.talentAugmentationRegistry],
    ["Forged_Technique_Registry.json", sourceFiles.forgedTechniqueRegistry],
    ["Character_Action_Registry.json", sourceFiles.characterActionRegistry],
    ["Complete_Action_Surface.json", sourceFiles.completeActionSurface],
    ["Temporal_Feasibility_Registry.json", sourceFiles.temporalRegistry],
    ["State_Window_Lock_Audit.json", sourceFiles.stateWindowAudit],
    ["Execution_Block_Registry.json", sourceFiles.executionBlockRegistry],
    ["Field_Object_Registry.json", sourceFiles.fieldObjectRegistry],
    ["Combat_State_Ledger_Template.json", sourceFiles.combatStateLedger],
    ["Dao_Combat_Behavior_Profile.json", sourceFiles.daoProfile]
  ];
  return `<div class="composite-source-grid">${rows.map(([name, present]) => `<span class="${present ? "present" : "missing"}">${escapeHtml(name)}: ${present ? "read" : "missing"}</span>`).join("")}</div>`;
}

function compositeComponentsHtml(components = [], registries = {}) {
  const list = compactImportList(components);
  if (!list.length) return `<p class="sheet-description">No component stack declared for this composite.</p>`;
  return `<ol class="composite-component-stack">${list.map((component, index) => {
    const resolved = resolveComponentEntry(component, registries);
    const type = componentType(component);
    const name = componentDisplayName(component);
    const resolvedName = resolved ? (actionDisplayName(resolved) || forgedTechniqueDisplayName(resolved) || entryDisplayName(resolved)) : "";
    const body = truncateValue(asDisplayText(component.effect || component.summary || component.notes || component.reason || resolved?.damage_or_effect || resolved?.effect || resolved?.summary || resolved?.description || resolved?.mechanics || ""), 360);
    const cost = forgedTechniqueCostDisplay(component.cost || component.resource_cost || resolved?.cost || resolved?.resource_spent || "");
    return `<li>
      <div class="composite-component-head"><strong>${index + 1}. ${escapeHtml(name)}</strong><span>${escapeHtml(titleCase(type))}</span></div>
      ${resolvedName && resolvedName !== name ? `<div class="manual-technique-meta"><strong>Resolved:</strong> ${escapeHtml(resolvedName)}</div>` : ""}
      ${cost ? `<div class="manual-technique-meta"><strong>Cost:</strong> ${escapeHtml(cost)}</div>` : ""}
      ${body ? `<p>${escapeHtml(body)}</p>` : ""}
    </li>`;
  }).join("")}</ol>`;
}

function compositeDetailField(label, value, max = 520) {
  const text = asDisplayText(value).trim();
  return text ? `<div class="composite-detail-field"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(truncateValue(text, max))}</div>` : "";
}

function compositeForgedRulesHtml(composite = {}, components = [], registries = {}) {
  const names = [];
  const add = (entry) => {
    if (!entry) return;
    if (typeof entry === "string") names.push(entry);
    else if (typeof entry === "object") names.push(entry.forged_technique_id || entry.technique_id || entry.name || entry.display_name || entry.ref || "");
  };
  components.forEach((component) => {
    if (/forged/.test(componentType(component))) add(component);
  });
  compactImportList(firstAvailableList(composite.forged_techniques, composite.forgedTechniques, composite.forged_rules, composite.forgedTechniqueRules)).forEach(add);
  const unique = [...new Set(names.map((name) => String(name || "").trim()).filter(Boolean))];
  const resolved = unique.map((name) => registries.forgedMap?.get(compositeKey(name)) || { name });
  if (!resolved.length) return `<p class="sheet-description">No forged-technique dependency declared for this composite.</p>`;
  return `<div class="composite-forged-rules">${resolved.map((item) => {
    const name = forgedTechniqueDisplayName(item) || entryDisplayName(item);
    const rules = compositeFullRuleText(item);
    const cost = forgedTechniqueCostDisplay(item.cost || item.resource_cost || "");
    return `<details class="composite-rules-drawer">
      <summary>${escapeHtml(name)}${cost ? ` — Cost ${escapeHtml(cost)}` : ""}</summary>
      <p>${escapeHtml(truncateValue(rules || "No full rules text found in the imported forged-technique registry.", 1400))}</p>
    </details>`;
  }).join("")}</div>`;
}

function compositeDetailPanelHtml(composite = {}, index = 0, playbook = {}) {
  const registries = playbook.registries || {};
  const components = compositeComponentList(composite);
  const augments = compositeAugmentationList(composite);
  const spheres = compositeRequiredSpheres(composite);
  const outputs = compositeOutputs(composite);
  const aiPrompt = compositeAiPrompt(composite, components);
  const sv05CompositeProjectionHtml = composite.projection_contract_active ? `<section class="composite-panel-block sv05-projection-panel">
    <h5>SV05 Projection Contract</h5>
    ${projectionDetailField("GM Screen Category", composite.gm_screen_category, 180)}
    ${projectionDetailField("Execution Role", composite.execution_role, 180)}
    ${projectionDetailField("Tactical Roles", composite.tactical_roles || composite.role_tags, 360)}
    ${projectionDetailField("Temporal Feasibility", composite.temporal_feasibility_summary || composite.temporal_feasibility, 1100)}
    ${projectionDetailField("Object Steps", composite.object_steps, 1400)}
    ${projectionDetailField("Live State Contract", composite.live_state_contract, 900)}
    ${projectionDetailField("Resource Contract", composite.resource_contract, 900)}
    ${projectionDetailField("Opener Lines", composite.opener_lines, 700)}
    ${projectionDetailField("Reaction Lines", composite.reaction_lines, 700)}
    ${projectionDetailField("Anti-Caster Lines", composite.anti_caster_lines, 700)}
    ${projectionDetailField("Finisher Lines", composite.finisher_lines, 700)}
    ${projectionDetailField("Fallback Lines", composite.fallback_lines, 700)}
    ${projectionDetailField("Counterplay", composite.counterplay, 900)}
    ${projectionDetailField("Failure Branches", composite.failure_branches, 900)}
  </section>` : "";
  return `<article class="composite-detail-panel ${index === 0 ? "active" : ""}" data-composite-detail="${escapeHtml(String(index))}">
    <header class="composite-detail-header">
      <div>
        <span class="manual-label">${escapeHtml(titleCase(composite.priority || "Composite"))}</span>
        <h4>${escapeHtml(compositeDisplayName(composite))}</h4>
      </div>
      <span class="manual-count">${escapeHtml(asDisplayText(composite.source_file || "declared"))}</span>
    </header>
    <div class="composite-detail-grid">
      <section class="composite-panel-block selected-composite-detail">
        <h5>Selected Composite Detail</h5>
        ${Number.isFinite(compositeNumericPriority(composite)) ? compositeDetailField("AI Priority", compositeNumericPriority(composite), 80) : ""}
        ${compositeDetailField("Category", composite.gm_screen_category || composite.category || composite.priority, 180)}
        ${compositeDetailField("Execution Role", composite.execution_role || composite.role, 180)}
        ${compositeDetailField("When", compositePriorityWhen(composite), 720)}
        ${compositeDetailField("Logic", compositeLogic(composite), 620)}
        ${compositeDetailField("Build Thesis", compositeThesis(composite), 620)}
        ${spheres.length ? `<div class="manual-badge-list">${spheres.map((sphere) => `<span>${escapeHtml(sphere)}</span>`).join("")}</div>` : ""}
        ${compositeDetailField("Timing", compositeTiming(composite), 900)}
        ${compositeDetailField("Outputs", outputs, 620)}
      </section>
      ${sv05CompositeProjectionHtml}
      ${temporalPanelHtml(composite)}
      ${daoIChingPanelHtml(playbook)}
      ${liveStatePanelHtml(playbook)}
      <section class="composite-panel-block component-stack-panel">
        <h5>Component Stack</h5>
        ${compositeComponentsHtml(components, registries)}
        ${augments.length ? `<div class="section-divider">Augmentation Stack</div>${visualList(augments.map(asDisplayText).filter(Boolean), (item) => String(item), "No augmentation stack.")}` : ""}
      </section>
      ${executionBlockPanelHtml(components, registries)}
      <section class="composite-panel-block economy-ledger-panel">
        <h5>Economy + Resource Ledger</h5>
        <p>${escapeHtml(compositeEconomyLedger(composite) || "No economy/resource ledger declared.")}</p>
      </section>
      <section class="composite-panel-block counterplay-panel">
        <h5>Counterplay Panel</h5>
        <p>${escapeHtml(compositeCounterplay(composite) || "No counterplay panel declared.")}</p>
      </section>
      <section class="composite-panel-block do-not-use-panel">
        <h5>Do-Not-Use Panel</h5>
        <p>${escapeHtml(compositeDoNotUse(composite) || "No do-not-use rule declared.")}</p>
      </section>
      <section class="composite-panel-block forged-rules-panel">
        <h5>Forged Technique Rules Drawer</h5>
        ${compositeForgedRulesHtml(composite, components, registries)}
      </section>
      <section class="composite-panel-block ai-prompt-panel">
        <div class="composite-copy-head"><h5>AI Turn Prompt Export</h5><button type="button" class="secondary-button" data-copy-composite-prompt="${escapeHtml(String(index))}">Copy</button></div>
        <textarea class="output-box composite-ai-prompt" rows="8" readonly>${escapeHtml(aiPrompt || "No AI turn prompt declared or derivable from declared composite fields.")}</textarea>
      </section>
    </div>
  </article>`;
}

function compositePlaybookPanelHtml(playbook = {}, integrity = null) {
  const facet = importIntegrityFacetByKey(integrity, "composites");
  if (!playbook.hasDeclaredComposites) {
    return `<div class="composite-playbook-shell">
      <article class="martial-manual-card composite-playbook-card">
        <header class="martial-manual-header"><div><span class="manual-label">Composite Playbook</span><h4>${escapeHtml(facet?.status === "error" ? "Composite registry referenced but not loaded" : "No declared composite registry found")}</h4></div><span class="manual-count">0 composites</span></header>
        <p class="manual-summary">${escapeHtml(importIntegrityEmptyMessage(facet, "This tab intentionally does not infer combos from loose actions, talents, manuals, or forged techniques. Add Combat_Playbook.json or Composite_Action_Registry.json to the character package to populate declared composites."))}</p>
        ${compositeSourceStatusHtml(playbook.sourceFiles || {})}
      </article>
    </div>`;
  }
  const composites = playbook.composites || [];
  const hasNumericPriority = composites.some((item) => Number.isFinite(compositeNumericPriority(item)));
  const grouped = COMPOSITE_PRIORITY_ORDER.map((entry) => ({ ...entry, composites: composites.map((item, index) => ({ item, index })).filter(({ item }) => normalizeCompositePriority(item.priority) === entry.key) }));
  const railButton = (item, index) => {
    const numeric = compositeNumericPriority(item);
    const when = compositePriorityWhen(item);
    return `<button type="button" class="composite-rail-button ${index === 0 ? "active" : ""}" data-composite-select="${escapeHtml(String(index))}">
      <span>${escapeHtml(compositeDisplayName(item))}</span>
      ${Number.isFinite(numeric) ? `<small>AI ${escapeHtml(String(numeric))}</small>` : ""}
      ${when ? `<em>${escapeHtml(truncateValue(when, 96))}</em>` : ""}
    </button>`;
  };
  const railHtml = hasNumericPriority
    ? `<section><strong>AI Priority Order</strong>${composites.map((item, index) => railButton(item, index)).join("")}</section>`
    : grouped.filter((group) => group.composites.length || group.key !== "uncategorized").map((group) => `<section><strong>${escapeHtml(group.label)}</strong>${group.composites.length ? group.composites.map(({ item, index }) => railButton(item, index)).join("") : `<p class="muted">None declared.</p>`}</section>`).join("");
  return `<div class="composite-playbook-shell">
    <article class="martial-manual-card composite-playbook-card">
      <header class="martial-manual-header"><div><span class="manual-label">Composite Playbook</span><h4>Declared Composite Actions</h4></div><span class="manual-count">${escapeHtml(String(composites.length))} composite${composites.length === 1 ? "" : "s"}</span></header>
      <p class="manual-summary">Declared combo logic only. This panel reads playbook/registry files and does not invent tactical combos when those files are absent.</p>
      ${compositeSourceStatusHtml(playbook.sourceFiles || {})}
      <div class="composite-playbook-layout">
        <aside class="composite-priority-rail">
          <h5>Priority Rail</h5>
          ${railHtml}
        </aside>
        <div class="composite-selected-detail">
          ${composites.map((composite, index) => compositeDetailPanelHtml(composite, index, playbook)).join("")}
        </div>
      </div>
    </article>
  </div>`;
}

function renderVisualCharacterSheet(pkg, notes = {}) {
  if (!pkg) return `<div class="empty-state">No character selected.</div>`;
  const sheet = buildCharacterSheetData(pkg);
  const hpMax = sheet.hp.maximum ?? sheet.hp.max ?? sheet.hp.current ?? "";
  const hpCurrent = sheet.hp.current ?? sheet.hp.current_default ?? hpMax;
  const acValue = sheet.ac.current ?? sheet.ac.base ?? sheet.ac.ac ?? "—";
  const speedText = speedDisplay(sheet.speed) || "—";
  const primaryResource = primaryResourceForDisplay(pkg, sheet);
  const resourceValue = primaryResource ? resourceDisplayText(primaryResource) : "—";
  const abilityCards = hasAbilityScoreData(sheet)
    ? ABILITY_ROWS.map((ability) => {
      const score = abilityScalarValue(abilityField(sheet.abilityScores, ability), ["final", "score", "value", "total", "base"]);
      const mod = abilityScalarValue(abilityField(sheet.abilityModifiers, ability), ["modifier", "mod", "bonus", "value", "total"]);
      const save = abilityScalarValue(abilityField(sheet.saves, ability), ["save", "bonus", "modifier", "mod", "value", "total"]);
      return `
        <article class="ability-card">
          <strong>${escapeHtml(ability.short)}</strong>
          <span class="ability-mod">${escapeHtml(formatSigned(mod))}</span>
          <span class="ability-score">Score ${escapeHtml(score ?? "—")}</span>
          <span class="ability-save">Save ${escapeHtml(formatSigned(save))}</span>
        </article>
      `;
    }).join("")
    : `<p class="sheet-description">Ability scores, ability modifiers, and save bonuses were not included in this package.</p>`;
  const skillItems = Object.entries(skillBonusMap(sheet.skills)).map(([name, value]) => `${name} ${formatSigned(value)}`);
  if (!skillItems.length) skillItems.push("Not recorded in this source package.");
  const defenses = [
    sheet.resistances.length ? `Resistances: ${sheet.resistances.join(", ")}` : "",
    sheet.immunities.length ? `Immunities: ${sheet.immunities.join(", ")}` : "",
    sheet.vulnerabilities.length ? `Vulnerabilities: ${sheet.vulnerabilities.join(", ")}` : ""
  ].filter(Boolean);
  const physical = notes.physicalDescription?.trim() || sheet.physicalDescription || "Not recorded.";
  const backgroundText = sheet.background
    ? [
      sheet.background.name || sheet.background.background_name,
      sheet.background.region_or_origin || sheet.background.region,
      sheet.background.feature,
      Array.isArray(sheet.background.skill_proficiencies) ? `Skills: ${sheet.background.skill_proficiencies.join(", ")}` : "",
      Array.isArray(sheet.background.tools_and_languages) ? `Tools/Languages: ${sheet.background.tools_and_languages.join(", ")}` : ""
    ].filter(Boolean).join(" | ")
    : "Not recorded.";
  const foundationEntries = sheet.foundations || [];
  const equipmentEntries = [...(sheet.equipment || []), ...savedLinkedAsEntries(notes.equipment)];
  const consumableEntries = [...(sheet.consumables || []), ...savedLinkedAsEntries(notes.consumables)];
  const martialArtEntries = [...(sheet.martialArtsLearned || []), ...savedLinkedAsEntries(notes.martialArts)];
  const economyCounts = actionEconomyCounts(sheet.actions, sheet.passives);
  const actionCount = economyCounts.action;
  const bonusCount = economyCounts.bonus_action;
  const reactionCount = economyCounts.reaction;
  const passiveCount = economyCounts.passive;
  const activeTab = "actions";
  const sphereNames = Array.from(new Set((sheet.spheres || []).map(asDisplayText).filter(Boolean)));
  const firstSphere = sphereNames[0] || "";
  const compositePlaybook = compositeRegistryDataFromPackage(pkg, sheet);
  const importIntegrity = importIntegrityForPackage(pkg, sheet, compositePlaybook);

  return `
    <article class="sheet-card">
      <header class="sheet-hero">
        <div class="sheet-portrait">${escapeHtml(characterInitials(sheet.name))}</div>
        <div>
          <h3>${escapeHtml(sheet.name)}</h3>
          <p>${escapeHtml([sheet.path, sheet.realm, sheet.cultivationLevel ? `CL ${sheet.cultivationLevel}` : ""].filter(Boolean).join(" | "))}</p>
          <div class="sheet-tags">
            ${sheet.spheres.slice(0, 6).map((sphere) => `<span>${escapeHtml(sphere)}</span>`).join("")}
          </div>
        </div>
      </header>

      <div class="sheet-stat-strip">
        <div class="sheet-stat"><strong>HP</strong><span>${escapeHtml(`${hpCurrent || "?"}/${hpMax || "?"}`)}</span></div>
        <div class="sheet-stat"><strong>AC</strong><span>${escapeHtml(acValue)}</span></div>
        <div class="sheet-stat"><strong>Speed</strong><span>${escapeHtml(speedText)}</span></div>
        <div class="sheet-stat"><strong>Attack</strong><span>${escapeHtml(formatSigned(sheet.cultivationAttackBonus))}</span></div>
        <div class="sheet-stat"><strong>Save DC</strong><span>${escapeHtml(sheet.cultivationSaveDc ?? "—")}</span></div>
        <div class="sheet-stat"><strong>Resource</strong><span>${escapeHtml(resourceValue)}</span></div>
      </div>

      <div class="sheet-main">
        <aside class="sheet-column">
          <section class="sheet-section">
            <h4>Abilities</h4>
            <div class="sheet-section-body">
              <div class="ability-grid">${abilityCards}</div>
            </div>
          </section>
          <section class="sheet-section">
            <h4>Skills</h4>
            <div class="sheet-section-body">${visualList(skillItems)}</div>
          </section>
          <section class="sheet-section">
            <h4>Senses & Defenses</h4>
            <div class="sheet-section-body">
              ${visualList([...(sheet.senses || []), ...defenses])}
            </div>
          </section>
          <section class="sheet-section">
            <h4>Description</h4>
            <div class="sheet-section-body">
              <p class="sheet-description">${escapeHtml(physical)}</p>
            </div>
          </section>
          <section class="sheet-section">
            <h4>Background</h4>
            <div class="sheet-section-body"><p class="sheet-description">${escapeHtml(backgroundText)}</p></div>
          </section>
          <section class="sheet-section">
            <h4>Foundation</h4>
            <div class="sheet-section-body">${visualList(foundationEntries, (item) => `${item.name || item.foundation_name || item.id || "Foundation"}${item.depth ? ` | ${item.depth}` : ""}${item.stage ? ` | ${item.stage}` : ""}`, importIntegrityEmptyMessage(importIntegrityFacetByKey(importIntegrity, "foundations"), "No Foundation record."))}</div>
          </section>
          ${importIntegrityPanelHtml(importIntegrity)}
        </aside>

        <main class="sheet-column">
          <section class="sheet-section">
            <div class="sheet-section-body">
              <div class="sheet-tabs">
                ${["actions", "spheres", "talents", "insights", "forged techniques", "composite playbook", "resources", "equipment", "consumables", "martial arts", "foundation", "import integrity", "defense"].map((tab) => `
                  <button class="sheet-tab-button ${tab === activeTab ? "active" : ""}" type="button" data-sheet-tab="${tab}">${escapeHtml(titleCase(tab))}</button>
                `).join("")}
              </div>

              <div class="sheet-tab-panel ${activeTab === "actions" ? "active" : ""}" data-sheet-panel="actions">
                <div class="sheet-detail-grid">
                  <article class="sheet-detail-card"><strong>Action Economy</strong><p>${escapeHtml(`${actionCount} actions | ${bonusCount} bonus actions | ${reactionCount} reactions | ${passiveCount} passive entries`)}</p></article>
                  <article class="sheet-detail-card"><strong>Attacks Per Action</strong><p>${escapeHtml(String(sheet.attacksPerAttackAction ?? "Unknown"))}</p></article>
                </div>
                ${visualActionRowsV2(sheet.actions)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="spheres">
                ${visualSphereChips(sphereNames, firstSphere)}
                ${sphereReferenceCard(firstSphere)}
                <div class="section-divider">Dao Expression</div>
                <p class="sheet-description">${escapeHtml(pkg.daoPhrase || "No Dao phrase recorded.")}</p>
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="talents">
                ${visualDetailCards(sheet.talents, talentDetail)}
                <div class="section-divider">Passive Features</div>
                ${visualDetailCards(sheet.passives, passiveLine)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="insights">
                ${visualDetailCards(sheet.insights, talentDetail)}
                <div class="section-divider">Controlled Assets</div>
                ${visualDetailCards(sheet.assets, assetLine)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="forged techniques">
                ${forgedTechniquePanelHtml(sheet.forgedTechniques, sheet.actions, importIntegrity)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="composite playbook">
                ${compositePlaybookPanelHtml(compositePlaybook, importIntegrity)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="resources">
                ${visualDetailCards(sheet.resources, (item) => ({ title: String(item?.display_name || item?.resource_name || item?.resource_id || item?.name || "Resource"), body: resourceLine(item) }))}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="equipment">
                ${visualDetailCards(equipmentEntries, inventoryDetail, "No equipment listed.")}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="consumables">
                ${visualDetailCards(consumableEntries, inventoryDetail, "No consumables listed.")}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="martial arts">
                <p class="sheet-description">Manuals, tablets, inherited forms, and learned martial arts recorded here are tracked outside sphere/talent known limits.</p>
                ${martialArtPanelHtml(martialArtEntries, sheet.actions, importIntegrity)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="foundation">
                ${foundationPanelHtml(foundationEntries, sheet)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="import integrity">
                ${importIntegrityPanelHtml(importIntegrity)}
              </div>
              <div class="sheet-tab-panel" data-sheet-panel="defense">
                <div class="sheet-detail-grid">
                  <article class="sheet-detail-card"><strong>Armor Class</strong><p>${escapeHtml(`${acValue}${sheet.ac.formula ? ` | ${sheet.ac.formula}` : ""}`)}</p></article>
                  <article class="sheet-detail-card"><strong>Hit Points</strong><p>${escapeHtml(`${hpCurrent || "?"}/${hpMax || "?"}`)}</p></article>
                </div>
                <div class="section-divider">Defensive Tags</div>
                ${visualList([...(sheet.senses || []), ...defenses])}
                <div class="section-divider">States</div>
                ${visualDetailCards(sheet.states, (item) => ({
                  title: item?.display_name || item?.state_name || item?.name || item?.state_id || "State",
                  body: [item?.duration, item?.expiry, item?.collapse_rule, item?.summary, item?.effect].map(asDisplayText).filter(Boolean).join(" | ")
                }))}
              </div>
            </div>
          </section>
        </main>
      </div>
    </article>
  `;
}

function attachVisualSheetTabs(rootId = "activeCharacterVisualSheet") {
  const root = $(rootId);
  if (!root) return;
  root.querySelectorAll("[data-sheet-tab]").forEach((button) => {
    button.addEventListener("click", () => {
      const tab = button.dataset.sheetTab;
      root.querySelectorAll("[data-sheet-tab]").forEach((item) => {
        item.classList.toggle("active", item.dataset.sheetTab === tab);
      });
      root.querySelectorAll("[data-sheet-panel]").forEach((panel) => {
        panel.classList.toggle("active", panel.dataset.sheetPanel === tab);
      });
    });
  });
  root.querySelectorAll("[data-sheet-sphere]").forEach((button) => {
    button.addEventListener("click", () => {
      const sphereName = button.dataset.sheetSphere || "";
      root.querySelectorAll("[data-sheet-sphere]").forEach((item) => {
        item.classList.toggle("active", item.dataset.sheetSphere === sphereName);
      });
      const panel = root.querySelector("[data-sheet-sphere-panel]");
      if (panel) panel.innerHTML = sphereReferenceBody(sphereName);
    });
  });
  root.querySelectorAll("[data-composite-select]").forEach((button) => {
    button.addEventListener("click", () => {
      const selected = button.dataset.compositeSelect || "0";
      root.querySelectorAll("[data-composite-select]").forEach((item) => item.classList.toggle("active", item.dataset.compositeSelect === selected));
      root.querySelectorAll("[data-composite-detail]").forEach((panel) => panel.classList.toggle("active", panel.dataset.compositeDetail === selected));
    });
  });
  root.querySelectorAll("[data-copy-composite-prompt]").forEach((button) => {
    button.addEventListener("click", () => {
      const key = button.dataset.copyCompositePrompt || "0";
      const panel = root.querySelector(`[data-composite-detail="${key}"]`);
      const textarea = panel?.querySelector(".composite-ai-prompt");
      if (textarea) copyText(textarea.value || textarea.textContent || "");
    });
  });
  if (!root.dataset.libraryJumpBound) {
    root.dataset.libraryJumpBound = "true";
    root.addEventListener("click", (event) => {
      const button = event.target.closest("[data-open-library-sphere]");
      if (!button || !root.contains(button)) return;
      const sphereName = button.dataset.openLibrarySphere || "";
      const search = $("sphereSearch");
      if (search) search.value = sphereName;
      renderLibrary();
      setActiveTab("library");
    });
  }
}

function gateActivePackage() {
  const gate = gateState();
  return packageById(gate.activeCharacterId) || state.packages[0] || null;
}

function gateSyncFromInputs() {
  const gate = gateState();
  if ($("gateCharacterSelect")) gate.activeCharacterId = $("gateCharacterSelect").value;
  if ($("gateSceneTitle")) gate.sceneTitle = $("gateSceneTitle").value.trim();
  if ($("gateLocation")) gate.location = $("gateLocation").value.trim();
  if ($("gateWorldTime")) gate.worldTime = $("gateWorldTime").value.trim();
  if ($("gateSceneText")) gate.sceneText = $("gateSceneText").value.trim();
  if ($("gateChoicesInput")) {
    gate.choices = $("gateChoicesInput").value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  }
  if ($("gateSectNotes")) gate.sectNotes = $("gateSectNotes").value.trim();
}

function gateEventText(event) {
  return [
    event.action ? `Action: ${event.action}` : "",
    event.result ? `Result: ${event.result}` : "",
    event.source ? `Source: ${event.source}` : ""
  ].filter(Boolean).join(" | ");
}

function renderGateCharacterRail(pkg) {
  if (!pkg) {
    return `<div class="empty-state">Save or build a character package first.</div>`;
  }
  const sheet = buildCharacterSheetData(pkg);
  const hpMax = sheet.hp.maximum ?? sheet.hp.max ?? sheet.hp.current ?? "?";
  const hpCurrent = sheet.hp.current ?? sheet.hp.current_default ?? hpMax;
  const primaryResource = primaryResourceForDisplay(pkg, sheet);
  const resourceText = primaryResource ? resourceDisplayText(primaryResource) : "No resource listed";
  return `
    <div class="gate-avatar">${escapeHtml(characterInitials(sheet.name))}</div>
    <h3>${escapeHtml(sheet.name)}</h3>
    <p>${escapeHtml([sheet.path, sheet.realm, sheet.cultivationLevel ? `CL ${sheet.cultivationLevel}` : ""].filter(Boolean).join(" | ") || "No cultivation data")}</p>
    <div class="gate-vital-list">
      <div><span>HP</span><strong>${escapeHtml(`${hpCurrent}/${hpMax}`)}</strong></div>
      <div><span>AC</span><strong>${escapeHtml(sheet.ac.current ?? sheet.ac.base ?? sheet.ac.ac ?? "?")}</strong></div>
      <div><span>Resource</span><strong>${escapeHtml(resourceText)}</strong></div>
      <div><span>Save DC</span><strong>${escapeHtml(sheet.cultivationSaveDc ?? "?")}</strong></div>
    </div>
    <div class="section-divider">Spheres</div>
    <div class="gate-mini-tags">${(sheet.spheres || []).slice(0, 10).map((sphere) => `<span>${escapeHtml(sphere)}</span>`).join("") || "<span>None listed</span>"}</div>
    <div class="section-divider">Current Description</div>
    <p>${escapeHtml(sheet.physicalDescription || "No description recorded yet.")}</p>
  `;
}

function renderGateCards(items, kind) {
  if (!items.length) return `<div class="empty-state">Nothing pinned yet.</div>`;
  return items.map((item) => `
    <article class="gate-card">
      <button class="gate-card-remove" type="button" data-gate-remove="${escapeHtml(kind)}" data-gate-remove-id="${escapeHtml(item.id)}">x</button>
      <strong>${escapeHtml(item.title || item.name || "Untitled")}</strong>
      <p>${escapeHtml(item.notes || "No notes.")}</p>
    </article>
  `).join("");
}

function renderGateHistory(gate) {
  if (!gate.events.length) {
    return `<div class="empty-state">No committed scene events yet.</div>`;
  }
  return gate.events.slice(0, 8).map((event) => `
    <article class="gate-history-event">
      <strong>${escapeHtml(event.created?.slice(0, 16).replace("T", " ") || "Event")}</strong>
      <p>${escapeHtml(gateEventText(event))}</p>
    </article>
  `).join("");
}

function cleanSuggestedActionLine(line) {
  const cleaned = String(line || "")
    .replace(/^\s*(?:[-*]|\d+[\.)]|[A-Ea-e][\.)])\s*/, "")
    .trim();
  const wrapped = cleaned.match(/^(['"])(.*)\1$/);
  return wrapped ? wrapped[2].trim() : cleaned;
}

function isSuggestedActionHeading(line) {
  const normalized = String(line || "")
    .trim()
    .replace(/^#{1,6}\s*/, "")
    .replace(/^\d+[\.)]\s*/, "")
    .replace(/\s*\(.+\)\s*$/, "")
    .replace(/_/g, " ")
    .toLowerCase();
  return normalized === "suggested actions"
    || normalized === "suggested next actions"
    || normalized === "next actions"
    || normalized === "choices"
    || normalized === "options"
    || normalized === "suggested actions:"
    || /^suggested\s+next\s+actions/.test(normalized)
    || /^suggested\s+actions/.test(normalized);
}

function isNextResponseSectionHeading(line) {
  const normalized = String(line || "")
    .trim()
    .replace(/^#{1,6}\s*/, "")
    .toLowerCase();
  return /^(?:\d+[\.)]\s*)?(?:immediate|required|quest|person|sect|dao|yijing|gm confirmation|rules uncertainty|narrated result|response request|updates?)\b/.test(normalized);
}

function extractSuggestedActions(text) {
  const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  const exactHeadingIndex = lines.map((line) => line.trim()).findLastIndex((line) => /^SUGGESTED_ACTIONS\s*:?\s*$/i.test(line));
  if (exactHeadingIndex >= 0) {
    const exactActions = [];
    for (const rawLine of lines.slice(exactHeadingIndex + 1)) {
      const line = rawLine.trim();
      if (!line) continue;
      if (exactActions.length && isNextResponseSectionHeading(line)) break;
      const cleaned = cleanSuggestedActionLine(line);
      if (cleaned && cleaned.length > 4) exactActions.push(cleaned);
      if (exactActions.length >= 6) break;
    }
    if (exactActions.length) return exactActions;
  }
  const actions = [];
  let capture = false;
  let capturedAny = false;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) {
      continue;
    }
    if (/^SUGGESTED_ACTIONS\s*:?\s*$/i.test(line) || isSuggestedActionHeading(line)) {
      capture = true;
      capturedAny = false;
      continue;
    }
    if (!capture) continue;
    if (capturedAny && isNextResponseSectionHeading(line)) break;
    const cleaned = cleanSuggestedActionLine(line);
    if (cleaned && cleaned.length > 4) {
      actions.push(cleaned);
      capturedAny = true;
    }
    if (actions.length >= 6) break;
  }
  return actions;
}

function stripSuggestedActionsBlock(text) {
  const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  const output = [];
  let skipping = false;
  let skippedAny = false;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (/^SUGGESTED_ACTIONS\s*:?\s*$/i.test(line)) {
      skipping = true;
      skippedAny = false;
      continue;
    }
    if (skipping) {
      if (!line) {
        continue;
      }
      if (skippedAny && isNextResponseSectionHeading(line)) {
        skipping = false;
      } else {
        skippedAny = true;
        continue;
      }
    }
    if (!skipping) output.push(rawLine);
  }
  return output.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

function gateStatePacket(action = "") {
  gateSyncFromInputs();
  const gate = gateState();
  const pkg = gateActivePackage();
  const sheet = pkg ? buildCharacterSheetData(pkg) : null;
  return [
    `# Tianxia Gate Scene Packet`,
    ``,
    `## Operating Rule`,
    `AI proposes scene interpretation, consequences, dialogue, and options. The GM commits final campaign events. Do not change mechanics, character sheets, quests, or hidden facts as canon unless the GM confirms.`,
    ``,
    `## Current Scene`,
    `Title: ${gate.sceneTitle || "Untitled scene"}`,
    `Location: ${gate.location || "Unknown location"}`,
    `World Time: ${gate.worldTime || "Unknown time"}`,
    ``,
    `Scene Text:`,
    "```text",
    gate.sceneText || "No scene text recorded.",
    "```",
    ``,
    `## Active Character Projection`,
    sheet ? [
      `Name: ${sheet.name}`,
      `Path: ${sheet.path || "unknown"}`,
      `Realm: ${sheet.realm || "unknown"}`,
      `CL: ${sheet.cultivationLevel || "unknown"}`,
      `Spheres: ${(sheet.spheres || []).join(", ") || "none listed"}`,
      `Current resources: ${sheet.resources.map((resource) => `${resource.resource_name || resource.name || resource.resource_id}: ${resource.current ?? resource.maximum ?? "?"}/${resource.maximum ?? resource.max ?? "?"}`).join("; ") || "none listed"}`
    ].join("\n") : "No active character selected.",
    ``,
    `## Quests`,
    gate.quests.length ? gate.quests.map((quest) => `- ${quest.title}: ${quest.notes}`).join("\n") : "- None",
    ``,
    `## Pinned People`,
    gate.pinnedPeople.length ? gate.pinnedPeople.map((person) => `- ${person.name}: ${person.notes}`).join("\n") : "- None",
    ``,
    `## Sect / World Notes`,
    gate.sectNotes || "None",
    ``,
    `## Recent Committed Events`,
    gate.events.length ? gate.events.slice(0, 6).map((event) => `- ${gateEventText(event)}`).join("\n") : "- None yet",
    ``,
    `## Current Player / GM Action`,
    action || $("gateActionInput")?.value.trim() || "No action entered yet.",
    ``,
    `## Response Request`,
    `Return a playable next beat with:`,
    `1. immediate narrated result;`,
    `2. any required GM confirmation or rules uncertainty;`,
    `3. 3-5 suggested next actions;`,
    `4. quest/person/sect updates as proposals only;`,
    `5. one Dao/Yijing pressure note if relevant.`,
    ``,
    `End with this exact machine-readable block so the dashboard can update the action buttons:`,
    `SUGGESTED_ACTIONS:`,
    `- first concrete player-facing action`,
    `- second concrete player-facing action`,
    `- third concrete player-facing action`,
    `- optional fourth or fifth action`
  ].flat().join("\n");
}

function renderGate() {
  if (!$("gateSceneTitle")) return;
  const gate = gateState();
  const currentCharacter = gate.activeCharacterId;
  if ($("gateCharacterSelect")) {
    $("gateCharacterSelect").innerHTML = packageOptionHtml(currentCharacter);
    if (state.packages.some((item) => item.id === currentCharacter)) $("gateCharacterSelect").value = currentCharacter;
    else if (state.packages[0]) {
      $("gateCharacterSelect").value = state.packages[0].id;
      gate.activeCharacterId = state.packages[0].id;
    }
  }
  $("gateSceneTitle").value = gate.sceneTitle || "";
  $("gateLocation").value = gate.location || "";
  $("gateWorldTime").value = gate.worldTime || "";
  $("gateSceneText").value = gate.sceneText || "";
  $("gateChoicesInput").value = gate.choices.join("\n");
  $("gateSectNotes").value = gate.sectNotes || "";
  $("gateCharacterRail").innerHTML = renderGateCharacterRail(gateActivePackage());
  $("gateChoices").innerHTML = gate.choices.map((choice, index) => `
    <button type="button" data-gate-choice="${escapeHtml(choice)}"><span>${index + 1}.</span>${escapeHtml(choice)}</button>
  `).join("");
  $("gateSceneHistory").innerHTML = renderGateHistory(gate);
  $("gateQuestList").innerHTML = renderGateCards(gate.quests, "quest");
  $("gatePinnedList").innerHTML = renderGateCards(gate.pinnedPeople, "pinned");
  $("gateAiPacketOutput").value = gateStatePacket();
  document.querySelectorAll("[data-gate-choice]").forEach((button) => {
    button.addEventListener("click", () => {
      $("gateActionInput").value = button.dataset.gateChoice;
      $("gateAiPacketOutput").value = gateStatePacket(button.dataset.gateChoice);
    });
  });
  document.querySelectorAll("[data-gate-remove]").forEach((button) => {
    button.addEventListener("click", () => removeGateItem(button.dataset.gateRemove, button.dataset.gateRemoveId));
  });
}

function saveGateScene() {
  gateSyncFromInputs();
  saveState();
  renderGate();
  toast("Gate scene saved.");
}

function commitGateAction() {
  gateSyncFromInputs();
  const gate = gateState();
  const action = $("gateActionInput").value.trim();
  if (!action) {
    toast("Add an action or choose an option first.");
    return;
  }
  gate.events.unshift({
    id: makeId("gate_evt"),
    created: new Date().toISOString(),
    actorId: gate.activeCharacterId || "",
    action,
    result: "Committed from Gate screen. Add/import follow-up scene text as needed.",
    source: "manual_gate"
  });
  $("gateActionInput").value = "";
  saveState();
  renderGate();
  toast("Gate event committed.");
}

function importGateAiResponse() {
  gateSyncFromInputs();
  const response = $("gateAiResponseInput").value.trim();
  if (!response) {
    toast("Paste a response first.");
    return;
  }
  const gate = gateState();
  const suggestedActions = extractSuggestedActions(response);
  const sceneText = stripSuggestedActionsBlock(response) || response;
  gate.sceneText = sceneText;
  if (suggestedActions.length) gate.choices = suggestedActions;
  gate.events.unshift({
    id: makeId("gate_evt"),
    created: new Date().toISOString(),
    actorId: gate.activeCharacterId || "",
    action: "Imported AI scene draft",
    result: compactText(sceneText, 260),
    source: "manual_ai_bridge"
  });
  $("gateAiResponseInput").value = "";
  saveState();
  renderGate();
  toast(suggestedActions.length ? "Scene draft and suggested actions imported." : "Scene draft imported.");
}

function addGateQuest() {
  const title = $("gateQuestTitle").value.trim();
  const notes = $("gateQuestNotes").value.trim();
  if (!title && !notes) {
    toast("Add quest text first.");
    return;
  }
  gateSyncFromInputs();
  gateState().quests.unshift({ id: makeId("quest"), title: title || "Untitled Quest", notes });
  $("gateQuestTitle").value = "";
  $("gateQuestNotes").value = "";
  saveState();
  renderGate();
}

function addGatePinnedPerson() {
  const name = $("gatePinnedName").value.trim();
  const notes = $("gatePinnedNotes").value.trim();
  if (!name && !notes) {
    toast("Add a person or faction first.");
    return;
  }
  gateSyncFromInputs();
  gateState().pinnedPeople.unshift({ id: makeId("pin"), name: name || "Unnamed", notes });
  $("gatePinnedName").value = "";
  $("gatePinnedNotes").value = "";
  saveState();
  renderGate();
}

function removeGateItem(kind, id) {
  gateSyncFromInputs();
  const gate = gateState();
  if (kind === "quest") gate.quests = gate.quests.filter((item) => item.id !== id);
  if (kind === "pinned") gate.pinnedPeople = gate.pinnedPeople.filter((item) => item.id !== id);
  saveState();
  renderGate();
}

function analyzePackageText(text, preferredName = "", version = "") {
  const rawText = String(text || "").trim();
  const blocks = parseFileBlocks(rawText);
  const parsedJson = parseJsonPackageBlocks(blocks);
  const sheetExport = findJsonBlock(parsedJson, [/sheet_export/i, /complete_sheet/i, /Complete_Character_Record/i, /tianxia_character_sheet_export/i, /tianxia_complete_sheet_export/i, /tianxia_complete_character_record/i])?.data || {};
  const dashboardImport = findJsonBlock(parsedJson, [/Dashboard_Import/i, /tianxia_dashboard_import/i])?.data || {};
  const normalizedBlock = findJsonBlock(parsedJson, [/Normalized_Sheet/i, /Normalized_Character/i, /normalized_character/i, /tianxia_normalized_sheet/i, /_Normalized\.json$/i])?.data || {};
  const normalizedJson = Object.keys(normalizedBlock).length ? normalizedBlock : sheetExport.raw_normalized_character || {};
  const importSurfaceJson = findJsonBlock(parsedJson, [/^(?:.*[\\/])?Character_Import_Surface\.json$/i, /character_import_surface/i])?.data || {};
  const runtimeJson = findJsonBlock(parsedJson, [/Fight_Runtime_Initialization_Profile/i, /fight_runtime_initialization/i])?.data || {};
  const directRecord = sheetExport.character || sheetExport;
  const exportIdentity = sheetExport.identity || sheetExport.character || dashboardImport.identity || dashboardImport.character || {};
  const exportCultivation = sheetExport.cultivation || sheetExport.progression || dashboardImport.cultivation || dashboardImport.progression || {};
  const exportBuild = sheetExport.build || {};
  const identityText = packageIdentityText(blocks, rawText);
  const lines = splitCleanLines(identityText);
  const detected = detectSphereWeights(identityText, lines);
  const explicitSpheres = extractExplicitPackageSpheres(identityText);
  const exportedSpheres = Array.isArray(exportBuild.spheres) && exportBuild.spheres.length
    ? namedEntries(exportBuild.spheres)
    : Array.isArray(sheetExport.spheres) && sheetExport.spheres.length ? namedEntries(sheetExport.spheres)
      : Array.isArray(directRecord.spheres) && directRecord.spheres.length ? namedEntries(directRecord.spheres)
      : Array.isArray(dashboardImport.spheres) && dashboardImport.spheres.length ? namedEntries(dashboardImport.spheres)
        : Array.isArray(normalizedJson.spheres) ? namedEntries(normalizedJson.spheres) : Array.isArray(normalizedJson.spheres_routes) ? namedEntries(normalizedJson.spheres_routes) : [];
  const primaryName = explicitSpheres.primary[0] || exportedSpheres[0];
  const primary = primaryName ? profile(primaryName) : detected[0]?.sphere || profile("Smoke");
  const secondaryName = explicitSpheres.secondary.find((name) => name !== primary.name)
    || explicitSpheres.primary.find((name) => name !== primary.name)
    || exportedSpheres.find((name) => name !== primary.name);
  const secondary = secondaryName ? profile(secondaryName) : detected.find((item) => item.sphere.name !== primary.name)?.sphere || null;
  const artifacts = detectArtifacts(rawText, blocks);
  const nameFromFile = blocks
    .map((block) => cleanNameCandidate(block.name))
    .find(isLikelyNameCandidate);
  const preferred = cleanNameCandidate(preferredName);
  const jsonNameRaw = String(importSurfaceJson.display_name || importSurfaceJson.full_name || importSurfaceJson.name || importSurfaceJson.character_name || importSurfaceJson.identity?.display_name || importSurfaceJson.identity?.name || exportIdentity.name || sheetExport.name || sheetExport.character_name || dashboardImport.name || normalizedJson.name || normalizedJson.character_name || runtimeJson.name || runtimeJson.character_name || "").trim();
  const jsonName = isLikelyNameCandidate(jsonNameRaw) ? jsonNameRaw : cleanNameCandidate(jsonNameRaw);
  const name = (isLikelyNameCandidate(jsonName) ? jsonName : "") || (isLikelyNameCandidate(preferred) ? preferred : "") || nameFromFile || extractNpcName(lines) || "Unnamed Tianxia Character";
  const jsonPath = importSurfaceJson.path || importSurfaceJson.cultivation?.path || exportCultivation.path || exportIdentity.path || directRecord.path || sheetExport.path || dashboardImport.path || normalizedJson.path || runtimeJson.path || "";
  const jsonRealm = importSurfaceJson.realm || importSurfaceJson.realm_and_stage || importSurfaceJson.cultivation?.realm || importSurfaceJson.cultivation?.realm_and_stage || [exportCultivation.stage, exportCultivation.realm].filter(Boolean).join(" ") || exportCultivation.realm || exportIdentity.realm || directRecord.realm || sheetExport.realm || dashboardImport.realm || normalizedJson.realm_and_stage || normalizedJson.realm || runtimeJson.realm_and_stage || runtimeJson.realm || "";
  const jsonVersion = importSurfaceJson.package_version || importSurfaceJson.schema || sheetExport.source?.package_version || sheetExport.build_version || exportIdentity.build_version || directRecord.build_version || sheetExport.package_version || sheetExport.schema_version || normalizedJson.package_version || runtimeJson.package_version || parsedJson.map((item) => item.data?.package_version || item.data?.build_version).find(Boolean) || "";
  const path = jsonPath || extractPackagePath(identityText);
  const realm = jsonRealm || extractPackageRealm(identityText);
  return {
    name,
    characterId: sheetExport.character_id || directRecord.character_id || exportIdentity.character_id || normalizedJson.character_id || runtimeJson.character_id || runtimeJson.runtime_actor_id || "",
    version: version || jsonVersion || extractNpcField(lines, ["Package Version", "Version"]) || "unversioned",
    path,
    realm,
    primary: primary.name,
    secondary: secondary?.name || "",
    daoPhrase: makeDaoPhrase(primary, secondary),
    detected: detected.slice(0, 8).map((item) => ({ name: item.sphere.name, weight: item.weight })),
    artifacts,
    readiness: packageReadiness(artifacts),
    blocks,
    sourcePackageKey: importSourcePackageKeyFromBlocks(blocks),
    rawText
  };
}

function currentPackageAnalysis() {
  const text = $("canonPackageInput").value.trim();
  if (!text) return null;
  return analyzePackageText(text, $("canonPackageName").value.trim(), $("canonPackageVersion").value.trim());
}

function renderPackageAnalysis(analysis) {
  if (!analysis) {
    $("packageAnalysis").textContent = "No package analyzed yet.";
    return;
  }
  $("packageAnalysis").innerHTML = `
    <h3>${escapeHtml(analysis.name)}</h3>
    <p>${escapeHtml(analysis.path)} | ${escapeHtml(analysis.realm || "realm unclear")} | ${escapeHtml(analysis.readiness)}</p>
    <div class="tag-row">
      <span class="tag sphere">${escapeHtml(analysis.primary)}</span>
      ${analysis.secondary ? `<span class="tag sphere">${escapeHtml(analysis.secondary)}</span>` : ""}
      <span class="tag">${escapeHtml(analysis.version)}</span>
    </div>
    <div class="status-grid">
      ${summarizeArtifacts(analysis.artifacts).map((item) => `
        <div class="status-item ${item.status.toLowerCase()}">
          <strong>${item.status}</strong>
          ${escapeHtml(item.label)}
        </div>
      `).join("")}
    </div>
  `;
}

function analyzePackageInput() {
  const analysis = currentPackageAnalysis();
  if (!analysis) {
    toast("Paste a package or stat block first.");
    return null;
  }
  if (!$("canonPackageName").value.trim()) $("canonPackageName").value = analysis.name;
  if (!$("canonPackageVersion").value.trim()) $("canonPackageVersion").value = analysis.version;
  renderPackageAnalysis(analysis);
  toast("Package analyzed.");
  return analysis;
}


function importSourcePackageKeyFromBlocks(blocks = []) {
  if (!Array.isArray(blocks) || !blocks.length) return "";
  const first = String(blocks[0]?.name || "").replace(/\\/g, "/");
  const parts = first.split("/").filter(Boolean);
  const candidate = parts.find((part) => /CL\d+.*HF05B3Z/i.test(part)) || parts[0] || "";
  return candidate.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
}

function packageHumanNameKey(value = "") {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/—/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\b(?:cl\d+|hf05b3z|r9|r12|stable|normalized|full|audited|optimized|tournament|build)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const R9_R12_ROSTER_NAME_ALIASES = {
  "gaara": ["gaara", "gaara desert guardian", "gaara desert guardian sand coffin kazekage"],
  "bai meizhen": ["bai meizhen", "bai meizhen white serpent venom mist heiress"],
  "cai renxiang": ["cai renxiang", "cai renxiang white gold heiress"],
  "sun liling": ["sun liling", "sun liling crimson princess"],
  "ling qi": ["ling qi", "ling qi hidden moon vale songseeker"],
  "gu xiulan": ["gu xiulan", "gu xiulan later crimson wildfire thunder scar"],
  "orochimaru": ["orochimaru", "orochimaru white snake sannin"],
  "liang zhen": ["liang zhen", "liang zhen cinder kite spearbreaker"],
  "shen baoli": ["shen baoli", "shen baoli rain mirror chain magistrate"],
  "itachi uchiha": ["itachi uchiha", "itachi uchiha moonlit crow mirror"],
  "miyamoto musashi": ["miyamoto musashi", "musashi", "miyamoto musashi niten ichi ryu"],
  "yagyu munenori": ["yagyu munenori", "yagyū munenori", "yagyu munenori shinkage ryu"]
};

function rosterCanonicalNameKey(value = "") {
  const key = packageHumanNameKey(value);
  if (!key) return "";
  for (const [canonical, aliases] of Object.entries(R9_R12_ROSTER_NAME_ALIASES)) {
    if (aliases.some((alias) => key === packageHumanNameKey(alias) || key.startsWith(packageHumanNameKey(alias)) || packageHumanNameKey(alias).startsWith(key))) return canonical;
  }
  return key;
}

function isLegacyBadPackageRecord(pkg = {}) {
  const label = String(pkg?.name || pkg?.sheetData?.name || "").trim();
  if (!label) return false;
  if (/(?:Ability Source Closure Ledger|Legal Talent Inventory|Composite Action Registry|Combat Playbook|Character Action Registry|Foundation Registry|Forged Technique Registry|Dashboard Import|Complete Action Surface|Action Execution Scripts|Martial Arts and Manuals|Normalized Sheet|Complete Character Record)$/i.test(label)) return true;
  const actions = Array.isArray(pkg?.sheetData?.actions) ? pkg.sheetData.actions : [];
  if (actions.length >= 3) {
    const unnamed = actions.filter((action) => /^(?:Unnamed Action)?$/i.test(String(action?.action_name || action?.name || action?.display_name || "").trim()) || /^Unnamed Action$/i.test(String(action?.action_name || action?.name || action?.display_name || ""))).length;
    if (unnamed / actions.length >= 0.5) return true;
  }
  const blocks = Array.isArray(pkg?.blocks) ? pkg.blocks : [];
  if (!blocks.length && actions.length && actions.every((action) => /^Unnamed Action$/i.test(String(action?.action_name || "")))) return true;
  const rosterKey = rosterCanonicalNameKey(label);
  if (rosterKey && R9_R12_ROSTER_NAME_ALIASES[rosterKey]) {
    const hasCompositeSupport = blocks.some((block) => /(?:Composite_Action_Registry|Combat_Playbook)\.json$/i.test(String(block?.name || "")));
    const forgedSupportMissing = !blocks.some((block) => /Forged_Technique_Registry\.json$/i.test(String(block?.name || "")));
    const martialSupportMissing = !Array.isArray(pkg?.sheetData?.martialArtsLearned) || !pkg.sheetData.martialArtsLearned.length;
    if (actions.length && !hasCompositeSupport) return true;
    if (/^Gaara/i.test(label) && (forgedSupportMissing || actions.some((action) => /^Unnamed Action$/i.test(String(action?.action_name || ""))))) return true;
    if (/^Bai Meizhen/i.test(label) && martialSupportMissing) return true;
  }
  return false;
}

function purgeStalePackagesForIncomingAnalyses(analyses = []) {
  if (!Array.isArray(analyses) || !analyses.length || !Array.isArray(state?.packages)) return 0;
  const incomingCharacters = new Set();
  const incomingIds = new Set();
  const incomingSources = new Set();
  analyses.forEach((analysis) => {
    const nameKey = rosterCanonicalNameKey(analysis?.name || analysis?.sheetData?.name || "");
    if (nameKey) incomingCharacters.add(nameKey);
    const id = String(analysis?.characterId || analysis?.sheetData?.characterId || "").trim();
    if (id) incomingIds.add(id);
    const sourceKey = analysis?.sourcePackageKey || importSourcePackageKeyFromBlocks(analysis?.blocks || []);
    if (sourceKey) incomingSources.add(sourceKey);
  });
  const before = state.packages.length;
  state.packages = state.packages.filter((pkg) => {
    const id = String(pkg?.characterId || pkg?.sheetData?.characterId || "").trim();
    if (id && incomingIds.has(id)) return false;
    const sourceKey = pkg?.sourcePackageKey || importSourcePackageKeyFromBlocks(pkg?.blocks || []);
    if (sourceKey && incomingSources.has(sourceKey)) return false;
    const pkgNameKey = rosterCanonicalNameKey(pkg?.name || pkg?.sheetData?.name || "");
    if (pkgNameKey && incomingCharacters.has(pkgNameKey)) return false;
    if (isLegacyBadPackageRecord(pkg)) return false;
    return true;
  });
  return before - state.packages.length;
}

function cleanupLegacyBadPackagesOnLoad() {
  if (!Array.isArray(state?.packages) || !state.packages.length) return 0;
  const before = state.packages.length;
  state.packages = state.packages.filter((pkg) => !isLegacyBadPackageRecord(pkg));
  return before - state.packages.length;
}

function storePackageAnalysis(analysis) {
  const incomingName = String(analysis.name || "").toLowerCase();
  const incomingNameKey = rosterCanonicalNameKey(analysis.name || "");
  const incomingSourceKey = analysis.sourcePackageKey || importSourcePackageKeyFromBlocks(analysis.blocks || []);
  const incomingCharacterId = String(analysis.characterId || "");
  const existing = state.packages.find((item) => {
    const itemCharacterId = String(item?.sheetData?.characterId || item?.characterId || "");
    if (incomingCharacterId && itemCharacterId === incomingCharacterId) return true;
    if (incomingSourceKey && (item.sourcePackageKey || importSourcePackageKeyFromBlocks(item.blocks || [])) === incomingSourceKey) return true;
    if (String(item?.name || "").toLowerCase() === incomingName) return true;
    return incomingNameKey && rosterCanonicalNameKey(item?.name || item?.sheetData?.name || "") === incomingNameKey;
  });
  const saved = compactSavedPackage({
    id: existing?.id || makeId("pkg"),
    created: existing?.created || new Date().toISOString(),
    updated: new Date().toISOString(),
    ...analysis,
    sourcePackageKey: incomingSourceKey
  });
  saved.sourcePackageKey = incomingSourceKey || saved.sourcePackageKey || "";
  // HF05X: do not purge newly imported roster records during each individual
  // store operation.  Earlier cleanup treated partially parsed current R9/R12
  // imports with sparse/legacy-looking surfaces as stale and deleted them as
  // later roster members were saved, leaving only a few characters visible.
  // Stale cleanup is handled before/before-merge by purgeStalePackages*; once
  // an analysis has reached this function, preserve every distinct saved package.
  state.packages = [saved, ...state.packages.filter((item) => item.id !== saved.id)];
  return saved;
}

function savePackage() {
  const analysis = analyzePackageInput();
  if (!analysis) return;
  storePackageAnalysis(analysis);
  saveState();
  renderAutomation();
  renderCharacterViewer();
  toast("Character package saved.");
}

function deletePackage(id) {
  state.packages = state.packages.filter((item) => item.id !== id);
  delete state.characterNotes[id];
  saveState();
  renderAutomation();
  renderCharacterViewer();
  toast("Package removed.");
}

function packageById(id) {
  return state.packages.find((item) => item.id === id) || null;
}

function packageSelectLabel(item) {
  const level = levelValue(item?.sheetData?.cultivationLevel)
    || levelValue(item?.cultivationLevel)
    || levelValue(item?.level)
    || levelFromText(item?.sheetData?.realm || item?.realm || "");
  return level === "" || level === null || level === undefined
    ? item.name
    : `${item.name} - Level ${level}`;
}

function packageOptionHtml(selected = "") {
  if (!state.packages.length) return `<option value="">No packages saved</option>`;
  return state.packages.map((item) => `<option value="${escapeHtml(item.id)}" ${item.id === selected ? "selected" : ""}>${escapeHtml(packageSelectLabel(item))}</option>`).join("");
}

function renderPackageList() {
  $("packageList").innerHTML = state.packages.length ? state.packages.map((item) => `
    <article class="canon-card">
      <header>
        <div>
          <h3>${escapeHtml(item.name)}</h3>
          <div class="mini-meta">
            <span class="tag">${escapeHtml(item.version)}</span>
            <span class="tag">${escapeHtml(item.readiness)}</span>
            <span class="tag sphere">${escapeHtml(item.primary)}</span>
            ${item.secondary ? `<span class="tag sphere">${escapeHtml(item.secondary)}</span>` : ""}
          </div>
        </div>
        <button class="ghost-button" type="button" data-delete-package="${escapeHtml(item.id)}">Remove</button>
      </header>
      <p>${escapeHtml(item.path)}${item.realm ? ` | ${escapeHtml(item.realm)}` : ""}</p>
      <p>${escapeHtml(item.daoPhrase)}</p>
    </article>
  `).join("") : `<div class="empty-state">No saved character packages yet. Paste a package or stat block above and save it.</div>`;
  document.querySelectorAll("[data-delete-package]").forEach((button) => {
    button.addEventListener("click", () => deletePackage(button.dataset.deletePackage));
  });
}

function refreshPackageSelectors() {
  ["gateCharacterSelect", "activeCharacterSelect", "tribCharacterSelect", "tribTrackCharacter", "preFightA", "preFightB", "regressionA", "regressionB"].forEach((id) => {
    if (!$(id)) return;
    const current = $(id).value;
    $(id).innerHTML = packageOptionHtml(current);
    if (state.packages.some((item) => item.id === current)) $(id).value = current;
  });
}

function packageSummary(pkg) {
  if (!pkg) return "No package selected.";
  return [
    `Character: ${pkg.name}`,
    `Version: ${pkg.version}`,
    `Path: ${pkg.path}`,
    pkg.realm ? `Realm: ${pkg.realm}` : null,
    `Primary sphere: ${pkg.primary}`,
    pkg.secondary ? `Secondary sphere: ${pkg.secondary}` : null,
    `Dao phrase: ${pkg.daoPhrase}`,
    `Readiness: ${pkg.readiness}`,
    `Artifacts present: ${summarizeArtifacts(pkg.artifacts).filter((item) => item.present).map((item) => item.label).join(", ") || "none detected"}`
  ].filter(Boolean).join("\n");
}

function relevantPacketsForPackage(pkg) {
  if (!pkg) return [];
  const lowerName = pkg.name.toLowerCase();
  return state.packets.filter((packet) => packet.player.toLowerCase() === lowerName).slice(0, 8);
}

function notesForPackage(id) {
  if (!id) return { marks: [], rivals: [], encounters: [], physicalDescription: "" };
  const current = state.characterNotes[id] || {};
  const notes = {
    marks: Array.isArray(current.marks) ? current.marks : [],
    rivals: Array.isArray(current.rivals) ? current.rivals : [],
    encounters: Array.isArray(current.encounters) ? current.encounters : [],
    equipment: Array.isArray(current.equipment) ? current.equipment : [],
    consumables: Array.isArray(current.consumables) ? current.consumables : [],
    martialArts: Array.isArray(current.martialArts) ? current.martialArts : [],
    physicalDescription: typeof current.physicalDescription === "string" ? current.physicalDescription : ""
  };
  state.characterNotes[id] = notes;
  return notes;
}

function activePackage() {
  return packageById($("activeCharacterSelect")?.value);
}

function bestPackageBlock(pkg) {
  if (!pkg) return "";
  const wanted = [
    /readable\s+sheet\s+source|readable\s+sheet/i,
    /normalized\s+sheet/i,
    /stat\s+block/i,
    /combat\s+package/i
  ];
  for (const pattern of wanted) {
    const block = (pkg.blocks || []).find((item) => pattern.test(item.name) && !/\.json/i.test(item.name));
    if (block?.content) return `# ${block.name}\n\n${block.content}`;
  }
  return pkg.rawText || "";
}

function linkedItemHtml(type, item) {
  return `
    <article class="linked-card">
      <header>
        <strong>${escapeHtml(item.name || "Unnamed")}</strong>
        <button class="ghost-button" type="button" data-delete-linked="${escapeHtml(type)}:${escapeHtml(item.id)}">Remove</button>
      </header>
      <p><span class="tag">${escapeHtml(item.status || "open")}</span></p>
      ${item.notes ? `<p>${escapeHtml(item.notes)}</p>` : ""}
    </article>
  `;
}

function renderLinkedList(id, type, items) {
  $(id).innerHTML = items.length
    ? items.map((item) => linkedItemHtml(type, item)).join("")
    : `<div class="empty-state">Nothing linked yet.</div>`;
}

function activeCharacterPacketText() {
  const pkg = activePackage();
  if (!pkg) return "No active character selected.";
  const notes = notesForPackage(pkg.id);
  const packets = relevantPacketsForPackage(pkg);
  return [
    `# Active Character Packet`,
    ``,
    packageSummary(pkg),
    ``,
    `## Marks`,
    notes.marks.length ? notes.marks.map((item) => `- ${item.name || "Unnamed"} [${item.status || "open"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Physical Description`,
    notes.physicalDescription?.trim() || "- Not recorded.",
    ``,
    `## Rivals`,
    notes.rivals.length ? notes.rivals.map((item) => `- ${item.name || "Unnamed"} [${item.status || "open"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Encounter Links`,
    notes.encounters.length ? notes.encounters.map((item) => `- ${item.name || "Unnamed"} [${item.status || "open"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Equipment Notes`,
    notes.equipment.length ? notes.equipment.map((item) => `- ${item.name || "Unnamed"} [${item.status || "carried"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Consumables Notes`,
    notes.consumables.length ? notes.consumables.map((item) => `- ${item.name || "Unnamed"} [${item.status || "available"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Martial Arts Learned`,
    notes.martialArts.length ? notes.martialArts.map((item) => `- ${item.name || "Unnamed"} [${item.status || "learned"}]: ${item.notes || "no notes"}`).join("\n") : "- None recorded.",
    ``,
    `## Recent Dao Packets`,
    packets.length ? packets.map((packet) => `- ${packetText(packet)}${packet.notes ? ` | ${packet.notes}` : ""}`).join("\n") : "- None recorded.",
    ``,
    `## Use`,
    `Use this packet as active context for scenes, encounters, rivals, teachers, tribulations, or character-specific follow-up. Do not change mechanics without human approval.`
  ].join("\n");
}

function safeFileName(name, fallback = "Tianxia_Character") {
  return String(name || fallback).replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "") || fallback;
}

function compactCombatExportPayload(pkg = activePackage()) {
  if (!pkg) return null;
  const notes = notesForPackage(pkg.id);
  const packets = relevantPacketsForPackage(pkg);
  const sheet = compactSheetData(buildCharacterSheetData(pkg));
  return {
    schema_version: "tianxia_compact_combat_export_v1",
    export_kind: "COMPACT_COMBAT_HANDOFF",
    generated_at: new Date().toISOString(),
    intended_use: [
      "Paste into a new chat with Tianxia_Mobile_New_Chat_Combat_Simulation_Bootstrap_v1.md.",
      "Use as the operative combat sheet unless a newer full character package is supplied.",
      "Do not treat this compact export as full source validation."
    ],
    character: {
      id: pkg.id,
      name: pkg.name || sheet.name,
      version: pkg.version || "unversioned",
      readiness: pkg.readiness || "unknown",
      path: pkg.path || sheet.path,
      realm: pkg.realm || sheet.realm,
      primary_sphere: pkg.primary || sheet.spheres?.[0] || "",
      secondary_sphere: pkg.secondary || sheet.spheres?.[1] || "",
      dao_phrase: pkg.daoPhrase || ""
    },
    sheet,
    links: {
      physical_description: notes.physicalDescription || sheet.physicalDescription || "",
      marks: notes.marks || [],
      rivals: notes.rivals || [],
      encounters: notes.encounters || [],
      equipment: notes.equipment || [],
      consumables: notes.consumables || [],
      martial_arts_learned: notes.martialArts || [],
      recent_dao_packets: packets.map((packet) => ({
        player: packet.player,
        sphere: packet.sphere,
        action: packet.action,
        weight: packet.weight,
        outer: packet.outer,
        inner: packet.inner,
        notes: packet.notes || ""
      }))
    },
    source_status: {
      dashboard_package_version: pkg.version || "",
      dashboard_readiness: pkg.readiness || "",
      strict_source_validation: "not asserted by compact export",
      import_note: "Full raw source blocks are intentionally omitted to keep this handoff small."
    }
  };
}

function compactCombatExportMarkdown(pkg = activePackage()) {
  const payload = compactCombatExportPayload(pkg);
  if (!payload) return "No active character selected.";
  const sheet = payload.sheet;
  const resources = (sheet.resources || []).map((item) => {
    if (typeof item === "string") return `- ${item}`;
    return `- ${item.name || item.resource_id || "Resource"}: ${item.current || "?"}/${item.maximum || "?"}${item.recovery ? `; recovery ${item.recovery}` : ""}`;
  });
  const actions = (sheet.actions || []).map(compactActionEntry).map(actionLine);
  const passives = (sheet.passives || []).map((item) => `- ${item.name || "Unnamed"}${item.summary ? `: ${item.summary}` : ""}`);
  const marks = (payload.links.marks || []).map((item) => `- ${item.name || "Unnamed"} [${item.status || "open"}]: ${item.notes || "no notes"}`);
  return [
    `# Tianxia Compact Combat Export`,
    ``,
    `Use with: Tianxia_Mobile_New_Chat_Combat_Simulation_Bootstrap_v1.md`,
    ``,
    `## Identity`,
    `Name: ${payload.character.name}`,
    `Version: ${payload.character.version}`,
    `Readiness: ${payload.character.readiness}`,
    `Path: ${payload.character.path || "unknown"}`,
    `Realm: ${payload.character.realm || "unknown"}`,
    `CL: ${sheet.cultivationLevel || "unknown"}`,
    `Dao Phrase: ${payload.character.dao_phrase || "not recorded"}`,
    ``,
    `## Core Combat Stats`,
    `HP: ${asDisplayText(sheet.hp) || "unknown"}`,
    `AC: ${asDisplayText(sheet.ac) || "unknown"}`,
    `Speed: ${asDisplayText(sheet.speed) || "unknown"}`,
    `PB: ${sheet.proficiencyBonus || "unknown"}`,
    `Attack Bonus: ${sheet.cultivationAttackBonus || "unknown"}`,
    `Save DC: ${sheet.cultivationSaveDc || "unknown"}`,
    `Key Ability: ${sheet.keyAbility || "unknown"}`,
    ``,
    `## Ability Scores`,
    asDisplayText(sheet.abilityScores) || "Not recorded.",
    ``,
    `## Saves`,
    asDisplayText(sheet.saves) || "Not recorded.",
    ``,
    `## Resources`,
    resources.length ? resources.join("\n") : "- None recorded.",
    ``,
    `## Spheres`,
    sheet.spheres?.length ? sheet.spheres.map((sphere) => `- ${sphere}`).join("\n") : "- None recorded.",
    ``,
    `## Talents and Insights`,
    [
      ...(sheet.talents || []).map((item) => `- Talent: ${item.name || item}${item.summary ? `: ${item.summary}` : ""}`),
      ...(sheet.insights || []).map((item) => `- Insight: ${item.name || item}${item.summary ? `: ${item.summary}` : ""}`),
      ...(sheet.forgedTechniques || []).map((item) => `- Forged Technique: ${item.name || item}${item.summary ? `: ${item.summary}` : ""}`)
    ].join("\n") || "- None recorded.",
    ``,
    `## Actions`,
    actions.length ? actions.join("\n\n") : "- No action registry found.",
    ``,
    `## Passives and States`,
    passives.length ? passives.join("\n") : "- No passives recorded.",
    ``,
    `## Assets`,
    sheet.assets?.length ? sheet.assets.map((item) => `- ${item.name || item}${item.summary ? `: ${item.summary}` : ""}`).join("\n") : "- No controlled assets recorded.",
    ``,
    `## Equipment`,
    sheet.equipment?.length ? sheet.equipment.map((item) => `- ${inventoryLine(item)}`).join("\n") : "- None recorded.",
    ``,
    `## Consumables`,
    sheet.consumables?.length ? sheet.consumables.map((item) => `- ${inventoryLine(item)}`).join("\n") : "- None recorded.",
    ``,
    `## Martial Arts Learned`,
    [
      ...(sheet.martialArtsLearned || []).map((item) => `- ${inventoryLine(item)}`),
      ...(payload.links.martial_arts_learned || []).map((item) => `- ${item.name || "Unnamed"} [${item.status || "learned"}]: ${item.notes || "no notes"}`)
    ].join("\n") || "- None recorded.",
    ``,
    `## Defenses`,
    `Resistances: ${sheet.resistances?.length ? sheet.resistances.join(", ") : "none listed"}`,
    `Immunities: ${sheet.immunities?.length ? sheet.immunities.join(", ") : "none listed"}`,
    `Vulnerabilities: ${sheet.vulnerabilities?.length ? sheet.vulnerabilities.join(", ") : "none listed"}`,
    ``,
    `## Current Character Notes`,
    `Physical Description: ${payload.links.physical_description || "not recorded"}`,
    `Marks:`,
    marks.length ? marks.join("\n") : "- None recorded.",
    ``,
    `## Source Status`,
    `This is a compact combat handoff, not a full source archive. Use it as operative combat data, but mark exact source validation as WARN/SOURCE_NEEDED unless full rules files are also loaded.`
  ].join("\n");
}

function activeCharacterCombatExportText() {
  const pkg = activePackage();
  if (!pkg) return "No active character selected.";
  const payload = compactCombatExportPayload(pkg);
  return [
    `# New Chat Combat Handoff`,
    ``,
    `Load Tianxia_Mobile_New_Chat_Combat_Simulation_Bootstrap_v1.md first.`,
    `Then use this compact character export as one combatant's operative sheet.`,
    ``,
    fileBlock(`${safeFileName(payload.character.name)}_Compact_Combat_Export.md`, compactCombatExportMarkdown(pkg)),
    ``,
    fileBlock(`${safeFileName(payload.character.name)}_Compact_Combat_Export.json`, JSON.stringify(payload, null, 2))
  ].join("\n\n");
}

function exportActiveCombatZip() {
  const pkg = activePackage();
  if (!pkg) {
    toast("Select an active character first.");
    return;
  }
  const payload = compactCombatExportPayload(pkg);
  const safeName = safeFileName(payload.character.name);
  const files = [
    {
      name: "README_FIRST.md",
      content: [
        `# ${payload.character.name} Compact Combat Export`,
        ``,
        `Load Tianxia_Mobile_New_Chat_Combat_Simulation_Bootstrap_v1.md in a new chat, then upload or paste this package.`,
        ``,
        `This package is intentionally compact. It omits raw source archives and long audits so fights can run in smaller chats.`,
        ``,
        `Use the JSON as structured combat data and the Markdown as the readable combat sheet.`
      ].join("\n")
    },
    { name: `${safeName}_Compact_Combat_Export.md`, content: compactCombatExportMarkdown(pkg) },
    { name: `${safeName}_Compact_Combat_Export.json`, content: JSON.stringify(payload, null, 2) },
    { name: `${safeName}_New_Chat_Handoff.txt`, content: activeCharacterCombatExportText() }
  ];
  const zipBytes = createStoredZip(files);
  downloadBlob(new Blob([zipBytes], { type: "application/zip" }), `${safeName}_Compact_Combat_Handoff.zip`);
  toast("Compact combat handoff exported.");
}

function renderCharacterViewer() {
  if (!$("activeCharacterSelect")) return;
  refreshPackageSelectors();
  const pkg = activePackage();
  if (!pkg) {
    $("activeCharacterSummary").innerHTML = `<div class="empty-state">Save a character package in Automation, then select it here.</div>`;
    if ($("physicalDescriptionNotes")) $("physicalDescriptionNotes").value = "";
    $("activeCharacterSheet").value = "";
    if ($("activeCharacterVisualSheet")) $("activeCharacterVisualSheet").innerHTML = `<div class="empty-state">No character selected.</div>`;
    $("activeCharacterPrompt").value = "";
    ["markList", "rivalList", "encounterLinkList", "equipmentList", "consumableList", "martialArtList"].forEach((id) => {
      if ($(id)) $(id).innerHTML = `<div class="empty-state">No active character.</div>`;
    });
    return;
  }
  const notes = notesForPackage(pkg.id);
  if ($("physicalDescriptionNotes")) {
    $("physicalDescriptionNotes").value = notes.physicalDescription || "";
    $("physicalDescriptionNotes").onchange = () => {
      const currentNotes = notesForPackage(pkg.id);
      currentNotes.physicalDescription = $("physicalDescriptionNotes").value.trim();
      saveState();
      $("activeCharacterSheet").value = renderReadableCharacterSheet(pkg, currentNotes);
      if ($("activeCharacterVisualSheet")) {
        $("activeCharacterVisualSheet").innerHTML = renderVisualCharacterSheet(pkg, currentNotes);
        attachVisualSheetTabs();
      }
      $("activeCharacterPrompt").value = activeCharacterPacketText();
      toast("Physical description saved.");
    };
  }
  $("activeCharacterSummary").innerHTML = `
    <h3>${escapeHtml(pkg.name)}</h3>
    <p>${escapeHtml(pkg.path)}${pkg.realm ? ` | ${escapeHtml(pkg.realm)}` : ""} | ${escapeHtml(pkg.readiness)}</p>
    <div class="tag-row">
      <span class="tag sphere">${escapeHtml(pkg.primary)}</span>
      ${pkg.secondary ? `<span class="tag sphere">${escapeHtml(pkg.secondary)}</span>` : ""}
      <span class="tag">${escapeHtml(pkg.version)}</span>
    </div>
    <p>${escapeHtml(pkg.daoPhrase)}</p>
  `;
  $("activeCharacterSheet").value = renderReadableCharacterSheet(pkg, notes);
  if ($("activeCharacterVisualSheet")) {
    $("activeCharacterVisualSheet").innerHTML = renderVisualCharacterSheet(pkg, notes);
    attachVisualSheetTabs();
  }
  renderLinkedList("markList", "marks", notes.marks);
  renderLinkedList("rivalList", "rivals", notes.rivals);
  renderLinkedList("encounterLinkList", "encounters", notes.encounters);
  renderLinkedList("equipmentList", "equipment", notes.equipment);
  renderLinkedList("consumableList", "consumables", notes.consumables);
  renderLinkedList("martialArtList", "martialArts", notes.martialArts);
  $("activeCharacterPrompt").value = activeCharacterPacketText();
  document.querySelectorAll("[data-delete-linked]").forEach((button) => {
    button.addEventListener("click", () => {
      const [type, itemId] = button.dataset.deleteLinked.split(":");
      deleteLinkedItem(type, itemId);
    });
  });
}

function addLinkedItem(type, nameId, statusId, notesId) {
  const pkg = activePackage();
  if (!pkg) {
    toast("Select an active character first.");
    return;
  }
  const name = $(nameId).value.trim();
  const notesText = $(notesId).value.trim();
  if (!name && !notesText) {
    toast("Add a name or note first.");
    return;
  }
  const notes = notesForPackage(pkg.id);
  notes[type].unshift({
    id: makeId(type),
    created: new Date().toISOString(),
    name: name || "Unnamed",
    status: $(statusId).value.trim(),
    notes: notesText
  });
  [nameId, statusId, notesId].forEach((id) => { $(id).value = ""; });
  saveState();
  renderCharacterViewer();
  toast("Linked to character.");
}

function deleteLinkedItem(type, itemId) {
  const pkg = activePackage();
  if (!pkg) return;
  const notes = notesForPackage(pkg.id);
  notes[type] = notes[type].filter((item) => item.id !== itemId);
  saveState();
  renderCharacterViewer();
  toast("Link removed.");
}

function memoryExportText() {
  return [
    `# Tianxia Dashboard Memory Export`,
    ``,
    `## Global Rules Lessons`,
    state.globalRules.length ? state.globalRules.map((item, index) => `${index + 1}. ${item.text}`).join("\n") : "None saved.",
    ``,
    `## Tactical Patterns`,
    state.tacticalPatterns.length ? state.tacticalPatterns.map((item, index) => `${index + 1}. ${item.text}`).join("\n\n") : "None saved.",
    ``,
    `## Recent Reflection Notes`,
    state.reflections.length ? state.reflections.slice(0, 10).map((item, index) => `${index + 1}. ${item.encounterId || "Unnamed encounter"} - ${item.outcome || "outcome unstated"}\n${item.notes}`).join("\n\n") : "None saved."
  ].join("\n");
}

function buildCharacterPrompt() {
  const idea = $("characterIdeaInput").value.trim() || "Create a Tianxia character from the user's next idea.";
  $("characterPromptOutput").value = [
    `Use the Tianxia ChatGPT Character Creation Canon Workflow v1.1 as canon for this character generation.`,
    `Also load the Tianxia Sphere Catalogue Lock and Creative Generation Patch v1.`,
    ``,
    `Canonical sphere catalogue (${CANONICAL_SPHERE_NAMES.length} spheres):`,
    SPHERE_CATALOGUE_TEXT,
    ``,
    `Alias lock: Flower, flower sphere, and flowers sphere all resolve to Flowers. Twin Moons is a legacy / removed display name that resolves to Dual Wielding only for paired-weapon or dual-wielding contexts. If a requested sphere appears unfamiliar, check this catalogue before saying it does not exist.`,
    ``,
    `Generate the full standard package and output clearly labeled file blocks if you cannot create files directly.`,
    ``,
    `Required package:`,
    `- Generation Brief`,
    `- Stat Block`,
    `- Normalized Sheet`,
    `- Normalized Sheet JSON`,
    `- Readable Sheet Source`,
    `- Dao Combat AI behavior card`,
    `- Combat Package`,
    `- Background and Future`,
    `- Canon Manifest`,
    `- Reflection Ledger`,
    `- Tactical Patterns`,
    `- Pre-Simulation Retrieval Template`,
    `- Human Review Checklist`,
    `- Codex Integration Notes`,
    `- Sphere Verification Ledger`,
    `- Cohesive Strategy Ledger`,
    ``,
    `Creative generation rule: if the idea is rough, random, or open-ended, build cohesive novelty by choosing a narrative seed, social role, combat role, path chassis, sphere portfolio, strategic engine, signature pressure, cost or limitation, counterplay, and one rejected obvious choice before writing mechanics.`,
    ``,
    `Safeguards: do not silently upgrade mechanics, do not let tactical lessons become powers, and queue human approval for any sheet or rules change.`,
    ``,
    `Character idea:`,
    idea
  ].join("\n");
}

function buildPreFightPrompt() {
  const a = packageById($("preFightA").value);
  const b = packageById($("preFightB").value);
  const mode = $("preFightMode").value.trim() || "tactical combat simulation";
  const battlefield = $("preFightBattlefield").value.trim() || "battlefield not specified";
  const notes = $("preFightNotes").value.trim() || "No match-specific exceptions supplied.";
  const packets = [a, b].flatMap(relevantPacketsForPackage);
  $("preFightOutput").value = [
    `Use the Tianxia Combat Simulation Sandbox.`,
    ``,
    `Load the v1.1 canon workflow, Sphere Catalogue Lock, character normalizer, general tactical combat script, Rules Arbiter, Dao behavior engine, and auto-load fight simulation script.`,
    `Canonical sphere catalogue (${CANONICAL_SPHERE_NAMES.length}): ${SPHERE_CATALOGUE_TEXT}`,
    ``,
    `## Encounter`,
    `Mode: ${mode}`,
    `Battlefield: ${battlefield}`,
    `Match notes: ${notes}`,
    ``,
    `## Combatants`,
    `### Combatant A`,
    packageSummary(a),
    ``,
    `### Combatant B`,
    packageSummary(b),
    ``,
    `## Pre-Simulation Retrieval Packet`,
    `Retrieve only relevant memories. Do not load every prior encounter.`,
    ``,
    `### Global Rules Lessons`,
    state.globalRules.length ? state.globalRules.map((item) => `- ${item.text}`).join("\n") : "- No saved global rules lessons.",
    ``,
    `### Tactical Patterns`,
    state.tacticalPatterns.length ? state.tacticalPatterns.map((item) => `- ${item.text}`).join("\n") : "- No saved tactical patterns.",
    ``,
    `### Character Dao Packets`,
    packets.length ? packets.map((packet) => `- ${packet.player}: ${packetText(packet)}${packet.notes ? ` | ${packet.notes}` : ""}`).join("\n") : "- No matching Dao packets recorded.",
    ``,
    `### Recent Reflection Notes`,
    state.reflections.length ? state.reflections.slice(0, 5).map((item) => `- ${item.encounterId || "Unnamed encounter"}: ${item.outcome || "outcome unstated"}`).join("\n") : "- No saved reflections.",
    ``,
    `## Required Procedure`,
    `1. Normalize every supplied combatant sheet before initiative.`,
    `2. Build a Sphere Verification Ledger for every combatant before behavior cards.`,
    `3. Build belief states before initiative.`,
    `4. Load only relevant stable doctrines and tactical patterns.`,
    `5. Resolve mechanics completely before narrative.`,
    `6. Freeze transcript before prose.`,
    `7. Produce Systems Audit, Dao Evolution Audit, Post-Fight Reflection Packet, and Human Approval Queue.`,
    `8. Do not change sheets, behavior cards, tactical patterns, or global rules without explicit human approval.`
  ].join("\n");
}

function buildReflectionPrompt() {
  const encounterId = $("reflectionEncounterId").value.trim() || `encounter-${new Date().toISOString().slice(0, 10)}`;
  const outcome = $("reflectionOutcome").value.trim() || "outcome not recorded";
  const notes = $("reflectionNotes").value.trim() || "No transcript pasted.";
  $("reflectionOutput").value = [
    `Create a Tianxia Post-Fight Reflection Packet.`,
    ``,
    `Encounter ID: ${encounterId}`,
    `Outcome: ${outcome}`,
    ``,
    `Use the v1.1 lifecycle-memory rules.`,
    ``,
    `Separate:`,
    `- Global rules lessons`,
    `- Character tactical lessons`,
    `- Dao reflections`,
    `- Tactical pattern candidates`,
    `- Balance flags`,
    `- Script-hardening suggestions`,
    `- Human approval queue`,
    `- Recommended regression tests`,
    ``,
    `Do not promote any lesson into a mechanical upgrade without human approval, sheet revision, normalization, and balance review.`,
    ``,
    `Transcript or notes:`,
    "```text",
    notes,
    "```"
  ].join("\n");
}

function saveReflection() {
  const notes = $("reflectionNotes").value.trim();
  if (!notes) {
    toast("Add reflection notes first.");
    return;
  }
  state.reflections.unshift({
    id: makeId("reflection"),
    created: new Date().toISOString(),
    encounterId: $("reflectionEncounterId").value.trim(),
    outcome: $("reflectionOutcome").value.trim(),
    notes
  });
  saveState();
  renderAutomation();
  toast("Reflection note saved.");
}

function saveGlobalRule() {
  const text = $("globalRuleInput").value.trim();
  if (!text) {
    toast("Add a global rule lesson first.");
    return;
  }
  state.globalRules.unshift({ id: makeId("rule"), created: new Date().toISOString(), text });
  $("globalRuleInput").value = "";
  saveState();
  renderAutomation();
  toast("Global rule lesson saved.");
}

function saveTacticalPattern() {
  const text = $("tacticalPatternInput").value.trim();
  if (!text) {
    toast("Add a tactical pattern first.");
    return;
  }
  state.tacticalPatterns.unshift({ id: makeId("pattern"), created: new Date().toISOString(), text });
  $("tacticalPatternInput").value = "";
  saveState();
  renderAutomation();
  toast("Tactical pattern saved.");
}

function deleteMemoryItem(kind, id) {
  if (kind === "rule") state.globalRules = state.globalRules.filter((item) => item.id !== id);
  if (kind === "pattern") state.tacticalPatterns = state.tacticalPatterns.filter((item) => item.id !== id);
  if (kind === "reflection") state.reflections = state.reflections.filter((item) => item.id !== id);
  saveState();
  renderAutomation();
  toast("Saved item removed.");
}

function renderMemoryList() {
  const rules = state.globalRules.map((item) => `
    <article class="canon-card">
      <header><strong>Global Rule Lesson</strong><button class="ghost-button" type="button" data-delete-rule="${escapeHtml(item.id)}">Remove</button></header>
      <p>${escapeHtml(item.text)}</p>
    </article>
  `).join("");
  const patterns = state.tacticalPatterns.map((item) => `
    <article class="canon-card">
      <header><strong>Tactical Pattern</strong><button class="ghost-button" type="button" data-delete-pattern="${escapeHtml(item.id)}">Remove</button></header>
      <p>${escapeHtml(item.text)}</p>
    </article>
  `).join("");
  $("memoryList").innerHTML = rules || patterns ? `${rules}${patterns}` : `<div class="empty-state">No global memory saved yet.</div>`;
  $("memoryOutput").value = memoryExportText();
  document.querySelectorAll("[data-delete-rule]").forEach((button) => {
    button.addEventListener("click", () => deleteMemoryItem("rule", button.dataset.deleteRule));
  });
  document.querySelectorAll("[data-delete-pattern]").forEach((button) => {
    button.addEventListener("click", () => deleteMemoryItem("pattern", button.dataset.deletePattern));
  });
}

function renderReflectionList() {
  $("reflectionList").innerHTML = state.reflections.length ? state.reflections.slice(0, 8).map((item) => `
    <article class="canon-card">
      <header>
        <strong>${escapeHtml(item.encounterId || "Unnamed encounter")}</strong>
        <button class="ghost-button" type="button" data-delete-reflection="${escapeHtml(item.id)}">Remove</button>
      </header>
      <p>${escapeHtml(item.outcome || "Outcome unstated")}</p>
      <p>${escapeHtml(item.notes.slice(0, 260))}${item.notes.length > 260 ? "..." : ""}</p>
    </article>
  `).join("") : `<div class="empty-state">No saved reflection notes yet.</div>`;
  document.querySelectorAll("[data-delete-reflection]").forEach((button) => {
    button.addEventListener("click", () => deleteMemoryItem("reflection", button.dataset.deleteReflection));
  });
}

function buildRegressionPrompt() {
  const a = packageById($("regressionA").value);
  const b = packageById($("regressionB").value);
  const purpose = $("regressionPurpose").value.trim() || "validate combat-script behavior after a workflow change";
  const seed = $("regressionSeed").value.trim() || `seed-${new Date().toISOString().slice(0, 10)}`;
  const checks = $("regressionChecks").value.trim() || "concentration, action economy, detection grades, created assets, and narrative freeze";
  $("regressionOutput").value = [
    `Create a Tianxia regression combat test.`,
    ``,
    `Test purpose: ${purpose}`,
    `Seed: ${seed}`,
    ``,
    `Combatant A:`,
    packageSummary(a),
    ``,
    `Combatant B:`,
    packageSummary(b),
    ``,
    `Expected rules checks:`,
    checks,
    ``,
    `Run the fight with the full current system. Report:`,
    `- mechanical integrity score`,
    `- tactical quality score`,
    `- character distinctiveness score`,
    `- narrative quality score`,
    `- review burden score`,
    `- validation failures`,
    `- narrative-only failures`,
    `- balance changes`,
    `- whether the result should trigger a workflow or rules patch`
  ].join("\n");
}

function renderAutomation() {
  if (!$("packageCount")) return;
  $("packageCount").textContent = `${state.packages.length} packages`;
  $("memoryCount").textContent = `${state.globalRules.length + state.tacticalPatterns.length + state.reflections.length} memory notes`;
  refreshPackageSelectors();
  renderPackageList();
  renderMemoryList();
  renderReflectionList();
  renderCharacterViewer();
}

function formatRatings(ratings) {
  return Object.entries(ratings || {})
    .map(([key, value]) => `${key}: ${value}`)
    .join("\n");
}

function currentAnalysisMatches(primary, secondary) {
  if (!lastNpcAnalysis) return false;
  if (lastNpcAnalysis.primary.name !== primary.name) return false;
  if ((lastNpcAnalysis.secondary?.name || "") !== (secondary?.name || "")) return false;
  return true;
}

function buildFightPrompt() {
  const primary = profile($("npcPrimary").value);
  const secondaryName = $("npcSecondary").value;
  const secondary = secondaryName ? profile(secondaryName) : null;
  const defaultPosture = trigram($("npcDefaultTrigram").value);
  const stressPosture = trigram($("npcStressTrigram").value);
  const name = $("npcName").value.trim() || `${primary.name} cultivator`;
  const path = $("npcPath").value;
  const realm = $("npcRealm").value.trim() || "appropriate to the encounter";
  const objective = $("npcObjective").value.trim() || "win without betraying their Dao";
  const terrain = $("npcTerrain").value.trim() || "the current battlefield";
  const context = $("npcContext").value.trim() || "No extra context.";
  const analysis = currentAnalysisMatches(primary, secondary) ? lastNpcAnalysis : null;
  const detected = analysis?.detected || [
    { sphere: primary, weight: 6 },
    secondary ? { sphere: secondary, weight: 4 } : null
  ].filter(Boolean);
  const preset = analysis?.preset || derivePreset(path, detected);
  const tags = analysis?.tags || deriveTags(path, detected, $("npcDefaultTrigram").value);
  const doctrine = analysis?.doctrine || doctrineFromAnalysis(primary, secondary, $("npcDefaultTrigram").value, $("npcStressTrigram").value, tags, preset);
  const ratings = analysis?.ratings || RATING_PRESETS[preset];
  const daoPhrase = analysis?.daoPhrase || makeDaoPhrase(primary, secondary);
  const sphereSpread = detected.slice(0, 8).map((item) => `${item.sphere.name} (${item.weight})`).join(", ");
  const tertiary = detected.slice(2, 6).map((item) => item.sphere.name).join(", ") || "none detected";
  const rawStatBlock = analysis?.rawText || $("npcStatBlock").value.trim();

  return [
    `Apply the Tianxia Dao-Expression Combat AI Engine.`,
    `Use this NPC's Dao Combat AI Card as a dynamic behavior script, not a restrictive alignment system.`,
    `Track facts separately from beliefs. Resolve legal mechanics first, then express the Dao through tactics and narration.`,
    `Load the Sphere Catalogue Lock before resolving sphere names. Canonical sphere catalogue (${CANONICAL_SPHERE_NAMES.length}): ${SPHERE_CATALOGUE_TEXT}`,
    `Alias lock: Flower, flower sphere, and flowers sphere resolve to Flowers. Twin Moons is legacy / removed and resolves to Dual Wielding only for paired-weapon contexts. Do not treat a listed canonical sphere as nonexistent.`,
    ``,
    `## Dao Combat AI Card`,
    ``,
    `NPC: ${name}`,
    `Realm or threat: ${realm}`,
    `Path: ${path}`,
    analysis?.subpath ? `Subpath: ${analysis.subpath}` : null,
    analysis?.role ? `Role: ${analysis.role}` : `Role: inferred from the stat block and objective`,
    analysis?.range ? `Preferred range: ${analysis.range}` : `Preferred range: choose from legal options in the stat block`,
    `Objective: ${objective}`,
    `Terrain or scene: ${terrain}`,
    ``,
    `Primary spheres: ${primary.name}`,
    `Secondary spheres: ${secondary ? secondary.name : "none"}`,
    `Tertiary or accent spheres: ${tertiary}`,
    `Detected sphere spread: ${sphereSpread}`,
    `Primary sphere truth: ${primary.read}`,
    secondary ? `Secondary sphere truth: ${secondary.read}` : null,
    `Relevant insights: ${analysis?.insights || "use any listed insights in the stat block"}`,
    `Relevant techniques: ${analysis?.techniques || "use only legal listed techniques, actions, and features"}`,
    ``,
    `Emerging Dao phrase: ${daoPhrase}`,
    `Core motifs: ${primary.verbs.join(", ")}${secondary ? `, colored by ${secondary.verbs.slice(0, 3).join(", ")}` : ""}`,
    `Repeated Dao verbs: ${primary.verbs.concat(secondary?.verbs || []).slice(0, 8).join(", ")}`,
    `Recurring cost: expose, spend, risk, or delay whatever this Dao demands rather than choosing generic efficiency every turn.`,
    `Unresolved shadow: ${primary.shadow.join(", ")}`,
    `Battlefield truth they notice first: ${primary.read}`,
    `Battlefield truth they often overlook: ${stressPosture.failure}`,
    `What they believe combat fundamentally is: ${daoPhrase}`,
    ``,
    `Ratings preset: ${preset}`,
    formatRatings(ratings),
    ``,
    `Tags: ${tags.join(", ")}`,
    ``,
    `Default Trigram Posture: ${defaultPosture.label} - ${defaultPosture.keys}`,
    `Stress Trigram: ${stressPosture.label} - ${stressPosture.keys}`,
    `Shadow Trigger: ${primary.shadow.join(", ")}`,
    `Context: ${context}`,
    ``,
    `## Tactical Doctrine`,
    ``,
    `Opening Doctrine: ${doctrine.opening}`,
    `Target Doctrine: ${doctrine.target}`,
    `Resource-Reveal Doctrine: ${doctrine.resourceReveal}`,
    `Reaction Doctrine: ${doctrine.reaction}`,
    `Learning Doctrine: ${doctrine.learning}`,
    `Rescue Doctrine: ${doctrine.rescue}`,
    `Retreat Doctrine: ${doctrine.retreat}`,
    `Stress Behavior: ${doctrine.stress}`,
    `Emotional Failure Mode: ${doctrine.failure}`,
    `Anti-Pattern: ${doctrine.antiPattern}`,
    `Signature Tactical Question: ${doctrine.question}`,
    ``,
    `## Round-by-Round Use`,
    ``,
    `For each notable turn:`,
    `1. Identify the current objective.`,
    `2. Identify the obstacle.`,
    `3. Generate legal actions from the stat block.`,
    `4. Weight those actions through sphere spread, tags, posture, beliefs, objective, and action economy.`,
    `5. Choose the strongest character-faithful action, not the most generic damage line.`,
    `6. Briefly state objective, obstacle, observed information, Dao-salient pattern, chosen action, rejected alternatives, and reason.`,
    ``,
    `Rules Arbiter pass before narration:`,
    `- Validate action type, cost, prerequisites, range, line geometry, targeting information grade, movement origin and destination, landing square, reaction windows, concentration changes, dependent assets, damage instances, conditions, expiry timing, and state transition.`,
    `- Stunned does not automatically end concentration unless the system or technique also applies Incapacitated or another explicit concentration-ending rule.`,
    `- Off-Beat applies after the triggering technique fully resolves; the creating technique cannot also exploit it.`,
    `- Speed 0 stops ordinary movement, not teleportation, unless the effect explicitly says otherwise.`,
    `- Dark, Smoke, Illusion, invisibility, and concealment are not automatic Hidden status. Use information grades: unknown, broad region, inferred lane, probable square, exact square, fully perceived.`,
    `- Ambush, assassination, and unseen-entry riders fail inside a valid exact-perception sense such as Spiritual Sense unless a stronger effect bypasses that sense.`,
    `- Every created anchor, door, fragment, puppet, summon, or formation node needs position, visibility, AC, HP, detection methods, legal interactions, and collapse rule.`,
    ``,
    `Make every important NPC turn answer: "How would ${primary.name} under ${defaultPosture.label} try to fulfill ${objective} in ${terrain}?"`,
    `When pressured, reassess through ${stressPosture.label} without giving the NPC knowledge they did not earn.`,
    `Do not prescribe one correct player answer. Let the NPC create pressure. Let the players reveal their own Dao by how they survive it.`,
    rawStatBlock ? `` : null,
    rawStatBlock ? `## Original Stat Block for Legal Mechanics` : null,
    rawStatBlock ? "```text" : null,
    rawStatBlock || null,
    rawStatBlock ? "```" : null
  ].filter(Boolean).join("\n");
}

function buildEncounterPrompt() {
  const outer = trigram($("encounterOuter").value);
  const inner = trigram($("encounterInner").value);
  const sphere = profile($("encounterSphere").value);
  const type = $("encounterType").value.trim() || "meaningful encounter";
  const location = $("encounterLocation").value.trim() || "a place already established in the campaign";
  const pressure = $("encounterPressure").value.trim() || "the party must act before the situation worsens";
  return [
    `Design a Dao-shaped ${type}.`,
    ``,
    `Outer trigram: ${outer.label} - ${outer.keys}`,
    `Inner trigram: ${inner.label} - ${inner.keys}`,
    `Pressure sphere: ${sphere.name}`,
    `Sphere truth: ${sphere.read}`,
    `Location: ${location}`,
    `Party pressure: ${pressure}`,
    ``,
    `The encounter is not a puzzle with one intended key. It is a configuration of change.`,
    ``,
    `Provide:`,
    `1. Visible situation that players understand quickly.`,
    `2. Hidden question created by ${inner.label}.`,
    `3. Pressure clock that worsens if no one acts.`,
    `4. Cost gate: what any meaningful answer risks or spends.`,
    `5. Three obvious approaches that different cultivators could attempt.`,
    `6. Three hidden approaches revealed by attention, creativity, or Dao resonance.`,
    `7. Shadow temptation using ${sphere.shadow.join(", ")}.`,
    `8. Opportunity door if someone answers with meaningful insight.`,
    `9. Failure branch that changes the campaign without ending it.`,
    ``,
    `Tone: The players do not need to know the Dao engine is running. They should simply feel that the world is responding with strange precision.`
  ].join("\n");
}

function generateFightPrompt() {
  $("fightPromptOutput").value = buildFightPrompt();
}

function generateEncounterPrompt() {
  $("encounterPromptOutput").value = buildEncounterPrompt();
}

function randomizeNpc() {
  lastNpcAnalysis = null;
  const creativityMode = randomItem(CREATIVITY_MODES);
  const primaryPool = Math.random() < 0.35
    ? SPHERES.filter((sphere) => UNDERUSED_SPHERE_NAMES.includes(sphere.name))
    : SPHERES;
  const primary = randomItem(primaryPool);
  const compatible = SPHERES.filter((sphere) => {
    if (sphere.name === primary.name) return false;
    const sharedNatural = sphere.natural.some((key) => primary.natural.includes(key));
    const sharedTesting = sphere.testing.some((key) => primary.testing.includes(key));
    return sharedNatural || sharedTesting || sphere.path === primary.path;
  });
  const secondary = randomItem(compatible.length ? compatible : SPHERES.filter((sphere) => sphere.name !== primary.name));
  const accent = randomItem(SPHERES.filter((sphere) => ![primary.name, secondary.name].includes(sphere.name)));
  const strategy = randomItem(STRATEGY_FAMILIES);
  const limitation = randomItem(NPC_LIMITATIONS);
  $("npcPrimary").value = primary.name;
  $("npcSecondary").value = secondary.name;
  $("npcDefaultTrigram").value = randomItem(primary.natural);
  $("npcStressTrigram").value = randomItem(primary.testing);
  $("npcName").value = `${primary.name} ${randomItem(["outer disciple", "wandering rival", "sect examiner", "hidden inheritor", "rogue cultivator", "arena specialist", "strange protector"])}`;
  $("npcRealm").value = randomItem(["CL 2 pressure test", "CL 5 dangerous rival", "Foundation elder", "injured but skilled cultivator", "low-realm prodigy"]);
  $("npcObjective").value = randomItem(["test the party's response", "delay the party without killing them", "defend a secret route", "recover a stolen manual", "force one character to reveal a pattern", "protect a dependent mortal or spirit object", "win the crowd without revealing the whole method"]);
  $("npcTerrain").value = randomItem(["flooded bridge", "broken courtyard", "misty archive", "banquet hall", "outer sect training field", "storm-cut mountain road"]);
  $("npcContext").value = [
    `Creativity mode: ${creativityMode}.`,
    `Strategy family: ${strategy}.`,
    `Sphere portfolio: primary ${primary.name}, secondary ${secondary.name}, accent ${accent.name}.`,
    `Accent truth: ${accent.read}`,
    `Cost or limitation: ${limitation}.`,
    `Rejected obvious choice: choose one tempting stronger sphere or tactic and explain why this NPC does not rely on it.`,
    `Build cohesive novelty: every sphere should support the same person, pressure, flaw, and counterplay.`
  ].join(" ");
  $("statBlockAnalysis").textContent = "Random NPC generated. Paste a stat block to run automated analysis.";
  generateFightPrompt();
}

function renderLibrary() {
  const query = $("sphereSearch")?.value.trim().toLowerCase() || "";
  const spheres = SPHERES.filter((sphere) => {
    const haystack = [sphere.name, sphere.path, sphere.read, ...sphere.verbs, ...sphere.natural, ...sphere.testing, ...sphere.shadow].join(" ").toLowerCase();
    return haystack.includes(query);
  });
  if ($("sphereLibrary")) $("sphereLibrary").innerHTML = spheres.map((sphere) => `
    <article class="library-card">
      <h3>${escapeHtml(sphere.name)}</h3>
      <p><strong>Path:</strong> ${escapeHtml(sphere.path)}</p>
      <p><strong>Natural:</strong> ${escapeHtml(sphere.natural.map((key) => TRIGRAMS[key]?.label || key).join(", "))}</p>
      <p><strong>Testing:</strong> ${escapeHtml(sphere.testing.map((key) => TRIGRAMS[key]?.label || key).join(", "))}</p>
      <p><strong>Shadow:</strong> ${escapeHtml(sphere.shadow.join(", "))}</p>
      <p><strong>Verbs:</strong> ${escapeHtml(sphere.verbs.join(", "))}</p>
      <p>${escapeHtml(sphere.read)}</p>
    </article>
  `).join("");
  if ($("trigramLibrary")) $("trigramLibrary").innerHTML = trigramKeys.map((key) => {
    const item = TRIGRAMS[key];
    return `
      <article class="library-card">
        <h3>${escapeHtml(item.label)}</h3>
        <p><strong>Pressure:</strong> ${escapeHtml(item.keys)}</p>
        <p><strong>Hidden question:</strong> ${escapeHtml(item.question)}</p>
        <p><strong>Failure mode:</strong> ${escapeHtml(item.failure)}</p>
      </article>
    `;
  }).join("");
  if ($("foundationLibrary")) {
    const foundationQuery = $("foundationSearch")?.value.trim().toLowerCase() || "";
    const foundations = FOUNDATION_CATALOG.filter((item) => {
      const haystack = [
        item.name,
        item.id,
        Array.isArray(item.family) ? item.family.join(" ") : item.family,
        item.depth,
        item.stage,
        item.primary_path,
        item.secondary_path_fit,
        item.dao_principle,
        foundationKnownValue(item, "summary"),
        foundationKnownValue(item, "benefit"),
        foundationKnownValue(item, "warning"),
        item.sphere_interfaces?.compatible_spheres?.join(" "),
        item.sphere_interfaces?.conditional_spheres_unlocked?.join(" "),
        item.burdens?.map((burden) => [burden.name, burden.trigger, burden.default_effect].filter(Boolean).join(" ")).join(" ")
      ].filter(Boolean).join(" ").toLowerCase();
      return haystack.includes(foundationQuery);
    });
    $("foundationLibrary").innerHTML = foundations.length
      ? foundations.map(foundationLibraryCard).join("")
      : `<div class="empty-state">No foundations match this search.</div>`;
  }
}

function setActiveTab(name) {
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === name);
  });
  document.querySelectorAll(".tab-panel").forEach((panel) => {
    panel.classList.toggle("active", panel.id === name);
  });
}

function copyViaHiddenTextarea(text) {
  const helper = document.createElement("textarea");
  helper.value = text;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.left = "-9999px";
  helper.style.top = "0";
  document.body.appendChild(helper);
  helper.focus();
  helper.select();
  helper.setSelectionRange(0, helper.value.length);
  let copied = false;
  try {
    copied = document.execCommand("copy");
  } catch {
    copied = false;
  }
  helper.remove();
  return copied;
}

async function copyText(text) {
  const value = String(text || "");
  if (!value.trim()) {
    toast("Nothing to copy yet.");
    return;
  }
  let copied = false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      copied = true;
    }
  } catch {
    copied = false;
  }
  if (!copied) {
    copied = copyViaHiddenTextarea(value);
  }
  if (copied) {
    toast("Copied.");
  } else {
    toast("Copy failed. Select the text box and copy manually.");
  }
}

function toast(message) {
  const box = $("toast");
  box.textContent = message;
  box.classList.add("visible");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => box.classList.remove("visible"), 1800);
}


function tribulationState() {
  if (!Array.isArray(state.tribulations)) state.tribulations = [];
  return state.tribulations;
}

function tribSafeArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter(Boolean);
  if (typeof value === "object") return Object.values(value).filter(Boolean);
  return [value];
}

function tribText(value, fallback = "") {
  if (value === null || value === undefined) return fallback;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value).trim() || fallback;
  if (Array.isArray(value)) return value.map((item) => tribText(item)).filter(Boolean).join("; ") || fallback;
  if (typeof value === "object") {
    return value.text || value.summary || value.description || value.name || value.id || JSON.stringify(value);
  }
  return fallback;
}

function tribPrimaryFoundation(pkg) {
  const sheet = pkg?.sheetData || {};
  const foundations = tribSafeArray(sheet.foundations || sheet.foundation || pkg?.foundations || pkg?.foundation).filter(Boolean);
  return foundations[0] || {};
}

function tribFoundationLines(foundation = {}, keyNames = []) {
  const lines = [];
  keyNames.forEach((key) => {
    tribSafeArray(foundation[key]).forEach((item) => {
      const text = tribText(item).replace(/\s+/g, " ").trim();
      if (text && !lines.includes(text)) lines.push(text);
    });
  });
  return lines.slice(0, 8);
}

function tribSpheres(pkg) {
  const sheet = pkg?.sheetData || {};
  const fromSheet = tribSafeArray(sheet.spheres || sheet.legal_spheres || sheet.sphere_list)
    .map((item) => tribText(item.name || item.sphere || item))
    .filter(Boolean);
  const extra = [pkg?.primary, pkg?.secondary, sheet.primary_sphere, sheet.secondary_sphere].map((item) => tribText(item)).filter(Boolean);
  return [...new Set(fromSheet.concat(extra))].filter(Boolean).slice(0, 10);
}

function tribRecentPacketLines(pkg) {
  if (!pkg || typeof relevantPacketsForPackage !== "function") return [];
  return relevantPacketsForPackage(pkg).slice(0, 4).map((packet) => packetText(packet));
}

function tribPackageProfile(pkg) {
  const sheet = pkg?.sheetData || {};
  const foundation = tribPrimaryFoundation(pkg);
  const dao = sheet.dao || sheet.dao_phrase || pkg?.daoPhrase || foundation.dao_principle || foundation.doctrine || "No Dao phrase imported.";
  const path = pkg?.path || sheet.path || sheet.cultivation_path || "Unknown Path";
  const realm = pkg?.realm || sheet.realm || sheet.cultivation_realm || "Unknown Realm";
  const resources = tribSafeArray(sheet.resources || sheet.resource_registry || sheet.counters)
    .map((item) => tribText(item.name || item.resource || item.counter_id || item.id || item))
    .filter(Boolean)
    .slice(0, 6);
  return {
    name: pkg?.name || sheet.name || "No character selected",
    path,
    realm,
    dao: tribText(dao, "No Dao phrase imported."),
    foundation,
    foundationName: foundationDisplayName(foundation || {}),
    foundationDoctrine: foundationDoctrine(foundation || {}),
    foundationBenefits: foundationBenefits(foundation || {}).slice(0, 6),
    foundationBurdens: foundationBurdens(foundation || {}).slice(0, 6),
    foundationTriggers: foundationTriggers(foundation || {}).slice(0, 6),
    foundationCounters: foundationCounters(foundation || {}).slice(0, 6),
    spheres: tribSpheres(pkg),
    resources,
    recentPackets: tribRecentPacketLines(pkg)
  };
}

function tribPathMode(path = "") {
  const value = String(path).toLowerCase();
  if (value.includes("body")) {
    return {
      mode: "Body Refining",
      test: "marrow, organs, bones, breath, scar tissue, and refusal to fall",
      injury: "Hidden Injury, organ furnace strain, cracked bone-script, or overdrawn stamina guard",
      answer: "endure honestly, repair the body, or convert pain into a bounded form"
    };
  }
  if (value.includes("spirit")) {
    return {
      mode: "Spirit Awakening",
      test: "soul-image, companion bond, memory, oath, dream, and identity boundary",
      injury: "Soul scar, companion backlash, dream contamination, or resonance fracture",
      answer: "name the self, reconcile the bond, and choose what memory becomes power"
    };
  }
  if (value.includes("chakra")) {
    return {
      mode: "Chakra",
      test: "Open Wheel routing, vessel saturation, vital rhythm, and embodied overload",
      injury: "Vital Imbalance, Blocked Wheel Strain, Hollow Stain, or burst-channel scar",
      answer: "re-route the wheel, ground the vessel, and accept that output must have shape"
    };
  }
  return {
    mode: "Qi Cultivation",
    test: "meridians, qi sea, source-text accuracy, intent, and Dao-shaped circulation",
    injury: "Meridian burn, qi-sea turbulence, hollow channel, or distorted technique imprint",
    answer: "circulate cleanly, refine the intent, and pay the cost without widening the deviation"
  };
}

function tribIntensityProfile(value = "standard") {
  const map = {
    minor: { label: "Minor", dc: 14, dice: "1d4", consequence: "omen, mark, light strain, small repair route" },
    standard: { label: "Standard", dc: 17, dice: "1d6", consequence: "visible tribulation, one tracked strain or injury hook" },
    major: { label: "Major", dc: 20, dice: "1d8", consequence: "serious trial, major counter, temporary locked benefit or burden" },
    severe: { label: "Severe", dc: 23, dice: "1d10", consequence: "dangerous deviation or hidden injury unless answered cleanly" },
    mythic: { label: "Mythic / Realm-Edge", dc: 26, dice: "1d12", consequence: "realm-scale omen, permanent scar route, or breakthrough-defining choice" }
  };
  return map[value] || map.standard;
}

function tribTypeLabel(value = "breakthrough") {
  const map = {
    breakthrough: "Breakthrough Tribulation",
    heavenly_warning: "Heavenly Warning / Omen",
    hidden_injury: "Hidden Injury Emerges",
    deviation: "Cultivation Deviation",
    strain: "Strain / Overuse Consequence",
    forbidden: "Forbidden Temptation",
    foundation_trial: "Foundation Trial"
  };
  return map[value] || titleCase(value);
}

function tribSuggestedTitle(profile, type, outer, inner) {
  const f = profile.foundationName && profile.foundationName !== "Foundation" ? profile.foundationName : profile.path;
  const core = {
    breakthrough: "Heaven Tests the Root",
    heavenly_warning: "Omen Before the Gate",
    hidden_injury: "Old Wound Demands Its Name",
    deviation: "Wrong Growth Finds a Shape",
    strain: "Debt of Overdrawn Power",
    forbidden: "The Door That Should Not Open",
    foundation_trial: "Foundation Answers Back"
  }[type] || "Tribulation";
  return `${core}: ${f} under ${TRIGRAMS[outer]?.label || outer} / ${TRIGRAMS[inner]?.label || inner}`;
}

function tribRoll() {
  return Math.floor(Math.random() * 20) + 1;
}

function tribOutcome(roll, dc) {
  if (roll >= dc + 5) return "Clean answer: gain a clear boon, insight candidate, or reduced recovery cost.";
  if (roll >= dc) return "Pass with price: resolve the immediate pressure but record a strain, omen, or duty.";
  if (roll >= dc - 4) return "Failure-forward: gain Failure Enlightenment and record a repair route, hidden injury, or deviation seed.";
  return "Hard backlash: the trial becomes a major injury/deviation unless someone intervenes or a cost is paid now.";
}

function tribReadHtml(profile) {
  if (!profile || profile.name === "No character selected") return `<div class="empty-state">Choose a character to see path, Dao, foundation, and recent pressure.</div>`;
  return `
    <article class="trib-read-card">
      <header><h3>${escapeHtml(profile.name)}</h3><span>${escapeHtml(profile.realm)}</span></header>
      <div class="trib-chip-row"><span>${escapeHtml(profile.path)}</span>${profile.spheres.slice(0, 5).map((s) => `<span>${escapeHtml(s)}</span>`).join("")}</div>
      <p><strong>Dao:</strong> ${escapeHtml(truncateValue(profile.dao, 240))}</p>
      <p><strong>Foundation:</strong> ${escapeHtml(profile.foundationName)}${profile.foundationDoctrine ? ` — ${escapeHtml(truncateValue(profile.foundationDoctrine, 220))}` : ""}</p>
      ${profile.foundationBurdens.length ? `<p><strong>Likely burden:</strong> ${escapeHtml(profile.foundationBurdens[0])}</p>` : ""}
      ${profile.recentPackets.length ? `<p><strong>Recent Dao pressure:</strong> ${escapeHtml(profile.recentPackets[0])}</p>` : ""}
    </article>`;
}

function tribPacketFromFields(saveToState = false) {
  const pkg = packageById($("tribCharacterSelect")?.value || $("activeCharacterSelect")?.value || "");
  const profileData = tribPackageProfile(pkg);
  const type = $("tribType")?.value || "breakthrough";
  const intensity = tribIntensityProfile($("tribIntensity")?.value || "standard");
  const outer = $("tribOuter")?.value || "Zhen";
  const inner = $("tribInner")?.value || "Kan";
  const answer = $("tribAnswer")?.value || "Gen";
  const pressure = $("tribPressure")?.value.trim() || "No scene pressure entered; infer from package state, Dao, and Foundation.";
  const manualNotes = $("tribManualNotes")?.value.trim();
  const pathMode = tribPathMode(profileData.path);
  const roll = tribRoll();
  const dc = intensity.dc;
  const title = tribSuggestedTitle(profileData, type, outer, inner);
  const burden = profileData.foundationBurdens[0] || pathMode.injury;
  const trigger = profileData.foundationTriggers[0] || pressure;
  const counter = profileData.foundationCounters[0] || "Create a repair route: medicine, meditation, confession, ritual correction, teacher intervention, sacrifice, or changed practice.";
  const issueType = type === "hidden_injury" ? "Hidden Injury" : type === "deviation" ? "Deviation Seed" : type === "strain" ? "Strain" : type === "forbidden" ? "Forbidden Temptation" : "Tribulation Mark";
  const packet = {
    id: makeId("trib"),
    timestamp: Date.now(),
    characterId: pkg?.id || "",
    character: profileData.name,
    title,
    type,
    typeLabel: tribTypeLabel(type),
    intensity: intensity.label,
    roll,
    dc,
    outcome: tribOutcome(roll, dc),
    outer,
    inner,
    answer,
    pressure,
    manualNotes,
    pathMode,
    dao: profileData.dao,
    foundation: profileData.foundationName,
    foundationDoctrine: profileData.foundationDoctrine,
    likelyIssue: issueType,
    burden,
    trigger,
    counter,
    spheres: profileData.spheres.slice(0, 8),
    recentPackets: profileData.recentPackets.slice(0, 4)
  };
  if (saveToState) {
    tribulationState().unshift(packet);
    saveState();
  }
  return packet;
}

function tribPacketText(packet) {
  if (!packet) return "";
  return [
    `# ${packet.title}`,
    `Character: ${packet.character}`,
    `Type: ${packet.typeLabel}`,
    `Intensity: ${packet.intensity}`,
    `Roll: d20 ${packet.roll} vs DC ${packet.dc}`,
    `Outcome: ${packet.outcome}`,
    "",
    `## I Ching / Dao Layer`,
    `Outer: ${TRIGRAMS[packet.outer]?.label || packet.outer} — ${(TRIGRAMS[packet.outer]?.keys || "")}`,
    `Inner: ${TRIGRAMS[packet.inner]?.label || packet.inner} — ${(TRIGRAMS[packet.inner]?.keys || "")}`,
    `Answer: ${TRIGRAMS[packet.answer]?.label || packet.answer} — ${(TRIGRAMS[packet.answer]?.question || "")}`,
    "",
    `## Character Reading`,
    `Path test: ${packet.pathMode.mode} — ${packet.pathMode.test}`,
    `Dao: ${packet.dao}`,
    `Foundation: ${packet.foundation}`,
    packet.foundationDoctrine ? `Foundation doctrine: ${packet.foundationDoctrine}` : null,
    packet.spheres.length ? `Relevant spheres/routes: ${packet.spheres.join(", ")}` : null,
    "",
    `## Trigger`,
    packet.pressure,
    packet.manualNotes ? `GM note: ${packet.manualNotes}` : null,
    "",
    `## Mechanical Consequence Hook`,
    `Record as: ${packet.likelyIssue}`,
    `Burden / fault line: ${packet.burden}`,
    `Trigger to watch: ${packet.trigger}`,
    `Counter / repair route: ${packet.counter}`,
    "",
    `## Recent Dao Packets`,
    packet.recentPackets.length ? packet.recentPackets.map((line) => `- ${line}`).join("\n") : "- None recorded.",
    "",
    `Use this as a table-facing tribulation packet. Do not rewrite package mechanics unless the human explicitly approves a patch.`
  ].filter(Boolean).join("\n");
}


function tribTitleHtml(title = "") {
  const safe = String(title || "Tribulation");
  const parts = safe.split(":");
  if (parts.length > 1) {
    const main = parts.shift().trim();
    const detail = parts.join(":").trim();
    return `<span class="trib-title-main">${escapeHtml(main)}</span><span class="trib-title-detail">${escapeHtml(detail)}</span>`;
  }
  return `<span class="trib-title-main">${escapeHtml(safe)}</span>`;
}

function tribOutputHtml(packet) {
  if (!packet) return `<div class="empty-state">Click Roll Tribulation to generate a structured consequence.</div>`;
  return `
    <article class="trib-card">
      <header>
        <div class="trib-title-block"><p class="eyebrow">${escapeHtml(packet.typeLabel)} · ${escapeHtml(packet.intensity)}</p><h3 class="trib-title">${tribTitleHtml(packet.title)}</h3></div>
        <div class="trib-roll-badge"><span>Check</span><strong>${escapeHtml(String(packet.roll))} vs DC ${escapeHtml(String(packet.dc))}</strong><small>d20 tribulation roll</small></div>
      </header>
      <p class="trib-outcome">${escapeHtml(packet.outcome)}</p>
      <div class="trib-i-ching-grid">
        <article><strong>Outer</strong><span>${escapeHtml(TRIGRAMS[packet.outer]?.label || packet.outer)}</span><p>${escapeHtml(TRIGRAMS[packet.outer]?.keys || "")}</p></article>
        <article><strong>Inner</strong><span>${escapeHtml(TRIGRAMS[packet.inner]?.label || packet.inner)}</span><p>${escapeHtml(TRIGRAMS[packet.inner]?.keys || "")}</p></article>
        <article><strong>Answer</strong><span>${escapeHtml(TRIGRAMS[packet.answer]?.label || packet.answer)}</span><p>${escapeHtml(TRIGRAMS[packet.answer]?.question || "")}</p></article>
      </div>
      <div class="trib-hook-grid">
        <section><h4>Character Reading</h4><p><strong>${escapeHtml(packet.pathMode.mode)}:</strong> ${escapeHtml(packet.pathMode.test)}</p><p><strong>Dao:</strong> ${escapeHtml(truncateValue(packet.dao, 260))}</p><p><strong>Foundation:</strong> ${escapeHtml(packet.foundation)}</p></section>
        <section><h4>Consequence Hook</h4><p><strong>Record as:</strong> ${escapeHtml(packet.likelyIssue)}</p><p><strong>Fault line:</strong> ${escapeHtml(packet.burden)}</p><p><strong>Counter:</strong> ${escapeHtml(packet.counter)}</p></section>
      </div>
    </article>`;
}

let lastTribulationPacket = null;

function renderTribulations() {
  if (!$("tribCharacterSelect")) return;
  const selected = $("tribCharacterSelect").value || $("activeCharacterSelect")?.value || "";
  if (selected && state.packages.some((pkg) => pkg.id === selected)) {
    $("tribCharacterSelect").value = selected;
  }
  const pkg = packageById($("tribCharacterSelect").value);
  const profileData = tribPackageProfile(pkg);
  if ($("tribCharacterRead")) $("tribCharacterRead").innerHTML = tribReadHtml(profileData);
  if ($("tribTrackerList")) renderTribulationTrackerList();
}

function generateTribulationPacket() {
  const packet = tribPacketFromFields(false);
  lastTribulationPacket = packet;
  if ($("tribOutput")) $("tribOutput").value = tribPacketText(packet);
  if ($("tribOutputCard")) $("tribOutputCard").innerHTML = tribOutputHtml(packet);
  if ($("tribRollSummary")) $("tribRollSummary").textContent = `${packet.roll} vs DC ${packet.dc}`;
  toast("Tribulation generated.");
}

function saveGeneratedTribulation() {
  if (!lastTribulationPacket) lastTribulationPacket = tribPacketFromFields(false);
  tribulationState().unshift({ ...lastTribulationPacket, id: makeId("trib"), saved: true, timestamp: Date.now() });
  saveState();
  renderTribulations();
  toast("Tribulation saved to log.");
}

function addTribulationTrackerEntry() {
  const entry = {
    id: makeId("tribtrack"),
    timestamp: Date.now(),
    characterId: $("tribTrackCharacter")?.value || $("tribCharacterSelect")?.value || "",
    character: packageById($("tribTrackCharacter")?.value || $("tribCharacterSelect")?.value || "")?.name || "Unassigned",
    kind: $("tribTrackType")?.value || "Strain",
    name: $("tribTrackName")?.value.trim() || "Unnamed consequence",
    severity: $("tribTrackSeverity")?.value.trim() || "active",
    notes: $("tribTrackNotes")?.value.trim() || "No notes. Add trigger, effect, worsening condition, and repair route."
  };
  tribulationState().unshift(entry);
  ["tribTrackName", "tribTrackSeverity", "tribTrackNotes"].forEach((id) => { if ($(id)) $(id).value = ""; });
  saveState();
  renderTribulations();
  toast("Tracker entry added.");
}

function deleteTribulationEntry(id) {
  state.tribulations = tribulationState().filter((item) => item.id !== id);
  saveState();
  renderTribulations();
}

function renderTribulationTrackerList() {
  const items = tribulationState().slice(0, 40);
  if (!items.length) {
    $("tribTrackerList").innerHTML = `<div class="empty-state">No injuries, strains, deviations, or saved tribulations yet.</div>`;
    return;
  }
  $("tribTrackerList").innerHTML = items.map((item) => `
    <article class="trib-tracker-card">
      <header><div><strong>${escapeHtml(item.name || item.title || "Tribulation")}</strong><span>${escapeHtml(item.character || "Unassigned")}</span></div><button class="ghost-button compact" type="button" data-delete-trib="${escapeHtml(item.id)}">Remove</button></header>
      <div class="trib-chip-row"><span>${escapeHtml(item.kind || item.typeLabel || "Tribulation")}</span><span>${escapeHtml(item.severity || item.intensity || "active")}</span></div>
      <p>${escapeHtml(truncateValue(item.notes || item.outcome || item.burden || "", 360))}</p>
    </article>
  `).join("");
  document.querySelectorAll("[data-delete-trib]").forEach((button) => button.addEventListener("click", () => deleteTribulationEntry(button.dataset.deleteTrib)));
}

function renderAll() {
  updatePlayerControls();
  renderGate();
  renderPacketLog();
  renderPatterns();
  renderLibrary();
  renderAutomation();
  renderCharacterViewer();
  renderTribulations();
  updateBuilderPreview();
  updatePacketPreview();
}

function attachEvents() {
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.addEventListener("click", () => setActiveTab(button.dataset.tab));
  });
  ["gateSceneTitle", "gateLocation", "gateWorldTime", "gateSceneText", "gateChoicesInput", "gateSectNotes", "gateActionInput"].forEach((id) => {
    if (!$(id)) return;
    $(id).addEventListener("input", () => {
      gateSyncFromInputs();
      if ($("gateAiPacketOutput")) $("gateAiPacketOutput").value = gateStatePacket();
    });
  });
  if ($("gateCharacterSelect")) {
    $("gateCharacterSelect").addEventListener("change", () => {
      gateSyncFromInputs();
      saveState();
      renderGate();
    });
  }
  if ($("gateSaveSceneButton")) $("gateSaveSceneButton").addEventListener("click", saveGateScene);
  if ($("gateCommitActionButton")) $("gateCommitActionButton").addEventListener("click", commitGateAction);
  if ($("gateCopyAiPacketButton")) $("gateCopyAiPacketButton").addEventListener("click", () => copyText(gateStatePacket()));
  if ($("gateCopyStateButton")) $("gateCopyStateButton").addEventListener("click", () => copyText(JSON.stringify(gateState(), null, 2)));
  if ($("gateImportAiButton")) $("gateImportAiButton").addEventListener("click", importGateAiResponse);
  if ($("gateAddQuestButton")) $("gateAddQuestButton").addEventListener("click", addGateQuest);
  if ($("gateAddPinnedButton")) $("gateAddPinnedButton").addEventListener("click", addGatePinnedPerson);
  ["packetOuter", "packetInner", "packetSphere", "packetAnswer", "packetVerb", "packetLine", "packetCost", "packetShadow", "packetNotes"].forEach((id) => {
    $(id).addEventListener("input", updatePacketPreview);
    $(id).addEventListener("change", updatePacketPreview);
  });
  $("recordPacketButton").addEventListener("click", recordPacket);
  $("clearPacketButton").addEventListener("click", clearPacketFields);
  $("copyPacketButton").addEventListener("click", () => copyText(packetText(readPacketFields())));
  $("clearAllButton").addEventListener("click", () => {
    if (confirm("Clear all saved Dao dashboard data on this browser?")) {
      state.packets = [];
      state.packages = [];
      state.characterNotes = {};
      state.campaign = defaultCampaignState();
      state.globalRules = [];
      state.tacticalPatterns = [];
      state.reflections = [];
      state.tribulations = [];
      saveState();
      renderAll();
      toast("Campaign data cleared.");
    }
  });
  $("patternPlayer").addEventListener("change", renderPatterns);
  $("activeCharacterSelect").addEventListener("change", renderCharacterViewer);
  if ($("tribCharacterSelect")) $("tribCharacterSelect").addEventListener("change", renderTribulations);
  if ($("tribTrackCharacter")) $("tribTrackCharacter").addEventListener("change", renderTribulations);
  ["tribType", "tribIntensity", "tribOuter", "tribInner", "tribAnswer", "tribPressure", "tribManualNotes"].forEach((id) => {
    if (!$(id)) return;
    $(id).addEventListener("input", renderTribulations);
    $(id).addEventListener("change", renderTribulations);
  });
  if ($("tribRollButton")) $("tribRollButton").addEventListener("click", generateTribulationPacket);
  if ($("tribCopyButton")) $("tribCopyButton").addEventListener("click", () => {
    if (!$("tribOutput")?.value?.trim()) generateTribulationPacket();
    copyText($("tribOutput")?.value || "");
  });
  if ($("tribSaveButton")) $("tribSaveButton").addEventListener("click", saveGeneratedTribulation);
  if ($("tribAddTrackButton")) $("tribAddTrackButton").addEventListener("click", addTribulationTrackerEntry);
  $("buildActiveCharacterButton").addEventListener("click", renderCharacterViewer);
  $("copyActiveCharacterButton").addEventListener("click", () => copyText(activeCharacterPacketText()));
  $("copyActivePromptButton").addEventListener("click", () => {
    if (!$("activeCharacterPrompt").value.trim()) renderCharacterViewer();
    copyText($("activeCharacterPrompt").value);
  });
  if ($("copyCombatExportButton")) $("copyCombatExportButton").addEventListener("click", () => copyText(activeCharacterCombatExportText()));
  if ($("downloadCombatExportButton")) $("downloadCombatExportButton").addEventListener("click", exportActiveCombatZip);
  $("addMarkButton").addEventListener("click", () => addLinkedItem("marks", "markName", "markStatus", "markNotes"));
  $("addRivalButton").addEventListener("click", () => addLinkedItem("rivals", "rivalName", "rivalStatus", "rivalNotes"));
  $("addEncounterLinkButton").addEventListener("click", () => addLinkedItem("encounters", "encounterLinkName", "encounterLinkStatus", "encounterLinkNotes"));
  $("addEquipmentButton").addEventListener("click", () => addLinkedItem("equipment", "equipmentName", "equipmentStatus", "equipmentNotes"));
  $("addConsumableButton").addEventListener("click", () => addLinkedItem("consumables", "consumableName", "consumableStatus", "consumableNotes"));
  $("addMartialArtButton").addEventListener("click", () => addLinkedItem("martialArts", "martialArtName", "martialArtStatus", "martialArtNotes"));
  $("generateEncounterButton").addEventListener("click", generateEncounterPrompt);
  $("copyEncounterButton").addEventListener("click", () => {
    if (!$("encounterPromptOutput").value.trim()) generateEncounterPrompt();
    copyText($("encounterPromptOutput").value);
  });
  [
    "builderName",
    "builderLevel",
    "builderRealm",
    "builderKeyAbility",
    "builderVersion",
    "builderDescription",
    "builderStr",
    "builderDex",
    "builderCon",
    "builderInt",
    "builderWis",
    "builderCha",
    "builderTalents",
    "builderInsights",
    "builderTechniques",
    "builderActions",
    "builderEquipment",
    "builderBackground",
    "builderBackgroundRegion",
    "builderFoundationCatalogSelect",
    "builderFoundationName",
    "builderFoundationFamily",
    "builderFoundationDepth",
    "builderFoundationStage",
    "builderFoundationNotes",
    "builderMartialArtName",
    "builderMartialArtStatus",
    "builderMartialArtDoctrine",
    "builderChakraRecord"
  ].forEach((id) => {
    if (!$(id)) return;
    $(id).addEventListener("input", updateBuilderPreview);
    $(id).addEventListener("change", updateBuilderPreview);
  });
  if ($("builderFoundationCatalogSet")) {
    $("builderFoundationCatalogSet").addEventListener("change", () => { fillFoundationCatalogSelect(); applyBuilderFoundationCatalogSelection(); });
  }
  if ($("builderFoundationCatalogSelect")) {
    $("builderFoundationCatalogSelect").addEventListener("change", applyBuilderFoundationCatalogSelection);
  }
  if ($("builderFoundationStage")) {
    $("builderFoundationStage").addEventListener("change", applyBuilderFoundationStageSelection);
  }
  if ($("builderPath")) {
    $("builderPath").addEventListener("change", () => {
      const next = builderConfig($("builderPath").value);
      if ($("builderKeyAbility")) $("builderKeyAbility").value = next.key;
      if ($("builderRealm")) $("builderRealm").value = $("builderPath").value === "Chakra" ? chakraRealmByLevel(Number($("builderLevel")?.value || 1)) : realmByLevel(Number($("builderLevel")?.value || 1));
      updateBuilderPreview();
    });
  }
  if ($("builderLevel")) {
    $("builderLevel").addEventListener("change", () => {
      if ($("builderRealm")) $("builderRealm").value = $("builderPath")?.value === "Chakra" ? chakraRealmByLevel(Number($("builderLevel").value || 1)) : realmByLevel(Number($("builderLevel").value || 1));
      updateBuilderPreview();
    });
  }
  if ($("builderAddSphereButton")) $("builderAddSphereButton").addEventListener("click", addBuilderSphere);
  if ($("builderSaveButton")) $("builderSaveButton").addEventListener("click", saveBuilderCharacter);
  if ($("builderCopyBlocksButton")) $("builderCopyBlocksButton").addEventListener("click", () => {
    updateBuilderPreview();
    copyText($("builderPackageOutput").value);
  });
  if ($("builderExportZipButton")) $("builderExportZipButton").addEventListener("click", exportBuilderZip);
  if ($("builderResetButton")) $("builderResetButton").addEventListener("click", resetBuilder);
  $("copySuggestionButton").addEventListener("click", () => copyText($("suggestionOutput").value));
  if ($("sphereSearch")) $("sphereSearch").addEventListener("input", renderLibrary);
  if ($("foundationSearch")) $("foundationSearch").addEventListener("input", renderLibrary);
  $("analyzePackageButton").addEventListener("click", analyzePackageInput);
  $("savePackageButton").addEventListener("click", savePackage);
  $("clearPackageInputButton").addEventListener("click", () => {
    $("canonPackageName").value = "";
    $("canonPackageVersion").value = "";
    $("canonPackageInput").value = "";
    $("packageFileStatus").textContent = "No files imported yet.";
    renderPackageAnalysis(null);
  });
  const dropZone = $("packageDropZone");
  let packageDropDepth = 0;
  dropZone.addEventListener("click", () => $("packageFileInput").click());
  dropZone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      $("packageFileInput").click();
    }
  });
  dropZone.addEventListener("dragover", (event) => {
    if (!hasDroppedFiles(event)) return;
    event.preventDefault();
    dropZone.classList.add("dragging");
  });
  dropZone.addEventListener("dragenter", (event) => {
    if (!hasDroppedFiles(event)) return;
    event.preventDefault();
    packageDropDepth += 1;
    dropZone.classList.add("dragging");
  });
  dropZone.addEventListener("dragleave", (event) => {
    if (!hasDroppedFiles(event)) return;
    packageDropDepth = Math.max(0, packageDropDepth - 1);
    if (!packageDropDepth) dropZone.classList.remove("dragging");
  });
  dropZone.addEventListener("drop", (event) => {
    if (!hasDroppedFiles(event)) return;
    event.preventDefault();
    packageDropDepth = 0;
    dropZone.classList.remove("dragging");
    importPackageFiles(event.dataTransfer.files);
  });
  $("packageFileInput").addEventListener("change", (event) => {
    importPackageFiles(event.target.files);
    event.target.value = "";
  });

  // Prevent a near-miss from navigating Brave to the dropped ZIP instead of importing it.
  document.addEventListener("dragover", (event) => {
    if (hasDroppedFiles(event)) event.preventDefault();
  });
  document.addEventListener("drop", (event) => {
    if (!hasDroppedFiles(event) || dropZone.contains(event.target)) return;
    event.preventDefault();
    packageDropDepth = 0;
    dropZone.classList.remove("dragging");
    importPackageFiles(event.dataTransfer.files);
  });
  if ($("analyzeNpcButton")) $("analyzeNpcButton").addEventListener("click", () => analyzeNpcStatBlock(false));
  if ($("analyzeNpcGenerateButton")) $("analyzeNpcGenerateButton").addEventListener("click", () => analyzeNpcStatBlock(true));
  if ($("generateFightPromptButton")) $("generateFightPromptButton").addEventListener("click", generateFightPrompt);
  if ($("randomizeNpcButton")) $("randomizeNpcButton").addEventListener("click", randomizeNpc);
  if ($("copyFightPromptButton")) $("copyFightPromptButton").addEventListener("click", () => {
    if (!$('fightPromptOutput').value.trim()) generateFightPrompt();
    copyText($('fightPromptOutput').value);
  });
  $("buildCharacterPromptButton").addEventListener("click", buildCharacterPrompt);
  $("copyCharacterPromptButton").addEventListener("click", () => {
    if (!$("characterPromptOutput").value.trim()) buildCharacterPrompt();
    copyText($("characterPromptOutput").value);
  });
  $("buildPreFightButton").addEventListener("click", buildPreFightPrompt);
  $("copyPreFightButton").addEventListener("click", () => {
    if (!$("preFightOutput").value.trim()) buildPreFightPrompt();
    copyText($("preFightOutput").value);
  });
  $("buildReflectionButton").addEventListener("click", buildReflectionPrompt);
  $("copyReflectionButton").addEventListener("click", () => {
    if (!$("reflectionOutput").value.trim()) buildReflectionPrompt();
    copyText($("reflectionOutput").value);
  });
  $("saveReflectionButton").addEventListener("click", saveReflection);
  $("saveGlobalRuleButton").addEventListener("click", saveGlobalRule);
  $("saveTacticalPatternButton").addEventListener("click", saveTacticalPattern);
  $("copyMemoryButton").addEventListener("click", () => copyText($("memoryOutput").value));
  $("buildRegressionButton").addEventListener("click", buildRegressionPrompt);
  $("copyRegressionButton").addEventListener("click", () => {
    if (!$("regressionOutput").value.trim()) buildRegressionPrompt();
    copyText($("regressionOutput").value);
  });
}

function setDefaults() {
  $("packetPlayer").value = "";
  $("packetOuter").value = "Zhen";
  $("packetInner").value = "Kan";
  $("packetSphere").value = "Life";
  $("packetAnswer").value = "Kun";
  $("packetLine").value = "Line 2 - Relationship";
  $("encounterOuter").value = "Kan";
  $("encounterInner").value = "Gen";
  $("encounterSphere").value = "Life";
  if ($("npcPath")) $("npcPath").value = "Body Refining";
  if ($("npcPrimary")) $("npcPrimary").value = "Iron Fist";
  if ($("npcSecondary")) $("npcSecondary").value = "";
  if ($("npcDefaultTrigram")) $("npcDefaultTrigram").value = "Qian";
  if ($("npcStressTrigram")) $("npcStressTrigram").value = "Kan";
  if ($("postureVariability")) $("postureVariability").value = "Balanced";
  if ($("minorSphereInfluence")) $("minorSphereInfluence").value = "Normal";
  if ($("tribOuter")) $("tribOuter").value = "Zhen";
  if ($("tribInner")) $("tribInner").value = "Kan";
  if ($("tribAnswer")) $("tribAnswer").value = "Gen";
  if ($("tribType")) $("tribType").value = "breakthrough";
  if ($("tribIntensity")) $("tribIntensity").value = "standard";
  $("encounterType").value = "sect trial encounter";
  $("preFightMode").value = "sanctioned duel";
  $("preFightBattlefield").value = "typical cultivator arena";
  $("regressionPurpose").value = "validate full combat workflow after script changes";
  if ($("builderPath")) $("builderPath").value = "Body Refining";
  if ($("builderKeyAbility")) $("builderKeyAbility").value = builderConfig("Body Refining").key;
  if ($("builderRealm")) $("builderRealm").value = realmByLevel(Number($("builderLevel")?.value || 1));
}



// Tianxia GM Screen HF05ZTK-R1A Character Package Import Patch
// Adds CL13 HF05ZTK package awareness: AI generation ledgers, sphere/talent
// accounting, Methods, Dao/Immortal Art profiles, Spirit Companion profiles,
// alias projection rows, and executable-content evidence display.
const TIANXIA_GM_HF05ZTK_CL13_IMPORT_PATCH = "v1.11.0-HF05ZTK-CL13-NEW-INFO-IMPORT-2026-07-08";
const HF05ZTK_CHARACTER_EXTRA_PATTERN = /(?:AI_Character_Generation_Profile|Sphere_Acquisition_Ledger|Talent_Source_Ledger|Level_Talent_Ledger|Trained_Choice_Ledger|Point_Buy_Ledger|Canonical_Talent_Ledger|Talent_Effect_Packet_Library|Cultivation_Method_Profile|Cultivation_Methods_AI_Index|Dao_Aspect_Immortal_Art_Profile|Dao_Aspect_Immortal_Arts_AI_Index|Immortal_Art_Registry|Spirit_Companion_Profile|HF05ZT[A-Z0-9_]*|HF05ZTK_Executable_Content_Evidence_Ledger|Action_Coverage_Matrix|Action_Provenance_Ledger|Equipment_Ledger|Armor_Class_Calculation_Ledger|Body_Refining_Externality_Profile|Foundation_Detail_Ledger|Foundation_Display_Row|I_Ching_Combat_Generation_Profile|Dao_Profile|Character_Identity)\.(?:json|md)$/i;

function hf05ztkBaseName(name) {
  return String(name || "").replace(/\\/g, "/").split("/").filter(Boolean).pop() || "";
}

function hf05ztkCanImportEntryName(name) {
  const base = hf05ztkBaseName(name);
  return HF05ZTK_CHARACTER_EXTRA_PATTERN.test(base);
}

if (typeof ARTIFACT_DEFINITIONS !== "undefined" && Array.isArray(ARTIFACT_DEFINITIONS)) {
  ARTIFACT_DEFINITIONS.push(
    ["aiGenerationProfile", "AI Generation Profile", /AI_Character_Generation_Profile|sphere_acquisition_ledger|trained_choice_ledger/i],
    ["methodProfile", "Cultivation Method Profile", /Cultivation_Method_Profile|primary_method|selected_method/i],
    ["daoArtProfile", "Dao / Immortal Art Profile", /Dao_Aspect_Immortal_Art_Profile|Immortal_Art_Registry/i],
    ["spiritCompanionProfile", "Spirit Companion Profile", /Spirit_Companion_Profile|companion_id|bond_triggers/i],
    ["hf05ztkEvidence", "HF05ZTK Executable Evidence", /HF05ZTK_Executable_Content_Evidence_Ledger|PASS_HF05ZTK/i],
    ["canonicalTalentLedger", "Canonical Talent Ledger", /Canonical_Talent_Ledger|selected_talents/i],
    ["talentPacketLibrary", "Talent Effect Packet Library", /Talent_Effect_Packet_Library|source_packet_ids/i]
  );
}

const hf05ztkIsCmlCharacterRecordEntryBefore = isCmlCharacterRecordEntry;
isCmlCharacterRecordEntry = function isCmlCharacterRecordEntryHf05ztk(entry) {
  if (hf05ztkIsCmlCharacterRecordEntryBefore(entry)) return true;
  const name = String(entry?.name || "").replace(/\\/g, "/");
  if (!name || isCmlInfrastructureEntryName(name)) return false;
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  return hf05ztkCanImportEntryName(name);
};

const hf05ztkIsEntryInCharacterFolderBefore = isEntryInCharacterFolder;
isEntryInCharacterFolder = function isEntryInCharacterFolderHf05ztk(entryName, folder) {
  if (hf05ztkIsEntryInCharacterFolderBefore(entryName, folder)) return true;
  const name = String(entryName || "").replace(/\\/g, "/");
  if (!name || isCmlInfrastructureEntryName(name)) return false;
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  if (folder === "__ROOT__" && name.includes("/")) return false;
  if (folder !== "__ROOT__" && !name.startsWith(`${folder}/`)) return false;
  const relative = relativeCharacterEntryName(name, folder);
  return hf05ztkCanImportEntryName(relative) || hf05ztkCanImportEntryName(name);
};

const hf05ztkProjectionDataBefore = sv05ProjectionDataFromParsed;
function hf05ztkProjectionLike(data) {
  if (!data || typeof data !== "object" || Array.isArray(data)) return null;
  const sourceRows = Array.isArray(data.rows) ? data.rows
    : Array.isArray(data.action_rows) ? data.action_rows
      : Array.isArray(data.gm_screen_action_rows) ? data.gm_screen_action_rows
        : Array.isArray(data.actions) ? data.actions : [];
  const statusRows = Array.isArray(data.status_rows) ? data.status_rows : [];
  const foundationRows = Array.isArray(data.foundation_rows) ? data.foundation_rows : [];
  const rows = [
    ...sourceRows.map((row) => row && typeof row === "object" ? { row_type: row.row_type || row.type || "action", ...row } : null).filter(Boolean),
    ...statusRows.map((row) => row && typeof row === "object" ? { row_type: row.row_type || row.type || "status", ...row } : null).filter(Boolean),
    ...foundationRows.map((row) => row && typeof row === "object" ? { row_type: row.row_type || row.type || "foundation", ...row } : null).filter(Boolean)
  ];
  return rows.length ? { ...data, rows, projection_contract_version: data.projection_contract_version || data.row_contract || data.schema || "HF05ZTK_ALIAS_ROW_CONTRACT" } : null;
}
sv05ProjectionDataFromParsed = function sv05ProjectionDataFromParsedHf05ztk(parsed = []) {
  const existing = hf05ztkProjectionDataBefore(parsed);
  if (existing) return existing;
  const primary = findJsonBlock(parsed, [/(?:^|[\\/])GM_Screen_Projection_Rows\.json$/i, /GM_Screen_Projection_Rows/i])?.data || null;
  const display = findJsonBlock(parsed, [/(?:^|[\\/])GM_Screen_Display_Rows\.json$/i, /GM_Screen_Display_Rows/i])?.data || null;
  return hf05ztkProjectionLike(primary) || hf05ztkProjectionLike(display) || null;
};

function hf05ztkJson(parsed = [], patterns = []) {
  return findJsonBlock(parsed, patterns)?.data || null;
}

function hf05ztkList(data, keys = []) {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  for (const key of keys) if (Array.isArray(data[key])) return data[key];
  return [];
}

function hf05ztkActionIds(list = []) {
  return compactImportList(list).map((row) => row?.action_id || row?.id || row?.act_action_ref || row?.linked_action_id).filter(Boolean);
}

function hf05ztkBestActionRows(parsed = [], fallback = []) {
  const projection = sv05ProjectionDataFromParsed(parsed);
  const projected = sv05ProjectionActionRows(projection);
  if (projected.length) return projected;
  const complete = hf05ztkJson(parsed, [/^(?:.*[\\/])?Complete_Action_Surface\.json$/i, /Complete_Action_Surface/i]);
  const completeRows = hf05ztkList(complete, ["actions", "complete_action_surface"]);
  if (completeRows.length) return completeRows;
  return fallback || [];
}

function hf05ztkMethodName(method = {}) {
  if (!method || typeof method !== "object") return "";
  return method.primary_method || method.selected_method || method.method_name || method.method || method.active_primary_method || method.name || method.description || "";
}

function hf05ztkDaoAspectText(profile = {}) {
  if (!profile || typeof profile !== "object") return "";
  const aspects = profile.selected_dao_aspects || profile.active_aspects || profile.dao_aspects || profile.dao_aspect || profile.aspect || profile.dao_aspect_system?.selected_aspects;
  return asDisplayText(aspects) || asDisplayText(profile.dao_aspect_system) || asDisplayText(profile.immortal_art_status) || asDisplayText(profile.notes);
}

function hf05ztkImmortalArtsList(registry = {}) {
  return hf05ztkList(registry, ["immortal_arts", "arts", "registry", "entries"]);
}

function hf05ztkSpiritCompanionSummary(profile = {}) {
  if (!profile || typeof profile !== "object") return "";
  return [
    profile.companion_name || profile.name,
    profile.companion_type,
    profile.bond_state,
    Array.isArray(profile.companion_limits) ? profile.companion_limits.join("; ") : profile.companion_limits,
    Array.isArray(profile.bond_triggers) ? profile.bond_triggers.join("; ") : profile.bond_triggers
  ].map(asDisplayText).filter(Boolean).join(" | ");
}

const hf05ztkBuildCharacterSheetDataBefore = buildCharacterSheetData;
buildCharacterSheetData = function buildCharacterSheetDataHf05ztk(pkg) {
  const sheet = sanitizeSheetCollections(hf05ztkBuildCharacterSheetDataBefore(pkg));
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const ai = hf05ztkJson(parsed, [/^(?:.*[\\/])?AI_Character_Generation_Profile\.json$/i, /AI_Character_Generation_Profile/i]);
  const method = hf05ztkJson(parsed, [/^(?:.*[\\/])?Cultivation_Method_Profile\.json$/i, /Cultivation_Method_Profile/i]);
  const daoProfile = hf05ztkJson(parsed, [/^(?:.*[\\/])?Dao_Aspect_Immortal_Art_Profile\.json$/i, /Dao_Aspect_Immortal_Art_Profile/i]);
  const immortalRegistry = hf05ztkJson(parsed, [/^(?:.*[\\/])?Immortal_Art_Registry\.json$/i, /Immortal_Art_Registry/i]);
  const spiritProfile = hf05ztkJson(parsed, [/^(?:.*[\\/])?Spirit_Companion_Profile\.json$/i, /Spirit_Companion_Profile/i]);
  const ztkEvidence = hf05ztkJson(parsed, [/^(?:.*[\\/])?HF05ZTK_Executable_Content_Evidence_Ledger\.json$/i, /HF05ZTK_Executable_Content_Evidence_Ledger/i]);
  const coverage = hf05ztkJson(parsed, [/^(?:.*[\\/])?Action_Coverage_Matrix\.json$/i, /Action_Coverage_Matrix/i]);
  const canonicalTalents = hf05ztkJson(parsed, [/^(?:.*[\\/])?Canonical_Talent_Ledger\.json$/i, /Canonical_Talent_Ledger/i]);
  const packetLibrary = hf05ztkJson(parsed, [/^(?:.*[\\/])?Talent_Effect_Packet_Library\.json$/i, /Talent_Effect_Packet_Library/i]);

  const actionRows = hf05ztkBestActionRows(parsed, sheet.actions);
  if (actionRows.length) sheet.actions = actionRows.sort((a, b) => actionSortScore(a) - actionSortScore(b));

  sheet.aiGenerationProfile = ai || sheet.aiGenerationProfile || null;
  sheet.pointBuyLedger = ai?.point_buy_ledger || sheet.pointBuyLedger || null;
  sheet.backgroundRecord = ai?.background_record || sheet.backgroundRecord || sheet.background || null;
  sheet.cl1FreeSphereGrant = ai?.cl1_free_sphere_grant || sheet.cl1FreeSphereGrant || null;
  sheet.sphereAcquisitionLedger = hf05ztkList(ai, ["sphere_acquisition_ledger", "spheres"]);
  sheet.talentSourceLedger = hf05ztkList(ai, ["talent_source_ledger"]);
  sheet.levelTalentLedger = hf05ztkList(ai, ["level_talent_ledger"]);
  sheet.trainedChoiceLedger = hf05ztkList(ai, ["trained_choice_ledger"]);
  sheet.manualLineageRecord = ai?.manual_lineage_record || null;
  sheet.methodProfile = method || ai?.method_record || ai?.method_records || sheet.methodProfile || null;
  sheet.daoAspectProfile = daoProfile || sheet.daoAspectProfile || null;
  sheet.immortalArtRegistry = immortalRegistry || sheet.immortalArtRegistry || null;
  sheet.immortalArts = hf05ztkImmortalArtsList(immortalRegistry);
  sheet.spiritCompanionProfile = spiritProfile || sheet.spiritCompanionProfile || null;
  sheet.hf05ztkEvidence = ztkEvidence || sheet.hf05ztkEvidence || null;
  sheet.actionCoverageMatrix = coverage || sheet.actionCoverageMatrix || null;
  sheet.canonicalTalentLedger = canonicalTalents || sheet.canonicalTalentLedger || null;
  sheet.talentEffectPacketLibrary = packetLibrary || sheet.talentEffectPacketLibrary || null;
  sheet.hf05ztkImportPatch = TIANXIA_GM_HF05ZTK_CL13_IMPORT_PATCH;

  if ((!sheet.talents || !sheet.talents.length) && canonicalTalents) {
    sheet.talents = hf05ztkList(canonicalTalents, ["selected_talents", "talents"]);
  }
  return sanitizeSheetCollections(finalizeSheetDisplayStats(sheet));
};

const hf05ztkCompactSupportBlocksBefore = compactSupportBlocks;
compactSupportBlocks = function compactSupportBlocksHf05ztk(blocks = []) {
  const base = hf05ztkCompactSupportBlocksBefore(blocks);
  const extraPattern = /(?:AI_Character_Generation_Profile|Canonical_Talent_Ledger|Talent_Effect_Packet_Library|Cultivation_Method_Profile|Dao_Aspect_Immortal_Art_Profile|Immortal_Art_Registry|Spirit_Companion_Profile|HF05ZTK_Executable_Content_Evidence_Ledger|Action_Coverage_Matrix|Action_Provenance_Ledger|Equipment_Ledger|Armor_Class_Calculation_Ledger|Body_Refining_Externality_Profile|Foundation_Detail_Ledger|Foundation_Display_Row|Character_Identity)\.(?:json|md)$/i;
  const seen = new Set(base.map((block) => block.name));
  const extras = (blocks || [])
    .filter((block) => extraPattern.test(String(block?.name || "")) && !seen.has(block.name))
    .map((block) => ({ name: block.name, content: block.content }));
  return [...base, ...extras];
};

const hf05ztkCompactSheetDataBefore = compactSheetData;
compactSheetData = function compactSheetDataHf05ztk(sheet) {
  const compact = hf05ztkCompactSheetDataBefore(sheet);
  if (!sheet || typeof sheet !== "object") return compact;
  return {
    ...compact,
    aiGenerationProfile: sheet.aiGenerationProfile || null,
    pointBuyLedger: sheet.pointBuyLedger || null,
    backgroundRecord: sheet.backgroundRecord || null,
    cl1FreeSphereGrant: sheet.cl1FreeSphereGrant || null,
    sphereAcquisitionLedger: (sheet.sphereAcquisitionLedger || []).slice(0, 80),
    talentSourceLedger: (sheet.talentSourceLedger || []).slice(0, 120),
    levelTalentLedger: (sheet.levelTalentLedger || []).slice(0, 40),
    trainedChoiceLedger: (sheet.trainedChoiceLedger || []).slice(0, 120),
    manualLineageRecord: sheet.manualLineageRecord || null,
    methodProfile: sheet.methodProfile || null,
    daoAspectProfile: sheet.daoAspectProfile || null,
    immortalArtRegistry: sheet.immortalArtRegistry || null,
    immortalArts: (sheet.immortalArts || []).slice(0, 40),
    spiritCompanionProfile: sheet.spiritCompanionProfile || null,
    hf05ztkEvidence: sheet.hf05ztkEvidence || null,
    actionCoverageMatrix: sheet.actionCoverageMatrix || null,
    hf05ztkImportPatch: sheet.hf05ztkImportPatch || TIANXIA_GM_HF05ZTK_CL13_IMPORT_PATCH
  };
};

function hf05ztkSmallKv(label, value) {
  const text = asDisplayText(value);
  return text ? `<article class="sheet-detail-card"><strong>${escapeHtml(label)}</strong><p>${escapeHtml(truncateValue(text, 420))}</p></article>` : "";
}

function hf05ztkLedgerTable(title, rows = [], columns = []) {
  const list = compactImportList(rows).slice(0, 16);
  if (!list.length) return `<section class="sheet-section"><h4>${escapeHtml(title)}</h4><div class="sheet-section-body"><p class="sheet-description">No ${escapeHtml(title.toLowerCase())} imported.</p></div></section>`;
  return `<section class="sheet-section"><h4>${escapeHtml(title)}</h4><div class="sheet-section-body"><table class="mini-table"><thead><tr>${columns.map((col) => `<th>${escapeHtml(col.label)}</th>`).join("")}</tr></thead><tbody>${list.map((row) => `<tr>${columns.map((col) => `<td>${escapeHtml(truncateValue(row?.[col.key] ?? row?.[col.alt] ?? "", 160))}</td>`).join("")}</tr>`).join("")}</tbody></table>${rows.length > list.length ? `<p class="sheet-description">Showing ${list.length} of ${rows.length} rows.</p>` : ""}</div></section>`;
}

function hf05ztkPanelHtml(sheet = {}) {
  const ai = sheet.aiGenerationProfile || {};
  const coverage = sheet.actionCoverageMatrix || {};
  const evidence = sheet.hf05ztkEvidence || {};
  const pointBuy = sheet.pointBuyLedger || {};
  const background = sheet.backgroundRecord || sheet.background || {};
  const cl1 = sheet.cl1FreeSphereGrant || {};
  const method = sheet.methodProfile || {};
  const dao = sheet.daoAspectProfile || {};
  const spirit = sheet.spiritCompanionProfile || {};
  const immortalArts = sheet.immortalArts || [];
  const actions = sheet.actions || [];
  const uniqueSpheres = new Set((sheet.sphereAcquisitionLedger || []).map((row) => row?.Sphere || row?.sphere || row?.name || row?.Sphere_gained).filter(Boolean));
  const actionIds = hf05ztkActionIds(actions);
  const coverageIds = coverage?.action_ids || [];
  const closureText = coverage?.coverage_verdict || coverage?.verdict || evidence?.verdict || evidence?.checks?.verdict || "Imported evidence available.";
  return `
    <section class="sheet-section hf05ztk-section">
      <h4>HF05ZTK Character-Generation & Import Evidence</h4>
      <div class="sheet-section-body">
        <div class="sheet-detail-grid">
          ${hf05ztkSmallKv("Import Patch", TIANXIA_GM_HF05ZTK_CL13_IMPORT_PATCH)}
          ${hf05ztkSmallKv("Generation Verdict", ai.verdict || ai.complete_generated_character || ai.schema)}
          ${hf05ztkSmallKv("Point Buy", pointBuy.points_spent !== undefined ? `${pointBuy.points_spent} points; legal=${pointBuy.legal}` : pointBuy)}
          ${hf05ztkSmallKv("Background", background.name || background.Background || background.background || background)}
          ${hf05ztkSmallKv("CL1 Grant", cl1.Sphere || cl1.sphere || cl1.free_sphere || cl1)}
          ${hf05ztkSmallKv("Known Sphere Diversity", uniqueSpheres.size || (sheet.spheres || []).length)}
          ${hf05ztkSmallKv("Method", hf05ztkMethodName(method))}
          ${hf05ztkSmallKv("Dao / Immortal Arts", hf05ztkDaoAspectText(dao) || `${immortalArts.length} refined art(s) imported`)}
          ${hf05ztkSmallKv("Spirit Companion", hf05ztkSpiritCompanionSummary(spirit))}
          ${hf05ztkSmallKv("Action Closure", `${actionIds.length} imported action rows${coverageIds.length ? `; ${coverageIds.length} coverage IDs` : ""}; ${closureText}`)}
        </div>
      </div>
    </section>
    ${hf05ztkLedgerTable("Sphere Acquisition Ledger", sheet.sphereAcquisitionLedger || [], [
      { key: "CL", alt: "cl", label: "CL" },
      { key: "Sphere", alt: "sphere", label: "Sphere" },
      { key: "source", alt: "grant_source", label: "Source" },
      { key: "free_bonus_talent", alt: "bonus_talent", label: "Free Talent" }
    ])}
    ${hf05ztkLedgerTable("Level Talent Ledger", sheet.levelTalentLedger || [], [
      { key: "CL", alt: "cl", label: "CL" },
      { key: "Sphere", alt: "sphere", label: "Sphere" },
      { key: "talent", alt: "Talent", label: "Talent" },
      { key: "source", alt: "grant_source", label: "Source" }
    ])}
    ${hf05ztkLedgerTable("Trained Choice Ledger", sheet.trainedChoiceLedger || [], [
      { key: "CL", alt: "cl", label: "CL" },
      { key: "choice_type", alt: "type", label: "Type" },
      { key: "source", alt: "Sphere", label: "Source" },
      { key: "counts_against_limit", alt: "counts_against_3_per_CL", label: "Counts" }
    ])}
  `;
}

const hf05ztkRenderReadableCharacterSheetBefore = renderReadableCharacterSheet;
renderReadableCharacterSheet = function renderReadableCharacterSheetHf05ztk(pkg, notes = {}) {
  const base = hf05ztkRenderReadableCharacterSheetBefore(pkg, notes);
  const sheet = buildCharacterSheetData(pkg);
  const ai = sheet.aiGenerationProfile || {};
  const method = sheet.methodProfile || {};
  const dao = sheet.daoAspectProfile || {};
  const coverage = sheet.actionCoverageMatrix || {};
  return [
    base,
    "",
    "## HF05ZTK Character-Generation Evidence",
    `Import Patch: ${TIANXIA_GM_HF05ZTK_CL13_IMPORT_PATCH}`,
    ai.schema || ai.verdict ? `Generation Profile: ${[ai.schema, ai.verdict].filter(Boolean).join(" | ")}` : "Generation Profile: not imported.",
    sheet.pointBuyLedger ? `Point Buy: ${asDisplayText(sheet.pointBuyLedger)}` : "Point Buy: not imported.",
    sheet.cl1FreeSphereGrant ? `CL1 Free Sphere Grant: ${asDisplayText(sheet.cl1FreeSphereGrant)}` : "CL1 Free Sphere Grant: not imported.",
    `Sphere Acquisition Ledger Rows: ${(sheet.sphereAcquisitionLedger || []).length}`,
    `Level Talent Ledger Rows: ${(sheet.levelTalentLedger || []).length}`,
    `Trained Choice Ledger Rows: ${(sheet.trainedChoiceLedger || []).length}`,
    `Method: ${hf05ztkMethodName(method) || "not imported"}`,
    `Dao / Immortal Art Profile: ${hf05ztkDaoAspectText(dao) || "not imported"}`,
    `Immortal Arts: ${(sheet.immortalArts || []).length}`,
    sheet.spiritCompanionProfile ? `Spirit Companion: ${hf05ztkSpiritCompanionSummary(sheet.spiritCompanionProfile)}` : "Spirit Companion: none imported or not required.",
    `Action Coverage: ${coverage.coverage_verdict || coverage.verdict || "not imported"}`
  ].join("\n");
};

const hf05ztkRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05ztk(pkg, notes = {}) {
  const html = hf05ztkRenderVisualCharacterSheetBefore(pkg, notes);
  const sheet = buildCharacterSheetData(pkg);
  const panel = hf05ztkPanelHtml(sheet);
  if (html.includes("</main>")) return html.replace("</main>", `<section class="sheet-section hf05ztk-visual-import"><div class="sheet-section-body">${panel}</div></section></main>`);
  return `${html}${panel}`;
};

function init() {
  populateControls();
  loadState();
  setDefaults();
  attachEvents();
  renderAll();
  void hydrateStoredPackages();
  generateEncounterPrompt();
}

init();

// Tianxia GM Screen HF05ZTL-R1A Projection Contract / HF05ZTK Display Repair
// Fixes visible AC/HP/speed, Foundation, Martial Manual, Talent display-name, and I Ching tab ingestion for HF05ZTK-era packages.
const TIANXIA_GM_HF05ZTL_PROJECTION_CONTRACT_PATCH = "v1.11.0-HF05ZTL-PROJECTION-CONTRACT-DISPLAY-2026-07-08";

function hf05ztlFindJson(parsed = [], patterns = []) {
  try { return findJsonBlock(parsed, patterns)?.data || null; } catch { return null; }
}
function hf05ztlList(data, keys = []) {
  if (Array.isArray(data)) return compactImportList(data);
  if (!data || typeof data !== "object") return [];
  for (const key of keys) {
    const value = data[key];
    if (Array.isArray(value)) return compactImportList(value);
    if (value && typeof value === "object") {
      const nested = hf05ztlList(value, ["rows", "items", "entries", "manuals", "forms", "techniques", "talents", "foundations"]);
      if (nested.length) return nested;
    }
  }
  return [];
}
function hf05ztlStatValue(stats = {}, keys = []) {
  if (!stats || typeof stats !== "object") return "";
  for (const key of keys) {
    if (stats[key] !== undefined && stats[key] !== null && stats[key] !== "") return stats[key];
  }
  return "";
}
function hf05ztlRowValue(rows = [], labels = []) {
  const patterns = labels.map((label) => new RegExp(`^${String(label).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i"));
  for (const row of compactImportList(rows)) {
    const label = String(row?.label || row?.name || row?.stat || row?.row_label || "").trim();
    if (!label) continue;
    if (patterns.some((rx) => rx.test(label))) return row.value ?? row.current ?? row.amount ?? row.text ?? row.summary ?? "";
  }
  return "";
}
function hf05ztlCollectStatusRows(...surfaces) {
  return surfaces.flatMap((surface) => hf05ztlList(surface || {}, ["status_rows", "statusRows", "combat_status_rows", "stat_rows", "rows"])
    .filter((row) => row && typeof row === "object" && /status|combat_stat|^$/i.test(String(row.row_type || row.type || ""))));
}
function hf05ztlBestHp(parsed = [], surfaces = []) {
  const statsList = surfaces.map((surface) => surface?.stats || {}).filter(Boolean);
  const rows = hf05ztlCollectStatusRows(...surfaces);
  const direct = statsList.map((stats) => hf05ztlStatValue(stats, ["HP", "hp", "max_hp", "hp_max", "maximum_hp", "maxHitPoints", "hit_points", "hp_current"])).find((v) => v !== "");
  const row = hf05ztlRowValue(rows, ["HP", "Hit Points", "Health"]);
  const value = direct !== undefined && direct !== "" ? direct : row;
  if (typeof value === "string" && value.includes("/")) {
    const parts = value.split("/").map((x) => Number(String(x).replace(/[^0-9.-]/g, ""))).filter(Number.isFinite);
    if (parts.length) return { current: parts[0], maximum: parts[1] ?? parts[0] };
  }
  if (value !== undefined && value !== null && value !== "") return { current: value, maximum: value };
  return null;
}
function hf05ztlBestAc(parsed = [], surfaces = []) {
  const acLedger = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Armor_Class_Calculation_Ledger\.json$/i, /Armor_Class_Calculation_Ledger/i]);
  const statsList = surfaces.map((surface) => surface?.stats || {}).filter(Boolean);
  const rows = hf05ztlCollectStatusRows(...surfaces);
  const direct = statsList.map((stats) => hf05ztlStatValue(stats, ["AC", "ac", "armor_class", "ac_active", "active_ac", "armorClass"])).find((v) => v !== "");
  const row = hf05ztlRowValue(rows, ["AC", "Armor Class"]);
  const ledgerValue = acLedger?.current ?? acLedger?.active ?? acLedger?.AC ?? acLedger?.ac ?? acLedger?.final_ac ?? acLedger?.armor_class;
  const value = direct !== undefined && direct !== "" ? direct : (row !== "" ? row : ledgerValue);
  if (value !== undefined && value !== null && value !== "") return { current: value, base: value, formula: acLedger?.formula || acLedger?.calculation || "" };
  return null;
}
function hf05ztlBestSpeed(parsed = [], surfaces = []) {
  const statsList = surfaces.map((surface) => surface?.stats || {}).filter(Boolean);
  const rows = hf05ztlCollectStatusRows(...surfaces);
  const direct = surfaces.map((surface) => surface?.speed ?? surface?.speed_ft ?? surface?.movement_speed ?? surface?.movement?.speed).find((v) => v !== undefined && v !== null && v !== "");
  const statValue = statsList.map((stats) => hf05ztlStatValue(stats, ["speed", "Speed", "speed_ft", "movement_speed", "move_speed", "walk_speed", "walking_speed"])).find((v) => v !== "");
  const row = hf05ztlRowValue(rows, ["Speed", "Move Speed", "Movement", "Walking Speed"]);
  const value = direct !== undefined && direct !== "" ? direct : (statValue !== undefined && statValue !== "" ? statValue : row);
  if (value !== undefined && value !== null && value !== "") return value;
  return "30 ft (default fallback; package missing explicit speed projection)";
}
function hf05ztlFoundationRows(parsed = [], surfaces = []) {
  const direct = [];
  const displayRow = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Foundation_Display_Row\.json$/i, /Foundation_Display_Row/i]);
  if (displayRow && typeof displayRow === "object") direct.push(displayRow);
  const ledger = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Foundation_Detail_Ledger\.json$/i, /Foundation_Detail_Ledger/i]);
  if (ledger?.foundation) direct.push(ledger.foundation);
  if (Array.isArray(ledger?.foundations)) direct.push(...ledger.foundations);
  surfaces.forEach((surface) => {
    direct.push(...hf05ztlList(surface, ["foundation_rows", "foundations", "foundation_records"]));
    if (surface?.foundation && typeof surface.foundation === "object") direct.push(surface.foundation);
  });
  const out = [];
  const seen = new Set();
  direct.filter(Boolean).forEach((row) => {
    const item = typeof row === "string" ? { name: row } : { ...row };
    const name = item.name || item.foundation_name || item.display_name || item.id || "";
    if (!name) return;
    item.name = item.name || item.foundation_name || item.display_name || name;
    item.foundation_name = item.foundation_name || item.name;
    item.family = item.family || item.foundation_family || item.foundation_type || item.type || "Package Foundation";
    item.stage = item.stage || item.default_stage || item.grade || item.depth || "Recorded";
    item.summary = item.summary || item.thesis || item.description || item.note || "HF05ZTL package foundation row.";
    const key = String(name).toLowerCase();
    if (seen.has(key)) return;
    seen.add(key); out.push(item);
  });
  return normalizeFoundationEntries(out);
}
function hf05ztlManualRowsFromDisplay(rows = []) {
  const groups = new Map();
  compactImportList(rows).forEach((row) => {
    if (!row || typeof row !== "object") return;
    const manualName = row.manual || row.manual_name || row.source_manual || row.name || "Martial Manual";
    const key = String(manualName).toLowerCase();
    if (!groups.has(key)) groups.set(key, { name: manualName, display_name: manualName, source_status: "Martial_Manual_Display_Rows.json", manual_forms: [], forms: [], techniques: [] });
    const group = groups.get(key);
    const formName = row.form || row.form_name || row.technique_name || row.display_name || row.action_name || "Manual Form";
    const form = { ...row, name: formName, display_name: formName, linked_action_id: row.linked_action_id || row.action_id || row.act_action_ref };
    group.manual_forms.push(form); group.forms = group.manual_forms; group.techniques = group.manual_forms;
  });
  return [...groups.values()];
}
function hf05ztlManualRows(parsed = [], surfaces = []) {
  const martial = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Martial_Arts_and_Manuals\.json$/i, /Martial_Arts_and_Manuals/i]);
  const registry = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Martial_Manual_Registry\.json$/i, /Martial_Manual_Registry/i]);
  const display = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Martial_Manual_Display_Rows\.json$/i, /Martial_Manual_Display_Rows/i]);
  const list = [];
  list.push(...hf05ztlList(martial, ["manuals", "martial_arts", "entries"]));
  list.push(...hf05ztlList(registry, ["manuals", "martial_arts", "entries"]));
  list.push(...hf05ztlManualRowsFromDisplay(hf05ztlList(display, ["rows", "manual_rows", "entries"])));
  const seen = new Map();
  list.filter(Boolean).forEach((manual) => {
    const obj = typeof manual === "string" ? { name: manual } : { ...manual };
    const name = obj.name || obj.manual_name || obj.display_name || obj.style_name || "Martial Manual";
    obj.name = obj.name || name; obj.display_name = obj.display_name || name;
    if (Array.isArray(obj.forms) && !obj.manual_forms) obj.manual_forms = obj.forms.map((form) => typeof form === "string" ? { name: form, display_name: form } : form);
    if (Array.isArray(obj.manual_forms) && !obj.forms) obj.forms = obj.manual_forms;
    if (Array.isArray(obj.manual_forms) && !obj.techniques) obj.techniques = obj.manual_forms;
    const key = String(name).toLowerCase();
    if (!seen.has(key)) seen.set(key, obj);
    else {
      const prior = seen.get(key);
      const combined = { ...prior, ...obj };
      const forms = [...compactImportList(prior.manual_forms || prior.forms || prior.techniques), ...compactImportList(obj.manual_forms || obj.forms || obj.techniques)];
      const formSeen = new Set();
      combined.manual_forms = forms.filter((form) => { const fkey = String((typeof form === "string" ? form : form?.name || form?.display_name || form?.form || "")).toLowerCase(); if (!fkey || formSeen.has(fkey)) return false; formSeen.add(fkey); return true; });
      combined.forms = combined.manual_forms; combined.techniques = combined.manual_forms;
      seen.set(key, combined);
    }
  });
  return [...seen.values()];
}
function hf05ztlTalentName(item = {}) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return "";
  return item.display_name || item.name || item.canonical_talent_name || item.talent_name || item.source_talent_name || item.feature_name || item.option_name || item.legal_talent_name || item.talent_id || item.canonical_talent_id || "";
}
function hf05ztlTalentSphere(item = {}) {
  if (!item || typeof item !== "object") return "";
  return item.sphere || item.canonical_source_sphere || item.source_sphere || item.legal_tianxia_sphere || item.sphere_name || "";
}
function hf05ztlNormalizeTalent(item = {}) {
  if (typeof item === "string") return item;
  if (!item || typeof item !== "object") return item;
  const name = hf05ztlTalentName(item) || "Unnamed Talent";
  const sphere = hf05ztlTalentSphere(item);
  return { ...item, name: item.name || name, display_name: item.display_name || name, sphere: item.sphere || sphere, legal_tianxia_sphere: item.legal_tianxia_sphere || sphere };
}
function hf05ztlTalents(parsed = [], current = []) {
  const canonical = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Canonical_Talent_Ledger\.json$/i, /Canonical_Talent_Ledger/i]);
  const source = hf05ztlList(canonical, ["selected_talents", "talents", "entries"]);
  const existing = compactImportList(current || []);
  const needsReplacement = !existing.length || existing.every((item) => !hf05ztlTalentName(item) || /^Unnamed/i.test(hf05ztlTalentName(item)));
  const list = needsReplacement && source.length ? source : (existing.length ? existing : source);
  return list.map(hf05ztlNormalizeTalent).filter(Boolean);
}
function hf05ztlIChingSummary(profile = {}) {
  if (!profile || typeof profile !== "object") return "";
  const lines = [];
  if (profile.hexagram_bias) lines.push(`Hexagram bias: ${asDisplayText(profile.hexagram_bias)}`);
  if (profile.use) lines.push(`Use: ${asDisplayText(profile.use)}`);
  if (profile.i_ching_combat_layer) lines.push(iChingLayerSummary(profile));
  if (profile.default_change_strategy) lines.push(`Default change: ${asDisplayText(profile.default_change_strategy)}`);
  if (profile.shift_triggers) lines.push(`Shift triggers: ${asDisplayText(profile.shift_triggers)}`);
  return lines.filter(Boolean).join("\n");
}
function hf05ztlDaoBehaviorSummary(profile = {}) {
  if (!profile || typeof profile !== "object") return "";
  if (profile.combat_behavior) return asDisplayText(profile.combat_behavior);
  return daoLayerSummary(profile) || asDisplayText(profile.dao_layer || profile.dao || profile.notes || "");
}

const hf05ztlBuildCharacterSheetDataBefore = buildCharacterSheetData;
buildCharacterSheetData = function buildCharacterSheetDataHf05ztl(pkg) {
  const sheet = hf05ztlBuildCharacterSheetDataBefore(pkg);
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const importSurface = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Character_Import_Surface\.json$/i, /Character_Import_Surface/i]) || {};
  const normalized = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Normalized_Sheet\.json$/i, /Normalized_Sheet/i]) || {};
  const display = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?GM_Screen_Display_Rows\.json$/i, /GM_Screen_Display_Rows/i]) || {};
  const projection = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?GM_Screen_Projection_Rows\.json$/i, /GM_Screen_Projection_Rows/i]) || {};
  const surfaces = [importSurface, normalized, display, projection];
  const hp = hf05ztlBestHp(parsed, surfaces);
  const ac = hf05ztlBestAc(parsed, surfaces);
  if (hp && (!sheet.hp || (!sheet.hp.maximum && !sheet.hp.max && !sheet.hp.current))) sheet.hp = normalizeHpRecord(hp);
  if (ac && (!sheet.ac || (sheet.ac.current === undefined && sheet.ac.base === undefined && sheet.ac.ac === undefined))) sheet.ac = normalizeAcRecord(ac);
  if (!sheet.speed || sheet.speed === "—") sheet.speed = hf05ztlBestSpeed(parsed, surfaces);
  const foundations = hf05ztlFoundationRows(parsed, surfaces);
  if (foundations.length && (!sheet.foundations || !sheet.foundations.length)) sheet.foundations = foundations;
  const manuals = hf05ztlManualRows(parsed, surfaces);
  if (manuals.length && (!sheet.martialArtsLearned || !sheet.martialArtsLearned.length)) sheet.martialArtsLearned = manuals;
  else if (manuals.length) {
    const byName = new Map((sheet.martialArtsLearned || []).map((m) => [String(m?.name || m?.display_name || m?.manual_name || "").toLowerCase(), m]));
    manuals.forEach((m) => { const key = String(m?.name || m?.display_name || "").toLowerCase(); if (key && !byName.has(key)) sheet.martialArtsLearned.push(m); });
  }
  sheet.talents = hf05ztlTalents(parsed, sheet.talents || []);
  sheet.iChingProfile = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?I_Ching_Combat_Generation_Profile\.json$/i, /I_Ching_Combat_Generation_Profile/i]) || sheet.iChingProfile || null;
  sheet.daoCombatBehaviorProfile = hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Dao_Combat_Behavior_Profile\.json$/i, /Dao_Combat_Behavior_Profile/i]) || sheet.daoCombatBehaviorProfile || null;
  sheet.hf05ztlProjectionPatch = TIANXIA_GM_HF05ZTL_PROJECTION_CONTRACT_PATCH;
  return sanitizeSheetCollections(finalizeSheetDisplayStats(sheet));
};

const hf05ztlCompactSupportBlocksBefore = compactSupportBlocks;
compactSupportBlocks = function compactSupportBlocksHf05ztl(blocks = []) {
  const base = hf05ztlCompactSupportBlocksBefore(blocks);
  const extraPattern = /(?:I_Ching_Combat_Generation_Profile|Dao_Combat_Behavior_Profile|Martial_Manual_Display_Rows|Martial_Arts_and_Manuals|Foundation_Detail_Ledger|Foundation_Display_Row|Canonical_Talent_Ledger|Talent_Effect_Packet_Library|Armor_Class_Calculation_Ledger|Character_Import_Surface|Normalized_Sheet|GM_Screen_Projection_Rows|GM_Screen_Display_Rows)\.(?:json|md)$/i;
  const seen = new Set(base.map((block) => block.name));
  const extras = (blocks || [])
    .filter((block) => extraPattern.test(String(block?.name || "")) && !seen.has(block.name))
    .map((block) => ({ name: block.name, content: block.content }));
  return [...base, ...extras];
};

const hf05ztlCompactSheetDataBefore = compactSheetData;
compactSheetData = function compactSheetDataHf05ztl(sheet) {
  const compact = hf05ztlCompactSheetDataBefore(sheet);
  if (!sheet || typeof sheet !== "object") return compact;
  return {
    ...compact,
    iChingProfile: sheet.iChingProfile || null,
    daoCombatBehaviorProfile: sheet.daoCombatBehaviorProfile || null,
    hf05ztlProjectionPatch: sheet.hf05ztlProjectionPatch || TIANXIA_GM_HF05ZTL_PROJECTION_CONTRACT_PATCH
  };
};

const hf05ztlCompositeRegistryDataFromPackageBefore = compositeRegistryDataFromPackage;
compositeRegistryDataFromPackage = function compositeRegistryDataFromPackageHf05ztl(pkg, sheet = {}) {
  const playbook = hf05ztlCompositeRegistryDataFromPackageBefore(pkg, sheet);
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  playbook.iChingProfile = sheet.iChingProfile || hf05ztlFindJson(parsed, [/^(?:.*[\\/])?I_Ching_Combat_Generation_Profile\.json$/i, /I_Ching_Combat_Generation_Profile/i]) || null;
  playbook.daoCombatBehaviorProfile = sheet.daoCombatBehaviorProfile || hf05ztlFindJson(parsed, [/^(?:.*[\\/])?Dao_Combat_Behavior_Profile\.json$/i, /Dao_Combat_Behavior_Profile/i]) || playbook.daoProfile || null;
  if (playbook.sourceFiles) {
    playbook.sourceFiles.iChingProfile = Boolean(playbook.iChingProfile);
    playbook.sourceFiles.daoCombatBehaviorProfile = Boolean(playbook.daoCombatBehaviorProfile);
  }
  return playbook;
};

const hf05ztlDaoIChingPanelHtmlBefore = daoIChingPanelHtml;
daoIChingPanelHtml = function daoIChingPanelHtmlHf05ztl(playbook = {}) {
  const daoProfile = playbook.daoCombatBehaviorProfile || playbook.daoProfile || null;
  const iChingProfile = playbook.iChingProfile || null;
  if (!daoProfile && !iChingProfile) return hf05ztlDaoIChingPanelHtmlBefore(playbook);
  return `<section class="composite-panel-block dao-iching-panel">
    <h5>Dao / I Ching Behavior</h5>
    ${daoProfile ? `<div class="composite-detail-field"><strong>Dao Combat Behavior:</strong><pre class="mini-pre">${escapeHtml(hf05ztlDaoBehaviorSummary(daoProfile) || daoLayerSummary(daoProfile) || asDisplayText(daoProfile))}</pre></div>` : ""}
    ${iChingProfile ? `<div class="composite-detail-field"><strong>I Ching Combat Layer:</strong><pre class="mini-pre">${escapeHtml(hf05ztlIChingSummary(iChingProfile) || iChingLayerSummary(iChingProfile) || asDisplayText(iChingProfile))}</pre></div>` : ""}
  </section>`;
};

function hf05ztlDaoIChingStandalonePanelHtml(sheet = {}) {
  const dao = sheet.daoCombatBehaviorProfile || sheet.daoAspectProfile || null;
  const iching = sheet.iChingProfile || null;
  return `<div class="sheet-detail-grid">
    <article class="sheet-detail-card"><strong>Dao Behavior</strong><p>${escapeHtml(dao ? truncateValue(hf05ztlDaoBehaviorSummary(dao) || asDisplayText(dao), 900) : "No Dao_Combat_Behavior_Profile imported.")}</p></article>
    <article class="sheet-detail-card"><strong>I Ching Combat Layer</strong><p>${escapeHtml(iching ? truncateValue(hf05ztlIChingSummary(iching) || asDisplayText(iching), 900) : "No I_Ching_Combat_Generation_Profile imported.")}</p></article>
  </div>`;
}

const hf05ztlRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05ztl(pkg, notes = {}) {
  let html = hf05ztlRenderVisualCharacterSheetBefore(pkg, notes);
  const sheet = buildCharacterSheetData(pkg);
  const button = `<button class="sheet-tab-button " type="button" data-sheet-tab="dao / i ching">Dao / I Ching</button>`;
  if (!html.includes('data-sheet-tab="dao / i ching"')) {
    html = html.replace(/(<button class="sheet-tab-button\s*" type="button" data-sheet-tab="defense">Defense<\/button>)/, `${button}\n                  $1`);
  }
  const panel = `<div class="sheet-tab-panel" data-sheet-panel="dao / i ching">${hf05ztlDaoIChingStandalonePanelHtml(sheet)}</div>`;
  if (!html.includes('data-sheet-panel="dao / i ching"')) {
    html = html.replace(/(<div class="sheet-tab-panel" data-sheet-panel="defense">)/, `${panel}\n              $1`);
  }
  return html;
};

const hf05ztlTalentLineBefore = talentLine;
talentLine = function talentLineHf05ztl(item) {
  if (item && typeof item === "object") return hf05ztlTalentName(item) ? [hf05ztlTalentName(item), item.slot ? `[${item.slot}]` : "", hf05ztlTalentSphere(item) ? `sphere: ${hf05ztlTalentSphere(item)}` : "", item.acquisition_source ? `source: ${item.acquisition_source}` : item.source ? `source: ${item.source}` : "", item.effect || item.summary || item.description || ""].filter(Boolean).join(" ") : hf05ztlTalentLineBefore(item);
  return hf05ztlTalentLineBefore(item);
};
const hf05ztlTalentDetailBefore = talentDetail;
talentDetail = function talentDetailHf05ztl(item) {
  if (!item || typeof item !== "object") return hf05ztlTalentDetailBefore(item);
  const normalized = hf05ztlNormalizeTalent(item);
  const base = hf05ztlTalentDetailBefore(normalized);
  return { ...base, title: hf05ztlTalentName(normalized) || base.title || "Talent" };
};


// Tianxia GM Screen HF05ZTQ-R1A Rendered Output Truth Patch
// Derives active display from package canonical surfaces and replaces fallback-merged foundations/manuals/talents.
const TIANXIA_GM_HF05ZTQ_RENDERED_OUTPUT_TRUTH_PATCH = "v1.11.0-HF05ZTQ-RENDERED-OUTPUT-TRUTH-2026-07-08";
function hf05ztqFindJson(parsed = [], patterns = []) { try { return findJsonBlock(parsed, patterns)?.data || null; } catch { return null; } }
function hf05ztqList(data, keys = []) { if (Array.isArray(data)) return compactImportList(data); if (!data || typeof data !== "object") return []; for (const key of keys) if (Array.isArray(data[key])) return compactImportList(data[key]); return []; }
function hf05ztqCanonicalFoundation(parsed = []) {
  const detail = hf05ztqFindJson(parsed, [/Foundation_Detail_Ledger/i]);
  const display = hf05ztqFindJson(parsed, [/Foundation_Display_Row/i]);
  const reg = hf05ztqFindJson(parsed, [/Foundation_Registry/i]);
  const candidates = [detail?.foundation, display, ...(Array.isArray(detail?.foundations)?detail.foundations:[]), ...(Array.isArray(reg?.foundations)?reg.foundations:[])].filter(x => x && typeof x === "object");
  const good = candidates.find(x => String(x.foundation_id || x.id || x.name || "").trim() && !/^foundation$/i.test(String(x.name || x.foundation_name || "")));
  return good ? normalizeFoundationEntry({...good, active_foundation_count:1}) : null;
}
function hf05ztqCanonicalManuals(parsed = []) {
  const martial = hf05ztqFindJson(parsed, [/Martial_Arts_and_Manuals/i]);
  const manuals = hf05ztqList(martial, ["martialArtsLearned","manuals","martial_arts","entries"]);
  return manuals.filter(m => m && typeof m === "object" && compactImportList(m.manual_forms || m.forms || m.techniques).length)
    .map(m => { const forms = compactImportList(m.manual_forms || m.forms || m.techniques).filter(f => f && typeof f === "object" && (f.name || f.display_name || f.technique_name) && !/Unnamed Form|Learned form|Practice requirement recorded/i.test(JSON.stringify(f))); return {...m, manual_forms:forms, forms:forms, techniques:forms}; })
    .filter(m => m.manual_forms.length);
}
function hf05ztqCanonicalSphereGrants(parsed = []) {
  const grant = hf05ztqFindJson(parsed, [/Sphere_Free_Talent_Grant_Ledger/i]);
  return hf05ztqList(grant, ["grant_rows","rows","entries"]);
}
function hf05ztqAcProof(parsed = []) { return hf05ztqFindJson(parsed, [/Armor_Class_Calculation_Ledger/i]); }
const hf05ztqBuildCharacterSheetDataBefore = buildCharacterSheetData;
buildCharacterSheetData = function buildCharacterSheetDataHf05ztq(pkg) {
  const sheet = hf05ztqBuildCharacterSheetDataBefore(pkg);
  const parsed = parseJsonPackageBlocks(pkg?.blocks || []);
  const foundation = hf05ztqCanonicalFoundation(parsed);
  if (foundation) sheet.foundations = [foundation];
  const manuals = hf05ztqCanonicalManuals(parsed);
  if (manuals.length) sheet.martialArtsLearned = manuals;
  const grants = hf05ztqCanonicalSphereGrants(parsed);
  if (grants.length) sheet.sphereTalentGrantRows = grants;
  const ac = hf05ztqAcProof(parsed);
  if (ac) { sheet.acFormula = ac.display_text || ac.gm_screen_display || ac.equation || ac.formula || ""; sheet.acCalculationLedger = ac; }
  sheet.hf05ztqRenderPatch = TIANXIA_GM_HF05ZTQ_RENDERED_OUTPUT_TRUTH_PATCH;
  return sanitizeSheetCollections(finalizeSheetDisplayStats(sheet));
};
const hf05ztqRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05ztq(pkg, notes = {}) {
  let html = hf05ztqRenderVisualCharacterSheetBefore(pkg, notes);
  const sheet = buildCharacterSheetData(pkg);
  if (sheet.acFormula && !html.includes('AC Calculation')) {
    const panel = `<article class="sheet-detail-card"><strong>AC Calculation</strong><p>${escapeHtml(sheet.acFormula)}</p></article>`;
    html = html.replace(/(<div class="sheet-tab-panel" data-sheet-panel="defense">)/, `$1${panel}`);
  }
  if (Array.isArray(sheet.sphereTalentGrantRows) && sheet.sphereTalentGrantRows.length && !html.includes('Sphere / Free Talent Pairing')) {
    const rows = sheet.sphereTalentGrantRows.map(r => `<tr><td>${escapeHtml(r.sphere||'')}</td><td>${escapeHtml(r.sphere_source||'')}</td><td>${escapeHtml(String(r.first_gained_CL||''))}</td><td>${escapeHtml(r.free_talent_name||r.free_talent_id||'')}</td></tr>`).join('');
    const table = `<section class="sheet-section"><h4>Sphere / Free Talent Pairing</h4><table class="compact-table"><thead><tr><th>Sphere</th><th>Source</th><th>CL</th><th>Free Talent</th></tr></thead><tbody>${rows}</tbody></table></section>`;
    html = html.replace(/(<div class="sheet-tab-panel" data-sheet-panel="talents">)/, `$1${table}`);
  }
  return html;
};



// Tianxia GM Screen HF05ZTM-R1B Canonical Character Model Importer
// Rebuilds import/save/display input around one normalized Tianxia_GM_Character_Model_v1.
// R1B adds direct root-model intake for creator packages that export Tianxia_GM_Character_Model_v1.json.
const TIANXIA_GM_HF05ZTM_CANONICAL_IMPORTER = "v1.11.0-HF05ZTM-R1B-CANONICAL-CHARACTER-MODEL-IMPORTER-DIRECT-MODEL-2026-07-08";
const TGM_MODEL_SCHEMA_V1 = "Tianxia_GM_Character_Model_v1";
const TGM_COMPACT_SAVE_SCHEMA_V1 = "Tianxia_GM_Compact_Save_v1";
const TGM_EXEC_BUCKETS = new Set(["action", "bonus_action", "reaction", "passive"]);
const TGM_NONEXEC_BUCKETS = new Set(["procedure", "training", "downtime", "crafting", "recovery_project", "source_note", "audit_note", "split_required"]);
const TGM_ABILITIES = ["STR", "DEX", "CON", "INT", "WIS", "CHA"];

function tgmIsObject(value) { return Boolean(value) && typeof value === "object" && !Array.isArray(value); }
function tgmArray(value) { try { return compactImportList(Array.isArray(value) ? value : (value ? [value] : [])); } catch { return Array.isArray(value) ? value.filter(Boolean) : (value ? [value] : []); } }
function tgmStr(value, fallback = "") { return value === null || value === undefined ? fallback : String(value).trim(); }
function tgmNum(value, fallback = null) { if (value === null || value === undefined || String(value).trim() === "") return fallback; const raw = typeof value === "number" ? value : Number(String(value ?? "").replace(/[^0-9.-]/g, "")); return Number.isFinite(raw) ? raw : fallback; }
function tgmSlug(value = "") { return tgmStr(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, ""); }
function tgmTextKey(value = "") { return tgmStr(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim(); }
function tgmDisplayName(value = "") { const raw = polishMachineReadableText ? polishMachineReadableText(tgmStr(value)) : tgmStr(value).replace(/_/g, " "); return raw.replace(/\s+/g, " ").trim(); }
function tgmFirst(...values) { for (const value of values.flat()) { const text = tgmStr(value); if (text && !/^(?:null|undefined|none|n\/a)$/i.test(text)) return text; } return ""; }
function tgmPick(obj, keys = []) { if (!tgmIsObject(obj)) return undefined; for (const key of keys) if (obj[key] !== undefined && obj[key] !== null && obj[key] !== "") return obj[key]; return undefined; }
function tgmBlockPath(block = {}) { return tgmStr(block.name || block.path || block.file || ""); }
function tgmFindJson(parsed = [], patterns = []) { try { return findJsonBlock(parsed, patterns)?.data || null; } catch { return null; } }
function tgmFindJsonBlock(parsed = [], patterns = []) { try { return findJsonBlock(parsed, patterns) || null; } catch { return null; } }
function tgmListFrom(data, keys = []) { try { return compactImportList(listFromJsonData(data || {}, keys)); } catch { if (Array.isArray(data)) return data.filter(Boolean); return []; } }
function tgmNormalizeList(value, keys = []) { if (Array.isArray(value)) return compactImportList(value); if (tgmIsObject(value)) return tgmListFrom(value, keys); return []; }
function tgmUniqueBy(items = [], keyFn = (x) => JSON.stringify(x)) { const seen = new Set(); const out = []; for (const item of items) { const key = keyFn(item); if (!key || seen.has(key)) continue; seen.add(key); out.push(item); } return out; }
function tgmSource(block, fallback = "") { return fallback || tgmBlockPath(block) || null; }
function tgmGetNested(obj, path = []) { let cur = obj; for (const key of path) { if (!tgmIsObject(cur) && !Array.isArray(cur)) return undefined; cur = cur?.[key]; } return cur; }
function tgmAddDiag(model, severity, code, message, source_path = null, facet = null) {
  model.diagnostics.push({ severity, code, message, source_path, facet, importer: TIANXIA_GM_HF05ZTM_CANONICAL_IMPORTER });
}
function tgmAbilityMod(score) { const n = tgmNum(score, null); return n === null ? null : Math.floor((n - 10) / 2); }
function tgmAsAbilityRecord(value, maybeMod = undefined) {
  if (tgmIsObject(value)) {
    const score = tgmNum(tgmPick(value, ["score", "value", "final", "final_score", "total"]), null);
    const modifier = tgmNum(tgmPick(value, ["modifier", "mod", "bonus"]), score === null ? null : tgmAbilityMod(score));
    return score === null && modifier === null ? null : { score, modifier };
  }
  const score = tgmNum(value, null);
  const modifier = maybeMod !== undefined ? tgmNum(maybeMod, null) : (score === null ? null : tgmAbilityMod(score));
  return score === null && modifier === null ? null : { score, modifier };
}
function tgmDeepFirstObject(parsed = [], keys = []) {
  for (const entry of parsed) {
    const data = entry?.data;
    if (!tgmIsObject(data)) continue;
    for (const key of keys) {
      if (tgmIsObject(data[key]) || Array.isArray(data[key])) return data[key];
    }
  }
  return null;
}
function tgmSafeJson(value) { try { return JSON.stringify(value); } catch { return ""; } }

function tgmCanonicalBlocks(pkg = {}) {
  if (Array.isArray(pkg?.blocks) && pkg.blocks.length) return pkg.blocks;
  if (pkg?.rawText) { try { return parseFileBlocks(String(pkg.rawText || "")); } catch { return []; } }
  return [];
}
function tgmCanonicalParsed(pkg = {}) {
  try { return parseJsonPackageBlocks(tgmCanonicalBlocks(pkg)); } catch { return []; }
}
function tgmCanonicalFileMap(parsed = []) {
  const map = {};
  parsed.forEach((entry) => { if (entry?.name) map[entry.name] = { parsed_json: true, keys: tgmIsObject(entry.data) ? Object.keys(entry.data).slice(0, 80) : [] }; });
  return map;
}
function tgmAllBlockNames(pkg = {}) { return tgmCanonicalBlocks(pkg).map((b) => tgmBlockPath(b)).filter(Boolean); }

function tgmNormalizeIdentity(model, parsed, pkg = {}) {
  const importSurface = tgmFindJson(parsed, [/^(?:.*[\/])?Character_Import_Surface\.json$/i, /Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/^(?:.*[\/])?Normalized_Sheet\.json$/i, /Normalized_Sheet/i]) || {};
  const core = tgmFindJson(parsed, [/Character_Identity/i]) || tgmFindJson(parsed, [/Character_Core/i]) || {};
  const aiProfile = tgmFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const aiCore = aiProfile.character_core || {};
  const identity = importSurface.identity || normalized.identity || core.identity || core || aiProfile.identity || aiCore || {};
  const displayName = tgmFirst(importSurface.display_name, importSurface.name, importSurface.character, normalized.display_name, normalized.name, core.display_name, core.name, aiCore.name, aiProfile.character, pkg.name);
  const name = tgmFirst(importSurface.name, importSurface.character, normalized.name, core.name, aiCore.name, displayName, pkg.name);
  model.identity = {
    name: tgmDisplayName(name || "Unnamed Tianxia Character"),
    display_name: tgmDisplayName(displayName || name || "Unnamed Tianxia Character"),
    species: tgmFirst(identity.species, importSurface.species, normalized.species, "Human"),
    background_name: tgmFirst(importSurface.background?.name, aiProfile.background_record?.name, identity.background_name, identity.background),
    origin_name: tgmFirst(importSurface.origin?.name, aiProfile.origin_record?.name, identity.origin_name, identity.origin),
    concept_summary: tgmFirst(importSurface.concept_summary, identity.concept_summary, aiProfile.character_core?.concept_summary),
    build_role: tgmFirst(importSurface.build_role, identity.build_role, aiProfile.character_core?.role),
    source_inspiration: tgmFirst(importSurface.source_inspiration, identity.source_inspiration, aiProfile.origin_record?.source)
  };
  model.metadata.character_id = tgmFirst(importSurface.character_id, normalized.character_id, core.character_id, aiProfile.character_id, aiCore.character_id, pkg.characterId, tgmSlug(model.identity.display_name));
  model.metadata.character_slug = tgmSlug(model.identity.display_name || model.metadata.character_id);
}

function tgmNormalizePathRealm(model, parsed) {
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const aiProfile = tgmFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const pathChassis = aiProfile.path_chassis || {};
  const cl = tgmNum(tgmFirst(surface.CL, surface.cl, surface.level, normalized.CL, normalized.level, aiProfile.character_core?.requested_CL, aiProfile.derived_values?.CL), null);
  const path = tgmFirst(surface.path, normalized.path, pathChassis.Path, pathChassis.path, aiProfile.character_core?.Path, aiProfile.character_core?.path);
  const pb = tgmNum(tgmFirst(surface.PB, surface.pb, surface.proficiency_bonus, normalized.PB, normalized.pb, normalized.proficiency_bonus, aiProfile.derived_values?.PB), cl ? Math.ceil(cl / 4) + 1 : null);
  const key = tgmFirst(surface.key_ability, normalized.key_ability, pathChassis.key_ability, pathChassis.path_key_ability, path === "Body Refining" ? "CON" : path === "Spirit Awakening" ? "WIS" : "INT");
  const resource = tgmFirst(surface.primary_resource_name, normalized.primary_resource_name, pathChassis.primary_resource_type, pathChassis.resource, path === "Body Refining" ? "Stamina" : path === "Spirit Awakening" ? "Resonance" : "Qi");
  model.path_realm = {
    cultivation_level: cl,
    realm: tgmFirst(surface.realm, surface.realm_and_stage, normalized.realm, normalized.realm_and_stage, aiProfile.character_core?.Realm, aiProfile.character_core?.realm),
    path,
    key_ability: key.replace(/^.*\b(STR|DEX|CON|INT|WIS|CHA)\b.*$/i, "$1").toUpperCase(),
    hit_die: tgmFirst(surface.hit_die, normalized.hit_die, pathChassis.hit_die, path === "Body Refining" ? "d12" : "d8"),
    primary_resource_type: resource,
    proficiency_bonus: pb
  };
  if (!model.path_realm.cultivation_level) tgmAddDiag(model, "error", "MISSING_CL", "Cultivation Level was not found.", null, "path_realm");
  if (!model.path_realm.path) tgmAddDiag(model, "error", "MISSING_PATH", "Path was not found.", null, "path_realm");
}

function tgmNormalizeCombat(model, parsed) {
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const acLedger = tgmFindJson(parsed, [/Armor_Class_Calculation_Ledger/i]) || surface.ac_calculation || normalized.ac_calculation || {};
  const aiProfile = tgmFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const statSources = [surface.stats, normalized.stats, surface.combat_stats, normalized.combat_stats, aiProfile.derived_values?.status_rows, acLedger].filter(tgmIsObject);
  const pickStat = (keys) => { for (const src of statSources) { const v = tgmPick(src, keys); if (v !== undefined) return v; } return undefined; };
  const hpObj = surface.hp || normalized.hp || {};
  const resourceObj = surface.resource || normalized.resource || surface.resources?.primary || normalized.resources?.primary || {};
  const ac = tgmNum(tgmFirst(surface.ac_active, surface.ac, normalized.ac_active, normalized.ac, pickStat(["AC", "ac", "final_ac", "armor_class"]), acLedger.final_ac), null);
  const hpMax = tgmNum(tgmFirst(surface.hp_max, normalized.hp_max, hpObj.max, hpObj.maximum, pickStat(["HP", "hp", "hp_max", "max_hp", "hit_points"])), null);
  const hpCur = tgmNum(tgmFirst(surface.hp_current, normalized.hp_current, hpObj.current, hpMax), hpMax);
  const speed = tgmNum(tgmFirst(surface.speed_ft, surface.speed, normalized.speed_ft, normalized.speed, pickStat(["speed_ft", "speed", "Speed"])), null);
  const primaryName = tgmFirst(surface.primary_resource_name, normalized.primary_resource_name, resourceObj.name, model.path_realm.primary_resource_type);
  const primaryMax = tgmNum(tgmFirst(surface.primary_resource_max, normalized.primary_resource_max, resourceObj.max, resourceObj.maximum, resourceObj.value, surface.stats?.base_stamina, normalized.stats?.base_stamina), null);
  const primaryCur = tgmNum(tgmFirst(surface.primary_resource_current, normalized.primary_resource_current, resourceObj.current, primaryMax), primaryMax);
  model.combat_stats = {
    ac, hp_current: hpCur, hp_max: hpMax, speed_ft: speed,
    initiative_bonus: tgmNum(tgmFirst(surface.initiative_bonus, normalized.initiative_bonus, pickStat(["Initiative", "initiative", "initiative_bonus"])), 0),
    proficiency_bonus: model.path_realm.proficiency_bonus,
    primary_resource_current: primaryCur,
    primary_resource_max: primaryMax,
    primary_resource_name: primaryName,
    defenses: tgmNormalizeList(surface.defenses || normalized.defenses),
    resistances: tgmNormalizeList(surface.resistances || normalized.resistances),
    immunities: tgmNormalizeList(surface.immunities || normalized.immunities),
    vulnerabilities: tgmNormalizeList(surface.vulnerabilities || normalized.vulnerabilities),
    senses: tgmNormalizeList(surface.senses || normalized.senses),
    size: tgmFirst(surface.size, normalized.size),
    armor_summary: tgmFirst(surface.armor_summary, normalized.armor_summary, acLedger.display_text, acLedger.gm_screen_display),
    shield_summary: tgmFirst(surface.shield_summary, normalized.shield_summary)
  };
  if (ac === null) tgmAddDiag(model, "error", "MISSING_AC", "AC was not found in canonical combat stats or known aliases.", null, "combat_stats");
  if (hpMax === null) tgmAddDiag(model, "error", "MISSING_HP_MAX", "HP max was not found.", null, "combat_stats");
  if (speed === null) tgmAddDiag(model, "error", "MISSING_SPEED", "Speed was not found.", null, "combat_stats");
}

function tgmNormalizeAbilities(model, parsed) {
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const asi = tgmFindJson(parsed, [/Ability_Score_Increase_Ledger/i]) || {};
  const aiProfile = tgmFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const scoreSrc = surface.ability_scores || surface.abilities?.scores || normalized.ability_scores || normalized.abilities?.scores || asi.final_scores || aiProfile.ability_scores || aiProfile.derived_values?.ability_scores || {};
  const modSrc = surface.ability_modifiers || surface.abilities?.modifiers || normalized.ability_modifiers || normalized.abilities?.modifiers || asi.modifiers || aiProfile.ability_modifiers || aiProfile.derived_values?.ability_modifiers || {};
  const scores = {};
  for (const ab of TGM_ABILITIES) scores[ab] = tgmAsAbilityRecord(scoreSrc[ab], modSrc[ab]) || { score: null, modifier: null };
  model.ability_scores = scores;
  model.saving_throws = [];
  const saves = surface.saves || normalized.saves || aiProfile.derived_values?.saves || {};
  for (const ab of TGM_ABILITIES) if (saves[ab] !== undefined) model.saving_throws.push({ ability: ab, bonus: tgmNum(saves[ab], 0), proficient: false, source_path: "saves" });
  const skillsObj = surface.skills || normalized.skills || aiProfile.derived_values?.skills || {};
  model.skills = Object.entries(skillsObj).map(([name, value]) => ({ name: tgmDisplayName(name), bonus: tgmNum(value, value), source_path: "skills" }));
  const presentCount = TGM_ABILITIES.filter((ab) => model.ability_scores[ab]?.score !== null).length;
  if (presentCount < 6) tgmAddDiag(model, "error", "MISSING_ABILITY_SCORES", `Only ${presentCount}/6 ability scores loaded.`, null, "ability_scores");
}

function tgmNormalizeResources(model, parsed) {
  const limit = tgmFindJson(parsed, [/Limited_Resource_Counter_Inventory/i]) || {};
  const resources = tgmListFrom(limit, ["resources", "counters", "entries", "items"]);
  model.resources = {
    primary: {
      name: model.combat_stats.primary_resource_name || model.path_realm.primary_resource_type,
      current: model.combat_stats.primary_resource_current,
      max: model.combat_stats.primary_resource_max,
      formula: "CL * Path key ability modifier unless source override",
      recovery: "",
      temporal_notes: []
    },
    secondary: resources.filter((r) => tgmTextKey(r.name || r.resource_name) !== tgmTextKey(model.combat_stats.primary_resource_name)).map((r) => ({ name: tgmDisplayName(r.name || r.resource_name || "Resource"), current: tgmNum(r.current, null), max: tgmNum(r.max || r.maximum || r.value, null), source_path: "Limited_Resource_Counter_Inventory.json" })),
    scene_limited: [], rest_limited: [], counters: resources
  };
}

function tgmNormalizeSpheresTalents(model, parsed) {
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const ai = tgmFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const sphereLedger = tgmFindJson(parsed, [/Sphere_Free_Talent_Grant_Ledger/i]) || {};
  const knownSpheres = tgmUniqueBy([
    ...tgmNormalizeList(surface.spheres), ...tgmNormalizeList(normalized.spheres),
    ...tgmNormalizeList(ai.sphere_acquisition_ledger).map((r) => r.sphere || r.name || r.sphere_name),
    ...tgmNormalizeList(sphereLedger.grant_rows).map((r) => r.sphere)
  ].map((x) => typeof x === "string" ? { name: tgmDisplayName(x), sphere_id: `SPHERE_${tgmSlug(x).toUpperCase()}` } : { ...x, name: tgmDisplayName(x?.name || x?.sphere || x?.sphere_name || "Sphere"), sphere_id: x?.sphere_id || `SPHERE_${tgmSlug(x?.name || x?.sphere || x?.sphere_name).toUpperCase()}` }), (x) => tgmTextKey(x.name));
  model.spheres = knownSpheres;
  const legalTalent = tgmFindJson(parsed, [/Legal_Talent_Inventory/i]) || {};
  const canonicalTalent = tgmFindJson(parsed, [/Canonical_Talent_Ledger/i]) || {};
  const talentMap = tgmFindJson(parsed, [/Talent_Action_Expression_Map/i]) || {};
  const talentSources = [
    ...tgmListFrom(legalTalent, ["talents", "selected_talents", "rows", "entries", "items"]),
    ...tgmListFrom(canonicalTalent, ["selected_talents", "talents", "rows", "entries"]),
    ...tgmListFrom(ai, ["talent_source_ledger", "level_talent_ledger", "trained_choice_ledger"]),
    ...tgmListFrom(talentMap, ["rows", "talents", "entries"]),
    ...tgmNormalizeList(surface.talents),
    ...tgmNormalizeList(normalized.talents)
  ];
  model.talents = tgmUniqueBy(talentSources.map((t, index) => {
    if (typeof t === "string") return { talent_id: `TALENT_${tgmSlug(t).toUpperCase()}`, display_name: tgmDisplayName(t), canonical_talent_name: tgmDisplayName(t), sphere: "", source_type: "unknown", source_path: "talent fallback" };
    const name = tgmFirst(t.display_name, t.name, t.talent_name, t.canonical_talent_name, t.source_talent_name, t.free_talent_name, t.free_talent, t.title, t.label);
    return {
      talent_id: tgmFirst(t.talent_id, t.id, t.source_talent_id, name ? `TALENT_${tgmSlug(name).toUpperCase()}` : `TALENT_${index+1}`),
      display_name: tgmDisplayName(name || `Talent ${index + 1}`),
      canonical_talent_name: tgmDisplayName(tgmFirst(t.canonical_talent_name, t.name, name)),
      sphere: tgmDisplayName(tgmFirst(t.sphere, t.sphere_name, t.source_sphere, t.source_sphere_name)),
      gained_at_CL: tgmNum(t.gained_at_CL || t.CL || t.cl || t.level, null),
      source_type: tgmFirst(t.source_type, t.source, t.grant_source, t.type, "unknown"),
      counts_against_trained_choices: Boolean(t.counts_against_trained_choices),
      effect_summary: tgmFirst(t.effect_summary, t.effect, t.summary, t.description),
      action_exports: tgmNormalizeList(t.action_exports || t.actions),
      passive_exports: tgmNormalizeList(t.passive_exports || t.passives),
      source_path: t.source_path || "talent ledger"
    };
  }).filter((t) => t.display_name && !/^Talent \d+$/i.test(t.display_name)), (t) => tgmTextKey(t.display_name));
  if (!model.talents.length && tgmNum(surface.talent_count || canonicalTalent.talent_count, 0) > 0) tgmAddDiag(model, "error", "TALENTS_DECLARED_NOT_LOADED", "Talent count was declared but no readable talent entries loaded.", "Character_Import_Surface/Canonical_Talent_Ledger", "talents");
}

function tgmNormalizeFoundation(model, parsed) {
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = tgmFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const detail = tgmFindJson(parsed, [/Foundation_Detail_Ledger/i]) || {};
  const display = tgmFindJson(parsed, [/Foundation_Display_Row/i]) || null;
  const record = tgmFindJson(parsed, [/Foundation_Record/i]) || {};
  const registry = tgmFindJson(parsed, [/Foundation_Registry/i]) || {};
  const candidates = [surface.foundation, normalized.foundation, detail.foundation, display, record.foundation, record, ...tgmNormalizeList(surface.foundations), ...tgmNormalizeList(normalized.foundations), ...tgmListFrom(detail, ["foundations", "rows", "entries"]), ...tgmListFrom(registry, ["foundations", "rows", "entries"])]
    .filter(tgmIsObject);
  model.foundations = tgmUniqueBy(candidates.map((f, index) => {
    const name = tgmFirst(f.name, f.foundation_name, f.display_name, f.title);
    if (!name || /^foundation$/i.test(name)) return null;
    return {
      foundation_id: tgmFirst(f.foundation_id, f.id, `FOUNDATION_${tgmSlug(name).toUpperCase()}`),
      name: tgmDisplayName(name),
      family: tgmFirst(f.family, f.foundation_family, f.foundation_type),
      grade_or_depth: tgmFirst(f.grade, f.depth, f.foundation_grade, f.grade_or_depth),
      stage: tgmFirst(f.stage, f.status, f.default_stage),
      source: tgmFirst(f.source, f.authority),
      benefits: tgmNormalizeList(f.benefits || f.mechanical_benefits || f.mechanical_benefits_or_constraints || f.passive_chassis || f.benefit_rows),
      burdens_or_risks: tgmNormalizeList(f.burdens || f.burdens_or_risks || f.burden_deviation_risks || f.risks),
      compatibility: tgmNormalizeList(f.compatibility || f.sphere_interfaces),
      action_exports: tgmNormalizeList(f.action_exports || f.actions),
      passive_exports: tgmNormalizeList(f.passive_exports || f.passives),
      display_summary: tgmFirst(f.display_summary, f.summary, f.known_player_text, f.mechanical_summary),
      source_path: f.source_path || (index === 0 ? "Foundation surfaces" : "Foundation fallback")
    };
  }).filter(Boolean), (f) => tgmTextKey(f.name));
  if ((model.path_realm.cultivation_level || 0) >= 5 && !model.foundations.length) tgmAddDiag(model, "error", "CL5_FOUNDATION_MISSING", "CL5+ character has no normalized Foundation.", null, "foundations");
}

function tgmNormalizeMethods(model, parsed) {
  const method = tgmFindJson(parsed, [/Cultivation_Method_Profile/i]) || tgmFindJson(parsed, [/Method_Record/i]) || {};
  const list = tgmListFrom(method, ["methods", "entries", "items"]);
  const primary = method.primary_method || method.method || method;
  const candidates = [...list, primary].filter(tgmIsObject);
  model.methods = tgmUniqueBy(candidates.map((m) => ({
    method_id: tgmFirst(m.method_id, m.id, tgmSlug(m.name || m.method || m.primary_method)),
    name: tgmDisplayName(tgmFirst(m.name, m.method, m.primary_method, "Method")),
    status: tgmFirst(m.status, m.primary_method ? "Primary" : "known"),
    resource_shape: tgmFirst(m.resource_shape, m.resource_modifier, m.resource, m.benefit),
    breakthrough_shape: tgmFirst(m.breakthrough_shape, m.breakthrough),
    foundation_shape: tgmFirst(m.foundation_shape, m.foundation),
    compatibility: tgmNormalizeList(m.compatibility),
    incompatibility: tgmNormalizeList(m.incompatibility),
    display_summary: tgmFirst(m.display_summary, m.summary, m.benefit),
    source_path: "Cultivation_Method_Profile.json"
  })).filter((m) => m.name && !/^Method$/i.test(m.name)), (m) => tgmTextKey(m.name));
}

function tgmNormalizeActions(model, parsed) {
  const actionRegistry = tgmFindJson(parsed, [/Character_Action_Registry/i]) || {};
  const complete = tgmFindJson(parsed, [/Complete_Action_Surface/i]) || {};
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const sources = [
    ...tgmListFrom(actionRegistry, ["actions", "action_actions", "bonus_action_actions", "reaction_actions", "passive_entries", "entries", "items", "registry"]),
    ...tgmListFrom(complete, ["actions", "complete_action_surface", "entries", "items", "registry"]),
    ...tgmNormalizeList(surface.actions), ...tgmNormalizeList(surface.gm_screen_action_rows), ...tgmNormalizeList(surface.action_rows)
  ];
  const normalized = sources.map((a, index) => {
    if (!tgmIsObject(a)) return null;
    const rawBucket = tgmFirst(a.bucket, a.action_type, a.action, a.type, a.action_economy, a.activation_type, a.activation_action_type).toLowerCase().replace(/[\s-]+/g, "_");
    const bucket = rawBucket === "bonus" ? "bonus_action" : rawBucket === "react" ? "reaction" : rawBucket === "passive_entry" ? "passive" : rawBucket;
    const executable = TGM_EXEC_BUCKETS.has(bucket);
    const sourceType = tgmFirst(a.source_type, a.source_category, a.category, a.origin_type);
    const name = tgmFirst(a.display_name, a.action_name, a.name, a.title, a.label, a.action_id, a.id);
    const actionId = tgmFirst(a.action_id, a.id, a.complete_action_id, name ? `ACT_${tgmSlug(name).toUpperCase()}` : `ACT_${index + 1}`);
    const entry = {
      action_id: actionId,
      name: tgmDisplayName(name || `Action ${index + 1}`),
      display_name: tgmDisplayName(name || `Action ${index + 1}`),
      bucket: executable ? bucket : (TGM_NONEXEC_BUCKETS.has(bucket) ? "procedure" : "action"),
      source_id: tgmFirst(a.source_id, a.talent_id, a.foundation_id, a.manual_id, a.forged_technique_id),
      source_type: sourceType || "other",
      source_name: tgmDisplayName(tgmFirst(a.source_name, a.source, a.talent_name, a.manual_name, a.foundation_name)),
      activation_or_trigger: tgmFirst(a.activation_or_trigger, a.activation, a.trigger, a.timing, a.action_trigger),
      cost: a.cost ?? a.resource_cost ?? a.resources ?? "",
      target_or_area: tgmFirst(a.target_or_area, a.target, a.area, a.targets),
      range: tgmFirst(a.range, a.reach),
      roll_save_check: a.roll_save_check ?? a.roll ?? a.save ?? a.check ?? a.attack ?? "",
      attack_bonus: a.attack_bonus ?? a.to_hit ?? "",
      save_dc: a.save_dc ?? a.dc ?? "",
      damage: a.damage ?? a.damage_or_effect ?? "",
      effect: tgmFirst(a.effect, a.effects, a.effect_summary, a.description, a.resolution, a.result, a.summary, a.damage_or_effect),
      duration: tgmFirst(a.duration, a.duration_text),
      limit: tgmFirst(a.limit, a.limits, a.uses, a.frequency),
      resource_timing: tgmFirst(a.resource_timing),
      temporal_feasibility: tgmFirst(a.temporal_feasibility, a.temporal_status),
      linked_components: tgmNormalizeList(a.linked_components || a.components),
      created_states: tgmNormalizeList(a.created_states || a.states),
      created_modifiers: tgmNormalizeList(a.created_modifiers || a.modifiers),
      counterplay: tgmFirst(a.counterplay, a.counter_play),
      gm_notes: tgmFirst(a.gm_notes, a.notes),
      source_path: a.source_path || "action registry"
    };
    if (!entry.effect) entry.effect = tgmFirst(entry.damage, entry.activation_or_trigger, "Effect not separately recorded.");
    return entry;
  }).filter(Boolean);
  const unique = tgmUniqueBy(normalized, (a) => tgmTextKey(a.action_id || a.display_name));
  model.actions = unique.filter((a) => a.bucket === "action");
  model.bonus_actions = unique.filter((a) => a.bucket === "bonus_action");
  model.reactions = unique.filter((a) => a.bucket === "reaction");
  model.passives = unique.filter((a) => a.bucket === "passive");
  model.procedures = unique.filter((a) => !TGM_EXEC_BUCKETS.has(a.bucket));
  if (!unique.length) tgmAddDiag(model, "error", "NO_ACTIONS_LOADED", "No actions loaded from action registries or import surface.", null, "actions");
  if (unique.some((a) => /^Unnamed Action$/i.test(a.display_name || a.name))) tgmAddDiag(model, "error", "UNNAMED_ACTION", "One or more actions normalized as Unnamed Action.", null, "actions");
}

function tgmNormalizeManuals(model, parsed) {
  const martial = tgmFindJson(parsed, [/Martial_Arts_and_Manuals/i]) || {};
  const rows = tgmFindJson(parsed, [/Martial_Manual_Display_Rows/i]) || {};
  const lineage = tgmFindJson(parsed, [/Manual_Lineage_Record/i]) || {};
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const manualsRaw = [
    ...tgmListFrom(martial, ["manuals", "martialArtsLearned", "martial_arts", "entries"]),
    ...tgmListFrom(lineage, ["manuals", "entries", "items"]),
    ...tgmNormalizeList(surface.manuals), ...tgmNormalizeList(surface.martial_manuals), ...tgmNormalizeList(surface.martialArtsLearned)
  ];
  const rowList = [...tgmListFrom(rows, ["rows", "manual_rows", "entries"]), ...tgmNormalizeList(surface.martial_manual_rows), ...tgmNormalizeList(surface.gm_screen_martial_manual_rows)];
  const manuals = tgmUniqueBy(manualsRaw.map((m, index) => {
    if (!tgmIsObject(m)) return null;
    const name = tgmFirst(m.name, m.manual_name, m.display_name, m.title, m.lineage_name);
    return {
      manual_id: tgmFirst(m.manual_id, m.id, name ? `MANUAL_${tgmSlug(name).toUpperCase()}` : `MANUAL_${index + 1}`),
      name: tgmDisplayName(name || `Manual ${index + 1}`),
      type: tgmFirst(m.type, m.manual_type, "manual"),
      source: tgmFirst(m.source, m.origin),
      contents_summary: tgmFirst(m.contents_summary, m.summary, m.description, m.effect),
      recorded_arts: tgmNormalizeList(m.recorded_arts),
      methods: tgmNormalizeList(m.methods),
      warnings: tgmNormalizeList(m.warnings),
      recipes: tgmNormalizeList(m.recipes),
      theory: tgmNormalizeList(m.theory),
      false_routes: tgmNormalizeList(m.false_routes),
      restrictions: tgmNormalizeList(m.restrictions),
      risks: tgmNormalizeList(m.risks),
      mechanics_granted: tgmNormalizeList(m.mechanics_granted),
      display_rows: rowList.filter((r) => tgmTextKey(r.manual_name || r.manual || r.source || r.parent_manual) === tgmTextKey(name)),
      source_path: "Martial_Arts_and_Manuals.json"
    };
  }).filter(Boolean), (m) => tgmTextKey(m.name));
  model.manuals = manuals;
  const formRaw = [
    ...manualsRaw.flatMap((m) => tgmNormalizeList(m?.forms || m?.manual_forms || m?.techniques || m?.recorded_techniques)),
    ...rowList
  ];
  model.martial_arts = tgmUniqueBy(formRaw.map((f, index) => {
    if (!tgmIsObject(f)) return null;
    const name = tgmFirst(f.name, f.form_name, f.technique_name, f.display_name, f.title, f.row_name);
    if (!name || /^(?:Learned form|Practice requirement recorded|Unnamed Form)$/i.test(name)) return null;
    return {
      martial_art_id: tgmFirst(f.martial_art_id, f.form_id, f.technique_id, f.id, `MARTIAL_${index + 1}`),
      name: tgmDisplayName(name),
      manual_name: tgmDisplayName(tgmFirst(f.manual_name, f.manual, f.parent_manual, f.source)),
      form_type: tgmFirst(f.form_type, f.type, f.row_type),
      activation: tgmFirst(f.activation, f.trigger, f.timing, f.action_type),
      cost: tgmFirst(f.cost, f.resource_cost),
      effect: tgmFirst(f.effect, f.effects, f.effect_summary, f.description, f.result, f.summary),
      duration: tgmFirst(f.duration),
      limits: tgmNormalizeList(f.limits || f.limit),
      linked_actions: tgmNormalizeList(f.linked_actions || f.action_ids || f.actions),
      display_summary: tgmFirst(f.display_summary, f.summary, f.description, f.effect),
      source_path: "Martial manual rows"
    };
  }).filter(Boolean), (f) => `${tgmTextKey(f.manual_name)}:${tgmTextKey(f.name)}`);
  if ((manuals.length || rowList.length) && !model.martial_arts.length) tgmAddDiag(model, "error", "MANUALS_DECLARED_NOT_RENDERABLE", "Manual/martial files exist but no readable martial forms normalized.", "Martial_Arts_and_Manuals/Martial_Manual_Display_Rows", "martial_arts");
}

function tgmNormalizeForged(model, parsed) {
  const registryBlock = tgmFindJsonBlock(parsed, [/Forged_Technique_Registry/i]);
  const registry = registryBlock?.data || {};
  const surface = tgmFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const raw = [...tgmListFrom(registry, ["forged_techniques", "installed_forged_techniques", "learned_forged_techniques", "forgedTechniques", "techniques", "entries", "items", "registry"]), ...tgmNormalizeList(surface.forged_techniques || surface.forgedTechniques)];
  model.forged_techniques = tgmUniqueBy(raw.map((f, index) => {
    if (!tgmIsObject(f)) return null;
    const name = tgmFirst(f.name, f.display_name, f.technique_name, f.forged_technique_name, f.title);
    if (!name) return null;
    return {
      forged_technique_id: tgmFirst(f.forged_technique_id, f.id, `FORGED_${tgmSlug(name).toUpperCase()}`),
      name: tgmDisplayName(name),
      source_spheres: tgmNormalizeList(f.source_spheres || f.spheres),
      complexity: tgmNum(f.complexity, null),
      activation: tgmFirst(f.activation, f.trigger, f.action_type),
      factory_combat_bucket: tgmFirst(f.factory_combat_bucket, f.bucket, f.action_type),
      cost: tgmFirst(f.cost, f.resource_cost),
      effect: tgmFirst(f.effect, f.effects, f.effect_summary, f.description, f.result, f.summary),
      drawback_or_limit: tgmFirst(f.drawback_or_limit, f.drawback, f.limit, f.limits),
      learned_at_CL: tgmNum(f.learned_at_CL || f.CL || f.cl, null),
      linked_actions: tgmNormalizeList(f.linked_actions || f.action_ids || f.actions),
      created_states: tgmNormalizeList(f.created_states || f.states),
      created_modifiers: tgmNormalizeList(f.created_modifiers || f.modifiers),
      source_path: registryBlock?.name || "Forged_Technique_Registry.json"
    };
  }).filter(Boolean), (f) => tgmTextKey(f.forged_technique_id || f.name));
  const hasExplicitEmpty = registryBlock && (Array.isArray(registry.forged_techniques) && registry.forged_techniques.length === 0 || Array.isArray(registry.installed_forged_techniques) && registry.installed_forged_techniques.length === 0 || tgmNum(registry.count, null) === 0);
  if (registryBlock && !model.forged_techniques.length && !hasExplicitEmpty) tgmAddDiag(model, "error", "FORGED_REGISTRY_UNREADABLE", "Forged registry exists but no readable forged techniques normalized.", registryBlock.name, "forged_techniques");
}

function tgmNormalizeComposite(model, parsed) {
  const comp = tgmFindJson(parsed, [/Composite_Action_Registry/i]) || {};
  const playbook = tgmFindJson(parsed, [/Combat_Playbook/i]) || {};
  const raw = [...tgmListFrom(comp, ["composites", "composite_actions", "playbooks", "entries", "items", "registry"]), ...tgmListFrom(playbook, ["composites", "composite_actions", "playbooks", "priority_table", "entries", "items"] )];
  model.composite_playbooks = tgmUniqueBy(raw.map((c, index) => {
    if (!tgmIsObject(c)) return null;
    const name = tgmFirst(c.name, c.display_name, c.playbook_name, c.composite_name, c.title, c.role);
    return {
      playbook_id: tgmFirst(c.playbook_id, c.composite_id, c.id, `COMP_${index + 1}`),
      name: tgmDisplayName(name || `Composite ${index + 1}`),
      role: tgmFirst(c.role, c.use_case, c.category),
      priority: tgmNum(c.priority, index + 1),
      trigger: tgmFirst(c.trigger, c.when, c.activation),
      components: tgmNormalizeList(c.components || c.sequence || c.steps || c.actions).map((x, i) => tgmIsObject(x) ? { component_id: tgmFirst(x.component_id, x.id, `COMPONENT_${i+1}`), action_id: tgmFirst(x.action_id, x.linked_action_id, x.source_action_id, x.id), linked_action_id: x.linked_action_id || null, source_action_id: x.source_action_id || null, name: tgmDisplayName(tgmFirst(x.name, x.action_name, x.display_name, x.action_id)), step_order: tgmNum(x.step_order || x.order, i+1), bucket: tgmFirst(x.bucket, x.action_type), timing: tgmFirst(x.timing, x.trigger), cost: tgmFirst(x.cost), resolution: tgmFirst(x.resolution, x.effect, x.result) } : { name: tgmDisplayName(x), step_order: i+1 }),
      temporal_feasibility: tgmFirst(c.temporal_feasibility, c.temporal_status),
      resource_feasibility: tgmFirst(c.resource_feasibility, c.resource_status),
      dao_i_ching_notes: tgmNormalizeList(c.dao_i_ching_notes || c.dao_notes),
      foundation_notes: tgmNormalizeList(c.foundation_notes),
      method_notes: tgmNormalizeList(c.method_notes),
      manual_notes: tgmNormalizeList(c.manual_notes),
      display_summary: tgmFirst(c.display_summary, c.summary, c.description),
      source_path: "Composite_Action_Registry/Combat_Playbook"
    };
  }).filter(Boolean), (c) => tgmTextKey(c.playbook_id || c.name));
}

function tgmNormalizeDaoIChing(model, parsed) {
  const block = tgmFindJsonBlock(parsed, [/I_Ching_Combat_Generation_Profile/i, /IChing_Combat_Generation_Profile/i, /Yijing_Combat_Generation_Profile/i, /Dao_Behavior_Profile/i, /Dao_I_Ching_Profile/i]);
  const data = block?.data || {};
  model.i_ching = {
    present: Boolean(block),
    profile_id: tgmFirst(data.profile_id, data.id),
    name: tgmFirst(data.name, data.profile_name, block?.name),
    trigrams: tgmNormalizeList(data.trigrams),
    hexagrams: tgmNormalizeList(data.hexagrams || data.hexagram_bias),
    generation_rules: tgmNormalizeList(data.generation_rules || data.active_hexagram_logic),
    combat_use: tgmNormalizeList(data.combat_use || data.line_shift_triggers),
    dao_behavior_notes: tgmNormalizeList(data.dao_behavior_notes || data.dao_behavior || data.combat_behavior),
    linked_composite_playbooks: tgmNormalizeList(data.linked_composite_playbooks),
    display_summary: tgmFirst(data.display_summary, data.summary),
    source_path: block?.name || null
  };
}

function tgmNormalizeMisc(model, parsed) {
  const equipment = tgmFindJson(parsed, [/Equipment_Ledger/i, /Equipment_Record/i]) || {};
  model.equipment = tgmListFrom(equipment, ["equipment", "items", "entries", "active_equipment_names"]).map((e, i) => typeof e === "string" ? { equipment_id: `EQ_${i+1}`, name: tgmDisplayName(e), type: "equipment", equipped: true, source_path: "Equipment_Ledger.json" } : { equipment_id: tgmFirst(e.equipment_id, e.id, `EQ_${i+1}`), name: tgmDisplayName(tgmFirst(e.name, e.display_name, e.item_name, `Equipment ${i+1}`)), type: tgmFirst(e.type, e.slot, "equipment"), equipped: e.equipped !== false, ac_contribution: tgmFirst(e.ac_contribution, e.ac), speed_effect: tgmFirst(e.speed_effect), actions: tgmNormalizeList(e.actions), modifiers: tgmNormalizeList(e.modifiers), procedures: tgmNormalizeList(e.procedures), source_rule: tgmFirst(e.source_rule, e.source), legacy_ids: tgmNormalizeList(e.legacy_ids), source_path: "Equipment_Ledger.json" });
  const states = tgmFindJson(parsed, [/State_Window_Lock_Audit/i, /Combat_State_Ledger_Template/i]) || {};
  model.states = tgmListFrom(states, ["states", "starting_state", "entries", "items"]).map((s, i) => tgmIsObject(s) ? { state_id: tgmFirst(s.state_id, s.id, `STATE_${i+1}`), name: tgmDisplayName(tgmFirst(s.name, s.display_name, s.state, `State ${i+1}`)), created_by: tgmFirst(s.created_by, s.source), duration: tgmFirst(s.duration), effect: tgmFirst(s.effect, s.summary, s.description), end_condition: tgmFirst(s.end_condition), stacking: tgmFirst(s.stacking), visibility: tgmFirst(s.visibility), source_path: "State/Combat Ledger" } : { state_id: `STATE_${i+1}`, name: tgmDisplayName(s), effect: "", source_path: "State/Combat Ledger" });
  model.modifiers = [];
  model.source_records = [];
  model.dao_aspects = tgmNormalizeList(tgmFindJson(parsed, [/Dao_Aspect_Immortal_Art_Profile/i])?.active_aspects).map((x, i) => ({ aspect_id: `DAO_${i+1}`, name: tgmDisplayName(typeof x === "string" ? x : x.name || x.aspect), status: "known", source: "Dao_Aspect_Immortal_Art_Profile.json", notes: [] }));
  model.immortal_arts = tgmListFrom(tgmFindJson(parsed, [/Immortal_Art_Registry/i]) || {}, ["arts", "entries", "items"]);
  model.spirit_companions = tgmListFrom(tgmFindJson(parsed, [/Spirit_Companion_Profile/i]) || {}, ["companions", "spirits", "entries", "items"]);
}

function tgmAdoptDirectCanonicalModel(raw = {}, parsed = [], pkg = {}) {
  if (!tgmIsObject(raw) || raw.schema_version !== TGM_MODEL_SCHEMA_V1) return null;
  const model = JSON.parse(JSON.stringify(raw));
  model.metadata = { ...(model.metadata || {}) };
  model.metadata.package_name = model.metadata.package_name || tgmFirst(pkg.name, pkg.package_name, "Imported Package");
  model.metadata.imported_at = model.metadata.imported_at || new Date().toISOString();
  model.metadata.source_package_files = model.metadata.source_package_files?.length ? model.metadata.source_package_files : tgmAllBlockNames(pkg);
  model.metadata.recognized_files = model.metadata.recognized_files?.length ? model.metadata.recognized_files : parsed.map((p) => p.name).filter(Boolean);
  model.metadata.source_map = model.metadata.source_map || tgmCanonicalFileMap(parsed);
  model.metadata.importer = TIANXIA_GM_HF05ZTM_CANONICAL_IMPORTER;
  model.diagnostics = Array.isArray(model.diagnostics) ? model.diagnostics : [];
  model.audit = tgmIsObject(model.audit) ? model.audit : {};
  model.identity = tgmIsObject(model.identity) ? model.identity : {};
  model.path_realm = tgmIsObject(model.path_realm) ? model.path_realm : {};
  model.combat_stats = tgmIsObject(model.combat_stats) ? model.combat_stats : {};
  model.ability_scores = tgmIsObject(model.ability_scores) ? model.ability_scores : {};
  model.saving_throws = Array.isArray(model.saving_throws) ? model.saving_throws : [];
  model.skills = Array.isArray(model.skills) ? model.skills : [];
  model.resources = tgmIsObject(model.resources) ? model.resources : {};
  ["spheres","talents","foundations","methods","manuals","martial_arts","recorded_arts","forged_techniques","dao_aspects","immortal_arts","spirit_companions","equipment","source_records","actions","bonus_actions","reactions","passives","procedures","states","modifiers","composite_playbooks"].forEach((key) => {
    model[key] = Array.isArray(model[key]) ? model[key] : [];
  });
  model.i_ching = tgmIsObject(model.i_ching) ? model.i_ching : {};
  model.metadata.character_id = model.metadata.character_id || tgmSlug(model.identity.display_name || model.identity.name || pkg.name || "tianxia_character");
  model.metadata.character_slug = model.metadata.character_slug || tgmSlug(model.identity.display_name || model.identity.name || model.metadata.character_id);
  tgmValidateModel(model);
  return model;
}

function tgmDirectCanonicalModelFromParsed(parsed = [], pkg = {}) {
  const block = tgmFindJsonBlock(parsed, [/^(?:.*[\/])?Tianxia_GM_Character_Model_v1\.json$/i, /^(?:.*[\/])?GM_Screen_Character_Model\.json$/i, /^(?:.*[\/])?Character_Model\.json$/i, /Tianxia_GM_Character_Model_v1/i]);
  const model = tgmAdoptDirectCanonicalModel(block?.data || null, parsed, pkg);
  if (model) {
    model.metadata.direct_model_source_path = block?.name || "Tianxia_GM_Character_Model_v1.json";
    model.metadata.direct_model_used = true;
  }
  return model;
}

function tgmValidateModel(model) {
  const errors = model.diagnostics.filter((d) => d.severity === "error");
  const warnings = model.diagnostics.filter((d) => d.severity === "warning" || d.severity === "warn");
  const hasRequired = model.identity.display_name && model.path_realm.path && model.path_realm.cultivation_level && model.combat_stats.ac !== null && model.combat_stats.hp_max !== null && model.combat_stats.speed_ft !== null && TGM_ABILITIES.every((ab) => model.ability_scores[ab]?.score !== null);
  model.audit.validation = {
    verdict: errors.length ? "FAIL_RELEASE_CONTRACT" : warnings.length || !hasRequired ? "PASS_IMPORTABLE_WITH_WARNINGS" : "PASS_RELEASE_READY",
    error_count: errors.length,
    warning_count: warnings.length,
    model_schema: TGM_MODEL_SCHEMA_V1,
    importer: TIANXIA_GM_HF05ZTM_CANONICAL_IMPORTER
  };
  return model.audit.validation;
}

function tgmBuildCanonicalModelFromPackage(pkg = {}) {
  if (pkg?.canonicalModel?.schema_version === TGM_MODEL_SCHEMA_V1) return pkg.canonicalModel;
  const blocks = tgmCanonicalBlocks(pkg);
  const parsed = tgmCanonicalParsed(pkg);
  const directModel = tgmDirectCanonicalModelFromParsed(parsed, pkg);
  if (directModel) return directModel;
  const model = {
    schema_version: TGM_MODEL_SCHEMA_V1,
    metadata: {
      character_id: "",
      character_slug: "",
      package_name: tgmFirst(pkg.name, pkg.package_name, "Imported Package"),
      package_version: tgmFirst(pkg.version, pkg.package_version, null),
      package_sha256: null,
      imported_at: new Date().toISOString(),
      source_package_files: tgmAllBlockNames(pkg),
      recognized_files: parsed.map((p) => p.name).filter(Boolean),
      unrecognized_files: tgmAllBlockNames(pkg).filter((name) => !parsed.some((p) => p.name === name)),
      source_map: tgmCanonicalFileMap(parsed),
      claim_boundary: null,
      importer: TIANXIA_GM_HF05ZTM_CANONICAL_IMPORTER
    },
    identity: {}, path_realm: {}, combat_stats: {}, ability_scores: {}, saving_throws: [], skills: [], resources: {}, background: {}, origin: {}, cultivation: {}, spheres: [], talents: [], foundations: [], methods: [], manuals: [], martial_arts: [], recorded_arts: [], forged_techniques: [], dao_aspects: [], i_ching: {}, immortal_arts: [], spirit_companions: [], equipment: [], source_records: [], actions: [], bonus_actions: [], reactions: [], passives: [], procedures: [], states: [], modifiers: [], composite_playbooks: [], audit: {}, diagnostics: []
  };
  try {
    tgmNormalizeIdentity(model, parsed, pkg);
    tgmNormalizePathRealm(model, parsed);
    tgmNormalizeCombat(model, parsed);
    tgmNormalizeAbilities(model, parsed);
    tgmNormalizeResources(model, parsed);
    tgmNormalizeSpheresTalents(model, parsed);
    tgmNormalizeFoundation(model, parsed);
    tgmNormalizeMethods(model, parsed);
    tgmNormalizeActions(model, parsed);
    tgmNormalizeManuals(model, parsed);
    tgmNormalizeForged(model, parsed);
    tgmNormalizeComposite(model, parsed);
    tgmNormalizeDaoIChing(model, parsed);
    tgmNormalizeMisc(model, parsed);
    tgmValidateModel(model);
  } catch (error) {
    tgmAddDiag(model, "error", "MODEL_NORMALIZATION_EXCEPTION", error?.message || String(error), null, "normalization");
    tgmValidateModel(model);
  }
  return model;
}

function tgmModelActionsFlat(model = {}) { return [...(model.actions||[]), ...(model.bonus_actions||[]), ...(model.reactions||[]), ...(model.passives||[])]; }
function tgmOldActionFromModel(action = {}) { return { ...action, id: action.action_id, action_id: action.action_id, action_name: action.display_name || action.name, name: action.display_name || action.name, display_name: action.display_name || action.name, action_type: action.bucket, type: action.bucket, source: action.source_name || action.source_type, source_type: action.source_type, activation: action.activation_or_trigger, trigger: action.activation_or_trigger, cost: action.cost, target: action.target_or_area, range: action.range, damage_or_effect: action.damage || action.effect, effect: action.effect, duration: action.duration, limit: action.limit, temporal_feasibility: action.temporal_feasibility }; }
function tgmOldManualFromModel(manual = {}, forms = []) { const ownForms = forms.filter((f) => tgmTextKey(f.manual_name) === tgmTextKey(manual.name)); return { ...manual, id: manual.manual_id, name: manual.name, manual_name: manual.name, display_name: manual.name, description: manual.contents_summary || manual.display_summary || "", forms: ownForms, manual_forms: ownForms, techniques: ownForms, source_path: manual.source_path }; }
function tgmModelToSheetData(model = {}, fallback = {}) {
  const saves = {}; (model.saving_throws || []).forEach((s) => { saves[s.ability] = s.bonus; });
  const skills = {}; (model.skills || []).forEach((s) => { skills[s.name] = s.bonus; });
  const abilityScores = {}; const abilityModifiers = {}; TGM_ABILITIES.forEach((ab) => { abilityScores[ab] = model.ability_scores?.[ab]?.score; abilityModifiers[ab] = model.ability_scores?.[ab]?.modifier; });
  const actions = tgmModelActionsFlat(model).map(tgmOldActionFromModel);
  const martialArtsLearned = (model.manuals || []).map((m) => tgmOldManualFromModel(m, model.martial_arts || []));
  const forgedTechniques = (model.forged_techniques || []).map((f) => ({ ...f, id: f.forged_technique_id, display_name: f.name, name: f.name, action_type: f.factory_combat_bucket, description: f.effect, effect: f.effect, cost: f.cost }));
  const foundations = (model.foundations || []).map((f) => ({ ...f, id: f.foundation_id, display_name: f.name, foundation_name: f.name, foundation_family: f.family, grade: f.grade_or_depth, summary: f.display_summary, mechanical_benefits: f.benefits, burdens: f.burdens_or_risks }));
  return sanitizeSheetCollections({
    ...fallback,
    canonicalModel: model,
    characterModelSchema: model.schema_version,
    name: model.identity.display_name || fallback.name,
    displayName: model.identity.display_name || fallback.displayName,
    characterId: model.metadata.character_id || fallback.characterId,
    path: model.path_realm.path || fallback.path,
    realm: model.path_realm.realm || fallback.realm,
    cultivationLevel: model.path_realm.cultivation_level ?? fallback.cultivationLevel,
    proficiencyBonus: model.path_realm.proficiency_bonus ?? fallback.proficiencyBonus,
    ac: model.combat_stats.ac ?? fallback.ac,
    hp: { current: model.combat_stats.hp_current ?? fallback.hpCurrent ?? fallback.hp?.current ?? fallback.hp?.max ?? fallback.hp?.maximum ?? null, max: model.combat_stats.hp_max ?? fallback.hpMax ?? fallback.hp?.max ?? fallback.hp?.maximum ?? null, maximum: model.combat_stats.hp_max ?? fallback.hpMax ?? fallback.hp?.maximum ?? fallback.hp?.max ?? null },
    hpMax: model.combat_stats.hp_max ?? fallback.hpMax,
    hpCurrent: model.combat_stats.hp_current ?? fallback.hpCurrent,
    speed: model.combat_stats.speed_ft ?? fallback.speed,
    stats: { ...(fallback.stats || {}), AC: model.combat_stats.ac ?? fallback.ac ?? fallback.stats?.AC, HP: model.combat_stats.hp_max ?? fallback.hpMax ?? fallback.stats?.HP, Speed: model.combat_stats.speed_ft ?? fallback.speed ?? fallback.stats?.Speed },
    initiative: model.combat_stats.initiative_bonus ?? fallback.initiative,
    resource: model.resources?.primary?.name || fallback.resource,
    resourceMax: model.resources?.primary?.max ?? fallback.resourceMax,
    resourceCurrent: model.resources?.primary?.current ?? fallback.resourceCurrent,
    abilityScores, abilityModifiers, saves, skills,
    senses: model.combat_stats.senses?.length ? model.combat_stats.senses : fallback.senses || [],
    resistances: model.combat_stats.resistances || fallback.resistances || [],
    immunities: model.combat_stats.immunities || fallback.immunities || [],
    vulnerabilities: model.combat_stats.vulnerabilities || fallback.vulnerabilities || [],
    spheres: model.spheres?.length ? model.spheres.map((s) => s.name || s.sphere_name || s) : fallback.spheres || [],
    talents: model.talents?.length ? model.talents : fallback.talents || [],
    actions: actions.length ? actions : fallback.actions || [],
    passives: model.passives?.length ? model.passives.map(tgmOldActionFromModel) : fallback.passives || [],
    martialArtsLearned: martialArtsLearned.length ? martialArtsLearned : fallback.martialArtsLearned || [],
    forgedTechniques: forgedTechniques.length ? forgedTechniques : fallback.forgedTechniques || [],
    foundations: foundations.length ? foundations : fallback.foundations || [],
    methods: model.methods?.length ? model.methods : fallback.methods || [],
    equipment: model.equipment?.length ? model.equipment : fallback.equipment || [],
    states: model.states?.length ? model.states : fallback.states || [],
    diagnostics: model.diagnostics || fallback.diagnostics || []
  });
}

function tgmModelIntegrity(model = {}) {
  const facets = [
    ["actions", "Actions", tgmModelActionsFlat(model).length],
    ["composites", "Composite Playbook", (model.composite_playbooks||[]).length],
    ["forged", "Forged Techniques", (model.forged_techniques||[]).length],
    ["manuals", "Martial Manuals", (model.manuals||[]).length],
    ["foundation", "Foundation", (model.foundations||[]).length],
    ["talents", "Talents", (model.talents||[]).length]
  ];
  return { model_schema: model.schema_version, verdict: model.audit?.validation?.verdict || "UNKNOWN", facets: facets.map(([key,label,loaded]) => ({ key, label, loaded, status: loaded ? "ok" : "absent" })), diagnostics: model.diagnostics || [] };
}
function tgmModelDiagnosticsHtml(model = {}) {
  const validation = model.audit?.validation || {};
  const rows = (model.diagnostics || []).map((d) => `<tr><td>${escapeHtml(String(d.severity || "" ).toUpperCase())}</td><td>${escapeHtml(d.code || "")}</td><td>${escapeHtml(d.message || "")}</td><td>${escapeHtml(d.source_path || "")}</td></tr>`).join("");
  return `<section class="sheet-section"><h4>Canonical Import Model</h4><p><strong>${escapeHtml(validation.verdict || "UNKNOWN")}</strong> — ${escapeHtml(model.schema_version || "")}</p><div class="sheet-detail-grid"><article class="sheet-detail-card"><strong>Actions</strong><p>${tgmModelActionsFlat(model).length}</p></article><article class="sheet-detail-card"><strong>Composites</strong><p>${(model.composite_playbooks||[]).length}</p></article><article class="sheet-detail-card"><strong>Forged</strong><p>${(model.forged_techniques||[]).length}</p></article><article class="sheet-detail-card"><strong>Manuals</strong><p>${(model.manuals||[]).length}</p></article><article class="sheet-detail-card"><strong>Foundation</strong><p>${(model.foundations||[]).length}</p></article><article class="sheet-detail-card"><strong>Talents</strong><p>${(model.talents||[]).length}</p></article></div>${rows ? `<table class="compact-table"><thead><tr><th>Severity</th><th>Code</th><th>Message</th><th>Source</th></tr></thead><tbody>${rows}</tbody></table>` : `<p class="sheet-description">No canonical model diagnostics.</p>`}</section>`;
}

const tgmAnalyzePackageTextBefore = analyzePackageText;
analyzePackageText = function analyzePackageTextHf05ztm(text, preferredName = "", version = "") {
  const analysis = tgmAnalyzePackageTextBefore(text, preferredName, version);
  const model = tgmBuildCanonicalModelFromPackage(analysis);
  analysis.canonicalModel = model;
  analysis.modelSchema = model.schema_version;
  analysis.characterId = model.metadata.character_id || analysis.characterId;
  analysis.name = model.identity.display_name || analysis.name;
  analysis.path = model.path_realm.path || analysis.path;
  analysis.realm = model.path_realm.realm || analysis.realm;
  analysis.primary = model.spheres?.[0]?.name || analysis.primary;
  analysis.sheetData = tgmModelToSheetData(model, analysis.sheetData || {});
  analysis.readiness = model.audit?.validation?.verdict || analysis.readiness;
  return analysis;
};

const tgmBuildCharacterSheetDataBefore = buildCharacterSheetData;
buildCharacterSheetData = function buildCharacterSheetDataHf05ztm(pkg) {
  const fallback = tgmBuildCharacterSheetDataBefore(pkg);
  const model = tgmBuildCanonicalModelFromPackage(pkg);
  return tgmModelToSheetData(model, fallback);
};

const tgmCompactSavedPackageBefore = compactSavedPackage;
compactSavedPackage = function compactSavedPackageHf05ztm(pkg) {
  const model = tgmBuildCanonicalModelFromPackage(pkg);
  const saved = tgmCompactSavedPackageBefore({ ...pkg, canonicalModel: model, sheetData: tgmModelToSheetData(model, pkg.sheetData || {}) });
  saved.canonicalModel = model;
  saved.save_schema = TGM_COMPACT_SAVE_SCHEMA_V1;
  saved.modelSchema = model.schema_version;
  saved.modelVerdict = model.audit?.validation?.verdict || "UNKNOWN";
  saved.name = model.identity.display_name || saved.name;
  saved.characterId = model.metadata.character_id || saved.characterId;
  saved.sourceEvidence = { package_sha256: model.metadata.package_sha256, source_file_map: model.metadata.source_map, diagnostics: model.diagnostics };
  return saved;
};

const tgmCompositeRegistryDataBefore = compositeRegistryDataFromPackage;
compositeRegistryDataFromPackage = function compositeRegistryDataFromPackageHf05ztm(pkg, sheet = {}) {
  const base = tgmCompositeRegistryDataBefore(pkg, sheet);
  const model = tgmBuildCanonicalModelFromPackage(pkg);
  if (!model.composite_playbooks?.length) return base;
  const actions = tgmModelActionsFlat(model).map(tgmOldActionFromModel);
  const composites = model.composite_playbooks.map((c) => ({ ...c, id: c.playbook_id, composite_id: c.playbook_id, display_name: c.name, name: c.name, priority: c.priority, role: c.role, source: c.source_path, components: c.components }));
  return {
    ...base,
    hasDeclaredComposites: true,
    composites,
    sourceFiles: { ...(base.sourceFiles || {}), canonicalModel: true },
    daoProfile: base.daoProfile || (model.i_ching?.present ? model.i_ching : null),
    registries: { ...(base.registries || {}), actionMap: makeAnyRegistryMap(actions), forgedMap: makeAnyRegistryMap(model.forged_techniques || []) }
  };
};

const tgmImportIntegrityBefore = importIntegrityForPackage;
importIntegrityForPackage = function importIntegrityForPackageHf05ztm(pkg = {}, sheet = {}, playbook = null) {
  const base = tgmImportIntegrityBefore(pkg, sheet, playbook);
  const model = tgmBuildCanonicalModelFromPackage(pkg);
  const counts = { actions: tgmModelActionsFlat(model).length, composites: (model.composite_playbooks||[]).length, forged: (model.forged_techniques||[]).length, manuals: (model.manuals||[]).length, foundation: (model.foundations||[]).length, talents: (model.talents||[]).length };
  const byKey = Object.fromEntries((base.facets || []).map((f) => [f.key, f]));
  const keyMap = { actions: "actions", composites: "composites", forged: "forged", manuals: "manuals", foundation: "foundation", talents: "talents" };
  Object.entries(counts).forEach(([k, count]) => {
    const facet = byKey[keyMap[k]];
    if (facet && count > facet.loaded) {
      facet.loaded = count;
      facet.status = "ok";
      facet.message = `${facet.label}: loaded ${count} from canonical model.`;
      facet.notes = [...(facet.notes || []), "Canonical model supplied normalized entries."];
    }
  });
  base.model = { schema: model.schema_version, verdict: model.audit?.validation?.verdict, diagnostics: model.diagnostics, counts };
  return base;
};

const tgmRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05ztm(pkg, notes = {}) {
  let html = tgmRenderVisualCharacterSheetBefore(pkg, notes);
  const model = tgmBuildCanonicalModelFromPackage(pkg);
  const panel = tgmModelDiagnosticsHtml(model);
  if (html.includes('data-sheet-panel="diagnostics"')) {
    html = html.replace(/(<div class="sheet-tab-panel" data-sheet-panel="diagnostics">)/, `$1${panel}`);
  } else {
    html += panel;
  }
  return html;
};

const tgmPackageSelectLabelBefore = packageSelectLabel;
packageSelectLabel = function packageSelectLabelHf05ztm(item = {}) {
  const model = item?.canonicalModel;
  if (model?.identity?.display_name) {
    const cl = model.path_realm?.cultivation_level ? `CL${model.path_realm.cultivation_level}` : "CL?";
    const realm = model.path_realm?.realm || item.realm || "Realm unclear";
    return `${model.identity.display_name} — ${cl} ${realm}`;
  }
  return tgmPackageSelectLabelBefore(item);
};

const tgmRenderPackageAnalysisBefore = renderPackageAnalysis;
renderPackageAnalysis = function renderPackageAnalysisHf05ztm(analysis) {
  tgmRenderPackageAnalysisBefore(analysis);
  if (!analysis?.canonicalModel || !$('packageAnalysis')) return;
  const model = analysis.canonicalModel;
  $('packageAnalysis').insertAdjacentHTML('beforeend', `<div class="status-grid"><div class="status-item ${model.audit?.validation?.verdict === 'PASS_RELEASE_READY' ? 'pass' : 'warn'}"><strong>${escapeHtml(model.audit?.validation?.verdict || 'UNKNOWN')}</strong> Canonical Model</div><div class="status-item pass"><strong>${escapeHtml(model.schema_version)}</strong> Unified importer</div></div>`);
};


/* ========================================================================
 * HF05ZUC-R1A — Universal Character View Model and Composite Runtime Renderer
 * Adds Tianxia_GM_Character_View_Model_v2 above the legacy/v1 importer.
 * ===================================================================== */
const ZUC_PATCH_ID = "HF05ZUC-R1A";
const ZUC_VIEW_SCHEMA = "Tianxia_GM_Character_View_Model_v2";
const ZUC_COMPACT_SAVE_SCHEMA = "Tianxia_GM_Compact_Save_v2";
const ZUC_ACCEPTED_SURFACE_PATTERNS = [
  /Tianxia_GM_Character_View_Model_v2/i,
  /Tianxia_GM_Character_Model_v1/i,
  /GM_Screen_Character_Model/i,
  /Character_Model/i,
  /Character_Import_Surface/i,
  /Normalized_Sheet/i,
  /Character_Sheet\.md/i,
  /Character_Stat_Block\.md/i,
  /GM_SCREEN_HEADER\.md/i,
  /Armor_Class_Calculation_Ledger/i,
  /Skill_Proficiency_Ledger/i,
  /Character_Action_Registry/i,
  /Basic_Action_Registry/i,
  /Action_Provenance_Ledger/i,
  /Action_Coverage_Matrix/i,
  /Visible_Action_Economy_Ledger/i,
  /Complete_Action_Surface/i,
  /GM_Screen_Display_Rows/i,
  /GM_Screen_Projection_Rows/i,
  /Composite_Action_Registry/i,
  /Combat_Playbook/i,
  /Composite_Description_Ledger/i,
  /Temporal_Feasibility_Registry/i,
  /Martial_Arts_and_Manuals/i,
  /Martial_Manual_Display_Rows/i,
  /Martial_Manual_Rules_Ledger/i,
  /Foundation_Detail_Ledger/i,
  /Foundation_Display_Row/i,
  /Cultivation_Method_Profile|Method_Profile/i,
  /Dao_Combat_Behavior_Profile/i,
  /Dao_Profile/i,
  /I_Ching_Combat_Generation_Profile|IChing_Combat_Generation_Profile|Yijing_Combat_Generation_Profile/i,
  /Sphere_Acquisition_Ledger|Sphere_Free_Talent_Grant_Ledger/i,
  /Talent_Source_Ledger/i,
  /Canonical_Talent_Ledger/i,
  /Level_Talent_Ledger/i,
  /Trained_Choice_Ledger/i,
  /AI_Character_Generation_Profile/i,
  /Background_Origin_Profile|Background_Record/i,
  /Origin_Insight_Ledger/i,
  /Equipment_Ledger/i,
  /Limited_Resource_Counter_Inventory/i,
  /State_Window_Lock_Audit|Combat_State_Ledger_Template/i
];

function zucIsObject(value) { return Boolean(value) && typeof value === "object" && !Array.isArray(value); }
function zucArray(value) { return Array.isArray(value) ? value.filter((x) => x !== null && x !== undefined && x !== "") : (value === null || value === undefined || value === "" ? [] : [value]); }
function zucText(value, fallback = "") {
  if (value === null || value === undefined) return fallback;
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return zucValueText(value, fallback);
}
function zucNum(value, fallback = null) {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "number") return Number.isFinite(value) ? value : fallback;
  const n = Number(String(value).replace(/[^0-9.+-]/g, ""));
  return Number.isFinite(n) ? n : fallback;
}
function zucFirst(...values) {
  for (const value of values.flat()) {
    if (value === null || value === undefined) continue;
    if (typeof value === "object") {
      if (Array.isArray(value) && value.length) return value;
      if (!Array.isArray(value) && Object.keys(value).length) return value;
      continue;
    }
    const text = String(value).trim();
    if (text && !/^(?:null|undefined|none|n\/a|—|-)$/.test(text.toLowerCase())) return value;
  }
  return "";
}
function zucSlug(value = "") { return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, ""); }
function zucKey(value = "") { return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").replace(/\s+/g, " ").trim(); }
function zucDisplay(value = "") {
  const raw = String(value || "").replace(/_/g, " ").replace(/\s+/g, " ").trim();
  if (!raw) return "";
  try { return typeof polishMachineReadableText === "function" ? polishMachineReadableText(raw) : raw; } catch { return raw; }
}
function zucHtml(value) { return escapeHtml(zucValueText(value, "Not recorded")); }
function zucValueText(value, fallback = "Not recorded", max = 900) {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    const joined = value.map((v) => zucValueText(v, "", Math.max(120, Math.floor(max / Math.max(value.length, 1))))).filter(Boolean).join("; ");
    return joined || fallback;
  }
  if (zucIsObject(value)) {
    const direct = zucFirst(value.display_name, value.name, value.title, value.label, value.summary, value.description, value.effect, value.effect_summary, value.text, value.value);
    if (direct && typeof direct !== "object") return String(direct);
    const parts = Object.entries(value).filter(([, v]) => v !== null && v !== undefined && v !== "" && !(Array.isArray(v) && !v.length)).slice(0, 10).map(([k, v]) => `${zucDisplay(k)}: ${zucValueText(v, "", 160)}`).filter(Boolean);
    const text = parts.join("; ");
    return text || fallback;
  }
  return String(value || fallback);
}
function zucList(value, keys = []) {
  if (Array.isArray(value)) return value.filter((x) => x !== null && x !== undefined && x !== "");
  if (!zucIsObject(value)) return value ? [value] : [];
  for (const key of keys) if (Array.isArray(value[key])) return value[key].filter(Boolean);
  try {
    const l = listFromJsonData(value, keys);
    if (Array.isArray(l) && l.length) return l;
  } catch {}
  return [];
}
function zucUnique(items = [], keyFn = (x) => JSON.stringify(x)) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    if (item === null || item === undefined) continue;
    const key = keyFn(item) || JSON.stringify(item);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}
function zucBlockName(block = {}) { return String(block.name || block.path || block.file || "").replace(/\\/g, "/"); }
function zucBlocks(pkg = {}) {
  if (Array.isArray(pkg?.blocks) && pkg.blocks.length) return pkg.blocks;
  if (pkg?.rawText) { try { return parseFileBlocks(String(pkg.rawText || "")); } catch { return []; } }
  return [];
}
function zucParsed(pkg = {}) { try { return parseJsonPackageBlocks(zucBlocks(pkg)); } catch { return []; } }
function zucFindBlock(parsed = [], patterns = []) {
  const pats = Array.isArray(patterns) ? patterns : [patterns];
  return parsed.find((entry) => pats.some((p) => p.test(zucBlockName(entry)))) || null;
}
function zucFindJson(parsed = [], patterns = []) { return zucFindBlock(parsed, patterns)?.data || null; }
function zucAllNames(pkg = {}) { return zucBlocks(pkg).map(zucBlockName).filter(Boolean); }
function zucAddDiag(model, severity, code, message, source = "", facet = "") {
  model.diagnostics.push({ severity, code, message, source, facet, patch: ZUC_PATCH_ID });
}
function zucSourceDiscovery(parsed = [], pkg = {}) {
  const names = zucAllNames(pkg);
  const recognized = [];
  const map = {};
  for (const name of names) {
    const matched = ZUC_ACCEPTED_SURFACE_PATTERNS.some((p) => p.test(name));
    if (matched) recognized.push(name);
    if (matched) map[name] = { recognized_by: ZUC_PATCH_ID, parsed_json: parsed.some((p) => p.name === name), basename: name.split("/").pop() };
  }
  return { recognized_files: recognized, unrecognized_files: names.filter((n) => !recognized.includes(n)), source_map: map };
}
function zucDirectViewModelV2(parsed = []) {
  const block = parsed.find((entry) => {
    const data = entry?.data;
    return zucIsObject(data) && (data.schema === ZUC_VIEW_SCHEMA || data.schema_version === ZUC_VIEW_SCHEMA);
  });
  if (!block?.data) return null;
  const clone = JSON.parse(JSON.stringify(block.data));
  clone.schema = ZUC_VIEW_SCHEMA;
  clone.schema_version = ZUC_VIEW_SCHEMA;
  clone.source_package = clone.source_package || {};
  clone.diagnostics = Array.isArray(clone.diagnostics) ? clone.diagnostics : [];
  clone.source_package.direct_view_model_source = block.name;
  clone.source_package.importer = ZUC_PATCH_ID;
  return clone;
}
function zucActionListFromRegistry(reg = {}) {
  return [
    ...zucList(reg, ["actions", "registry", "rows", "items"]),
    ...zucList(reg.basic_actions),
    ...zucList(reg.sphere_talent_actions),
    ...zucList(reg.manual_technique_actions),
    ...zucList(reg.forged_technique_actions),
    ...zucList(reg.composite_actions),
    ...zucList(reg.fallback_actions)
  ];
}
function zucActionId(a = {}, index = 0) { return zucText(zucFirst(a.action_id, a.id, a.linked_action_id, a.source_action_id, a.action_ref, a.ref, a.fallback_action_ref, `ACT_${index + 1}`)); }
function zucEconomy(a = {}) {
  const raw = zucText(zucFirst(a.economy_bucket, a.action_economy, a.action_type, a.type, a.bucket, a.row_type, a.activation, a.timing_window)).toLowerCase();
  if (/bonus/.test(raw)) return "bonus action";
  if (/reaction/.test(raw)) return "reaction";
  if (/passive|always|static/.test(raw)) return "passive";
  if (/free/.test(raw)) return "free/part of action";
  if (/downtime|training|procedure|craft/.test(raw)) return "procedure";
  return raw ? zucDisplay(raw) : "Not recorded";
}
function zucNormalizeAction(a = {}, index = 0, source = "action surface") {
  if (!zucIsObject(a)) return null;
  const id = zucActionId(a, index);
  const name = zucDisplay(zucFirst(a.display_name, a.action_name, a.name, a.title, a.row_name, a.fallback_role, id));
  const effect = zucText(zucFirst(a.effect_summary, a.effect, a.damage_or_effect, a.resolution, a.result, a.description, a.full_rules_text, a.gm_screen_text, a.fixed_talent_expression));
  return {
    action_id: id,
    name,
    display_name: name,
    row_type: zucText(zucFirst(a.row_type, a.classification, a.type, "action")),
    economy: zucEconomy(a),
    timing: zucText(zucFirst(a.timing_window, a.timing, a.activation, a.trigger, a.actor_window)),
    cost: zucText(zucFirst(a.cost, a.resource_cost, a.resource_check, a.resource_name)),
    range: zucText(zucFirst(a.range, a.reach)),
    target: zucText(zucFirst(a.target, a.targeting?.target_rule, a.target_or_area)),
    roll_or_save: zucText(zucFirst(a.roll_or_save, a.roll_save, a.attack_or_save, a.check, a.save, a.roll)),
    effect,
    success_effect: zucText(zucFirst(a.success_effect, a.effect_summary, a.effect, a.damage_or_effect, a.resolution, a.legal_resolution, effect)),
    failure_or_limit: zucText(zucFirst(a.failure_or_limit, a.failure, a.miss, a.limit, a.limits)),
    duration: zucText(zucFirst(a.duration)),
    limit: zucText(zucFirst(a.limit, a.limits)),
    counterplay: zucText(zucFirst(a.counterplay, a.counterplay_panel)),
    source_spheres: zucArray(zucFirst(a.source_spheres, a.spheres, a.source_spheres_display)),
    source_talents: zucArray(zucFirst(a.source_talent_names, a.source_talents_display, a.source_talent_ids)),
    linked_actions: zucArray(zucFirst(a.linked_actions, a.linked_action_ids, a.action_ids, a.act_action_refs)),
    source,
    raw: a
  };
}
function zucActionsById(actions = []) {
  const map = new Map();
  for (const a of actions) {
    const ids = [a.action_id, a.id, a.name, a.display_name, ...(a.linked_actions || [])].map(zucKey).filter(Boolean);
    ids.forEach((id) => { if (!map.has(id)) map.set(id, a); });
  }
  return map;
}
function zucNormalizeActions(parsed = [], model = null) {
  const reg = zucFindJson(parsed, [/Character_Action_Registry/i]) || {};
  const basicReg = zucFindJson(parsed, [/Basic_Action_Registry/i]) || {};
  const surface = zucFindJson(parsed, [/Complete_Action_Surface/i]) || {};
  const importSurface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const display = zucFindJson(parsed, [/GM_Screen_Display_Rows/i]) || {};
  const projection = zucFindJson(parsed, [/GM_Screen_Projection_Rows/i]) || {};
  const raw = [
    ...zucActionListFromRegistry(reg).map((x) => [x, "Character_Action_Registry.json"]),
    ...zucActionListFromRegistry(basicReg).map((x) => [x, "Basic_Action_Registry.json"]),
    ...zucList(surface, ["actions", "rows", "registry"]).map((x) => [x, "Complete_Action_Surface.json"]),
    ...zucList(importSurface.actions).map((x) => [x, "Character_Import_Surface.json/actions"]),
    ...zucList(importSurface.gm_screen_action_rows).map((x) => [x, "Character_Import_Surface.json/gm_screen_action_rows"]),
    ...zucList(display, ["rows"]).filter((r) => /action|manual|composite|reaction|bonus|passive/i.test(zucText(zucFirst(r.row_type, r.classification, r.action_type)))).map((x) => [x, "GM_Screen_Display_Rows.json"]),
    ...zucList(projection, ["rows"]).filter((r) => /action|manual|composite|reaction|bonus|passive/i.test(zucText(zucFirst(r.row_type, r.classification, r.action_type)))).map((x) => [x, "GM_Screen_Projection_Rows.json"])
  ];
  const normalized = raw.map(([a, src], i) => zucNormalizeAction(a, i, src)).filter((a) => a && a.name && a.effect);
  const richest = new Map();
  function score(a) { return [a.effect, a.timing, a.cost, a.range, a.target, a.roll_or_save, a.counterplay, a.limit].filter(Boolean).join(" ").length; }
  normalized.forEach((a) => {
    const key = zucKey(a.action_id || a.name);
    if (!richest.has(key) || score(a) > score(richest.get(key))) richest.set(key, a);
  });
  const out = Array.from(richest.values());
  if (model && !out.length) zucAddDiag(model, "warning", "ACTIONS_MISSING", "No usable action rows were normalized from accepted action surfaces.", "action surfaces", "actions");
  return out;
}
function zucNormalizeIdentityCore(parsed = [], oldModel = {}, oldSheet = {}, pkg = {}, model = null) {
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const identityFile = zucFindJson(parsed, [/Character_Identity/i, /Character_Core/i]) || {};
  const ai = zucFindJson(parsed, [/AI_Character_Generation_Profile/i]) || {};
  const char = zucFirst(surface.character, normalized.character, identityFile.character, identityFile.identity, ai.character_core, {});
  const name = zucDisplay(zucFirst(char.name, char.display_name, surface.name, normalized.name, oldModel.identity?.display_name, oldSheet.name, pkg.name, "Unnamed Tianxia Character"));
  const cl = zucNum(zucFirst(char.CL, char.cl, char.level, surface.CL, surface.level, normalized.CL, normalized.level, oldModel.path_realm?.cultivation_level, oldSheet.cultivationLevel), null);
  const pb = zucNum(zucFirst(char.PB, char.pb, char.proficiency_bonus, surface.PB, surface.proficiency_bonus, normalized.PB, normalized.proficiency_bonus, oldModel.path_realm?.proficiency_bonus, oldSheet.proficiencyBonus), cl ? Math.ceil(cl / 4) + 1 : null);
  return {
    name,
    display_name: name,
    character_id: zucText(zucFirst(char.character_id, char.package_id, char.slug, surface.character_id, normalized.character_id, oldModel.metadata?.character_id, zucSlug(name))),
    concept: zucText(zucFirst(char.concept, char.concept_summary, char.role, surface.description, normalized.description, oldModel.identity?.concept_summary, oldSheet.description)),
    species: zucText(zucFirst(char.species, surface.species, normalized.species, oldModel.identity?.species, "Human")),
    path: zucText(zucFirst(char.path, surface.path, normalized.path, oldModel.path_realm?.path, oldSheet.path)),
    realm: zucText(zucFirst(char.realm, surface.realm, normalized.realm, oldModel.path_realm?.realm, oldSheet.realm)),
    CL: cl,
    PB: pb
  };
}
function zucNormalizeCoreStats(parsed = [], oldModel = {}, oldSheet = {}, identity = {}, model = null) {
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const acLedger = zucFindJson(parsed, [/Armor_Class_Calculation_Ledger/i]) || surface.ac_calculation || normalized.ac_calculation || {};
  const skillLedger = zucFindJson(parsed, [/Skill_Proficiency_Ledger/i]) || {};
  const stats = [surface.stats, normalized.stats, surface.combat, normalized.combat, surface.stats?.combat, normalized.stats?.combat, oldSheet.stats, oldSheet.combat].filter(zucIsObject);
  const pick = (keys) => { for (const s of stats) for (const k of keys) if (s[k] !== undefined && s[k] !== null && s[k] !== "") return s[k]; return ""; };
  const hpObj = zucIsObject(surface.hp) ? surface.hp : (zucIsObject(normalized.hp) ? normalized.hp : {});
  const acObj = zucIsObject(surface.ac) ? surface.ac : (zucIsObject(normalized.ac) ? normalized.ac : {});
  const oldAc = oldSheet.ac || {};
  const oldHp = oldSheet.hp || {};
  const ac = zucNum(zucFirst(surface.ac_active, surface.ac, normalized.ac_active, normalized.ac, acObj.current, acObj.base, acLedger.final_ac, acLedger.ac, pick(["ac", "AC", "final_ac", "armor_class"]), oldModel.combat_stats?.ac, oldAc.current, oldAc.base, oldAc.ac), null);
  const hpMax = zucNum(zucFirst(surface.hp_max, normalized.hp_max, hpObj.max, hpObj.maximum, surface.hp, normalized.hp, pick(["hp", "HP", "hp_max", "max_hp", "hit_points"]), oldModel.combat_stats?.hp_max, oldHp.max, oldHp.maximum, oldHp.current), null);
  const hpCur = zucNum(zucFirst(surface.hp_current, normalized.hp_current, hpObj.current, oldModel.combat_stats?.hp_current, oldHp.current, hpMax), hpMax);
  const speed = zucNum(zucFirst(surface.speed_ft, surface.speed, normalized.speed_ft, normalized.speed, pick(["speed", "Speed", "speed_ft"]), oldModel.combat_stats?.speed_ft, oldSheet.speed?.walk, oldSheet.speed), null);
  const attackBonus = zucNum(zucFirst(surface.technique_attack_bonus, normalized.technique_attack_bonus, pick(["technique_attack_bonus", "attack_bonus", "Attack"]), oldSheet.cultivationAttackBonus), null);
  const saveDc = zucNum(zucFirst(surface.save_dc, normalized.save_dc, pick(["save_dc", "Save DC"]), oldSheet.cultivationSaveDc), null);
  const primaryResourceSource = zucFirst(surface.resources?.primary, normalized.resources?.primary, surface.resource, normalized.resource, oldModel.resources?.primary, {});
  const primaryName = zucText(zucFirst(surface.primary_resource, surface.primary_resource_name, normalized.primary_resource_name, primaryResourceSource.name, oldModel.resources?.primary?.name, oldSheet.resource, identity.path === "Body Refining" ? "Stamina" : identity.path === "Spirit Awakening" ? "Resonance" : "Qi"));
  const primaryMax = zucNum(zucFirst(surface.primary_resource_max, normalized.primary_resource_max, primaryResourceSource.max, primaryResourceSource.maximum, primaryResourceSource.value, oldModel.resources?.primary?.max, oldSheet.resourceMax), null);
  const primaryCur = zucNum(zucFirst(surface.primary_resource_current, normalized.primary_resource_current, primaryResourceSource.current, oldModel.resources?.primary?.current, oldSheet.resourceCurrent, primaryMax), primaryMax);
  const abilityScores = surface.ability_scores || surface.abilities || normalized.ability_scores || normalized.abilities || oldSheet.abilityScores || {};
  const abilityMods = surface.ability_modifiers || normalized.ability_modifiers || oldSheet.abilityModifiers || {};
  const saves = surface.saves || normalized.saves || oldSheet.saves || {};
  const skills = zucSkillRows(zucFirst(skillLedger.rows, skillLedger.skills, surface.skills, normalized.skills, oldSheet.skills, {}), model);
  if (model) {
    if (ac === null) zucAddDiag(model, "error", "MISSING_AC", "AC was not found in any accepted surface.", "core stats", "overview");
    if (hpMax === null) zucAddDiag(model, "error", "MISSING_HP", "HP max was not found in any accepted surface.", "core stats", "overview");
    if (speed === null) zucAddDiag(model, "warning", "MISSING_SPEED", "Speed was not found in any accepted surface.", "core stats", "overview");
  }
  return {
    ac: { current: ac, base: zucNum(zucFirst(acObj.base, acLedger.base_ac, ac), ac), math: zucArray(zucFirst(acLedger.math, acLedger.formula, acLedger.display_text, surface.ac_calculation?.formula)), source: acLedger ? "Armor_Class_Calculation_Ledger / import aliases" : "fallback" },
    hp: { current: hpCur, max: hpMax, formula: zucText(zucFirst(hpObj.formula, oldHp.formula)), source: "Character_Import_Surface / Normalized_Sheet / v1 fallback" },
    speed_ft: speed,
    initiative: zucNum(zucFirst(surface.initiative_bonus, normalized.initiative_bonus, pick(["initiative_bonus", "initiative", "Initiative"]), oldSheet.initiative), 0),
    attack_bonus: attackBonus,
    save_dc: saveDc,
    primary_resource: { name: primaryName, current: primaryCur, max: primaryMax, formula: zucText(zucFirst(primaryResourceSource.formula, "CL × Path key ability modifier unless source override")) },
    senses: zucArray(zucFirst(surface.senses, normalized.senses, oldModel.combat_stats?.senses, oldSheet.senses)),
    defenses: zucArray(zucFirst(surface.defenses, normalized.defenses, oldModel.combat_stats?.defenses, oldSheet.defenses)).concat(zucArray(oldSheet.resistances).map((x) => `Resistance: ${x}`), zucArray(oldSheet.immunities).map((x) => `Immunity: ${x}`), zucArray(oldSheet.vulnerabilities).map((x) => `Vulnerability: ${x}`)),
    saving_throws: Object.entries(saves || {}).map(([ability, bonus]) => ({ ability, bonus: zucNum(bonus, bonus), proficient: false, source: "saving throw surface" })),
    skills,
    ability_scores: ["STR","DEX","CON","INT","WIS","CHA"].map((ab) => ({ ability: ab, score: zucNum(abilityScores?.[ab], null), modifier: zucNum(abilityMods?.[ab], null), save: zucNum(saves?.[ab], null) }))
  };
}
function zucSkillRows(skills = {}, model = null) {
  if (Array.isArray(skills)) return skills.map((s, i) => zucIsObject(s) ? { name: zucDisplay(zucFirst(s.name, s.skill, s.skill_name, s.display_name, `Skill ${i+1}`)), bonus: zucNum(zucFirst(s.bonus, s.modifier, s.value, s.modifier_display), 0), proficient: Boolean(s.proficient || s.selected || /proficient/i.test(zucText(s.proficiency_status))), source: s.source || "skills" } : null).filter(Boolean);
  if (!zucIsObject(skills)) return [];
  const rows = [];
  for (const [key, value] of Object.entries(skills)) {
    if (/^\d+$/.test(key)) {
      if (model) zucAddDiag(model, "warning", "SKILLS_NUMERIC_KEY_RISK", `Numeric skill key ${key} was converted to a named row or skipped.`, "skills", "overview");
      if (zucIsObject(value) && zucFirst(value.name, value.skill, value.skill_name)) rows.push({ name: zucDisplay(zucFirst(value.name, value.skill, value.skill_name)), bonus: zucNum(zucFirst(value.bonus, value.value, value.modifier, value.modifier_display), 0), proficient: Boolean(value.proficient || value.selected || /proficient/i.test(zucText(value.proficiency_status))), source: value.source || "skills" });
      continue;
    }
    rows.push({ name: zucDisplay(key), bonus: zucNum(zucIsObject(value) ? zucFirst(value.bonus, value.value, value.modifier, value.modifier_display) : value, 0), proficient: zucIsObject(value) ? Boolean(value.proficient || value.selected || /proficient/i.test(zucText(value.proficiency_status))) : false, source: zucIsObject(value) ? (value.source || "skills") : "skills" });
  }
  return rows;
}
function zucNormalizeBackgroundOrigin(parsed = [], oldSheet = {}, model = null) {
  const profile = zucFindJson(parsed, [/Background_Origin_Profile/i, /Background_Record/i]) || {};
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const originLedger = zucFindJson(parsed, [/Origin_Insight_Ledger/i]) || {};
  const bg = zucFirst(profile.background, profile.background_record, surface.background, normalized.background, oldSheet.background, {});
  const insight = zucFirst(profile.origin_insight, profile.originInsight, profile.origin, originLedger.origin_insight, originLedger.selected_origin_insight, zucList(originLedger, ["origin_insights", "rows", "entries"])[0], {});
  const background = {
    name: zucDisplay(zucFirst(bg.name, bg.background_name, bg.title)),
    summary: zucText(zucFirst(bg.summary, bg.feature, bg.description)),
    equipment: zucArray(zucFirst(bg.equipment, bg.starting_equipment, profile.background_equipment)),
    background_sphere: zucDisplay(zucFirst(bg.background_sphere, bg.sphere, bg.granted_sphere, profile.background_sphere)),
    background_talent: zucDisplay(zucFirst(bg.background_talent, bg.talent, bg.granted_talent, profile.background_talent)),
    compensation: zucText(zucFirst(bg.compensation, bg.alternate_benefit, bg.benefit_without_sphere)),
    notes: zucText(zucFirst(bg.notes, bg.background_notes, bg.feature, bg.region_or_origin, bg.social_hooks, bg.obligations)),
    source: zucText(zucFirst(bg.source, profile.source, "Background surface"))
  };
  const origin = {
    name: zucDisplay(zucFirst(insight.name, insight.origin_insight_name, insight.insight_name, insight.title)),
    type: zucText(zucFirst(insight.type, "Origin Insight")),
    benefit: zucText(zucFirst(insight.benefit, insight.effect, insight.mechanical_benefit, insight.summary, insight.description)),
    restrictions: zucArray(zucFirst(insight.restrictions, insight.limits, insight.limit)),
    counts_against_background: Boolean(insight.counts_against_background),
    counts_against_level_talent: Boolean(insight.counts_against_level_talent),
    counts_against_trained_choices: Boolean(insight.counts_against_trained_choices),
    source: zucText(zucFirst(insight.source, originLedger.source, "Origin Insight surface"))
  };
  if (model) {
    if (!background.name) zucAddDiag(model, "warning", "BACKGROUND_MISSING", "No background name was found.", "Background_Origin_Profile / Character_Import_Surface", "background_origin");
    if (background.name && !background.notes) zucAddDiag(model, "warning", "BACKGROUND_NOTES_MISSING", "Background exists but notes are missing.", "Background surface", "background_origin");
    if (background.name && !background.background_sphere && !background.background_talent && !background.compensation) zucAddDiag(model, "warning", "BACKGROUND_GRANTS_MISSING", "Background exists but sphere/talent/compensation grants are not recorded.", "Background surface", "background_origin");
    if (!origin.name) zucAddDiag(model, "warning", "ORIGIN_INSIGHT_MISSING", "Origin Insight was not found.", "Origin_Insight_Ledger", "background_origin");
    if (origin.name && !origin.benefit) zucAddDiag(model, "warning", "ORIGIN_INSIGHT_BENEFIT_MISSING", "Origin Insight exists but benefit text is missing.", "Origin_Insight_Ledger", "background_origin");
  }
  return { background, origin_insight: origin };
}
function zucNormalizeSpheresTalents(parsed = [], oldSheet = {}) {
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const sphereLedger = zucFindJson(parsed, [/Sphere_Acquisition_Ledger/i, /Sphere_Free_Talent_Grant_Ledger/i]) || {};
  const canonical = zucFindJson(parsed, [/Canonical_Talent_Ledger/i]) || {};
  const talentSource = zucFindJson(parsed, [/Talent_Source_Ledger/i]) || {};
  const spheres = zucUnique([
    ...zucArray(surface.spheres), ...zucArray(normalized.spheres), ...zucArray(oldSheet.spheres),
    ...zucList(sphereLedger, ["spheres", "rows", "entries", "grant_rows"]).map((r) => zucIsObject(r) ? zucFirst(r.name, r.sphere, r.sphere_name) : r)
  ].map((s) => zucIsObject(s) ? { name: zucDisplay(zucFirst(s.name, s.sphere, s.sphere_name)), source: zucText(zucFirst(s.source, s.source_type, "sphere ledger")) } : { name: zucDisplay(s), source: "sheet" }).filter((s) => s.name), (s) => zucKey(s.name));
  const talentsRaw = [
    ...zucArray(surface.talents), ...zucArray(normalized.talents), ...zucArray(oldSheet.talents),
    ...zucList(canonical, ["talents", "selected_talents", "rows", "entries"]),
    ...zucList(talentSource, ["talents", "rows", "entries", "level_talents", "trained_choices"])
  ];
  const talents = zucUnique(talentsRaw.map((t, i) => {
    if (zucIsObject(t)) return { talent_id: zucText(zucFirst(t.talent_id, t.id, `TALENT_${i+1}`)), name: zucDisplay(zucFirst(t.name, t.talent_name, t.display_name, t.canonical_talent_name, `Talent ${i+1}`)), sphere: zucDisplay(zucFirst(t.sphere, t.sphere_name, t.source_sphere)), source_type: zucText(zucFirst(t.source_type, t.source, t.grant_source)), gained_at_CL: zucNum(zucFirst(t.gained_at_CL, t.CL, t.cl, t.level), null), effect: zucText(zucFirst(t.effect, t.effect_summary, t.summary, t.description)) };
    return { talent_id: `TALENT_${i+1}`, name: zucDisplay(t), sphere: "", source_type: "sheet", gained_at_CL: null, effect: "" };
  }).filter((t) => t.name && !/^Talent \d+$/i.test(t.name)), (t) => `${zucKey(t.sphere)}:${zucKey(t.name)}`);
  return { spheres, talents, source_ledgers: { sphere_ledger_present: Boolean(Object.keys(sphereLedger).length), canonical_talent_ledger_present: Boolean(Object.keys(canonical).length), talent_source_ledger_present: Boolean(Object.keys(talentSource).length) } };
}
function zucNormalizeLevelingLedger(parsed = [], model = null) {
  const identity = model?.identity || {};
  const cl = identity.CL || 1;
  const levelLedger = zucFindJson(parsed, [/Leveling_Ledger/i]) || {};
  const levelTalent = zucFindJson(parsed, [/Level_Talent_Ledger/i]) || {};
  const trained = zucFindJson(parsed, [/Trained_Choice_Ledger/i]) || {};
  const sphereLedger = zucFindJson(parsed, [/Sphere_Acquisition_Ledger/i, /Sphere_Free_Talent_Grant_Ledger/i]) || {};
  const originLedger = zucFindJson(parsed, [/Origin_Insight_Ledger/i]) || {};
  const manualRows = zucNormalizeManuals(parsed);
  let rows = zucList(levelLedger, ["levels", "rows", "entries", "leveling_ledger"]);
  if (!rows.length) {
    const levelTalents = zucList(levelTalent, ["rows", "entries", "level_talents", "talents"]);
    const trainedRows = zucList(trained, ["rows", "entries", "trained_choices", "choices"]);
    const sphereRows = zucList(sphereLedger, ["rows", "entries", "spheres", "grant_rows"]);
    rows = Array.from({ length: cl }, (_, i) => {
      const level = i + 1;
      const freeTalent = levelTalents.find((r) => zucNum(zucFirst(r.CL, r.cl, r.level, r.gained_at_CL), -1) === level) || null;
      const trainedAt = trainedRows.filter((r) => zucNum(zucFirst(r.CL, r.cl, r.level, r.gained_at_CL), -1) === level);
      const sphereAt = sphereRows.filter((r) => zucNum(zucFirst(r.CL, r.cl, r.level, r.gained_at_CL), -1) === level);
      return {
        CL: level,
        realm: level < 5 ? "Mortal" : level < 10 ? "Foundation Establishment" : "Core Formation",
        PB: level <= 4 ? 2 : level <= 8 ? 3 : level <= 12 ? 4 : 5,
        hp_gain: level === 1 ? "starting HP" : "not itemized",
        resource_max_after_level: level === cl ? model?.core_stats?.primary_resource?.max : null,
        free_level_talent: freeTalent ? { sphere: zucDisplay(zucFirst(freeTalent.sphere, freeTalent.sphere_name)), talent: zucDisplay(zucFirst(freeTalent.talent, freeTalent.talent_name, freeTalent.name)) } : null,
        new_spheres_gained: sphereAt.map((r) => zucDisplay(zucFirst(r.sphere, r.name, r.sphere_name))).filter(Boolean),
        new_sphere_bonus_talents: sphereAt.map((r) => zucDisplay(zucFirst(r.bonus_talent, r.free_talent, r.talent))).filter(Boolean),
        trained_choices: trainedAt.map((r) => zucDisplay(zucFirst(r.choice, r.talent, r.name, r.sphere))).filter(Boolean),
        background_grants: level === 1 && model?.background_origin?.background?.name ? [model.background_origin.background.name] : [],
        origin_insight: level === 1 && model?.background_origin?.origin_insight?.name ? model.background_origin.origin_insight.name : null,
        method_event: null,
        foundation_event: null,
        manuals_or_recorded_arts: level === cl ? manualRows.map((m) => m.technique_name || m.manual_name).slice(0, 4) : [],
        forged_techniques: [],
        validation_notes: levelTalents.length || trainedRows.length || sphereRows.length ? [] : ["CL-separated ledger not supplied; row synthesized from available surfaces."]
      };
    });
    if (model) zucAddDiag(model, "info", "LEVELING_LEDGER_SYNTHESIZED", "No complete CL-by-CL ledger found; synthesized rows from known ledgers and current character state.", "Leveling ledgers", "leveling_ledger");
  }
  return rows.map((r, i) => ({
    CL: zucNum(zucFirst(r.CL, r.cl, r.level), i + 1),
    realm: zucText(zucFirst(r.realm)),
    PB: zucNum(zucFirst(r.PB, r.pb, r.proficiency_bonus), null),
    hp_gain: zucText(zucFirst(r.hp_gain, r.hp, r.hp_change)),
    resource_max_after_level: zucText(zucFirst(r.resource_max_after_level, r.resource_max, r.resource)),
    free_level_talent: r.free_level_talent || r.level_talent || null,
    new_spheres_gained: zucArray(zucFirst(r.new_spheres_gained, r.new_spheres, r.spheres)),
    new_sphere_bonus_talents: zucArray(zucFirst(r.new_sphere_bonus_talents, r.bonus_talents, r.free_talents)),
    trained_choices: zucArray(zucFirst(r.trained_choices, r.trained, r.choices)),
    background_grants: zucArray(zucFirst(r.background_grants, r.background)),
    origin_insight: zucText(zucFirst(r.origin_insight, r.origin)),
    method_event: zucText(zucFirst(r.method_event, r.method)),
    foundation_event: zucText(zucFirst(r.foundation_event, r.foundation)),
    manuals_or_recorded_arts: zucArray(zucFirst(r.manuals_or_recorded_arts, r.manuals, r.recorded_arts)),
    forged_techniques: zucArray(zucFirst(r.forged_techniques, r.forged)),
    validation_notes: zucArray(zucFirst(r.validation_notes, r.notes, r.diagnostics))
  }));
}
function zucNormalizeFoundation(parsed = [], oldSheet = {}, model = null) {
  const detail = zucFindJson(parsed, [/Foundation_Detail_Ledger/i]) || {};
  const display = zucFindJson(parsed, [/Foundation_Display_Row/i]) || {};
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  const rows = zucList(detail, ["foundations", "rows", "entries"]);
  const displayRows = zucList(display, ["display_rows", "rows", "entries"]);
  const displayRow = zucFirst(display.row, displayRows[0], display, {});
  const detailPrimary = zucFirst(detail.foundation, detail.row, rows[0], detail, {});
  const primary = detailPrimary || displayRow || (Array.isArray(oldSheet.foundations) ? oldSheet.foundations[0] : null) || {};
  const foundation = {
    name: zucDisplay(zucFirst(primary.foundation_name, primary.name, primary.display_name, displayRow.foundation_name, displayRow.name, normalized.foundation, surface.foundation)),
    grade: zucText(zucFirst(primary.grade, primary.depth, primary.foundation_grade, displayRow.foundation_type, displayRow.foundation_grade, displayRow.grade, displayRow.depth)),
    status_stage: zucText(zucFirst(primary.status, primary.stage, primary.foundation_stage, displayRow.foundation_stage, displayRow.stage)),
    fixed_scope: zucArray(zucFirst(primary.fixed_scope, primary.does_not_grant_boundaries, displayRow.does_not_grant_boundaries)),
    passive_chassis: zucArray(zucFirst(primary.passive_chassis, primary.benefits_permissions, primary.visible_effect_description, primary.actual_description, displayRow.mechanical_constraints_or_benefits, displayRow.summary)),
    benefits: zucArray(zucFirst(primary.benefits, primary.benefits_permissions, primary.mechanical_benefits, primary.what_it_does_at_table, primary.visible_effect_description, primary.resource, displayRow.mechanical_constraints_or_benefits, displayRow.table_effect, displayRow.summary, displayRow.path_interaction)),
    resources_counters: zucArray(zucFirst(primary.resources, primary.resource, primary.counters, displayRow.resources, displayRow.counters)),
    actions_riders: zucArray(zucFirst(primary.actions, primary.riders, primary.triggers, displayRow.actions, displayRow.triggers)),
    burdens_strains_deviations: zucArray(zucFirst(primary.burdens, primary.strains, primary.deviations, primary.drawback, primary.counterplay, displayRow.burden_deviation_risks)),
    ai_notes: zucArray(zucFirst(primary.ai_notes, primary.ai_piloting_notes, displayRow.ai_notes, displayRow.breakthrough_relevance)),
    source: zucText(zucFirst(primary.source_reference, primary.source, displayRow.source_catalog_reference, "Foundation_Detail_Ledger / Foundation_Display_Row"))
  };
  if (model && foundation.name && !foundation.benefits.length) zucAddDiag(model, "error", "FOUNDATION_EXISTS_BUT_NO_BENEFITS_RENDERED", "Foundation exists but no benefit/mechanical row normalized.", "Foundation_Detail_Ledger / Foundation_Display_Row", "foundation");
  return foundation;
}
function zucNormalizeMethod(parsed = []) {
  const profile = zucFindJson(parsed, [/Cultivation_Method_Profile/i, /Method_Profile/i]) || {};
  const method = zucFirst(profile.active_primary_method, profile.active_method, profile.method_profile, profile.method, profile.method_name, profile.primary_method, profile, {});
  if (!zucIsObject(method) && !zucText(method)) return {};
  const obj = zucIsObject(method) ? method : { name: method };
  return {
    name: zucDisplay(zucFirst(obj.name, obj.method_name, obj.title, profile.name, profile.method_name, profile.method)),
    status: zucText(zucFirst(obj.status, obj.primary_active_status, obj.active_status, profile.status, profile.primary_method === true ? "primary" : "")),
    resource_shape: zucText(zucFirst(obj.resource_shape, obj.resource, profile.resource_shape, profile.resource)),
    mechanical_effects: zucArray(zucFirst(obj.mechanical_effects, obj.effects, obj.benefits, obj.benefit, profile.mechanical_effects, profile.benefit, profile.description)),
    applied_math: zucArray(zucFirst(obj.applied_math, obj.math, obj.resource_modifier_formula, obj.resource_modifier, obj.primary_resource_bonus, profile.applied_math, profile.resource_modifier, profile.primary_resource_bonus)),
    breakthrough_shape: zucText(zucFirst(obj.breakthrough_shape, obj.breakthrough, profile.breakthrough_shape)),
    foundation_compatibility: zucArray(zucFirst(obj.foundation_compatibility, obj.compatibility, profile.foundation_compatibility)),
    incompatibilities: zucArray(zucFirst(obj.incompatibilities, obj.incompatible_with, obj.drawback, profile.incompatibilities, profile.drawback)),
    source: zucText(zucFirst(obj.source, profile.source, "Cultivation_Method_Profile.json"))
  };
}
function zucNormalizeManuals(parsed = []) {
  const manualsFile = zucFindJson(parsed, [/Martial_Arts_and_Manuals/i]) || {};
  const displayRows = zucFindJson(parsed, [/Martial_Manual_Display_Rows/i]) || {};
  const rules = zucFindJson(parsed, [/Martial_Manual_Rules_Ledger/i]) || {};
  const rows = [];
  const manualList = zucList(manualsFile, ["manuals", "martial_arts", "entries", "items"]);
  manualList.forEach((m) => {
    const forms = zucList(zucFirst(m.forms, m.techniques, m.manual_forms, m.recorded_techniques));
    if (!forms.length) rows.push({ manual: m, form: {}, source: "Martial_Arts_and_Manuals.json" });
    forms.forEach((f) => rows.push({ manual: m, form: f, source: "Martial_Arts_and_Manuals.json" }));
  });
  zucList(displayRows, ["rows", "entries", "items"]).forEach((r) => rows.push({ manual: {}, form: r, source: "Martial_Manual_Display_Rows.json" }));
  return rows.map(({ manual, form, source }, i) => ({
    manual_name: zucDisplay(zucFirst(form.manual_name, manual.manual_name, manual.name, form.source, `Manual ${i+1}`)),
    technique_name: zucDisplay(zucFirst(form.technique_name, form.name, form.form_name, form.display_name, form.title, `Technique ${i+1}`)),
    source_spheres: zucArray(zucFirst(form.source_spheres, form.source_spheres_display, manual.source_spheres, form.spheres)),
    reproduced_ability: zucText(zucFirst(form.reproduced_ability, form.reproduced_package, form.source_talent_names, form.source_packet_ids, form.fixed_talent_expression, form.description)),
    DC: zucText(zucFirst(form.DC, form.dc, form.practice_dc, form.training_dc, rules.practice_dc)),
    realm_gate: zucText(zucFirst(form.realm_gate, form.realm, manual.realm_gate)),
    timing_economy: zucText(zucFirst(form.timing, form.activation, form.action_type, form.economy_bucket)),
    cost: zucText(zucFirst(form.cost, form.resource_cost)),
    range: zucText(zucFirst(form.range)),
    target: zucText(zucFirst(form.target)),
    roll_save_check: zucText(zucFirst(form.roll_save, form.roll_or_save, form.attack_or_save, form.check)),
    effect: zucText(zucFirst(form.effect, form.effect_summary, form.description, form.fixed_talent_expression_display, form.fixed_talent_expression)),
    failure_miss: zucText(zucFirst(form.failure, form.miss, form.failure_or_limit)),
    duration: zucText(zucFirst(form.duration)),
    limit: zucText(zucFirst(form.limit, form.limits)),
    counterplay: zucText(zucFirst(form.counterplay)),
    linked_action_refs: zucArray(zucFirst(form.linked_action_ids, form.act_action_refs, form.actions)),
    policy_notes: zucText(zucFirst(manual.does_not_grant_policy, manual.does_not_grant_spheres_or_talents, form.policy_notes)),
    source
  })).filter((r) => r.manual_name || r.technique_name || r.effect);
}
function zucNormalizeDaoIChing(parsed = [], model = null) {
  const daoCombat = zucFindJson(parsed, [/Dao_Combat_Behavior_Profile/i]) || {};
  const daoProfile = zucFindJson(parsed, [/Dao_Profile/i]) || {};
  const iProfile = zucFindJson(parsed, [/I_Ching_Combat_Generation_Profile/i, /IChing_Combat_Generation_Profile/i, /Yijing_Combat_Generation_Profile/i]) || {};
  const daoLayer = zucFirst(daoProfile.dao_layer, daoCombat.dao_layer, daoCombat, {});
  const iLayer = zucFirst(iProfile.i_ching_combat_layer, daoCombat.i_ching_combat_layer, iProfile, {});
  const dao = {
    dao_phrase: zucText(zucFirst(daoCombat.dao_phrase, daoLayer.dao_phrase, daoLayer.dao_name, daoProfile.dao_phrase)),
    combat_doctrine: zucText(zucFirst(daoCombat.combat_doctrine, daoLayer.default_behavior, daoLayer.dao_thesis)),
    preferred_engagements: zucArray(zucFirst(daoCombat.preferred_engagements, daoLayer.engagement_preferences)),
    avoidance_rules: zucArray(zucFirst(daoCombat.avoidance_rules, daoLayer.avoidance_rules)),
    resource_policy: zucText(zucFirst(daoCombat.resource_policy, daoLayer.resource_temperament)),
    risk_thresholds: zucArray(zucFirst(daoCombat.risk_thresholds, daoLayer.risk_temperament)),
    target_selection_logic: zucArray(zucFirst(daoCombat.target_selection_logic, daoLayer.target_selection_logic)),
    reaction_policy: zucText(zucFirst(daoCombat.reaction_policy)),
    failure_recovery: zucArray(zucFirst(daoCombat.failure_recovery, daoCombat.failure_recovery_policy, daoLayer.failure_recovery_policy)),
    forbidden_behaviors: zucArray(zucFirst(daoCombat.forbidden_behaviors, daoLayer.refuses_to_become)),
    ai_turn_prompt: zucText(zucFirst(daoCombat.ai_turn_prompt)),
    composite_hooks: zucArray(zucFirst(daoCombat.composite_selection_logic, daoCombat.composite_hooks))
  };
  const i_ching = {
    enabled: Boolean(Object.keys(iProfile).length || Object.keys(iLayer || {}).length),
    reading_name: zucText(zucFirst(iLayer.reading_name, iLayer.name, iProfile.name)),
    hexagram_or_trigram: zucText(zucFirst(iLayer.hexagram_or_trigram, iLayer.hexagram, iLayer.trigram, iLayer.natural_trigram_tendencies)),
    natural_tendency: zucText(zucFirst(iLayer.natural_tendency, iLayer.natural_trigram_tendencies)),
    testing_tendency: zucText(zucFirst(iLayer.testing_tendency, iLayer.testing_trigram_tendencies)),
    shift_triggers: zucArray(zucFirst(iLayer.shift_triggers, iLayer.line_shift_triggers)),
    low_resource_shift: zucText(zucFirst(iLayer.low_resource_shift)),
    combat_state_interpretation: zucText(zucFirst(iLayer.combat_state_interpretation)),
    gm_generation_instruction: zucText(zucFirst(iLayer.gm_generation_instruction)),
    composite_hooks: zucArray(zucFirst(iLayer.composite_hooks, iLayer.default_change_strategy))
  };
  if (model && Object.keys(daoCombat).length && !dao.dao_phrase && !dao.combat_doctrine) zucAddDiag(model, "error", "DAO_PROFILE_FOUND_BUT_NOT_RENDERED", "Dao profile exists but no structured Dao fields normalized.", "Dao_Combat_Behavior_Profile / Dao_Profile", "dao_i_ching");
  if (model && Object.keys(iProfile).length && !i_ching.enabled) zucAddDiag(model, "error", "I_CHING_PROFILE_FOUND_BUT_NOT_RENDERED", "I Ching profile exists but no structured fields normalized.", "I_Ching_Combat_Generation_Profile", "dao_i_ching");
  return { dao, i_ching };
}
function zucNormalizeEquipmentResourcesStates(parsed = [], oldSheet = {}, core = {}) {
  const equip = zucFindJson(parsed, [/Equipment_Ledger/i]) || {};
  const limit = zucFindJson(parsed, [/Limited_Resource_Counter_Inventory/i]) || {};
  const state = zucFindJson(parsed, [/State_Window_Lock_Audit/i, /Combat_State_Ledger_Template/i]) || {};
  const surface = zucFindJson(parsed, [/Character_Import_Surface/i]) || {};
  const normalized = zucFindJson(parsed, [/Normalized_Sheet/i]) || {};
  return {
    equipment: zucList(equip, ["equipment", "items", "entries", "active_equipment_names"]).concat(zucArray(surface.equipment), zucArray(normalized.equipment), zucArray(oldSheet.equipment)).map((e, i) => zucIsObject(e) ? { name: zucDisplay(zucFirst(e.name, e.display_name, e.item_name, `Equipment ${i+1}`)), type: zucText(zucFirst(e.type, e.slot)), equipped: e.equipped !== false, ac_contribution: zucText(zucFirst(e.ac_contribution, e.ac)), notes: zucText(zucFirst(e.notes, e.effect, e.summary)), source: zucText(zucFirst(e.source, "Equipment_Ledger")) } : { name: zucDisplay(e), type: "equipment", equipped: true, ac_contribution: "", notes: "", source: "sheet" }),
    resources: [core.primary_resource].filter(Boolean).concat(zucList(limit, ["resources", "counters", "entries", "items"]), zucArray(surface.resources), zucArray(normalized.resources), zucArray(oldSheet.resources)),
    states: zucList(state, ["states", "starting_state", "entries", "items"]).concat(zucArray(normalized.states), zucArray(oldSheet.states)).map((s, i) => zucIsObject(s) ? { name: zucDisplay(zucFirst(s.name, s.display_name, s.state, `State ${i+1}`)), created_by: zucText(zucFirst(s.created_by, s.source)), duration: zucText(zucFirst(s.duration)), effect: zucText(zucFirst(s.effect, s.summary, s.description)), end_condition: zucText(zucFirst(s.end_condition)), source: "State/Combat Ledger" } : { name: zucDisplay(s), effect: "", source: "sheet" })
  };
}
function zucRawComposites(parsed = []) {
  const comp = zucFindJson(parsed, [/Composite_Action_Registry/i]) || {};
  const playbook = zucFindJson(parsed, [/Combat_Playbook/i]) || {};
  const desc = zucFindJson(parsed, [/Composite_Description_Ledger/i]) || {};
  const byId = new Map();
  function mergeRaw(item, source) {
    if (!zucIsObject(item)) return;
    const id = zucText(zucFirst(item.composite_id, item.id, item.playbook_id, item.composite_ref, item.name, item.display_name));
    if (!id) return;
    const key = zucKey(id);
    byId.set(key, { ...(byId.get(key) || {}), ...item, __sources: [...(byId.get(key)?.__sources || []), source] });
  }
  zucList(comp, ["composite_actions", "composites", "playbooks", "entries", "items", "registry"]).forEach((x) => mergeRaw(x, "Composite_Action_Registry.json"));
  zucList(playbook, ["composite_playbook_entries", "composites", "composite_actions", "playbooks", "entries", "items"]).forEach((x) => mergeRaw(x, "Combat_Playbook.json"));
  zucList(playbook, ["priority_table"]).forEach((x) => mergeRaw(x, "Combat_Playbook.json/priority_table"));
  zucList(desc, ["composite_descriptions", "composites", "entries", "items"]).forEach((x) => mergeRaw(x, "Composite_Description_Ledger.json"));
  return Array.from(byId.values());
}
function zucTemporalMap(parsed = []) {
  const temporal = zucFindJson(parsed, [/Temporal_Feasibility_Registry/i]) || {};
  const map = new Map();
  zucList(temporal, ["temporal_feasibility", "entries", "rows"]).forEach((t) => {
    [t.composite_id, t.id, t.name, t.display_name, t.composite_name, t.composite_ref].forEach((id) => {
      const key = zucKey(id);
      if (key && !map.has(key)) map.set(key, t);
    });
  });
  return map;
}
function zucNormalizeCompositeStep(step, index, actionMap) {
  const rawId = zucIsObject(step) ? zucFirst(step.action_id, step.linked_action_id, step.source_action_id, step.component_id, step.id, step.ref) : step;
  const action = actionMap.get(zucKey(rawId)) || actionMap.get(zucKey(zucIsObject(step) ? zucFirst(step.name, step.action_name, step.display_name) : "")) || null;
  return {
    step: zucNum(zucIsObject(step) ? zucFirst(step.step, step.step_order, step.order) : null, index + 1),
    timing: zucText(zucFirst(step?.timing, step?.actor_window, step?.trigger, action?.timing)),
    economy: zucText(zucFirst(step?.economy, step?.bucket, step?.action_type, action?.economy)),
    action_id: zucText(zucFirst(rawId, action?.action_id)),
    action_name: zucDisplay(zucFirst(step?.action_name, step?.name, step?.display_name, action?.name, rawId)),
    cost: zucText(zucFirst(step?.cost, step?.resource_check, action?.cost)),
    range: zucText(zucFirst(step?.range, action?.range)),
    target: zucText(zucFirst(step?.target, action?.target)),
    roll_or_save: zucText(zucFirst(step?.roll_or_save, step?.roll_save, step?.attack_or_save, action?.roll_or_save)),
    success_effect: zucText(zucFirst(step?.success_effect, step?.legal_resolution, step?.resolution, step?.effect, action?.success_effect, action?.effect)),
    failure_or_limit: zucText(zucFirst(step?.failure_or_limit, step?.limit, action?.failure_or_limit, action?.limit)),
    duration: zucText(zucFirst(step?.duration, action?.duration)),
    counterplay: zucText(zucFirst(step?.counterplay, action?.counterplay)),
    resolved: Boolean(action),
    source_action: action
  };
}
function zucNormalizeComposites(parsed = [], actions = [], daoIChing = {}, model = null) {
  const raw = zucRawComposites(parsed);
  const tmap = zucTemporalMap(parsed);
  const actionMap = zucActionsById(actions);
  const composites = raw.map((c, index) => {
    const id = zucText(zucFirst(c.composite_id, c.id, c.playbook_id, c.composite_ref, `COMP_${index+1}`));
    const registryTemporal = tmap.get(zucKey(id)) || tmap.get(zucKey(c.name || c.display_name)) || tmap.get(zucKey(c.composite_name || c.playbook_name));
    const embeddedTemporal = zucIsObject(c.temporal_feasibility) ? c.temporal_feasibility : (zucIsObject(c.temporal) ? c.temporal : {});
    const temporal = registryTemporal || (Object.keys(embeddedTemporal).length ? { ...embeddedTemporal, __source: "Composite embedded temporal_feasibility" } : {});
    const hasTemporal = Boolean(Object.keys(temporal).length || zucText(zucFirst(c.temporal_feasibility, c.temporal_feasibility_summary, c.timing_class, c.selection_condition)));
    const componentSeeds = [];
    zucArray(zucFirst(c.components, c.component_stack, c.sequence, c.steps)).forEach((x) => componentSeeds.push(x));
    zucArray(c.component_action_ids).forEach((x) => componentSeeds.push(x));
    if (!componentSeeds.length) zucArray(temporal.steps).forEach((x) => componentSeeds.push(x));
    const sequence = componentSeeds.map((s, i) => zucNormalizeCompositeStep(s, i, actionMap));
    const diagnostics = [];
    if (!sequence.length) diagnostics.push("COMPOSITE_SEQUENCE_MISSING");
    sequence.filter((s) => s.action_id && !s.resolved).forEach((s) => diagnostics.push(`COMPOSITE_COMPONENT_UNRESOLVED: ${s.action_id}`));
    if (!sequence.some((s) => s.economy)) diagnostics.push("COMPOSITE_ECONOMY_MISSING");
    if (!sequence.some((s) => s.success_effect)) diagnostics.push("COMPOSITE_EFFECT_TEXT_MISSING");
    if (!hasTemporal) diagnostics.push("COMPOSITE_TEMPORAL_FEASIBILITY_FALLBACK_USED");
    const onlyDeclared = sequence.length && sequence.every((s) => /^declared$/i.test(zucText(s.success_effect)) || /^declared$/i.test(zucText(s.action_name)));
    if (onlyDeclared) diagnostics.push("COMPOSITE_ONLY_DECLARED");
    const footprint = zucUnique(sequence.map((s) => s.economy).filter(Boolean).map(zucDisplay), zucKey);
    return {
      composite_id: id,
      name: zucDisplay(zucFirst(c.display_name, c.name, c.composite_name, c.playbook_name, id)),
      priority: zucNum(zucFirst(c.priority, c.priority_bucket), index + 1),
      category: zucText(zucFirst(c.gm_screen_category, c.category, c.strategy_archetype, c.role)),
      execution_role: zucText(zucFirst(c.execution_role, c.role, c.use_case, c.playbook_role)),
      when_to_use: zucText(zucFirst(c.when_to_use, c.selection_condition, temporal.selection_condition, c.logic_statement, c.output)),
      do_not_use_when: zucText(zucFirst(c.do_not_use_when, c.do_not_use_panel)),
      preconditions: zucArray(zucFirst(c.preconditions, c.selection_condition, temporal.selection_condition)),
      resource_budget: zucFirst(c.resource_budget, c.resource_contract, c.economy_resource_ledger, { resource: "Not recorded", expected_cost: sequence.map((s) => zucNum(s.cost, 0)).reduce((a,b) => a+b, 0), max_commitment: "Not recorded" }),
      economy_footprint: footprint,
      sequence,
      temporal_feasibility: { same_turn_legal: temporal.selection_allowed !== false, round_segmentation: zucText(zucFirst(temporal.primary_followup_window, temporal.timing_class, temporal.round_segmentation, c.temporal_feasibility_summary, c.temporal_feasibility, c.timing_class)), source: temporal.__source || (Object.keys(temporal).length ? "Temporal_Feasibility_Registry" : "composite_projection"), missing_rows: hasTemporal ? [] : ["No Temporal_Feasibility_Registry row matched this composite."] },
      linked_actions: zucUnique(sequence.map((s) => s.source_action).filter(Boolean), (a) => zucKey(a.action_id)).map((a) => ({ action_id: a.action_id, name: a.name, economy: a.economy, effect: a.effect })),
      fallback: zucText(zucFirst(c.fallback, c.fallback_action, c.fallback_action_ref, c.low_resource_fallback)),
      dao_hook: zucText(zucFirst(c.dao_hook, c.dao_layer_summary, c.dao_i_ching_notes, daoIChing.dao?.composite_hooks, daoIChing.dao?.combat_doctrine)),
      i_ching_hook: zucText(zucFirst(c.i_ching_hook, c.i_ching_layer_summary, daoIChing.i_ching?.composite_hooks, daoIChing.i_ching?.low_resource_shift)),
      diagnostics,
      source: zucUnique(c.__sources || [], zucKey).join("; ") || "Composite surfaces"
    };
  });
  if (model) composites.forEach((c) => c.diagnostics.forEach((d) => zucAddDiag(model, /UNRESOLVED|MISSING|ONLY_DECLARED/.test(d) ? "error" : "warning", d.split(":")[0], d, c.source, "composites")));
  if (model && raw.length && !composites.length) zucAddDiag(model, "error", "COMPOSITES_FOUND_BUT_NOT_RENDERED", "Composite source files exist but no composite cards normalized.", "Composite surfaces", "composites");
  return composites;
}
function zucValidateModel(model) {
  const errors = model.diagnostics.filter((d) => d.severity === "error").length;
  const warnings = model.diagnostics.filter((d) => /warn/i.test(d.severity)).length;
  model.validation = { verdict: errors ? "FAIL_HF05ZUC_VIEW_MODEL_VALIDATION" : "PASS_HF05ZUC_VIEW_MODEL_STATIC_VALIDATION", error_count: errors, warning_count: warnings, patch: ZUC_PATCH_ID };
  return model.validation;
}
function zucBuildViewModelV2(pkg = {}) {
  if (pkg?.viewModelV2?.schema === ZUC_VIEW_SCHEMA || pkg?.viewModelV2?.schema_version === ZUC_VIEW_SCHEMA) return pkg.viewModelV2;
  const parsed = zucParsed(pkg);
  const direct = zucDirectViewModelV2(parsed);
  if (direct) { zucValidateModel(direct); return direct; }
  const oldModel = (typeof tgmBuildCanonicalModelFromPackage === "function") ? tgmBuildCanonicalModelFromPackage(pkg) : {};
  const oldSheet = (typeof zucBuildSheetDataBefore === "function") ? zucBuildSheetDataBefore(pkg) : (pkg.sheetData || {});
  const discovery = zucSourceDiscovery(parsed, pkg);
  const model = {
    schema: ZUC_VIEW_SCHEMA,
    schema_version: ZUC_VIEW_SCHEMA,
    patch: ZUC_PATCH_ID,
    source_package: { package_name: zucText(zucFirst(pkg.name, pkg.package_name, oldModel.metadata?.package_name, "Imported Package")), source_files: zucAllNames(pkg), ...discovery },
    identity: {}, core_stats: {}, leveling_ledger: [], background_origin: {}, spheres_talents: {}, actions: [], composites: [], martial_manuals: [], foundation: {}, method: {}, dao_i_ching: {}, equipment_resources_states: {}, diagnostics: []
  };
  model.identity = zucNormalizeIdentityCore(parsed, oldModel, oldSheet, pkg, model);
  model.core_stats = zucNormalizeCoreStats(parsed, oldModel, oldSheet, model.identity, model);
  model.background_origin = zucNormalizeBackgroundOrigin(parsed, oldSheet, model);
  model.spheres_talents = zucNormalizeSpheresTalents(parsed, oldSheet);
  model.actions = zucNormalizeActions(parsed, model);
  model.martial_manuals = zucNormalizeManuals(parsed);
  model.foundation = zucNormalizeFoundation(parsed, oldSheet, model);
  model.method = zucNormalizeMethod(parsed);
  model.dao_i_ching = zucNormalizeDaoIChing(parsed, model);
  model.composites = zucNormalizeComposites(parsed, model.actions, model.dao_i_ching, model);
  model.equipment_resources_states = zucNormalizeEquipmentResourcesStates(parsed, oldSheet, model.core_stats);
  model.leveling_ledger = zucNormalizeLevelingLedger(parsed, model);
  if (!model.martial_manuals.length) zucAddDiag(model, "info", "MARTIAL_MANUALS_NOT_RECORDED", "No martial manual display rows were found.", "Martial surfaces", "martial_manuals");
  if (!model.method.name) zucAddDiag(model, "info", "METHOD_NOT_RECORDED", "No cultivation method profile was found.", "Cultivation_Method_Profile", "method");
  if (!model.dao_i_ching.i_ching?.enabled) zucAddDiag(model, "info", "I_CHING_NOT_RECORDED", "No I Ching profile recorded.", "I_Ching_Combat_Generation_Profile", "dao_i_ching");
  zucValidateModel(model);
  return model;
}

function zucMiniTable(headers = [], rows = []) {
  return `<div class="zuc-table-wrap"><table class="compact-table zuc-table"><thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${rows.length ? rows.map((row) => `<tr>${headers.map((h, i) => `<td>${zucHtml(row[i] ?? "")}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${headers.length}">Not recorded.</td></tr>`}</tbody></table></div>`;
}
function zucBullet(items = [], empty = "Not recorded.") {
  const list = zucArray(items).map((x) => zucValueText(x, "")).filter(Boolean);
  return list.length ? `<ul>${list.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : `<p class="sheet-description">${escapeHtml(empty)}</p>`;
}
function zucCard(title, body) { return `<article class="sheet-detail-card"><strong>${escapeHtml(title)}</strong><p>${zucHtml(body)}</p></article>`; }
function zucTabButton(slug, label, active = false) { return `<button class="sheet-tab-button ${active ? "active" : ""}" type="button" data-sheet-tab="${escapeHtml(slug)}">${escapeHtml(label)}</button>`; }
function zucTabPanel(slug, html, active = false) { return `<div class="sheet-tab-panel ${active ? "active" : ""}" data-sheet-panel="${escapeHtml(slug)}">${html}</div>`; }
function zucSection(title, html) { return `<section class="sheet-section"><h4>${escapeHtml(title)}</h4><div class="sheet-section-body">${html}</div></section>`; }
function zucRenderOverview(model) {
  const cs = model.core_stats || {};
  const abilityRows = (cs.ability_scores || []).map((a) => [a.ability, a.score ?? "—", a.modifier === null ? "—" : formatSigned(a.modifier), a.save === null ? "—" : formatSigned(a.save)]);
  const skillRows = (cs.skills || []).map((s) => [s.name, s.bonus === null ? "—" : formatSigned(s.bonus), s.proficient ? "yes" : "no", s.source || ""]);
  return `
    <div class="sheet-detail-grid">
      ${zucCard("AC", `${cs.ac?.current ?? "—"}${cs.ac?.math?.length ? ` (${zucValueText(cs.ac.math)})` : ""}`)}
      ${zucCard("HP", `${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}
      ${zucCard("Speed", `${cs.speed_ft ?? "—"} ft`)}
      ${zucCard("Attack Bonus", cs.attack_bonus === null ? "—" : formatSigned(cs.attack_bonus))}
      ${zucCard("Save DC", cs.save_dc ?? "—")}
      ${zucCard("Primary Resource", `${cs.primary_resource?.name || "Resource"} ${cs.primary_resource?.current ?? "?"}/${cs.primary_resource?.max ?? "?"}`)}
    </div>
    ${zucSection("Ability Scores / Saves", zucMiniTable(["Ability", "Score", "Mod", "Save"], abilityRows))}
    ${zucSection("Skills", zucMiniTable(["Skill", "Bonus", "Proficient", "Source"], skillRows))}
    ${zucSection("Senses", zucBullet(cs.senses))}
    ${zucSection("Defenses", zucBullet(cs.defenses))}
  `;
}
function zucRenderLeveling(model) {
  const rows = (model.leveling_ledger || []).map((r) => [r.CL, r.realm, r.PB, [r.hp_gain, r.resource_max_after_level].filter(Boolean).join(" / "), zucValueText(r.free_level_talent, ""), zucValueText([...(r.new_spheres_gained||[]), ...(r.new_sphere_bonus_talents||[])], ""), `${(r.trained_choices||[]).length}/3 ${zucValueText(r.trained_choices, "")}`, zucValueText([...(r.background_grants||[]), r.origin_insight].filter(Boolean), ""), zucValueText([r.method_event, r.foundation_event].filter(Boolean), ""), zucValueText(r.manuals_or_recorded_arts, ""), zucValueText(r.forged_techniques, ""), zucValueText(r.validation_notes, "")]);
  return `${zucSection("CL-by-CL Choices", zucMiniTable(["CL","Realm","PB","HP / Resource","Free Level Talent","New Sphere + Bonus Talent","Trained Choices","Background / Origin","Method / Foundation","Manuals / Recorded Arts","Forged","Validation"], rows))}`;
}
function zucRenderBackground(model) {
  const b = model.background_origin?.background || {};
  const o = model.background_origin?.origin_insight || {};
  return `
    <div class="sheet-detail-grid">
      ${zucCard("Background", b.name || "Not recorded")}
      ${zucCard("Background Sphere", b.background_sphere || "Not recorded")}
      ${zucCard("Background Talent", b.background_talent || "Not recorded")}
      ${zucCard("Compensation", b.compensation || "Not recorded")}
      ${zucCard("Origin Insight", o.name || "Not recorded")}
      ${zucCard("Count Flags", `Background ${!!o.counts_against_background}; Level Talent ${!!o.counts_against_level_talent}; Trained ${!!o.counts_against_trained_choices}`)}
    </div>
    ${zucSection("Background Equipment", zucBullet(b.equipment))}
    ${zucSection("Background Notes", `<p class="sheet-description">${zucHtml(b.notes || b.summary)}</p>`)}
    ${zucSection("Origin Insight Benefit", `<p class="sheet-description">${zucHtml(o.benefit)}</p>`)}
    ${zucSection("Origin Insight Restrictions", zucBullet(o.restrictions))}
    ${zucSection("Sources", `<p class="sheet-description">Background: ${zucHtml(b.source)}<br>Origin: ${zucHtml(o.source)}</p>`)}
  `;
}
function zucRenderSpheresTalents(model) {
  const st = model.spheres_talents || {};
  const spheres = (st.spheres || []).map((s) => [s.name, s.source]);
  const talents = (st.talents || []).map((t) => [t.name, t.sphere, t.source_type, t.gained_at_CL ?? "", t.effect]);
  return `${zucSection("Known Spheres", zucMiniTable(["Sphere", "Source"], spheres))}${zucSection("Talents", zucMiniTable(["Talent", "Sphere", "Source", "CL", "Effect"], talents))}`;
}
function zucRenderActions(model) {
  const rows = (model.actions || []).map((a) => [a.name, a.economy, a.timing, a.cost, a.range, a.target, a.roll_or_save, a.effect, a.duration, a.limit, a.counterplay, a.source]);
  return zucSection("Playable Actions", zucMiniTable(["Action", "Economy", "Timing", "Cost", "Range", "Target", "Roll / Save", "Effect", "Duration", "Limit", "Counterplay", "Source"], rows));
}
function zucRenderComposites(model) {
  const cards = (model.composites || []).map((c, i) => {
    const seq = (c.sequence || []).map((s) => [s.step, s.timing, s.economy, s.action_id, s.action_name, s.cost, s.range, s.target, s.roll_or_save, s.success_effect, s.failure_or_limit, s.duration, s.counterplay]);
    const linked = (c.linked_actions || []).map((a) => [a.action_id, a.name, a.economy, a.effect]);
    return `<article class="zuc-composite-card sheet-detail-card">
      <h4>${escapeHtml(c.priority ? `${c.priority}. ${c.name}` : c.name)}</h4>
      <div class="sheet-detail-grid">
        ${zucCard("Execution Role", c.execution_role || c.category)}
        ${zucCard("When to Use", c.when_to_use)}
        ${zucCard("Do Not Use When", c.do_not_use_when)}
        ${zucCard("Resource Budget", zucValueText(c.resource_budget))}
        ${zucCard("Economy Footprint", zucValueText(c.economy_footprint))}
        ${zucCard("Temporal Feasibility", `${c.temporal_feasibility?.same_turn_legal ? "Legal when windows match" : "Not automatically legal"}; ${c.temporal_feasibility?.round_segmentation || "No segmentation recorded"}`)}
        ${zucCard("Fallback", c.fallback || "Not recorded")}
        ${zucCard("Dao / I Ching Hooks", [c.dao_hook, c.i_ching_hook].filter(Boolean).join(" | "))}
      </div>
      <h5>Component Sequence</h5>${zucMiniTable(["Step","Timing","Economy","Action ID","Action","Cost","Range","Target","Roll / Save","Success / Effect","Failure / Limit","Duration","Counterplay"], seq)}
      <h5>Linked Actions</h5>${zucMiniTable(["Action ID", "Name", "Economy", "Effect"], linked)}
      <h5>Diagnostics</h5>${zucBullet(c.diagnostics, "No composite diagnostics.")}
    </article>`;
  }).join("");
  return cards || `<p class="sheet-description">No composite playbooks recorded.</p>`;
}
function zucRenderManuals(model) {
  const rows = (model.martial_manuals || []).map((m) => [m.manual_name, m.technique_name, zucValueText(m.source_spheres, ""), m.reproduced_ability, m.DC, m.realm_gate, m.timing_economy, m.cost, m.range, m.target, m.roll_save_check, m.effect, m.failure_miss, m.duration, m.limit, m.counterplay, zucValueText(m.linked_action_refs, ""), m.source]);
  const policy = zucUnique((model.martial_manuals || []).map((m) => m.policy_notes).filter(Boolean), zucKey);
  return `${zucSection("Martial Manuals / Recorded Arts", zucMiniTable(["Manual", "Technique", "Sphere(s)", "Reproduced Package", "DC", "Realm", "Timing", "Cost", "Range", "Target", "Roll/Save/Check", "Effect", "Failure", "Duration", "Limit", "Counterplay", "Linked Actions", "Source"], rows))}${zucSection("Rule Notes", zucBullet(policy, "No policy notes recorded."))}`;
}
function zucRenderFoundation(model) {
  const f = model.foundation || {};
  return `<div class="sheet-detail-grid">${zucCard("Foundation", f.name || "Not recorded")}${zucCard("Grade", f.grade)}${zucCard("Status / Stage", f.status_stage)}${zucCard("Source", f.source)}</div>${zucSection("Fixed Scope", zucBullet(f.fixed_scope))}${zucSection("Passive Chassis", zucBullet(f.passive_chassis))}${zucSection("Benefits", zucBullet(f.benefits))}${zucSection("Resources / Counters", zucBullet(f.resources_counters))}${zucSection("Actions / Riders", zucBullet(f.actions_riders))}${zucSection("Burdens / Strains / Deviations", zucBullet(f.burdens_strains_deviations))}${zucSection("AI Piloting Notes", zucBullet(f.ai_notes))}`;
}
function zucRenderMethod(model) {
  const m = model.method || {};
  return `<div class="sheet-detail-grid">${zucCard("Method", m.name || "Not recorded")}${zucCard("Status", m.status)}${zucCard("Resource Shape", m.resource_shape)}${zucCard("Breakthrough Shape", m.breakthrough_shape)}${zucCard("Source", m.source)}</div>${zucSection("Mechanical Effects", zucBullet(m.mechanical_effects))}${zucSection("Applied Math", zucBullet(m.applied_math))}${zucSection("Foundation Compatibility", zucBullet(m.foundation_compatibility))}${zucSection("Incompatibilities", zucBullet(m.incompatibilities))}`;
}
function zucRenderDaoIChing(model) {
  const d = model.dao_i_ching?.dao || {};
  const y = model.dao_i_ching?.i_ching || {};
  return `${zucSection("Dao", `<div class="sheet-detail-grid">${zucCard("Dao Phrase", d.dao_phrase)}${zucCard("Combat Doctrine", d.combat_doctrine)}${zucCard("Resource Policy", d.resource_policy)}${zucCard("Reaction Policy", d.reaction_policy)}${zucCard("AI Turn Prompt", d.ai_turn_prompt)}</div>${zucSection("Preferred Engagements", zucBullet(d.preferred_engagements))}${zucSection("Avoidance Rules", zucBullet(d.avoidance_rules))}${zucSection("Risk Thresholds", zucBullet(d.risk_thresholds))}${zucSection("Target Selection", zucBullet(d.target_selection_logic))}${zucSection("Failure Recovery", zucBullet(d.failure_recovery))}${zucSection("Forbidden Behaviors", zucBullet(d.forbidden_behaviors))}${zucSection("Composite Hooks", zucBullet(d.composite_hooks))}`)}${zucSection("I Ching", `<div class="sheet-detail-grid">${zucCard("Enabled", y.enabled ? "Yes" : "No")}${zucCard("Reading", y.reading_name)}${zucCard("Hexagram / Trigram", y.hexagram_or_trigram)}${zucCard("Natural Tendency", y.natural_tendency)}${zucCard("Testing Tendency", y.testing_tendency)}${zucCard("Low-Resource Shift", y.low_resource_shift)}${zucCard("GM Instruction", y.gm_generation_instruction)}</div>${zucSection("Shift Triggers", zucBullet(y.shift_triggers))}${zucSection("Combat State Interpretation", `<p class="sheet-description">${zucHtml(y.combat_state_interpretation)}</p>`)}${zucSection("Composite Hooks", zucBullet(y.composite_hooks))}`)}`;
}
function zucRenderEquipmentResourcesStates(model) {
  const ers = model.equipment_resources_states || {};
  const eqRows = (ers.equipment || []).map((e) => [e.name, e.type, e.equipped ? "yes" : "no", e.ac_contribution, e.notes, e.source]);
  const resRows = (ers.resources || []).map((r) => zucIsObject(r) ? [zucFirst(r.name, r.resource_name), zucFirst(r.current, r.value), zucFirst(r.max, r.maximum), zucFirst(r.formula, r.recovery), zucFirst(r.source, r.source_path)] : [r, "", "", "", ""]);
  const stateRows = (ers.states || []).map((s) => [s.name, s.created_by, s.duration, s.effect, s.end_condition, s.source]);
  return `${zucSection("Equipment", zucMiniTable(["Item", "Type", "Equipped", "AC", "Notes", "Source"], eqRows))}${zucSection("Resources", zucMiniTable(["Resource", "Current", "Max", "Formula / Recovery", "Source"], resRows))}${zucSection("States", zucMiniTable(["State", "Created By", "Duration", "Effect", "End", "Source"], stateRows))}`;
}
function zucRenderDiagnostics(model) {
  const rows = (model.diagnostics || []).map((d) => [String(d.severity || "").toUpperCase(), d.code, d.message, d.source, d.facet]);
  const fileRows = Object.entries(model.source_package?.source_map || {}).map(([name, v]) => [name, v.parsed_json ? "json parsed" : "text/source", v.recognized_by || ""]);
  return `<div class="sheet-detail-grid">${zucCard("View Model", model.schema)}${zucCard("Patch", model.patch)}${zucCard("Validation", model.validation?.verdict || "UNKNOWN")}${zucCard("Errors / Warnings", `${model.validation?.error_count ?? 0} errors / ${model.validation?.warning_count ?? 0} warnings`)}</div>${zucSection("Diagnostics", zucMiniTable(["Severity", "Code", "Message", "Source", "Facet"], rows))}${zucSection("Surface Discovery", zucMiniTable(["File", "Status", "Recognizer"], fileRows))}`;
}
function zucRenderVisualCharacterSheet(pkg, notes = {}) {
  const model = zucBuildViewModelV2(pkg);
  const id = model.identity || {};
  const cs = model.core_stats || {};
  const tabs = [
    ["overview-core-stats", "Overview / Core Stats", zucRenderOverview],
    ["leveling-ledger", "Leveling Ledger", zucRenderLeveling],
    ["background-origin", "Background & Origin", zucRenderBackground],
    ["spheres-talents", "Spheres & Talents", zucRenderSpheresTalents],
    ["actions", "Actions", zucRenderActions],
    ["composite-playbooks", "Composite Playbooks", zucRenderComposites],
    ["martial-manuals-recorded-arts", "Martial Manuals / Recorded Arts", zucRenderManuals],
    ["foundation", "Foundation", zucRenderFoundation],
    ["method", "Method", zucRenderMethod],
    ["dao-i-ching", "Dao & I Ching", zucRenderDaoIChing],
    ["equipment-resources-states", "Equipment / Resources / States", zucRenderEquipmentResourcesStates],
    ["diagnostics", "Diagnostics", zucRenderDiagnostics]
  ];
  return `<article class="sheet-card zuc-v2-sheet" data-view-model-schema="${ZUC_VIEW_SCHEMA}">
    <header class="sheet-hero"><div class="sheet-portrait">${escapeHtml(characterInitials(id.display_name || id.name || "TX"))}</div><div><h3>${zucHtml(id.display_name || id.name)}</h3><p>${zucHtml([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p><div class="sheet-tags"><span>${escapeHtml(ZUC_PATCH_ID)}</span><span>${escapeHtml(ZUC_VIEW_SCHEMA)}</span><span>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</span></div></div></header>
    <div class="sheet-stat-strip"><div class="sheet-stat"><strong>HP</strong><span>${zucHtml(`${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}</span></div><div class="sheet-stat"><strong>AC</strong><span>${zucHtml(cs.ac?.current ?? "—")}</span></div><div class="sheet-stat"><strong>Speed</strong><span>${zucHtml(cs.speed_ft !== null && cs.speed_ft !== undefined ? `${cs.speed_ft} ft` : "—")}</span></div><div class="sheet-stat"><strong>Attack</strong><span>${zucHtml(cs.attack_bonus === null || cs.attack_bonus === undefined ? "—" : formatSigned(cs.attack_bonus))}</span></div><div class="sheet-stat"><strong>Save DC</strong><span>${zucHtml(cs.save_dc ?? "—")}</span></div><div class="sheet-stat"><strong>Resource</strong><span>${zucHtml(`${cs.primary_resource?.name || "Resource"} ${cs.primary_resource?.current ?? "?"}/${cs.primary_resource?.max ?? "?"}`)}</span></div></div>
    <div class="sheet-main"><main class="sheet-column sheet-column-wide"><section class="sheet-section"><div class="sheet-section-body"><div class="sheet-tabs">${tabs.map(([slug, label], i) => zucTabButton(slug, label, i === 0)).join("")}</div>${tabs.map(([slug, , renderer], i) => zucTabPanel(slug, renderer(model), i === 0)).join("")}</div></section></main></div>
  </article>`;
}

const zucAnalyzePackageTextBefore = analyzePackageText;
analyzePackageText = function analyzePackageTextHf05zuc(text, preferredName = "", version = "") {
  const analysis = zucAnalyzePackageTextBefore(text, preferredName, version);
  const model = zucBuildViewModelV2(analysis);
  analysis.viewModelV2 = model;
  analysis.viewModelSchema = ZUC_VIEW_SCHEMA;
  analysis.name = model.identity?.display_name || analysis.name;
  analysis.path = model.identity?.path || analysis.path;
  analysis.realm = model.identity?.realm || analysis.realm;
  analysis.characterId = model.identity?.character_id || analysis.characterId;
  analysis.primary = model.spheres_talents?.spheres?.[0]?.name || analysis.primary;
  analysis.readiness = model.validation?.verdict || analysis.readiness;
  return analysis;
};

const zucBuildSheetDataBefore = buildCharacterSheetData;
buildCharacterSheetData = function buildCharacterSheetDataHf05zuc(pkg) {
  const sheet = zucBuildSheetDataBefore(pkg);
  const model = zucBuildViewModelV2({ ...pkg, sheetData: sheet });
  sheet.viewModelV2 = model;
  sheet.characterViewModelSchema = ZUC_VIEW_SCHEMA;
  return sheet;
};

const zucCompactSavedPackageBefore = compactSavedPackage;
compactSavedPackage = function compactSavedPackageHf05zuc(pkg) {
  const model = zucBuildViewModelV2(pkg);
  const saved = zucCompactSavedPackageBefore({ ...pkg, viewModelV2: model });
  saved.viewModelV2 = model;
  saved.save_schema = ZUC_COMPACT_SAVE_SCHEMA;
  saved.view_model_schema = ZUC_VIEW_SCHEMA;
  saved.modelSchema = ZUC_VIEW_SCHEMA;
  saved.name = model.identity?.display_name || saved.name;
  saved.characterId = model.identity?.character_id || saved.characterId;
  saved.hf05zuc = { patch: ZUC_PATCH_ID, validation: model.validation, source_discovery: model.source_package?.source_map || {} };
  return saved;
};

const zucRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zuc(pkg, notes = {}) {
  try { return zucRenderVisualCharacterSheet(pkg, notes); }
  catch (error) {
    const fallback = zucRenderVisualCharacterSheetBefore(pkg, notes);
    return `${fallback}<section class="sheet-section"><h4>HF05ZUC Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`;
  }
};

const zucCompositeRegistryDataBefore = compositeRegistryDataFromPackage;
compositeRegistryDataFromPackage = function compositeRegistryDataFromPackageHf05zuc(pkg, sheet = {}) {
  const base = zucCompositeRegistryDataBefore(pkg, sheet);
  const model = zucBuildViewModelV2(pkg);
  if (!model.composites?.length) return base;
  return { ...base, hasDeclaredComposites: true, composites: model.composites.map((c) => ({ ...c, id: c.composite_id, display_name: c.name, components: c.sequence })), sourceFiles: { ...(base.sourceFiles || {}), viewModelV2: true }, viewModelV2: model };
};

const zucPackageSelectLabelBefore = packageSelectLabel;
packageSelectLabel = function packageSelectLabelHf05zuc(item = {}) {
  const model = item?.viewModelV2;
  if (model?.identity?.display_name) return `${model.identity.display_name} — CL${model.identity.CL || "?"} ${model.identity.realm || "Realm unclear"}`;
  return zucPackageSelectLabelBefore(item);
};

const zucRenderPackageAnalysisBefore = renderPackageAnalysis;
renderPackageAnalysis = function renderPackageAnalysisHf05zuc(analysis) {
  zucRenderPackageAnalysisBefore(analysis);
  if (!analysis?.viewModelV2 || !$("packageAnalysis")) return;
  const model = analysis.viewModelV2;
  $("packageAnalysis").insertAdjacentHTML("beforeend", `<div class="status-grid"><div class="status-item ${model.validation?.error_count ? "warn" : "pass"}"><strong>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</strong> ${escapeHtml(ZUC_VIEW_SCHEMA)}</div><div class="status-item pass"><strong>${escapeHtml(ZUC_PATCH_ID)}</strong> Universal normalizer + composite runtime renderer</div></div>`);
};



/* =====================================================================
 * HF05ZUD-R1A — Stable Character Layout and Readable Composite UX Patch
 * Layout/readability patch only. Preserves HF05ZUC v2 model architecture.
 * ===================================================================== */
const ZUD_PATCH_ID = "HF05ZUD-R1A";

function zudSafeText(value, fallback = "Not recorded") {
  const text = zucValueText(value, fallback, 1200);
  if (!text || /^(?:null|undefined|none|n\/a|—|-)$/.test(String(text).trim().toLowerCase())) return fallback;
  return text;
}
function zudCleanText(value, fallback = "Not recorded") { return escapeHtml(zudSafeText(value, fallback)); }
function zudBadge(value, fallback = "") {
  const text = zudSafeText(value, fallback);
  return text && text !== "Not recorded" ? `<span class="zud-badge">${escapeHtml(text)}</span>` : "";
}
function zudField(label, value, fallback = "Not recorded") {
  return `<div class="zud-field"><strong>${escapeHtml(label)}</strong><span>${zudCleanText(value, fallback)}</span></div>`;
}
function zudFieldWide(label, value, fallback = "Not recorded") {
  return `<div class="zud-field zud-field-wide"><strong>${escapeHtml(label)}</strong><span>${zudCleanText(value, fallback)}</span></div>`;
}
function zudSection(title, html, cls = "") {
  return `<section class="zud-section ${escapeHtml(cls)}"><h4>${escapeHtml(title)}</h4><div class="zud-section-body">${html}</div></section>`;
}
function zuiR2ReadableRecord(value) {
  if (value === null || value === undefined) return "";
  if (!zucIsObject(value)) return zudSafeText(value, "");
  const preferred = [
    ["name", value.name], ["stage", value.stage], ["resource", value.resource_name || value.resource],
    ["modifier", value.modifier ?? value.amount ?? value.delta], ["formula", value.formula],
    ["effect", value.effect], ["note", value.note], ["source", value.source_packet_id || value.source]
  ].filter(([, v]) => v !== null && v !== undefined && String(v).trim());
  if (preferred.length) return preferred.map(([k,v]) => `${k}: ${zudSafeText(v, "")}`).join(" · ");
  return Object.entries(value).map(([k,v]) => `${k}: ${zudSafeText(v, "")}`).join(" · ");
}
function zuiR2ReadableList(value) {
  return zucArray(value).map(zuiR2ReadableRecord).filter(Boolean);
}
function zudBulletList(items = [], empty = "Not recorded.") {
  const list = zuiR2ReadableList(items);
  return list.length ? `<ul class="zud-list">${list.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : `<p class="zud-muted">${escapeHtml(empty)}</p>`;
}
function zudMiniKvs(entries = []) {
  return `<div class="zud-kv-grid">${entries.map(([k, v]) => zudField(k, v)).join("")}</div>`;
}
function zudDetailCard(title, body, cls = "") {
  return `<article class="zud-info-card ${escapeHtml(cls)}"><h5>${escapeHtml(title)}</h5><p>${zudCleanText(body)}</p></article>`;
}
function zudTabButton(slug, label, active = false) {
  return `<button class="zud-nav-button ${active ? "active" : ""}" type="button" data-sheet-tab="${escapeHtml(slug)}"><span>${escapeHtml(label)}</span></button>`;
}
function zudTabPanel(slug, html, active = false) {
  return `<section class="zud-tab-panel ${active ? "active" : ""}" data-sheet-panel="${escapeHtml(slug)}"><div class="zud-panel-scroll">${html}</div></section>`;
}
function zudActionCategory(action = {}) {
  const hay = `${action.row_type || ""} ${action.source || ""} ${action.name || ""} ${action.action_id || ""}`.toLowerCase();
  const econ = String(action.economy || "").toLowerCase();
  if (/basic|system|universal|dodge|dash|disengage|help|hide|ready|search|use object|improvised|grapple|shove/.test(hay)) return "basic/system actions";
  if (/reaction/.test(econ) || /reaction/.test(hay)) return "reactions";
  if (/bonus/.test(econ) || /bonus/.test(hay)) return "bonus actions";
  if (/passive|always|static/.test(econ) || /passive|always on|static/.test(hay)) return "passives";
  return "signature actions";
}
function zudActionCard(a = {}, compact = false) {
  return `<article class="zud-action-card ${compact ? "compact" : ""}">
    <header><h5>${zudCleanText(a.name || a.display_name || a.action_id, "Unnamed action")}</h5><div class="zud-badges">${zudBadge(a.economy)}${zudBadge(a.timing)}${zudBadge(a.action_id)}</div></header>
    <div class="zud-action-grid">
      ${zudField("Cost", a.cost)}${zudField("Range", a.range)}${zudField("Target", a.target)}${zudField("Roll / Save", a.roll_or_save)}
      ${zudFieldWide("Success / Effect", a.effect)}${compact ? "" : zudField("Duration", a.duration)}${compact ? "" : zudField("Limit", a.limit)}${compact ? "" : zudFieldWide("Counterplay", a.counterplay)}
    </div>
  </article>`;
}
function zudRenderActions(model) {
  const actions = model.actions || [];
  const groups = {
    "signature actions": [],
    "reactions": [],
    "bonus actions": [],
    "passives": [],
    "basic/system actions": []
  };
  actions.forEach((a) => { (groups[zudActionCategory(a)] || groups["signature actions"]).push(a); });
  const order = ["signature actions", "reactions", "bonus actions", "passives"];
  const normal = order.map((name) => zudSection(zucDisplay(name), groups[name].length ? `<div class="zud-card-stack">${groups[name].map((a) => zudActionCard(a)).join("")}</div>` : `<p class="zud-muted">No ${escapeHtml(name)} recorded.</p>`, "zud-action-group")).join("");
  const basics = `<details class="zud-collapsible"><summary>Basic / system actions (${groups["basic/system actions"].length})</summary><div class="zud-card-stack">${groups["basic/system actions"].map((a) => zudActionCard(a, true)).join("") || `<p class="zud-muted">No basic/system actions recorded.</p>`}</div></details>`;
  return `<div class="zud-tab-heading"><h3>Actions</h3><p>Gameplay actions are grouped into cards; basic/system actions are collapsed so they do not dominate the combat view.</p></div>${normal}${basics}`;
}
function zudStepCard(step = {}, index = 0) {
  return `<article class="zud-step-card">
    <header><span class="zud-step-number">${escapeHtml(step.step || index + 1)}</span><div><h5>${zudCleanText(step.action_name || step.name || step.action_id, "Unnamed component")}</h5><p>${zudCleanText(step.action_id, "Action ID not recorded")}</p></div></header>
    <div class="zud-step-grid">
      ${zudField("Timing", step.timing)}${zudField("Economy", step.economy)}${zudField("Cost", step.cost)}${zudField("Range", step.range)}${zudField("Target", step.target)}${zudField("Roll / Save", step.roll_or_save)}
      ${zudFieldWide("Success / Effect", step.success_effect)}${zudFieldWide("Failure / Limit", step.failure_or_limit)}${zudField("Duration", step.duration)}${zudFieldWide("Counterplay", step.counterplay)}
    </div>
  </article>`;
}
function zudLinkedActionCard(action = {}, index = 0) {
  return `<details class="zud-linked-action"><summary>${escapeHtml(action.name || action.display_name || action.action_id || `Linked Action ${index + 1}`)} <span>${escapeHtml(action.action_id || "no id")}</span></summary>${zudActionCard(action)}</details>`;
}
function zudRenderComposites(model) {
  const composites = model.composites || [];
  if (!composites.length) return `<p class="zud-muted">No composite playbooks recorded.</p>`;
  return `<div class="zud-tab-heading"><h3>Composite Playbooks</h3><p>Each composite is rendered as an execution card: use conditions, budget, fallback, hooks, component sequence, linked actions, and diagnostics.</p></div><div class="zud-composite-stack">${composites.map((c, i) => {
    const temporal = `${c.temporal_feasibility?.same_turn_legal ? "Same-turn legal when listed windows match" : "Not automatically same-turn legal"}${c.temporal_feasibility?.synthesized ? " — synthesized/fallback label" : ""}; ${c.temporal_feasibility?.round_segmentation || "No round segmentation recorded"}`;
    return `<article class="zud-composite-card">
      <header class="zud-composite-head"><div><p class="zud-eyebrow">${escapeHtml(c.priority ? `Priority ${c.priority}` : `Composite ${i + 1}`)}${c.execution_role ? ` · ${escapeHtml(c.execution_role)}` : ""}</p><h4>${zudCleanText(c.name, "Unnamed composite")}</h4></div><div class="zud-badges">${zudBadge(c.category)}${zudBadge(c.composite_id)}</div></header>
      <div class="zud-composite-summary">
        ${zudDetailCard("When to use", c.when_to_use)}${zudDetailCard("Do not use when", c.do_not_use_when)}${zudDetailCard("Resource budget", c.resource_budget)}${zudDetailCard("Economy footprint", c.economy_footprint)}${zudDetailCard("Temporal feasibility", temporal)}${zudDetailCard("Fallback", c.fallback)}${zudDetailCard("Dao hook", c.dao_hook)}${zudDetailCard("I Ching hook", c.i_ching_hook)}
      </div>
      ${zudSection("Component sequence", `<div class="zud-step-stack">${(c.sequence || []).map(zudStepCard).join("") || `<p class="zud-muted">No component steps recorded.</p>`}</div>`, "zud-components")}
      ${zudSection("Linked action details", `<div class="zud-linked-stack">${(c.linked_actions || []).map(zudLinkedActionCard).join("") || `<p class="zud-muted">No linked actions recorded.</p>`}</div>`, "zud-linked")}
      ${zudSection("Diagnostics", zudBulletList(c.diagnostics, "No composite diagnostics."), "zud-diagnostics-mini")}
    </article>`;
  }).join("")}</div>`;
}
function zudManualCard(m = {}, index = 0) {
  const multiSphere = (m.source_spheres || []).length > 1;
  const unclassifiedCustom = m.custom_design && multiSphere && m.expression_kind !== "preserved_forged_expression";
  const expressionLabel = ({ single_sphere_expression: "Single-Sphere expression", source_authored_lineage_expression: "Source-authored lineage expression", preserved_forged_expression: "Preserved Forged expression", unclassified: "Expression unclassified" })[m.expression_kind] || m.expression_kind;
  return `<article class="zud-manual-card${unclassifiedCustom ? " zui-r2-contract-warning" : ""}">
    <header><div><p class="zud-eyebrow">${zudCleanText(m.manual_name, "Manual not recorded")}</p><h5>${zudCleanText(m.technique_name, `Technique ${index + 1}`)}</h5></div><div class="zud-badges">${zudBadge(expressionLabel)}${zudBadge(m.realm_gate)}${zudBadge(m.DC ? `DC ${m.DC}` : "")}</div></header>
    <div class="zud-manual-grid">
      ${zudField("Sphere(s)", m.source_spheres)}${zudField("Reproduced package", m.reproduced_ability)}${zudField("Timing", m.timing_economy)}${zudField("Cost", m.cost)}${zudField("Range", m.range)}${zudField("Target", m.target)}${zudField("Roll / Save / Check", m.roll_save_check)}${zudFieldWide("Effect", m.effect)}${zudFieldWide("Failure", m.failure_miss)}${zudField("Duration", m.duration)}${zudField("Limit", m.limit)}${zudFieldWide("Counterplay", m.counterplay)}${zudField("Linked action", m.linked_action_refs)}${zudField("Source packets", m.source_packet_ids)}
    </div>
    ${unclassifiedCustom ? `<aside class="zud-policy-note zui-r2-warning-note"><strong>Classification warning</strong><span>This custom multi-Sphere technique is not recorded as a preserved Forged expression. HF05ZVK-R1E rejects it until it is rebuilt under the Forged Technique rules or simplified to a single-Sphere Recorded Art.</span></aside>` : ""}
    ${m.policy_notes ? `<aside class="zud-policy-note"><strong>Policy note</strong><span>${zudCleanText(m.policy_notes)}</span></aside>` : ""}
  </article>`;
}

function zudTrainingSourceCard(source = {}, index = 0) {
  const contents = source.contents || {};
  return `<article class="zud-manual-card zui-training-source-card">
    <header><div><p class="zud-eyebrow">${zudCleanText(source.type, "Training source")}</p><h5>${zudCleanText(source.name, `Source ${index + 1}`)}</h5></div><div class="zud-badges">${zudBadge(source.gained_at_cl ? `CL ${source.gained_at_cl}` : "")}${zudBadge(source.source_id)}</div></header>
    <div class="zud-manual-grid">
      ${zudField("Recorded Arts", contents.recorded_arts?.length ? contents.recorded_arts : "None associated with this source")}${zudField("Methods", contents.methods?.length ? contents.methods : "None associated with this source")}${zudFieldWide("Theory", contents.theory)}${zudFieldWide("Warnings", contents.warnings)}${zudFieldWide("Restrictions", source.restrictions)}${zudFieldWide("Risks", source.risks)}${zudFieldWide("Mechanics granted", source.mechanics_granted)}${zudField("Source authority", source.source)}
    </div>
  </article>`;
}
function zudRenderManuals(model) {
  const manuals = model.martial_manuals || [];
  const sources = model.training_sources || [];
  return `<div class="zud-tab-heading"><h3>Martial Manuals / Recorded Arts</h3><p>Training provenance is displayed separately from fixed Recorded Art execution cards.</p></div>${zudSection("Manual / lineage / teacher sources", `<div class="zud-card-stack">${sources.length ? sources.map(zudTrainingSourceCard).join("") : `<p class="zud-muted">No training source record was imported.</p>`}</div>`)}${zudSection("Recorded Arts", `<div class="zud-card-stack">${manuals.length ? manuals.map(zudManualCard).join("") : `<p class="zud-muted">No Recorded Arts learned from the recorded source.</p>`}</div>`)}`;
}
function zudRenderLeveling(model) {
  const levels = model.leveling_ledger || [];
  const byRealm = {};
  levels.forEach((r) => { const key = r.realm || "Realm not recorded"; (byRealm[key] ||= []).push(r); });
  const realmCards = Object.entries(byRealm).map(([realm, rows]) => `<section class="zud-realm-card"><h4>${escapeHtml(realm)}</h4><div class="zud-level-grid">${rows.map((r) => `<article class="zud-level-card"><header><strong>CL ${escapeHtml(r.CL ?? "?")}</strong><span>PB ${escapeHtml(r.PB ?? "?")}</span></header><div class="zud-level-fields">${zudField("HP / Resource", [r.hp_gain, r.resource_max_after_level].filter(Boolean).join(" / "))}${zudField("Free level talent", r.free_level_talent)}${zudField("New sphere + bonus", [...(r.new_spheres_gained||[]), ...(r.new_sphere_bonus_talents||[])])}${zudField("Trained choices", `${(r.trained_choices||[]).length}/3 ${zucValueText(r.trained_choices, "")}`)}${zudField("Background / Origin", [...(r.background_grants||[]), r.origin_insight].filter(Boolean))}${zudField("Method / Foundation", [r.method_event, r.foundation_event].filter(Boolean))}${zudField("Manuals / Recorded Arts", r.manuals_or_recorded_arts)}${zudField("Forged", r.forged_techniques)}${zudField("Validation", r.validation_notes)}</div></article>`).join("")}</div></section>`).join("");
  return `<div class="zud-tab-heading"><h3>Leveling Ledger</h3><p>Grouped by realm so the full page does not stretch into a wide spreadsheet.</p></div>${realmCards || `<p class="zud-muted">No leveling ledger recorded.</p>`}`;
}
function zudRenderBackground(model) {
  const b = model.background_origin?.background || {};
  const o = model.background_origin?.origin_insight || {};
  const eq = b.equipment_reconciliation || {};
  const effects = (o.effect_records || []).map((row) => `<article class="zud-action-card compact"><header><h5>${zudCleanText(row.name || row.effect_type || "Origin effect")}</h5><div class="zud-badges">${zudBadge(row.display_surface)}${zudBadge(row.trigger || row.condition)}</div></header><p class="zud-muted">${zudCleanText(row.effect)}</p>${row.source_claim_text ? `<p class="zud-source-note"><strong>Source claim:</strong> ${zudCleanText(row.source_claim_text)}</p>` : ""}</article>`).join("");
  return `<div class="zud-tab-heading"><h3>Background & Origin</h3><p>Complete origin grants, proficiencies, equipment reconciliation, and source-faithful Origin effects.</p></div>
    <div class="zud-two-card-grid">
      <article class="zud-large-card"><h4>Background</h4>${zudMiniKvs([["Background", b.name], ["Background Sphere", b.background_sphere], ["Background Talent", b.background_talent], ["Skills", b.skill_proficiencies], ["Tools / Vehicles", b.tool_proficiencies], ["Languages", b.languages], ["Compensation", b.compensation], ["Equipment", b.equipment], ["Ledger equipment IDs", eq.ledger_equipment_ids], ["Bundled items", eq.bundled_items], ["Missing printed items", zuiR2ExplicitList(eq.missing_items, "None.")], ["Reconciliation", eq.note], ["Notes", b.notes || b.summary], ["Source", b.source]])}</article>
      <article class="zud-large-card"><h4>Origin Insight</h4>${zudMiniKvs([["Insight", o.name], ["Benefit Summary", o.benefit], ["Restrictions", o.restrictions], ["Count Flags", `Background ${!!o.counts_against_background}; Level Talent ${!!o.counts_against_level_talent}; Trained ${!!o.counts_against_trained_choices}`], ["Source", o.source]])}${zudSection("Executable / procedural effects", `<div class="zud-card-stack">${effects || `<p class="zud-muted">No Origin effect records were projected.</p>`}</div>`)}</article>
    </div>`;
}
function zudRenderSpheresTalents(model) {
  const st = model.spheres_talents || {};
  const coverageText = (c = {}) => [c.classification ? `Coverage: ${c.classification}` : "", (c.action_ids || []).length ? `Actions: ${(c.action_ids || []).join(", ")}` : "", (c.target_action_ids || []).length ? `Modifies: ${(c.target_action_ids || []).join(", ")}` : "", c.display_surface ? `Surface: ${c.display_surface}` : ""].filter(Boolean).join(" · ");
  const spheres = (st.spheres || []).map((s) => `<article class="zud-chip-card"><strong>${zudCleanText(s.name, "Sphere")}</strong><span>${zudCleanText(coverageText(s.execution_coverage) || s.source)}</span></article>`).join("");
  const talents = (st.talents || []).map((t) => `<article class="zud-action-card compact"><header><h5>${zudCleanText(t.name, "Talent")}</h5><div class="zud-badges">${zudBadge(t.sphere)}${zudBadge(t.source_type)}${zudBadge(t.gained_at_CL ? `CL ${t.gained_at_CL}` : "")}${zudBadge(t.execution_coverage?.classification)}</div></header><p class="zud-muted">${zudCleanText(t.effect)}</p><p class="zud-source-note">${zudCleanText(coverageText(t.execution_coverage), "Execution coverage is not projected.")}</p></article>`).join("");
  return `<div class="zud-tab-heading"><h3>Spheres & Talents</h3></div>${zudSection("Known Spheres", `<div class="zud-chip-grid">${spheres || `<p class="zud-muted">No spheres recorded.</p>`}</div>`)}${zudSection("Talents", `<div class="zud-card-stack">${talents || `<p class="zud-muted">No talents recorded.</p>`}</div>`)}`;
}
function zudRenderOverview(model) {
  const cs = model.core_stats || {};
  const abilityCards = (cs.ability_scores || []).map((a) => `<article class="zud-ability-card"><strong>${escapeHtml(a.ability || "Ability")}</strong><b>${escapeHtml(a.score ?? "—")}</b><span>Mod ${escapeHtml(a.modifier === null ? "—" : formatSigned(a.modifier))}</span><span>Save ${escapeHtml(a.save === null ? "—" : formatSigned(a.save))}</span></article>`).join("");
  const skills = (cs.skills || []).map((s) => `<span>${escapeHtml(s.name || "Skill")} ${escapeHtml(s.bonus === null ? "—" : formatSigned(s.bonus))}${s.proficient ? " *" : ""}</span>`).join("");
  return `<div class="zud-tab-heading"><h3>Overview / Core Stats</h3><p>Stable combat math and quick-read defenses.</p></div>
    <div class="zud-core-grid">${zudDetailCard("Armor Class", `${cs.ac?.current ?? "—"}${cs.ac?.math?.length ? ` (${zucValueText(cs.ac.math)})` : ""}`)}${zudDetailCard("Hit Points", `${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}${zudDetailCard("Speed", cs.speed_ft !== null && cs.speed_ft !== undefined ? `${cs.speed_ft} ft` : "—")}${zudDetailCard("Attack Bonus", cs.attack_bonus === null ? "—" : formatSigned(cs.attack_bonus))}${zudDetailCard("Save DC", cs.save_dc ?? "—")}${zudDetailCard("Primary Resource", `${cs.primary_resource?.name || "Resource"} ${cs.primary_resource?.current ?? "?"}/${cs.primary_resource?.max ?? "?"}`)}</div>
    ${zudSection("Ability Scores / Saves", `<div class="zud-ability-grid">${abilityCards || `<p class="zud-muted">No ability scores recorded.</p>`}</div>`)}
    ${zudSection("Skills", `<div class="zud-skill-cloud">${skills || `<p class="zud-muted">No skill bonuses recorded.</p>`}</div>`)}
    <div class="zud-two-card-grid">${zudSection("Senses", zudBulletList(cs.senses))}${zudSection("Defenses", zudBulletList(cs.defenses, "None."))}</div>`;
}
function zudRenderFoundation(model) {
  const f = model.foundation || {};
  const stageRows = Array.isArray(f.stage_benefit_map)
    ? f.stage_benefit_map.map((row) => ({ stage: row.stage || "Stage", available: row.available, benefits: row.benefits || [], sources: row.source_packet_ids || [] }))
    : Object.entries(f.stage_benefit_map || {}).map(([stage, rows]) => ({ stage, available: true, benefits: zucArray(rows), sources: [] }));
  const stages = stageRows.map((row) => `<article class="zud-chip-card"><strong>${zudCleanText(row.stage)}</strong><span>${row.available === false ? "Unavailable at current stage" : zudCleanText(zuiR2ReadableList(row.benefits).join(" · "), "No separate benefit recorded")}${row.sources.length ? `<br><small>Sources: ${escapeHtml(row.sources.join(", "))}</small>` : ""}</span></article>`).join("");
  const lifecycleOrder = ["passive_chassis","resources","actions_reactions","states","burdens","hidden_injuries","strains","deviations","integration","repair","treatment","temptations","failure_consequences"];
  const lifecycle = lifecycleOrder.map((key) => { const row=(f.lifecycle_coverage || {})[key] || {}; return `<article class="zud-action-card compact"><header><h5>${zudCleanText(key.replaceAll("_"," "))}</h5><div class="zud-badges">${zudBadge(row.status)}</div></header>${zudBulletList(row.entries, row.note || "No separate entry printed for this category.")}</article>`; }).join("");
  return `<div class="zud-tab-heading"><h3>Foundation</h3><p>All attained stage benefits stack with the active Method when their printed rules modify the same resource. Full lifecycle risks and correction procedures are retained.</p></div><article class="zud-large-card zud-foundation-card"><h4>${zudCleanText(f.name || "Foundation not recorded")}</h4><div class="zud-badges">${zudBadge(f.grade)}${zudBadge(f.status_stage)}${zudBadge(f.source)}</div></article>${zudSection("Benefits by attained stage", `<div class="zud-chip-grid">${stages || `<p class="zud-muted">No stage map projected.</p>`}</div>`)}<div class="zud-two-card-grid">${zudSection("Prominent Benefits", zudBulletList(f.benefits), "zud-prominent")}${zudSection("Passive Chassis", zudBulletList(f.passive_chassis), "zud-prominent")}${zudSection("Primary-resource modifiers", zudBulletList(f.primary_resource_modifiers, "None printed."))}${zudSection("Resources / Counters", zudBulletList(f.resources_counters))}${zudSection("Actions / Riders", zudBulletList(f.actions_riders))}${zudSection("Fixed Scope", zudBulletList(f.fixed_scope))}${zudSection("Suppressed / excluded benefits", zudBulletList(f.suppressed_or_excluded_benefits, "None."))}${zudSection("AI Piloting Notes", zudBulletList(f.ai_notes))}</div>${zudSection("Foundation lifecycle", `<div class="zud-card-stack">${lifecycle}</div>`)}`;
}
function zudRenderMethod(model) {
  const m = model.method || {};
  return `<div class="zud-tab-heading"><h3>Method</h3><p>Method effects and applied math are kept prominent and separate from compatibility notes.</p></div><article class="zud-large-card"><h4>${zudCleanText(m.name || "No cultivation method recorded")}</h4><div class="zud-badges">${zudBadge(m.status)}${zudBadge(m.resource_shape)}${zudBadge(m.source)}</div></article><div class="zud-two-card-grid">${zudSection("Mechanical Effects", zudBulletList(m.mechanical_effects), "zud-prominent")}${zudSection("Applied Math", zudBulletList(m.applied_math), "zud-prominent")}${zudSection("Method / Foundation stacking", `<p class="zud-muted">${zudCleanText(m.stacking_statement)}</p>${zudBulletList(m.resource_modifiers, "No separate Method resource modifier.")}`)}${zudSection("Breakthrough Shape", `<p class="zud-muted">${zudCleanText(m.breakthrough_shape)}</p>`)}${zudSection("Foundation Compatibility", zudBulletList(m.foundation_compatibility))}${zudSection("Incompatibilities", zudBulletList(m.incompatibilities))}</div>`;
}
function zudRenderDaoIChing(model) {
  const d = model.dao_i_ching?.dao || {};
  const y = model.dao_i_ching?.i_ching || {};
  return `<div class="zud-tab-heading"><h3>Dao & I Ching</h3><p>Combat doctrine, trigger interpretation, and composite hooks in readable cards.</p></div><div class="zud-two-card-grid"><article class="zud-large-card"><h4>Dao</h4>${zudMiniKvs([["Dao Phrase", d.dao_phrase], ["Combat Doctrine", d.combat_doctrine], ["Resource Policy", d.resource_policy], ["Reaction Policy", d.reaction_policy], ["AI Turn Prompt", d.ai_turn_prompt], ["Preferred Engagements", d.preferred_engagements], ["Avoidance Rules", d.avoidance_rules], ["Risk Thresholds", d.risk_thresholds], ["Target Selection", d.target_selection_logic], ["Failure Recovery", d.failure_recovery], ["Forbidden Behaviors", d.forbidden_behaviors], ["Composite Hooks", d.composite_hooks]])}</article><article class="zud-large-card"><h4>I Ching</h4>${zudMiniKvs([["Enabled", y.enabled ? "Yes" : "No"], ["Reading", y.reading_name], ["Hexagram / Trigram", y.hexagram_or_trigram], ["Natural Tendency", y.natural_tendency], ["Testing Tendency", y.testing_tendency], ["Low-Resource Shift", y.low_resource_shift], ["GM Instruction", y.gm_generation_instruction], ["Shift Triggers", y.shift_triggers], ["Combat State Interpretation", y.combat_state_interpretation], ["Composite Hooks", y.composite_hooks]])}</article></div>`;
}
function zudRenderEquipmentResourcesStates(model) {
  const ers = model.equipment_resources_states || {};
  const eq = (ers.equipment || []).map((e) => `<article class="zud-chip-card"><strong>${zudCleanText(e.name, "Item")}</strong><span>${zudCleanText([e.type, e.equipped ? "equipped" : "", e.ac_contribution ? `AC ${e.ac_contribution}` : "", e.notes].filter(Boolean).join(" | "))}</span></article>`).join("");
  const res = (ers.resources || []).map((r) => zucIsObject(r) ? `<article class="zud-chip-card"><strong>${zudCleanText(zucFirst(r.name, r.resource_name), "Resource")}</strong><span>${zudCleanText(`${zucFirst(r.current, r.value, "?")}/${zucFirst(r.max, r.maximum, "?")} ${zucFirst(r.formula, r.recovery, "")}`)}</span></article>` : `<article class="zud-chip-card"><strong>${zudCleanText(r, "Resource")}</strong></article>`).join("");
  const states = (ers.states || []).map((s) => `<article class="zud-action-card compact"><header><h5>${zudCleanText(s.name, "State")}</h5><div class="zud-badges">${zudBadge(s.duration)}${zudBadge(s.created_by)}</div></header><p class="zud-muted">${zudCleanText([s.effect, s.end_condition, s.source].filter(Boolean).join(" | "))}</p></article>`).join("");
  return `<div class="zud-tab-heading"><h3>Equipment / Resources / States</h3></div>${zudSection("Equipment", `<div class="zud-chip-grid">${eq || `<p class="zud-muted">No equipment recorded.</p>`}</div>`)}${zudSection("Resources", `<div class="zud-chip-grid">${res || `<p class="zud-muted">No resources recorded.</p>`}</div>`)}${zudSection("States", `<div class="zud-card-stack">${states || `<p class="zud-muted">No states recorded.</p>`}</div>`)}`;
}
function zudDiagnosticsSummary(model) {
  const diags = model.diagnostics || [];
  const missing = diags.filter((d) => /MISSING|NOT_RECORDED|UNRESOLVED/i.test(`${d.code} ${d.message}`)).map((d) => `${d.code}: ${d.message}`);
  const synth = diags.filter((d) => /SYNTH|fallback|adapter/i.test(`${d.code} ${d.message} ${d.source}`)).map((d) => `${d.code}: ${d.message}`);
  const hazards = diags.filter((d) => /OBJECT|NaN|undefined|numeric|hazard/i.test(`${d.code} ${d.message}`)).map((d) => `${d.code}: ${d.message}`);
  return { missing, synth, hazards };
}
function zudRenderDiagnostics(model) {
  const s = zudDiagnosticsSummary(model);
  return `<div class="zud-tab-heading"><h3>Diagnostics</h3><p>Gameplay tabs stay clean; renderer and adapter diagnostics live here.</p></div><div class="zud-core-grid">${zudDetailCard("Renderer Mode", `${ZUD_PATCH_ID} stable layout over ${ZUC_VIEW_SCHEMA}`)}${zudDetailCard("v2 Model Loaded", model.schema === ZUC_VIEW_SCHEMA || model.schema_version === ZUC_VIEW_SCHEMA ? "Yes" : "No")}${zudDetailCard("Fallback Adapters Used", s.synth.length ? `${s.synth.length} synthesized/fallback diagnostics` : "None flagged")}${zudDetailCard("Missing High-Priority Fields", s.missing.length ? `${s.missing.length} diagnostics` : "None flagged")}${zudDetailCard("Render Hazards", s.hazards.length ? `${s.hazards.length} diagnostics` : "None flagged")}${zudDetailCard("Tabs With Synthesized Data", s.synth.length ? s.synth.slice(0, 6).join("; ") : "None flagged")}</div>${zudSection("Missing / Unresolved", zudBulletList(s.missing, "None flagged."))}${zudSection("Fallback / Synthesized", zudBulletList(s.synth, "None flagged."))}${zudSection("Render Hazards", zudBulletList(s.hazards, "None flagged."))}${zudSection("All Model Diagnostics", zudBulletList((model.diagnostics || []).map((d) => `${String(d.severity || "").toUpperCase()} ${d.code}: ${d.message} [${d.source || "no source"}]`), "No model diagnostics."))}`;
}
function zudLeftRail(model, tabs) {
  const id = model.identity || {};
  const cs = model.core_stats || {};
  const stat = (label, value) => `<div class="zud-rail-stat"><strong>${escapeHtml(label)}</strong><span>${zudCleanText(value)}</span></div>`;
  return `<aside class="zud-left-rail"><section class="zud-rail-summary"><div class="zud-rail-portrait">${escapeHtml(characterInitials(id.display_name || id.name || "TX"))}</div><h4>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h4><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></section><section class="zud-rail-stats">${stat("HP", `${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}${stat("AC", cs.ac?.current ?? "—")}${stat("Speed", cs.speed_ft !== null && cs.speed_ft !== undefined ? `${cs.speed_ft} ft` : "—")}${stat("Attack", cs.attack_bonus === null || cs.attack_bonus === undefined ? "—" : formatSigned(cs.attack_bonus))}${stat("Save DC", cs.save_dc ?? "—")}${stat(cs.primary_resource?.name || "Resource", `${cs.primary_resource?.current ?? "?"}/${cs.primary_resource?.max ?? "?"}`)}</section><nav class="zud-tab-nav" aria-label="Character detail tabs">${tabs.map(([slug, label], i) => zudTabButton(slug, label, i === 0)).join("")}</nav></aside>`;
}
function zudRenderVisualCharacterSheet(pkg, notes = {}) {
  const model = zucBuildViewModelV2(pkg);
  const id = model.identity || {};
  const tabs = [
    ["overview-core-stats", "Overview / Core Stats", zudRenderOverview],
    ["leveling-ledger", "Leveling Ledger", zudRenderLeveling],
    ["background-origin", "Background & Origin", zudRenderBackground],
    ["spheres-talents", "Spheres & Talents", zudRenderSpheresTalents],
    ["actions", "Actions", zudRenderActions],
    ["composite-playbooks", "Composite Playbooks", zudRenderComposites],
    ["martial-manuals-recorded-arts", "Martial Manuals / Recorded Arts", zudRenderManuals],
    ["immortal-arts", "Immortal Arts", zuiR2RenderImmortalArts],
    ["foundation", "Foundation", zudRenderFoundation],
    ["method", "Method", zudRenderMethod],
    ["dao-i-ching", "Dao & I Ching", zudRenderDaoIChing],
    ["equipment-resources-states", "Equipment / Resources / States", zudRenderEquipmentResourcesStates],
    ["diagnostics", "Diagnostics", zudRenderDiagnostics]
  ];
  return `<article class="sheet-card zud-v2-sheet" data-view-model-schema="${ZUC_VIEW_SCHEMA}" data-renderer-patch="${ZUD_PATCH_ID}">
    <header class="zud-sheet-header"><div><p class="zud-eyebrow">Tianxia GM Screen · Stable Character View</p><h3>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h3><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></div><div class="zud-header-tags"><span>${escapeHtml(ZUD_PATCH_ID)}</span><span>${escapeHtml(ZUC_VIEW_SCHEMA)}</span><span>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</span></div></header>
    <div class="zud-character-shell">${zudLeftRail(model, tabs)}<main class="zud-main-panel">${tabs.map(([slug, , renderer], i) => zudTabPanel(slug, renderer(model), i === 0)).join("")}</main></div>
  </article>`;
}

const zudRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zud(pkg, notes = {}) {
  try { return zudRenderVisualCharacterSheet(pkg, notes); }
  catch (error) {
    const fallback = zudRenderVisualCharacterSheetBefore(pkg, notes);
    return `${fallback}<section class="sheet-section"><h4>HF05ZUD Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`;
  }
};

/* =====================================================================
 * HF05ZUE-R1A — Resource Display and Composite Drilldown UX Repair
 * Narrow UI/UX patch over HF05ZUC/HF05ZUD. Preserves v2 architecture.
 * ===================================================================== */
const ZUE_PATCH_ID = "HF05ZUF-R1A";

function zueBlankish(value) {
  if (value === undefined || value === null) return true;
  const text = String(value).trim();
  return !text || /^(?:\?|\?\/\?|-|—|–|n\/?a|none|null|undefined|unknown)$/i.test(text);
}
function zueValidResourceNumber(value) {
  if (value === undefined || value === null) return false;
  if (typeof value === "number") return Number.isFinite(value);
  const text = String(value).trim();
  if (zueBlankish(text)) return false;
  if (/^\d+(?:\.\d+)?$/.test(text)) return true;
  return false;
}
function zueResourceNumber(value) {
  if (!zueValidResourceNumber(value)) return null;
  if (typeof value === "number") return value;
  const n = Number(String(value).trim());
  return Number.isFinite(n) ? n : null;
}
function zueResourceNameFallback(identity = {}) {
  const path = String(identity.path || "").toLowerCase();
  if (/body/.test(path)) return "Stamina";
  if (/spirit/.test(path)) return "Resonance";
  if (/qi|core|cultivation/.test(path)) return "Qi";
  return "Resource";
}
function zueResourceCleanName(value, identity = {}) {
  if (zueBlankish(value)) return zueResourceNameFallback(identity);
  let text = String(value).trim();
  if (/cultivation points|\bcp\b/i.test(text)) text = /qi/i.test(String(identity.path || "")) ? "Qi" : "Cultivation Points";
  return text;
}
function zueReadFirst(obj = {}, keys = []) {
  if (!obj || typeof obj !== "object") return undefined;
  for (const key of keys) {
    if (obj[key] !== undefined && obj[key] !== null && obj[key] !== "") return obj[key];
  }
  return undefined;
}
function zueMakeResourceCandidate(name, current, max, source, identity = {}) {
  const currentN = zueResourceNumber(current);
  const maxN = zueResourceNumber(max);
  if (currentN === null && maxN === null) return null;
  const finalMax = maxN !== null ? maxN : currentN;
  const finalCur = currentN !== null ? currentN : finalMax;
  return {
    name: zueResourceCleanName(name, identity),
    current: finalCur,
    max: finalMax,
    source,
    score: (currentN !== null ? 4 : 0) + (maxN !== null ? 4 : 0) + (!zueBlankish(name) ? 2 : 0) + (/Character_Import_Surface|combat_stats|Normalized_Sheet|Limited_Resource|resources\[\]/i.test(source || "") ? 1 : 0)
  };
}
function zueResourceCandidateFromObject(obj = {}, source = "object", identity = {}) {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  const name = zueReadFirst(obj, ["primary_resource_name", "resource_name", "resourceName", "display_name", "displayName", "name", "label", "id", "resource_id", "resource", "primary_resource", "type"]);
  const current = zueReadFirst(obj, ["primary_resource_current", "resource_current", "current_resource", "resourceCurrent", "current", "current_default", "remaining", "value_current", "current_cp", "current_qi", "current_stamina", "current_resonance"]);
  const max = zueReadFirst(obj, ["primary_resource_max", "resource_max", "max_resource", "resourceMax", "max", "maximum", "total", "value", "max_cp", "max_qi", "max_stamina", "max_resonance"]);
  return zueMakeResourceCandidate(name, current, max, source, identity);
}
function zueResourceCandidatesFromList(list = [], source = "resources[]", identity = {}) {
  return zucArray(list)
    .map((row, i) => zueResourceCandidateFromObject(row, `${source}[${i}]`, identity))
    .filter(Boolean)
    .filter((row) => !/^(?:hp|hit points|reaction|reactions|armor class|ac)$/i.test(String(row.name || "")));
}
function zueResourceCandidatesFromSurface(obj = {}, source = "surface", identity = {}) {
  const candidates = [];
  if (!obj || typeof obj !== "object") return candidates;
  const objectSources = [
    [obj, source],
    [obj.stats, `${source}.stats`],
    [obj.combat_stats, `${source}.combat_stats`],
    [obj.combat, `${source}.combat`],
    [obj.resources && obj.resources.primary, `${source}.resources.primary`],
    [obj.primary_resource, `${source}.primary_resource`],
    [obj.resource, `${source}.resource`],
    [obj.resource_ledger, `${source}.resource_ledger`],
    [obj.resourceLedger, `${source}.resourceLedger`]
  ];
  objectSources.forEach(([entry, label]) => {
    if (entry && typeof entry === "object" && !Array.isArray(entry)) {
      const cand = zueResourceCandidateFromObject(entry, label, identity);
      if (cand) candidates.push(cand);
    }
  });
  // String resource name at root plus current/max siblings.
  const directName = zueReadFirst(obj, ["resource", "primary_resource", "primary_resource_name", "resource_name", "resourceName"]);
  const directCurrent = zueReadFirst(obj, ["primary_resource_current", "resource_current", "current_resource", "resourceCurrent"]);
  const directMax = zueReadFirst(obj, ["primary_resource_max", "resource_max", "max_resource", "resourceMax"]);
  const directCand = zueMakeResourceCandidate(directName, directCurrent, directMax, `${source}.direct_resource_keys`, identity);
  if (directCand) candidates.push(directCand);
  ["resources", "limited_resources", "counters", "resource_counters", "resource_ledger", "resourceLedger", "older_package_resource_ledger", "older_resource_ledger"].forEach((key) => {
    if (Array.isArray(obj[key])) candidates.push(...zueResourceCandidatesFromList(obj[key], `${source}.${key}`, identity));
    else if (obj[key] && typeof obj[key] === "object") {
      Object.entries(obj[key]).forEach(([name, value]) => {
        if (value && typeof value === "object") {
          candidates.push(...zueResourceCandidatesFromList([{ name, ...value }], `${source}.${key}.${name}`, identity));
        } else {
          const cand = zueMakeResourceCandidate(name, value, value, `${source}.${key}.${name}`, identity);
          if (cand) candidates.push(cand);
        }
      });
    }
  });
  return candidates;
}
function zueFindPrimaryResource(pkg = {}, model = {}) {
  const identity = model.identity || {};
  const candidates = [];
  const parsed = typeof zucParsed === "function" ? zucParsed(pkg) : parseJsonPackageBlocks(pkg?.blocks || []);
  const add = (items) => { items.filter(Boolean).forEach((x) => candidates.push(x)); };
  add(zueResourceCandidatesFromSurface({ primary_resource: model.core_stats?.primary_resource }, "view_model.core_stats", identity));
  add(zueResourceCandidatesFromSurface(model.equipment_resources_states || {}, "view_model.equipment_resources_states", identity));
  if (pkg.sheetData) add(zueResourceCandidatesFromSurface(pkg.sheetData, "pkg.sheetData", identity));
  parsed.forEach((block) => {
    const data = block?.data;
    const name = block?.name || "package_json_block";
    if (!data || typeof data !== "object") return;
    add(zueResourceCandidatesFromSurface(data, name, identity));
    if (/Limited_Resource|Resource_Counter|Resource_Ledger|Combat_State|Character_Import_Surface|Normalized_Sheet|Complete_Character_Record/i.test(name)) {
      add(zueResourceCandidatesFromList(zucList(data, ["resources", "limited_resources", "counters", "entries", "items", "rows"]), name, identity));
    }
  });
  const preferred = zueResourceNameFallback(identity).toLowerCase();
  const valid = candidates
    .filter((c) => c && zueValidResourceNumber(c.current) && zueValidResourceNumber(c.max))
    .filter((c) => !/^(?:hp|hit points|reaction|reactions|armor class|ac)$/i.test(String(c.name || "")));
  if (!valid.length) return null;
  valid.forEach((c) => { if (String(c.name || "").toLowerCase() === preferred) c.score += 6; });
  valid.sort((a, b) => b.score - a.score);
  return valid[0];
}
function zueRepairModelResource(model = {}, pkg = {}) {
  const found = zueFindPrimaryResource(pkg, model);
  model.diagnostics ||= [];
  if (found) {
    model.core_stats ||= {};
    model.core_stats.primary_resource = { name: found.name, current: found.current, max: found.max, source: found.source, formula: model.core_stats.primary_resource?.formula || "Resolved by HF05ZUE resource display normalizer" };
    model.equipment_resources_states ||= {};
    const resources = zucArray(model.equipment_resources_states.resources);
    if (!resources.some((r) => String(r?.name || r?.resource_name || "").toLowerCase() === String(found.name || "").toLowerCase() && zueResourceNumber(r?.current) === found.current && zueResourceNumber(r?.max ?? r?.maximum) === found.max)) {
      resources.unshift({ name: found.name, current: found.current, max: found.max, source: found.source, display_label: `${found.name} ${found.current}/${found.max}` });
      model.equipment_resources_states.resources = resources;
    }
    model.diagnostics = model.diagnostics.filter((d) => d.code !== "ZUE_PRIMARY_RESOURCE_MISSING");
    if (!model.diagnostics.some((d) => d.code === "ZUE_PRIMARY_RESOURCE_RESOLVED")) model.diagnostics.push({ severity: "info", code: "ZUE_PRIMARY_RESOURCE_RESOLVED", message: `${found.name} ${found.current}/${found.max}`, source: found.source, tab: "overview" });
  } else {
    model.core_stats ||= {};
    model.core_stats.primary_resource = { name: "Resource not found", current: null, max: null, source: "HF05ZUE searched accepted resource surfaces" };
    if (!model.diagnostics.some((d) => d.code === "ZUE_PRIMARY_RESOURCE_MISSING")) model.diagnostics.push({ severity: "warning", code: "ZUE_PRIMARY_RESOURCE_MISSING", message: "Primary resource current/max not found in accepted resource surfaces.", source: "HF05ZUE resource display normalizer", tab: "overview" });
  }
  return model;
}
function zuePrimaryResourceDisplay(model = {}) {
  const r = model.core_stats?.primary_resource || {};
  if (zueValidResourceNumber(r.current) && zueValidResourceNumber(r.max)) return { label: r.name || "Resource", value: `${r.current}/${r.max}`, text: `${r.name || "Resource"} ${r.current}/${r.max}`, found: true };
  return { label: "Resource", value: "Resource not found", text: "Resource not found", found: false };
}
function zueResourceChip(r = {}) {
  const name = zudSafeText(zucFirst(r.name, r.resource_name, r.display_name), "Resource");
  const current = zueResourceNumber(zucFirst(r.current, r.resourceCurrent, r.remaining, r.value));
  const max = zueResourceNumber(zucFirst(r.max, r.maximum, r.resourceMax, r.total, r.value));
  const value = current !== null || max !== null ? `${current ?? max}/${max ?? current}` : zudSafeText(zucFirst(r.display_label, r.summary, r.notes), "Resource not found");
  return `<article class="zud-chip-card"><strong>${escapeHtml(name)}</strong><span>${escapeHtml(value)}${r.source ? ` · ${escapeHtml(zudSafeText(r.source, ""))}` : ""}</span></article>`;
}
function zueTemporalText(c = {}) {
  const tf = c.temporal_feasibility || {};
  const source = String(tf.source || "");
  const hasMissing = zucArray(tf.missing_rows).length || /missing|no temporal/i.test(String(tf.round_segmentation || ""));
  const round = zudSafeText(tf.round_segmentation || c.temporal_feasibility_summary || c.timing_class, "No exact timing row recorded");
  if (/Temporal_Feasibility_Registry/i.test(source) && !hasMissing) return `Matched registry: ${round}`;
  return `Synthesized/fallback timing label: ${round}`;
}
function zueCompositeStatus(c = {}) {
  const diags = `${zucValueText(c.diagnostics || [], "")} ${zucValueText(c.temporal_feasibility || {}, "")}`;
  if (/UNRESOLVED|MISSING|ONLY_DECLARED/i.test(diags)) return "missing data";
  if (/FALLBACK|SYNTH|projection|No exact/i.test(diags) || c.fallback) return "fallback";
  return "ready";
}
function zueCompositeStatusLabel(c = {}) {
  const diagText = zucValueText(c.diagnostics || [], "");
  const temporalText = zucValueText(c.temporal_feasibility || {}, "");
  if (/UNRESOLVED_COMPONENT|UNRESOLVED COMPONENT|MISSING_COMPONENT|MISSING COMPONENT|COMPONENT_MISSING|ACTION_MISSING|ACTION MISSING/i.test(diagText)) return "missing data";
  if (c.fallback || /FALLBACK|SYNTH|projection|No exact|ONLY_DECLARED/i.test(`${diagText} ${temporalText}`)) return "fallback available";
  return "ready";
}
function zueCompositeRoleShort(c = {}) {
  const raw = zudSafeText(c.execution_role || c.category || c.playbook_role || c.role, "role unclear");
  return raw.replace(/[_\s]+/g, "/").replace(/\/{2,}/g, "/").toLowerCase();
}
function zueCompositeEconomyShort(c = {}) {
  const values = zucArray(c.economy_footprint || c.action_economy || c.economy).flatMap((x) => String(x || "").split(/[,+/;|]/));
  const cleaned = values.map((x) => x.trim().toLowerCase()).filter(Boolean);
  const order = ["action", "bonus action", "reaction", "movement", "passive", "free", "no action"];
  const unique = [];
  order.forEach((key) => { if (cleaned.some((x) => x === key || new RegExp(`\\b${key.replace(/ /g, "\\\\s+")}\\b`).test(x))) unique.push(key); });
  cleaned.forEach((x) => { if (!unique.includes(x)) unique.push(x); });
  const nonPassive = unique.filter((x) => !/passive|free|no action/.test(x));
  const final = (nonPassive.length ? nonPassive : unique).slice(0, 3);
  if (!final.length) return "Economy unclear";
  return final.map((x) => x.replace(/\w/g, (m) => m.toUpperCase())).join(" + ");
}
function zueCompositeResourceShort(c = {}) {
  const costs = [];
  zucArray(c.sequence).forEach((step) => {
    const text = String(step?.cost || step?.resource_cost || step?.resource_spent || "");
    const match = text.match(/(\d+)\s*(Qi|Stamina|Resonance|CP)/i);
    if (match) costs.push({ amount: Number(match[1]), name: match[2][0].toUpperCase() + match[2].slice(1).toLowerCase() });
    else if (/^0$|0/.test(text)) costs.push({ amount: 0, name: zueResourceNameFallback({ path: "Qi Cultivation" }) });
  });
  const paid = costs.filter((x) => x.amount > 0);
  const resourceName = (paid[0] || costs[0] || { name: "Qi" }).name;
  if (paid.length) {
    const nums = paid.map((x) => x.amount);
    const min = Math.min(...nums), max = Math.max(...nums);
    if (min === max) return `${resourceName} ${max}`;
    return `${resourceName} ${min}–${max}`;
  }
  const budget = zudSafeText(c.resource_budget, "");
  const budgetMatch = budget.match(/(Qi|Stamina|Resonance|CP)[^0-9]*(\d+)(?:\s*[–-]\s*(\d+))?/i) || budget.match(/(\d+)(?:\s*[–-]\s*(\d+))?\s*(Qi|Stamina|Resonance|CP)/i);
  if (budgetMatch) {
    if (/^\d/.test(budgetMatch[0])) {
      const a = budgetMatch[1], b = budgetMatch[2], name = budgetMatch[3];
      return `${name} ${a}${b ? "–" + b : ""}`;
    }
    const name = budgetMatch[1], a = budgetMatch[2], b = budgetMatch[3];
    return `${name} ${a}${b ? "–" + b : ""}`;
  }
  return "Qi 0";
}
function zueCompositeBrief(c = {}) {
  return `${zueCompositeRoleShort(c)} · ${zueCompositeEconomyShort(c)} · ${zueCompositeResourceShort(c)}`;
}
function zueCompositeListItem(c = {}, active = false, index = 0) {
  const status = zueCompositeStatusLabel(c);
  const statusClass = status.replace(/\s+/g, "-");
  const priority = c.priority ?? index + 1;
  return `<button class="zue-composite-list-item ${active ? "active" : ""}" type="button" data-composite-select="${index}" data-zuf-compact-composite-row="true">
    <span class="zue-composite-list-body"><strong>${escapeHtml(priority)}. ${zudCleanText(c.name, `Composite ${index + 1}`)}</strong><em><span>${escapeHtml(zueCompositeBrief(c))}</span><span class="zue-status ${statusClass}">${escapeHtml(status)}</span></em></span>
  </button>`;
}
function zueLinkedDetails(c = {}) {
  const linked = zucArray(c.linked_actions);
  const separate = linked.length ? `<details class="zue-linked-section"><summary>Linked action details (${linked.length})</summary><div class="zud-linked-stack">${linked.map(zudLinkedActionCard).join("")}</div></details>` : `<p class="zud-muted">No linked action details recorded.</p>`;
  return separate;
}
function zueCompositeDetail(c = {}, active = false, index = 0) {
  const sequence = zucArray(c.sequence);
  return `<article class="zue-composite-detail ${active ? "active" : ""}" data-composite-detail="${index}">
    <header class="zue-detail-header"><div><p class="zud-eyebrow">Priority ${escapeHtml(c.priority ?? index + 1)} · ${zudCleanText(c.execution_role || c.category, "role unclear")}</p><h4>${zudCleanText(c.name, `Composite ${index + 1}`)}</h4><p>${zudCleanText(c.when_to_use || c.purpose, "Use condition not recorded")}</p></div><div class="zud-badges">${zudBadge(c.category)}${zudBadge(c.composite_id)}</div></header>
    <section class="zue-quick-summary">
      ${zudDetailCard("Best timing", zudSafeText(c.best_timing || c.timing || c.temporal_feasibility?.round_segmentation, "Timing synthesized below"))}
      ${zudDetailCard("Opening condition", zudSafeText(c.opening_condition || c.when_to_use || c.preconditions, "Opening condition not recorded"))}
      ${zudDetailCard("Resource budget", c.resource_budget)}
      ${zudDetailCard("Action economy footprint", c.economy_footprint)}
      ${zudDetailCard("Fallback action", c.fallback)}
    </section>
    ${zudSection("Component sequence", `<div class="zud-step-stack zue-step-stack">${sequence.map(zudStepCard).join("") || `<p class="zud-muted">No component steps recorded.</p>`}</div>`, "zue-components")}
    ${zudSection("Linked action details", zueLinkedDetails(c), "zue-linked")}
    ${zudSection("Temporal feasibility", `<p class="zud-muted">${escapeHtml(zueTemporalText(c))}</p>`, "zue-temporal")}
    ${zudSection("Dao / I Ching hooks", `<div class="zud-kv-grid">${zudField("Dao behavior trigger", c.dao_hook)}${zudField("I Ching state / reading", c.i_ching_hook)}${zudField("Preferred when", c.when_to_use)}${zudField("Avoid when", c.do_not_use_when)}</div>`, "zue-hooks")}
    <details class="zue-diagnostics"><summary>Diagnostics</summary>${zudBulletList(c.diagnostics, "No composite diagnostics.")}</details>
  </article>`;
}
function zueSortComposites(composites = []) {
  return zucArray(composites).map((c, i) => ({ c, originalIndex: i })).sort((a, b) => (zucNum(a.c.priority, a.originalIndex + 1) - zucNum(b.c.priority, b.originalIndex + 1))).map((x) => x.c);
}
function zueRenderComposites(model) {
  const composites = zueSortComposites(model.composites || []);
  if (!composites.length) return `<p class="zud-muted">No composite playbooks recorded.</p>`;
  return `<div class="zud-tab-heading"><h3>Composite Playbooks</h3><p>Drill down from the fixed list at left. Only the selected composite opens in the detail pane.</p></div>
  <div class="zue-composite-drilldown" data-composite-drilldown="true">
    <aside class="zue-composite-list" aria-label="Composite playbook list">
      <div class="zue-list-title"><strong>Composite options</strong><span>${composites.length} playbooks</span></div>
      <div class="zue-list-scroll">${composites.map((c, i) => zueCompositeListItem(c, i === 0, i)).join("")}</div>
    </aside>
    <section class="zue-composite-detail-pane">${composites.map((c, i) => zueCompositeDetail(c, i === 0, i)).join("")}</section>
  </div>`;
}
function zueRenderOverview(model) {
  const cs = model.core_stats || {};
  const res = zuePrimaryResourceDisplay(model);
  const abilityCards = (cs.ability_scores || []).map((a) => `<article class="zud-ability-card"><strong>${escapeHtml(a.ability || "Ability")}</strong><b>${escapeHtml(a.score ?? "—")}</b><span>Mod ${escapeHtml(a.modifier === null ? "—" : formatSigned(a.modifier))}</span><span>Save ${escapeHtml(a.save === null ? "—" : formatSigned(a.save))}</span></article>`).join("");
  const skills = (cs.skills || []).map((s) => `<span>${escapeHtml(s.name || "Skill")} ${escapeHtml(s.bonus === null ? "—" : formatSigned(s.bonus))}${s.proficient ? " *" : ""}</span>`).join("");
  return `<div class="zud-tab-heading"><h3>Overview / Core Stats</h3><p>Stable combat math and quick-read defenses.</p></div>
    <div class="zud-core-grid">${zudDetailCard("Armor Class", `${cs.ac?.current ?? "—"}${cs.ac?.math?.length ? ` (${zucValueText(cs.ac.math)})` : ""}`)}${zudDetailCard("Hit Points", `${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}${zudDetailCard("Speed", cs.speed_ft !== null && cs.speed_ft !== undefined ? `${cs.speed_ft} ft` : "—")}${zudDetailCard("Attack Bonus", cs.attack_bonus === null ? "—" : formatSigned(cs.attack_bonus))}${zudDetailCard("Save DC", cs.save_dc ?? "—")}${zudDetailCard("Primary Resource", res.text)}</div>
    ${zudSection("Ability Scores / Saves", `<div class="zud-ability-grid">${abilityCards || `<p class="zud-muted">No ability scores recorded.</p>`}</div>`)}
    ${zudSection("Skills", `<div class="zud-skill-cloud">${skills || `<p class="zud-muted">No skill bonuses recorded.</p>`}</div>`)}
    <div class="zud-two-card-grid">${zudSection("Senses", zudBulletList(cs.senses))}${zudSection("Defenses", zudBulletList(cs.defenses, "None."))}</div>`;
}
function zueLeftRail(model, tabs) {
  const id = model.identity || {};
  const cs = model.core_stats || {};
  const res = zuePrimaryResourceDisplay(model);
  const stat = (label, value) => `<div class="zud-rail-stat"><strong>${escapeHtml(label)}</strong><span>${zudCleanText(value)}</span></div>`;
  return `<aside class="zud-left-rail"><section class="zud-rail-summary"><div class="zud-rail-portrait">${escapeHtml(characterInitials(id.display_name || id.name || "TX"))}</div><h4>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h4><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></section><section class="zud-rail-stats">${stat("HP", `${cs.hp?.current ?? "?"}/${cs.hp?.max ?? "?"}`)}${stat("AC", cs.ac?.current ?? "—")}${stat("Speed", cs.speed_ft !== null && cs.speed_ft !== undefined ? `${cs.speed_ft} ft` : "—")}${stat("Attack", cs.attack_bonus === null || cs.attack_bonus === undefined ? "—" : formatSigned(cs.attack_bonus))}${stat("Save DC", cs.save_dc ?? "—")}${stat(res.label, res.value)}</section><nav class="zud-tab-nav" aria-label="Character detail tabs">${tabs.map(([slug, label], i) => zudTabButton(slug, label, i === 0)).join("")}</nav></aside>`;
}
function zueRenderEquipmentResourcesStates(model) {
  const ers = model.equipment_resources_states || {};
  const eq = (ers.equipment || []).map((e) => `<article class="zud-chip-card"><strong>${zudCleanText(e.name, "Item")}</strong><span>${zudCleanText([e.type, e.equipped ? "equipped" : "", e.ac_contribution ? `AC ${e.ac_contribution}` : "", e.notes].filter(Boolean).join(" | "))}</span></article>`).join("");
  const res = (ers.resources || []).map((r) => zucIsObject(r) ? zueResourceChip(r) : `<article class="zud-chip-card"><strong>${zudCleanText(r, "Resource")}</strong></article>`).join("");
  const states = (ers.states || []).map((s) => `<article class="zud-action-card compact"><header><h5>${zudCleanText(s.name, "State")}</h5><div class="zud-badges">${zudBadge(s.duration)}${zudBadge(s.created_by)}</div></header><p class="zud-muted">${zudCleanText([s.effect, s.end_condition, s.source].filter(Boolean).join(" | "))}</p></article>`).join("");
  return `<div class="zud-tab-heading"><h3>Equipment / Resources / States</h3></div>${zudSection("Equipment", `<div class="zud-chip-grid">${eq || `<p class="zud-muted">No equipment recorded.</p>`}</div>`)}${zudSection("Resources", `<div class="zud-chip-grid">${res || `<p class="zud-muted">No resources recorded.</p>`}</div>`)}${zudSection("States", `<div class="zud-card-stack">${states || `<p class="zud-muted">No states recorded.</p>`}</div>`)}`;
}
function zueDiagnosticsSummary(model) {
  const base = zudDiagnosticsSummary(model);
  const resource = zuePrimaryResourceDisplay(model);
  const compHazards = (model.composites || []).flatMap((c) => zucArray(c.diagnostics || []).filter((d) => /UNRESOLVED|COMPONENT.*MISSING/i.test(d))).map((d) => String(d));
  return { ...base, resource, compHazards };
}
function zueRenderDiagnostics(model) {
  const s = zueDiagnosticsSummary(model);
  return `<div class="zud-tab-heading"><h3>Diagnostics</h3><p>Gameplay tabs stay clean; renderer, resource, and composite diagnostics live here.</p></div><div class="zud-core-grid">${zudDetailCard("Renderer Mode", `${ZUE_PATCH_ID} over ${ZUD_PATCH_ID} / ${ZUC_VIEW_SCHEMA}`)}${zudDetailCard("v2 Model Loaded", model.schema === ZUC_VIEW_SCHEMA || model.schema_version === ZUC_VIEW_SCHEMA ? "Yes" : "No")}${zudDetailCard("Primary Resource", s.resource.found ? `${s.resource.text} — no resource render hazard` : "Resource not found")}${zudDetailCard("Fallback Adapters Used", s.synth.length ? `${s.synth.length} synthesized/fallback diagnostics` : "None flagged")}${zudDetailCard("Render Hazards", s.hazards.length ? `${s.hazards.length} diagnostics` : "None flagged")}${zudDetailCard("Composite Component Hazards", s.compHazards.length ? `${s.compHazards.length} unresolved hazards` : "None flagged")}</div>${zudSection("Missing / Unresolved", zudBulletList(s.missing, "None flagged."))}${zudSection("Fallback / Synthesized", zudBulletList(s.synth, "None flagged."))}${zudSection("Render Hazards", zudBulletList(s.hazards, "None flagged."))}${zudSection("Composite Component Hazards", zudBulletList(s.compHazards, "None flagged."))}${zudSection("All Model Diagnostics", zudBulletList((model.diagnostics || []).map((d) => `${String(d.severity || "").toUpperCase()} ${d.code}: ${d.message} [${d.source || "no source"}]`), "No model diagnostics."))}`;
}
function zueRenderVisualCharacterSheet(pkg, notes = {}) {
  const model = zueRepairModelResource(zucBuildViewModelV2(pkg), pkg);
  const id = model.identity || {};
  const tabs = [
    ["overview-core-stats", "Overview / Core Stats", zueRenderOverview],
    ["leveling-ledger", "Leveling Ledger", zudRenderLeveling],
    ["background-origin", "Background & Origin", zudRenderBackground],
    ["spheres-talents", "Spheres & Talents", zudRenderSpheresTalents],
    ["actions", "Actions", zudRenderActions],
    ["composite-playbooks", "Composite Playbooks", zueRenderComposites],
    ["martial-manuals-recorded-arts", "Martial Manuals / Recorded Arts", zudRenderManuals],
    ["foundation", "Foundation", zudRenderFoundation],
    ["method", "Method", zudRenderMethod],
    ["dao-i-ching", "Dao & I Ching", zudRenderDaoIChing],
    ["equipment-resources-states", "Equipment / Resources / States", zueRenderEquipmentResourcesStates],
    ["diagnostics", "Diagnostics", zuiR2RenderDiagnostics]
  ];
  return `<article class="sheet-card zud-v2-sheet zue-v2-sheet" data-view-model-schema="${ZUC_VIEW_SCHEMA}" data-renderer-patch="${ZUE_PATCH_ID}" data-preserves-layout="HF05ZUD-R1A">
    <header class="zud-sheet-header"><div><p class="zud-eyebrow">Tianxia GM Screen · Stable Character View</p><h3>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h3><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></div><div class="zud-header-tags"><span>${escapeHtml(ZUE_PATCH_ID)}</span><span>${escapeHtml(ZUD_PATCH_ID)}</span><span>${escapeHtml(ZUC_VIEW_SCHEMA)}</span><span>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</span></div></header>
    <div class="zud-character-shell">${zueLeftRail(model, tabs)}<main class="zud-main-panel">${tabs.map(([slug, , renderer], i) => zudTabPanel(slug, renderer(model), i === 0)).join("")}</main></div>
  </article>`;
}
const zueRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zue(pkg, notes = {}) {
  try { return zueRenderVisualCharacterSheet(pkg, notes); }
  catch (error) {
    const fallback = zueRenderVisualCharacterSheetBefore(pkg, notes);
    return `${fallback}<section class="sheet-section"><h4>HF05ZUE Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`;
  }
};

/* ============================================================================
 * HF05ZUH-R1A — Character Surface Visibility Normalization Patch
 * Scope: renderer/model-edge visibility only. Preserves HF05ZUC v2 model,
 * HF05ZUD stable layout, HF05ZUE resource fix, and HF05ZUF composite list polish.
 * Purpose: show data already present in imported character ZIPs instead of
 * rendering aliases as — / Not recorded / [object Object].
 * ========================================================================== */
const ZUH_PATCH_ID = "HF05ZUH-R1A";
function zuhParsedBlocks(pkg = {}) {
  try { return typeof zucParsed === "function" ? zucParsed(pkg) : parseJsonPackageBlocks(pkg?.blocks || []); }
  catch (_) { return []; }
}
function zuhFindJson(parsed = [], patterns = []) {
  try { return zucFindJson(parsed, patterns) || {}; }
  catch (_) { return {}; }
}
function zuhNum(value, fallback = null) {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const text = String(value).trim().replace(/^\+/, "");
  if (/^-?\d+(?:\.\d+)?$/.test(text)) return Number(text);
  return fallback;
}
function zuhPresent(value) {
  return value !== undefined && value !== null && value !== "" && String(value) !== "[object Object]";
}
function zuhObjectToText(obj = {}) {
  if (!zucIsObject(obj)) return zudSafeText(obj, "");
  const name = zudSafeText(zucFirst(obj.name, obj.display_name, obj.title, obj.action_name, obj.technique, obj.manual, obj.id, obj.action_id, obj.composite_id), "");
  const effect = zudSafeText(zucFirst(obj.effect, obj.summary, obj.description, obj.benefit, obj.numeric, obj.generation, obj.reading, obj.choose, obj.if), "");
  const extra = zudSafeText(zucFirst(obj.numeric, obj.limit, obj.cost, obj.timing, obj.range, obj.target, obj.value), "");
  if (name && effect && extra && extra !== effect) return `${name} — ${effect} (${extra})`;
  if (name && effect) return `${name} — ${effect}`;
  if (name && extra) return `${name} — ${extra}`;
  if (name) return name;
  const parts = Object.entries(obj)
    .filter(([k, v]) => !/^schema$|^status$|^character_id$/i.test(k) && zuhPresent(v))
    .slice(0, 8)
    .map(([k, v]) => `${zucDisplay(k)}: ${zuhValueText(v)}`);
  return parts.join("; ");
}
function zuhValueText(value, fallback = "Not recorded") {
  if (value === undefined || value === null || value === "") return fallback;
  if (Array.isArray(value)) {
    const text = value.map((v) => zuhValueText(v, "")).filter(Boolean).join("; ");
    return text || fallback;
  }
  if (zucIsObject(value)) return zuhObjectToText(value) || fallback;
  const text = zudSafeText(value, "");
  return text || fallback;
}
function zuhArrayText(value) {
  if (value === undefined || value === null || value === "") return [];
  const arr = Array.isArray(value) ? value : [value];
  return arr.map((x) => zuhValueText(x, "")).filter(Boolean);
}
function zuhAbilityAliases(ab) {
  const key = String(ab || "").toUpperCase();
  const map = {
    STR: ["STR", "str", "Strength", "strength", "STRENGTH"],
    DEX: ["DEX", "dex", "Dexterity", "dexterity", "DEXTERITY"],
    CON: ["CON", "con", "Constitution", "constitution", "CONSTITUTION"],
    INT: ["INT", "int", "Intelligence", "intelligence", "INTELLIGENCE"],
    WIS: ["WIS", "wis", "Wisdom", "wisdom", "WISDOM"],
    CHA: ["CHA", "cha", "Charisma", "charisma", "CHARISMA"]
  };
  return map[key] || [ab];
}
function zuhReadByAbility(record = {}, ab) {
  if (!zucIsObject(record)) return undefined;
  for (const key of zuhAbilityAliases(ab)) {
    if (record[key] !== undefined) return record[key];
  }
  return undefined;
}
function zuhScoreFrom(value) {
  if (zucIsObject(value)) return zuhNum(zucFirst(value.score, value.final, value.value, value.total, value.base), null);
  return zuhNum(value, null);
}
function zuhModFrom(value) {
  if (zucIsObject(value)) return zuhNum(zucFirst(value.modifier, value.mod, value.bonus, value.value, value.total), null);
  return zuhNum(value, null);
}
function zuhSaveFrom(value) {
  if (zucIsObject(value)) return zuhNum(zucFirst(value.save, value.bonus, value.modifier, value.mod, value.value, value.total), null);
  return zuhNum(value, null);
}
function zuhSavingThrowLookup(record = {}, ab) {
  if (Array.isArray(record)) {
    const row = record.find((x) => zucIsObject(x) && zuhAbilityAliases(ab).some((alias) => String(zucFirst(x.ability, x.name, x.save, x.key, "")).toLowerCase() === String(alias).toLowerCase()));
    return row ? zuhSaveFrom(row) : null;
  }
  return zuhSaveFrom(zuhReadByAbility(record, ab));
}
function zuhCollectAbilitySources(parsed = [], pkg = {}, model = {}) {
  const blocks = [
    model.core_stats || {},
    pkg.sheetData || {},
    zuhFindJson(parsed, [/Canonical_Stats_Resource_Block/i]),
    zuhFindJson(parsed, [/Character_Import_Surface/i]),
    zuhFindJson(parsed, [/Normalized_Sheet/i]),
    zuhFindJson(parsed, [/Tianxia_GM_Character_Model_v1/i]),
    zuhFindJson(parsed, [/Tianxia_GM_Character_View_Model_v2/i])
  ].filter(zucIsObject);
  const sources = [];
  blocks.forEach((b) => {
    [b, b.stats, b.combat_stats, b.normalized, b.summary].filter(zucIsObject).forEach((s) => {
      sources.push({ scores: s.ability_scores || s.abilityScores || s.abilities || s.scores, mods: s.ability_modifiers || s.abilityModifiers || s.mods || s.modifiers, saves: s.saving_throw_bonuses || s.saving_throws || s.saves || s.save_bonuses });
    });
  });
  return sources;
}
function zuhRepairAbilities(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const sources = zuhCollectAbilitySources(parsed, pkg, model);
  const existing = {};
  zucArray(model.core_stats?.ability_scores).forEach((row) => {
    const ab = String(row?.ability || "").toUpperCase();
    if (ab) existing[ab] = { ...row };
  });
  const rows = ["STR", "DEX", "CON", "INT", "WIS", "CHA"].map((ab) => {
    const row = existing[ab] || { ability: ab, score: null, modifier: null, save: null };
    for (const s of sources) {
      const scoreValue = zuhReadByAbility(s.scores, ab);
      const modValue = zuhReadByAbility(s.mods, ab);
      const saveValue = s.saves;
      const score = zuhScoreFrom(scoreValue);
      const mod = zuhModFrom(modValue !== undefined ? modValue : scoreValue);
      const save = zuhSavingThrowLookup(saveValue, ab);
      if (row.score === null || row.score === undefined || row.score === "—") if (score !== null) row.score = score;
      if (row.modifier === null || row.modifier === undefined || row.modifier === "—") {
        if (mod !== null) row.modifier = mod;
        else if (zuhNum(row.score, null) !== null) row.modifier = Math.floor((Number(row.score) - 10) / 2);
      }
      if (row.save === null || row.save === undefined || row.save === "—") {
        if (save !== null) row.save = save;
        else if (row.modifier !== null && row.modifier !== undefined) row.save = row.modifier;
      }
    }
    return row;
  });
  model.core_stats ||= {};
  model.core_stats.ability_scores = rows;
  if (rows.every((r) => r.score !== null && r.score !== undefined)) {
    model.diagnostics ||= [];
    model.diagnostics.push({ severity: "info", code: "ZUH_ABILITY_SCORES_VISIBLE", message: "Ability scores normalized from full-name or short-key package surfaces.", source: "HF05ZUH ability adapter", tab: "overview" });
  }
  return model;
}
function zuhFoundationSource(parsed = [], model = {}) {
  const detail = zuhFindJson(parsed, [/Foundation_Detail_Ledger/i]);
  const surface = zuhFindJson(parsed, [/Character_Import_Surface/i]);
  const normalized = zuhFindJson(parsed, [/Normalized_Sheet/i]);
  const display = zuhFindJson(parsed, [/Foundation_Display_Row/i]);
  return [detail, surface.foundation, normalized.foundation, display.foundation, display.row, model.foundation].find(zucIsObject) || {};
}
function zuhRepairFoundation(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const src = zuhFoundationSource(parsed, model);
  if (!Object.keys(src || {}).length) return model;
  const fr = src.foundation_resource || src.resource || src.resources;
  const benefits = [
    ...zuhArrayText(src.prominent_benefits),
    ...zuhArrayText(src.benefits),
    ...zuhArrayText(src.mechanical_benefits),
    ...zuhArrayText(src.passive_benefits),
    ...zuhArrayText(src.benefits_permissions)
  ];
  const actions = [
    ...zuhArrayText(src.active_reaction_benefits),
    ...zuhArrayText(src.actions),
    ...zuhArrayText(src.riders),
    ...zuhArrayText(src.triggers)
  ];
  const resourceText = zuhArrayText(fr).concat(fr && zucIsObject(fr) ? [`${zuhValueText(zucFirst(fr.name, fr.resource_name), "Resource")} ${zuhValueText(zucFirst(fr.start, fr.current), "0")}/${zuhValueText(zucFirst(fr.max, fr.maximum), "?")} — ${zuhValueText(zucFirst(fr.generation, fr.recovery, fr.rules), "generation not recorded")}`] : []);
  model.foundation = {
    name: zudSafeText(zucFirst(src.chosen_foundation, src.foundation_name, src.name, src.display_name, model.foundation?.name), "Foundation not recorded"),
    grade: zudSafeText(zucFirst(src.grade_status, src.grade, src.foundation_grade, src.depth, model.foundation?.grade), ""),
    status_stage: zudSafeText(zucFirst(src.stage, src.status_stage, src.status, src.foundation_stage, model.foundation?.status_stage), ""),
    fixed_scope: zuhArrayText(zucFirst(src.fixed_scope, src.source_trait_match, src.why_closest_existing_foundation, model.foundation?.fixed_scope)),
    passive_chassis: benefits.length ? benefits : zuhArrayText(model.foundation?.passive_chassis),
    benefits: benefits.length ? benefits : zuhArrayText(model.foundation?.benefits),
    resources_counters: resourceText.length ? resourceText : zuhArrayText(model.foundation?.resources_counters),
    actions_riders: actions.length ? actions : zuhArrayText(model.foundation?.actions_riders),
    burdens_strains_deviations: zuhArrayText(zucFirst(src.burden_strain, src.burdens, src.strains, src.deviations, src.known_mismatch_or_gap, src.excluded_stage_features, model.foundation?.burdens_strains_deviations)),
    ai_notes: zuhArrayText(zucFirst(src.ai_notes, src.ai_piloting_notes, src.display_surfaces_required_later, model.foundation?.ai_notes)),
    source: "Foundation_Detail_Ledger / Character_Import_Surface.foundation"
  };
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_FOUNDATION_OBJECT_RENDERED", message: `${model.foundation.name} benefits surfaced from nested Foundation object.`, source: model.foundation.source, tab: "foundation" });
  return model;
}
function zuhRepairDaoIChing(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const src = zuhFindJson(parsed, [/Dao_IChing_Combat_Profile/i, /Dao_Combat_Behavior_Profile/i, /Dao_Profile/i]);
  if (!Object.keys(src || {}).length) return model;
  const i = zucFirst(src.i_ching, src.i_ching_combat_layer, src.iChing, {});
  model.dao_i_ching = {
    dao: {
      dao_phrase: zudSafeText(zucFirst(src.dao_phrase, src.dao_name, model.dao_i_ching?.dao?.dao_phrase), ""),
      combat_doctrine: zudSafeText(zucFirst(src.combat_doctrine, src.dao_thesis, src.default_behavior, model.dao_i_ching?.dao?.combat_doctrine), ""),
      resource_policy: zudSafeText(zucFirst(src.resource_policy, src.resource_temperament, model.dao_i_ching?.dao?.resource_policy), ""),
      reaction_policy: zudSafeText(zucFirst(src.reaction_policy, model.dao_i_ching?.dao?.reaction_policy), ""),
      ai_turn_prompt: zudSafeText(zucFirst(src.ai_turn_prompt, src.preferred_victory, model.dao_i_ching?.dao?.ai_turn_prompt), ""),
      preferred_engagements: zuhArrayText(zucFirst(src.preferred_engagements, src.preferred_victory, src.composite_selection_logic, model.dao_i_ching?.dao?.preferred_engagements)),
      avoidance_rules: zuhArrayText(zucFirst(src.avoidance_rules, model.dao_i_ching?.dao?.avoidance_rules)),
      risk_thresholds: zuhArrayText(zucFirst(src.risk_thresholds, src.risk_policy, model.dao_i_ching?.dao?.risk_thresholds)),
      target_selection_logic: zuhArrayText(zucFirst(src.target_selection_logic, model.dao_i_ching?.dao?.target_selection_logic)),
      failure_recovery: zuhArrayText(zucFirst(src.failure_recovery, src.failure_recovery_policy, model.dao_i_ching?.dao?.failure_recovery)),
      forbidden_behaviors: zuhArrayText(zucFirst(src.forbidden_behaviors, model.dao_i_ching?.dao?.forbidden_behaviors)),
      composite_hooks: zuhArrayText(zucFirst(src.composite_selection_logic, src.composite_hooks, model.dao_i_ching?.dao?.composite_hooks))
    },
    i_ching: {
      enabled: Object.keys(i || {}).length > 0,
      reading_name: zudSafeText(zucFirst(i.opening_read, i.reading_name, i.name, model.dao_i_ching?.i_ching?.reading_name), ""),
      hexagram_or_trigram: zudSafeText(zucFirst(i.default_trigram_pair, i.hexagram_or_trigram, i.hexagram, i.trigram, model.dao_i_ching?.i_ching?.hexagram_or_trigram), ""),
      natural_tendency: zudSafeText(zucFirst(i.natural_tendency, i.opening_read, model.dao_i_ching?.i_ching?.natural_tendency), ""),
      testing_tendency: zudSafeText(zucFirst(i.testing_tendency, i.defensive_shift, i.pursuit_shift, model.dao_i_ching?.i_ching?.testing_tendency), ""),
      shift_triggers: zuhArrayText(zucFirst(i.shift_triggers, [i.defensive_shift, i.pursuit_shift].filter(Boolean), model.dao_i_ching?.i_ching?.shift_triggers)),
      low_resource_shift: zudSafeText(zucFirst(i.low_resource_shift, model.dao_i_ching?.i_ching?.low_resource_shift), ""),
      combat_state_interpretation: zudSafeText(zucFirst(i.combat_state_interpretation, i.opening_read, model.dao_i_ching?.i_ching?.combat_state_interpretation), ""),
      gm_generation_instruction: zudSafeText(zucFirst(i.gm_generation_instruction, i.defensive_shift, model.dao_i_ching?.i_ching?.gm_generation_instruction), ""),
      composite_hooks: zuhArrayText(zucFirst(i.composite_hooks, model.dao_i_ching?.i_ching?.composite_hooks))
    }
  };
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_DAO_ICHING_VISIBLE", message: "Dao/I Ching combat profile surfaced from Dao_IChing_Combat_Profile.json.", source: "Dao_IChing_Combat_Profile.json", tab: "dao-i-ching" });
  return model;
}
function zuhRepairLeveling(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const ledger = zuhFindJson(parsed, [/Leveling_Ledger$/i, /Leveling_Ledger\.json/i]);
  const alias = zuhFindJson(parsed, [/Leveling_Ledger_Display_Alias/i]);
  const src = Object.keys(ledger || {}).length ? ledger : (alias.leveling_ledger || alias);
  const rows = zucArray(zucFirst(src.level_rows, src.rows, src.levels, alias.leveling_ledger?.level_rows));
  if (!rows.length) return model;
  const inferRealm = (cl) => cl < 5 ? "Mortal" : cl < 10 ? "Foundation Establishment" : "Core Formation";
  model.leveling_ledger = rows.map((r, i) => {
    const gain = r.gain && zucIsObject(r.gain) ? r.gain : r;
    const cl = zucNum(zucFirst(gain.cl, gain.CL, gain.level), i + 1);
    const used = zucNum(gain.trained_choices_used, null);
    const limit = zucNum(gain.trained_choice_limit, 3);
    return {
      CL: cl,
      realm: zudSafeText(zucFirst(gain.realm, r.realm, src.realm), inferRealm(cl)),
      PB: zucNum(zucFirst(gain.pb, gain.PB, gain.proficiency_bonus), cl <= 4 ? 2 : cl <= 8 ? 3 : cl <= 12 ? 4 : 5),
      hp_gain: zudSafeText(zucFirst(gain.hp_gain, gain.hp, gain.hp_change), "not itemized"),
      resource_max_after_level: zudSafeText(zucFirst(gain.resource_max_after_level, gain.resource_max, gain.resource), "not itemized"),
      free_level_talent: zudSafeText(zucFirst(gain.free_level_talent, gain.level_talent, gain.talent), ""),
      new_spheres_gained: zuhArrayText(zucFirst(gain.new_spheres_gained, gain.new_spheres, gain.spheres)),
      new_sphere_bonus_talents: zuhArrayText(zucFirst(gain.new_sphere_bonus_talents, gain.bonus_talents, gain.free_talents)),
      trained_choices: zuhArrayText(zucFirst(gain.trained_choices, gain.trained, gain.choices)),
      trained_choices_used: used,
      trained_choice_limit: limit,
      trained_choices_text: used !== null ? `${used}/${limit} trained choices used` : "not itemized",
      background_grants: cl === 1 ? zuhArrayText(zucFirst(gain.background_grants, gain.background, model.background_origin?.background?.name)) : zuhArrayText(zucFirst(gain.background_grants, gain.background)),
      origin_insight: cl === 1 ? zudSafeText(zucFirst(gain.origin_insight, gain.origin, model.background_origin?.origin_insight?.name), "") : zudSafeText(zucFirst(gain.origin_insight, gain.origin), ""),
      method_event: zudSafeText(zucFirst(gain.method_event, gain.method), ""),
      foundation_event: zudSafeText(zucFirst(gain.foundation_event, gain.foundation), ""),
      advancement_choice: zudSafeText(zucFirst(gain.asi_or_insight_choice, gain.advancement_choice), "") || zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)).join("; "),
      advancement_choices: zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)),
      manuals_or_recorded_arts: zuhArrayText(zucFirst(gain.manuals_or_recorded_arts, gain.manuals, gain.recorded_arts)),
      forged_techniques: zuhArrayText(zucFirst(gain.forged_techniques, gain.forged)),
      validation_notes: zuhArrayText(zucFirst(gain.validation_notes, gain.notes, gain.diagnostics, gain.legal === true ? "legal" : ""))
    };
  });
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_LEVELING_LEDGER_VISIBLE", message: `${model.leveling_ledger.length} CL rows surfaced from Leveling_Ledger.level_rows.`, source: "Leveling_Ledger.json", tab: "leveling-ledger" });
  return model;
}
function zuhRepairManuals(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const file = zuhFindJson(parsed, [/Martial_Arts_and_Manuals/i]);
  const rows = zucArray(zucFirst(file.recorded_arts, file.manuals, file.martial_arts, file.entries, file.items));
  if (!rows.length) return model;
  model.martial_manuals = rows.map((r, i) => ({
    manual_name: zudSafeText(zucFirst(r.manual, r.manual_name, r.name, r.id), `Manual ${i+1}`),
    technique_name: zudSafeText(zucFirst(r.technique, r.technique_name, r.form_name, r.name), `Technique ${i+1}`),
    source_spheres: zuiR2ArrayValue(r.source_spheres, r.spheres),
    reproduced_ability: zudSafeText(zucFirst(r.reproduced_package, r.reproduced_ability, r.source_package), ""),
    DC: zudSafeText(zucFirst(r.dc, r.DC, r.training_dc, r.practice_dc), ""),
    realm_gate: zudSafeText(zucFirst(r.realm, r.realm_gate), ""),
    timing_economy: zudSafeText(zucFirst(r.timing, r.timing_economy, r.activation, r.action_type), ""),
    cost: zudSafeText(zucFirst(r.cost, r.resource_cost), ""),
    range: zudSafeText(zucFirst(r.range), ""),
    target: zudSafeText(zucFirst(r.target), ""),
    roll_save_check: zudSafeText(zucFirst(r.roll_save_check, r.roll_save, r.roll_or_save, r.attack_or_save, r.check), ""),
    effect: zudSafeText(zucFirst(r.effect, r.success_effect, r.description), ""),
    failure_miss: zudSafeText(zucFirst(r.failure, r.failure_miss, r.miss, r.failure_or_limit), ""),
    duration: zudSafeText(zucFirst(r.duration), ""),
    limit: zudSafeText(zucFirst(r.limit, r.limits, r.restrictions), ""),
    counterplay: zudSafeText(zucFirst(r.counterplay), ""),
    linked_action_refs: zuhArrayText(zucFirst(r.linked_action, r.linked_action_ids, r.actions)),
    policy_notes: zudSafeText(zucFirst(r.policy_note, r.policy_notes, file.manual_legality_note), ""),
    source: "Martial_Arts_and_Manuals.recorded_arts"
  }));
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_RECORDED_ARTS_VISIBLE", message: `${model.martial_manuals.length} Recorded Art cards surfaced from Martial_Arts_and_Manuals.recorded_arts.`, source: "Martial_Arts_and_Manuals.json", tab: "martial-manuals-recorded-arts" });
  return model;
}
function zuhRepairModelVisibility(model = {}, pkg = {}) {
  model = zueRepairModelResource(model, pkg);
  model = zuhRepairAbilities(model, pkg);
  model = zuhRepairFoundation(model, pkg);
  model = zuhRepairDaoIChing(model, pkg);
  model = zuhRepairLeveling(model, pkg);
  model = zuhRepairManuals(model, pkg);
  model.patch = ZUH_PATCH_ID;
  model.renderer_patch = ZUH_PATCH_ID;
  return model;
}
function zuhRenderLeveling(model) {
  const levels = model.leveling_ledger || [];
  const byRealm = {};
  levels.forEach((r) => { const key = r.realm || "Realm not recorded"; (byRealm[key] ||= []).push(r); });
  const realmCards = Object.entries(byRealm).map(([realm, rows]) => `<section class="zud-realm-card"><h4>${escapeHtml(realm)}</h4><div class="zud-level-grid">${rows.map((r) => `<article class="zud-level-card"><header><strong>CL ${escapeHtml(r.CL ?? "?")}</strong><span>PB ${escapeHtml(r.PB ?? "?")}</span></header><div class="zud-level-fields">${zudField("HP / Resource", [r.hp_gain, r.resource_max_after_level].filter(Boolean).join(" / "))}${zudField("Free level talent", r.free_level_talent)}${zudField("New sphere + bonus", [...(r.new_spheres_gained||[]), ...(r.new_sphere_bonus_talents||[])])}${zudField("Trained choices", r.trained_choices_text || `${(r.trained_choices||[]).length}/3 ${zucValueText(r.trained_choices, "")}`)}${zudField("Background / Origin", [...(r.background_grants||[]), r.origin_insight].filter(Boolean))}${zudField("Method / Foundation", [r.method_event, r.foundation_event].filter(Boolean))}${zudField("Manuals / Recorded Arts", r.manuals_or_recorded_arts)}${zudField("Forged", r.forged_techniques)}${zudField("Validation", r.validation_notes)}</div></article>`).join("")}</div></section>`).join("");
  return `<div class="zud-tab-heading"><h3>Leveling Ledger</h3><p>CL-by-CL rows are surfaced from package ledgers, including level talents and trained-choice counts.</p></div>${realmCards || `<p class="zud-muted">No leveling ledger recorded.</p>`}`;
}
function zuhRenderVisualCharacterSheet(pkg, notes = {}) {
  const model = zuhRepairModelVisibility(zucBuildViewModelV2(pkg), pkg);
  const id = model.identity || {};
  const tabs = [
    ["overview-core-stats", "Overview / Core Stats", zueRenderOverview],
    ["leveling-ledger", "Leveling Ledger", zuiR2RenderLeveling],
    ["background-origin", "Background & Origin", zudRenderBackground],
    ["spheres-talents", "Spheres & Talents", zudRenderSpheresTalents],
    ["actions", "Actions", zudRenderActions],
    ["composite-playbooks", "Composite Playbooks", zueRenderComposites],
    ["martial-manuals-recorded-arts", "Martial Manuals / Recorded Arts", zudRenderManuals],
    ["foundation", "Foundation", zudRenderFoundation],
    ["method", "Method", zudRenderMethod],
    ["dao-i-ching", "Dao & I Ching", zudRenderDaoIChing],
    ["equipment-resources-states", "Equipment / Resources / States", zueRenderEquipmentResourcesStates],
    ["diagnostics", "Diagnostics", zuiR2RenderDiagnostics]
  ];
  return `<article class="sheet-card zud-v2-sheet zue-v2-sheet zuh-v2-sheet" data-view-model-schema="${ZUC_VIEW_SCHEMA}" data-renderer-patch="${ZUH_PATCH_ID}" data-preserves-layout="HF05ZUD-R1A"><header class="zud-sheet-header"><div><p class="zud-eyebrow">Tianxia GM Screen · Character Surface Visibility</p><h3>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h3><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></div><div class="zud-header-tags"><span>${escapeHtml(ZUH_PATCH_ID)}</span><span>${escapeHtml(ZUE_PATCH_ID)}</span><span>${escapeHtml(ZUC_VIEW_SCHEMA)}</span><span>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</span></div></header><div class="zud-character-shell">${zueLeftRail(model, tabs)}<main class="zud-main-panel">${tabs.map(([slug, , renderer], i) => zudTabPanel(slug, renderer(model), i === 0)).join("")}</main></div></article>`;
}
const zuhRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zuh(pkg, notes = {}) {
  try { return zuhRenderVisualCharacterSheet(pkg, notes); }
  catch (error) {
    const fallback = zuhRenderVisualCharacterSheetBefore(pkg, notes);
    return `${fallback}<section class="sheet-section"><h4>HF05ZUH Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`;
  }
};

/* HF05ZUH-R1A supplemental adapters: action/composite/background package-shape visibility. */
function zuhActionFromSurface(a = {}, index = 0, source = "Complete_Action_Surface") {
  const card = zucIsObject(a.display_card) ? a.display_card : {};
  const id = zudSafeText(zucFirst(a.action_id, a.id, card.action_id, `ACT_${index + 1}`), `ACT_${index + 1}`);
  const name = zudSafeText(zucFirst(a.display_name, a.name, a.action_name, card.action_name, id), id);
  const effect = zudSafeText(zucFirst(a.effect, a.effect_summary, a.success_effect, a.damage_or_effect, card.success_effect, card.effect, a.description), "");
  return {
    action_id: id,
    name,
    display_name: name,
    row_type: zudSafeText(zucFirst(a.row_type, a.type, a.classification, "action"), "action"),
    economy: zudSafeText(zucFirst(a.economy, a.action_type, card.economy), ""),
    timing: zudSafeText(zucFirst(a.timing, a.timing_window, card.timing), ""),
    cost: zudSafeText(zucFirst(a.cost, a.resource_cost, card.cost), ""),
    range: zudSafeText(zucFirst(a.range, card.range), ""),
    target: zudSafeText(zucFirst(a.target, card.target), ""),
    roll_or_save: zudSafeText(zucFirst(a.roll_or_save, a.roll_save_check, a.attack_or_save, card.roll_save_check), ""),
    effect,
    success_effect: effect,
    failure_or_limit: zudSafeText(zucFirst(a.failure_or_limit, a.failure_limit, a.failure, card.failure_limit), ""),
    duration: zudSafeText(zucFirst(a.duration, card.duration), ""),
    limit: zudSafeText(zucFirst(a.limit, a.limits, card.limit), ""),
    counterplay: zudSafeText(zucFirst(a.counterplay, card.counterplay), ""),
    source_spheres: zuhArrayText(zucFirst(a.source_spheres, a.spheres, a.tags)),
    source_talents: zuhArrayText(zucFirst(a.source_talents, a.source_talent_names)),
    linked_actions: zuhArrayText(zucFirst(a.linked_actions, a.linked_action_ids)),
    source,
    raw: a
  };
}
function zuhRepairActions(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const complete = zuhFindJson(parsed, [/Complete_Action_Surface/i]);
  const surface = zuhFindJson(parsed, [/Character_Import_Surface/i]);
  const rows = [
    ...zucArray(complete.actions),
    ...zucArray(complete.rows),
    ...zucArray(surface.actions),
    ...zucArray(surface.gm_screen_action_rows)
  ];
  if (!rows.length) return model;
  const byId = new Map();
  rows.map((a, i) => zuhActionFromSurface(a, i, "Complete_Action_Surface / Character_Import_Surface")).forEach((a) => {
    if (!a.name || !a.effect) return;
    const key = zucKey(a.action_id || a.name);
    if (!byId.has(key) || zuhValueText(a).length > zuhValueText(byId.get(key)).length) byId.set(key, a);
  });
  if (byId.size) {
    model.actions = Array.from(byId.values());
    model.diagnostics ||= [];
    model.diagnostics.push({ severity: "info", code: "ZUH_ACTIONS_VISIBLE", message: `${model.actions.length} action cards surfaced from Complete_Action_Surface.actions.`, source: "Complete_Action_Surface.json", tab: "actions" });
  }
  return model;
}
function zuhRepairBackgroundOrigin(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const ledger = zuhFindJson(parsed, [/Background_Origin_Ledger/i]);
  const originLedger = zuhFindJson(parsed, [/Origin_Insight_Ledger/i]);
  const surface = zuhFindJson(parsed, [/Character_Import_Surface/i]);
  const b = zucFirst(ledger.background, surface.background, model.background_origin?.background, {});
  const o = zucFirst(ledger.origin_insight, surface.origin_insight, originLedger, model.background_origin?.origin_insight, {});
  if (!zucIsObject(b) && !zucIsObject(o)) return model;
  model.background_origin ||= {};
  model.background_origin.background = {
    name: zudSafeText(zucFirst(b.name, b.background_name, b.title), ""),
    background_sphere: zudSafeText(zucFirst(b.background_sphere, b.sphere), ""),
    background_talent: zudSafeText(zucFirst(b.background_talent, b.talent), ""),
    compensation: zudSafeText(zucFirst(b.compensation), ""),
    equipment: zuhArrayText(zucFirst(b.equipment, b.items)),
    notes: zudSafeText(zucFirst(b.gm_screen_note, b.notes, b.reason_selected, b.summary), ""),
    summary: zudSafeText(zucFirst(b.reason_selected, b.summary), ""),
    source: "Background_Origin_Ledger.json"
  };
  model.background_origin.origin_insight = {
    name: zudSafeText(zucFirst(o.name, o.insight_name), ""),
    benefit: zudSafeText(zucFirst(o.full_benefit, o.benefit, o.effect), ""),
    restrictions: zuhArrayText(zucFirst(o.restrictions, o.limits)),
    counts_against_background: Boolean(o.counts_against_background),
    counts_against_level_talent: Boolean(o.counts_against_level_talent),
    counts_against_trained_choices: Boolean(o.counts_against_trained_choices),
    source: zudSafeText(zucFirst(o.source_category, o.source), "Origin_Insight_Ledger.json")
  };
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_BACKGROUND_ORIGIN_VISIBLE", message: "Background and Origin Insight surfaced from Background_Origin_Ledger / Origin_Insight_Ledger.", source: "Background_Origin_Ledger.json", tab: "background-origin" });
  return model;
}
function zuhStepFromComposite(step = {}, index = 0) {
  const detail = zucIsObject(step.linked_action_detail) ? step.linked_action_detail : {};
  return {
    step: zucNum(zucFirst(step.step, step.step_number, step.order), index + 1),
    timing: zudSafeText(zucFirst(step.timing, detail.timing), ""),
    economy: zudSafeText(zucFirst(step.economy, detail.economy), ""),
    action_id: zudSafeText(zucFirst(step.action_id, step.linked_action_id, detail.action_id), ""),
    action_name: zudSafeText(zucFirst(step.action_name, step.name, detail.action_name), ""),
    cost: zudSafeText(zucFirst(step.cost, detail.cost), ""),
    range: zudSafeText(zucFirst(step.range, detail.range), ""),
    target: zudSafeText(zucFirst(step.target, detail.target), ""),
    roll_or_save: zudSafeText(zucFirst(step.roll_or_save, step.roll_save_check, detail.roll_save_check), ""),
    success_effect: zudSafeText(zucFirst(step.success_effect, step.effect, detail.success_effect), ""),
    failure_or_limit: zudSafeText(zucFirst(step.failure_or_limit, step.failure_limit, detail.failure_limit), ""),
    duration: zudSafeText(zucFirst(step.duration, detail.duration), ""),
    counterplay: zudSafeText(zucFirst(step.counterplay, detail.counterplay), ""),
    resolved: true,
    source_action: detail
  };
}
function zuhRepairComposites(model = {}, pkg = {}) {
  const parsed = zuhParsedBlocks(pkg);
  const file = zuhFindJson(parsed, [/Composite_Playbook/i, /Combat_Playbook/i, /Composite_Action_Registry/i]);
  const rows = zucArray(zucFirst(file.composites, file.composite_playbook_entries, file.composite_actions, file.playbooks, file.entries));
  if (!rows.length) return model;
  model.composites = rows.map((c, i) => {
    const steps = zucArray(zucFirst(c.component_steps, c.component_sequence, c.sequence, c.steps, c.components)).map(zuhStepFromComposite);
    const linked = zucArray(zucFirst(c.linked_action_details)).concat(steps.map((s) => s.source_action).filter(zucIsObject)).map((a, j) => zuhActionFromSurface(a, j, "Composite_Playbook.linked_action_details"));
    const hooks = zucFirst(c.dao_iching_hooks, c.dao_i_ching_hooks, {});
    return {
      composite_id: zudSafeText(zucFirst(c.composite_id, c.id), `CMP_${i + 1}`),
      name: zudSafeText(zucFirst(c.name, c.display_name, c.composite_name), `Composite ${i + 1}`),
      priority: zucNum(zucFirst(c.priority, c.priority_bucket), i + 1),
      category: zudSafeText(zucFirst(c.category, c.role), ""),
      execution_role: zudSafeText(zucFirst(c.execution_role, c.role), ""),
      when_to_use: zudSafeText(zucFirst(c.when_to_use, c.purpose, c.selection_condition), ""),
      do_not_use_when: zudSafeText(zucFirst(c.do_not_use_when, c.avoid_when), ""),
      resource_budget: zudSafeText(zucFirst(c.resource_budget, c.resource_budget_short), ""),
      economy_footprint: zuhArrayText(zucFirst(c.economy_footprint, steps.map((s) => s.economy))).filter(Boolean),
      temporal_feasibility: { same_turn_legal: /same.turn|single.turn/i.test(String(c.temporal_feasibility || c.temporal_feasibility_display || "")), round_segmentation: zudSafeText(zucFirst(c.temporal_feasibility_display, c.temporal_feasibility), "Timing label not recorded"), synthesized: !c.temporal_feasibility_display, source: "Composite_Playbook.json" },
      fallback: zudSafeText(zucFirst(c.fallback_action, c.fallback), ""),
      sequence: steps,
      linked_actions: linked.filter((a) => a.name),
      dao_hook: zuhValueText(zucFirst(hooks.dao_behavior_trigger, hooks.dao_hook, hooks.dao, c.dao_hook), ""),
      i_ching_hook: zuhValueText(zucFirst(hooks.i_ching_state_reading, hooks.i_ching_hook, hooks.i_ching, c.i_ching_hook), ""),
      diagnostics: zuhArrayText(zucFirst(c.diagnostics, c.gm_screen_drilldown_ready ? "GM screen drilldown ready" : ""))
    };
  });
  model.diagnostics ||= [];
  model.diagnostics.push({ severity: "info", code: "ZUH_COMPOSITES_VISIBLE", message: `${model.composites.length} composite playbooks surfaced from Composite_Playbook.composites.`, source: "Composite_Playbook.json", tab: "composite-playbooks" });
  return model;
}
const zuhRepairModelVisibilityBase = zuhRepairModelVisibility;
zuhRepairModelVisibility = function zuhRepairModelVisibilityWithActionComposite(model = {}, pkg = {}) {
  model = zuhRepairModelVisibilityBase(model, pkg);
  model = zuhRepairBackgroundOrigin(model, pkg);
  model = zuhRepairActions(model, pkg);
  model = zuhRepairComposites(model, pkg);
  model.patch = ZUH_PATCH_ID;
  model.renderer_patch = ZUH_PATCH_ID;
  return model;
};


/* ============================================================================
 * HF05ZUI-R1A — Real ZIP Ledger Import Visibility Bridge
 * Scope: importer/view-model bridge only. Preserves HF05ZUC v2 architecture,
 * HF05ZUD/ZUE/ZUF layout and composite drilldown. Fixes the real ZIP import
 * path so current character-factory ledger files are retained and normalized.
 * ========================================================================== */
const ZUI_PATCH_ID = "HF05ZUI-R1A";
const ZUI_CURRENT_LEDGER_IMPORT_PATTERN = /(?:^|[\\/])(?:Composite_Playbook|Dao_IChing_Combat_Profile|Leveling_Ledger|Leveling_Ledger_Display_Alias|Foundation_Detail_Ledger|Background_Origin_Ledger|Origin_Insight_Ledger|Complete_Action_Surface|Martial_Arts_and_Manuals|Cultivation_Method_Profile|Canonical_Stats_Resource_Block|Normalized_Sheet|Character_Import_Surface|Tianxia_GM_Character_Model_v1|Tianxia_GM_Character_View_Model_v2|GM_Screen_Tab_Expectation_Manifest|GM_Screen_Render_Contract_Report|GM_SCREEN_TEMPLATE_READINESS_PROFILE)\.json$/i;
const ZUI_CURRENT_LEDGER_RECORD_PATTERN = /(?:^|[\\/])(?:Character_Import_Surface|Tianxia_GM_Character_View_Model_v2|Canonical_Stats_Resource_Block|Normalized_Sheet|Complete_Action_Surface|Composite_Playbook|Dao_IChing_Combat_Profile|Leveling_Ledger|Foundation_Detail_Ledger)\.json$/i;
const zuiIsCmlCharacterRecordEntryBefore = isCmlCharacterRecordEntry;
isCmlCharacterRecordEntry = function isCmlCharacterRecordEntryHf05zui(entry) {
  const name = String(entry?.name || "").replace(/\\/g, "/");
  if (!name || isCmlInfrastructureEntryName(name)) return false;
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  if (ZUI_CURRENT_LEDGER_RECORD_PATTERN.test(entryBaseName(name))) return true;
  return zuiIsCmlCharacterRecordEntryBefore(entry);
};
const zuiIsEntryInCharacterFolderBefore = isEntryInCharacterFolder;
isEntryInCharacterFolder = function isEntryInCharacterFolderHf05zui(entryName, folder) {
  const name = String(entryName || "").replace(/\\/g, "/");
  if (isCmlInfrastructureEntryName(name)) return false;
  if (/\.zip(?:\.|$)/i.test(name)) return false;
  if (!(isTextLikeFile(name) || isDocxFile(name))) return false;
  const relative = relativeCharacterEntryName(name, folder);
  if (folder === "__ROOT__" && name.includes("/")) return false;
  if (folder !== "__ROOT__" && !name.startsWith(`${folder}/`)) return false;
  if (ZUI_CURRENT_LEDGER_IMPORT_PATTERN.test(relative) || ZUI_CURRENT_LEDGER_IMPORT_PATTERN.test(entryBaseName(relative))) return true;
  return zuiIsEntryInCharacterFolderBefore(entryName, folder);
};
const zuiCompactSupportBlocksBefore = compactSupportBlocks;
compactSupportBlocks = function compactSupportBlocksHf05zui(blocks = []) {
  const base = zuiCompactSupportBlocksBefore(blocks);
  const seen = new Set(base.map((b) => String(b?.name || "")));
  const extras = (Array.isArray(blocks) ? blocks : [])
    .filter((block) => ZUI_CURRENT_LEDGER_IMPORT_PATTERN.test(String(block?.name || "")) || ZUI_CURRENT_LEDGER_IMPORT_PATTERN.test(entryBaseName(block?.name || "")))
    .filter((block) => !seen.has(String(block?.name || "")))
    .map((block) => ({ name: block.name, content: block.content }));
  return base.concat(extras);
};
function zuiParsedBlocks(pkg = {}) { try { return parseJsonPackageBlocks(zucBlocks(pkg)); } catch { return []; } }
function zuiFindJsonByBase(parsed = [], names = []) {
  const wanted = names.map((n) => String(n).toLowerCase());
  const found = parsed.find((entry) => wanted.includes(entryBaseName(entry?.name || "").toLowerCase()));
  return found?.data || null;
}
function zuiFindJsonAny(pkg = {}, names = [], patterns = []) {
  const parsed = zuiParsedBlocks(pkg);
  return zuiFindJsonByBase(parsed, names) || zuhFindJson(parsed, patterns) || {};
}
function zuiPushDiag(model, code, message, source, tab = "diagnostics", severity = "info") {
  model.diagnostics ||= [];
  model.diagnostics.push({ severity, code, message, source, tab, patch: ZUI_PATCH_ID });
}
function zuiFirstText(...values) {
  for (const v of values) {
    const t = zuhValueText(v, "");
    if (t) return t;
  }
  return "";
}
function zuiNormalizeMethod(model = {}, pkg = {}) {
  const method = zuiFindJsonAny(pkg, ["Cultivation_Method_Profile.json"], [/Cultivation_Method_Profile/i]);
  if (!zucIsObject(method) || !Object.keys(method).length) return model;
  const res = zucIsObject(method.resource_shape) ? method.resource_shape : {};
  const breakthrough = zucIsObject(method.breakthrough_shape) ? method.breakthrough_shape : method.breakthrough_shape;
  const foundation = zucIsObject(method.foundation_shape) ? method.foundation_shape : {};
  const mech = [];
  if (res.effect || res.name) mech.push(zuiFirstText(res.name, res.effect, res.applied_to));
  if (res.effect) mech.push(zuhValueText(res.effect, ""));
  if (method.source_conversion_rationale) mech.push(zuhValueText(method.source_conversion_rationale, ""));
  const math = [];
  if (res.applied_to || res.final_primary_resource_max !== undefined) math.push(`${zuhValueText(res.applied_to, "Primary resource")} max ${zuhValueText(res.final_primary_resource_max, "?")}`);
  if (res.numeric_modifier !== undefined) math.push(`Numeric modifier ${zuhValueText(res.numeric_modifier, "")}`);
  if (res.effect) math.push(zuhValueText(res.effect, ""));
  model.method = {
    name: zudSafeText(zucFirst(method.method_name, method.name, method.display_name), "No cultivation method recorded"),
    status: zudSafeText(zucFirst(method.status, method.primary_method ? "active" : ""), ""),
    resource_shape: zuiFirstText(res.name, res.effect),
    source: "Cultivation_Method_Profile.json",
    mechanical_effects: mech.filter(Boolean),
    applied_math: math.filter(Boolean),
    breakthrough_shape: zuiFirstText(breakthrough?.name, breakthrough?.compatible_bonus, breakthrough),
    foundation_compatibility: zuhArrayText(zucFirst(foundation.foundation_compatibility, foundation.supported_families, method.foundation_shape)),
    incompatibilities: zuhArrayText(method.incompatibilities)
  };
  zuiPushDiag(model, "ZUI_METHOD_VISIBLE", "Cultivation method mechanical effects surfaced from Cultivation_Method_Profile.json.", "Cultivation_Method_Profile.json", "method");
  return model;
}
function zuiManualFromRecordedArt(r = {}, i = 0, file = {}) {
  const linked = zucArray(zucFirst(r.linked_action_details));
  const first = linked.find(zucIsObject) || {};
  return {
    recorded_art_id: zudSafeText(zucFirst(r.recorded_art_id, r.art_id, r.id), `RECORDED_ART_${i + 1}`),
    manual_name: zudSafeText(zucFirst(r.manual, r.manual_name, r.name, r.id), `Manual ${i + 1}`),
    technique_name: zudSafeText(zucFirst(r.technique, r.technique_name, r.form_name, r.name), `Technique ${i + 1}`),
    expression_kind: zudSafeText(r.expression_kind, "unclassified"),
    custom_design: r.custom_design === true,
    preserved_forged_expression: zucIsObject(r.preserved_forged_expression) ? r.preserved_forged_expression : null,
    source_packet_ids: zuiR2ArrayValue(r.source_packet_ids, r.source_packet_id),
    source_spheres: zuiR2ArrayValue(r.source_spheres, r.spheres),
    reproduced_ability: zudSafeText(zucFirst(r.reproduced_package, r.reproduced_ability, r.source_package), ""),
    DC: zudSafeText(zucFirst(r.dc, r.DC, r.training_dc, r.practice_dc), ""),
    realm_gate: zudSafeText(zucFirst(r.realm, r.realm_gate), ""),
    timing_economy: zudSafeText(zucFirst(r.timing, r.timing_economy, r.activation, r.action_type, first.timing), ""),
    cost: zudSafeText(zucFirst(r.cost, r.resource_cost, first.cost), ""),
    range: zudSafeText(zucFirst(r.range, first.range), ""),
    target: zudSafeText(zucFirst(r.target, first.target), ""),
    roll_save_check: zudSafeText(zucFirst(r.roll_save_check, r.roll_save, r.roll_or_save, r.attack_or_save, r.check, first.roll_save_check), ""),
    effect: zudSafeText(zucFirst(r.effect, r.success_effect, r.description, first.success_effect), ""),
    failure_miss: zudSafeText(zucFirst(r.failure, r.failure_miss, r.miss, r.failure_or_limit, first.failure_limit), ""),
    duration: zudSafeText(zucFirst(r.duration, first.duration), ""),
    limit: zudSafeText(zucFirst(r.limit, r.limits, r.restrictions), ""),
    counterplay: zudSafeText(zucFirst(r.counterplay, first.counterplay), ""),
    linked_action_refs: zuiR2ArrayValue(r.linked_action_ids, r.actions, r.linked_action, first.action_id),
    policy_notes: zudSafeText(zucFirst(r.policy_note, r.policy_notes, file.manual_legality_note), ""),
    source: "Martial_Arts_and_Manuals.recorded_arts"
  };
}
function zuiNormalizeManuals(model = {}, pkg = {}) {
  const file = zuiFindJsonAny(pkg, ["Martial_Arts_and_Manuals.json"], [/Martial_Arts_and_Manuals/i]);
  const rows = zucArray(zucFirst(file.recorded_arts, file.manuals, file.martial_arts, file.entries, file.items));
  if (!rows.length) return model;
  model.martial_manuals = rows.map((r, i) => zuiManualFromRecordedArt(r, i, file));
  zuiPushDiag(model, "ZUI_RECORDED_ARTS_VISIBLE", `${model.martial_manuals.length} recorded art technique cards surfaced from Martial_Arts_and_Manuals.json.`, "Martial_Arts_and_Manuals.json", "martial-manuals-recorded-arts");
  return model;
}
function zuiNormalizeDaoIChing(model = {}, pkg = {}) {
  const src = zuiFindJsonAny(pkg, ["Dao_IChing_Combat_Profile.json"], [/Dao_IChing_Combat_Profile/i, /Dao_Combat_Behavior_Profile/i, /Dao_Profile/i]);
  if (!zucIsObject(src) || !Object.keys(src).length) return model;
  const i = zucFirst(src.i_ching, src.i_ching_combat_layer, src.iChing, {});
  model.dao_i_ching = {
    dao: {
      dao_phrase: zudSafeText(zucFirst(src.dao_phrase, src.dao_name), ""),
      combat_doctrine: zudSafeText(zucFirst(src.combat_doctrine, src.dao_thesis, src.default_behavior), ""),
      resource_policy: zudSafeText(zucFirst(src.resource_policy, src.resource_temperament), ""),
      reaction_policy: zudSafeText(zucFirst(src.reaction_policy), ""),
      ai_turn_prompt: zudSafeText(zucFirst(src.ai_turn_prompt, src.preferred_victory), ""),
      preferred_engagements: zuhArrayText(zucFirst(src.preferred_engagements, src.preferred_victory, src.composite_selection_logic)),
      avoidance_rules: zuhArrayText(zucFirst(src.avoidance_rules)),
      risk_thresholds: zuhArrayText(zucFirst(src.risk_thresholds, src.risk_policy)),
      target_selection_logic: zuhArrayText(zucFirst(src.target_selection_logic)),
      failure_recovery: zuhArrayText(zucFirst(src.failure_recovery, src.failure_recovery_policy)),
      forbidden_behaviors: zuhArrayText(zucFirst(src.forbidden_behaviors)),
      composite_hooks: zuhArrayText(zucFirst(src.composite_selection_logic, src.composite_hooks))
    },
    i_ching: {
      enabled: Object.keys(i || {}).length > 0,
      reading_name: zudSafeText(zucFirst(i.opening_read, i.reading_name, i.name), ""),
      hexagram_or_trigram: zudSafeText(zucFirst(i.default_trigram_pair, i.hexagram_or_trigram, i.hexagram, i.trigram), ""),
      natural_tendency: zudSafeText(zucFirst(i.natural_tendency, i.opening_read), ""),
      testing_tendency: zudSafeText(zucFirst(i.testing_tendency, i.defensive_shift, i.pursuit_shift), ""),
      shift_triggers: zuhArrayText(zucFirst(i.shift_triggers, [i.defensive_shift, i.pursuit_shift].filter(Boolean))),
      low_resource_shift: zudSafeText(zucFirst(i.low_resource_shift), ""),
      combat_state_interpretation: zudSafeText(zucFirst(i.combat_state_interpretation, i.opening_read), ""),
      gm_generation_instruction: zudSafeText(zucFirst(i.gm_generation_instruction, i.defensive_shift), ""),
      composite_hooks: zuhArrayText(zucFirst(i.composite_hooks))
    }
  };
  zuiPushDiag(model, "ZUI_DAO_ICHING_VISIBLE", "Dao and I Ching profile surfaced from Dao_IChing_Combat_Profile.json.", "Dao_IChing_Combat_Profile.json", "dao-i-ching");
  return model;
}
function zuiNormalizeComposites(model = {}, pkg = {}) {
  const file = zuiFindJsonAny(pkg, ["Composite_Playbook.json"], [/Composite_Playbook/i, /Combat_Playbook/i, /Composite_Action_Registry/i]);
  const rows = zucArray(zucFirst(file.composites, file.composite_playbook_entries, file.composite_actions, file.playbooks, file.entries));
  if (!rows.length) return model;
  model.composites = rows.map((c, i) => {
    const steps = zucArray(zucFirst(c.component_steps, c.component_sequence, c.sequence, c.steps, c.components)).map(zuhStepFromComposite);
    const linked = zucArray(zucFirst(c.linked_action_details)).concat(steps.map((s) => s.source_action).filter(zucIsObject)).map((a, j) => zuhActionFromSurface(a, j, "Composite_Playbook.linked_action_details"));
    const hooks = zucFirst(c.dao_iching_hooks, c.dao_i_ching_hooks, {});
    return {
      composite_id: zudSafeText(zucFirst(c.composite_id, c.id), `CMP_${i + 1}`),
      name: zudSafeText(zucFirst(c.name, c.display_name, c.composite_name), `Composite ${i + 1}`),
      priority: zucNum(zucFirst(c.priority, c.priority_bucket), i + 1),
      category: zudSafeText(zucFirst(c.category, c.role), ""),
      execution_role: zudSafeText(zucFirst(c.execution_role, c.role), ""),
      when_to_use: zudSafeText(zucFirst(c.when_to_use, c.purpose, c.selection_condition), ""),
      do_not_use_when: zudSafeText(zucFirst(c.do_not_use_when, c.avoid_when), ""),
      resource_budget: zudSafeText(zucFirst(c.resource_budget, c.resource_budget_short), ""),
      economy_footprint: zuhArrayText(zucFirst(c.economy_footprint, steps.map((s) => s.economy))).filter(Boolean),
      temporal_feasibility: { same_turn_legal: /same.turn|single.turn/i.test(String(c.temporal_feasibility || c.temporal_feasibility_display || "")), round_segmentation: zudSafeText(zucFirst(c.temporal_feasibility_display, c.temporal_feasibility), "Timing label not recorded"), synthesized: !c.temporal_feasibility_display, source: "Composite_Playbook.json" },
      fallback: zudSafeText(zucFirst(c.fallback_action, c.fallback), ""),
      sequence: steps,
      linked_actions: linked.filter((a) => a.name),
      dao_hook: zuhValueText(zucFirst(hooks.dao_behavior_trigger, hooks.dao_hook, hooks.dao, c.dao_hook), ""),
      i_ching_hook: zuhValueText(zucFirst(hooks.i_ching_state_reading, hooks.i_ching_hook, hooks.i_ching, c.i_ching_hook), ""),
      diagnostics: zuhArrayText(zucFirst(c.diagnostics, c.gm_screen_drilldown_ready ? "GM screen drilldown ready" : ""))
    };
  });
  zuiPushDiag(model, "ZUI_COMPOSITES_VISIBLE", `${model.composites.length} composite playbooks surfaced from Composite_Playbook.json through the live import path.`, "Composite_Playbook.json", "composite-playbooks");
  return model;
}
function zuiNormalizeActions(model = {}, pkg = {}) {
  const complete = zuiFindJsonAny(pkg, ["Complete_Action_Surface.json"], [/Complete_Action_Surface/i]);
  const surface = zuiFindJsonAny(pkg, ["Character_Import_Surface.json"], [/Character_Import_Surface/i]);
  const rows = [...zucArray(complete.actions), ...zucArray(complete.rows), ...zucArray(surface.actions), ...zucArray(surface.gm_screen_action_rows)];
  if (!rows.length) return model;
  const byId = new Map();
  rows.map((a, i) => zuhActionFromSurface(a, i, "Complete_Action_Surface / Character_Import_Surface")).forEach((a) => {
    if (!a.name) return;
    const key = zucKey(a.action_id || a.name);
    if (!byId.has(key) || zuhValueText(a).length > zuhValueText(byId.get(key)).length) byId.set(key, a);
  });
  if (byId.size) {
    model.actions = Array.from(byId.values());
    zuiPushDiag(model, "ZUI_ACTIONS_VISIBLE", `${model.actions.length} action cards surfaced from Complete_Action_Surface.json.`, "Complete_Action_Surface.json", "actions");
  }
  return model;
}
function zuiNormalizeLeveling(model = {}, pkg = {}) {
  const ledger = zuiFindJsonAny(pkg, ["Leveling_Ledger.json"], [/Leveling_Ledger$/i, /Leveling_Ledger\.json/i]);
  const alias = zuiFindJsonAny(pkg, ["Leveling_Ledger_Display_Alias.json"], [/Leveling_Ledger_Display_Alias/i]);
  const src = Object.keys(ledger || {}).length ? ledger : (alias.leveling_ledger || alias);
  const rows = zucArray(zucFirst(src.level_rows, src.rows, src.levels, alias.leveling_ledger?.level_rows));
  if (!rows.length) return model;
  const inferRealm = (cl) => cl < 5 ? "Mortal" : cl < 10 ? "Foundation Establishment" : "Core Formation";
  model.leveling_ledger = rows.map((r, idx) => {
    const gain = r.gain && zucIsObject(r.gain) ? r.gain : r;
    const cl = zucNum(zucFirst(gain.cl, gain.CL, gain.level), idx + 1);
    const used = zucNum(gain.trained_choices_used, null);
    const limit = zucNum(gain.trained_choice_limit, 3);
    return {
      CL: cl,
      realm: zudSafeText(zucFirst(gain.realm, r.realm, src.realm), inferRealm(cl)),
      PB: zucNum(zucFirst(gain.pb, gain.PB, gain.proficiency_bonus), cl <= 4 ? 2 : cl <= 8 ? 3 : cl <= 12 ? 4 : 5),
      hp_gain: zudSafeText(zucFirst(gain.hp_gain, gain.hp, gain.hp_change), "not itemized"),
      resource_max_after_level: zudSafeText(zucFirst(gain.resource_max_after_level, gain.resource_max, gain.resource), "not itemized"),
      free_level_talent: zudSafeText(zucFirst(gain.free_level_talent, gain.level_talent, gain.talent), ""),
      new_spheres_gained: zuhArrayText(zucFirst(gain.new_spheres_gained, gain.new_spheres, gain.spheres)),
      new_sphere_bonus_talents: zuhArrayText(zucFirst(gain.new_sphere_bonus_talents, gain.bonus_talents, gain.free_talents)),
      trained_choices: zuhArrayText(zucFirst(gain.trained_choices, gain.trained, gain.choices)),
      trained_choices_used: used,
      trained_choice_limit: limit,
      trained_choices_text: used !== null ? `${used}/${limit} trained choices used` : "not itemized",
      background_grants: cl === 1 ? zuhArrayText(zucFirst(gain.background_grants, gain.background, model.background_origin?.background?.name)) : zuhArrayText(zucFirst(gain.background_grants, gain.background)),
      origin_insight: cl === 1 ? zudSafeText(zucFirst(gain.origin_insight, gain.origin, model.background_origin?.origin_insight?.name), "") : zudSafeText(zucFirst(gain.origin_insight, gain.origin), ""),
      method_event: zudSafeText(zucFirst(gain.method_event, gain.method), ""),
      foundation_event: zudSafeText(zucFirst(gain.foundation_event, gain.foundation), ""),
      advancement_choice: zudSafeText(zucFirst(gain.asi_or_insight_choice, gain.advancement_choice), "") || zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)).join("; "),
      advancement_choices: zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)),
      manuals_or_recorded_arts: zuhArrayText(zucFirst(gain.manuals_or_recorded_arts, gain.manuals, gain.recorded_arts)),
      forged_techniques: zuhArrayText(zucFirst(gain.forged_techniques, gain.forged)),
      validation_notes: zuhArrayText(zucFirst(gain.validation_notes, gain.notes, gain.diagnostics, gain.legal === true ? "legal" : ""))
    };
  });
  zuiPushDiag(model, "ZUI_LEVELING_LEDGER_VISIBLE", `${model.leveling_ledger.length} CL rows surfaced from Leveling_Ledger.json through the live import path.`, "Leveling_Ledger.json", "leveling-ledger");
  return model;
}
const zuiRepairModelVisibilityBefore = zuhRepairModelVisibility;
zuhRepairModelVisibility = function zuiRepairModelVisibility(model = {}, pkg = {}) {
  model = zuiRepairModelVisibilityBefore(model, pkg);
  model = zuiNormalizeActions(model, pkg);
  model = zuiNormalizeComposites(model, pkg);
  model = zuiNormalizeManuals(model, pkg);
  model = zuiNormalizeMethod(model, pkg);
  model = zuiNormalizeDaoIChing(model, pkg);
  model = zuiNormalizeLeveling(model, pkg);
  model.patch = ZUI_PATCH_ID;
  model.renderer_patch = ZUI_PATCH_ID;
  model.diagnostics ||= [];
  model.diagnostics = model.diagnostics.filter((d) => {
    const text = `${d.code || ""} ${d.message || ""}`;
    if (/ACTIONS_MISSING/i.test(text) && (model.actions || []).length) return false;
    if (/MARTIAL_MANUALS_NOT_RECORDED/i.test(text) && (model.martial_manuals || []).length) return false;
    if (/I_CHING_NOT_RECORDED/i.test(text) && model.dao_i_ching?.i_ching?.enabled) return false;
    if (/COMPOSITES.*MISSING|No usable composite/i.test(text) && (model.composites || []).length) return false;
    return true;
  });
  zuiPushDiag(model, "ZUI_REAL_IMPORT_BRIDGE_ACTIVE", "Current factory ledger files are retained by the ZIP import path and normalized into the visible v2 model.", "HF05ZUI import/view bridge", "diagnostics");
  return model;
};
const zuiRenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zui(pkg, notes = {}) {
  try {
    const html = zuhRenderVisualCharacterSheet(pkg, notes);
    return html.replace(/HF05ZUH-R1A/g, ZUI_PATCH_ID).replace(/Character Surface Visibility/g, "Real ZIP Ledger Visibility");
  } catch (error) {
    const fallback = zuiRenderVisualCharacterSheetBefore(pkg, notes);
    return `${fallback}<section class="sheet-section"><h4>HF05ZUI Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`;
  }
};

/* HF05ZUI-R1B list-array repair: do not use zucFirst() for arrays because it flattens and returns the first row. */
const ZUI_LIST_PATCH_ID = "HF05ZUI-R1B";
function zuiFirstArray(obj = {}, keys = []) {
  for (const key of keys) {
    const v = obj?.[key];
    if (Array.isArray(v) && v.length) return v;
  }
  return [];
}
function zuiNormalizeManualsAllRows(model = {}, pkg = {}) {
  const file = zuiFindJsonAny(pkg, ["Martial_Arts_and_Manuals.json"], [/Martial_Arts_and_Manuals/i]);
  const rows = zuiFirstArray(file, ["recorded_arts", "manuals", "martial_arts", "entries", "items"]);
  if (!rows.length) return model;
  model.martial_manuals = rows.map((r, i) => zuiManualFromRecordedArt(r, i, file));
  zuiPushDiag(model, "ZUI_RECORDED_ARTS_ALL_ROWS_VISIBLE", `${model.martial_manuals.length} recorded art technique cards surfaced from Martial_Arts_and_Manuals.json.`, "Martial_Arts_and_Manuals.json", "martial-manuals-recorded-arts");
  return model;
}
function zuiStepFromCompositeAll(step = {}, index = 0) {
  const detail = zucIsObject(step.linked_action_detail) ? step.linked_action_detail : {};
  return {
    step: zucNum(zucFirst(step.step, step.step_number, step.order), index + 1),
    timing: zudSafeText(zucFirst(step.timing, detail.timing), ""),
    economy: zudSafeText(zucFirst(step.economy, detail.economy), ""),
    action_id: zudSafeText(zucFirst(step.action_id, step.linked_action_id, detail.action_id), ""),
    action_name: zudSafeText(zucFirst(step.action_name, step.name, detail.action_name), ""),
    cost: zudSafeText(zucFirst(step.cost, detail.cost), ""),
    range: zudSafeText(zucFirst(step.range, detail.range), ""),
    target: zudSafeText(zucFirst(step.target, detail.target), ""),
    roll_or_save: zudSafeText(zucFirst(step.roll_or_save, step.roll_save_check, detail.roll_save_check), ""),
    success_effect: zudSafeText(zucFirst(step.success_effect, step.effect, detail.success_effect), ""),
    failure_or_limit: zudSafeText(zucFirst(step.failure_or_limit, step.failure_limit, detail.failure_limit), ""),
    duration: zudSafeText(zucFirst(step.duration, detail.duration), ""),
    counterplay: zudSafeText(zucFirst(step.counterplay, detail.counterplay), ""),
    resolved: true,
    source_action: detail
  };
}
function zuiNormalizeCompositesAllRows(model = {}, pkg = {}) {
  const file = zuiFindJsonAny(pkg, ["Composite_Playbook.json"], [/Composite_Playbook/i, /Combat_Playbook/i, /Composite_Action_Registry/i]);
  const rows = zuiFirstArray(file, ["composites", "composite_playbook_entries", "composite_actions", "playbooks", "entries"]);
  if (!rows.length) return model;
  model.composites = rows.map((c, i) => {
    const steps = zuiFirstArray(c, ["component_steps", "component_sequence", "sequence", "steps", "components"]).map(zuiStepFromCompositeAll);
    const linked = zuiFirstArray(c, ["linked_action_details"]).concat(steps.map((s) => s.source_action).filter(zucIsObject)).map((a, j) => zuhActionFromSurface(a, j, "Composite_Playbook.linked_action_details"));
    const hooks = zucFirst(c.dao_iching_hooks, c.dao_i_ching_hooks, {});
    return {
      composite_id: zudSafeText(zucFirst(c.composite_id, c.id), `CMP_${i + 1}`),
      name: zudSafeText(zucFirst(c.name, c.display_name, c.composite_name), `Composite ${i + 1}`),
      priority: zucNum(zucFirst(c.priority, c.priority_bucket), i + 1),
      category: zudSafeText(zucFirst(c.category, c.role), ""),
      execution_role: zudSafeText(zucFirst(c.execution_role, c.role), ""),
      when_to_use: zudSafeText(zucFirst(c.when_to_use, c.purpose, c.selection_condition), ""),
      do_not_use_when: zudSafeText(zucFirst(c.do_not_use_when, c.avoid_when), ""),
      resource_budget: zudSafeText(zucFirst(c.resource_budget, c.resource_budget_short), ""),
      economy_footprint: zuiFirstArray(c, ["economy_footprint"]).length ? zuiFirstArray(c, ["economy_footprint"]) : steps.map((s) => s.economy).filter(Boolean),
      temporal_feasibility: { same_turn_legal: /same.turn|single.turn/i.test(String(c.temporal_feasibility || c.temporal_feasibility_display || "")), round_segmentation: zudSafeText(zucFirst(c.temporal_feasibility_display, c.temporal_feasibility), "Timing label not recorded"), synthesized: !c.temporal_feasibility_display, source: "Composite_Playbook.json" },
      fallback: zudSafeText(zucFirst(c.fallback_action, c.fallback), ""),
      sequence: steps,
      linked_actions: linked.filter((a) => a.name),
      dao_hook: zuhValueText(zucFirst(hooks.dao_behavior_trigger, hooks.dao_hook, hooks.dao, c.dao_hook), ""),
      i_ching_hook: zuhValueText(zucFirst(hooks.i_ching_state_reading, hooks.i_ching_hook, hooks.i_ching, c.i_ching_hook), ""),
      diagnostics: zuiFirstArray(c, ["diagnostics"]).length ? zuiFirstArray(c, ["diagnostics"]) : (c.gm_screen_drilldown_ready ? ["GM screen drilldown ready"] : [])
    };
  });
  zuiPushDiag(model, "ZUI_COMPOSITES_ALL_ROWS_VISIBLE", `${model.composites.length} composite playbooks surfaced from Composite_Playbook.json through the live import path.`, "Composite_Playbook.json", "composite-playbooks");
  return model;
}
function zuiNormalizeLevelingAllRows(model = {}, pkg = {}) {
  const ledger = zuiFindJsonAny(pkg, ["Leveling_Ledger.json"], [/Leveling_Ledger$/i, /Leveling_Ledger\.json/i]);
  const alias = zuiFindJsonAny(pkg, ["Leveling_Ledger_Display_Alias.json"], [/Leveling_Ledger_Display_Alias/i]);
  const src = Object.keys(ledger || {}).length ? ledger : (alias.leveling_ledger || alias);
  const rows = zuiFirstArray(src, ["level_rows", "rows", "levels"]).length ? zuiFirstArray(src, ["level_rows", "rows", "levels"]) : zuiFirstArray(alias.leveling_ledger || {}, ["level_rows"]);
  if (!rows.length) return model;
  const inferRealm = (cl) => cl < 5 ? "Mortal" : cl < 10 ? "Foundation Establishment" : "Core Formation";
  model.leveling_ledger = rows.map((r, idx) => {
    const gain = r.gain && zucIsObject(r.gain) ? r.gain : r;
    const cl = zucNum(zucFirst(gain.cl, gain.CL, gain.level), idx + 1);
    const used = zucNum(gain.trained_choices_used, null);
    const limit = zucNum(gain.trained_choice_limit, 3);
    return {
      CL: cl,
      realm: zudSafeText(zucFirst(gain.realm, r.realm, src.realm), inferRealm(cl)),
      PB: zucNum(zucFirst(gain.pb, gain.PB, gain.proficiency_bonus), cl <= 4 ? 2 : cl <= 8 ? 3 : cl <= 12 ? 4 : 5),
      hp_gain: zudSafeText(zucFirst(gain.hp_gain, gain.hp, gain.hp_change), "not itemized"),
      resource_max_after_level: zudSafeText(zucFirst(gain.resource_max_after_level, gain.resource_max, gain.resource), "not itemized"),
      free_level_talent: zudSafeText(zucFirst(gain.free_level_talent, gain.level_talent, gain.talent), ""),
      new_spheres_gained: zuiFirstArray(gain, ["new_spheres_gained", "new_spheres", "spheres"]),
      new_sphere_bonus_talents: zuiFirstArray(gain, ["new_sphere_bonus_talents", "bonus_talents", "free_talents"]),
      trained_choices: zuiFirstArray(gain, ["trained_choices", "trained", "choices"]),
      trained_choices_used: used,
      trained_choice_limit: limit,
      trained_choices_text: used !== null ? `${used}/${limit} trained choices used` : "not itemized",
      background_grants: cl === 1 ? (zuiFirstArray(gain, ["background_grants"]).length ? zuiFirstArray(gain, ["background_grants"]) : [model.background_origin?.background?.name].filter(Boolean)) : zuiFirstArray(gain, ["background_grants"]),
      origin_insight: cl === 1 ? zudSafeText(zucFirst(gain.origin_insight, gain.origin, model.background_origin?.origin_insight?.name), "") : zudSafeText(zucFirst(gain.origin_insight, gain.origin), ""),
      method_event: zudSafeText(zucFirst(gain.method_event, gain.method), ""),
      foundation_event: zudSafeText(zucFirst(gain.foundation_event, gain.foundation), ""),
      advancement_choice: zudSafeText(zucFirst(gain.asi_or_insight_choice, gain.advancement_choice), "") || zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)).join("; "),
      advancement_choices: zuhArrayText(zucFirst(gain.advancement_choices, gain.advancement_events)),
      manuals_or_recorded_arts: zuiFirstArray(gain, ["manuals_or_recorded_arts", "manuals", "recorded_arts"]),
      forged_techniques: zuiFirstArray(gain, ["forged_techniques", "forged"]),
      validation_notes: zuiFirstArray(gain, ["validation_notes", "notes", "diagnostics"]).length ? zuiFirstArray(gain, ["validation_notes", "notes", "diagnostics"]) : (gain.legal === true ? ["legal"] : [])
    };
  });
  zuiPushDiag(model, "ZUI_LEVELING_ALL_ROWS_VISIBLE", `${model.leveling_ledger.length} CL rows surfaced from Leveling_Ledger.json through the live import path.`, "Leveling_Ledger.json", "leveling-ledger");
  return model;
}
const zuiRepairModelVisibilityBeforeR1B = zuhRepairModelVisibility;
zuhRepairModelVisibility = function zuiRepairModelVisibilityR1B(model = {}, pkg = {}) {
  model = zuiRepairModelVisibilityBeforeR1B(model, pkg);
  model = zuiNormalizeCompositesAllRows(model, pkg);
  model = zuiNormalizeManualsAllRows(model, pkg);
  model = zuiNormalizeLevelingAllRows(model, pkg);
  model.patch = ZUI_LIST_PATCH_ID;
  model.renderer_patch = ZUI_LIST_PATCH_ID;
  zuiPushDiag(model, "ZUI_ARRAY_LEDGER_ROWS_PRESERVED", "Array ledgers are read as full lists instead of being flattened to the first row.", "HF05ZUI-R1B list adapter", "diagnostics");
  return model;
};

/* ============================================================================
 * HF05ZUI-R2H — Authoritative Factory Consumer + Immortal Execution Projection
 * Clean consumer contract for HF05ZVK-R1E. Preserves ZUC/ZUD/ZUE/ZUH/ZUI
 * import compatibility while adding canonical forged-technique input, roster
 * retention, an always-visible active-renderer tab, and CL10 Realm correction.
 * ========================================================================== */
const ZUI_R2_PATCH_ID = "HF05ZUI-R2H";
const ZUI_R2_CANONICAL_PATTERN = /(?:^|[\/])(?:Forged_Techniques|Preserved_Forged_Expressions|Emergency_Technique_Seeds|Immortal_Arts|Manual_Lineage_Record|Character_Master_Ledger|Rules_Selection_Packets|Selected_Spheres|Sphere_Execution_Coverage|Talent_Source_Ledger|Talent_Execution_Coverage|Tianxia_GM_Character_View_Model_v2|GM_Screen_Tab_Expectation_Manifest|Build_Reconciliation)\.json$/i;

const zuiR2IsCmlCharacterRecordEntryBefore = isCmlCharacterRecordEntry;
isCmlCharacterRecordEntry = function isCmlCharacterRecordEntryHf05zuiR2(entry) {
  const name = String(entry?.name || "").replace(/\\/g, "/");
  if (ZUI_R2_CANONICAL_PATTERN.test(name) || ZUI_R2_CANONICAL_PATTERN.test(entryBaseName(name))) return true;
  return zuiR2IsCmlCharacterRecordEntryBefore(entry);
};
const zuiR2IsEntryInCharacterFolderBefore = isEntryInCharacterFolder;
isEntryInCharacterFolder = function isEntryInCharacterFolderHf05zuiR2(entryName, folder) {
  const name = String(entryName || "").replace(/\\/g, "/");
  const relative = relativeCharacterEntryName(name, folder);
  if (ZUI_R2_CANONICAL_PATTERN.test(relative) || ZUI_R2_CANONICAL_PATTERN.test(entryBaseName(relative))) return true;
  return zuiR2IsEntryInCharacterFolderBefore(entryName, folder);
};
const zuiR2CompactSupportBlocksBefore = compactSupportBlocks;
compactSupportBlocks = function compactSupportBlocksHf05zuiR2(blocks = []) {
  const base = zuiR2CompactSupportBlocksBefore(blocks);
  const seen = new Set(base.map((b) => String(b?.name || "")));
  const extras = (Array.isArray(blocks) ? blocks : []).filter((b) => ZUI_R2_CANONICAL_PATTERN.test(String(b?.name || "").replace(/\\/g, "/")));
  extras.forEach((b) => { if (!seen.has(String(b?.name || ""))) { base.push(b); seen.add(String(b?.name || "")); } });
  return base;
};

function zuiR2FindJson(pkg = {}, names = [], patterns = []) {
  if (typeof zuiFindJsonAny === "function") return zuiFindJsonAny(pkg, names, patterns);
  const parsed = typeof zucParsed === "function" ? zucParsed(pkg) : parseJsonPackageBlocks(pkg?.blocks || []);
  for (const name of names) {
    const hit = parsed.find((b) => String(b?.name || "").replace(/\\/g, "/").endsWith(name));
    if (hit?.data) return hit.data;
  }
  for (const pattern of patterns) {
    const hit = parsed.find((b) => pattern.test(String(b?.name || "")));
    if (hit?.data) return hit.data;
  }
  return {};
}
function zuiR2ArrayValue(...values) {
  for (const value of values) {
    const rows = zuhArrayText(value).filter((item) => String(item || "").trim());
    if (rows.length) return rows;
  }
  return [];
}
function zuiR2ObjectArrayValue(...values) {
  for (const value of values) {
    if (Array.isArray(value) && value.length) return value.map((item) => zucIsObject(item) ? { ...item } : item);
    if (zucIsObject(value) && Object.keys(value).length) return [{ ...value }];
  }
  return [];
}
function zuiR2Execution(raw = {}) {
  const e = zucIsObject(raw.execution) ? raw.execution : raw;
  return {
    timing: zudSafeText(zucFirst(e.timing, raw.timing, raw.trigger), "Timing is not supplied by the package."),
    cost: zudSafeText(zucFirst(e.cost, raw.cost, raw.cp_cost, raw.final_cp_cost), "No separate cost is stated."),
    range: zudSafeText(zucFirst(e.range, raw.range), "Self or as stated by the fixed expression."),
    target: zudSafeText(zucFirst(e.target, raw.target), "As stated by the fixed expression."),
    roll_save_check: zudSafeText(zucFirst(e.roll_save_check, raw.roll_save_check, raw.roll_or_save), "No separate roll is stated."),
    effect: zudSafeText(zucFirst(e.effect, raw.effect, raw.success_effect), "Effect text is missing."),
    failure: zudSafeText(zucFirst(e.failure, raw.failure, raw.failure_or_limit), "No separate failure effect is stated."),
    duration: zudSafeText(zucFirst(e.duration, raw.duration), "Instantaneous unless the fixed expression states otherwise."),
    limit: zudSafeText(zucFirst(e.limit, raw.limit, raw.limits), "No additional limit is stated."),
    counterplay: zudSafeText(zucFirst(e.counterplay, raw.counterplay), "Normal defenses and interruption rules apply.")
  };
}
function zuiR2ForgedRecord(raw = {}, index = 0) {
  const e = zuiR2Execution(raw);
  return {
    forged_id: zudSafeText(zucFirst(raw.forged_id, raw.technique_id, raw.id), `FGT_${index + 1}`),
    action_id: zudSafeText(zucFirst(raw.action_id, raw.linked_action_id), ""),
    name: zudSafeText(zucFirst(raw.name, raw.display_name, raw.technique_name, raw.forged_technique_name), `Forged Technique ${index + 1}`),
    status: zudSafeText(zucFirst(raw.status, "learned"), "learned"),
    cl_learned: zucNum(zucFirst(raw.cl_learned, raw.gained_at_cl, raw.CL), null),
    realm: zudSafeText(zucFirst(raw.realm, raw.realm_learned), ""),
    creator: zudSafeText(zucFirst(raw.creator, raw.created_by), ""),
    learner: zudSafeText(zucFirst(raw.learner, raw.owner), ""),
    base_form: zudSafeText(zucFirst(raw.base_form, raw.form), ""),
    primary_sphere: zudSafeText(zucFirst(raw.primary_sphere, raw.primary_effect_sphere), ""),
    secondary_spheres: zuiR2ArrayValue(raw.secondary_spheres, raw.additional_spheres),
    component_grant_ids: zuiR2ArrayValue(raw.component_grant_ids, raw.component_ids, raw.components),
    component_action_ids: zuiR2ArrayValue(raw.component_action_ids, raw.linked_action_ids),
    augments: zuiR2ObjectArrayValue(raw.augments),
    drawbacks: zuiR2ObjectArrayValue(raw.drawbacks),
    final_complexity: zucNum(zucFirst(raw.final_complexity, raw.complexity), null),
    final_cp_cost: zucNum(zucFirst(raw.final_cp_cost, raw.cp_cost), null),
    forging_dc: zucNum(raw.forging_dc, null),
    allocation_id: zudSafeText(zucFirst(raw.allocation_id, raw.acquisition_event_id), ""),
    research_material_history: zudSafeText(zucFirst(raw.research_material_history, raw.research_history, raw.materials), ""),
    source_packet_ids: zuiR2ArrayValue(raw.source_packet_ids, raw.source_packet_id),
    ...e,
    raw
  };
}
function zuiR2PreservedRecord(raw = {}, index = 0) {
  const e = zuiR2Execution(raw);
  return {
    expression_id: zudSafeText(zucFirst(raw.expression_id, raw.preserved_expression_id, raw.id), `PFX_${index + 1}`),
    name: zudSafeText(zucFirst(raw.name, raw.display_name, raw.technique_name), `Preserved Forged Expression ${index + 1}`),
    status: zudSafeText(zucFirst(raw.status, "preserved_recorded_art_expression"), "preserved_recorded_art_expression"),
    source_recorded_art_id: zudSafeText(zucFirst(raw.source_recorded_art_id, raw.manual_technique_id, raw.recorded_art_id), ""),
    recorded_art_name: zudSafeText(zucFirst(raw.recorded_art_name, raw.technique_name), ""),
    manual_name: zudSafeText(raw.manual_name, ""),
    linked_action_id: zudSafeText(zucFirst(raw.linked_action_id, raw.action_id), ""),
    base_form: zudSafeText(zucFirst(raw.base_form, raw.form), ""),
    primary_sphere: zudSafeText(raw.primary_sphere, ""),
    secondary_spheres: zuiR2ArrayValue(raw.secondary_spheres),
    component_grant_ids: zuiR2ArrayValue(raw.component_grant_ids, raw.components),
    complexity: zucNum(zucFirst(raw.complexity, raw.final_complexity), null),
    cp_cost: zucNum(zucFirst(raw.cp_cost, raw.final_cp_cost), null),
    counts_against_personal_forged_limit: Boolean(raw.counts_against_personal_forged_limit),
    learned_as_personal_technique: Boolean(raw.learned_as_personal_technique),
    learnable_separately: Boolean(raw.learnable_separately),
    preservation_note: zudSafeText(zucFirst(raw.preservation_note, raw.note), "This expression remains part of its Recorded Art and does not consume a personal Forged Technique slot."),
    allocation_id: zudSafeText(raw.allocation_id, ""),
    source_packet_ids: zuiR2ArrayValue(raw.source_packet_ids, raw.source_packet_id),
    ...e,
    raw
  };
}
function zuiR2SeedRecord(raw = {}, index = 0) {
  return {
    seed_id: zudSafeText(zucFirst(raw.seed_id, raw.id), `SEED_${index + 1}`),
    name: zudSafeText(zucFirst(raw.name, raw.display_name), `Emergency Technique Seed ${index + 1}`),
    exact_expression: zudSafeText(zucFirst(raw.exact_expression, raw.expression, raw.summary), "Expression text missing."),
    component_spheres: zuiR2ArrayValue(raw.component_spheres, raw.spheres),
    created_at_cl: zucNum(zucFirst(raw.created_at_cl, raw.CL), null),
    event: zudSafeText(zucFirst(raw.event, raw.encounter, raw.acquisition_reason), ""),
    later_study_benefit: zudSafeText(zucFirst(raw.later_study_benefit, raw.study_benefit), ""),
    converted_to_learned: Boolean(raw.converted_to_learned),
    learned_forged_id: zudSafeText(zucFirst(raw.learned_forged_id, raw.converted_forged_id), "")
  };
}
function zuiR2RepairForged(model = {}, pkg = {}) {
  const file = zuiR2FindJson(pkg, ["Forged_Techniques.json"], [/Forged_Techniques/i, /Forged_Technique_Registry/i]);
  const surface = zuiR2FindJson(pkg, ["Character_Import_Surface.json"], [/Character_Import_Surface/i]);
  const master = zuiR2FindJson(pkg, ["Character_Master_Ledger.json"], [/Character_Master_Ledger/i]);
  const direct = Array.isArray(model.forged_techniques) ? model.forged_techniques : [];
  const rows = zuiFirstArray(file, ["forged_techniques", "learned_forged_techniques", "installed_forged_techniques", "techniques", "entries"]);
  const surfaceRows = zuiFirstArray(surface, ["forged_techniques", "learned_forged_techniques"]);
  const masterRows = zuiFirstArray(master, ["forged_techniques"]);
  const selected = rows.length ? rows : surfaceRows.length ? surfaceRows : masterRows.length ? masterRows : direct;
  model.forged_techniques = selected.map(zuiR2ForgedRecord);
  const explicitNone = zucFirst(file.none_state, file.forged_techniques_none_state, surface.forged_techniques_none_state, master.forged_techniques_none_state, model.forged_techniques_none_state);
  model.forged_techniques_none_state = zucIsObject(explicitNone) ? explicitNone : { status: "none_acquired", reason: "No learned Forged Techniques are recorded for this character." };
  const preservedFile = zuiR2FindJson(pkg, ["Preserved_Forged_Expressions.json"], [/Preserved_Forged_Expressions/i]);
  const manualFile = zuiR2FindJson(pkg, ["Martial_Arts_and_Manuals.json"], [/Martial_Arts_and_Manuals/i]);
  const preservedRows = zuiFirstArray(preservedFile, ["preserved_forged_expressions", "expressions", "entries"]);
  const forgedPreservedRows = zuiFirstArray(file, ["preserved_forged_expressions"]);
  const manualPreservedRows = zuiFirstArray(manualFile, ["preserved_forged_expressions"]);
  const surfacePreservedRows = zuiFirstArray(surface, ["preserved_forged_expressions"]);
  const masterManualRows = zuiFirstArray(master, ["recorded_arts"]);
  const masterPreservedRows = [
    ...zuiFirstArray(master, ["preserved_forged_expressions"]),
    ...masterManualRows.map((row) => row?.preserved_forged_expression).filter((row) => zucIsObject(row))
  ];
  const directPreservedRows = Array.isArray(model.preserved_forged_expressions) ? model.preserved_forged_expressions : [];
  const selectedPreserved = preservedRows.length ? preservedRows : forgedPreservedRows.length ? forgedPreservedRows : manualPreservedRows.length ? manualPreservedRows : surfacePreservedRows.length ? surfacePreservedRows : masterPreservedRows.length ? masterPreservedRows : directPreservedRows;
  model.preserved_forged_expressions = selectedPreserved.map(zuiR2PreservedRecord);
  const seedFile = zuiR2FindJson(pkg, ["Emergency_Technique_Seeds.json"], [/Emergency_Technique_Seeds/i]);
  const seedRows = zuiFirstArray(seedFile, ["emergency_technique_seeds", "seeds", "entries"]);
  const surfaceSeeds = zuiFirstArray(surface, ["emergency_technique_seeds"]);
  const masterSeeds = zuiFirstArray(master, ["emergency_technique_seeds"]);
  model.emergency_technique_seeds = (seedRows.length ? seedRows : surfaceSeeds.length ? surfaceSeeds : masterSeeds.length ? masterSeeds : (model.emergency_technique_seeds || [])).map(zuiR2SeedRecord);
  model.diagnostics ||= [];
  model.diagnostics = model.diagnostics.filter((d) => !/FORGED.*MISSING|FORGED.*NOT_RECORDED|ZUI_R2_FORGED_TAB_READY/i.test(`${d.code || ""} ${d.message || ""}`));
  model.diagnostics.push({ severity: "info", code: "ZUI_R2_FORGED_TAB_READY", message: `${model.forged_techniques.length} learned Forged Techniques, ${model.preserved_forged_expressions.length} preserved Recorded Art expressions, and ${model.emergency_technique_seeds.length} Emergency Technique Seeds normalized.`, source: "Forged_Techniques.json / Preserved_Forged_Expressions.json / Emergency_Technique_Seeds.json", facet: "forged-techniques" });
  // Compact-save reloads may re-run the inherited visibility adapters. Keep one
  // diagnostic per actual finding so the Diagnostics tab remains stable.
  const diagnosticKeys = new Set();
  model.diagnostics = model.diagnostics.filter((d) => {
    const key = [d?.code || "", d?.message || "", d?.source || "", d?.tab || d?.facet || ""].join("|");
    if (diagnosticKeys.has(key)) return false;
    diagnosticKeys.add(key);
    return true;
  });
  model.patch = ZUI_R2_PATCH_ID; model.renderer_patch = ZUI_R2_PATCH_ID;
  return model;
}

function zuiR2SourceText(raw = {}, fallback = "Character Master Ledger") {
  if (raw.source) return zudSafeText(raw.source, fallback);
  const refs = zuhArrayText(raw.source_packet_ids || raw.source_packet_id);
  const cl = zucFirst(raw.gained_at_CL, raw.gained_at_cl);
  return [cl ? `CL ${cl}` : "", refs.length ? `Rules packet${refs.length === 1 ? "" : "s"}: ${refs.join(", ")}` : ""].filter(Boolean).join(" · ") || fallback;
}
function zuiR2ExplicitList(value, emptyText = "None specified.") {
  const rows = zuhArrayText(value).filter((x) => String(x).trim());
  return rows.length ? rows : [emptyText];
}
function zuiR2ImmortalActionRecord(raw = {}, index = 0) {
  return {
    ...raw,
    action_id: zudSafeText(zucFirst(raw.action_id, raw.id), `IA_ACTION_${index + 1}`),
    name: zudSafeText(zucFirst(raw.name, raw.display_name, raw.action_name), `Immortal technique ${index + 1}`),
    economy: zudSafeText(zucFirst(raw.economy, raw.action_type, raw.bucket), "Action"),
    action_type: zudSafeText(zucFirst(raw.action_type, raw.economy, raw.bucket), "Action"),
    timing: zudSafeText(raw.timing, "Use at the printed timing."),
    cost: zudSafeText(raw.cost, "No cost recorded."),
    range: zudSafeText(raw.range, "Range not recorded."),
    target: zudSafeText(raw.target, "Target not recorded."),
    roll_or_save: zudSafeText(zucFirst(raw.roll_or_save, raw.roll_save_check), "No roll or save recorded."),
    effect: zudSafeText(zucFirst(raw.effect, raw.success_effect), "Effect not recorded."),
    failure: zudSafeText(zucFirst(raw.failure, raw.failure_or_limit), "No separate failure effect."),
    duration: zudSafeText(raw.duration, "Instantaneous or as printed."),
    limit: zudSafeText(raw.limit, "No additional limit recorded."),
    counterplay: zudSafeText(raw.counterplay, "Use the printed defenses and counterplay."),
    creates_states: zuiR2ArrayValue(raw.creates_states),
    consumes_states: zuiR2ArrayValue(raw.consumes_states),
    source_spheres: zuiR2ArrayValue(raw.source_spheres),
    source_talents: zuiR2ArrayValue(raw.source_talents),
    source_packet_ids: zuiR2ArrayValue(raw.source_packet_ids, raw.source_packet_id),
    immortal_art_id: zudSafeText(raw.immortal_art_id, "")
  };
}
function zuiR2ImmortalRecord(raw = {}, index = 0) {
  return {
    ...raw,
    immortal_art_id: zudSafeText(zucFirst(raw.immortal_art_id, raw.id), `IA_${index + 1}`),
    name: zudSafeText(zucFirst(raw.name, raw.display_name), `Immortal Art ${index + 1}`),
    dao_aspect: zudSafeText(raw.dao_aspect, "Dao Aspect recorded in the source profile."),
    status: zudSafeText(raw.status, "Learned"),
    gained_at_cl: zucNum(zucFirst(raw.gained_at_cl, raw.CL), null),
    evolution_state: zudSafeText(raw.evolution_state, "Current expression"),
    action_ids: zuiR2ArrayValue(raw.action_ids, raw.linked_action_ids),
    linked_action_details: zuiFirstArray(raw, ["linked_action_details", "execution_actions", "action_packets"]).map(zuiR2ImmortalActionRecord),
    limitations: zuiR2ArrayValue(raw.limitations),
    behavior_hooks: zuiR2ArrayValue(raw.behavior_hooks),
    source_packet_ids: zuiR2ArrayValue(raw.source_packet_ids, raw.source_packet_id),
    execution_summary: zudSafeText(raw.execution_summary, "Use only the linked executable action cards and listed limitations."),
    acquisition_record: zudSafeText(raw.acquisition_record, "Acquisition recorded in the canonical ledger.")
  };
}
function zuiR2RepairImmortalArts(model = {}, pkg = {}) {
  const file = zuiR2FindJson(pkg, ["Immortal_Arts.json"], [/Immortal_Arts/i]);
  const surface = zuiR2FindJson(pkg, ["Character_Import_Surface.json"], [/Character_Import_Surface/i]);
  const master = zuiR2FindJson(pkg, ["Character_Master_Ledger.json"], [/Character_Master_Ledger/i]);
  const fileRows = zuiFirstArray(file, ["immortal_arts", "arts", "entries"]);
  const surfaceRows = zuiFirstArray(surface, ["immortal_arts"]);
  const masterRows = zuiFirstArray(master, ["immortal_arts"]);
  const directRows = Array.isArray(model.immortal_arts) ? model.immortal_arts : [];
  const selected = fileRows.length ? fileRows : surfaceRows.length ? surfaceRows : masterRows.length ? masterRows : directRows;
  const actionMap = new Map((model.actions || []).map((row) => [row.action_id, row]));
  model.immortal_arts = selected.map((raw, index) => {
    const art = zuiR2ImmortalRecord(raw, index);
    const embedded = zuiFirstArray(raw, ["linked_action_details", "execution_actions", "action_packets"]);
    const resolved = embedded.length ? embedded : art.action_ids.map((aid) => actionMap.get(aid)).filter(Boolean);
    art.linked_action_details = resolved.map(zuiR2ImmortalActionRecord);
    art.unresolved_action_ids = art.action_ids.filter((aid) => !art.linked_action_details.some((row) => row.action_id === aid));
    return art;
  });
  const none = zucFirst(file.none_state, file.immortal_arts_none_state, surface.immortal_arts_none_state, master.immortal_arts_none_state, model.immortal_arts_none_state);
  model.immortal_arts_none_state = zucIsObject(none) ? none : { status: "none_acquired", reason: "No Immortal Arts are recorded for this character." };
  model.diagnostics ||= [];
  model.diagnostics = model.diagnostics.filter((d) => !/ZUI_R2_IMMORTAL_ART_TAB_READY/i.test(`${d.code || ""} ${d.message || ""}`));
  model.diagnostics.push({ severity: "info", code: "ZUI_R2_IMMORTAL_ART_TAB_READY", message: `${model.immortal_arts.length} Immortal Arts normalized with ${model.immortal_arts.reduce((n, art) => n + art.linked_action_details.length, 0)} executable technique packet(s).`, source: "Immortal_Arts.json", facet: "immortal-arts" });
  model.immortal_arts.forEach((art) => { if (art.unresolved_action_ids.length) model.diagnostics.push({ severity: "error", code: "ZUI_R2_IMMORTAL_ACTION_UNRESOLVED", message: `${art.name}: unresolved linked action IDs ${art.unresolved_action_ids.join(", ")}.`, source: "Immortal_Arts.json", facet: "immortal-arts" }); });
  return model;
}
function zuiR2AuditRecordedArtClassification(model = {}, pkg = {}) {
  const file = zuiR2FindJson(pkg, ["Martial_Arts_and_Manuals.json"], [/Martial_Arts_and_Manuals/i]);
  const master = zuiR2FindJson(pkg, ["Character_Master_Ledger.json"], [/Character_Master_Ledger/i]);
  const fileRows = zuiFirstArray(file, ["recorded_arts", "manuals", "entries"]);
  const rawRows = fileRows.length ? fileRows : zuiFirstArray(master, ["recorded_arts"]);
  const byId = new Map(rawRows.map((row, index) => [zudSafeText(zucFirst(row.recorded_art_id, row.art_id, row.id), `RECORDED_ART_${index + 1}`), row]));
  (model.martial_manuals || []).forEach((row, index) => {
    const id = row.recorded_art_id || `RECORDED_ART_${index + 1}`;
    const raw = byId.get(id) || rawRows[index] || {};
    row.recorded_art_id = id;
    row.expression_kind = zudSafeText(raw.expression_kind, row.expression_kind || "unclassified");
    row.custom_design = raw.custom_design === true;
    row.preserved_forged_expression = zucIsObject(raw.preserved_forged_expression) ? raw.preserved_forged_expression : null;
    row.source_packet_ids = zuiR2ArrayValue(raw.source_packet_ids, raw.source_packet_id, row.source_packet_ids);
  });
  model.diagnostics ||= [];
  model.diagnostics = model.diagnostics.filter((d) => !/ZUI_R2_RECORDED_ART_EXPRESSION_/i.test(`${d.code || ""}`));
  (model.martial_manuals || []).forEach((row) => {
    const multiSphere = (row.source_spheres || []).length > 1;
    if (row.custom_design && multiSphere && row.expression_kind !== "preserved_forged_expression") {
      model.diagnostics.push({ severity: "error", code: "ZUI_R2_RECORDED_ART_EXPRESSION_UNCLASSIFIED", message: `${row.technique_name}: custom multi-Sphere Recorded Art must be rebuilt as a preserved Forged expression or simplified to one Sphere.`, source: "Martial_Arts_and_Manuals.json", facet: "martial-manuals-recorded-arts" });
    } else if (row.expression_kind === "source_authored_lineage_expression" && row.custom_design) {
      model.diagnostics.push({ severity: "error", code: "ZUI_R2_RECORDED_ART_EXPRESSION_SOURCE_CONFLICT", message: `${row.technique_name}: source-authored lineage expressions cannot be marked custom_design.`, source: "Martial_Arts_and_Manuals.json", facet: "martial-manuals-recorded-arts" });
    }
  });
  return model;
}
function zuiR2RepairCanonical(model = {}, pkg = {}) {
  model = zuiR2RepairImmortalArts(zuiR2RepairForged(model, pkg), pkg);
  const master = zuiR2FindJson(pkg, ["Character_Master_Ledger.json"], [/Character_Master_Ledger/i]);
  const backgroundFile = zuiR2FindJson(pkg, ["Background_Origin_Ledger.json"], [/Background_Origin_Ledger/i]);
  const bo = zucIsObject(backgroundFile) && Object.keys(backgroundFile).length ? backgroundFile : (master.background_origin || model.background_origin || {});
  if (zucIsObject(bo.background)) {
    model.background_origin ||= {};
    model.background_origin.background = {
      ...bo.background,
      compensation: zudSafeText(bo.background.compensation, "None required; the normal Background package is used."),
      skill_proficiencies: zuiR2ArrayValue(bo.background.skill_proficiencies),
      tool_proficiencies: zuiR2ArrayValue(bo.background.tool_proficiencies),
      languages: zuiR2ArrayValue(bo.background.languages),
      equipment_reconciliation: zucIsObject(bo.background.equipment_reconciliation) ? bo.background.equipment_reconciliation : {},
      source: zuiR2SourceText(bo.background)
    };
  }
  if (zucIsObject(bo.origin_insight)) {
    model.background_origin ||= {};
    model.background_origin.origin_insight = {
      ...bo.origin_insight,
      effect_records: Array.isArray(bo.origin_insight.effect_records) ? bo.origin_insight.effect_records : [],
      counts_against_background: Boolean(bo.origin_insight.counts_against_background),
      counts_against_level_talent: Boolean(bo.origin_insight.counts_against_level_talent),
      counts_against_trained_choices: Boolean(bo.origin_insight.counts_against_trained_choices),
      source: zuiR2SourceText(bo.origin_insight)
    };
  }

  const sphereFile = zuiR2FindJson(pkg, ["Selected_Spheres.json"], [/Selected_Spheres/i]);
  const talentFile = zuiR2FindJson(pkg, ["Talent_Source_Ledger.json"], [/Talent_Source_Ledger/i]);
  const sphereRows = zuiFirstArray(sphereFile, ["spheres"]).length ? zuiFirstArray(sphereFile, ["spheres"]) : zuiFirstArray(master, ["spheres"]);
  const talentRows = zuiFirstArray(talentFile, ["talents"]).length ? zuiFirstArray(talentFile, ["talents"]) : zuiFirstArray(master, ["talents"]);
  const sphereCoverageFile = zuiR2FindJson(pkg, ["Sphere_Execution_Coverage.json"], [/Sphere_Execution_Coverage/i]);
  const talentCoverageFile = zuiR2FindJson(pkg, ["Talent_Execution_Coverage.json"], [/Talent_Execution_Coverage/i]);
  const sphereCoverageRows = zuiFirstArray(sphereFile, ["execution_coverage"]).length ? zuiFirstArray(sphereFile, ["execution_coverage"]) : (zuiFirstArray(sphereCoverageFile, ["execution_coverage", "sphere_execution_coverage", "coverage"]).length ? zuiFirstArray(sphereCoverageFile, ["execution_coverage", "sphere_execution_coverage", "coverage"]) : zuiFirstArray(master, ["sphere_execution_coverage"]));
  const talentCoverageRows = zuiFirstArray(talentFile, ["execution_coverage"]).length ? zuiFirstArray(talentFile, ["execution_coverage"]) : (zuiFirstArray(talentCoverageFile, ["execution_coverage", "talent_execution_coverage", "coverage"]).length ? zuiFirstArray(talentCoverageFile, ["execution_coverage", "talent_execution_coverage", "coverage"]) : zuiFirstArray(master, ["talent_execution_coverage"]));
  const sphereCoverageById = new Map(sphereCoverageRows.map((row) => [String(zucFirst(row.source_id, row.sphere_id, row.id) || ""), row]));
  const talentCoverageById = new Map(talentCoverageRows.map((row) => [String(zucFirst(row.source_id, row.talent_id, row.id) || ""), row]));
  model.spheres_talents ||= {};
  if (sphereRows.length) model.spheres_talents.spheres = sphereRows.map((row) => ({ ...row, name: zudSafeText(zucFirst(row.name, row.display_name), "Unnamed Sphere"), execution_coverage: zucIsObject(row.execution_coverage) && Object.keys(row.execution_coverage).length ? row.execution_coverage : (sphereCoverageById.get(String(row.sphere_id || row.id || "")) || {}), source: zuiR2SourceText(row) }));
  if (talentRows.length) model.spheres_talents.talents = talentRows.map((row) => ({
    ...row,
    name: zudSafeText(zucFirst(row.name, row.talent_name, row.display_name), "Unnamed Talent"),
    sphere: zudSafeText(row.sphere, "Sphere not identified"),
    source_type: zudSafeText(zucFirst(row.source_type, row.acquisition_type), "Acquisition recorded in master ledger"),
    gained_at_CL: zucNum(zucFirst(row.gained_at_CL, row.gained_at_cl), null),
    effect: zudSafeText(zucFirst(row.effect, row.mechanical_summary), "See the authoritative rules packet."),
    execution_coverage: zucIsObject(row.execution_coverage) && Object.keys(row.execution_coverage).length ? row.execution_coverage : (talentCoverageById.get(String(row.talent_id || row.id || "")) || {}),
    source: zuiR2SourceText(row)
  }));

  const methodFile = zuiR2FindJson(pkg, ["Cultivation_Method_Profile.json"], [/Cultivation_Method_Profile/i]);
  if (zucIsObject(methodFile) && Object.keys(methodFile).length && !/none/i.test(String(methodFile.status || ""))) {
    const resource = zucIsObject(methodFile.resource_shape) ? methodFile.resource_shape : {};
    const mechanical = zuiR2ExplicitList(zucFirst(methodFile.mechanical_effects, methodFile.benefits, methodFile.mechanical_hooks), "No additional mechanical effects beyond the stated method profile.");
    const applied = zuiR2ExplicitList(methodFile.applied_math, resource.final_primary_resource_max !== undefined ? `${zudSafeText(resource.applied_to, "Primary resource")} maximum: ${resource.final_primary_resource_max}` : "No numeric modifier beyond the stated resource formula.");
    model.method = {
      ...methodFile,
      name: zudSafeText(zucFirst(methodFile.method_name, methodFile.name), "Cultivation method"),
      status: zudSafeText(zucFirst(methodFile.status, "Active primary method"), "Active primary method"),
      resource_shape: [zudSafeText(zucFirst(resource.name, methodFile.resource_name), "Resource"), zudSafeText(zucFirst(resource.formula, methodFile.resource_formula, resource.effect), "Formula recorded in method")].filter(Boolean).join(" · "),
      source: zudSafeText(methodFile.source, "Cultivation_Method_Profile.json"),
      mechanical_effects: mechanical,
      applied_math: applied,
      stacking_statement: zudSafeText(methodFile.stacking_statement, "Printed Method, Foundation, and item modifiers stack when each source explicitly grants them; only multiple primary Methods are mutually exclusive."),
      resource_modifiers: zuiR2ArrayValue(methodFile.resource_modifiers),
      breakthrough_shape: zudSafeText(methodFile.breakthrough_shape, "Breakthrough follows the method's stated circulation discipline."),
      foundation_compatibility: zuiR2ExplicitList(zucFirst(methodFile.foundation_compatibility, methodFile.foundation_shape?.foundation_compatibility), "No special Foundation interaction beyond the listed method effects."),
      incompatibilities: zuiR2ExplicitList(methodFile.incompatibilities, "No additional incompatibilities are recorded.")
    };
  }

  const foundationFile = zuiR2FindJson(pkg, ["Foundation_Detail_Ledger.json"], [/Foundation_Detail_Ledger/i]);
  if (zucIsObject(foundationFile) && Object.keys(foundationFile).length && !/none/i.test(String(foundationFile.status || ""))) {
    const r = zucIsObject(foundationFile.foundation_resource) ? foundationFile.foundation_resource : {};
    const counter = r.name ? `${r.name} ${r.current ?? "—"}/${r.max ?? "—"} · ${zudSafeText(r.generation, "Generation rule recorded in the Foundation profile.")}` : "No separate Foundation counter.";
    model.foundation = {
      ...foundationFile,
      name: zudSafeText(zucFirst(foundationFile.name, foundationFile.chosen_foundation), "Foundation"),
      grade: zudSafeText(foundationFile.grade, "Grade recorded in source"),
      status_stage: zudSafeText(zucFirst(foundationFile.status_stage, foundationFile.stage), "Stage recorded in source"),
      source: zudSafeText(foundationFile.source, "Foundation_Detail_Ledger.json"),
      benefits: zuiR2ExplicitList(foundationFile.benefits, "No benefits recorded."),
      passive_chassis: zuiR2ExplicitList(zucFirst(foundationFile.passive_chassis, foundationFile.benefits), "No additional passive chassis beyond the prominent benefits."),
      resources_counters: zuiR2ExplicitList(zucFirst(foundationFile.resources_counters, r.name ? [counter] : []), "No separate Foundation counter."),
      actions_riders: zuiR2ExplicitList(zucFirst(foundationFile.actions_riders, foundationFile.actions), "No separate Foundation action or rider."),
      fixed_scope: zuiR2ExplicitList(foundationFile.fixed_scope, "Only the explicitly listed Foundation effects apply."),
      stage_benefit_map: Array.isArray(foundationFile.stage_benefit_map) ? foundationFile.stage_benefit_map : (zucIsObject(foundationFile.stage_benefit_map) ? foundationFile.stage_benefit_map : {}),
      primary_resource_modifiers: zuiR2ArrayValue(foundationFile.primary_resource_modifiers),
      lifecycle_coverage: zucIsObject(foundationFile.lifecycle_coverage) ? foundationFile.lifecycle_coverage : {},
      burdens_strains_deviations: zuiR2ExplicitList(zucFirst(foundationFile.burdens_strains_deviations, foundationFile.burdens), "No additional burden beyond the stated Foundation profile."),
      suppressed_or_excluded_benefits: zuiR2ArrayValue(foundationFile.suppressed_or_excluded_benefits),
      ai_notes: zuiR2ExplicitList(foundationFile.ai_notes, "Use the Foundation only within its fixed scope.")
    };
  }

  const daoFile = zuiR2FindJson(pkg, ["Dao_IChing_Combat_Profile.json"], [/Dao_IChing_Combat_Profile/i]);
  if (zucIsObject(daoFile) && Object.keys(daoFile).length) {
    const d = zucIsObject(daoFile.dao) ? daoFile.dao : daoFile;
    const y = zucIsObject(daoFile.i_ching) ? daoFile.i_ching : {};
    model.dao_i_ching = {
      dao: {
        dao_phrase: zudSafeText(zucFirst(d.dao_phrase, daoFile.dao_phrase), "Dao phrase recorded in source profile."),
        combat_doctrine: zudSafeText(d.combat_doctrine, "Follow the character's authored combat doctrine."),
        resource_policy: zudSafeText(d.resource_policy, "Follow the authored resource reserve policy."),
        reaction_policy: zudSafeText(d.reaction_policy, "Use reactions according to their legal triggers and authored priorities."),
        ai_turn_prompt: zudSafeText(d.ai_turn_prompt, "Evaluate the battlefield before selecting a legal action."),
        preferred_engagements: zuiR2ExplicitList(d.preferred_engagements, "No special preferred engagement."),
        avoidance_rules: zuiR2ExplicitList(d.avoidance_rules, "Avoid illegal or self-defeating actions."),
        risk_thresholds: zuiR2ExplicitList(d.risk_thresholds, "Use the authored resource and positioning thresholds."),
        target_selection_logic: zuiR2ExplicitList(d.target_selection_logic, "Select the most tactically relevant legal target."),
        failure_recovery: zuiR2ExplicitList(d.failure_recovery, "Return to the default legal composite or basic action plan."),
        forbidden_behaviors: zuiR2ExplicitList(d.forbidden_behaviors, "Never violate action economy or invent unrecorded abilities."),
        composite_hooks: zuiR2ExplicitList(d.composite_hooks, "Use composites only when their prerequisites and timing are satisfied.")
      },
      i_ching: {
        enabled: y.enabled !== false && Object.keys(y).length > 0,
        reading_name: zudSafeText(y.reading_name, "I Ching combat reading"),
        hexagram_or_trigram: zudSafeText(y.hexagram_or_trigram, "Reading recorded in source profile"),
        natural_tendency: zudSafeText(y.natural_tendency, "Follow the natural tendency recorded in the profile."),
        testing_tendency: zudSafeText(y.testing_tendency, "Watch for the testing tendency recorded in the profile."),
        shift_triggers: zuiR2ExplicitList(y.shift_triggers, "Shift only when battlefield state materially changes."),
        low_resource_shift: zudSafeText(y.low_resource_shift, "Preserve resources and use lower-cost legal actions."),
        combat_state_interpretation: zudSafeText(y.combat_state_interpretation, "Interpret changes through the authored combat reading."),
        gm_generation_instruction: zudSafeText(y.gm_generation_instruction, "Do not invent abilities; vary priorities within the recorded kit."),
        composite_hooks: zuiR2ExplicitList(y.composite_hooks, "Use the reading to choose among recorded composites.")
      }
    };
  }

  // Re-run the full-row composite adapter after actions and canonical files are loaded.
  model = zuiNormalizeCompositesAllRows(model, pkg);
  model.composites = (model.composites || []).map((c) => ({
    ...c,
    economy_footprint: zuiR2ExplicitList(c.economy_footprint, "Economy is listed on each component step."),
    temporal_feasibility: {
      ...(zucIsObject(c.temporal_feasibility) ? c.temporal_feasibility : {}),
      round_segmentation: zudSafeText(zucFirst(c.temporal_feasibility?.round_segmentation, c.temporal_feasibility), "Use the authored step timing in order."),
      synthesized: false,
      source: "Composite_Playbook.json"
    },
    linked_actions: (() => {
      const seen = new Set();
      return (c.linked_actions || []).filter((a) => { const key = String(a?.action_id || a?.name || ""); if (!key || seen.has(key)) return false; seen.add(key); return true; });
    })(),
    sequence: (c.sequence || []).map((step, index) => ({
      ...step,
      step: step.step ?? index + 1,
      timing: zudSafeText(step.timing, "Use the linked action's timing."),
      economy: zudSafeText(step.economy, "Use the linked action's economy."),
      action_name: zudSafeText(step.action_name, step.action_id || `Step ${index + 1}`),
      cost: zudSafeText(step.cost, "No additional cost beyond the linked action."),
      range: zudSafeText(step.range, "Use the linked action's range."),
      target: zudSafeText(step.target, "Use the linked action's target."),
      roll_or_save: zudSafeText(step.roll_or_save, "Use the linked action's roll or save."),
      success_effect: zudSafeText(step.success_effect, "Use the linked action's success effect."),
      failure_or_limit: zudSafeText(step.failure_or_limit, "Use the linked action's failure and limits."),
      duration: zudSafeText(step.duration, "Use the linked action's duration."),
      counterplay: zudSafeText(step.counterplay, "Use the linked action's counterplay."),
      resolved: true
    })),
    diagnostics: zuiR2ExplicitList(c.diagnostics, "All component actions resolved from the canonical action surface.")
  }));

  model.diagnostics = (model.diagnostics || []).filter((d) => {
    const code = String(d?.code || "");
    const message = String(d?.message || "");
    if (/NOT_RECORDED|MISSING|SYNTHESIZED/i.test(code)) return false;
    if (/\b1 CL rows\b|\b1 composite playbooks\b/i.test(message)) return false;
    return /ZUE_PRIMARY_RESOURCE_RESOLVED|ZUH_ABILITY_SCORES_VISIBLE|HF05ZVK_CANONICAL_PROJECTION_COMPLETE|ZUI_R2_FORGED_TAB_READY|ZUI_COMPOSITES_ALL_ROWS_VISIBLE|ZUI_RECORDED_ARTS_ALL_ROWS_VISIBLE|ZUI_LEVELING_ALL_ROWS_VISIBLE|ZUI_ARRAY_LEDGER_ROWS_PRESERVED/i.test(code);
  });
  model.diagnostics.push({ severity: "info", code: "ZUI_R2_CANONICAL_CONTRACT_READY", message: "Background, progression, Spheres, actions, composites, Forged Techniques, Recorded Arts, Foundation, Method, Dao/I Ching, equipment, resources, and states were normalized from authoritative factory surfaces.", source: "HF05ZVK-R1E / HF05ZUI-R2H", tab: "diagnostics" });
  const keys = new Set();
  model.diagnostics = model.diagnostics.filter((d) => { const key = `${d?.code}|${d?.message}|${d?.source}`; if (keys.has(key)) return false; keys.add(key); return true; });
  model = zuiR2AuditRecordedArtClassification(model, pkg);
  const blocking = (model.diagnostics || []).filter((d) => String(d.severity || "").toLowerCase() === "error");
  const warnings = (model.diagnostics || []).filter((d) => String(d.severity || "").toLowerCase() === "warning");
  model.validation = { verdict: blocking.length ? "FAIL_HF05ZUI_R2H_CANONICAL_CONSUMER_MODEL" : "PASS_HF05ZUI_R2H_CANONICAL_CONSUMER_MODEL", error_count: blocking.length, warning_count: warnings.length, patch: ZUI_R2_PATCH_ID };
  model.patch = ZUI_R2_PATCH_ID;
  model.renderer_patch = ZUI_R2_PATCH_ID;
  return model;
}
function zuiR2LevelValue(value, emptyText = "None this level") {
  if (Array.isArray(value)) return value.length ? value : [emptyText];
  if (value === undefined || value === null || String(value).trim() === "") return emptyText;
  return value;
}
function zuiR2RenderLeveling(model = {}) {
  const levels = model.leveling_ledger || [];
  const byRealm = {};
  levels.forEach((row) => { const realm = zudSafeText(row.realm, "Realm"); (byRealm[realm] ||= []).push(row); });
  const groups = Object.entries(byRealm).map(([realm, rows]) => `<section class="zud-realm-card"><h4>${escapeHtml(realm)}</h4><div class="zud-level-grid">${rows.map((r) => {
    const sphereBonus = [...(r.new_spheres_gained || []), ...(r.new_sphere_bonus_talents || [])];
    const origin = [...(r.background_grants || []), r.origin_insight].filter(Boolean);
    const methodFoundation = [r.method_event, r.foundation_event].filter(Boolean);
    return `<article class="zud-level-card"><header><strong>CL ${escapeHtml(r.CL ?? r.cl ?? "?")}</strong><span>PB ${escapeHtml(r.PB ?? r.pb ?? "?")}</span></header><div class="zud-level-fields">
      ${zudField("HP / Resource", `${r.hp_gain ?? "—"} HP / ${r.resource_max_after_level ?? "—"} max resource`, "Recorded in level row")}
      ${zudField("Free level talent", zuiR2LevelValue(r.free_level_talent))}
      ${zudField("New sphere + bonus", zuiR2LevelValue(sphereBonus))}
      ${zudField("Trained choices", r.trained_choices_text || `${(r.trained_choices || []).length}/3 used${(r.trained_choices || []).length ? ` · ${zucValueText(r.trained_choices, "")}` : ""}`, "0/3 used")}
      ${zudField("Background / Origin", zuiR2LevelValue(origin))}
      ${zudField("ASI / Cultivation Insight", zuiR2LevelValue(r.advancement_choice || r.advancement_choices))}
      ${zudField("Method / Foundation", zuiR2LevelValue(methodFoundation))}
      ${zudField("Manuals / Recorded Arts", zuiR2LevelValue(r.manuals_or_recorded_arts))}
      ${zudField("Forged", zuiR2LevelValue(r.forged_techniques))}
      ${zudField("Validation", zuiR2LevelValue(r.validation_notes, "Checkpoint sealed"))}
    </div></article>`;
  }).join("")}</div></section>`).join("");
  return `<div class="zud-tab-heading"><h3>Leveling Ledger</h3><p>Complete CL-by-CL advancement, allocation channels, HP, resource progression, and acquisition events.</p></div>${groups || `<p class="zud-muted">No leveling ledger was supplied.</p>`}`;
}

function zuiR2ListField(label, value, fallback = "None.") {
  return `<div class="zud-field zud-field-wide"><strong>${escapeHtml(label)}</strong>${zudBulletList(value, fallback)}</div>`;
}
function zuiR2Disclosure(title, body, { open = false, meta = "" } = {}) {
  const openAttr = open ? " open" : "";
  const metaHtml = meta ? `<span class="zui-r2-disclosure-meta">${escapeHtml(meta)}</span>` : "";
  return `<details class="zui-r2-disclosure"${openAttr}><summary><span>${escapeHtml(title)}</span>${metaHtml}</summary><div class="zui-r2-disclosure-body">${body}</div></details>`;
}
function zuiR2QuickMetric(label, value, fallback = "—") {
  return `<div class="zui-r2-quick-metric"><span>${escapeHtml(label)}</span><strong>${escapeHtml(zucValueText(value, fallback))}</strong></div>`;
}
function zuiR2ForgedCard(f = {}) {
  const componentText = [...(f.component_grant_ids || []), ...(f.component_action_ids || [])];
  const top = [f.status, f.realm, f.cl_learned ? `CL ${f.cl_learned}` : "", f.action_id].filter(Boolean).map((x) => zudBadge(x)).join("");
  const quick = `<div class="zui-r2-forged-quick">
    ${zuiR2QuickMetric("Form", f.base_form)}${zuiR2QuickMetric("Primary", f.primary_sphere)}${zuiR2QuickMetric("CP", f.final_cp_cost)}${zuiR2QuickMetric("Complexity", f.final_complexity)}${zuiR2QuickMetric("Forge DC", f.forging_dc)}
  </div>`;
  const execution = `<div class="zud-action-grid">
    ${zudField("Timing / Trigger", f.timing)}${zudField("Cost", f.cost)}${zudField("Range", f.range)}${zudField("Target", f.target)}${zudField("Roll / Save", f.roll_save_check)}
    ${zudFieldWide("Success / Effect", f.effect)}${zudFieldWide("Failure / Miss", f.failure)}${zudField("Duration", f.duration)}${zudField("Limit", f.limit)}${zudFieldWide("Counterplay", f.counterplay)}
  </div>`;
  const construction = `<div class="zud-action-grid">
    ${zudField("Base Form", f.base_form)}${zudField("Primary Sphere", f.primary_sphere)}${zudField("Secondary Spheres", f.secondary_spheres)}${zudField("Components", componentText)}
    ${zudField("Final Complexity", f.final_complexity)}${zudField("Final CP Cost", f.final_cp_cost)}${zudField("Forging DC", f.forging_dc)}${zudField("Allocation", f.allocation_id)}
  </div>`;
  const modifiers = `<div class="zud-action-grid">${zuiR2ListField("Augments", f.augments, "None.")}${zuiR2ListField("Drawbacks", f.drawbacks, "None.")}</div>`;
  const provenance = `<div class="zud-action-grid">${zudFieldWide("Research / Materials", f.research_material_history)}${zudFieldWide("Rule Sources", f.source_packet_ids)}</div>`;
  const sphereMeta = [f.primary_sphere, ...(f.secondary_spheres || [])].filter(Boolean).join(" + ");
  return `<article class="zud-action-card zui-r2-forged-card"><header><div><h5>${zudCleanText(f.name, "Unnamed Forged Technique")}</h5><p class="zui-r2-card-subtitle">${escapeHtml(sphereMeta || "Forged expression")}</p></div><div class="zud-badges">${top}</div></header>
    ${quick}
    <div class="zui-r2-nested-stack">
      ${zuiR2Disclosure("Execution", execution, { open: true, meta: f.action_type || f.timing || "" })}
      ${zuiR2Disclosure("Construction & legality", construction, { meta: `${zucValueText(f.final_complexity, "—")} complexity · ${zucValueText(f.final_cp_cost, "—")} CP` })}
      ${zuiR2Disclosure("Augments & drawbacks", modifiers, { meta: `${(f.augments || []).length} / ${(f.drawbacks || []).length}` })}
      ${zuiR2Disclosure("Research & provenance", provenance, { meta: `${(f.source_packet_ids || []).length} source packet(s)` })}
    </div></article>`;
}
function zuiR2PreservedCard(p = {}) {
  const slotStatus = p.counts_against_personal_forged_limit ? "Consumes personal slot" : "No personal slot";
  const learnedStatus = p.learned_as_personal_technique ? "Also learned personally" : "Preserved only";
  const quick = `<div class="zui-r2-forged-quick">
    ${zuiR2QuickMetric("Recorded Art", p.recorded_art_name || p.source_recorded_art_id)}${zuiR2QuickMetric("Form", p.base_form)}${zuiR2QuickMetric("CP", p.cp_cost)}${zuiR2QuickMetric("Complexity", p.complexity)}${zuiR2QuickMetric("Learnable", p.learnable_separately ? "Yes" : "No")}
  </div>`;
  const execution = `<div class="zud-action-grid">
    ${zudField("Timing / Trigger", p.timing)}${zudField("Cost", p.cost)}${zudField("Range", p.range)}${zudField("Target", p.target)}${zudField("Roll / Save", p.roll_save_check)}
    ${zudFieldWide("Success / Effect", p.effect)}${zudFieldWide("Failure / Miss", p.failure)}${zudField("Duration", p.duration)}${zudField("Limit", p.limit)}${zudFieldWide("Counterplay", p.counterplay)}
  </div>`;
  const identity = `<div class="zud-action-grid">
    ${zudField("Recorded Art", p.recorded_art_name || p.source_recorded_art_id)}${zudField("Manual", p.manual_name)}${zudField("Linked Action", p.linked_action_id)}${zudField("Status", learnedStatus)}
    ${zudField("Base Form", p.base_form)}${zudField("Primary Sphere", p.primary_sphere)}${zudField("Secondary Spheres", p.secondary_spheres)}${zudField("Components", p.component_grant_ids)}
    ${zudField("Complexity", p.complexity)}${zudField("CP Cost", p.cp_cost)}${zudField("Separately Learnable", p.learnable_separately ? "Yes" : "No")}${zudField("Allocation", p.allocation_id)}
  </div>`;
  const provenance = `<div class="zud-action-grid">${zudFieldWide("Preservation Rule", p.preservation_note)}${zudFieldWide("Rule Sources", p.source_packet_ids)}</div>`;
  return `<article class="zud-action-card zui-r2-preserved-card"><header><div><h5>${zudCleanText(p.name, "Unnamed Preserved Forged Expression")}</h5><p class="zui-r2-card-subtitle">Fixed inside ${escapeHtml(zucValueText(p.recorded_art_name || p.source_recorded_art_id, "a Recorded Art"))}</p></div><div class="zud-badges">${zudBadge("Recorded Art expression")}${zudBadge(slotStatus)}</div></header>
    ${quick}
    <div class="zui-r2-nested-stack">
      ${zuiR2Disclosure("Execution", execution, { open: true, meta: p.linked_action_id || "" })}
      ${zuiR2Disclosure("Identity & components", identity, { meta: learnedStatus })}
      ${zuiR2Disclosure("Preservation & provenance", provenance, { meta: `${(p.source_packet_ids || []).length} source packet(s)` })}
    </div></article>`;
}
function zuiR2SeedCard(s = {}) {
  const converted = s.converted_to_learned ? `Converted${s.learned_forged_id ? ` · ${s.learned_forged_id}` : ""}` : "Unconverted seed";
  const summary = `<div class="zui-r2-forged-quick zui-r2-seed-quick">${zuiR2QuickMetric("Created", s.created_at_cl ? `CL ${s.created_at_cl}` : "—")}${zuiR2QuickMetric("Spheres", s.component_spheres)}${zuiR2QuickMetric("Status", converted)}</div>`;
  const body = `<div class="zud-kv-grid">${zudField("Seed ID", s.seed_id)}${zudField("Component Spheres", s.component_spheres)}${zudField("Converted", converted)}${zudFieldWide("Exact Emergency Expression", s.exact_expression)}${zudFieldWide("Creation Event", s.event)}${zudFieldWide("Later Study Benefit", s.later_study_benefit)}</div>`;
  return `<article class="zud-info-card zui-r2-seed-card"><header><div><h5>${zudCleanText(s.name, "Unnamed Emergency Technique Seed")}</h5><p class="zui-r2-card-subtitle">A preserved result of successful Emergency Forging—not a learned personal technique.</p></div>${zudBadge(converted)}</header>${summary}<div class="zui-r2-nested-stack">${zuiR2Disclosure("Seed record", body, { open: false, meta: s.seed_id || "" })}</div></article>`;
}
function zuiR2RenderForged(model = {}) {
  const learned = model.forged_techniques || [];
  const preserved = model.preserved_forged_expressions || [];
  const seeds = model.emergency_technique_seeds || [];
  const noneReason = zudSafeText(model.forged_techniques_none_state?.reason, "No learned Forged Techniques are recorded for this character.");
  const learnedHtml = learned.length ? `<div class="zud-card-stack">${learned.map(zuiR2ForgedCard).join("")}</div>` : `<article class="zui-r2-empty-state"><strong>No learned Forged Techniques</strong><p>${escapeHtml(noneReason)}</p></article>`;
  const preservedHtml = preserved.length ? `<div class="zud-card-stack">${preserved.map(zuiR2PreservedCard).join("")}</div>` : `<p class="zud-muted">No preserved Forged expressions are recorded inside the character’s Recorded Arts.</p>`;
  const seedHtml = seeds.length ? `<div class="zud-card-stack">${seeds.map(zuiR2SeedCard).join("")}</div>` : `<p class="zud-muted">No Emergency Technique Seeds are recorded.</p>`;
  return `<div class="zud-tab-heading"><h3>Forged Techniques</h3><p>Core combat execution stays open; construction, modifiers, research, preserved expressions, and Emergency Seeds are nested so the tab remains readable without losing mechanical detail.</p></div>${zudSection(`Learned Forged Techniques (${learned.length})`, learnedHtml)}${zudSection(`Preserved Recorded Art Expressions (${preserved.length})`, preservedHtml)}${zudSection(`Emergency Technique Seeds (${seeds.length})`, seedHtml)}`;
}

const zuiR2TemporalTextBefore = zueTemporalText;
zueTemporalText = function zuiR2TemporalText(c = {}) {
  const tf = zucIsObject(c.temporal_feasibility) ? c.temporal_feasibility : {};
  const round = zudSafeText(zucFirst(tf.round_segmentation, c.temporal_feasibility_display, c.temporal_feasibility_summary), "Follow the authored component timing in order.");
  if (tf.synthesized === false || /Composite_Playbook\.json|Character_Master_Ledger/i.test(String(tf.source || ""))) return `Authored timing: ${round}`;
  return zuiR2TemporalTextBefore(c);
};
function zuiR2ImmortalActionCard(action = {}, index = 0) {
  const quick = `<div class="zui-r2-forged-quick">${zuiR2QuickMetric("Economy", action.economy)}${zuiR2QuickMetric("Cost", action.cost)}${zuiR2QuickMetric("Range", action.range)}${zuiR2QuickMetric("Action ID", action.action_id)}</div>`;
  const execution = `<div class="zud-action-grid">${zudField("Timing", action.timing)}${zudField("Cost", action.cost)}${zudField("Range", action.range)}${zudField("Target", action.target)}${zudField("Roll / Save", action.roll_or_save)}${zudFieldWide("What happens", action.effect)}${zudFieldWide("Failure / Successful save", action.failure)}${zudField("Duration", action.duration)}${zudField("Limit", action.limit)}${zudFieldWide("Counterplay", action.counterplay)}</div>`;
  const mechanics = `<div class="zud-action-grid">${zuiR2ListField("Creates states", action.creates_states, "None.")}${zuiR2ListField("Consumes states", action.consumes_states, "None.")}${zuiR2ListField("Source Spheres", action.source_spheres, "None recorded.")}${zuiR2ListField("Source talents", action.source_talents, "None recorded.")}${zuiR2ListField("Rule sources", action.source_packet_ids, "None recorded.")}</div>`;
  return `<article class="zud-action-card zui-r2-immortal-action-card"><header><div><h5>${zudCleanText(action.name, `Immortal technique ${index + 1}`)}</h5><p class="zui-r2-card-subtitle">Executable expression of the parent Immortal Art</p></div><div class="zud-badges">${zudBadge(action.economy)}${zudBadge(action.action_id)}</div></header>${quick}<div class="zui-r2-nested-stack">${zuiR2Disclosure("What this technique does", execution, { open: true, meta: action.roll_or_save || "" })}${zuiR2Disclosure("States, sources, and implementation", mechanics, { meta: `${action.creates_states.length} state(s) created` })}</div></article>`;
}
function zuiR2ImmortalArtCard(art = {}) {
  const actionRows = art.linked_action_details || [];
  const quick = `<div class="zui-r2-forged-quick">${zuiR2QuickMetric("Status", art.status)}${zuiR2QuickMetric("Gained", art.gained_at_cl ? `CL ${art.gained_at_cl}` : "—")}${zuiR2QuickMetric("Techniques", actionRows.length)}${zuiR2QuickMetric("Evolution", art.evolution_state)}</div>`;
  const summary = `<div class="zud-action-grid">${zudFieldWide("Dao Aspect", art.dao_aspect)}${zudFieldWide("How the art functions", art.execution_summary)}</div>`;
  const actions = actionRows.length ? `<div class="zud-card-stack">${actionRows.map(zuiR2ImmortalActionCard).join("")}</div>` : `<article class="zui-r2-empty-state"><strong>Linked techniques unresolved</strong><p>The art names ${escapeHtml((art.action_ids || []).join(", ") || "no action IDs")}, but no complete execution packets were available.</p></article>`;
  const limits = `<div class="zud-action-grid">${zuiR2ListField("Limitations", art.limitations, "None recorded.")}${zuiR2ListField("Behavior hooks", art.behavior_hooks, "None recorded.")}</div>`;
  const provenance = `<div class="zud-action-grid">${zudFieldWide("Acquisition", art.acquisition_record)}${zudFieldWide("Rule sources", art.source_packet_ids)}${zudField("Linked action IDs", art.action_ids)}${zudField("Immortal Art ID", art.immortal_art_id)}</div>`;
  return `<article class="zud-action-card zui-r2-immortal-card"><header><div><h5>${zudCleanText(art.name, "Unnamed Immortal Art")}</h5><p class="zui-r2-card-subtitle">Dao-aspect art with ${actionRows.length} executable technique packet(s)</p></div><div class="zud-badges">${zudBadge(art.status)}${zudBadge(art.gained_at_cl ? `CL ${art.gained_at_cl}` : "")}${zudBadge(art.evolution_state)}</div></header>${quick}<div class="zui-r2-nested-stack">${zuiR2Disclosure("Dao principle and execution overview", summary, { open: true, meta: `${actionRows.length} technique(s)` })}${zuiR2Disclosure("Executable Immortal techniques", actions, { open: true, meta: `${actionRows.length} complete packet(s)` })}${zuiR2Disclosure("Limitations and combat behavior", limits, { meta: `${(art.limitations || []).length} limitation(s)` })}${zuiR2Disclosure("Acquisition and provenance", provenance, { meta: `${(art.source_packet_ids || []).length} source packet(s)` })}</div></article>`;
}
function zuiR2RenderImmortalArts(model = {}) {
  const rows = model.immortal_arts || [];
  const reason = zudSafeText(model.immortal_arts_none_state?.reason, "No Immortal Arts are recorded for this character.");
  const body = rows.length ? `<div class="zud-card-stack">${rows.map(zuiR2ImmortalArtCard).join("")}</div>` : `<article class="zui-r2-empty-state"><strong>No Immortal Arts</strong><p>${escapeHtml(reason)}</p></article>`;
  return `<div class="zud-tab-heading"><h3>Immortal Arts</h3><p>Each art shows its Dao principle and every complete executable technique packet. Immortal Arts remain distinct from Recorded Arts and personal Forged Techniques.</p></div>${zudSection(`Immortal Arts (${rows.length})`, body)}`;
}
function zuiR2RenderDiagnostics(model = {}) {
  const diagnostics = model.diagnostics || [];
  const issues = diagnostics.filter((d) => /error|warning/i.test(String(d?.severity || "")) || /UNRESOLVED|HAZARD|FAIL|MISSING/i.test(`${d?.code || ""} ${d?.message || ""}`));
  const counts = [
    ["Level rows", (model.leveling_ledger || []).length], ["Actions", (model.actions || []).length],
    ["Composites", (model.composites || []).length], ["Forged Techniques", (model.forged_techniques || []).length],
    ["Preserved Forged Expressions", (model.preserved_forged_expressions || []).length], ["Emergency Seeds", (model.emergency_technique_seeds || []).length], ["Recorded Arts", (model.martial_manuals || []).length], ["Immortal Arts", (model.immortal_arts || []).length]
  ];
  return `<div class="zud-tab-heading"><h3>Diagnostics</h3><p>Authoritative producer–consumer reconciliation. Final real-screen acceptance is reported separately.</p></div>
    <div class="zud-core-grid">
      ${zudDetailCard("Consumer", ZUI_R2_PATCH_ID)}
      ${zudDetailCard("Model contract", model.validation?.verdict || "Contract status unavailable")}
      ${zudDetailCard("Canonical projection", issues.length ? `${issues.length} blocking issue(s)` : "Complete")}
      ${zudDetailCard("Primary resource", `${model.core_stats?.primary_resource?.name || "Resource"} ${model.core_stats?.primary_resource?.current ?? "—"}/${model.core_stats?.primary_resource?.max ?? "—"}`)}
      ${zudDetailCard("Required tabs", "14 present in the active renderer")}
      ${zudDetailCard("Roster retention", "Run the Real GM Screen Acceptance test after import")}
    </div>
    ${zudSection("Compiled surface counts", `<div class="zud-kv-grid">${counts.map(([label,value]) => zudField(label, value, "0")).join("")}</div>`)}
    ${zudSection("Blocking issues", zudBulletList(issues.map((d) => `${String(d.severity || "INFO").toUpperCase()} ${d.code}: ${d.message}`), "None flagged."))}
    ${zudSection("Projection evidence", zudBulletList(diagnostics.map((d) => `${String(d.severity || "INFO").toUpperCase()} ${d.code}: ${d.message} [${d.source || "consumer"}]`), "Canonical projection completed with no diagnostic notes."))}`;
}

function zuiR2RenderVisualCharacterSheet(pkg, notes = {}) {
  const model = zuiR2RepairCanonical(zuhRepairModelVisibility(zucBuildViewModelV2(pkg), pkg), pkg);
  const id = model.identity || {};
  const tabs = [
    ["overview-core-stats", "Overview / Core Stats", zueRenderOverview],
    ["leveling-ledger", "Leveling Ledger", zuiR2RenderLeveling],
    ["background-origin", "Background & Origin", zudRenderBackground],
    ["spheres-talents", "Spheres & Talents", zudRenderSpheresTalents],
    ["actions", "Actions", zudRenderActions],
    ["composite-playbooks", "Composite Playbooks", zueRenderComposites],
    ["forged-techniques", "Forged Techniques", zuiR2RenderForged],
    ["martial-manuals-recorded-arts", "Martial Manuals / Recorded Arts", zudRenderManuals],
    ["immortal-arts", "Immortal Arts", zuiR2RenderImmortalArts],
    ["foundation", "Foundation", zudRenderFoundation],
    ["method", "Method", zudRenderMethod],
    ["dao-i-ching", "Dao & I Ching", zudRenderDaoIChing],
    ["equipment-resources-states", "Equipment / Resources / States", zueRenderEquipmentResourcesStates],
    ["diagnostics", "Diagnostics", zuiR2RenderDiagnostics]
  ];
  return `<article class="sheet-card zud-v2-sheet zue-v2-sheet zuh-v2-sheet zui-r2-sheet" data-view-model-schema="${ZUC_VIEW_SCHEMA}" data-renderer-patch="${ZUI_R2_PATCH_ID}"><header class="zud-sheet-header"><div><p class="zud-eyebrow">Tianxia GM Screen · Authoritative Factory Consumer</p><h3>${zudCleanText(id.display_name || id.name, "Unnamed character")}</h3><p>${zudCleanText([id.path, id.realm, id.CL ? `CL ${id.CL}` : ""].filter(Boolean).join(" | "))}</p></div><div class="zud-header-tags"><span>${escapeHtml(ZUI_R2_PATCH_ID)}</span><span>${escapeHtml(ZUC_VIEW_SCHEMA)}</span><span>${escapeHtml(model.validation?.verdict || "UNKNOWN")}</span></div></header><div class="zud-character-shell">${zueLeftRail(model, tabs)}<main class="zud-main-panel">${tabs.map(([slug,,renderer],i)=>zudTabPanel(slug,renderer(model),i===0)).join("")}</main></div></article>`;
}
const zuiR2RenderVisualCharacterSheetBefore = renderVisualCharacterSheet;
renderVisualCharacterSheet = function renderVisualCharacterSheetHf05zuiR2(pkg, notes = {}) {
  try { return zuiR2RenderVisualCharacterSheet(pkg, notes); }
  catch (error) { const fallback=zuiR2RenderVisualCharacterSheetBefore(pkg,notes); return `${fallback}<section class="sheet-section"><h4>HF05ZUI-R2H Renderer Exception</h4><p>${escapeHtml(error?.message || String(error))}</p></section>`; }
};
const zuiR2CompactSavedPackageBefore = compactSavedPackage;
compactSavedPackage = function compactSavedPackageHf05zuiR2(pkg) {
  const saved = zuiR2CompactSavedPackageBefore(pkg);
  saved.viewModelV2 = zuiR2RepairCanonical(zuhRepairModelVisibility(zucBuildViewModelV2(pkg), pkg), pkg);
  saved.save_schema = "HF05ZUI-R2H.compact-save.v1";
  saved.hf05zui_r2 = { patch: ZUI_R2_PATCH_ID, forged_count: saved.viewModelV2.forged_techniques.length, emergency_seed_count: saved.viewModelV2.emergency_technique_seeds.length, immortal_art_count: saved.viewModelV2.immortal_arts.length };
  return saved;
};

/* HF05ZUI-R2H — real user-opened GM Screen acceptance export */
const HF05ZUI_R2H_ACCEPTANCE_TABS = [
  "overview-core-stats","leveling-ledger","background-origin","spheres-talents","actions",
  "composite-playbooks","forged-techniques","martial-manuals-recorded-arts","immortal-arts","foundation","method",
  "dao-i-ching","equipment-resources-states","diagnostics"
];
const HF05ZUI_R2H_ACCEPTANCE_BLOCKERS = [
  "[object Object]","LEVELING_LEDGER_SYNTHESIZED","COMPOSITE_TEMPORAL_FEASIBILITY_FALLBACK_USED",
  "Renderer Exception","No composite playbooks recorded","Foundation not recorded","Method not recorded",
  "Not recorded","Unresolved execution component","Economy unclear","Timing label not recorded",
  "Synthesized/fallback timing label","No linked action details recorded"
];
function hf05zuiR2bSha256Fallback(bytes) {
  const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  ];
  const rotr = (value, bits) => (value >>> bits) | (value << (32 - bits));
  const bitLength = data.length * 8;
  const paddedLength = (((data.length + 9 + 63) >> 6) << 6);
  const padded = new Uint8Array(paddedLength);
  padded.set(data); padded[data.length] = 0x80;
  const view = new DataView(padded.buffer);
  const high = Math.floor(bitLength / 0x100000000);
  const low = bitLength >>> 0;
  view.setUint32(paddedLength - 8, high, false);
  view.setUint32(paddedLength - 4, low, false);
  let h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a,h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
  const w = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4, false);
    for (let i = 16; i < 64; i += 1) {
      const s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >>> 3);
      const s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0;
    }
    let a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,h=h7;
    for (let i = 0; i < 64; i += 1) {
      const s1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
      const ch = (e & f) ^ ((~e) & g);
      const t1 = (h + s1 + ch + K[i] + w[i]) >>> 0;
      const s0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (s0 + maj) >>> 0;
      h=g; g=f; f=e; e=(d+t1)>>>0; d=c; c=b; b=a; a=(t1+t2)>>>0;
    }
    h0=(h0+a)>>>0; h1=(h1+b)>>>0; h2=(h2+c)>>>0; h3=(h3+d)>>>0;
    h4=(h4+e)>>>0; h5=(h5+f)>>>0; h6=(h6+g)>>>0; h7=(h7+h)>>>0;
  }
  return [h0,h1,h2,h3,h4,h5,h6,h7].map((value) => value.toString(16).padStart(8,"0")).join("");
}
async function hf05zuiR2bSha256File(file) {
  const bytes = await file.arrayBuffer();
  if (globalThis.crypto?.subtle?.digest) {
    try {
      const digest = await crypto.subtle.digest("SHA-256", bytes);
      return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
    } catch {}
  }
  return hf05zuiR2bSha256Fallback(bytes);
}
const hf05zuiR2bImportPackageFilesBefore = importPackageFiles;
importPackageFiles = async function importPackageFilesHf05zuiR2b(files) {
  const list = [...files];
  const zipEvidence = [];
  for (const file of list) {
    if (isZipFile(file.name)) {
      try { zipEvidence.push({ filename: file.name, bytes: file.size, sha256: await hf05zuiR2bSha256File(file) }); }
      catch (error) { zipEvidence.push({ filename: file.name, bytes: file.size, hash_error: error?.message || String(error) }); }
    }
  }
  const beforeIds = new Set((state.packages || []).map((pkg) => pkg.id));
  await hf05zuiR2bImportPackageFilesBefore(list);
  if (zipEvidence.length && state.packages?.length) {
    const imported = state.packages.find((pkg) => !beforeIds.has(pkg.id)) || state.packages[0];
    imported.hf05zui_real_import = {
      consumer: "HF05ZUI-R2H",
    consumer_patch: ZUI_R2_PATCH_ID,
      imported_at: new Date().toISOString(),
      zip_files: zipEvidence,
      actual_zip_input_exercised: true
    };
    state.packages = state.packages.map((pkg) => pkg.id === imported.id ? pkg : pkg);
    saveState();
    refreshPackageSelectors();
    renderCharacterViewer();
  }
};
const hf05zuiR2bCompactSavedPackageBefore = compactSavedPackage;
compactSavedPackage = function compactSavedPackageHf05zuiR2bAcceptance(pkg) {
  const saved = hf05zuiR2bCompactSavedPackageBefore(pkg);
  if (pkg?.hf05zui_real_import) saved.hf05zui_real_import = JSON.parse(JSON.stringify(pkg.hf05zui_real_import));
  return saved;
};
function hf05zuiR2bModelCounts(model = {}) {
  return {
    levels: (model.leveling_ledger || []).length,
    spheres: (model.spheres_talents?.spheres || []).length,
    talents: (model.spheres_talents?.talents || []).length,
    actions: (model.actions || []).length,
    composites: (model.composites || []).length,
    training_sources: (model.training_sources || []).length,
    forged: (model.forged_techniques || []).length,
    preserved_forged: (model.preserved_forged_expressions || []).length,
    seeds: (model.emergency_technique_seeds || []).length,
    manuals: (model.martial_manuals || []).length,
    immortal_arts: (model.immortal_arts || []).length,
    equipment: (model.equipment_resources_states?.equipment || []).length,
    states: (model.equipment_resources_states?.states || []).length
  };
}
function hf05zuiR2bExpectedCounts(pkg = {}) {
  const manifest = zuiR2FindJson(pkg, ["GM_Screen_Tab_Expectation_Manifest.json"], [/GM_Screen_Tab_Expectation_Manifest/i]);
  const raw = manifest?.expected_counts || {};
  return {
    levels: Number(raw.level_rows ?? 0), spheres: Number(raw.spheres ?? 0), talents: Number(raw.talents ?? 0),
    actions: Number(raw.actions ?? 0), composites: Number(raw.composites ?? 0), training_sources: Number(raw.training_sources ?? 0), forged: Number(raw.forged_techniques ?? 0),
    preserved_forged: Number(raw.preserved_forged_expressions ?? 0), seeds: Number(raw.emergency_technique_seeds ?? 0),
    manuals: Number(raw.recorded_arts ?? 0), immortal_arts: Number(raw.immortal_arts ?? 0), equipment: Number(raw.equipment ?? 0), states: Number(raw.states ?? 0)
  };
}
function hf05zuiR2bCountMismatches(expected = {}, actual = {}) {
  return Object.keys(expected).filter((key) => Number(expected[key]) !== Number(actual[key])).map((key) => ({ key, expected: Number(expected[key]), actual: Number(actual[key]) }));
}
function hf05zuiR2bCollectRenderedTabs(root) {
  const tabs = [...root.querySelectorAll("[data-sheet-tab]")].map((node) => node.getAttribute("data-sheet-tab"));
  const text = {};
  HF05ZUI_R2H_ACCEPTANCE_TABS.forEach((tab) => {
    const panel = root.querySelector(`[data-sheet-panel="${tab}"]`);
    text[tab] = panel?.textContent || "";
  });
  return { tabs, text };
}
function hf05zuiR2bNormalizeText(value) { return String(value || "").replace(/\s+/g, " ").trim(); }
function hf05zuiR2cCanonicalArray(value) {
  return zucArray(value).map((item) => zucIsObject(item) ? JSON.stringify(item, Object.keys(item).sort()) : String(item)).sort();
}
function hf05zuiR2cArrayEqual(a, b) { return JSON.stringify(hf05zuiR2cCanonicalArray(a)) === JSON.stringify(hf05zuiR2cCanonicalArray(b)); }
function hf05zuiR2cProjectionFidelity(pkg = {}, model = {}) {
  const master = zuiR2FindJson(pkg, ["Character_Master_Ledger.json"], [/Character_Master_Ledger/i]);
  const mismatches = [];
  const checks = [];
  const check = (name, pass, expected, actual) => {
    checks.push({ name, pass: !!pass, expected, actual });
    if (!pass) mismatches.push({ name, expected, actual });
  };
  const masterForged = zucArray(master.forged_techniques);
  const modelForged = zucArray(model.forged_techniques);
  check("forged_record_count", masterForged.length === modelForged.length, masterForged.length, modelForged.length);
  masterForged.forEach((raw, index) => {
    const id = raw.forged_id || raw.forged_technique_id || raw.technique_id || raw.id || `forged_${index}`;
    const row = modelForged.find((x) => (x.forged_id || x.forged_technique_id || x.technique_id || x.id) === id) || modelForged[index] || {};
    ["secondary_spheres","component_grant_ids","component_action_ids","augments","drawbacks","source_packet_ids"].forEach((field) => {
      check(`forged:${id}:${field}`, hf05zuiR2cArrayEqual(raw[field], row[field]), hf05zuiR2cCanonicalArray(raw[field]), hf05zuiR2cCanonicalArray(row[field]));
    });
  });
  const masterCoverage = zucArray(master.talent_execution_coverage);
  const modelTalents = zucArray(model.spheres_talents?.talents);
  check("talent_execution_coverage_count", masterCoverage.length === modelTalents.length, masterCoverage.length, modelTalents.length);
  masterCoverage.forEach((raw) => {
    const talentId = raw.talent_id || raw.source_id;
    const row = modelTalents.find((x) => (x.talent_id || x.id) === talentId) || {};
    const cov = row.execution_coverage || {};
    check(`talent:${talentId}:classification`, String(raw.classification || "") === String(cov.classification || ""), raw.classification, cov.classification);
    check(`talent:${talentId}:action_ids`, hf05zuiR2cArrayEqual(raw.action_ids, cov.action_ids), hf05zuiR2cCanonicalArray(raw.action_ids), hf05zuiR2cCanonicalArray(cov.action_ids));
    check(`talent:${talentId}:target_action_ids`, hf05zuiR2cArrayEqual(raw.target_action_ids, cov.target_action_ids), hf05zuiR2cCanonicalArray(raw.target_action_ids), hf05zuiR2cCanonicalArray(cov.target_action_ids));
  });
  const masterFoundation = master.foundation || {};
  const modelFoundation = model.foundation || {};
  const expectedLifecycle = Object.keys(masterFoundation.lifecycle_coverage || {}).sort();
  const actualLifecycle = Object.keys(modelFoundation.lifecycle_coverage || {}).sort();
  check("foundation_lifecycle_categories", JSON.stringify(expectedLifecycle) === JSON.stringify(actualLifecycle), expectedLifecycle, actualLifecycle);
  const expectedStages = Array.isArray(masterFoundation.stage_benefit_map) ? masterFoundation.stage_benefit_map.length : Object.keys(masterFoundation.stage_benefit_map || {}).length;
  const actualStages = Array.isArray(modelFoundation.stage_benefit_map) ? modelFoundation.stage_benefit_map.length : Object.keys(modelFoundation.stage_benefit_map || {}).length;
  check("foundation_stage_map", expectedStages === actualStages, expectedStages, actualStages);
  const mb = master.background_origin?.background || {};
  const rb = model.background_origin?.background || {};
  ["skill_proficiencies","tool_proficiencies","languages"].forEach((field) => check(`background:${field}`, hf05zuiR2cArrayEqual(mb[field], rb[field]), hf05zuiR2cCanonicalArray(mb[field]), hf05zuiR2cCanonicalArray(rb[field])));
  const masterRecordedArts = zucArray(master.recorded_arts);
  const modelRecordedArts = zucArray(model.martial_manuals);
  check("recorded_art_count", masterRecordedArts.length === modelRecordedArts.length, masterRecordedArts.length, modelRecordedArts.length);
  masterRecordedArts.forEach((raw, index) => {
    const artId = raw.recorded_art_id || raw.art_id || raw.id || `RECORDED_ART_${index + 1}`;
    const rendered = modelRecordedArts.find((row) => row.recorded_art_id === artId) || modelRecordedArts[index] || {};
    const sourceSpheres = zucArray(raw.source_spheres);
    const invalidCustomMulti = raw.custom_design === true && sourceSpheres.length > 1 && raw.expression_kind !== "preserved_forged_expression";
    check(`recorded_art:${artId}:expression_kind`, !invalidCustomMulti && String(raw.expression_kind || "") === String(rendered.expression_kind || ""), raw.expression_kind || "missing", rendered.expression_kind || "missing");
    check(`recorded_art:${artId}:source_spheres`, hf05zuiR2cArrayEqual(raw.source_spheres, rendered.source_spheres), hf05zuiR2cCanonicalArray(raw.source_spheres), hf05zuiR2cCanonicalArray(rendered.source_spheres));
    if (raw.expression_kind === "preserved_forged_expression") check(`recorded_art:${artId}:preserved_forged_record`, !!raw.preserved_forged_expression && !!rendered.preserved_forged_expression, true, !!rendered.preserved_forged_expression);
  });
  const expectedImmortal = zucArray(master.immortal_arts).length;
  check("immortal_art_count", expectedImmortal === zucArray(model.immortal_arts).length, expectedImmortal, zucArray(model.immortal_arts).length);
  const masterActionMap = new Map(zucArray(master.actions).map((row) => [row.action_id, row]));
  zucArray(master.immortal_arts).forEach((rawArt) => {
    const artId = rawArt.immortal_art_id;
    const renderedArt = zucArray(model.immortal_arts).find((row) => row.immortal_art_id === artId) || {};
    check(`immortal:${artId}:action_ids`, hf05zuiR2cArrayEqual(rawArt.action_ids, renderedArt.action_ids), hf05zuiR2cCanonicalArray(rawArt.action_ids), hf05zuiR2cCanonicalArray(renderedArt.action_ids));
    check(`immortal:${artId}:linked_action_count`, zucArray(rawArt.action_ids).length === zucArray(renderedArt.linked_action_details).length, zucArray(rawArt.action_ids).length, zucArray(renderedArt.linked_action_details).length);
    zucArray(rawArt.action_ids).forEach((actionId) => {
      const expectedAction = masterActionMap.get(actionId) || {};
      const actualAction = zucArray(renderedArt.linked_action_details).find((row) => row.action_id === actionId) || {};
      const fields = [["timing","timing"],["cost","cost"],["range","range"],["target","target"],["roll_save_check","roll_or_save"],["effect","effect"],["failure","failure"],["duration","duration"],["limit","limit"],["counterplay","counterplay"]];
      fields.forEach(([expectedField, actualField]) => check(`immortal:${artId}:${actionId}:${expectedField}`, hf05zuiR2bNormalizeText(expectedAction[expectedField]) === hf05zuiR2bNormalizeText(actualAction[actualField]), expectedAction[expectedField] || "", actualAction[actualField] || ""));
    });
  });
  return { passed: mismatches.length === 0, checks, mismatches };
}
async function runHf05zuiR2bRealAcceptance() {
  const pkg = activePackage();
  if (!pkg) throw new Error("Import and select a character package first.");
  const importEvidence = pkg.hf05zui_real_import;
  if (!importEvidence?.actual_zip_input_exercised || !importEvidence.zip_files?.length) {
    throw new Error("This character does not have a recorded ZIP-input hash. Re-import the original character ZIP, then run the test.");
  }
  const model = zuiR2RepairCanonical(zuhRepairModelVisibility(zucBuildViewModelV2(pkg), pkg), pkg);
  const liveRoot = document.getElementById("activeCharacterVisualSheet");
  liveRoot.innerHTML = renderVisualCharacterSheet(pkg, notesForPackage(pkg.id));
  attachVisualSheetTabs("activeCharacterVisualSheet");
  const before = hf05zuiR2bCollectRenderedTabs(liveRoot);
  const saved = compactSavedPackage(pkg);
  const testRoot = document.createElement("div");
  testRoot.id = "hf05zuiR2bAcceptanceRehydrateRoot";
  testRoot.style.position = "fixed"; testRoot.style.left = "-100000px"; testRoot.style.width = "1600px";
  testRoot.innerHTML = renderVisualCharacterSheet(saved, notesForPackage(pkg.id));
  document.body.appendChild(testRoot);
  attachVisualSheetTabs(testRoot.id);
  const after = hf05zuiR2bCollectRenderedTabs(testRoot);
  testRoot.remove();
  const missing = HF05ZUI_R2H_ACCEPTANCE_TABS.filter((tab) => !before.tabs.includes(tab));
  const allText = Object.values(before.text).join("\n");
  const blockers = HF05ZUI_R2H_ACCEPTANCE_BLOCKERS.filter((item) => allText.toLowerCase().includes(item.toLowerCase()));
  HF05ZUI_R2H_ACCEPTANCE_TABS.forEach((tab) => { if (!hf05zuiR2bNormalizeText(before.text[tab])) blockers.push(`EMPTY_TAB:${tab}`); });
  const retention = {};
  HF05ZUI_R2H_ACCEPTANCE_TABS.forEach((tab) => {
    retention[tab] = {
      preserved: hf05zuiR2bNormalizeText(before.text[tab]) === hf05zuiR2bNormalizeText(after.text[tab]),
      before_chars: before.text[tab]?.length || 0,
      after_chars: after.text[tab]?.length || 0
    };
  });
  const saveReloadPreserved = Object.values(retention).every((row) => row.preserved);
  const candidate = importEvidence.zip_files[0];
  if (!/^[a-f0-9]{64}$/i.test(String(candidate?.sha256 || ""))) throw new Error("The imported ZIP does not have a valid SHA-256 record. Re-import the original character ZIP.");
  const counts = hf05zuiR2bModelCounts(model);
  const expectedCounts = hf05zuiR2bExpectedCounts(pkg);
  const countMismatches = hf05zuiR2bCountMismatches(expectedCounts, counts);
  const projectionFidelity = hf05zuiR2cProjectionFidelity(pkg, model);
  const passed = !missing.length && !blockers.length && !countMismatches.length && projectionFidelity.passed && saveReloadPreserved && before.tabs.join("|") === HF05ZUI_R2H_ACCEPTANCE_TABS.join("|");
  const report = {
    schema: "HF05ZUI-R2H.RealAcceptanceReport.v1",
    evidence_class: "real_gm_screen_user_acceptance",
    verdict: passed ? "PASS_REAL_GMSCREEN_ACCEPTANCE" : "FAIL_REAL_GMSCREEN_ACCEPTANCE",
    consumer: "HF05ZUI-R2H",
    consumer_patch: ZUI_R2_PATCH_ID,
    generated_at: new Date().toISOString(),
    candidate_filename: candidate.filename,
    candidate_sha256: candidate.sha256,
    candidate_bytes: candidate.bytes,
    actual_zip_input_exercised: true,
    package_id: pkg.id,
    character_name: model.identity?.display_name || model.identity?.name || pkg.name,
    browser: { user_agent: navigator.userAgent, platform: navigator.platform, language: navigator.language },
    tabs_present: before.tabs,
    missing_tabs: missing,
    blockers: [...new Set(blockers)],
    save_reload_preserved: saveReloadPreserved,
    retention,
    counts,
    expected_counts: expectedCounts,
    expected_counts_match: countMismatches.length === 0,
    count_mismatches: countMismatches,
    projection_fidelity: projectionFidelity,
    model_validation: model.validation,
    import_evidence: importEvidence
  };
  window.hf05zuiR2bLastAcceptanceReport = report;
  const status = document.getElementById("characterAcceptanceStatus");
  if (status) {
    status.classList.toggle("pass", passed); status.classList.toggle("fail", !passed);
    status.textContent = `${report.verdict}\n${report.character_name}\n18-tab set: ${missing.length ? `missing ${missing.join(", ")}` : "complete"}\nBlockers: ${report.blockers.length ? report.blockers.join("; ") : "none"}\nExpected counts: ${countMismatches.length ? countMismatches.map((row) => `${row.key} ${row.actual}/${row.expected}`).join("; ") : "matched"}\nProjection fidelity: ${projectionFidelity.passed ? "matched" : `${projectionFidelity.mismatches.length} mismatch(es)`}\nSave/reload retention: ${saveReloadPreserved ? "preserved" : "failed"}\nCandidate SHA-256: ${candidate.sha256}`;
  }
  const exportButton = document.getElementById("exportCharacterAcceptanceButton");
  if (exportButton) exportButton.disabled = false;
  return report;
}
function hf05zuiR2bExportAcceptance() {
  const report = window.hf05zuiR2bLastAcceptanceReport;
  if (!report) { toast("Run the acceptance test first."); return; }
  const safe = String(report.character_name || "Character").replace(/[^a-z0-9_-]+/gi, "_").replace(/^_+|_+$/g, "") || "Character";
  downloadBlob(new Blob([JSON.stringify(report, null, 2) + "\n"], { type: "application/json" }), `${safe}_HF05ZUI_R2H_Real_Acceptance.json`);
  toast("Acceptance report exported.");
}
function hf05zuiR2bBindAcceptanceControls() {
  const runButton = document.getElementById("runCharacterAcceptanceButton");
  const exportButton = document.getElementById("exportCharacterAcceptanceButton");
  if (runButton && !runButton.dataset.bound) {
    runButton.dataset.bound = "true";
    runButton.addEventListener("click", async () => {
      const status = document.getElementById("characterAcceptanceStatus");
      try { if (status) status.textContent = "Running acceptance test…"; await runHf05zuiR2bRealAcceptance(); }
      catch (error) { if (status) { status.classList.add("fail"); status.textContent = `ACCEPTANCE TEST ERROR\n${error?.message || String(error)}`; } toast("Acceptance test failed."); }
    });
  }
  if (exportButton && !exportButton.dataset.bound) { exportButton.dataset.bound = "true"; exportButton.addEventListener("click", hf05zuiR2bExportAcceptance); }
}
hf05zuiR2bBindAcceptanceControls();


// HF05ZUI-R2H Character Builder Studio
const HF05ZUI_R2E_BUILDER_PATCH = "HF05ZUI-R2H.2-BUILDER-INSIGHTS-ABILITY";
const HF05ZVK_R1E_RECORDED_ART_FLOORS = {
  standard: { mortal: 0, foundation: 4, core: 8, nascent: 10 },
  significant: { mortal: 0, foundation: 6, core: 10, nascent: 12 },
  powerful: { mortal: 2, foundation: 8, core: 12, nascent: 16 },
  rival: { mortal: 2, foundation: 10, core: 16, nascent: 20 }
};
const HF05ZUI_R2E_BUILDER_FIELD_IDS = [
  "builderName","builderImportance","builderPath","builderLevel","builderRealm","builderKeyAbility","builderVersion","builderSourceMode","builderConcept","builderSourceRestrictions","builderDescription",
  "builderStr","builderDex","builderCon","builderInt","builderWis","builderCha","builderBackground","builderBackgroundRegion","builderOriginInsightName","builderOriginInsightSource","builderOriginInsightMechanics","builderDaoName","builderIChing","builderDaoBehavior",
  "builderTalents","builderInsights","builderTalentExecutionNotes","builderFoundationCatalogSet","builderFoundationCatalogSelect","builderFoundationCatalogCode","builderFoundationGrade","builderFoundationName","builderFoundationFamily","builderFoundationDepth","builderFoundationStage","builderFoundationNotes","builderFoundationLifecycle",
  "builderMethodName","builderMethodStatus","builderMethodResource","builderMethodBreakthrough","builderMethodDoctrine","builderMartialArtName","builderMartialArtStatus","builderMartialArtDoctrine","builderRecordedArts","builderChakraRecord",
  "builderForgedMode","builderSeedMode","builderTechniques","builderEmergencySeed","builderImmortalEnabled","builderImmortalName","builderImmortalStatus","builderImmortalDaoAspect","builderImmortalActionType","builderImmortalCost","builderImmortalTarget","builderImmortalEffect","builderImmortalLimits",
  "builderActions","builderActionGenerationBrief","builderCompositeDescriptions","builderEquipment","builderAuthoredMechanics"
];
function hf05zuiR2eValue(id) {
  const el = document.getElementById(id);
  if (!el) return "";
  if (el.type === "checkbox") return !!el.checked;
  return String(el.value || "").trim();
}
function hf05zuiR2eLines(id) { return String(hf05zuiR2eValue(id) || "").split(/\r?\n/).map((x)=>x.trim()).filter(Boolean); }
function hf05zuiR2ePipeRows(id, fields) {
  return hf05zuiR2eLines(id).map((line,index)=>{
    const parts=line.split("|").map((x)=>x.trim());
    const row={ row_id: `${id}_${index+1}`, raw: line };
    fields.forEach((field,i)=>row[field]=parts[i]||"");
    return row;
  });
}
function hf05zuiR2eParagraphs(id) {
  return String(hf05zuiR2eValue(id)||"").split(/\n\s*\n/).map((x)=>x.trim()).filter(Boolean).map((text,index)=>({ composite_id:`composite_brief_${index+1}`, description:text }));
}
function hf05zuiR2eRecordedArtRealm(level) { const cl=Number(level)||0; return cl<5?"mortal":cl<10?"foundation":cl<15?"core":"nascent"; }
function hf05zuiR2eRecordedArtFloor() {
  const importance=hf05zuiR2eValue("builderImportance")||"standard";
  const realm=hf05zuiR2eRecordedArtRealm(hf05zuiR2eValue("builderLevel"));
  return HF05ZVK_R1E_RECORDED_ART_FLOORS[importance]?.[realm] ?? 0;
}
function hf05zuiR2ePointBuy() {
  const scores=builderAbilityScores(); const costs={8:0,9:1,10:2,11:3,12:4,13:5,14:7,15:9};
  let valid=true,total=0;
  Object.values(scores).forEach((score)=>{ if(costs[score]===undefined) valid=false; else total+=costs[score]; });
  return {scores,total,valid,remaining:27-total};
}
function hf05zuiR2eImmortalRecord() {
  if (!hf05zuiR2eValue("builderImmortalEnabled")) return null;
  return {
    name:hf05zuiR2eValue("builderImmortalName"), status:hf05zuiR2eValue("builderImmortalStatus"), dao_aspect:hf05zuiR2eValue("builderImmortalDaoAspect"),
    action_type:hf05zuiR2eValue("builderImmortalActionType"), cost_or_requirement:hf05zuiR2eValue("builderImmortalCost"), target_or_range:hf05zuiR2eValue("builderImmortalTarget"),
    effect_and_dao_expression:hf05zuiR2eValue("builderImmortalEffect"), limits_counterplay_evolution:hf05zuiR2eValue("builderImmortalLimits")
  };
}
function hf05zuiR2eBuilderSnapshot() {
  const derived=builderDerivedData(); const background=builderBackgroundRecord(); const foundation=builderFoundationRecord(hf05zuiR2eValue("builderName")||"Unnamed Tianxia Character");
  return {
    schema:"HF05ZUI-R2H.BuilderSnapshot.v1", builder_patch:HF05ZUI_R2E_BUILDER_PATCH, target_factory:"HF05ZVK-R1E", target_consumer:"HF05ZUI-R2H",
    identity:{ name:hf05zuiR2eValue("builderName"), character_depth:hf05zuiR2eValue("builderImportance"), concept:hf05zuiR2eValue("builderConcept"), physical_description:hf05zuiR2eValue("builderDescription"), source_mode:hf05zuiR2eValue("builderSourceMode"), source_restrictions_and_locks:hf05zuiR2eValue("builderSourceRestrictions") },
    cultivation:{ path:derived.pathName, level:derived.level, realm:derived.realm, key_ability:derived.keyAbility, proficiency_bonus:derived.pb, resource_name:derived.resourceName, provisional_resource_max:derived.resourceMax, chakra_record:hf05zuiR2eValue("builderChakraRecord") },
    abilities:{ scores:derived.scores, point_buy:hf05zuiR2ePointBuy() },
    background,
    origin_insight:{ name:hf05zuiR2eValue("builderOriginInsightName"), source_type:hf05zuiR2eValue("builderOriginInsightSource"), mechanics:hf05zuiR2eValue("builderOriginInsightMechanics") },
    dao_i_ching:{ dao_name:hf05zuiR2eValue("builderDaoName"), trigram:hf05zuiR2eValue("builderIChing"), combat_behavior:hf05zuiR2eValue("builderDaoBehavior") },
    spheres:[...builderSphereNames],
    talents:hf05zuiR2ePipeRows("builderTalents",["name","sphere_or_source","effect_or_note"]),
    additional_insights:hf05zuiR2ePipeRows("builderInsights",["name","source","effect"]),
    talent_execution_notes:hf05zuiR2eValue("builderTalentExecutionNotes"),
    foundation:{ ...foundation, lifecycle:hf05zuiR2eValue("builderFoundationLifecycle"), catalog_binding:{ catalog_code:foundation.catalog_code||hf05zuiR2eValue("builderFoundationCatalogCode"), catalog_set:foundation.catalog_set||foundationCatalogSetValue(), source_chunk:foundation.source_chunk||foundation.chunk||"", foundation_id:foundation.id||foundation.foundation_id||"", grade:foundation.foundation_grade||hf05zuiR2eValue("builderFoundationGrade"), source_package:foundation.catalog_source||"custom", source_package_sha256:foundation.catalog_source_package_sha256||"" } },
    method:{ name:hf05zuiR2eValue("builderMethodName"), status:hf05zuiR2eValue("builderMethodStatus"), resource_modifier:hf05zuiR2eValue("builderMethodResource"), breakthrough_shape:hf05zuiR2eValue("builderMethodBreakthrough"), doctrine_and_mechanics:hf05zuiR2eValue("builderMethodDoctrine"), stacking_rule:"Method, Foundation, and item modifiers stack when their own rules apply; only competing Primary Methods are mutually exclusive." },
    training_source:{ name:hf05zuiR2eValue("builderMartialArtName"), status:hf05zuiR2eValue("builderMartialArtStatus"), doctrine:hf05zuiR2eValue("builderMartialArtDoctrine") },
    recorded_arts:{ required_floor:hf05zuiR2eRecordedArtFloor(), rows:hf05zuiR2ePipeRows("builderRecordedArts",["name","sphere","reproduced_talent_expression","tactical_role","source_or_notes"]) },
    forged_techniques:{ planning_mode:hf05zuiR2eValue("builderForgedMode"), rows:hf05zuiR2ePipeRows("builderTechniques",["name","primary_sphere","secondary_spheres","tactical_purpose","description_or_locks"]) },
    emergency_forging:{ seed_mode:hf05zuiR2eValue("builderSeedMode"), seed_concept:hf05zuiR2eValue("builderEmergencySeed") },
    immortal_art:hf05zuiR2eImmortalRecord(),
    authored_actions:hf05zuiR2ePipeRows("builderActions",["name","action_type","range","attack_or_save","damage_or_effect","notes"]),
    action_generation_brief:hf05zuiR2eValue("builderActionGenerationBrief"),
    composite_playbook_briefs:hf05zuiR2eParagraphs("builderCompositeDescriptions"),
    equipment:hf05zuiR2eLines("builderEquipment"),
    authoritative_mechanics_notes:hf05zuiR2eValue("builderAuthoredMechanics")
  };
}
function hf05zuiR2eFactoryPrompt(snapshot=hf05zuiR2eBuilderSnapshot()) {
  return `Ingest the attached HF05ZUI-R2H Factory Handoff ZIP and use HF05ZVK-R1E as the sole authoritative character factory. Treat fields marked as locks as immutable. Treat other fields as strong preferences that may be optimized only when needed for legality, source fidelity, or quality. Run the six base commands separately, plus optional Command 4B if the Immortal Art record applies. Treat Selected_Foundation_Catalog_Record.json as the exact Foundation source packet when an FS/CH catalog binding is present. Do not substitute a similarly named non-current Foundation. Enforce complete talent execution routing, the R1E Recorded Art floor (${snapshot.recorded_arts.required_floor} for this build), complete Foundation lifecycle mapping, Method–Foundation stacking, executable Forged Techniques, Emergency Technique Seed handling, and the HF05ZUI-R2H consumer contract. Do not skip commands. Begin by validating the handoff and wait for Command 1.`;
}
function hf05zuiR2eActionOnlyPrompt(snapshot=hf05zuiR2eBuilderSnapshot()) {
  return `Ingest the attached HF05ZUI-R2H Action-Only Handoff ZIP. The character's authored mechanics are locked. Do not change ability scores, levels, Path, Background, Origin Insight, Spheres, talents, Foundation, Method, Recorded Arts, Forged Techniques, Immortal Art, equipment, resource formulas, or authored effects. Your permitted scope is only: (1) create complete executable action/reaction/passive/procedure packets for every applicable authored feature; (2) create only the states strictly required by those packets; (3) produce the talent execution coverage matrix; and (4) compile executable composite playbooks from the supplied composite descriptions. Preserve existing action exemplars exactly unless a validation defect requires a clearly documented correction. Return a ZIP containing action registries, state additions, talent routing, composite playbooks, validation, and a change log. Do not redesign the character.`;
}
function hf05zuiR2eReadable(snapshot) {
  const lines=[`# ${snapshot.identity.name||"Unnamed Tianxia Character"}`,``,`Target: ${snapshot.identity.character_depth} CL${snapshot.cultivation.level} ${snapshot.cultivation.path}`,`Realm: ${snapshot.cultivation.realm}`,``,`## Concept`,snapshot.identity.concept||"Not recorded.",``,`## Locks and Source Restrictions`,snapshot.identity.source_restrictions_and_locks||"None recorded.",``,`## Physical Description`,snapshot.identity.physical_description||"Not recorded.",``,`## Background and Origin`,`${snapshot.background?.name||"Background not selected"}${snapshot.origin_insight.name?` | Origin Insight: ${snapshot.origin_insight.name}`:""}`,snapshot.origin_insight.mechanics||"",``,`## Dao and I Ching`,`${snapshot.dao_i_ching.dao_name||"Not recorded"}${snapshot.dao_i_ching.trigram?` | ${snapshot.dao_i_ching.trigram}`:""}`,snapshot.dao_i_ching.combat_behavior||"",``,`## Spheres`,...(snapshot.spheres.length?snapshot.spheres.map(x=>`- ${x}`):["- None selected"]),``,`## Talents`,...(snapshot.talents.length?snapshot.talents.map(x=>`- ${x.raw}`):["- None entered"]),``,`## Foundation`,`${snapshot.foundation.name||"Not recorded"} | ${snapshot.foundation.depth||""} | ${snapshot.foundation.stage||""}`,snapshot.foundation.dao_principle||"",snapshot.foundation.lifecycle||"",``,`## Cultivation Method`,`${snapshot.method.name||"Not recorded"} | ${snapshot.method.status||""}`,snapshot.method.doctrine_and_mechanics||"",``,`## Recorded Arts (${snapshot.recorded_arts.rows.length}/${snapshot.recorded_arts.required_floor})`,...(snapshot.recorded_arts.rows.length?snapshot.recorded_arts.rows.map(x=>`- ${x.raw}`):["- None entered"]),``,`## Forged Techniques`,...(snapshot.forged_techniques.rows.length?snapshot.forged_techniques.rows.map(x=>`- ${x.raw}`):["- Factory may design or none planned"]),``,`## Immortal Art`,snapshot.immortal_art?`${snapshot.immortal_art.name||"Unnamed"}: ${snapshot.immortal_art.effect_and_dao_expression||"Effect not recorded"}`:"None.",``,`## Action Generation Brief`,snapshot.action_generation_brief||"Not recorded.",``,`## Composite Playbook Briefs`,...(snapshot.composite_playbook_briefs.length?snapshot.composite_playbook_briefs.map((x,i)=>`${i+1}. ${x.description}`):["- None entered"]),``,`## Equipment`,...(snapshot.equipment.length?snapshot.equipment.map(x=>`- ${x}`):["- None entered"]),``,`## Authoritative Mechanics Notes`,snapshot.authoritative_mechanics_notes||"None." ];
  return lines.filter((x)=>x!==null&&x!==undefined).join("\n");
}
function hf05zuiR2ePackage(mode) {
  const snapshot=hf05zuiR2eBuilderSnapshot();
  const name=(snapshot.identity.name||"Tianxia_Character").replace(/[^a-z0-9]+/gi,"_").replace(/^_+|_+$/g,"")||"Tianxia_Character";
  const isFactory=mode==="factory";
  const prompt=isFactory?hf05zuiR2eFactoryPrompt(snapshot):hf05zuiR2eActionOnlyPrompt(snapshot);
  const schema=isFactory?"HF05ZUI-R2H.FactoryHandoff.v1":"HF05ZUI-R2H.ActionOnlyHandoff.v1";
  const commonFiles=[
    {name:"README_FIRST.md",content:isFactory
      ?`# Factory Handoff — ${snapshot.identity.name||"Unnamed Character"}\n\nUpload this ZIP together with HF05ZVK_R1E_Factory.zip. Send the contents of START_HERE_PROMPT.txt. This handoff distinguishes exact locks from optimizable preferences; the factory remains responsible for legal advancement, source fidelity, complete mechanics, talent execution, Recorded Arts, actions, composites, and final GM Screen compilation.`
      :`# Action-Only Handoff — ${snapshot.identity.name||"Unnamed Character"}\n\nThe character mechanics in Authored_Mechanics_Lock.json are authoritative. The AI may generate only executable actions, required action states, talent routing, and composite playbooks from the supplied briefs. It must not rebuild, rebalance, or reinterpret the character.`},
    {name:"START_HERE_PROMPT.txt",content:prompt},
    {name:"Builder_Snapshot.json",content:JSON.stringify(snapshot,null,2)},
    {name:"Selected_Foundation_Catalog_Record.json",content:JSON.stringify(snapshot.foundation,null,2)},
    {name:"Authored_Character.md",content:hf05zuiR2eReadable(snapshot)}
  ];
  let modeFiles=[];
  let contract={};
  if(isFactory){
    contract={
      schema:"HF05ZUI-R2H.FactoryHandoffContract.v1", target_factory:"HF05ZVK-R1E",
      workflow:["Command 1 — Source Evidence and Blueprint Lock","Command 2 — Canonical Advancement and Rules Ledger","Command 3 — Chassis and Full Feature Mapping","Command 4 — Executable Combat and Technique Build","Optional Command 4B — Immortal Arts","Command 5 — Deterministic Compile and Contract","Command 6 — GM Screen Proof and Release Classification"],
      required_recorded_art_floor:snapshot.recorded_arts.required_floor,
      optimization_authority:"Full optimization authority except explicit locks and source restrictions.",
      nonnegotiable_quality:["complete talent execution routing","full Foundation lifecycle","Method–Foundation–item stacking","source-faithful Origin Insight","executable Recorded Arts","forged record separation","GM Screen projection fidelity"]
    };
    modeFiles=[
      {name:"Factory_Handoff_Brief.json",content:JSON.stringify(snapshot,null,2)},
      {name:"User_Locks.json",content:JSON.stringify({schema:"HF05ZUI-R2H.UserLocks.v1",source_mode:snapshot.identity.source_mode,exact_locks_and_restrictions:snapshot.identity.source_restrictions_and_locks,authored_immortal_art:snapshot.immortal_art,authored_forged_concepts:snapshot.forged_techniques.rows},null,2)},
      {name:"Factory_Quality_Targets.json",content:JSON.stringify({schema:"HF05ZUI-R2H.FactoryQualityTargets.v1",character_depth:snapshot.identity.character_depth,cultivation_level:snapshot.cultivation.level,minimum_recorded_arts:snapshot.recorded_arts.required_floor,require_full_talent_execution:true,require_full_foundation_lifecycle:true,allow_emergency_seed:snapshot.emergency_forging.seed_mode!=="none",immortal_art_command_required:!!snapshot.immortal_art},null,2)}
    ];
  }else{
    contract={
      schema:"HF05ZUI-R2H.ActionOnlyContract.v1",
      allowed_outputs:["Character_Action_Registry.json","Action_State_Additions.json","Talent_Execution_Coverage.json","Composite_Playbook.json","Action_Only_Validation.json","CHANGELOG.md"],
      forbidden_changes:["identity","ability scores","Path or CL","Background or Origin Insight","Spheres or talents","Foundation","Cultivation Method","Recorded Arts","Forged Techniques","Immortal Art","equipment","resource formulas","authored effects"],
      composite_input_field:"composite_playbook_briefs",action_input_field:"action_generation_brief",
      correction_policy:"A mechanical contradiction may be corrected only when explicitly identified in CHANGELOG.md; all unrelated authored content remains locked."
    };
    modeFiles=[
      {name:"Authored_Mechanics_Lock.json",content:JSON.stringify(snapshot,null,2)},
      {name:"Action_Generation_Request.json",content:JSON.stringify({schema:"HF05ZUI-R2H.ActionGenerationRequest.v1",action_generation_brief:snapshot.action_generation_brief,authored_action_exemplars:snapshot.authored_actions,talent_execution_notes:snapshot.talent_execution_notes,feature_sources:{talents:snapshot.talents,origin_insight:snapshot.origin_insight,foundation:snapshot.foundation,method:snapshot.method,recorded_arts:snapshot.recorded_arts.rows,forged_techniques:snapshot.forged_techniques.rows,immortal_art:snapshot.immortal_art},required_output:"Complete action/reaction/passive/procedure packets for every applicable feature plus exact talent execution routing."},null,2)},
      {name:"Composite_Playbook_Briefs.json",content:JSON.stringify({schema:"HF05ZUI-R2H.CompositeBriefs.v1",briefs:snapshot.composite_playbook_briefs,requirements:["purpose","setup","ordered executable steps","resource footprint","success expectation","fallback","Dao behavior","temporal feasibility"]},null,2)},
      {name:"Authored_Equipment_and_Resource_Notes.json",content:JSON.stringify({equipment:snapshot.equipment,authoritative_mechanics_notes:snapshot.authoritative_mechanics_notes,cultivation:snapshot.cultivation},null,2)}
    ];
  }
  const files=[...commonFiles,...modeFiles,{name:"Handoff_Contract.json",content:JSON.stringify(contract,null,2)}];
  const manifest={schema,mode:isFactory?"full_factory_handoff":"actions_and_composites_only",character_name:snapshot.identity.name,target_factory:"HF05ZVK-R1E",target_consumer:"HF05ZUI-R2H",created_at:new Date().toISOString(),files:[...files.map(x=>x.name),"package_manifest.json"]};
  files.push({name:"package_manifest.json",content:JSON.stringify(manifest,null,2)});
  return {safeName:name,files};
}
function hf05zuiR2eExport(mode) {
  const pkg=hf05zuiR2ePackage(mode); const bytes=createStoredZip(pkg.files); const suffix=mode==="factory"?"Factory_Handoff":"Action_Only_Handoff";
  downloadBlob(new Blob([bytes],{type:"application/zip"}),`${pkg.safeName}_${suffix}_HF05ZUI_R2H.zip`); toast(`${mode==="factory"?"Factory":"Action-only"} handoff ZIP exported.`);
}
function hf05zuiR2eValidationRows(snapshot) {
  const rows=[]; const artCount=snapshot.recorded_arts.rows.length, floor=snapshot.recorded_arts.required_floor; const point=snapshot.abilities.point_buy;
  rows.push({label:"Identity",value:snapshot.identity.name?"Named":"Name required",state:snapshot.identity.name?"pass":"fail"});
  rows.push({label:"Concept",value:snapshot.identity.concept?"Recorded":"Add a concept",state:snapshot.identity.concept?"pass":"warn"});
  rows.push({label:"Spheres / Talents",value:`${snapshot.spheres.length} / ${snapshot.talents.length}`,state:snapshot.spheres.length&&snapshot.talents.length?"pass":"warn"});
  rows.push({label:"Recorded Arts",value:`${artCount} / floor ${floor}`,state:artCount>=floor?"pass":artCount?"warn":"fail"});
  rows.push({label:"Foundation lifecycle",value:snapshot.foundation.lifecycle?"Recorded":"Incomplete",state:snapshot.foundation.lifecycle?"pass":"warn"});
  rows.push({label:"Method",value:snapshot.method.name||"Not recorded",state:snapshot.method.name?"pass":"warn"});
  rows.push({label:"Origin Insight",value:snapshot.origin_insight.name||"Not recorded",state:snapshot.origin_insight.name&&snapshot.origin_insight.mechanics?"pass":"warn"});
  rows.push({label:"Point buy",value:point.valid?`${point.total}/27 (${point.remaining>=0?point.remaining+" remaining":Math.abs(point.remaining)+" over"})`:"Custom scores",state:point.valid&&point.total===27?"pass":point.valid?"warn":"warn"});
  rows.push({label:"Action handoff",value:snapshot.action_generation_brief?"Brief ready":"Brief missing",state:snapshot.action_generation_brief?"pass":"warn"});
  rows.push({label:"Composite briefs",value:String(snapshot.composite_playbook_briefs.length),state:snapshot.composite_playbook_briefs.length?"pass":"warn"});
  if(snapshot.immortal_art) rows.push({label:"Immortal Art",value:snapshot.immortal_art.name||"Enabled but unnamed",state:snapshot.immortal_art.name&&snapshot.immortal_art.effect_and_dao_expression?"pass":"warn"});
  return rows;
}
function hf05zuiR2eRenderBuilder() {
  const snapshot=hf05zuiR2eBuilderSnapshot(); const rows=hf05zuiR2eValidationRows(snapshot);
  const validation=document.getElementById("builderR2EValidation"); if(validation) validation.innerHTML=rows.map((row)=>`<div class="builder-validation-row ${row.state}"><strong>${escapeHtml(row.label)}</strong><span>${escapeHtml(row.value)}</span></div>`).join("");
  const art=document.getElementById("builderRecordedArtStatus"); if(art){ const count=snapshot.recorded_arts.rows.length,floor=snapshot.recorded_arts.required_floor; art.className=`builder-inline-status ${count>=floor?"pass":count?"warn":"fail"}`; art.textContent=`Recorded Arts: ${count} entered. HF05ZVK-R1E floor for this CL/depth: ${floor}.`; }
  const point=document.getElementById("builderPointBuyStatus"); if(point){ const p=snapshot.abilities.point_buy; point.className=`builder-inline-status ${p.valid&&p.total===27?"pass":"warn"}`; point.textContent=p.valid?`Standard point buy: ${p.total}/27 points (${p.remaining>=0?p.remaining+" remaining":Math.abs(p.remaining)+" over"}).`:`One or more scores are outside the standard 8–15 point-buy range; treating them as custom/advanced scores.`; }
  const fields=document.getElementById("builderImmortalFields"); if(fields) fields.classList.toggle("enabled",!!snapshot.immortal_art);
}
function hf05zuiR2eDraftSnapshot() { const data={spheres:[...builderSphereNames],values:{}}; HF05ZUI_R2E_BUILDER_FIELD_IDS.forEach((id)=>data.values[id]=hf05zuiR2eValue(id)); return data; }
function hf05zuiR2eSaveDraft(showToast=true){ try{localStorage.setItem("hf05zui_r2e_builder_draft",JSON.stringify(hf05zuiR2eDraftSnapshot())); const status=document.getElementById("builderDraftStatus"); if(status){status.textContent=`Draft saved ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;status.classList.add("saved");} if(showToast)toast("Builder draft saved.");}catch(e){if(showToast)toast("Could not save builder draft.");} }
function hf05zuiR2eLoadDraft(){ try{const raw=localStorage.getItem("hf05zui_r2e_builder_draft");if(!raw){toast("No saved builder draft found.");return;}const data=JSON.parse(raw);Object.entries(data.values||{}).forEach(([id,value])=>{const el=document.getElementById(id);if(!el)return;if(el.type==="checkbox")el.checked=!!value;else {if(el.tagName==="SELECT"&&![...el.options].some(o=>o.value===String(value)))return;el.value=value;}});builderSphereNames=Array.isArray(data.spheres)?data.spheres:[];updateBuilderPreview();hf05zuiR2eRenderBuilder();toast("Builder draft loaded.");}catch(e){toast("Saved builder draft could not be loaded.");} }
function hf05zuiR2eResetNewFields(){ const defaults={builderImportance:"standard",builderFoundationCatalogSet:"all",builderSourceMode:"tianxia_only",builderOriginInsightSource:"printed",builderIChing:"",builderMethodStatus:"Primary",builderForgedMode:"factory_design",builderSeedMode:"include",builderImmortalStatus:"Learned",builderImmortalActionType:"Action",builderVersion:"HF05ZUI-R2H-builder-v6"};HF05ZUI_R2E_BUILDER_FIELD_IDS.forEach((id)=>{const el=document.getElementById(id);if(!el)return;if(["builderName","builderPath","builderLevel","builderRealm","builderKeyAbility","builderStr","builderDex","builderCon","builderInt","builderWis","builderCha","builderBackground","builderBackgroundRegion","builderFoundationCatalogSelect","builderFoundationName","builderFoundationFamily","builderFoundationDepth","builderFoundationStage","builderFoundationNotes","builderMartialArtName","builderMartialArtStatus","builderMartialArtDoctrine","builderChakraRecord","builderTalents","builderInsights","builderTechniques","builderActions","builderEquipment"].includes(id))return;if(el.type==="checkbox")el.checked=false;else el.value=defaults[id]??"";});localStorage.removeItem("hf05zui_r2e_builder_draft");hf05zuiR2eRenderBuilder();}
(function hf05zuiR2eBindBuilder(){
  const legacyUpdate=updateBuilderPreview;
  updateBuilderPreview=function(){legacyUpdate();hf05zuiR2eRenderBuilder();};
  HF05ZUI_R2E_BUILDER_FIELD_IDS.forEach((id)=>{const el=document.getElementById(id);if(!el||el.dataset.r2eBound)return;el.dataset.r2eBound="true";el.addEventListener("input",()=>{hf05zuiR2eRenderBuilder();});el.addEventListener("change",()=>{hf05zuiR2eRenderBuilder();});});
  document.getElementById("builderExportFactoryZipButton")?.addEventListener("click",()=>hf05zuiR2eExport("factory"));
  document.getElementById("builderExportActionZipButton")?.addEventListener("click",()=>hf05zuiR2eExport("action"));
  document.getElementById("builderCopyFactoryPromptButton")?.addEventListener("click",()=>copyText(hf05zuiR2eFactoryPrompt()));
  document.getElementById("builderCopyActionPromptButton")?.addEventListener("click",()=>copyText(hf05zuiR2eActionOnlyPrompt()));
  document.getElementById("builderSaveDraftButton")?.addEventListener("click",()=>hf05zuiR2eSaveDraft(true));
  document.getElementById("builderLoadDraftButton")?.addEventListener("click",hf05zuiR2eLoadDraft);
  document.getElementById("builderResetButton")?.addEventListener("click",hf05zuiR2eResetNewFields);
  updateBuilderPreview(); hf05zuiR2eRenderBuilder();
})();

// HF05ZUI-R2H enriched dashboard-package compatibility surface.
const hf05zuiR2eLegacyBuilderCompleteSheet = builderCompleteSheet;
builderCompleteSheet = function builderCompleteSheetR2E() {
  const sheet = hf05zuiR2eLegacyBuilderCompleteSheet();
  const snapshot = hf05zuiR2eBuilderSnapshot();
  sheet.schema_version = "HF05ZUI-R2H.DashboardBuilderCharacter.v3";
  sheet.builder_snapshot = snapshot;
  sheet.identity.origin_insight = snapshot.origin_insight;
  sheet.identity.dao_i_ching = snapshot.dao_i_ching;
  sheet.cultivation.method = snapshot.method;
  sheet.cultivation.resource_formula_note = "Base primary resource is CL × Path key-ability modifier; Method, Foundation, and item modifiers stack when their own rules apply.";
  sheet.build.training_sources = [snapshot.training_source].filter((row) => row.name || row.doctrine);
  sheet.build.recorded_arts = snapshot.recorded_arts.rows;
  sheet.build.immortal_arts = snapshot.immortal_art ? [snapshot.immortal_art] : [];
  sheet.build.emergency_forging = snapshot.emergency_forging;
  sheet.build.composite_playbook_briefs = snapshot.composite_playbook_briefs;
  sheet.build.character_depth = snapshot.identity.character_depth;
  sheet.build.required_recorded_art_floor = snapshot.recorded_arts.required_floor;
  sheet.build.talent_execution_notes = snapshot.talent_execution_notes;
  sheet.action_generation_brief = snapshot.action_generation_brief;
  sheet.authoritative_mechanics_notes = snapshot.authoritative_mechanics_notes;
  return sheet;
};
const hf05zuiR2eLegacyBuilderPackageFiles = builderPackageFiles;
builderPackageFiles = function builderPackageFilesR2E() {
  const pkg = hf05zuiR2eLegacyBuilderPackageFiles();
  const snapshot = hf05zuiR2eBuilderSnapshot();
  const additions = [
    { name: "Builder_Snapshot.json", content: JSON.stringify(snapshot, null, 2) },
    { name: "Origin_Insight.json", content: JSON.stringify(snapshot.origin_insight, null, 2) },
    { name: "Dao_IChing_Profile.json", content: JSON.stringify(snapshot.dao_i_ching, null, 2) },
    { name: "Cultivation_Method_Profile.json", content: JSON.stringify(snapshot.method, null, 2) },
    { name: "Recorded_Arts_Planning.json", content: JSON.stringify(snapshot.recorded_arts, null, 2) },
    { name: "Selected_Foundation_Catalog_Record.json", content: JSON.stringify(snapshot.foundation, null, 2) },
    { name: "Forged_Technique_Planning.json", content: JSON.stringify({ forged_techniques: snapshot.forged_techniques, emergency_forging: snapshot.emergency_forging }, null, 2) },
    { name: "Immortal_Arts.json", content: JSON.stringify({ immortal_arts: snapshot.immortal_art ? [snapshot.immortal_art] : [] }, null, 2) },
    { name: "Composite_Playbook_Briefs.json", content: JSON.stringify({ briefs: snapshot.composite_playbook_briefs }, null, 2) }
  ];
  const existing = new Set(pkg.blocks.map((row) => row.name));
  additions.forEach((row) => { if (!existing.has(row.name)) pkg.blocks.splice(pkg.blocks.length - 1, 0, row); });
  const manifestBlock = pkg.blocks.find((row) => row.name === "package_manifest.json");
  if (manifestBlock) {
    try {
      const manifest = JSON.parse(manifestBlock.content);
      manifest.package_version = hf05zuiR2eValue("builderVersion") || "HF05ZUI-R2H-builder-v6";
      manifest.builder_patch = HF05ZUI_R2E_BUILDER_PATCH;
      manifest.files = pkg.blocks.map((row) => row.name);
      manifestBlock.content = JSON.stringify(manifest, null, 2);
    } catch {}
  }
  return pkg;
};
updateBuilderPreview();
